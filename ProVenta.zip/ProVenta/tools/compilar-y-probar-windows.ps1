[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Fail([string]$Message) {
    Write-Host "ERROR: $Message" -ForegroundColor Red
    exit 1
}

$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot

$Java = Get-Command java -ErrorAction SilentlyContinue
if (-not $Java) { Fail 'No se encontró Java. Instala JDK 17 y añade su carpeta bin al PATH.' }
$JavaVersion = (& java -version 2>&1 | Out-String)
if ($JavaVersion -notmatch 'version "17[\.]') {
    Write-Host $JavaVersion
    Fail 'ProVenta requiere JDK 17. Configura JAVA_HOME y PATH con JDK 17.'
}

$Gradle = Get-Command gradle -ErrorAction SilentlyContinue
if (-not $Gradle) { Fail 'No se encontró Gradle. Instala Gradle 8.13 y añade gradle\bin al PATH. Este proyecto no incluye Gradle Wrapper.' }
$GradleVersion = (& gradle --version 2>&1 | Out-String)
if ($GradleVersion -notmatch 'Gradle 8\.13') {
    Write-Host $GradleVersion
    Fail 'Se requiere Gradle 8.13.'
}

Write-Host 'Compilando APK debug...' -ForegroundColor Cyan
& gradle --no-daemon :app:assembleDebug
if ($LASTEXITCODE -ne 0) { Fail 'Falló :app:assembleDebug.' }

Write-Host 'Ejecutando pruebas JVM...' -ForegroundColor Cyan
& gradle --no-daemon :app:testDebugUnitTest
if ($LASTEXITCODE -ne 0) { Fail 'Falló :app:testDebugUnitTest.' }

if ($env:PROVENTA_RUN_ANDROID_TESTS -eq '1') {
    Write-Host 'Ejecutando pruebas instrumentadas. Debe haber un emulador o dispositivo autorizado disponible...' -ForegroundColor Cyan
    & gradle --no-daemon :app:connectedDebugAndroidTest
    if ($LASTEXITCODE -ne 0) { Fail 'Falló :app:connectedDebugAndroidTest.' }
}

$Apk = Join-Path $ProjectRoot 'app\build\outputs\apk\debug\app-debug.apk'
if (Test-Path $Apk) {
    Write-Host "Proceso completado. APK: $Apk" -ForegroundColor Green
} else {
    Fail 'Gradle terminó, pero no se encontró app-debug.apk en la ruta esperada.'
}
