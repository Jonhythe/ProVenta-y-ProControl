# ProVenta

Aplicación Android nativa para dependientes, integrada con ProControl. El proyecto se reconstruye desde cero en Kotlin + Jetpack Compose.

## Objetivo
Permitir que cada dependiente consulte el inventario autorizado de su punto de venta, registre ventas y entradas de mercancía y complete el cierre de turno desde su teléfono Android. ProControl sigue siendo la autoridad central del negocio.

## Reglas fundamentales
- Operación sin Internet, nube ni Wi-Fi.
- Intercambio de datos con ProControl mediante archivos locales y cable USB; QR en los flujos de recepción acordados.
- Cada teléfono se autoriza contra una instalación concreta de ProControl; los permisos de POS y turno se administran por separado. La aplicación permanece bloqueada en la pantalla de vinculación hasta que importe un primer inventario firmado por esa instalación.
- El dependiente no puede modificar el catálogo maestro, los precios oficiales ni los datos de otros puntos de venta.
- No reintroducir la unidad/presentación «caja» retirada de ProControl.
- No borrar operaciones locales hasta validar un acuse auténtico y coincidente de ProControl.
- Evitar duplicaciones mediante identificadores estables, hash e idempotencia.
- Sin telemetría, servicios de pago ni dependencias de nube.

## Diseño móvil
- Prioridad a pantallas de 320–360 dp y teléfonos de gama baja.
- Navegación inferior, formularios de una columna y controles táctiles grandes.
- Sin tablas anchas ni desplazamiento horizontal.
- Carrito en tarjetas compactas, textos legibles y estados de operación claros.

## Estado — actualización del 9 de noviembre de 2026

La base Android incluye vinculación offline, identidad criptográfica del dispositivo, almacenamiento Room/SQLCipher protegido, importación firmada de inventario `.pcinv`, pantalla Stock, permisos `.pcpermit`, apertura de turno `.pcoutbox` y validación de acuses `.pcack`.

**Ventas ya genera paquetes `sale_batch` firmados para el contrato actual de ProControl cuando los artículos usan CUP o USD con tasa USD/CUP disponible.** La venta, el descuento local de stock y el paquete de salida se guardan en una misma transacción Room. La pantalla permite exportar el archivo `.pcoutbox` por el selector de documentos y luego importar el acuse `.pcack`; solo un acuse válido cambia la venta a sincronizada. Un rechazo o conflicto queda registrado sin borrar la venta.

Los carritos que mezclan moneda o método de pago se dividen en sub-tickets vinculados por `mobileOrderId`, porque el registro actual de ProControl acepta un método y una moneda por ticket. EUR, MLC, OTRA y combinaciones aún no admitidas se conservan localmente y se muestran como no exportables: no se inventa una tasa ni se convierten a CUP silenciosamente.

**La aplicación no está terminada ni validada para distribución.** Entradas y Cierre siguen siendo pantallas provisionales. ProControl mantiene `MOBILE_APP_READY=false`, por lo que todavía no se puede completar una prueba real de importación/conciliación en Windows ni habilitar `CON_APP`. La nueva compilación y sus pruebas se deben considerar pendientes hasta que el último GitHub Actions termine correctamente.

Consulta la [auditoría técnica integral](docs/AUDITORIA_TECNICA_2026-11-09.md) y el [estado actualizado](docs/ESTADO_DEL_PROYECTO.md). No se publicará una versión estable hasta que pasen CI, pruebas instrumentadas y una validación Android ↔ ProControl por USB en un dispositivo físico.


## Documentación
- [Contexto maestro y decisiones del producto](docs/CONTEXTO_MAESTRO_PROVENTA.md)
- [Estado técnico actual](docs/ESTADO_DEL_PROYECTO.md)
- [Plan de desarrollo y criterios de aceptación](docs/PLAN_DE_DESARROLLO.md)

## Compilación
El workflow Android build compila :app:assembleDebug con JDK 17, Gradle 8.13 y compileSdk 36 y publica el APK como artefacto de la ejecución. No se requiere Android Studio para que GitHub Actions ejecute esa compilación.

## Política de desarrollo
Cada entrega debe indicar archivos modificados, pruebas realmente ejecutadas, resultados, limitaciones y tareas pendientes. No se declarará una función terminada sin comprobarla.
