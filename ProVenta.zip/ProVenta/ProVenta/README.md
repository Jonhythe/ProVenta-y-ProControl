# ProVenta — Compose UI waits and narrow-width assertions (r7)

This patch preserves the explicit debug-only Compose test host from r6 and addresses two issues found during source review:

1. Semantics queries were performed immediately after `setContent`. The tests now use `waitUntil` to allow Android's window/Compose root to attach and register. They retry only the known `No compose hierarchies found` state; unrelated `IllegalStateException`s still fail immediately.
2. Several UI expectations were stale. The current activation UI exports `.pvid`, offers copy-ID, then selects `.pvlink` and asks for a PIN. It does not show the old `Escanear QR` or `Importar USB` labels. The sales test name now matches what it actually verifies.

The 320 dp tests now assert semantics bounds remain inside the simulated width, not merely that text exists.

## Files
- `app/src/debug/AndroidManifest.xml`
- `app/src/debug/java/com/proventa/app/testing/ComposeTestActivity.kt`
- `app/src/androidTest/java/com/proventa/app/ui/CompactInventoryScreenTest.kt`
- `app/src/androidTest/java/com/proventa/app/ui/CompactPhoneLayoutTest.kt`

No production screen, security logic, database, Gradle file, or release manifest is changed.

## Validation limitation
The patch was source-reviewed and packaged with SHA-256 checksums. It was not run on the user's Samsung A26 in this environment. A `waitUntil` timeout still fails the test; it does not convert a missing Compose hierarchy into a pass. If the hierarchy never registers, the timeout is evidence that the Activity/window/test host needs a separate runtime diagnosis.
