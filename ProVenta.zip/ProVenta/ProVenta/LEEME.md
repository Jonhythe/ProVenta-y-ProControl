# Corrección de fixtures v4 de ProVenta

Este parche modifica únicamente dos archivos de pruebas unitarias:

- `app/src/test/java/com/proventa/app/security/DeviceAuthorizationDescriptorVerifierTest.kt`
- `app/src/test/java/com/proventa/app/security/DeviceBoundActivationTest.kt`

Los descriptores v4 reales emitidos desde ProControl/PVID1 usan `device_` seguido de 32 caracteres hexadecimales minúsculos. Las fixtures anteriores utilizaban `device_phone_...`, que es un ID sintético inválido para el protocolo v4.

Se actualizaron las dos fixtures v4 y el identificador usado para simular otro teléfono en la prueba de sobre .pvlink. La prueba de versión 2 se conserva sin cambios porque usa el formato legado.

**No se modifica código de producción, firma Ed25519, validación de huellas, descifrado RSA/AES-GCM, datos ni claves del teléfono.**

Aplicar sobre la raíz del proyecto ProVenta, aceptar reemplazo de esos dos archivos y ejecutar:

```powershell
.\gradlew.bat --no-daemon :app:testDebugUnitTest
```

Si las pruebas fallan de nuevo, revisar las nuevas excepciones; no desactivar validaciones para forzar el éxito.
