# Estado actual del proyecto ProVenta

**Última actualización:** 9 de noviembre de 2026.  
**Repositorio:** `Jonhythe/ProVenta`, rama `main`.

## Resumen

ProVenta es una aplicación Android nativa Kotlin/Jetpack Compose para dependientes, diseñada para funcionar sin Internet ni Wi-Fi. ProControl sigue siendo la autoridad central del catálogo, inventario, precios y validación de operaciones.

La base de seguridad, la vinculación offline, la importación del inventario y la primera integración de exportación de ventas están implementadas en código. La aplicación aún no está terminada ni validada para distribuir.

## Implementado en código

- Proyecto Android con Gradle, Kotlin, Compose Material 3 y navegación inferior compacta.
- Almacenamiento Room sobre SQLCipher, clave envuelta con AES-GCM/Android Keystore y archivos sensibles fuera de copias de seguridad Android.
- Vinculación con una instalación ProControl y solicitud firmada del dispositivo.
- Importación/validación de snapshots `.pcinv` y pantalla Stock por POS.
- Importación y verificación de permisos de turno `.pcpermit`.
- Apertura offline firmada `.pcoutbox` e importación de acuse firmado `.pcack`.
- Ventas: búsqueda, carrito, cantidades, pago por artículo, datos de transferencia, cálculo exacto y descuento local de existencias.
- Gesto de deslizar a la derecha para añadir productos al carrito, conservando el botón.
- Conversión de ventas compatibles a paquetes `sale_batch` firmados con Ed25519, vinculados al POS, trabajador, turno y permiso.
- La venta, sus líneas/pagos, descuento de existencias y paquete `sale_batch` se guardan juntos en una transacción Room.
- Los carritos mixtos se separan en sub-tickets por moneda y método de pago, relacionados por `mobileOrderId` para respetar el contrato actual del registro de ProControl.
- La pantalla Ventas exporta el paquete `.pcoutbox` mediante selector de documentos y permite importar el acuse `.pcack`.
- El acuse se verifica contra instalación, PC, dispositivo, packageId, tipo, hash y firma. Solo un resultado `applied` marca la venta como `SYNCED`; `rejected` o `conflict` dejan la venta en `REJECTED`.
- EUR, MLC, OTRA, métodos aún no admitidos o ventas USD sin tasa quedan guardadas en el teléfono, sin un paquete exportable y sin convertir importes con una tasa inventada.
- Modelos locales y máquina de estados para entradas, aunque todavía no hay flujo visual/operativo completo.

## Pendiente o incompleto

- La pantalla Entradas continúa siendo un marcador de posición. Falta implementar el flujo de despacho, escaneo/lectura QR, importación por archivo, revisión, confirmación de código, acuse final y registro.
- La pantalla Cierre continúa siendo un marcador de posición. Falta capturar conteo final, denominaciones de efectivo, transferencias, monedas, diferencias e IPV.
- La exportación de ventas está implementada en código, pero falta probar el recorrido completo Android → archivo USB → ProControl → conciliación → acuse → Android en Windows.
- El soporte contable del puente actual para EUR, MLC y moneda personalizada está pendiente. Esas ventas se conservan localmente y aparecen identificadas como no exportables.
- Falta el paquete `shift_close` completo y su recorrido de acuse/revisión.
- Falta sincronización integral por USB para ventas, entradas y cierre, más los procedimientos completos de archivo de recuperación y transcripción manual.
- Falta validar todos los pasos en un teléfono Android físico y contra ProControl instalado en Windows.

## Contrato de ventas con ProControl

El importador del escritorio valida `sale_batch` con transacciones que incluyen ticket/idempotencia, POS, trabajador, fecha, `shiftPermitId`, artículos, `baseQty`, `lineTotal` y `lineTotalCUP`. La conciliación guarda los tickets en `salesLedger` y descuenta el stock en una transacción. El informe mensual de productos vendidos consume las líneas de ese libro y contempla eventos de origen móvil.

El contrato actual usa un método/moneda por ticket. Por eso ProVenta divide una orden móvil mixta en sub-tickets relacionados. No se debe confundir esa compatibilidad de formato con una prueba real de integración: el puente de escritorio sigue manteniendo `MOBILE_APP_READY=false`.

## CI y validación

El workflow de GitHub Actions compila APK debug, ejecuta pruebas JVM y pruebas instrumentadas en emulador API 36. Una ejecución anterior confirmó que `:app:assembleDebug` terminaba correctamente, pero `:app:testDebugUnitTest` falló por una cadena con comillas escapadas dos veces en `InventorySnapshotMapperTest.kt:39`; la cadena fue corregida.

Se añadieron pruebas JVM para el contrato de exportación `sale_batch` (CUP, USD, métodos mixtos, rechazo de EUR y pagos parciales no soportados) y una prueba instrumentada para persistencia del paquete de salida junto a la venta. La última ejecución debe terminar satisfactoriamente antes de considerar validados esos cambios. También se eliminó el `copy()` generado de los objetos de autorización/acuses verificados que requieren creación exclusiva tras una verificación criptográfica.

## Próximas fases

1. Confirmar CI verde: compilación debug, pruebas JVM y pruebas instrumentadas.
2. Realizar la prueba completa de una venta CUP y una USD con un dispositivo físico y ProControl Windows, revisar `salesLedger`, informe mensual y acuse.
3. Implementar Entradas con el flujo de despacho acordado, doble confirmación, idempotencia y registro.
4. Implementar Cierre completo, respetando IPV, efectivo por denominaciones, transferencias, monedas y revisión en ProControl.
5. Añadir recuperación y transcripción manual, y cerrar el soporte contable para EUR/MLC/OTRA antes de exportar esas ventas.
6. Validar la jornada completa por USB antes de habilitar `CON_APP` o publicar una versión estable.

## Referencias

- [Auditoría técnica integral del 9 de noviembre de 2026](AUDITORIA_TECNICA_2026-11-09.md)
- [Contexto maestro y decisiones históricas](CONTEXTO_MAESTRO_PROVENTA.md)
- [Arquitectura de datos móvil](ARQUITECTURA_DATOS_MOVIL.md)
- [Plan de desarrollo](PLAN_DE_DESARROLLO.md)
