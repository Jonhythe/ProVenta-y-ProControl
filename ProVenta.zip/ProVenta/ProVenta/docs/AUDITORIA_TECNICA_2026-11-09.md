# Auditoría técnica integral de ProVenta

**Fecha:** 9 de noviembre de 2026  
**Repositorio:** `Jonhythe/ProVenta` (privado)  
**Rama revisada:** `main`  
**Alcance:** estructura completa del repositorio, aplicación Android, persistencia, seguridad, navegación, flujos de inventario/ventas/turnos, pruebas, CI y compatibilidad con el puente actual de ProControl.

## 1. Resultado ejecutivo

ProVenta tiene una base Android real y varias piezas importantes ya implementadas: vinculación con una instalación ProControl, identidad criptográfica del teléfono, almacenamiento local cifrado, importación verificada de inventario, consulta de stock, permisos de turno y apertura de turno con paquete firmado.

Sin embargo, **todavía no es una aplicación terminada ni está lista para distribuirse**. El principal problema no es la compilación del APK: el APK debug compila, pero el último CI revisado fallaba al compilar una prueba unitaria. Además, las pantallas de Entradas y Cierre siguen siendo marcadores de posición y las ventas aún no se exportan a ProControl.

## 2. Inventario del proyecto

- Aplicación Android nativa con Kotlin, Jetpack Compose y Material 3.
- Android Gradle Plugin 8.13.2, Kotlin 2.3.20, Gradle 8.13 y JDK 17 en CI.
- `minSdk 26`, `compileSdk 36`, `targetSdk 36`.
- Navegación inferior con Inicio, Ventas, Entrada, Stock y Cierre.
- Persistencia Room 2.8.5 sobre SQLCipher Android 4.20.0.
- Bouncy Castle para operaciones criptográficas Ed25519/RSA.
- Workflow de GitHub Actions que compila el APK debug, ejecuta pruebas JVM e instrumentadas en emulador y publica el APK como artefacto temporal.

La rama principal contenía 119 entradas en el árbol Git al iniciar esta auditoría. No se encontraron carpetas de distribución ni un APK release validado dentro del repositorio.

## 3. Funciones comprobadas en el código

### Vinculación y seguridad del dispositivo

- Importación de descriptor de autorización/vinculación y validación de firma Ed25519.
- Identidad del dispositivo con claves Ed25519 y RSA-3072.
- Almacenamiento local de secretos protegido con AES-256-GCM y Android Keystore.
- Archivos sensibles dentro de `noBackupFilesDir`.
- Copias de seguridad Android desactivadas en el manifiesto.
- La app bloquea el acceso a los módulos si no hay una instalación de confianza y un primer inventario firmado asociado al dispositivo.

### Inventario

- Importación de paquete de inventario `.pcinv`.
- Verificación de firma, identidad de instalación/dispositivo, envoltura RSA-OAEP-SHA256, descifrado AES-256-GCM y hash.
- Mapeo de productos, familia, unidad, alias, precios CUP en efectivo/transferencia, precio extranjero y existencias.
- Aplicación por POS en transacción Room e idempotencia por identificador de paquete.
- Pantalla Stock de consulta, selección de POS y búsqueda.

### Turnos

- Importación y verificación de permisos `.pcpermit`.
- Validación de dispositivo, trabajador, POS, secuencia y ventana horaria.
- Creación de solicitud de apertura `.pcoutbox` firmada.
- Importación de acuse `.pcack` y actualización del estado de apertura cuando el acuse coincide y su firma es válida.

### Ventas

La pantalla de Ventas **sí existe** y ya permite:
- Buscar productos por nombre, identificador, familia y alias.
- Añadir artículos al carrito; se conserva el botón y se añadió también el gesto de deslizar a la derecha.
- Ajustar cantidad por artículo.
- Elegir efectivo CUP, transferencia CUP o precio extranjero por artículo.
- Capturar teléfono y número de operación para pagos por transferencia.
- Ver subtotales separados por moneda.
- Validar existencia antes de registrar la venta.
- Guardar venta, líneas, pagos y totales, y descontar existencias en una transacción local.

**Actualización posterior a la primera auditoría:** `SaleRecordingService` ahora crea un paquete firmado `sale_batch` para las ventas CUP/USD compatibles y lo guarda junto con la venta y el descuento local de stock en una única transacción Room. `SalesScreen` permite exportar el `.pcoutbox` y volver a importar el `.pcack`; el DAO solo marca la venta `SYNCED` si el acuse ha pasado la verificación criptográfica y coincide con el paquete. Un rechazo/conflicto la marca `REJECTED`, pero no borra la venta ni restaura stock automáticamente.\n\nEl contrato actual de ProControl admite un método y una moneda por ticket; por eso los carritos mixtos se dividen en sub-tickets relacionados mediante `mobileOrderId`. EUR, MLC, OTRA, pagos parciales por línea y ventas USD sin tasa quedan conservadas localmente, sin paquete exportable. El informe mensual de ProControl consume `salesLedger` y las líneas `baseQty`/`lineTotalCUP`, por lo que este formato está alineado con la fuente que alimenta el registro de productos vendidos.\n\n**Pendiente de certificar:** la recepción real, la conciliación del paquete y el acuse entre un Android físico y ProControl Windows. El puente mantiene `MOBILE_APP_READY=false`.

### Entradas

- Hay entidad Room para recepciones.
- Hay una máquina de estados que impide pasar a CONFIRMED sin autorización final verificada ligada al mismo identificador y hash del despacho.
- El DAO conserva transiciones condicionadas por estado.

Pero la navegación sigue llamando a `ModuleScreen`: no hay pantalla operativa de entradas, escáner QR conectado a la cámara, importación completa del flujo de despacho, entrada de código de confirmación, comprobante ni registro visual de recepciones.

### Cierre

La navegación también llama a `ModuleScreen`. El DAO contempla estados de cierre pendiente y puede procesar un acuse para un paquete `shift_close`, pero todavía no existe el flujo completo de captura del cierre ni un servicio que construya el paquete de cierre.

Faltan, entre otras cosas:
- Conteo final de existencias por producto.
- Desglose de efectivo por denominaciones.
- Transferencias recibidas.
- Totales por moneda sin mezclarlas.
- Diferencias, faltantes/sobrantes y resumen.
- Cálculo IPV con la fórmula acordada y datos de stock inicial/conteo final.
- Revisión visual y paquete firmado de cierre.

## 4. Integración con ProControl

Se revisó también el repositorio privado `Jonhythe/procontrol-desktop` para comprobar el contrato del puente.

- El puente reconoce paquetes `sale_batch`, `shift_open`, `shift_close`, `transfer`, `return` y `heartbeat`.
- Las ventas deben incluir transacciones vinculadas a un único POS, un permiso de turno y un identificador estable.
- Un cierre móvil se recibe como cierre pendiente de confirmación; no debe cerrar automáticamente la caja ni consolidar las finanzas sin revisión autorizada.
- El control de disponibilidad mantiene `MOBILE_APP_READY = false`. La aplicación de escritorio rechaza activar el modo CON_APP mientras esa condición siga así.

**No se debe cambiar ese indicador a true todavía.** Primero deben completarse los flujos móviles, validar los formatos reales y pasar pruebas end-to-end entre Android y Windows.

La arquitectura aprobada sigue siendo offline-first: nada de nube, telemetría, Internet ni Wi-Fi para operar. El intercambio de archivos grandes debe realizarse localmente/por USB; QR debe limitarse a los pasos de identificación o confirmación definidos para el despacho, no sustituir sin pruebas el transporte de paquetes grandes.

## 5. Estado de pruebas y CI

En la ejecución anterior al arreglo:
- `:app:assembleDebug`: **correcto**.
- `:app:testDebugUnitTest`: **falló**.
- Pruebas instrumentadas: **omitidas** como consecuencia del fallo unitario.
- El error exacto era una cadena con comillas escapadas dos veces en `InventorySnapshotMapperTest.kt`, línea 39.

La línea se corrigió en `main`. También se cambió `VerifiedFinalAuthorization` de `data class` a clase normal: el compilador advertía que el `copy()` generado podía exponer un constructor no público y permitir copias modificadas de un objeto que representa una autorización verificada.

La validación de la revisión nueva debe basarse en la ejecución más reciente de GitHub Actions. No se considera aprobada hasta que terminen correctamente compilación, pruebas JVM y pruebas instrumentadas.

## 6. Riesgos y faltantes prioritarios

| Prioridad | Faltante | Consecuencia |
|---|---|---|
| Crítica | Prueba end-to-end del `sale_batch` exportado por USB | El código genera el paquete, pero la recepción real en Windows sigue sin certificarse |
| Crítica | Implementar Entradas real y confirmar el código del despacho | No se puede completar el flujo de recepción aprobado |
| Crítica | Implementar Cierre y paquete `shift_close` | No se puede cerrar el turno desde el teléfono |
| Crítica | CI completo y pruebas instrumentadas verdes | No hay evidencia automatizada de una build íntegra |
| Alta | Transporte/acuse completo por USB para las operaciones | No existe sincronización integral de jornada |
| Alta | Archivo de recuperación y transcripción manual | Faltan las dos vías de emergencia acordadas |
| Alta | Prueba real Android ↔ ProControl en Windows | No puede habilitarse CON_APP con seguridad |
| Media | Historial claro de ventas, entradas y cierres | Menor trazabilidad para el dependiente |

## 7. Cambios aplicados durante esta auditoría

1. Corregida la cadena Kotlin inválida en `InventorySnapshotMapperTest.kt`.
2. Añadido el gesto horizontal hacia la derecha para añadir productos al carrito en `SalesScreen.kt`; se conserva el botón como alternativa.
3. Convertido `VerifiedFinalAuthorization` y `VerifiedPackageAcknowledgement` a clases con constructor interno, evitando el `copy()` público de objetos que representan verificaciones criptográficas.
4. Añadido `SaleBatchPayloadFactory` para el formato del libro de ventas actual de ProControl.
5. Cada venta CUP/USD compatible genera un `sale_batch` firmado; la venta, el descuento de stock y el outbox se guardan en la misma transacción Room.
6. Añadida exportación del `.pcoutbox`, importación/verificación del `.pcack` y cambios `PENDING_SYNC → SYNCED/REJECTED`.
7. Añadidas pruebas JVM para conversión y división de carritos mixtos, más prueba instrumentada de persistencia del outbox.
8. EUR, MLC, OTRA, USD sin tasa y métodos no admitidos siguen locales y se identifican expresamente como no exportables.

## 8. Criterio de finalización

ProVenta solo podrá declararse lista cuando estén implementados y probados Ventas → `sale_batch` → ProControl, Entradas → confirmación del despacho, Cierre → `shift_close` pendiente de revisión, sincronización/acuse durable por USB, recuperación de errores y pruebas en un teléfono físico. No se debe borrar ningún dato local antes de verificar el acuse auténtico correspondiente.


## 9. Segunda etapa: exportación de ventas móviles

El contrato actual de `sales-ledger.js` valida tickets con `id`, `idempotencyKey`, `posId`, `user`, `ts`, `kind`, `paymentMethod`, `currency`, `items`, `totalNative` y `totalCUP`. Cada línea lleva `productId`, `name`, `baseUnit`, `presentation='unit'`, `presentationQty`, `baseQty`, `unitPrice`, `lineTotal` y `lineTotalCUP`. `control-plane.js` exige que cada transacción indique el mismo `shiftPermitId` autorizado y que su fecha se encuentre dentro de la ventana del permiso.

ProVenta convierte cantidades guardadas en micros a cantidades decimales, genera importes nativos exactos y para USD calcula `lineTotalCUP` usando la tasa contenida en el snapshot. Una orden con CUP efectivo, CUP transferencia y/o USD se divide en sub-tickets por combinación de moneda/método, unidos por `mobileOrderId`, porque el contrato de escritorio actual no admite mezcla por línea en un mismo ticket. No se envían monedas no soportadas con tasas inventadas.

La pantalla Ventas exporta el sobre firmado como `.pcoutbox`. Después de la conciliación en el escritorio, el teléfono importa el `.pcack` y comprueba firma Ed25519, `desktopId`, dispositivo, packageId, tipo y hash antes de actualizar el estado local. Las ventas rechazadas o en conflicto se preservan para revisión. Se añadió una prueba del mapper y una prueba instrumentada de guardar venta + outbox en Room. La validación CI y la prueba física Android ↔ Windows siguen pendientes.
