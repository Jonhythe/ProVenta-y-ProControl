# Arquitectura de datos local de ProVenta

## Persistencia
La aplicación usa Room sobre SQLCipher. La frase de paso de SQLCipher es aleatoria (32 bytes) y se guarda envuelta con AES-GCM mediante SecureLocalStore. La clave AES reside en Android Keystore; los archivos de la envoltura y la base de datos viven en el almacenamiento privado excluido de copias de seguridad.

Si el archivo de base de datos existe y la clave envuelta no está disponible, la apertura falla de forma cerrada. No se crea una base nueva encima de los datos cifrados existentes.

## Modelo inicial
- products: catálogo/snapshot autorizado para un POS, con precios CUP en efectivo/transferencia y precio en moneda extranjera separados.
- inventory_snapshots: último paquete firmado aplicado por POS, con packageId, hash, fecha, recuento y tasa USD/CUP cuando venga incluida en el snapshot.
- shift_permits: permisos firmados por instalación/POS/dispositivo con secuencia, ventana horaria y límites de emergencia.
- outbox_packages: paquetes offline firmados por el dispositivo, hash, archivo exportable y acuse terminal firmado por ProControl.
- sales: cabecera de venta y estado de sincronización.
- sale_currency_totals: totales separados por CUP, USD, EUR, MLC u otras monedas presentes en la venta.
- sale_lines: detalle por producto, conservando nombre y unidad como fotografía histórica.
- sale_payments: uno o varios pagos por línea; transferencias guardan teléfono y número de operación.
- goods_receipts: recepción pendiente, código/hash, estado de confirmación, hash del acuse final y registro de discrepancias.
- outbox_operations: operaciones locales pendientes de exportar a ProControl.

## Precisión monetaria
Los importes se almacenan como enteros en unidades menores de la moneda, junto con su escala. Los precios importados de ProControl se convierten a dos decimales exactos; si el snapshot contiene más precisión, se rechaza en lugar de redondear silenciosamente. No se usa Double para operaciones monetarias. Cantidades de producto se almacenan en micros (escala 1.000.000).

## Reglas de integridad
- Claves estables e índices únicos para impedir duplicados.
- El snapshot se verifica primero (firma Ed25519, RSA-OAEP-SHA256, AES-256-GCM, AAD y SHA-256); solo después se aplica en una transacción.
- Reimportar el mismo packageId es idempotente; un snapshot nuevo sustituye la revisión anterior del mismo POS sin tocar otros POS.
- Las líneas pertenecen a una venta; los pagos pertenecen a una línea.
- La suma por moneda debe coincidir exactamente con las líneas de esa moneda.
- Una venta en estado PENDING_SYNC o SYNCED debe tener cada línea totalmente cubierta por sus pagos; un pago TRANSFER exige teléfono y número de operación.
- Los importes se guardan como enteros en unidades menores; no se usa coma flotante para dinero.
- Borrar una venta de prueba elimina sus líneas y pagos por cascada, pero el flujo normal no debe borrar ventas conciliadas.
- Los movimientos se exportarán con idempotencyKey y hash de contenido.
- No se descarta el outbox hasta que ProControl devuelva un acuse válido.
- El estado de una entrada se cambia mediante transición condicionada por estado esperado y transiciones permitidas.
- La entrada no puede llegar a CONFIRMED desde el flujo normal sin acuse final asociado al mismo transferId y packageHash.

## Estado
El esquema y DAO están incorporados con Room 2.8.5 y SQLCipher Android 4.20.0 (compileSdk 36). La frase de paso SQLCipher es aleatoria y queda protegida por SecureLocalStore/Android Keystore. La importación .pcinv verifica la firma Ed25519 de la instalación, descifra RSA-OAEP-SHA256 + AES-256-GCM con AAD y hash, mapea el snapshot y lo aplica por POS de forma transaccional e idempotente. La tasa USD/CUP se conserva solo si el snapshot la incluye; no se generan tasas EUR/MLC por cuenta propia. Los permisos .pcpermit se verifican con la clave Ed25519 fijada desde .pcpair y se vinculan al deviceId, desktopId, trabajador, POS, secuencia y ventana de tiempo. La apertura genera un paquete procontrol.offline-package de tipo shift_open firmado por el teléfono; el turno permanece pendiente hasta importar un .pcack terminal firmado por el PC. Hay pruebas instrumentadas para persistencia, claves del dispositivo, alta .pcdevice v2, interoperabilidad Node→Android, snapshot, permisos de turno, apertura .pcoutbox, acuses .pcack e interfaz compacta; pruebas unitarias para cálculos monetarios, mapeo de snapshot, JSON canónico, construcción de ventas y máquina de estados de recepción. La ejecución completa de build y pruebas en CI/emulador sigue pendiente; se deben añadir migraciones antes de cambiar el esquema después de una versión instalada.
