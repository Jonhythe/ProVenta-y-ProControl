# Auditoría de la entrega de reemplazo ProVenta — continuación POS v4

## Fuente revisada

- ZIP base: `ProVenta-work-device-authorization-qr.zip`.
- Paquete previo de reemplazos: `ProVenta-Parte-2-Reemplazos-20261112.zip`.
- Los 17 archivos enumerados en `SHA256SUMS.txt` del paquete previo se contrastaron y todos coincidieron con sus SHA-256 declarados antes de aplicar el reemplazo.
- Los reemplazos se aplicaron sobre el proyecto base respetando sus rutas; no se partió de un proyecto vacío ni se descartaron sus componentes.

## Cambios v4 conservados del paquete previo

1. Alinea el descifrado de `.pvlink` con `procontrol.device-link`: firma exterior Ed25519, cabecera canónica como AAD, RSA-OAEP/SHA-256, AES-256-GCM, hash del contenido y comparación exacta de metadatos con el descriptor.
2. Alinea la verificación del descriptor v4 con `deviceSigningPublicKeyHash`, `installationCode`, `authorizedPosId` y la identidad de instalación derivada de la clave Ed25519.
3. Integra el escáner de autorización `PCQ1|D` en la pantalla de activación y mantiene el archivo `.pvlink` como alternativa USB.
4. Exige que el inventario inicial, los permisos de turno y los manifiestos de despacho pertenezcan al único POS autorizado para el teléfono.
5. Fija las firmas de permisos, inventario, manifiestos y acuses a la clave Ed25519 de la instalación validada.
6. Endurece la coincidencia de la huella de la clave de firma del teléfono y del POS en los permisos v4.
7. La pantalla principal solo considera listo el teléfono cuando el inventario almacenado coincide con instalación, dispositivo y `authorizedPosId`.

## Correcciones adicionales de esta continuación

1. **Cierre de la ruta de activación directa v4.** `activateWithEnvelope()` ya no delega en el importador genérico de descriptores. Verifica el `.pvlink`, descifra con la clave RSA privada del teléfono, verifica el descriptor v4 y su firma, comprueba el PIN de ocho cifras y el `authorizationId`, y solo entonces persiste la autorización. El importador auxiliar quedó interno y rechaza expresamente v4; la ruta antigua PVLA2 también quedó interna y solo admite el formato legado que reconoce su decodificador.
2. **Protección contra replay/rollback de POS.** Cuando ya existe una autorización v4, el mismo `authorizationId` solo puede volver a instalarse si el descriptor es idéntico. Una autorización diferente debe tener un `createdAt` firmado estrictamente posterior. Así, un enlace anterior que siga dentro de su TTL no puede recuperar el POS previo después de activar uno nuevo. Se rechaza también la degradación de v4 a formatos antiguos.
3. **Pruebas instrumentadas con enlace real.** Se añadió `DeviceLinkTestSupport`, que genera para los tests un descriptor firmado, un `.pvlink` con RSA-OAEP/AES-GCM, AAD canónico, hash y firma exterior; los tests de permisos y acuses ahora activan mediante `activateWithEnvelope()` en vez de insertar directamente una ficha v4.
4. **Prueba negativa y anti-replay de activación.** La prueba instrumentada comprueba que el descriptor v4 directo se rechaza, que un PIN erróneo no guarda autorización, que un `.pvlink` correcto sí la instala, que una nueva autorización posterior de la misma instalación puede cambiar el POS y que el enlace anterior —aunque todavía no haya caducado— no puede restaurar el POS previo.
5. **Acuses temporales.** La verificación ahora rechaza secuencias imposibles (`acknowledgedAt` anterior a `receivedAt` o `appliedAt` fuera del intervalo de recepción) aun cuando el acuse esté correctamente firmado.
6. **Reloj inyectable.** La caducidad del `.pvlink` usa el `nowMillis` recibido por el flujo, no una segunda lectura oculta del reloj del sistema. También exige `expiresAt > createdAt`.
7. Se añadieron cinco pruebas JVM para las reglas de sustitución: reimportación idéntica, cambio de POS con el mismo ID, replay de autorización anterior, reemplazo posterior y rechazo de otra instalación/degradación de formato.

## Verificaciones de esta continuación

| Comprobación | Resultado |
|---|---|
| Integridad SHA-256 de los 17 archivos del paquete previo | Aprobada (17/17) |
| Prueba aislada del ensamblador QR | Aprobada: varios fragmentos, duplicados idénticos, secuencia malformada, fragmento corto y duplicado conflictivo |
| Barrido sintáctico Kotlin de los archivos del proyecto | Sin errores estructurales detectados por el parser; no equivale a compilación ni resolución de tipos |
| Correspondencia de las rutas del paquete previo con el proyecto base | Aprobada; los archivos modificados existían y los documentos eran nuevos |
| Búsqueda de rutas de persistencia v4 desde descriptor sin `.pvlink` | Corregida en código; importador auxiliar rechaza v4 |
| Pruebas instrumentadas de permisos/acuses | Actualizadas para usar `.pvlink` real; ejecución pendiente |
| Prueba instrumentada de activación v4 y replay de POS | Añadida; ejecución pendiente |
| Pruebas JVM de sustitución anti-rollback | Añadidas; ejecución pendiente |
| `:app:assembleDebug` | No ejecutado en este entorno: no hay Gradle, Gradle Wrapper ni Android SDK disponibles |
| `:app:testDebugUnitTest` | No ejecutado en este entorno: no hay Gradle instalado |
| `:app:connectedDebugAndroidTest` | No ejecutado: no hay emulador ni dispositivo Android conectado |

El informe del paquete previo enumeraba verificaciones anteriores (pruebas del protocolo ProControl, cifrado, ensamblador QR y barrido sintáctico). Se conservan como antecedentes aportados por esa entrega, pero no se presentan como pruebas repetidas durante esta continuación.

## Pendiente de comprobar en el equipo del usuario

- Compilar `:app:assembleDebug` y ejecutar `:app:testDebugUnitTest`.
- Ejecutar `:app:connectedDebugAndroidTest` en un emulador o teléfono.
- En hardware real: alta `PVID1`, exportación/importación del `.pvlink`, escaneo de todos los QR, PIN correcto/incorrecto, inventario solo del POS asignado, permiso y apertura de turno, venta, exportación USB, conciliación y acuse.
- Emitir una nueva autorización de otro POS para el mismo teléfono y comprobar que el enlace nuevo funciona y que un `.pvlink` antiguo no restaura el POS anterior.
- Revocar y sustituir el dispositivo en ProControl y comprobar el rechazo de intercambios posteriores.
- Probar reinstalación y confirmar que se genera una identidad nueva.

## Estado que no debe confundirse con esta entrega

Esta entrega endurece la vinculación v4 y el aislamiento por POS; no completa por sí sola toda la aplicación. Entradas y Cierre siguen teniendo partes provisionales según el estado del proyecto base. El puente de ProControl mantiene `MOBILE_APP_READY=false`. No habilitar `CON APP` ni distribuir a dependientes hasta superar compilación, pruebas automatizadas y recorrido físico Android ↔ ProControl por USB.
