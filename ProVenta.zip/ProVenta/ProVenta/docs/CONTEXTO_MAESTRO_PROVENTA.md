# CONTEXTO MAESTRO DE PROVENTA
## Documento de continuidad para trasladar el proyecto a otro chat de ChatGPT

**Fecha de consolidación:** 2 de noviembre de 2026  
**Proyecto:** ProVenta — aplicación móvil de ventas y operaciones de dependientes, integrada con ProControl  
**Objetivo de este documento:** trasladar al nuevo chat todo el contexto de ProVenta disponible en las memorias de trabajo y en los documentos de la biblioteca, sin mezclar decisiones confirmadas con propuestas, documentación técnica antigua ni funciones que todavía no existen.

---

# 0. Instrucciones para el nuevo chat

El nuevo chat debe dedicarse al proyecto **ProVenta**. No debe desviar la conversación hacia el desarrollo de ProControl ni hacia la aplicación Generador de códigos, salvo cuando sea necesario explicar una integración, una licencia o un intercambio de datos con esos productos.

Actúa como director técnico y responsable de continuidad del proyecto. Antes de programar, reconstruye la arquitectura a partir del código real de ProControl y de los requisitos de este documento. No inventes archivos, rutas, funciones, reglas comerciales ni avances. No afirmes que una función existe porque esté descrita en un plan.

Usa estas etiquetas al trabajar:

- **CONFIRMADO POR EL USUARIO:** decisión o comportamiento expresado directamente por el usuario.
- **DOCUMENTADO EN LA BIBLIOTECA:** aparece en informes o planes técnicos del proyecto ProControl; hay que comprobar que corresponda a la versión actual.
- **PROPUESTA TÉCNICA:** solución sugerida para cumplir los requisitos; necesita aprobación cuando afecte al comportamiento comercial o a la experiencia del usuario.
- **PENDIENTE DE DEFINIR:** falta una decisión o detalle.
- **NO IMPLEMENTADO / NO PROBADO:** no existe todavía una app móvil real o no se ha validado el recorrido con dispositivos reales.
- **DOCUMENTACIÓN ANTIGUA O EN CONFLICTO:** no debe imponerse sobre las instrucciones posteriores del usuario ni sobre el código actual.

No avances de una fase de desarrollo a la siguiente sin explicar qué se completó, qué pruebas pasaron, qué queda pendiente y obtener la aprobación del usuario para continuar. Trabaja en pasos verificables y no hagas sustituciones masivas sin auditoría y copia de seguridad.

Cuando haya que entregar código, la preferencia general del usuario es recibir solo las carpetas y archivos modificados necesarios, conservando sus rutas relativas, en lugar de volver a enviar todo el proyecto comprimido.

---

# 1. Visión general del producto

## 1.1 Qué es ProVenta

**CONFIRMADO POR EL USUARIO:** ProVenta será una aplicación para teléfonos Android utilizada por los dependientes/trabajadores de los puntos de venta de un negocio. Servirá para operar durante el turno sin que cada punto de venta necesite una computadora.

La empresa tendrá una **computadora central** donde funciona ProControl. Los dependientes usarán sus **propios teléfonos personales** para consultar el inventario del punto, registrar ventas, registrar entradas de mercancía y hacer el cierre del turno. Al terminar, transmitirán las operaciones a ProControl conectando el teléfono a la computadora central mediante un cable USB.

ProVenta no debe convertirse en una aplicación que dependa de servicios en la nube, Internet o Wi-Fi. La necesidad expresada por el usuario es operar sin Internet y sin Wi-Fi; el mecanismo previsto de intercambio con ProControl es el cable USB y archivos locales.

## 1.2 Para qué existe

- Permitir que el dependiente trabaje desde su teléfono personal.
- Evitar tener que instalar una computadora en cada punto de venta.
- Mantener ProControl como sistema central y fuente de administración del negocio.
- Trasladar al teléfono solo los datos que necesita el punto de venta asignado.
- Registrar ventas, entradas de productos y cierre de turno sin conexión.
- Enviar a la computadora central las operaciones realizadas y las existencias actualizadas.
- Evitar pérdida, repetición o doble aplicación de movimientos cuando hay interrupciones o fallos en la conexión USB.

## 1.3 Lo que ProVenta NO es

- No es una copia libre de ProControl con todos los permisos administrativos.
- No permite que un dependiente modifique el catálogo maestro de productos.
- No necesita que haya un ordenador en cada punto de venta.
- No debe depender de Internet, nube, servidores remotos ni Wi-Fi para su funcionamiento o sincronización.
- No está implementada todavía: los informes técnicos existentes preparan parte del lado de escritorio, pero no prueban una app Android real.

---

# 2. Dispositivos y entorno operativo

## 2.1 Dispositivos

**CONFIRMADO POR EL USUARIO:**

- ProVenta será una aplicación Android.
- Cada trabajador tendrá su propio teléfono personal.
- Los teléfonos no pertenecen necesariamente a la empresa.
- La computadora principal del negocio será la que ejecuta ProControl.
- Los puntos de venta no tienen una computadora propia.
- La operación debe poder realizarse sin Internet y sin Wi-Fi.
- El intercambio principal de datos entre móvil y PC será por cable USB.

**PENDIENTE DE DEFINIR:** versión mínima de Android, modelos de teléfono admitidos, capacidad mínima, requisitos de espacio, compatibilidad exacta con distintas versiones de Windows y si se soportarán tablets además de teléfonos.

## 2.2 Entorno del propietario/desarrollador

Preferencias generales relevantes para el desarrollo:

- PC con Windows y 16 GB de RAM.
- Sin GPU NVIDIA.
- Presupuesto de software y servicios: 0 USD mensuales.
- Conectividad a Internet irregular y restricciones para pagar servicios extranjeros.
- Se prefieren tecnologías gratuitas y de código abierto, sin suscripciones ni dependencias de pago.
- El desarrollo debe poder continuar con herramientas de bajo consumo y, en lo posible, sin exigir descargas enormes.

La referencia del teléfono Samsung Galaxy A26 corresponde al teléfono del propietario utilizado para el proyecto Generador de códigos; **no debe asumirse que ese será el teléfono de todos los dependientes de ProVenta**.

---

# 3. Usuarios, puntos de venta y permisos

## 3.1 Modelo de uso

**CONFIRMADO POR EL USUARIO:** cada dependiente trabaja desde su propio teléfono. Los dependientes se alternan por días y no trabajan simultáneamente en el mismo punto de venta.

Ejemplo de operación explicado por el usuario:

- El trabajador A llega por la mañana, recibe los datos actualizados del punto y trabaja durante el día.
- Al terminar su jornada, realiza el cierre y conecta su teléfono a la computadora central para enviar los datos.
- El trabajador B sustituye al trabajador A a la mañana siguiente.
- B debe recibir el inventario actualizado después de que las operaciones de A hayan sido recibidas y procesadas por ProControl.
- No debe entregarse a B un inventario nuevo como si el turno anterior hubiera sido procesado cuando la información anterior todavía no se ha recibido o conciliado.

El flujo está pensado para que solo exista un turno operativo activo por punto de venta en cada momento. La aplicación y ProControl deben impedir que dos dispositivos operen simultáneamente sobre el mismo turno/POS si eso pudiera causar divergencias.

## 3.2 Permisos del dependiente

**CONFIRMADO POR EL USUARIO:** el dependiente sí puede:

1. Consultar el inventario asignado a su punto de venta.
2. Consultar los precios disponibles para los productos.
3. Registrar ventas.
4. Registrar entradas de productos/mercancía que llegan al punto de venta.
5. Realizar el cierre del turno.
6. Consultar sus propias operaciones del turno, según se defina la pantalla de historial.

El dependiente **no puede**:

- Cambiar el nombre maestro de un producto.
- Cambiar el código o identificador maestro del producto.
- Modificar la unidad de medida maestra.
- Cambiar los precios oficiales del catálogo.
- Administrar el inventario general del negocio o de otros puntos.
- Cambiar la configuración comercial central de ProControl.

Los permisos deben imponerse en la lógica de negocio y en la validación de las operaciones, no solamente ocultando botones o controles en la interfaz.

## 3.3 Asignación de trabajador y dispositivo

**DOCUMENTADO / PROPUESTO EN LA ARQUITECTURA DE INTEGRACIÓN:** los permisos móviles pueden vincularse a un punto de venta (POS), un dispositivo, un dependiente, una secuencia única y un periodo de vigencia. Esto permitiría que un teléfono no use un permiso emitido para otro punto o para otro trabajador.

**PENDIENTE DE DEFINIR:** si un dependiente queda ligado permanentemente a un teléfono, si puede cambiar de teléfono mediante autorización del propietario, y qué sucede ante pérdida, rotura o sustitución del dispositivo.

---

# 4. Inicio y recepción de inventario

## 4.1 Primera carga o actualización

**CONFIRMADO POR EL USUARIO:** desde la computadora central, el propietario/administrador seleccionará el punto de venta correspondiente y preparará la información que debe recibir el teléfono del dependiente.

La carga debe incluir el inventario correspondiente a ese punto con los datos que ProControl realmente guarda para cada producto. No debe crearse una ficha simplificada que pierda campos comerciales importantes. El esquema exacto de campos debe obtenerse inspeccionando el catálogo y los registros actuales de ProControl.

El teléfono recibirá únicamente la información del punto de venta que tiene asignado, no la base completa del negocio ni el inventario de otros puntos.

## 4.2 QR y cable USB

El usuario describió dos vías:

- Escanear desde ProVenta un QR generado en ProControl para iniciar la recepción/emparejamiento.
- Si el proceso QR no funciona o no resulta suficiente, usar un cable USB y confirmar la transferencia desde el PC y el teléfono.

**RESTRICCIÓN POSTERIOR EXPRESA:** el usuario indicó que no habrá Internet ni Wi-Fi, y que el intercambio se hará por USB.

**ACLARACIÓN TÉCNICA IMPORTANTE:** un QR es adecuado para identificadores, códigos de emparejamiento, permisos o acuses pequeños. No es una solución práctica para trasladar inventarios grandes y completos de forma normal. La arquitectura de ProControl también documenta el QR local para permisos/acuses compactos y el transporte de paquetes comerciales mediante archivos locales/USB. Por tanto, el criterio técnico recomendado es usar QR para iniciar o identificar el emparejamiento, y cable/archivos USB para mover el inventario y los movimientos completos. No se debe afirmar que el QR transmite toda la base de inventario si no se ha implementado un mecanismo fragmentado y probado.

## 4.3 Actualización diaria

Antes de iniciar el siguiente turno, ProControl debe confirmar que el turno anterior del mismo punto fue recibido y procesado correctamente. Si hay un paquete pendiente, en conflicto o incompleto, no se debe ofrecer silenciosamente un snapshot nuevo que pueda provocar solapamientos o doble conteo.

El snapshot inicial del punto debe tener una hora/identificador de corte. Cuando un punto pasa al modo CON APP, la autoridad del inventario para ese POS debe ser única: no se debe seguir contabilizando en paralelo un inventario viejo del escritorio y otro inventario del teléfono.

---

# 5. Operaciones durante el turno

## 5.1 Consulta de inventario

El dependiente debe poder consultar de forma rápida los productos que corresponden a su punto de venta, su existencia y los precios habilitados. La información debe ser de solo lectura cuando se trate del catálogo maestro.

El conjunto de productos y sus campos deben coincidir con lo que ProControl asignó al POS. No se deben inventar productos ni completar datos faltantes automáticamente.

## 5.2 Registro de ventas

**CONFIRMADO POR EL USUARIO:** el trabajador registrará ventas desde ProVenta durante el turno.

Las ventas deben guardar suficiente detalle para que ProControl pueda reconstruir y conciliar las operaciones: producto, identidad estable del producto, cantidad, precio aplicado, moneda/forma de pago, fecha/hora, punto de venta, turno y un identificador único del evento/ticket.

La aplicación debe impedir vender más existencias de las disponibles, salvo que el usuario apruebe expresamente una política distinta. Los datos deben conservarse localmente hasta que ProControl confirme la recepción durable.

**DOCUMENTADO EN EL LADO DE PROCONTROL:** el libro de ventas usa tickets/eventos identificables; las devoluciones documentadas son completas, requieren el ticket original y no pueden repetirse. El móvil debe utilizar identificadores idempotentes para que un reenvío no duplique una venta.

## 5.3 Registro de entrada de mercancía

**CONFIRMADO POR EL USUARIO:** el dependiente debe poder registrar la entrada de productos cuando llega mercancía al punto. Esta entrada se captura desde ProVenta, no se presupone que la haga primero el operador en ProControl.

El formulario de entrada descrito por el usuario debe permitir registrar, como mínimo:

- Producto recibido.
- Unidad de medida que corresponda al producto y al catálogo vigente.
- Precio de venta en efectivo.
- Precio de venta por transferencia.
- Precio de venta en moneda extranjera, cuando corresponda.
- Cantidad recibida.
- Nombre de la persona que entrega la mercancía.
- Opción para imprimir un comprobante/recibo de entrada.

El móvil puede registrar los valores operativos que correspondan a esa entrada, pero no debe modificar la definición maestra del producto ni alterar silenciosamente los precios oficiales del catálogo. El comportamiento exacto cuando el precio recibido difiere del catálogo debe definirse y auditarse: por ejemplo, aceptar solo campos autorizados para la entrada o dejar la modificación pendiente de aprobación central.

**IMPORTANTE SOBRE UNIDADES:** una documentación técnica antigua de ProControl menciona cajas y conversiones a unidades base. Sin embargo, una instrucción posterior del usuario para ProControl fue eliminar completamente la opción/presentación «caja» de todas las áreas donde aparecía. ProVenta no debe reintroducir la opción «caja» por copiar documentos antiguos. Debe inspeccionar el modelo vigente de ProControl y respetar las unidades realmente admitidas. La palabra «unidad de medida» del formulario no autoriza a recuperar la presentación «caja» que el usuario mandó retirar.

## 5.4 Cierre de turno

**CONFIRMADO POR EL USUARIO:** el cierre de ProVenta debe ser igual al cierre que se realiza actualmente en ProControl, incluyendo el desglose monetario necesario.

El cierre debe recoger, según las reglas actuales de ProControl:

- Conteo físico final de los productos del punto.
- Desglose del efectivo por denominaciones/monedas que use la instalación.
- Importes recibidos por transferencia.
- Importes en cada moneda que ProControl maneje en ese cierre.
- Totales, diferencias, faltantes o sobrantes y datos del turno.
- Identidad del trabajador, POS, fechas y referencias de las ventas/entradas asociadas.

La fórmula de inventario documentada para ProControl es **IPV = stock inicial − conteo final**. La política monetaria del escritorio conserva el PPP, la tasa del dólar aplicada por cierre y la separación entre efectivo y transferencia. No se deben cambiar las fórmulas ni mezclar importes de monedas distintas al integrar ProVenta.

**PUNTO QUE DEBE ARMONIZARSE:** el usuario quiere que el dependiente pueda hacer el cierre completo en el móvil; los documentos técnicos del puente de ProControl describen que un cierre móvil recibido llega como evidencia pendiente y no cambia caja ni cierra financieramente el turno de forma automática. Una solución coherente es que ProVenta capture y presente el cierre completo, mientras ProControl lo recibe como pendiente para revisión/confirmación por un usuario autorizado antes de consolidarlo. Esta regla de aprobación debe validarse con el usuario y con el flujo real actual de ProControl.

---

# 6. Transferencia de datos al terminar el día

## 6.1 Flujo normal por USB

**CONFIRMADO POR EL USUARIO:** al terminar el turno, el dependiente conecta el teléfono a la computadora central mediante cable USB. El trabajador pulsa en ProVenta la opción de enviar/entregar la jornada; en ProControl se confirma la recepción correspondiente.

El paquete debe incluir los registros realizados desde la última sincronización:

- Ventas y tickets.
- Entradas de mercancía.
- Cierre completo del turno.
- Cambios de existencias derivados de las operaciones.
- Identificadores, fechas, POS, trabajador, dispositivo y referencias del turno.

ProControl valida los datos antes de aplicarlos. Las entradas comerciales no deben cambiar inventario de forma parcial si hay un error en una parte del paquete.

## 6.2 Aplicación segura y confirmación

**PROPUESTA TÉCNICA CONSISTENTE CON LOS INFORMES DEL PUENTE:**

1. ProVenta prepara un paquete inmutable con un identificador único de transferencia.
2. Se calcula un hash de integridad y se valida su estructura antes del envío.
3. ProControl copia/recibe el paquete en una zona de preparación.
4. ProControl verifica dispositivo, POS, turno, formato, identificadores, firma o autenticación requerida, cantidades y referencias de producto.
5. El usuario autorizado revisa los resultados y resuelve conflictos.
6. La aplicación central registra todos los movimientos relacionados de forma transaccional o mediante un diario durable de aplicación/reintento.
7. ProControl genera un acuse persistente que identifica el paquete y su hash y señala el resultado.
8. ProVenta verifica que el acuse corresponda exactamente al paquete enviado y que provenga de la PC de confianza.
9. **Solo después de verificar el acuse correcto**, ProVenta elimina o archiva los datos operativos que ya fueron transferidos y deja la aplicación preparada para recibir el inventario actualizado.

Nunca se deben borrar los datos operativos inmediatamente al pulsar «Enviar», al detectar que el cable está conectado ni al copiar un archivo. El borrado requiere un acuse válido y coincidente.

## 6.3 Fallos y reintentos

El sistema debe tolerar:

- Desconexión del cable durante el envío.
- Desconexión después de copiar el archivo pero antes del acuse.
- Cierre inesperado de ProVenta.
- Cierre inesperado de ProControl.
- Reinicio de la computadora o del teléfono.
- Archivo incompleto, truncado, manipulado o duplicado.
- Fallo durante la aplicación del paquete a la base de datos.
- Recepción repetida del mismo paquete.
- Acuse perdido aunque los movimientos ya hayan sido guardados.

La clave es la **idempotencia**: cada transferencia y cada evento comercial tienen IDs estables; repetir un envío no debe repetir ventas, entradas, transferencias ni efectos de stock. El lado de escritorio ya documenta un diario durable y recibos comerciales para reconocer un paquete aplicado aunque se interrumpa la actualización de su estado final.

## 6.4 Qué se conserva en el teléfono después de una sincronización correcta

**CONFIRMADO POR EL USUARIO:** después de enviar correctamente y recibir confirmación de ProControl, ProVenta limpia los datos operativos de esa jornada/punto y queda lista para recibir el nuevo inventario.

No se debe interpretar esto como desinstalar o reiniciar completamente la aplicación. Deben conservarse, como mínimo, la identidad de la instalación, la configuración necesaria, los datos de licencia/activación, la identificación del dispositivo y la asignación autorizada del punto/dependiente. El historial operativo ya entregado puede archivarse localmente según la política que se apruebe, pero no debe perderse antes de la confirmación de la PC.

---

# 7. Procedimientos de emergencia cuando falla el USB

**CONFIRMADO POR EL USUARIO:** el usuario aprobó las dos vías de emergencia; no hay que elegir solo una.

## 7.1 Opción A: archivo de recuperación

- ProVenta genera un archivo local con la información completa necesaria para recuperar la jornada.
- El dependiente puede trasladarlo mediante USB y el propietario lo importa manualmente en ProControl.
- El archivo debe tener identificador único, integridad verificable y protección contra reimportación duplicada.
- La aplicación móvil no borra los datos originales hasta recibir confirmación de que ProControl los ha aceptado.

## 7.2 Opción B: transcripción manual

- ProVenta muestra un resumen completo y ordenado del cierre y de las operaciones para que el dependiente o el propietario pueda transcribir manualmente los datos en ProControl.
- Deben aparecer los totales y detalles necesarios para no perder ventas, entradas, conteos ni desglose monetario.
- La pantalla debe facilitar una comprobación clara de qué datos ya se han introducido manualmente.

## 7.3 Prevención de duplicados entre ambas opciones

El usuario señaló expresamente el caso crítico: se puede haber utilizado la transcripción manual y, más tarde, lograr importar el archivo de recuperación. El sistema debe detectar las operaciones ya registradas y evitar duplicarlas.

Por tanto:

- Las operaciones manuales deben quedar asociadas a identificadores/referencias recuperables.
- Al importar posteriormente el archivo, ProControl debe comparar los IDs de eventos y el estado de conciliación.
- Los eventos ya aplicados manualmente deben marcarse como existentes/aplicados, no ejecutarse de nuevo.
- El archivo original y su evidencia deben conservarse hasta que el estado final esté claro.
- Si no es posible identificar con certeza una coincidencia, debe aparecer un conflicto para revisión humana; no se debe adivinar ni duplicar automáticamente.

---

# 8. Licencias y modelo comercial de ProVenta

Esta parte debe trasladarse al nuevo chat como contexto de diseño, pero conviene mantener la distinción entre las ideas ya expresadas y los detalles todavía no cerrados.

## 8.1 Estructura conceptual

El negocio usa una computadora central con ProControl y varios puntos de venta que no tienen computadoras propias. Los trabajadores utilizan teléfonos personales con ProVenta.

El usuario habló de diferenciar:

- Licencia del negocio/instalación central de ProControl.
- Cantidad de puntos de venta autorizados.
- Cantidad de trabajadores o plazas autorizadas en cada punto.
- Activación del teléfono de cada trabajador autorizado.

## 8.2 Códigos por trabajador/plaza

**IDEA COMERCIAL EXPRESADA POR EL USUARIO, PENDIENTE DE CERRAR FORMALMENTE:**

- Se contempla autorizar una cantidad de puntos de venta.
- Dentro de cada punto se contempla un número permitido de trabajadores.
- Se habló de un código por cada trabajador/plaza autorizada.
- Una vez ocupadas/activadas las plazas permitidas, no se deberían emitir nuevos códigos para excederlas sin autorización del propietario.

No se debe asumir todavía si el código pertenece para siempre al trabajador, al teléfono, a una plaza que puede reasignarse o a una combinación de esos elementos.

## 8.3 Activación offline y vinculación al dispositivo

Con el requisito de trabajar sin Internet, el control de activaciones no puede depender de consultar un servidor remoto en cada apertura. La arquitectura propuesta previamente consiste en que la activación incluya una identidad del dispositivo y que el código firmado quede vinculado a ese dispositivo y al punto de venta/trabajador autorizado.

Un QR podría transportar el identificador o la solicitud de activación; el Generador del propietario emitiría un código/token firmado para ese dispositivo. Un código ligado criptográficamente al dispositivo no debería poder activarse sin más en otro teléfono.

**LÍMITE REAL:** la vinculación offline puede elevar mucho la protección, pero no debe prometerse como inviolable frente a dispositivos rooteados, manipulación del sistema o clonación avanzada. La política de reemplazo de un teléfono perdido/roto necesita un procedimiento de revocación/reasignación autorizado.

## 8.4 Relación con la aplicación Generador de códigos

El Generador de códigos es un proyecto separado, que se está definiendo en otro chat. Se prevé que emita licencias Ed25519 firmadas y pueda manejar perfiles para productos de PC y productos móviles. La integración de ProVenta deberá consumir el tipo de licencia móvil que se apruebe; no debe crear su propio esquema incompatible ni alterar las licencias existentes de ProControl.

Las modalidades comerciales de prueba de 1 hora, prueba de 1 semana y licencia permanente fueron definidas para el flujo comercial general del Generador. No se debe asumir automáticamente que todas las condiciones, límites o pantallas se aplican exactamente igual a cada plaza móvil de ProVenta sin confirmación específica.

---

# 9. Arquitectura técnica de integración que ya aparece en la biblioteca

**ATENCIÓN:** esta sección describe principalmente el lado de ProControl y los contratos técnicos preparados para una app futura. No significa que ProVenta esté implementada.

## 9.1 Principios de seguridad documentados

- No usar red ni CDN para sincronización.
- Usar intercambio local mediante archivos/USB.
- Usar QR local solamente para permisos/acuses pequeños o emparejamiento.
- Mantener la clave privada de licencias fuera de la aplicación instalada y de los paquetes de distribución.
- Proteger la clave privada del puente de Windows mediante DPAPI en el diseño maestro.
- La PC mantiene una clave pública de confianza para verificar mensajes/paquetes según el protocolo final.
- Validar firmas, formato, esquema, tamaño, POS, dispositivo, secuencia y estado antes de aceptar operaciones.
- Los paquetes deben tener identificadores estables y huellas/hash para detectar alteraciones y duplicados.
- No confiar solo en controles visuales del renderer: las operaciones privilegiadas deben verificarse en el proceso principal y en la lógica de negocio.
- No aplicar automáticamente un paquete comercial sin revisión/validación.

## 9.2 Formatos que aparecen en documentos de distintas revisiones

Los documentos de la biblioteca mencionan varios nombres y revisiones. Debe inspeccionarse el código real antes de fijar un único contrato:

- **`.pcx`:** formato de paquete de sincronización cifrado descrito en los informes de fases 8–10.
- **`.pcpair`:** solicitud de emparejamiento; se describe con código de seis dígitos, ID de dispositivo, etiqueta y fecha, de un solo uso y con vencimiento de cinco minutos.
- **`.pcack`:** acuse para el paquete, su hash, dispositivo y estado. En diferentes documentos se describe como cifrado y/o firmado por la PC con Ed25519; hay que verificar qué está implementado realmente.
- **`.pcbackup`:** respaldo cifrado de datos del escritorio.
- **`.pcmanifest` y `.pcfrag`:** manifiesto y fragmentos para paquetes grandes, descritos en el informe de Parte 3.
- **`.pcpkg`:** aparece en el plan maestro de una revisión anterior; no debe adoptarse sin comprobar si fue reemplazado por `.pcx` o por otro formato.

### Sobre el cifrado del `.pcx`

El informe unificado documenta:

- AES-256-GCM.
- Clave derivada de frase de paso mediante scrypt con parámetros `N=16384`, `r=8`, `p=1`.
- Salt de 16 bytes.
- IV de 12 bytes.
- Tag de autenticación de 16 bytes.
- Valores binarios codificados en Base64.
- Frase de paso de 12 a 128 caracteres.
- Límite indicado para payload de sincronización de 2 MiB y para respaldo de 25 MiB.
- Hash SHA-256 adicional para identificar/verificar el contenido.

Un informe posterior habla de fragmentación con manifiesto, hash por fragmento y hash total para paquetes grandes. Los límites, el formato final de la envoltura y el método de autenticación deben verificarse en `package-exchange.js` y los demás módulos actuales.

## 9.3 Sobre de datos y tipos de evento descritos

El contrato de `.pcx` documenta una envoltura externa con:

- `format`
- `schemaVersion`
- `packageId`
- `deviceId`
- `type`
- `createdAt`
- `payload`
- `payloadHash`

Tipos citados:

- `inventory_snapshot`: contiene `products` y `pointsOfSale`.
- `sale_batch`: lote de ventas/eventos.
- `return`: devolución.
- `transfer`: transferencia.
- `shift_open`: inicio de turno.
- `shift_close`: cierre de turno.
- `heartbeat`: señal/evento de estado.

Los eventos deben incluir un `eventId` estable. Los IDs documentados admiten letras, números, guion y guion bajo, con longitud entre 8 y 100 caracteres. Hay que cotejar estas reglas con el código que se encuentre realmente en la versión actual.

## 9.4 Emparejamiento y acuses

El plan técnico describe emparejamiento temporal con un descriptor `.pcpair`, y acuses de PC que identifican el paquete original, su hash, el dispositivo, el resultado y la fecha. El acuse sirve como prueba de que la PC recibió o procesó el paquete. El móvil no debe borrar operaciones sin validar el acuse correspondiente.

La firma Ed25519 y la persistencia de acuses aparecen en el informe de Parte 3; otros informes hacen referencia a acuses cifrados. Este es otro punto que requiere reconciliación con la implementación real.

## 9.5 Conciliación del lado de ProControl

La biblioteca documenta:

- Importar un paquete crea primero una entrada de revisión; no toca existencias por el mero hecho de importar.
- Estados de revisión: pendiente, aceptado para conciliación, conciliado, conflicto o rechazado.
- La previsualización valida esquema, identificadores, tickets, devoluciones, unidades, cantidades y referencias locales.
- Las ventas y devoluciones se guardan en el libro de ventas.
- Las devoluciones requieren ticket original válido y no se pueden duplicar.
- Las transferencias se aplican al origen y destino de forma transaccional.
- Los snapshots de inventario comparan diferencias y no reemplazan el inventario automáticamente.
- Los cierres móviles son evidencia pendiente y no crean por sí solos un cierre local definitivo.
- Los IDs de evento/dispositivo reducen el riesgo de re-aplicar operaciones.
- La aplicación del paquete y su recibo durable deben permitir recuperación tras caídas.

## 9.6 Modo SIN APP / CON APP

El plan maestro propone que el modo se controle por cada punto de venta:

- `SIN APP`: ProControl continúa operando de la forma habitual.
- `CON APP`: una vez hecho el corte y validada la integración, se deshabilitan nuevas ventas de escritorio para ese POS y el inventario móvil pasa a ser la autoridad operativa.
- Otros POS pueden seguir en `SIN APP`.
- El cambio exige backup verificado, licencia válida, autorización, conteo físico, snapshot con hora de corte y auditoría.
- Debe existir ruta de reversión segura antes del corte.

**Estado documentado:** el modo `CON APP` permanece bloqueado/deshabilitado (`MOBILE_APP_READY=false`) mientras no exista una app móvil real y no se hayan superado pruebas end-to-end. No debe habilitarse por adelantado.

## 9.7 Permisos de turno y emergencia

El plan maestro describe permisos de turno firmados, vinculados a instalación/PC, POS, dispositivo, dependiente, inicio/fin y secuencia única.

- Las ventas sin permiso válido se ponen en cuarentena para revisión.
- Se rechazan permisos alterados, caducados, repetidos o de otro POS/dispositivo.
- La emergencia está desactivada por defecto.
- Si se autoriza, está limitada por cantidad y tiempo, se concede por el Dueño, vence al finalizar el turno y no permite continuar una vez caducada.
- El informe de fases 4–6 añade que durante emergencia no se permiten devoluciones.

Este control de emergencia está documentado como diseño de seguridad del puente, pero sus reglas de negocio definitivas deben confirmarse antes de implementarlo en ProVenta.

---

# 10. Reglas comerciales y financieras que ProVenta debe respetar

La aplicación móvil no debe recalcular de manera independiente reglas financieras diferentes a las de ProControl. Debe capturar datos y entregar eventos que el sistema central pueda validar bajo las reglas vigentes.

Invariantes documentados en el plan de ProControl:

- No cambiar el PPP/costo promedio ponderado que usa la aplicación central.
- Conservar la tasa del dólar aplicada por cierre.
- Mantener efectivo y transferencia separados.
- Mantener monedas separadas; no sumar CUP, USD u otras monedas como si fueran una sola.
- Conservar la fórmula de inventario IPV = stock inicial − conteo final.
- No transformar una diferencia de stock automáticamente en una venta.
- No borrar históricos; las correcciones deben realizarse mediante estados, anulaciones o movimientos compensatorios auditables.
- No invalidar licencias PCL1 antiguas.
- Mantener un `productId` estable entre catálogo, inventario, tickets, transferencias y paquetes.
- No fusionar fichas de producto solo porque los nombres coincidan; los duplicados o casos ambiguos deben revisarse.

La documentación antigua que describe cajas y conversiones no debe prevalecer sobre la instrucción posterior del usuario de eliminar «caja» completamente del flujo vigente de ProControl.

---

# 11. Preferencias de diseño y experiencia

## 11.1 Confirmado o generalizable

- Aplicación fácil de entender y rápida para el trabajo diario.
- Interfaz sencilla, elegante e intuitiva; evitar saturar con demasiada información.
- El trabajador debe ver primero las acciones que realmente puede ejecutar según su rol.
- Formularios claros para ventas, entrada de mercancía y cierre.
- Mensajes de error y confirmaciones que expliquen qué ocurrió y si los datos se guardaron.
- No presentar una operación como completada hasta que se haya guardado/confirmado realmente.
- Mantener datos y operaciones disponibles sin conectividad.

## 11.2 Identidad visual

El usuario ha preferido en otros productos de su ecosistema una identidad premium con mármol blanco/gris, negro, azul marino y acentos dorados. Es una referencia de estilo general de RoninLab/ProControl, pero **no hay en el material recuperado una aprobación específica de una interfaz final de ProVenta**. El nuevo chat debe tratar esa estética como punto de partida opcional, no como una especificación visual cerrada.

## 11.3 Preferencias de trabajo y entregas

- Priorizar soluciones gratuitas y que no exijan pagos recurrentes.
- Evitar depender de conectividad constante o servicios externos.
- No entregar un proyecto completo comprimido en cada corrección cuando solo cambian unos archivos; entregar deltas con rutas relativas.
- Probar los cambios automatizadamente y distinguir las pruebas que realmente se ejecutaron de las que solo están previstas.
- Explicar los riesgos y las limitaciones reales; no prometer seguridad absoluta contra un administrador malicioso del dispositivo.

---

# 12. Estado real del proyecto al 2 de noviembre de 2026

## 12.1 Lo que sí existe en el material de ProControl

En la biblioteca se encontraron informes y planes de integración móvil que describen trabajo del lado de escritorio, incluidos:

- Puente móvil offline del lado de ProControl.
- Importación/exportación local de paquetes.
- Validación de estructura, hash, tamaños y estados.
- Registro/diario persistente de paquetes.
- Reglas de idempotencia y recuperación de reintentos.
- Pantalla/esqueleto de integración móvil del escritorio.
- Conciliación de tickets, devoluciones, transferencias y eventos de turno.
- Preparación de archivos de respaldo y recuperación.
- Emparejamiento y acuses locales.
- Pruebas automatizadas de varios módulos del puente y del libro de ventas.

## 12.2 Lo que NO existe o NO está certificado

Los documentos de la biblioteca son explícitos:

- No hay una aplicación móvil Android real terminada.
- No se ha probado de extremo a extremo un teléfono conectado a ProControl.
- No se ha validado el recorrido real de sincronización por USB con ProVenta.
- No se ha probado el escaneo/decodificación de QR desde la cámara de una app móvil real.
- No se ha probado la restauración/sincronización con un teléfono real.
- No debe habilitarse `CON APP` en producción antes de la aplicación móvil y la aceptación end-to-end.
- Algunas pruebas del lado de escritorio pasaron en el entorno de preparación, pero no sustituyen las pruebas visuales y funcionales en el Windows del usuario.
- Algunos informes describen entregas candidatas/parches y advierten que requieren integrarse sobre una base concreta y validarse en Windows; no deben tratarse como una aplicación unificada instalada y certificada automáticamente.

## 12.3 Pruebas que constan en los informes

Los informes técnicos registran, en distintos momentos:

- Pruebas del puente móvil y su interfaz.
- Pruebas del núcleo de licencias y permisos POS.
- Pruebas del libro de ventas.
- Pruebas de conciliación y recuperación offline.
- Pruebas de intercambio de paquetes cifrados.
- Pruebas de QR local y fragmentación de paquetes.
- Pruebas de idempotencia, estados, recibos durables y rechazo de duplicados.

Los números de aserciones varían según la revisión del informe. No se deben sumar como si pertenecieran a una única ejecución final. Un informe de fases 4–6 registra, por ejemplo, 35 aserciones de endurecimiento y pruebas del puente, ventas y conciliación; los informes de fases 8–10 detallan baterías específicas de intercambio y recuperación. La conclusión común es que **se probaron componentes de escritorio en desarrollo, no la aplicación móvil real**.

---

# 13. Diferencias y conflictos que el nuevo chat debe resolver

1. **QR vs. USB:** la descripción inicial del usuario menciona QR para recibir información; la exigencia posterior y explícita es cero Internet y cero Wi-Fi con transferencia por USB. Recomendación: QR para emparejamiento/identificadores/acuses pequeños; USB para datos completos.
2. **`.pcx` vs. `.pcpkg`:** aparecen nombres de paquete diferentes en revisiones de documentos. Inspeccionar el código actual y declarar un único formato canónico.
3. **`.pcack` cifrado vs. firmado:** algunos documentos describen acuses cifrados y otros acuses Ed25519 firmados por la PC. Inspeccionar implementación y definir cómo se autentican y protegen.
4. **Paquete directo vs. fragmentos:** algunos informes mencionan un límite de 2 MiB y otros añaden `.pcmanifest`/`.pcfrag`. Confirmar límites y protocolo vigente.
5. **Cierre realizado en móvil vs. cierre aprobado en PC:** el usuario quiere que el trabajador complete el mismo cierre desde el teléfono; los documentos del puente mantienen el cierre móvil pendiente hasta revisión autorizada. Debe definirse cómo presentar el cierre al usuario y cómo se confirma en ProControl sin alterar las reglas financieras.
6. **Catálogo y precios vs. entrada de mercancía:** el dependiente debe capturar precios asociados a la entrada, pero no puede cambiar el catálogo maestro. Definir qué campos son datos de la entrada y cuáles requieren aprobación para convertirse en datos vigentes del catálogo.
7. **Unidades y presentación caja:** documentos técnicos anteriores hablan de cajas; el usuario ordenó retirar «caja» completamente en ProControl. La app móvil debe alinearse con el modelo vigente, no con documentos antiguos.
8. **Licencia por trabajador/dispositivo:** se habló de una cantidad de puntos y trabajadores autorizados, pero falta cerrar asignación, reemplazo, pérdida de teléfono, revocación y reasignación de plazas.
9. **Eliminación tras sincronizar:** el usuario quiere limpiar datos operativos después de la entrega; el diseño de seguridad exige esperar un acuse válido. Esta condición debe mantenerse como invariante.
10. **Doble procedimiento de emergencia:** tanto el archivo de recuperación como la transcripción manual están aprobados. La deduplicación entre ambos es obligatoria.

---

# 14. Plan recomendado para continuar ProVenta

Este es un plan de trabajo sugerido, no una afirmación de fases ya aprobadas:

## Fase A — Auditoría de la línea base ProControl

- Obtener la carpeta actual y canónica de ProControl.
- Identificar las versiones reales de `electron/mobile-bridge`, `package-exchange`, `mobile-reconcile`, `sales-ledger`, `license` y el esquema SQLite.
- Inspeccionar cómo se guardan productos, POS, precios, ventas, entradas y cierres.
- Determinar qué partes de los informes coinciden con el código actual y cuáles son propuestas antiguas.
- Congelar formatos, tamaños, claves públicas y protocolo de intercambio antes de programar Android.

## Fase B — Especificación definitiva de ProVenta

- Pantallas y navegación por rol.
- Esquema de datos móvil y correspondencia exacta con ProControl.
- Flujo de asignación de teléfono, trabajador y punto.
- Flujo de carga inicial y actualización de inventario.
- Venta, entrada de mercancía y cierre.
- Manejo de turnos alternos y bloqueo de turnos pendientes.
- Política de fallos, recuperación, confirmaciones y duplicados.
- Licencias y sustitución de dispositivos.

## Fase C — Base Android offline

- Proyecto Android instalable mediante APK.
- Almacenamiento local seguro y recuperación ante cierres inesperados.
- Identidad del dispositivo, sesión y permisos.
- Interfaz sencilla adaptada a teléfonos.
- Sin telemetría ni servicios remotos.

## Fase D — Inventario y operación del turno

- Recepción/validación del snapshot del POS.
- Consulta de productos y precios.
- Registro de ventas con identificadores únicos.
- Registro de entradas de mercancía.
- Cierre con desglose equivalente a ProControl.

## Fase E — Intercambio USB con ProControl

- Emparejamiento.
- Exportación de PC a móvil.
- Envío de móvil a PC.
- Acuses, deduplicación, reintentos e interrupciones.
- Aplicación transaccional y conciliación auditada.

## Fase F — Emergencia, respaldo y restauración

- Archivo de recuperación.
- Transcripción manual asistida.
- Detección de operaciones previamente transcritas.
- Respaldo/restauración del dispositivo sin perder datos pendientes.

## Fase G — Licencias y pruebas reales

- Vinculación con el Generador de códigos.
- Activación offline ligada a dispositivo, trabajador y POS según el modelo aprobado.
- Pruebas con dos teléfonos que alternan días en un mismo punto.
- Pruebas con varios POS.
- Pruebas de desconexión, reinicio, duplicados, teléfono perdido y restauración.
- Aceptación real en Windows y Android antes de activar `CON APP`.

---

# 15. Lista de asuntos que siguen pendientes de respuesta o inspección

No es necesario resolverlos todos en una sola conversación. El nuevo chat debe plantearlos cuando la fase correspondiente los necesite.

- Versión mínima de Android y modelos mínimos admitidos.
- Si el trabajador debe autenticarse con PIN, contraseña, huella o credencial asignada.
- Si cada dependiente queda ligado a un teléfono fijo o puede usar otro tras autorización.
- Qué datos de cliente, trabajador y proveedor se guardan en cada movimiento.
- Qué debe ocurrir cuando una entrada registra precios distintos a los oficiales.
- Si el dependiente puede consultar el historial de jornadas anteriores o solo la jornada actual.
- Si puede editar/anular una venta antes de enviarla; qué permisos y auditoría se requieren.
- Si se permiten devoluciones desde ProVenta; los documentos actuales del puente restringen devoluciones durante modo de emergencia y documentan devoluciones completas que necesitan ticket original.
- Si hay más de una moneda extranjera y cuáles deben aparecer en el cierre móvil en la versión vigente de ProControl.
- Política de batería, almacenamiento, limpieza del dispositivo y protección de datos en teléfonos personales.
- Política ante teléfono perdido, roto, robado, reseteado o sustituido.
- Cómo se autoriza la reasignación de una plaza de trabajador a otro dispositivo.
- Si el propietario quiere respaldo local adicional en PC y exportación de archivo manual en cualquier momento.
- Qué mecanismo USB es compatible con los teléfonos Android y Windows de destino, y cuál ofrece la experiencia de un botón en el teléfono y confirmación en PC sin depender de Wi-Fi.

---

# 16. Documentos de la biblioteca consultados

Los siguientes archivos encontrados en la biblioteca contienen la información técnica relevante sobre el lado de ProControl y la futura integración móvil:

1. `Plan_Maestro_ProControl.md` — plan maestro de la integración móvil, invariantes financieras, permisos, modo por POS, fases y reglas de seguridad.
2. `Informe_ProControl_Parte2_Fases_4-6.md` — importación idempotente, cierres, tickets, permisos de turno y límites de lo probado.
3. `Informe_ProControl_Fases_8_9_10.md` — formatos `.pcx`, `.pcpair`, `.pcack`, cifrado, tipos de paquete, conciliación y recuperación.
4. `Informe_ProControl_Parte3_Fases_7-9.md` — modo CON APP bloqueado, QR local, fragmentos, acuses y pruebas adicionales.
5. `INFORME-FASE-UNICA-8-9-10.md` — resumen unificado del intercambio offline, deduplicación, restauración y límites end-to-end.
6. `INFORME-FASES-8-10-INTEGRADAS.md` — informe de integración de escritorio, archivos tocados y pruebas reportadas.
7. `Pruebas_Correcciones_ProControl_Completas.txt` y otros informes de pruebas de ProControl — resultados de pruebas del lado de escritorio; no constituyen prueba de la app Android.

**Resultado de búsqueda de ProVenta:** no apareció un documento maestro independiente titulado ProVenta en la biblioteca consultada. Por eso la especificación funcional de ProVenta incluida aquí procede principalmente de los requisitos y decisiones conservados de conversaciones anteriores; los documentos recuperados aportan la arquitectura del puente del lado de ProControl.

---

# 17. Límite de completitud y honestidad del traspaso

Este documento reúne toda la información de ProVenta que está disponible en el contexto y en los archivos relevantes de la biblioteca que se pudieron localizar en esta sesión. No equivale a exportar literalmente todos los chats, todos los registros internos de la cuenta ni toda la configuración privada de ChatGPT.

No se incluyen instrucciones internas del sistema, prompts ocultos, razonamiento privado ni información de cuenta que no sea accesible como memoria o archivo. Tampoco se inventan decisiones ausentes.

El nuevo chat debe tratar este documento como **contexto de continuidad**, no como prueba de implementación. La primera tarea técnica debe ser auditar el código actual de ProControl y cotejar el protocolo real con los informes antes de escribir el cliente Android.

---

## MENSAJE INICIAL PARA PEGAR EN EL NUEVO CHAT

Quiero continuar exclusivamente el desarrollo de ProVenta. Lee y asimila íntegramente el documento de contexto que adjunto. Este es el contexto maestro recuperado de conversaciones y biblioteca: distingue requisitos confirmados, diseño técnico de ProControl, propuestas, pendientes y funciones no implementadas. No confundas los informes del puente de escritorio con una app móvil ya desarrollada. Antes de programar, resume tu comprensión del producto y propón el primer paso de auditoría del código real de ProControl. Mantén el requisito de cero Internet y cero Wi-Fi, con intercambio de datos por cable USB. No avances fases sin explicar resultados y obtener mi aprobación. La app debe respetar permisos limitados del dependiente, operación offline, ventas, entradas de mercancía, cierre completo, sincronización idempotente, acuse antes de borrar datos y los dos procedimientos de emergencia aprobados: archivo de recuperación y transcripción manual. No reintroduzcas la opción «caja» retirada de ProControl. Trabaja únicamente con archivos reales y no afirmes que una función está implementada sin comprobarla.