# Plan de desarrollo técnico de ProVenta

## Principios
- Android nativo con Kotlin y Jetpack Compose.
- Offline-first: ventas, consulta local y recepción no dependen de Internet.
- ProControl es la autoridad de catálogo, precios oficiales, reglas financieras, inventario central y permisos.
- El teléfono solo opera sobre el POS y turno que recibió autorización.
- Sin telemetría, nube, suscripciones ni servicios de pago.
- Datos de negocio locales protegidos con claves del Android Keystore; no incluir datos sensibles en copias de Google.
- Intercambio por archivos firmados y cifrados, con USB como vía principal y QR para los flujos acordados.
- Las operaciones deben ser idempotentes, auditables y recuperables tras cierres inesperados.

## UX para pantallas pequeñas
- Diseñar primero para 360 dp de ancho y validar también 320 dp.
- Una acción principal por pantalla; botones táctiles de al menos 48 dp.
- Navegación inferior con cinco destinos; textos cortos e iconos reconocibles.
- Formularios en una columna; evitar tablas, controles diminutos y scroll horizontal.
- Carrito como lista de tarjetas compactas; cantidad y método de pago editables por línea.
- Resumen fijo/visible de total cuando corresponda, sin ocultar el contenido al teclado.
- Tipografía legible, contraste alto y estados claros (pendiente, confirmado, error).
- Confirmaciones antes de operaciones irreversibles y recuperación de borradores.
- No depender solo del color para comunicar errores o estados.

## Fases
1. Base Android, tema, navegación adaptable y canal de compilación automatizada.
2. Modelo local, persistencia cifrada, migraciones y pruebas de recuperación.
3. Identidad criptográfica del dispositivo y vinculación de una sola instalación ProControl.
4. Importación, validación y descifrado de paquetes de inventario por POS.
5. Ventas, carrito, pagos mixtos por artículo y comprobantes de transferencia.
6. Entradas QR/USB con doble confirmación y protección contra duplicados.
7. Cierre de turno (efectivo, desglose de monedas, transferencias e IPV) y conciliación.
8. Exportación de operaciones y recepción de acuse firmado de ProControl.
9. Pruebas de seguridad, rendimiento, accesibilidad y dispositivos Android reales.
10. APK de distribución y publicación de versiones verificadas en GitHub Releases.

## Reglas de negocio ya acordadas
- La autorización de dispositivo es por instalación ProControl, no por POS ni turno.
- El dueño emite el código desde ProControl y puede revocar o reemplazar el dispositivo.
- El POS y el turno se asignan por separado.
- Un nuevo turno no se habilita mientras el cierre/operaciones previas no estén recibidos y conciliados por ProControl.
- El dependiente no puede modificar catálogo maestro, identificadores, unidades, precios oficiales ni inventario de otros POS.
- No reintroducir la unidad/presentación «caja» retirada de ProControl.
- Pagos por transferencia guardan teléfono y número de operación; se podrá adjuntar evidencia a la venta después sin frenar el cobro.
- La entrada de mercancía queda pendiente hasta que ProControl confirme el mismo código; luego se importa el acuse final en el teléfono.
- La revocación no puede borrar de inmediato datos de un teléfono que permanece desconectado. Impide futuras entregas y operaciones al volver a validar.

## Criterios de aceptación
Ninguna fase se considera terminada solo porque exista una pantalla. Debe incluir pruebas automatizadas de reglas críticas y una comprobación real en Android cuando corresponda. No se publicará una versión estable hasta validar instalación, persistencia, cifrado, flujo offline y recuperación ante interrupciones.
