# Integración ProVenta ↔ ProControl v4

## Alcance

Este documento describe el contrato de autorización y operación que ProVenta implementa para la rama `work/device-authorization-qr`, contrastado con el código local de ProControl que acompaña a la entrega de escritorio revisada el 11 de noviembre de 2026.

La integración sigue siendo **offline por archivos y QR**. No existe una sesión de red ni una revocación instantánea mientras el teléfono está desconectado.

## 1. Alta del dispositivo

1. ProVenta crea y conserva un `deviceId`, una clave Ed25519 de firma y una clave RSA de 3072 bits para descifrado.
2. La aplicación exporta `PVID1:` con la identidad firmada `proventa.device-identity`.
3. ProControl valida la firma del teléfono, calcula las huellas SHA-256 de las claves públicas y registra la identidad en su instalación.
4. El Dueño emite una autorización para ese dispositivo y un único `authorizedPosId`.

Las claves privadas del teléfono permanecen en el almacén local cifrado; el manifiesto Android mantiene `allowBackup=false`.

## 2. Contrato exacto del archivo `.pvlink`

ProControl v4 emite un objeto exterior con:

- `format`: `procontrol.device-link`
- `version`: `1`
- `algorithm`: `RSA-OAEP-256+A256GCM`
- `installationId`, `installationCode`, `authorizationId`, `deviceId`, `authorizedPosId`
- `createdAt`, `expiresAt`, `payloadHash`, `signerPublicKey`
- `encryption`: metadatos `RSA-OAEP-SHA256` y `AES-256-GCM`, con clave envuelta, IV y etiqueta
- `ciphertext` y firma Ed25519 exterior

ProVenta valida la firma exterior antes de descifrar, comprueba que el `deviceId` pertenece a este teléfono, reconstruye la cabecera canónica como AAD, descifra con RSA-OAEP/SHA-256 y AES-256-GCM y valida el SHA-256 del texto recuperado.

El descriptor interior `procontrol.device-authorization` v4 debe contener, entre otros campos, `installationCode`, `authorizedPosId`, `deviceSigningPublicKeyHash`, `deviceId`, `permanent=true`, `code` de ocho cifras y la clave pública Ed25519 de ProControl. El descriptor interior lleva su propia firma Ed25519. En v4 no se exige el antiguo `desktopId`; la identidad estable es `installationId`, derivada de la clave pública firmante.

El PIN de ocho cifras se verifica contra el descriptor firmado después del descifrado. El PIN no sustituye al archivo cifrado ni a la clave privada del teléfono.

## 3. Transporte por QR de autorización

ProControl divide el `.pvlink` en fragmentos de 40 bytes con el canal `PCQ1|D`:

`PCQ1|D|TOKEN|NN/TT|BASE64URL`

ProVenta utiliza CameraX y ZXing para leer los símbolos con enfoque automático, envía únicamente los fragmentos del canal `D` al `DeviceAuthorizationQrAssembler`, tolera duplicados exactos, rechaza duplicados conflictivos y reconstruye el documento completo antes de validar sus metadatos. El token de ocho caracteres debe coincidir con el prefijo normalizado del `authorizationId` del `.pvlink`.

Se conserva la importación manual del archivo `.pvlink` como alternativa de transferencia USB. Después de recibir el documento por QR o USB, el dependiente introduce el PIN de ocho cifras.

## 4. Turnos, inventario, despachos y acuses

- El permiso de turno v2 debe coincidir con instalación, código de instalación, autorización, huella de la clave de firma del teléfono, dispositivo, trabajador y POS. La firma se valida con la clave Ed25519 fijada en la autorización.
- El paquete de inventario cifrado debe provenir de la clave fijada y tener como `posId` el POS autorizado.
- El manifiesto de despacho se verifica con la clave de instalación y, en v4, debe pertenecer al `authorizedPosId` aunque no se proporcione un POS esperado por separado.
- Los acuses finales (`reconciled`, `rejected`, `conflict`) se verifican con la clave pública fijada y deben identificar el paquete, dispositivo, tipo, hash y resultado exactos.
- Para v4, el `desktopId` que aparece en permisos, manifiestos y acuses puede ser un identificador efímero del plano de control. No se usa como sustituto de la identidad estable de instalación; la confianza se establece mediante la clave Ed25519 fijada y la firma.

## 5. Revocación y sustitución

ProControl vuelve a comprobar la autorización activa al emitir permisos y al recibir paquetes. La revocación bloquea los intercambios siguientes cuando el teléfono vuelve a comunicarse con ProControl; un teléfono completamente desconectado no puede recibir una revocación instantánea.

La sustitución se procesa en ProControl: al completar la nueva vinculación, la autorización anterior queda supersedida y se deshabilita el dispositivo anterior. La reinstalación de ProVenta borra los datos locales y las claves asociadas a la app; el nuevo dispositivo debe generar un nuevo `PVID1` y recibir una autorización nueva.

## 6. Sustitución y protección contra retroceso local

ProVenta conserva la autorización v4 actual en el almacenamiento local cifrado. Un nuevo enlace de la misma instalación puede sustituirla solo cuando lleva un `authorizationId` distinto y un `createdAt` firmado estrictamente posterior al de la autorización almacenada. Si se repite el mismo `authorizationId`, solo se acepta el mismo descriptor firmado; no se permite cambiarle el POS, el dispositivo ni otros datos bajo el mismo identificador. No se permite degradar desde ningún formato actual a una versión anterior; en particular, v4 nunca acepta un descriptor legado.

Esta protección evita que un `.pvlink` v4 antiguo, aunque su sobre todavía no haya vencido, restaure en el teléfono una autorización anterior después de haberse activado una más reciente. No reemplaza la revocación de ProControl: un teléfono totalmente desconectado no puede conocer una revocación nueva hasta volver a intercambiar datos.

## 7. Límites de validación

La implementación de código y sus pruebas de regresión no sustituyen las pruebas de extremo a extremo en el hardware definitivo. Antes de habilitar `CON APP` deben superarse en Windows y Android: alta, escaneo de todos los fragmentos, PIN, inventario del POS correcto, apertura de turno, ventas, cierre, transferencia, acuse, revocación, sustitución y reinstalación real.
