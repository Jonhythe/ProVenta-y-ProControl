# Fase 6 — Estabilización y validación local

## Objetivo

Validar el proyecto entregado en el ZIP local antes de desarrollar los módulos incompletos. Esta fase no requiere actualizar GitHub.

## Diagnóstico conocido al recibir el ZIP

- `:app:assembleDebug`: pasó en la última ejecución de CI disponible.
- `:app:testDebugUnitTest`: pasó en esa misma ejecución.
- `:app:connectedDebugAndroidTest`: la ejecución terminó fallando durante el arranque/interacción con el emulador: ADB mostró el dispositivo `offline` repetidamente y el runner acabó con `Broken pipe (32)` / código de salida 224. El registro no demuestra que las pruebas instrumentadas llegaran a ejecutarse; no se debe atribuir ese fallo a una prueba Kotlin concreta sin un informe JUnit.

## Por qué cambiamos el método de validación

El emulador hospedado en CI tuvo problemas de arranque y de comunicación ADB. Para la siguiente verificación local se prioriza un Android físico conectado por USB. Esto permite comprobar las pruebas instrumentadas en un entorno más representativo del uso real de ProVenta y evita depender del arranque lento del emulador remoto.

## Requisitos del PC

1. Windows 10/11 de 64 bits.
2. Java/JDK 17 o superior. Si Android Studio está instalado, puede usarse su JBR.
3. Android SDK Platform 36, Build Tools 36.0.0 y Platform-Tools (ADB). No necesitas Android Studio: puedes usar Command-line Tools oficiales.
4. Node.js 22 o superior para las pruebas instrumentadas (el generador de fixture ya está incluido).
5. Conexión a Internet durante la primera descarga de Gradle y dependencias Maven/Android. La primera compilación no es completamente offline.
6. Al menos 8 GB de RAM recomendados; el PC del proyecto dispone de 16 GB.

El script `tools/preparar-gradle-8.13.ps1` instala Gradle 8.13 en el perfil del usuario, sin permisos de administrador, y verifica el SHA-256 del ZIP oficial antes de extraerlo. Si no dispones del SDK, descarga «Command line tools only» para Windows desde [Android Developers](https://developer.android.com/studio), extrae el contenido en `%LOCALAPPDATA%\Android\Sdk\cmdline-tools\latest\` y ejecuta `tools/instalar-sdk-android-36.ps1` para aceptar licencias e instalar Platform 36, Build Tools y ADB.

## Prueba A — compilación y pruebas unitarias

Desde PowerShell, en la carpeta raíz que contiene `settings.gradle.kts`:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\tools\compilar-y-probar-windows.ps1
```

También puedes hacer doble clic en `COMPILAR_PROVENTA.bat`.

El script:

1. Comprueba Java 17 o superior.
2. Localiza Android SDK Platform 36.
3. Prepara Gradle 8.13 si no está instalado.
4. Compila `:app:assembleDebug`.
5. Ejecuta `:app:testDebugUnitTest`.
6. Informa la ruta y SHA-256 del APK.

## Prueba B — pruebas instrumentadas en el teléfono

En el teléfono Android:

1. Activa Opciones de desarrollador pulsando siete veces «Número de compilación» en Información del teléfono.
2. Activa «Depuración USB».
3. Conecta el teléfono al PC con un cable USB de datos.
4. Desbloquea el teléfono y acepta la autorización RSA de depuración.
5. Selecciona «Transferencia de archivos» si Windows lo solicita.

En PowerShell (o haciendo doble clic en `PROBAR_PROVENTA_USB.bat`):

```powershell
$env:ANDROID_SDK_ROOT = "$env:LOCALAPPDATA\Android\Sdk"
$env:ANDROID_HOME = $env:ANDROID_SDK_ROOT
& "$env:ANDROID_SDK_ROOT\platform-tools\adb.exe" devices
.\tools\compilar-y-probar-windows.ps1 -RunAndroidTests
```

El estado del dispositivo debe aparecer como `device`, no `unauthorized` ni `offline`. Gradle genera automáticamente el fixture criptográfico temporal que usa `DeviceDataPackageDecryptorTest` antes de empaquetar los assets de AndroidTest. Después ejecuta `:app:connectedDebugAndroidTest`. El script se detiene de forma explícita si ADB no ve un teléfono autorizado.

## Criterios para dar esta fase por cerrada

- `:app:assembleDebug` finaliza correctamente.
- `:app:testDebugUnitTest` finaliza correctamente.
- `:app:connectedDebugAndroidTest` se ejecuta en el teléfono y todas las pruebas instrumentadas pasan.
- El APK debug se instala y abre en el teléfono sin cierre inesperado.
- Se comprueban las pantallas a 360 dp y 320 dp, y se revisan permisos, almacenamiento y persistencia.

## Siguiente trabajo funcional después de esta fase

Una vez cerrada la validación básica, continuar con Entradas completas (despacho, lectura QR/archivo, revisión, doble confirmación, idempotencia y registro), después Cierre (efectivo por denominaciones, transferencias, monedas, diferencias e IPV), y finalmente la jornada completa Android ↔ ProControl por USB.

## Regla de repositorio

Todos los cambios de esta entrega pertenecen únicamente a la copia extraída del ZIP. No se ha actualizado GitHub, no se ha fusionado ninguna PR y no se ha habilitado `MOBILE_APP_READY` ni `CON_APP`.
