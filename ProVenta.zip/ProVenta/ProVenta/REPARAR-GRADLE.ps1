$ErrorActionPreference = 'Stop'

# Ejecutar desde la carpeta raiz de ProVenta, donde estan gradlew.bat y settings.gradle.kts.
$ProjectRoot = $PSScriptRoot
$RequiredTargets = @(
    (Join-Path $ProjectRoot 'gradlew.bat'),
    (Join-Path $ProjectRoot 'settings.gradle.kts'),
    (Join-Path $ProjectRoot 'app')
)
foreach ($Path in $RequiredTargets) {
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "No se encuentra '$Path'. Descomprime TODO el ZIP directamente en la raiz del proyecto ProVenta. No se modificaron archivos."
    }
}

$ReferenceRoot = Join-Path $ProjectRoot 'gradle-reference'
$ReferenceFiles = @(
    (Join-Path $ReferenceRoot 'build.gradle.kts'),
    (Join-Path $ReferenceRoot 'settings.gradle.kts'),
    (Join-Path $ReferenceRoot 'app\build.gradle.kts')
)
foreach ($Path in $ReferenceFiles) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "El paquete esta incompleto: falta '$Path'. No se modificaron archivos."
    }
}

# Verifica las configuraciones del paquete antes de tocar la instalacion del usuario.
$ReferenceRootBuild = Get-Content -LiteralPath $ReferenceFiles[0] -Raw
$ReferenceSettings = Get-Content -LiteralPath $ReferenceFiles[1] -Raw
$ReferenceAppBuild = Get-Content -LiteralPath $ReferenceFiles[2] -Raw
if (-not $ReferenceRootBuild.Contains('id("com.android.application") version "8.13.2" apply false')) {
    throw 'La configuracion raiz incluida en el paquete no pasa la verificacion de Android Gradle Plugin.'
}
if (-not $ReferenceAppBuild.Contains('id("com.android.application")')) {
    throw 'La configuracion app incluida en el paquete no aplica com.android.application.'
}
if (-not $ReferenceSettings.Contains('include(":app")')) {
    throw 'La configuracion settings incluida en el paquete no incluye :app.'
}
if (-not $ReferenceAppBuild.Contains('com.google.mlkit:text-recognition:16.0.1')) {
    throw 'Falta ML Kit Text Recognition en la configuracion app incluida en el paquete.'
}

# Copia de seguridad de los tres archivos existentes.
$BackupDir = Join-Path $ProjectRoot ('.backup-gradle-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
$BackupTargets = @(
    @{ Path = (Join-Path $ProjectRoot 'build.gradle.kts'); Relative = 'build.gradle.kts' },
    @{ Path = (Join-Path $ProjectRoot 'settings.gradle.kts'); Relative = 'settings.gradle.kts' },
    @{ Path = (Join-Path $ProjectRoot 'app\build.gradle.kts'); Relative = 'app\build.gradle.kts' }
)
foreach ($Item in $BackupTargets) {
    if (Test-Path -LiteralPath $Item.Path -PathType Leaf) {
        $Destination = Join-Path $BackupDir $Item.Relative
        $DestinationParent = Split-Path -Parent $Destination
        New-Item -ItemType Directory -Path $DestinationParent -Force | Out-Null
        Copy-Item -LiteralPath $Item.Path -Destination $Destination -Force
    }
}

# Instala cada archivo en su ruta exacta. No cambia codigo fuente, gradle.properties ni el Wrapper.
Copy-Item -LiteralPath $ReferenceFiles[0] -Destination (Join-Path $ProjectRoot 'build.gradle.kts') -Force
Copy-Item -LiteralPath $ReferenceFiles[1] -Destination (Join-Path $ProjectRoot 'settings.gradle.kts') -Force
Copy-Item -LiteralPath $ReferenceFiles[2] -Destination (Join-Path $ProjectRoot 'app\build.gradle.kts') -Force

# Verifica que lo instalado aplica el plugin en el modulo app (no solo en el proyecto raiz).
$InstalledRootBuild = Get-Content -LiteralPath (Join-Path $ProjectRoot 'build.gradle.kts') -Raw
$InstalledSettings = Get-Content -LiteralPath (Join-Path $ProjectRoot 'settings.gradle.kts') -Raw
$InstalledAppBuild = Get-Content -LiteralPath (Join-Path $ProjectRoot 'app\build.gradle.kts') -Raw
if (-not $InstalledRootBuild.Contains('id("com.android.application") version "8.13.2" apply false') -or
    -not $InstalledAppBuild.Contains('id("com.android.application")') -or
    -not $InstalledSettings.Contains('include(":app")')) {
    throw "La verificacion posterior fallo. Los archivos anteriores estan respaldados en '$BackupDir'."
}

Write-Host ''
Write-Host 'CONFIGURACION GRADLE REPARADA Y VERIFICADA.' -ForegroundColor Green
Write-Host "Copia de seguridad: $BackupDir"
Write-Host 'Rutas verificadas:'
Write-Host '  build.gradle.kts                (raiz; declara AGP 8.13.2 apply false)'
Write-Host '  settings.gradle.kts             (raiz; incluye :app)'
Write-Host '  app\build.gradle.kts            (modulo; aplica com.android.application y ML Kit)'
Write-Host ''
Write-Host 'Ejecuta ahora, uno por uno:' -ForegroundColor Cyan
Write-Host '  .\gradlew.bat --stop'
Write-Host '  .\gradlew.bat --no-daemon projects'
Write-Host '  .\gradlew.bat --no-daemon :app:tasks --all'
Write-Host '  .\gradlew.bat --no-daemon :app:assembleDebug'
