@echo off
setlocal
cd /d "%~dp0"
echo ========================================
echo   PROVENTA - PRUEBAS EN ANDROID USB
echo ========================================
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\compilar-y-probar-windows.ps1" -RunAndroidTests
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" (
  echo Las pruebas no terminaron correctamente. Revisa el error anterior.
) else (
  echo Todas las pruebas solicitadas terminaron correctamente.
)
pause
exit /b %RESULT%
