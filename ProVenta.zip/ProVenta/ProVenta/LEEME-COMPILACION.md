# Corrección de compilación ProVenta — CameraLumaFrameNormalizer

Este parche corrige una incompatibilidad de nombre de argumento en:

`app/src/main/java/com/proventa/app/ui/screens/GoodsDispatchQrScanner.kt`

La función `copyCameraLumaPlane` declara el primer parámetro como `sourceBuffer`; el analizador lo invocaba erróneamente como `buffer`. Se cambia únicamente el nombre del argumento a `sourceBuffer`.

## Aplicación

Extrae el contenido del ZIP sobre la raíz del proyecto ProVenta:

`D:\Apps\Administracion\ProVenta\ProVenta\ProVenta`

Permite reemplazar el archivo conservando el resto del proyecto. No desinstales la app y no borres datos ni claves.

## Verificación en Windows

Desde la raíz del proyecto ejecuta, en este orden:

```powershell
$ErrorActionPreference = 'Stop'

.\gradlew.bat --no-daemon :app:compileDebugKotlin
if ($LASTEXITCODE -ne 0) { throw 'Falló la compilación Kotlin.' }

.\gradlew.bat --no-daemon :app:testDebugUnitTest
if ($LASTEXITCODE -ne 0) { throw 'Fallaron las pruebas unitarias.' }

.\gradlew.bat --no-daemon :app:lintDebug
if ($LASTEXITCODE -ne 0) { throw 'Falló Lint.' }

.\gradlew.bat --no-daemon :app:assembleDebug
if ($LASTEXITCODE -ne 0) { throw 'Falló la generación de APK.' }
```

Este parche corrige el error de compilación reportado. No demuestra por sí solo que las pruebas de Android, Lint, la APK ni la cámara física hayan pasado; esos resultados deben confirmarse en el proyecto Windows.
