@echo off
setlocal
cd /d "%~dp0"
echo ========================================
echo   PROVENTA - COMPILAR Y PROBAR
 echo ========================================
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\compilar-y-probar-windows.ps1" %*
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" (
  echo El proceso termino con errores. Revisa el mensaje anterior.
) else (
  echo Proceso terminado correctamente.
)
pause
exit /b %RESULT%
