# Keep serialization and cryptographic entry points when minifying.
-keepattributes *Annotation*

# Bouncy Castle is loaded through JCA provider APIs.
-keep class org.bouncycastle.jce.provider.BouncyCastleProvider { *; }
-keep class org.bouncycastle.crypto.** { *; }

-keep class org.bouncycastle.jcajce.provider.** { *; }
