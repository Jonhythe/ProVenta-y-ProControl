package com.proventa.app.testing

import androidx.activity.ComponentActivity

/**
 * Debug-only, empty host for isolated Compose UI tests.
 * Do not call setContent here; each test rule owns the single composition.
 */
class ComposeTestActivity : ComponentActivity()
