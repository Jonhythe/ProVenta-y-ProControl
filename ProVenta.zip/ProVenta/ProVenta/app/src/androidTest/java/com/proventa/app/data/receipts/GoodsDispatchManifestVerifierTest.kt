package com.proventa.app.data.receipts

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import android.util.Base64
import com.proventa.app.security.CanonicalJson
import com.proventa.app.security.VerifiedDeviceAuthorization
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.nio.charset.StandardCharsets
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.time.Instant

@RunWith(AndroidJUnit4::class)
class GoodsDispatchManifestVerifierTest {
    private val provider = BouncyCastleProvider()

    @Test
    fun verifiesSignedManifestAndPinnedInstallation() {
        val now = System.currentTimeMillis()
        val fixture = createManifest(now)
        val verifier = GoodsDispatchManifestVerifier(
            InstrumentationRegistry.getInstrumentation().targetContext
        )

        val verified = verifier.verifyWithAuthorization(
            fixture.document.toString(),
            fixture.authorization,
            "pos_test_01",
            now
        )

        assertEquals("dispatch_test_01", verified.dispatchId)
        assertEquals("pos_test_01", verified.posId)
        assertEquals("Punto de prueba", verified.posName)
        assertEquals(1, JSONObject(verified.rawJson).getJSONArray("items").length())
        assertEquals(fixture.itemsHash, verified.itemsHash)
        assertEquals(fixture.codeHash, verified.confirmationCodeHash)
    }

    @Test
    fun rejectsModifiedItemsEvenWhenTheOuterManifestIsResigned() {
        val now = System.currentTimeMillis()
        val fixture = createManifest(now)
        fixture.document.getJSONArray("items")
            .getJSONObject(0)
            .put("quantity", 99.0)
        resign(fixture.document, fixture.desktopKeys)

        val verifier = GoodsDispatchManifestVerifier(
            InstrumentationRegistry.getInstrumentation().targetContext
        )
        assertThrows(IllegalArgumentException::class.java) {
            verifier.verifyWithAuthorization(
                fixture.document.toString(),
                fixture.authorization,
                "pos_test_01",
                now
            )
        }
    }

    @Test
    fun rejectsManifestThatExposesTheSeparateConfirmationCode() {
        val now = System.currentTimeMillis()
        val fixture = createManifest(now)
        fixture.document.put("confirmationCode", "12345678")
        resign(fixture.document, fixture.desktopKeys)

        val verifier = GoodsDispatchManifestVerifier(
            InstrumentationRegistry.getInstrumentation().targetContext
        )
        assertThrows(IllegalArgumentException::class.java) {
            verifier.verifyWithAuthorization(
                fixture.document.toString(),
                fixture.authorization,
                null,
                now
            )
        }
    }


    @Test
    fun rejectsManifestForAnotherPosEvenWhenSignedByTheSameInstallation() {
        val now = System.currentTimeMillis()
        val fixture = createManifest(now)
        fixture.document.put("posId", "pos_other_02")
        resign(fixture.document, fixture.desktopKeys)

        val verifier = GoodsDispatchManifestVerifier(
            InstrumentationRegistry.getInstrumentation().targetContext
        )
        assertThrows(IllegalArgumentException::class.java) {
            verifier.verifyWithAuthorization(
                fixture.document.toString(),
                fixture.authorization,
                null,
                now
            )
        }
    }

    @Test
    fun v5InstallationAuthorizationAllowsSignedDispatchForPermitScopedPos() {
        val now = System.currentTimeMillis()
        val fixture = createManifest(
            now = now,
            authorizationVersion = 5,
            authorizedPosId = null,
            manifestPosId = "pos_test_02"
        )
        val verifier = GoodsDispatchManifestVerifier(
            InstrumentationRegistry.getInstrumentation().targetContext
        )

        val verified = verifier.verifyWithAuthorization(
            fixture.document.toString(),
            fixture.authorization,
            "pos_test_02",
            now
        )
        assertEquals("pos_test_02", verified.posId)
        assertThrows(IllegalArgumentException::class.java) {
            verifier.verifyWithAuthorization(
                fixture.document.toString(),
                fixture.authorization,
                "pos_other_03",
                now
            )
        }
    }

    private data class Fixture(
        val document: JSONObject,
        val authorization: VerifiedDeviceAuthorization,
        val desktopKeys: KeyPair,
        val itemsHash: String,
        val codeHash: String
    )

    private fun createManifest(
        now: Long,
        authorizationVersion: Int = 4,
        authorizedPosId: String? = "pos_test_01",
        manifestPosId: String = authorizedPosId ?: "pos_test_01"
    ): Fixture {
        val desktopKeys = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val publicPem = toPem(desktopKeys.public.encoded)
        val installationHash = sha256(desktopKeys.public.encoded)
        val installationId = "pcinst_" + installationHash.take(32)
        val installationShort = installationHash.take(16).uppercase()
        val installationCode = "PC-${installationShort.substring(0, 4)}-${installationShort.substring(4, 8)}-${installationShort.substring(8, 12)}-${installationShort.substring(12, 16)}"
        val authorization = VerifiedDeviceAuthorization(
            installationId = installationId,
            authorizationId = "auth_test_0123456789abcdef",
            // The v4 descriptor has no separate desktopId; its signer is pinned
            // by the installation fingerprint and Ed25519 key.
            desktopId = installationId,
            code = "12345678",
            employeeName = "Dependiente de prueba",
            expiresAt = now + 3_600_000L,
            desktopPublicKeyPem = publicPem,
            rawJson = "{}",
            deviceId = "device_manifest_test_1234",
            permanent = true,
            version = authorizationVersion,
            installationCode = installationCode,
            authorizedPosId = authorizedPosId,
            deviceSigningPublicKeyHash = "a".repeat(64)
        )
        val items = JSONArray().put(
            JSONObject()
                .put("productId", "rice_01")
                .put("name", "Arroz")
                .put("family", "granos")
                .put("unit", "lb")
                .put("quantity", 12.5)
                .put("sale", 100)
                .put("saleTransf", 108)
                .put("saleTransfMode", "percentage")
                .put("saleTransfPercent", 8)
                .put("saleUSD", 1.5)
                .put("saleCurrency", "USD")
                .put("saleCustomCurrency", "")
                .put("aliases", JSONArray().put("arroz"))
        )
        val itemsHash = sha256(CanonicalJson.stringify(items).toByteArray(StandardCharsets.UTF_8))
        val codeHash = sha256("12345678".toByteArray(StandardCharsets.UTF_8))
        val document = JSONObject()
            .put("format", "procontrol.goods-dispatch")
            .put("version", 1)
            .put("installationId", installationId)
            .put("desktopId", "control_plane_device_987654")
            .put("dispatchId", "dispatch_test_01")
            .put("posId", manifestPosId)
            .put("posName", "Punto de prueba")
            .put("createdAt", Instant.ofEpochMilli(now).toString())
            .put("expiresAt", now + 3_600_000L)
            .put("itemsHash", itemsHash)
            .put("confirmationCodeHash", codeHash)
            .put("items", items)
            .put("desktopPublicKey", publicPem)
        resign(document, desktopKeys)
        return Fixture(document, authorization, desktopKeys, itemsHash, codeHash)
    }

    private fun resign(document: JSONObject, keys: KeyPair) {
        document.remove("signature")
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(keys.private)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put(
            "signature",
            JSONObject()
                .put("algorithm", "Ed25519")
                .put("value", Base64.encodeToString(signer.sign(), Base64.NO_WRAP))
        )
    }

    private fun toPem(der: ByteArray): String {
        val encoded = Base64.encodeToString(der, Base64.NO_WRAP)
        return "-----BEGIN PUBLIC KEY-----\n" +
            encoded.chunked(64).joinToString("\n") +
            "\n-----END PUBLIC KEY-----\n"
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256")
            .digest(bytes)
            .joinToString("") { "%02x".format(it) }
}
