package com.proventa.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.proventa.app.security.DeviceEnrollmentRequestFactory
import com.proventa.app.security.DeviceLinkTestSupport
import com.proventa.app.security.ProVentaActivationCode
import com.proventa.app.security.SecureLocalStore
import com.proventa.app.testing.ComposeTestActivity
import com.proventa.app.ui.ProVentaApp
import com.proventa.app.ui.screens.ActivationScreen
import com.proventa.app.ui.screens.SalesScreen
import com.proventa.app.ui.theme.ProVentaTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class CompactPhoneLayoutTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<ComposeTestActivity>()

    /**
     * Waits for Android to attach/register the Compose root and for the expected
     * semantics node to appear. Only the known "no hierarchy yet" condition is
     * retried; unrelated IllegalStateExceptions are allowed to fail the test.
     */
    private fun waitForText(text: String, substring: Boolean = false) {
        composeRule.waitUntil(
            conditionDescription = "Compose must expose the semantics node '$text'",
            timeoutMillis = 15_000L
        ) {
            try {
                composeRule.onAllNodesWithText(text, substring = substring)
                    .fetchSemanticsNodes().isNotEmpty()
            } catch (error: IllegalStateException) {
                if (error.message.orEmpty().contains("No compose hierarchies found")) {
                    false
                } else {
                    throw error
                }
            }
        }
    }

    /** Verifies both presence and that the semantics bounds stay inside 320 dp. */
    private fun assertTextWithinWidth(text: String, substring: Boolean = false, widthDp: Int = 320) {
        waitForText(text, substring)
        val density = InstrumentationRegistry.getInstrumentation()
            .targetContext.resources.displayMetrics.density
        val rightLimitPx = widthDp * density
        val nodes = composeRule.onAllNodesWithText(text, substring = substring)
            .fetchSemanticsNodes()

        assertTrue("Expected a semantics node for '$text'", nodes.isNotEmpty())
        nodes.forEach { node ->
            val bounds = node.boundsInRoot
            assertTrue(
                "'$text' exceeds ${widthDp}dp: left=${bounds.left}px, right=${bounds.right}px, limit=${rightLimitPx}px",
                bounds.left >= -1f && bounds.right <= rightLimitPx + 1f
            )
        }
    }

    @Test
    fun activationScreenFitsNarrowPhoneBeforeLinking() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SecureLocalStore(context)
        store.delete("device_authorization_descriptor")
        store.delete("activation_attempts")

        try {
            composeRule.setContent {
                ProVentaTheme {
                    Box(Modifier.width(320.dp).height(760.dp)) {
                        ActivationScreen(onActivated = {})
                    }
                }
            }

            // New compact flow: export .pvid to ProControl, then paste one signed code.
            assertTextWithinWidth("ProVenta")
            assertTextWithinWidth("Exportar archivo de identidad (.pvid)", substring = true)
            assertTextWithinWidth("Código de activación de ProControl")
            assertTextWithinWidth("Validar código y entrar")
            assertTrue("El flujo no debe ofrecer escáner QR de activación", composeRule.onAllNodesWithText("Escanear QR").fetchSemanticsNodes().isEmpty())
            assertTrue("El flujo no debe ofrecer importación de .pvlink", composeRule.onAllNodesWithText("Importar USB").fetchSemanticsNodes().isEmpty())
            assertTrue("El flujo no debe pedir un PIN separado", composeRule.onAllNodesWithText("PIN de activación").fetchSemanticsNodes().isEmpty())
            assertTrue("El teléfono no debe ofrecer copiar la identidad en pantalla", composeRule.onAllNodesWithText("Copiar ID como alternativa").fetchSemanticsNodes().isEmpty())
        } finally {
            store.delete("device_authorization_descriptor")
            store.delete("activation_attempts")
        }
    }

    @Test
    fun appOpensAfterSignedCodeEvenWhenInventoryHasNotArrived() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SecureLocalStore(context)
        store.delete("device_authorization_descriptor")
        store.delete("activation_attempts")

        try {
            val now = System.currentTimeMillis()
            val fixture = DeviceLinkTestSupport.create(
                context = context,
                authorizedPosId = "pos_compact_layout_${now}",
                nowMillis = now
            )
            val activationCode = ProVentaActivationCode.encode(fixture.rawDescriptor)
            val activated = DeviceEnrollmentRequestFactory(context)
                .activateWithActivationCode(activationCode, now)
            assertEquals(4, activated.version)

            // No inventory snapshot is created in this test: a valid signed code
            // must open the workspace immediately, leaving stock import for later.
            composeRule.setContent {
                ProVentaTheme {
                    Box(Modifier.width(320.dp).height(760.dp)) {
                        ProVentaApp()
                    }
                }
            }

            assertTextWithinWidth("Accesos principales")
            assertTextWithinWidth("Tu jornada, clara y organizada")
            assertTextWithinWidth("Ventas")
            assertTrue(
                "No debe regresar a la pantalla de activación tras aceptar el código",
                composeRule.onAllNodesWithText("Código de activación de ProControl").fetchSemanticsNodes().isEmpty()
            )
        } finally {
            store.delete("device_authorization_descriptor")
            store.delete("activation_attempts")
        }
    }

    @Test
    fun salesScreenStartsWithCompactHeaderWithinNarrowWidth() {
        composeRule.setContent {
            ProVentaTheme {
                Box(Modifier.width(320.dp).height(760.dp)) {
                    SalesScreen()
                }
            }
        }

        // This test checks the compact header only. SalesScreen deliberately
        // shows an empty-inventory message when no authorized snapshot exists.
        assertTextWithinWidth("Ventas")
    }
}
