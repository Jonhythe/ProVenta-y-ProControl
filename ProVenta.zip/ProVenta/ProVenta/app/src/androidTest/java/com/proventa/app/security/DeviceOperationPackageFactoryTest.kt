package com.proventa.app.security

import android.util.Base64
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import kotlinx.coroutines.runBlocking
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.Signature
import java.security.MessageDigest
import java.security.spec.X509EncodedKeySpec

@RunWith(AndroidJUnit4::class)
class DeviceOperationPackageFactoryTest {
    @Test
    fun createsProControlOfflinePackageSignedByPersistentDeviceKey() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SecureLocalStore(context)
        store.delete("device_authorization_descriptor")
        store.delete("activation_attempts")

        val now = System.currentTimeMillis()
        val fixture = DeviceLinkTestSupport.create(
            context = context,
            authorizedPosId = "pos_package_test",
            employeeName = "Dependiente de prueba",
            nowMillis = now
        )
        val activated = DeviceLinkTestSupport.activate(context, fixture, now)
        assertEquals(4, activated.version)
        assertEquals("pos_package_test", activated.authorizedPosId)

        val shift = JSONObject()
            .put("id", "shift_${java.util.UUID.randomUUID()}")
            .put("permitId", java.util.UUID.randomUUID().toString())
            .put("posId", fixture.authorizedPosId)
            .put("sequence", 1)
            .put("startedAt", now)
        val payload = JSONObject().put("shift", shift)
        val result = DeviceOperationPackageFactory(context).create("shift_open", payload, now)
        val envelope = JSONObject(result.envelopeJson)

        assertEquals("procontrol.offline-package", envelope.getString("format"))
        assertEquals(1, envelope.getInt("version"))
        assertEquals(result.packageId, envelope.getString("packageId"))
        assertEquals(result.deviceId, envelope.getString("deviceId"))
        val expectedPayloadHash = MessageDigest.getInstance("SHA-256")
            .digest(CanonicalJson.stringify(payload).toByteArray(StandardCharsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        assertEquals(expectedPayloadHash, result.payloadHash)
        assertEquals(result.payloadHash, envelope.getString("payloadHash"))
        assertEquals("shift_open", envelope.getString("type"))

        val signerPublicKey = KeyFactory.getInstance("Ed25519", BouncyCastleProvider()).generatePublic(
            X509EncodedKeySpec(decodePem(fixture.phoneKeys.signingPublicPem))
        )
        val signature = envelope.getJSONObject("signature")
        assertEquals("Ed25519", signature.getString("algorithm"))
        val verifier = Signature.getInstance("Ed25519", BouncyCastleProvider())
        verifier.initVerify(signerPublicKey)
        verifier.update(
            CanonicalJson.stringify(CanonicalJson.withoutSignature(envelope))
                .toByteArray(StandardCharsets.UTF_8)
        )
        assertTrue(verifier.verify(Base64.decode(signature.getString("value"), Base64.DEFAULT)))
    }

    @Test
    fun refusesToSignAnyBusinessPackageForDifferentPos() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SecureLocalStore(context)
        store.delete("device_authorization_descriptor")
        store.delete("activation_attempts")

        val now = System.currentTimeMillis()
        val fixture = DeviceLinkTestSupport.create(
            context = context,
            authorizedPosId = "pos_package_scope_test",
            employeeName = "Dependiente de prueba",
            nowMillis = now
        )
        DeviceLinkTestSupport.activate(context, fixture, now)

        val shift = JSONObject()
            .put("id", "shift_scope_test")
            .put("permitId", java.util.UUID.randomUUID().toString())
            .put("posId", "pos_other_business")
            .put("sequence", 1)
            .put("startedAt", now)
        val cases = listOf(
            "shift_open" to JSONObject().put("shift", shift),
            "sale_batch" to JSONObject().put(
                "transactions",
                org.json.JSONArray().put(
                    JSONObject()
                        .put("posId", "pos_other_business")
                        .put("mobileOrderId", "sale_scope_test")
                )
            ),
            "goods_receipt" to JSONObject()
                .put("posId", "pos_other_business")
                .put("dispatchId", "dispatch_scope_test"),
            "shift_close" to JSONObject()
                .put("shift", JSONObject(shift.toString()).put("posId", fixture.authorizedPosId))
                .put("closingReport", JSONObject().put("posId", "pos_other_business"))
        )

        cases.forEach { (type, payload) ->
            try {
                DeviceOperationPackageFactory(context).create(type, payload, now)
                throw AssertionError("Se firmó $type con datos de un POS distinto del autorizado.")
            } catch (expected: IllegalArgumentException) {
                assertTrue(
                    "$type debe rechazarse por discrepancia de POS: ${expected.message}",
                    expected.message.orEmpty().contains("punto de venta")
                )
            }
        }
    }

    private fun decodePem(pem: String): ByteArray = Base64.decode(
        pem.replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() },
        Base64.DEFAULT
    )
}
