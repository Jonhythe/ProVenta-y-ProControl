package com.proventa.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.proventa.app.testing.ComposeTestActivity
import com.proventa.app.ui.screens.InventoryScreen
import com.proventa.app.ui.theme.ProVentaTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class CompactInventoryScreenTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<ComposeTestActivity>()

    /**
     * Waits for Android to attach/register the Compose root and for the expected
     * semantics node to appear. Only the known "no hierarchy yet" condition is
     * retried; unrelated IllegalStateExceptions are allowed to fail the test.
     */
    private fun waitForText(text: String, substring: Boolean = false) {
        composeRule.waitUntil(
            conditionDescription = "Compose must expose the semantics node '$text'",
            timeoutMillis = 15_000L
        ) {
            try {
                composeRule.onAllNodesWithText(text, substring = substring)
                    .fetchSemanticsNodes().isNotEmpty()
            } catch (error: IllegalStateException) {
                if (error.message.orEmpty().contains("No compose hierarchies found")) {
                    false
                } else {
                    throw error
                }
            }
        }
    }

    /** Verifies both presence and that the semantics bounds stay inside 320 dp. */
    private fun assertTextWithinWidth(text: String, substring: Boolean = false, widthDp: Int = 320) {
        waitForText(text, substring)
        val density = InstrumentationRegistry.getInstrumentation()
            .targetContext.resources.displayMetrics.density
        val rightLimitPx = widthDp * density
        val nodes = composeRule.onAllNodesWithText(text, substring = substring)
            .fetchSemanticsNodes()

        assertTrue("Expected a semantics node for '$text'", nodes.isNotEmpty())
        nodes.forEach { node ->
            val bounds = node.boundsInRoot
            assertTrue(
                "'$text' exceeds ${widthDp}dp: left=${bounds.left}px, right=${bounds.right}px, limit=${rightLimitPx}px",
                bounds.left >= -1f && bounds.right <= rightLimitPx + 1f
            )
        }
    }

    @Test
    fun inventoryImportActionFitsNarrowPhone() {
        composeRule.setContent {
            ProVentaTheme {
                Box(Modifier.width(320.dp).height(700.dp)) {
                    InventoryScreen()
                }
            }
        }

        assertTextWithinWidth("Inventario")
        assertTextWithinWidth("Importar inventario .pcinv")
    }
}
