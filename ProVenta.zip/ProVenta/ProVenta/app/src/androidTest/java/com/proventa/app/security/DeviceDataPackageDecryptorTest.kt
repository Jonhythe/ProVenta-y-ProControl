package com.proventa.app.security

import android.util.Base64
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import org.junit.runner.RunWith
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.spec.PKCS8EncodedKeySpec

@RunWith(AndroidJUnit4::class)
class DeviceDataPackageDecryptorTest {
    @Test
    fun decryptsPackageGeneratedByNodeCryptoUsingProControlProtocol() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        // The instrumentation Context may have a null applicationContext. Use it only
        // to read test assets; production constructors receive the target app Context.
        val assetContext = instrumentation.context
        val context = instrumentation.targetContext
        val fixtureText = assetContext.assets.open("proventa-node-envelope-fixture.json")
            .bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
        val fixture = JSONObject(fixtureText)
        val envelope = fixture.getJSONObject("envelope")
        val provider = BouncyCastleProvider()
        val encryptionPrivateBytes = Base64.decode(
            fixture.getString("encryptionPrivatePkcs8"),
            Base64.DEFAULT
        )
        val encryptionPrivate = try {
            KeyFactory.getInstance("RSA", provider)
                .generatePrivate(PKCS8EncodedKeySpec(encryptionPrivateBytes))
        } finally {
            encryptionPrivateBytes.fill(0)
        }
        val dummySigningKey = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val deviceKeys = DeviceKeyMaterial(
            deviceId = fixture.getString("deviceId"),
            signingPrivateKey = dummySigningKey.private,
            signingPublicPem = "",
            encryptionPrivateKey = encryptionPrivate,
            encryptionPublicPem = ""
        )
        val authorization = VerifiedDeviceAuthorization(
            installationId = fixture.getString("installationId"),
            authorizationId = fixture.getString("authorizationId"),
            desktopId = "desktop-fixture",
            code = "000000",
            employeeName = "Fixture",
            expiresAt = 1L,
            desktopPublicKeyPem = fixture.getString("desktopPublicKeyPem"),
            rawJson = "{}",
            deviceId = fixture.getString("deviceId"),
            permanent = true,
            version = 4,
            installationCode = "PC-0000-0000-0000",
            authorizedPosId = fixture.getString("posId")
        )

        val result = DeviceDataPackageDecryptor(context).decryptWithMaterial(
            envelopeJson = envelope.toString(),
            authorization = authorization,
            keys = deviceKeys,
            expectedPosId = fixture.getString("posId"),
            nowMillis = fixture.getLong("nowMillis")
        )

        assertEquals(fixture.getString("installationId"), result.installationId)
        assertEquals(fixture.getString("authorizationId"), result.authorizationId)
        assertEquals(fixture.getString("deviceId"), result.deviceId)
        assertEquals(fixture.getString("posId"), result.posId)
        assertEquals(1, result.inventoryCount)
        val payload = JSONObject(result.payloadJson)
        assertEquals("Arroz", payload.getJSONArray("inventory").getJSONObject(0).getString("name"))
        assertEquals(12.5, payload.getJSONArray("inventory").getJSONObject(0).getDouble("qty"), 0.000001)

        val authorizationForAnotherPOS = authorization.copy(authorizedPosId = "pos_someone_else")
        assertThrows(IllegalArgumentException::class.java) {
            DeviceDataPackageDecryptor(context).decryptWithMaterial(
                envelope.toString(),
                authorizationForAnotherPOS,
                deviceKeys,
                fixture.getString("posId"),
                fixture.getLong("nowMillis")
            )
        }

        val tampered = JSONObject(envelope.toString())
        val ciphertext = tampered.getString("ciphertext")
        tampered.put("ciphertext", (if (ciphertext[0] == 'A') "B" else "A") + ciphertext.drop(1))
        assertThrows(IllegalArgumentException::class.java) {
            DeviceDataPackageDecryptor(context).decryptWithMaterial(
                tampered.toString(),
                authorization,
                deviceKeys,
                fixture.getString("posId"),
                fixture.getLong("nowMillis")
            )
        }
    }
}
