package com.proventa.app.ui.screens

import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import com.proventa.app.security.ProVentaOneTimeCode
import org.junit.Test
import java.nio.charset.StandardCharsets
import java.util.EnumMap

class GoodsDispatchQrScannerTest {
    private fun authorizationPayload(): String = buildString {
        append("{\"format\":\"procontrol.device-authorization\",")
        append("\"version\":1,")
        append("\"installationId\":\"pcinst_0123456789abcdef0123456789abcdef\",")
        append("\"authorizationId\":\"auth_12345678-1234-1234-1234-123456789012\",")
        append("\"desktopId\":\"desktop-test\",")
        append("\"employeeName\":\"Trabajador Ñ\",")
        append("\"code\":\"123456\",")
        append("\"expiresAt\":1999999999999,")
        append("\"desktopPublicKey\":\"-----BEGIN PUBLIC KEY-----\\n")
        append("${"A".repeat(500)}")
        append("\\n-----END PUBLIC KEY-----\",")
        append("\"createdAt\":\"2026-11-10T00:00:00Z\",")
        append("\"signature\":{\"algorithm\":\"Ed25519\",\"value\":\"")
        append("${"B".repeat(88)}")
        append("\"}}")
    }

    private fun encodePayload(payload: String): Pair<ByteArray, Int> {
        val hints = EnumMap<EncodeHintType, Any>(EncodeHintType::class.java).apply {
            put(EncodeHintType.CHARACTER_SET, "UTF-8")
            put(EncodeHintType.MARGIN, 4)
        }
        val size = 900
        val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, size, size, hints)
        val luma = ByteArray(size * size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                luma[y * size + x] = if (matrix.get(x, y)) 0.toByte() else 0xFF.toByte()
            }
        }
        return luma to size
    }

    @Test
    fun decodesOneFullSignedAuthorizationQrLargerThanOld78ByteLimit() {
        val descriptor = authorizationPayload()
        assertTrue("Test descriptor must exceed legacy QR capacity", descriptor.toByteArray(StandardCharsets.UTF_8).size > 78)
        val payload = "PCD1:" + java.util.Base64.getUrlEncoder().withoutPadding()
            .encodeToString(descriptor.toByteArray(StandardCharsets.UTF_8))
        val (luma, size) = encodePayload(payload)
        val decoded = decodeQrPayloadsFromLuma(luma, size, size, 0)
        assertEquals(listOf(payload), decoded)
        assertEquals(descriptor, ProVentaOneTimeCode.descriptorFromQrPayload(decoded.single()))
    }

    @Test
    fun decodesTheSameSingleAuthorizationQrWhenCameraFrameIsRotated() {
        val descriptor = authorizationPayload()
        val payload = "PCD1:" + java.util.Base64.getUrlEncoder().withoutPadding()
            .encodeToString(descriptor.toByteArray(StandardCharsets.UTF_8))
        val (luma, size) = encodePayload(payload)
        val decoded = decodeQrPayloadsFromLuma(luma, size, size, 90)
        assertEquals(listOf(payload), decoded)
        assertEquals(descriptor, ProVentaOneTimeCode.descriptorFromQrPayload(decoded.single()))
    }
}
