package com.proventa.app.data.shifts

import android.util.Base64
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.ProductEntity
import com.proventa.app.security.CanonicalJson
import com.proventa.app.data.outbox.PackageAcknowledgementImporter
import com.proventa.app.security.SecureLocalStore
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.nio.charset.StandardCharsets
import java.security.Signature

@RunWith(AndroidJUnit4::class)
class ShiftPermitImporterTest {
    private fun testProduct(posId: String, productId: String) = ProductEntity(
        productId = productId,
        posId = posId,
        name = "Producto $productId",
        family = "Prueba",
        unit = "ud",
        cupCashPriceMinor = 100,
        cupTransferPriceMinor = 108,
        transferMode = "percentage",
        transferPercentBasisPoints = 800,
        foreignPriceMinor = null,
        foreignCurrency = null,
        customCurrencyLabel = null,
        foreignCurrencyScale = null,
        availableQuantityMicros = 3_000_000,
        catalogAliasesJson = "[]",
        catalogRevision = "test-revision-$posId",
        updatedAt = System.currentTimeMillis(),
        active = true
    )

    @Test
    fun verifiesAndImportsOnlyTheSignedPermitForThisDeviceAndPos() = kotlinx.coroutines.runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        SecureLocalStore(context).delete("device_authorization_descriptor")
        SecureLocalStore(context).delete("activation_attempts")
        val provider = BouncyCastleProvider()
        val employee = "Dependiente de prueba"
        val now = System.currentTimeMillis()
        val posId = "pos_permit_" + now
        val fixture = com.proventa.app.security.DeviceLinkTestSupport.create(
            context = context,
            authorizedPosId = posId,
            employeeName = employee,
            nowMillis = now
        )
        val activated = com.proventa.app.security.DeviceLinkTestSupport.activate(context, fixture, now)
        assertEquals(4, activated.version)
        assertEquals(posId, activated.authorizedPosId)
        val desktopKeys = fixture.desktopKeys
        val desktopPem = fixture.desktopPublicKeyPem
        val installationId = fixture.installationId
        val installationCode = fixture.installationCode
        val desktopId = fixture.desktopDeviceId
        val deviceId = fixture.phoneKeys.deviceId
        val phonePublicHash = fixture.deviceSigningPublicKeyHash
        val authorizationId = fixture.authorizationId

        val permitJson = createPermit(
            desktopKeys.private, desktopPem, desktopId, installationId, installationCode,
            authorizationId, phonePublicHash, deviceId, employee, posId, 1L, now, provider
        )
        val importer = ShiftPermitImporter(context)
        assertThrows(IllegalArgumentException::class.java) {
            kotlinx.coroutines.runBlocking {
                importer.importPermit("{\"format\":\"procontrol.shift-permit\",\"version\":2")
            }
        }
        val wrongPhoneHashPermit = JSONObject(permitJson)
            .put("deviceSigningPublicKeyHash", "0".repeat(64))
            .also { it.remove("signature") }
        sign(wrongPhoneHashPermit, desktopKeys.private, provider)
        assertThrows(IllegalArgumentException::class.java) {
            kotlinx.coroutines.runBlocking { importer.importPermit(wrongPhoneHashPermit.toString()) }
        }
        val tamperedPermit = JSONObject(permitJson).put("posId", "pos_other").toString()
        assertThrows(IllegalArgumentException::class.java) { kotlinx.coroutines.runBlocking { importer.importPermit(tamperedPermit) } }
        val first = importer.importPermit(permitJson)
        assertTrue(first.imported)
        assertEquals(posId, first.posId)
        assertEquals(employee, first.employee)
        assertFalse(importer.importPermit(permitJson).imported)

        val dao = ProVentaDatabaseFactory.get(context).proVentaDao()
        val otherPosId = "pos_other_inventory_" + now
        dao.replaceProducts(listOf(
            testProduct(posId, "in-scope-product-$now"),
            testProduct(otherPosId, "other-pos-product-$now")
        ))
        val openService = ShiftOpenService(context)
        val openingPackage = openService.createOrGetOpeningPackage(first.permitId)
        assertEquals("shift_open", openingPackage.type)
        val openingRows = JSONObject(openingPackage.envelopeJson)
            .getJSONObject("payload").getJSONObject("shift").getJSONArray("initialInventory")
        assertEquals("La apertura debe transportar solo inventario del POS autorizado.", 1, openingRows.length())
        assertEquals("in-scope-product-$now", openingRows.getJSONObject(0).getString("productId"))
        val repeatedOpening = openService.createOrGetOpeningPackage(first.permitId)
        assertEquals(openingPackage.packageId, repeatedOpening.packageId)

        // Even an already-created opening file cannot be reused after local authorization is removed.
        val localSecureStore = SecureLocalStore(context)
        val savedAuthorization = localSecureStore.get("device_authorization_descriptor")
            ?: throw AssertionError("The current phone authorization must exist.")
        localSecureStore.delete("device_authorization_descriptor")
        assertThrows(IllegalStateException::class.java) {
            kotlinx.coroutines.runBlocking { openService.createOrGetOpeningPackage(first.permitId) }
        }
        localSecureStore.put("device_authorization_descriptor", savedAuthorization)
        savedAuthorization.fill(0)

        val ackNow = System.currentTimeMillis()
        val acknowledgement = JSONObject()
            .put("format", "procontrol.package-ack")
            .put("version", 1)
            .put("desktopId", desktopId)
            .put("desktopPublicKey", desktopPem)
            .put("deviceId", deviceId)
            .put("packageId", openingPackage.packageId)
            .put("packageType", openingPackage.type)
            .put("payloadHash", openingPackage.payloadHash)
            .put("status", "reconciled")
            .put("result", "applied")
            .put("receivedAt", ackNow - 1000L)
            .put("appliedAt", ackNow - 500L)
            .put("acknowledgedAt", ackNow)
        signAcknowledgement(acknowledgement, desktopKeys.private, provider)
        val ackImporter = PackageAcknowledgementImporter(context)
        assertTrue(ackImporter.importAcknowledgement(acknowledgement.toString()).applied)
        assertEquals("OPENED", ProVentaDatabaseFactory.get(context).proVentaDao().getShiftPermit(first.permitId)?.status)
        assertFalse(ackImporter.importAcknowledgement(acknowledgement.toString()).applied)

        val overlappingPermit = createPermit(
            desktopKeys.private, desktopPem, desktopId, installationId, installationCode,
            authorizationId, phonePublicHash, deviceId, employee, posId, 2L, now, provider
        )
        assertThrows(IllegalArgumentException::class.java) {
            kotlinx.coroutines.runBlocking { importer.importPermit(overlappingPermit) }
        }

        val openedShiftId = dao.getShiftPermit(first.permitId)?.shiftId
            ?: throw AssertionError("La apertura confirmada debe conservar el shiftId asignado por ProControl.")
        val closeService = ShiftCloseService(context)
        val closingProducts = org.json.JSONArray().put(
            JSONObject()
                .put("productId", "in-scope-product-$now")
                .put("name", "Producto in-scope-product-$now")
                .put("unit", "ud")
                .put("finalQuantityMicros", 2_000_000L)
        )
        val report = JSONObject()
            .put("schemaVersion", 1)
            .put("posId", posId)
            .put("permitId", first.permitId)
            .put("shiftId", openedShiftId)
            .put("products", closingProducts)
            .put("cash", JSONObject())
        val closePackage = closeService.createOrGetClosePackage(first.permitId, report.toString())
        assertEquals("shift_close", closePackage.type)
        assertEquals("CLOSE_PENDING", ProVentaDatabaseFactory.get(context).proVentaDao()
            .getShiftPermit(first.permitId)?.status)
        val repeatedClose = closeService.createOrGetClosePackage(
            first.permitId,
            JSONObject().put("schemaVersion", 1).put("posId", posId)
                .put("permitId", first.permitId).put("shiftId", openedShiftId)
                .put("products", closingProducts).put("cash", JSONObject()).toString()
        )
        assertEquals("El cierre pendiente debe reutilizar exactamente el mismo paquete firmado.",
            closePackage.packageId, repeatedClose.packageId)

        val closeAckAt = System.currentTimeMillis()
        val closeAcknowledgement = JSONObject()
            .put("format", "procontrol.package-ack")
            .put("version", 1)
            .put("desktopId", desktopId)
            .put("desktopPublicKey", desktopPem)
            .put("deviceId", deviceId)
            .put("packageId", closePackage.packageId)
            .put("packageType", closePackage.type)
            .put("payloadHash", closePackage.payloadHash)
            .put("status", "reconciled")
            .put("result", "applied")
            .put("receivedAt", closeAckAt - 1000L)
            .put("appliedAt", closeAckAt - 500L)
            .put("acknowledgedAt", closeAckAt)
        signAcknowledgement(closeAcknowledgement, desktopKeys.private, provider)
        assertTrue(ackImporter.importAcknowledgement(closeAcknowledgement.toString()).applied)
        assertEquals("COMPLETED", ProVentaDatabaseFactory.get(context).proVentaDao()
            .getShiftPermit(first.permitId)?.status)
    }

    private fun createPermit(
        privateKey: java.security.PrivateKey,
        desktopPem: String,
        desktopId: String,
        installationId: String,
        installationCode: String,
        authorizationId: String,
        deviceSigningPublicKeyHash: String,
        deviceId: String,
        employee: String,
        posId: String,
        sequence: Long,
        now: Long,
        provider: BouncyCastleProvider
    ): String {
        val permit = JSONObject()
            .put("format", "procontrol.shift-permit")
            .put("version", 2)
            .put("permitId", java.util.UUID.randomUUID().toString())
            .put("desktopDeviceId", desktopId)
            .put("installationId", installationId)
            .put("installationCode", installationCode)
            .put("authorizationId", authorizationId)
            .put("posId", posId)
            .put("authorizedPosId", posId)
            .put("deviceSigningPublicKeyHash", deviceSigningPublicKeyHash)
            .put("deviceId", deviceId)
            .put("employee", employee)
            .put("startsAt", now - 60_000L)
            .put("endsAt", now + 8 * 60 * 60 * 1000L)
            .put("sequence", sequence)
            .put("emergency", JSONObject()
                .put("enabled", false)
                .put("maxSales", 0)
                .put("expiresAt", JSONObject.NULL)
                .put("reason", JSONObject.NULL))
            .put("issuedAt", now)
            .put("desktopPublicKey", desktopPem)
        sign(permit, privateKey, provider)
        return permit.toString()
    }

    private fun installationCode(installationId: String): String {
        val hex = installationId.removePrefix("pcinst_").take(16).uppercase()
        return "PC-${hex.substring(0, 4)}-${hex.substring(4, 8)}-${hex.substring(8, 12)}-${hex.substring(12, 16)}"
    }

    private fun sign(
        document: JSONObject,
        privateKey: java.security.PrivateKey,
        provider: BouncyCastleProvider
    ) {
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(privateKey)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put("signature", Base64.encodeToString(signer.sign(), Base64.NO_WRAP))
    }

    /** package-ack uses the structured Ed25519 signature object; shift-permit v2 intentionally uses a Base64 string. */
    private fun signAcknowledgement(
        document: JSONObject,
        privateKey: java.security.PrivateKey,
        provider: BouncyCastleProvider
    ) {
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(privateKey)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put(
            "signature",
            JSONObject()
                .put("algorithm", "Ed25519")
                .put("value", Base64.encodeToString(signer.sign(), Base64.NO_WRAP))
        )
    }

    private fun toPem(der: ByteArray): String =
        "-----BEGIN PUBLIC KEY-----\n" +
            Base64.encodeToString(der, Base64.NO_WRAP).chunked(64).joinToString("\n") +
            "\n-----END PUBLIC KEY-----\n"
}
