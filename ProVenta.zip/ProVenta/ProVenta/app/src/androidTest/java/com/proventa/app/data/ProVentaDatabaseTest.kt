package com.proventa.app.data

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.proventa.app.data.entities.SaleCurrencyTotalEntity
import com.proventa.app.data.entities.SaleEntity
import com.proventa.app.data.entities.SaleLineEntity
import com.proventa.app.data.entities.SalePaymentEntity
import com.proventa.app.data.entities.OutboxPackageEntity
import com.proventa.app.data.entities.ProductEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProVentaDatabaseTest {
    @Test
    fun saleBundleStoresTotalsPerCurrencyAndLinePayments() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val dao = ProVentaDatabaseFactory.get(context).proVentaDao()
        val suffix = System.currentTimeMillis().toString()
        val saleId = "multi-currency-$suffix"
        val sale = SaleEntity(
            saleId = saleId,
            posId = "pos-test",
            shiftId = "shift-test",
            status = "PENDING_SYNC",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            idempotencyKey = "multi-currency-idem-$suffix"
        )
        dao.replaceProducts(listOf(
            ProductEntity("prod-1", "pos-test", "Producto CUP", "prueba", "ud", 2_500, 2_600, "manual", null, null, null, null, null, 1_000_000, "[]", "rev-$suffix", System.currentTimeMillis()),
            ProductEntity("prod-2", "pos-test", "Producto USD", "prueba", "ud", null, null, null, null, 300, "USD", null, 2, 1_000_000, "[]", "rev-$suffix", System.currentTimeMillis())
        ))
        val lines = listOf(
            SaleLineEntity("line-cup-$suffix", saleId, "prod-1", "Producto CUP", "ud", 1_000_000, 2_500, 2_500, "CUP", null, 2),
            SaleLineEntity("line-usd-$suffix", saleId, "prod-2", "Producto USD", "ud", 1_000_000, 300, 300, "USD", null, 2)
        )
        val totals = listOf(
            SaleCurrencyTotalEntity("total-cup-$suffix", saleId, "CUP", null, 2, 2_500),
            SaleCurrencyTotalEntity("total-usd-$suffix", saleId, "USD", null, 2, 300)
        )
        val payments = listOf(
            SalePaymentEntity("pay-cash-$suffix", "line-cup-$suffix", "CASH", 1_500, "CUP", 2, null, null, null),
            SalePaymentEntity("pay-transfer-$suffix", "line-cup-$suffix", "TRANSFER", 1_000, "CUP", 2, "55512345", "OP-123", null),
            SalePaymentEntity("pay-usd-$suffix", "line-usd-$suffix", "CASH", 300, "USD", 2, null, null, null)
        )

        val outbox = OutboxPackageEntity(
            packageId = "sale-package-$suffix",
            deviceId = "device-test-$suffix",
            packageType = "sale_batch",
            payloadHash = "a".repeat(64),
            envelopeJson = """{"format":"test-outbox-envelope"}""",
            aggregateId = saleId,
            status = "PENDING",
            createdAt = System.currentTimeMillis(),
            acknowledgementJson = null,
            acknowledgedAt = null
        )
        dao.saveSaleBundle(sale, lines, totals, payments, outbox)
        assertEquals(
            "El límite de emergencia debe contar cada grupo de moneda/método que ProControl recibirá como ticket.",
            3,
            dao.countShiftSales("shift-test", "pos-test")
        )
        assertEquals(outbox, dao.getOutboxPackage(outbox.packageId))
        assertEquals(0, dao.countPendingSalesWithoutPackage("pos-test"))
        assertEquals(totals.sortedBy { it.currency }, dao.getSaleCurrencyTotals(saleId))
        assertEquals(0L, dao.searchProducts("pos-test", "prod-1").single().availableQuantityMicros)
        assertEquals(0L, dao.searchProducts("pos-test", "prod-2").single().availableQuantityMicros)
    }

    @Test
    fun shiftSalesAndPendingPackagesAreScopedToPosEvenWhenShiftIdMatches() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val suffix = System.currentTimeMillis().toString()
        val sharedShiftId = "same-shift-$suffix"
        val posA = "pos-a-$suffix"
        val posB = "pos-b-$suffix"

        suspend fun addPendingSale(posId: String, key: String) {
            val saleId = "sale-$key"
            val lineId = "line-$key"
            val now = System.currentTimeMillis()
            dao.insertSale(
                SaleEntity(
                    saleId = saleId,
                    posId = posId,
                    shiftId = sharedShiftId,
                    status = "PENDING_SYNC",
                    createdAt = now,
                    updatedAt = now,
                    idempotencyKey = "idem-$key"
                )
            )
            dao.insertSaleLines(
                listOf(SaleLineEntity(
                    lineId = lineId,
                    saleId = saleId,
                    productId = "shared-product-id",
                    productNameSnapshot = "Producto $key",
                    unitSnapshot = "ud",
                    quantityMicros = 1_000_000,
                    unitPriceMinor = 100,
                    lineTotalMinor = 100,
                    currency = "CUP",
                    currencyLabel = null,
                    currencyScale = 2
                ))
            )
            dao.insertPayments(
                listOf(SalePaymentEntity(
                    paymentId = "payment-$key",
                    saleLineId = lineId,
                    method = "CASH",
                    amountMinor = 100,
                    currency = "CUP",
                    currencyScale = 2,
                    transferPhone = null,
                    transferOperationNumber = null,
                    evidenceUri = null
                ))
            )
            dao.insertOutboxPackage(
                OutboxPackageEntity(
                    packageId = "package-$key",
                    deviceId = "device-$key",
                    packageType = "sale_batch",
                    payloadHash = "a".repeat(64),
                    envelopeJson = "{}",
                    aggregateId = saleId,
                    status = "PENDING",
                    createdAt = now,
                    acknowledgementJson = null,
                    acknowledgedAt = null
                )
            )
        }

        addPendingSale(posA, "a-$suffix")
        addPendingSale(posB, "b-$suffix")

        assertEquals(1, dao.countShiftSales(sharedShiftId, posA))
        assertEquals(1, dao.countShiftSales(sharedShiftId, posB))
        assertEquals("package-a-$suffix", dao.listPendingSalePackages(posA).single().packageId)
        assertEquals("package-b-$suffix", dao.listPendingSalePackages(posB).single().packageId)
    }

    @Test
    fun databasePersistsRecordsAndIsNotPlainSqlite() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val database = ProVentaDatabaseFactory.get(context)
        val now = System.currentTimeMillis()
        val suffix = now.toString()
        val sale = SaleEntity(
            saleId = "test-sale-$suffix",
            posId = "test-pos",
            shiftId = "test-shift",
            status = "DRAFT",
            createdAt = now,
            updatedAt = now,
            idempotencyKey = "test-idempotency-$suffix"
        )

        database.proVentaDao().insertSale(sale)
        val stored = database.proVentaDao().getSale(sale.saleId)
        assertEquals(sale, stored)

        database.openHelper.writableDatabase
        val databaseFile = context.getDatabasePath("proventa-secure.db")
        assertFalse("La base de datos no debe estar vacía.", databaseFile.length() == 0L)
        val header = databaseFile.inputStream().use { input -> ByteArray(16).also { input.read(it) } }
        val sqlitePlainHeader = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)
        assertNotEquals(
            "La base de datos debe estar cifrada y no mostrar la cabecera SQLite en claro.",
            sqlitePlainHeader.toList(),
            header.toList()
        )
    }
}
