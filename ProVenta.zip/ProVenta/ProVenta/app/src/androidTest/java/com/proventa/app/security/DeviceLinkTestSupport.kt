package com.proventa.app.security

import android.content.Context
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.Security
import java.security.Signature
import java.security.spec.MGF1ParameterSpec
import java.security.spec.X509EncodedKeySpec
import java.time.Instant
import java.util.Base64
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.spec.SecretKeySpec

/**
 * Builds a real ProControl v4 .pvlink fixture for instrumented tests.
 * Tests must activate through DeviceEnrollmentRequestFactory.activateWithEnvelope;
 * this helper intentionally does not call the legacy descriptor persistence hook.
 */
data class DeviceLinkTestFixture(
    val phoneKeys: DeviceKeyMaterial,
    val desktopKeys: KeyPair,
    val desktopPublicKeyPem: String,
    val desktopDeviceId: String,
    val installationId: String,
    val installationCode: String,
    val authorizationId: String,
    val authorizedPosId: String,
    val employeeName: String,
    val deviceSigningPublicKeyHash: String,
    val pin: String,
    val rawDescriptor: String,
    val envelopeJson: String,
    val createdAtMillis: Long
)

object DeviceLinkTestSupport {
    private const val PIN = "42817360"
    private const val ENVELOPE_TTL_MS = 5 * 60 * 1000L

    fun create(
        context: Context,
        authorizedPosId: String,
        employeeName: String = "Dependiente de prueba",
        nowMillis: Long = System.currentTimeMillis(),
        issuerKeyPair: KeyPair? = null
    ): DeviceLinkTestFixture {
        require(authorizedPosId.matches(Regex("[A-Za-z0-9:_-]{1,160}")))
        require(employeeName.trim().length in 2..100)
        val provider = BouncyCastleProvider()
        if (Security.getProvider(provider.name) == null) Security.addProvider(provider)

        val desktopKeys = issuerKeyPair ?: KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val phoneKeys = DeviceKeyManager(context.applicationContext).getOrCreate()
        val desktopPublicKeyPem = toPem(desktopKeys.public.encoded)
        val installationFingerprint = sha256(desktopKeys.public.encoded)
        val installationId = "pcinst_" + installationFingerprint.take(32)
        val installationCode = installationCode(installationId)
        val deviceSigningPublicKeyHash = sha256(pemBytes(phoneKeys.signingPublicPem))
        val authorizationId = "auth_${UUID.randomUUID()}"
        val createdAt = Instant.ofEpochMilli(nowMillis).toString()
        val expiresAt = nowMillis + ENVELOPE_TTL_MS
        val desktopDeviceId = "control_plane_device_test"

        val descriptor = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 4)
            .put("permanent", true)
            .put("installationId", installationId)
            .put("installationCode", installationCode)
            .put("authorizedPosId", authorizedPosId)
            .put("authorizationId", authorizationId)
            .put("employeeName", employeeName.trim())
            .put("code", PIN)
            .put("expiresAt", expiresAt)
            .put("deviceId", phoneKeys.deviceId)
            .put("deviceSigningPublicKeyHash", deviceSigningPublicKeyHash)
            .put("desktopPublicKey", desktopPublicKeyPem)
            .put("createdAt", createdAt)
        signObject(descriptor, desktopKeys, provider)
        val rawDescriptor = CanonicalJson.stringify(descriptor)
        val plaintext = rawDescriptor.toByteArray(StandardCharsets.UTF_8)
        val payloadHash = try { sha256(plaintext) } finally { plaintext.fill(0) }

        val header = JSONObject()
            .put("format", "procontrol.device-link")
            .put("version", 1)
            .put("algorithm", "RSA-OAEP-256+A256GCM")
            .put("installationId", installationId)
            .put("installationCode", installationCode)
            .put("authorizationId", authorizationId)
            .put("deviceId", phoneKeys.deviceId)
            .put("authorizedPosId", authorizedPosId)
            .put("createdAt", createdAt)
            .put("expiresAt", expiresAt)
            .put("payloadHash", payloadHash)
            .put("signerPublicKey", desktopPublicKeyPem)

        val rsaPublicKey = KeyFactory.getInstance("RSA", provider).generatePublic(
            X509EncodedKeySpec(pemBytes(phoneKeys.encryptionPublicPem))
        )
        val encryptedPayload = createEncryptedPayload(
            header = header,
            rawDescriptor = rawDescriptor,
            rsaPublicKey = rsaPublicKey,
            provider = provider
        )

        val envelope = JSONObject(header.toString())
            .put("encryption", JSONObject()
                .put("keyWrap", "RSA-OAEP-SHA256")
                .put("contentCipher", "AES-256-GCM")
                .put("wrappedKey", encryptedPayload.wrappedKey)
                .put("iv", encryptedPayload.iv)
                .put("tag", encryptedPayload.tag))
            .put("ciphertext", encryptedPayload.ciphertext)
        signObject(envelope, desktopKeys, provider)

        return DeviceLinkTestFixture(
            phoneKeys = phoneKeys,
            desktopKeys = desktopKeys,
            desktopPublicKeyPem = desktopPublicKeyPem,
            desktopDeviceId = desktopDeviceId,
            installationId = installationId,
            installationCode = installationCode,
            authorizationId = authorizationId,
            authorizedPosId = authorizedPosId,
            employeeName = employeeName.trim(),
            deviceSigningPublicKeyHash = deviceSigningPublicKeyHash,
            pin = PIN,
            rawDescriptor = rawDescriptor,
            envelopeJson = envelope.toString(),
            createdAtMillis = nowMillis
        )
    }

    fun activate(
        context: Context,
        fixture: DeviceLinkTestFixture,
        nowMillis: Long = fixture.createdAtMillis
    ): VerifiedDeviceAuthorization = DeviceEnrollmentRequestFactory(context.applicationContext)
        .activateWithEnvelope(fixture.pin, fixture.envelopeJson, nowMillis)

    private data class EncryptedPayload(
        val wrappedKey: String,
        val iv: String,
        val tag: String,
        val ciphertext: String
    )

    private fun createEncryptedPayload(
        header: JSONObject,
        rawDescriptor: String,
        rsaPublicKey: java.security.PublicKey,
        provider: BouncyCastleProvider
    ): EncryptedPayload {
        val dataKey = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val plaintext = rawDescriptor.toByteArray(StandardCharsets.UTF_8)
        val combined = try {
            val aes = Cipher.getInstance("AES/GCM/NoPadding")
            aes.init(Cipher.ENCRYPT_MODE, SecretKeySpec(dataKey, "AES"), GCMParameterSpec(128, iv))
            aes.updateAAD(CanonicalJson.stringify(header).toByteArray(StandardCharsets.UTF_8))
            aes.doFinal(plaintext)
        } finally {
            plaintext.fill(0)
        }
        val wrapped = try {
            val rsa = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", provider)
            rsa.init(Cipher.ENCRYPT_MODE, rsaPublicKey, OAEPParameterSpec(
                "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT
            ))
            rsa.doFinal(dataKey)
        } finally {
            dataKey.fill(0)
        }
        return EncryptedPayload(
            wrappedKey = Base64.getEncoder().encodeToString(wrapped),
            iv = Base64.getEncoder().encodeToString(iv),
            tag = Base64.getEncoder().encodeToString(combined.copyOfRange(combined.size - 16, combined.size)),
            ciphertext = Base64.getEncoder().encodeToString(combined.copyOfRange(0, combined.size - 16))
        )
    }

    private fun signObject(document: JSONObject, keyPair: KeyPair, provider: BouncyCastleProvider) {
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(keyPair.private)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put("signature", JSONObject()
            .put("algorithm", "Ed25519")
            .put("value", Base64.getEncoder().encodeToString(signer.sign())))
    }

    private fun installationCode(installationId: String): String {
        val hex = installationId.removePrefix("pcinst_").take(16).uppercase()
        return "PC-${hex.substring(0, 4)}-${hex.substring(4, 8)}-${hex.substring(8, 12)}-${hex.substring(12, 16)}"
    }

    private fun pemBytes(pem: String): ByteArray = Base64.getDecoder().decode(
        pem.replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() }
    )

    private fun toPem(der: ByteArray): String = "-----BEGIN PUBLIC KEY-----\n" +
        Base64.getEncoder().encodeToString(der).chunked(64).joinToString("\n") +
        "\n-----END PUBLIC KEY-----\n"

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }
}
