package com.proventa.app.security

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SecureLocalStoreTest {
    @Test
    fun encryptsAndReadsBackRecord() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SecureLocalStore(context)
        val original = "venta-pendiente-123".toByteArray()
        store.put("test_record", original)

        val file = context.noBackupFilesDir.resolve("secure_records/test_record.pvdata")
        assertTrue(file.exists())
        assertFalse(file.readBytes().contentEquals(original))
        assertArrayEquals(original, store.get("test_record"))
        store.delete("test_record")
        assertNull(store.get("test_record"))
    }

    @Test
    fun rejectsUnsafeRecordIds() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SecureLocalStore(context)
        try {
            store.put("../outside", byteArrayOf(1, 2, 3))
            throw AssertionError("Se aceptó un identificador de archivo inseguro.")
        } catch (_: IllegalArgumentException) {
            // Expected.
        }
    }
}
