package com.proventa.app.data.receipts

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.GoodsReceiptEntity
import com.proventa.app.data.entities.InventorySnapshotEntity
import com.proventa.app.data.entities.ProductEntity
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import java.time.Instant

@RunWith(AndroidJUnit4::class)
class GoodsReceiptStockApplicationTest {
    @Test
    fun addsReceivedQuantitiesWhenLocalSnapshotPredatesDispatch() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val now = System.currentTimeMillis()
        val suffix = now.toString()
        val posId = "pos-receipt-old-" + suffix
        val dispatchAt = now - 30_000L
        val productId = "rice-" + suffix
        val receiptId = "receipt-" + suffix
        val dispatchId = "dispatch-" + suffix
        val packageHash = "b".repeat(64)

        dao.replaceProducts(listOf(product(productId, posId, 10_000_000L, suffix)))
        dao.saveInventorySnapshot(snapshot(posId, "snapshot-old-" + suffix, dispatchAt - 10_000L, now))
        dao.insertGoodsReceipt(receipt(
            receiptId, dispatchId, posId, productId, packageHash, dispatchAt, now
        ))

        assertEquals(
            1,
            dao.confirmGoodsReceipt(
                receiptId,
                VerifiedFinalAuthorization(dispatchId, packageHash, "c".repeat(64), INSTALLATION_ID, DEVICE_ID),
                now
            )
        )
        assertEquals(
            12_500_000L,
            dao.getActiveProduct(posId, productId)?.availableQuantityMicros
        )
        assertEquals(ReceiptStatus.CONFIRMED.name, dao.getGoodsReceipt(receiptId)?.status)
    }

    @Test
    fun doesNotAddQuantitiesWhenLocalSnapshotAlreadyIncludesDispatch() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val now = System.currentTimeMillis()
        val suffix = now.toString()
        val posId = "pos-receipt-new-" + suffix
        val dispatchAt = now - 30_000L
        val productId = "beans-" + suffix
        val receiptId = "receipt-new-" + suffix
        val dispatchId = "dispatch-new-" + suffix
        val packageHash = "d".repeat(64)

        dao.replaceProducts(listOf(product(productId, posId, 12_500_000L, suffix)))
        dao.saveInventorySnapshot(snapshot(posId, "snapshot-new-" + suffix, dispatchAt + 10_000L, now))
        dao.insertGoodsReceipt(receipt(
            receiptId, dispatchId, posId, productId, packageHash, dispatchAt, now
        ))

        assertEquals(
            1,
            dao.confirmGoodsReceipt(
                receiptId,
                VerifiedFinalAuthorization(dispatchId, packageHash, "e".repeat(64), INSTALLATION_ID, DEVICE_ID),
                now
            )
        )
        assertEquals(
            12_500_000L,
            dao.getActiveProduct(posId, productId)?.availableQuantityMicros
        )
        assertEquals(ReceiptStatus.CONFIRMED.name, dao.getGoodsReceipt(receiptId)?.status)
    }


    @Test
    fun finalReceiptAuthorizationCannotUpdateSnapshotForAnotherDevice() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val now = System.currentTimeMillis()
        val suffix = now.toString()
        val posId = "pos-receipt-device-scope-$suffix"
        val dispatchAt = now - 30_000L
        val productId = "scope-product-$suffix"
        val receiptId = "scope-receipt-$suffix"
        val dispatchId = "scope-dispatch-$suffix"
        val packageHash = "9".repeat(64)
        val initialQuantity = 7_000_000L

        dao.replaceProducts(listOf(product(productId, posId, initialQuantity, suffix)))
        dao.saveInventorySnapshot(snapshot(posId, "snapshot-scope-$suffix", dispatchAt - 5_000L, now))
        dao.insertGoodsReceipt(receipt(
            receiptId, dispatchId, posId, productId, packageHash, dispatchAt, now
        ))

        try {
            dao.confirmGoodsReceipt(
                receiptId,
                VerifiedFinalAuthorization(
                    dispatchId,
                    packageHash,
                    "8".repeat(64),
                    INSTALLATION_ID,
                    "another-device"
                ),
                now
            )
            throw AssertionError("Una autorización de otro teléfono pudo modificar el inventario.")
        } catch (expected: IllegalStateException) {
            // The current inventory snapshot is pinned to DEVICE_ID.
        }
        assertEquals(initialQuantity, dao.getActiveProduct(posId, productId)?.availableQuantityMicros)
        assertEquals(ReceiptStatus.AWAITING_FINAL_ACK.name, dao.getGoodsReceipt(receiptId)?.status)
    }

    private companion object {
        const val INSTALLATION_ID = "pcinst_0123456789abcdef0123456789abcdef"
        const val DEVICE_ID = "device-receipt-test"
    }

    private fun product(
        productId: String,
        posId: String,
        quantityMicros: Long,
        revision: String
    ) = ProductEntity(
        productId = productId,
        posId = posId,
        name = "Producto de prueba",
        family = "granos",
        unit = "lb",
        cupCashPriceMinor = 100,
        cupTransferPriceMinor = 108,
        transferMode = "percentage",
        transferPercentBasisPoints = 800,
        foreignPriceMinor = null,
        foreignCurrency = null,
        customCurrencyLabel = null,
        foreignCurrencyScale = null,
        availableQuantityMicros = quantityMicros,
        catalogAliasesJson = "[]",
        catalogRevision = revision,
        updatedAt = System.currentTimeMillis()
    )

    private fun snapshot(posId: String, packageId: String, generatedAt: Long, importedAt: Long) =
        InventorySnapshotEntity(
            posId = posId,
            posName = "POS de prueba",
            usdCupRateMicros = null,
            installationId = "pcinst_0123456789abcdef0123456789abcdef",
            deviceId = "device-receipt-test",
            packageId = packageId,
            payloadHash = "a".repeat(64),
            generatedAt = generatedAt,
            importedAt = importedAt,
            productCount = 1
        )

    private fun receipt(
        receiptId: String,
        dispatchId: String,
        posId: String,
        productId: String,
        packageHash: String,
        dispatchAt: Long,
        now: Long
    ): GoodsReceiptEntity {
        val manifestJson =
            "{\"format\":\"procontrol.goods-dispatch\",\"installationId\":\"" + INSTALLATION_ID +
                "\",\"dispatchId\":\"" + dispatchId +
                "\",\"posId\":\"" + posId +
                "\",\"itemsHash\":\"" + "a".repeat(64) +
                "\",\"createdAt\":\"" + Instant.ofEpochMilli(dispatchAt).toString() +
                "\",\"items\":[{\"productId\":" +
                JSONObject.quote(productId) +
                ",\"unit\":\"lb\",\"quantity\":2.5}]}"
        return GoodsReceiptEntity(
            receiptId = receiptId,
            transferId = dispatchId,
            posId = posId,
            status = ReceiptStatus.AWAITING_FINAL_ACK.name,
            confirmationCodeHash = "f".repeat(64),
            packageHash = packageHash,
            manifestJson = manifestJson,
            finalAuthorizationHash = null,
            discrepancyReason = null,
            confirmedAt = null,
            createdAt = now,
            updatedAt = now
        )
    }
}
