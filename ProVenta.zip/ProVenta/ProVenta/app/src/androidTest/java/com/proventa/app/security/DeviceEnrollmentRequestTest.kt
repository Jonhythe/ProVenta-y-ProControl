package com.proventa.app.security

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.security.interfaces.RSAPublicKey
import java.security.spec.X509EncodedKeySpec
import java.time.Instant
import android.util.Base64

@RunWith(AndroidJUnit4::class)
class DeviceEnrollmentRequestTest {
    @Test
    fun importsSignedPcpairAndCreatesOneUsePcdeviceV2Request() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        SecureLocalStore(context).delete("device_authorization_descriptor")
        val provider = BouncyCastleProvider()
        val desktopKeys = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val desktopPublicPem = toPem(desktopKeys.public.encoded)
        val installationHash = MessageDigest.getInstance("SHA-256")
            .digest(desktopKeys.public.encoded)
            .joinToString("") { "%02x".format(it) }
        val installationId = "pcinst_" + installationHash.take(32)
        val authorizationId = "auth_" + java.util.UUID.randomUUID().toString()
        val now = System.currentTimeMillis()

        val descriptor = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 1)
            .put("installationId", installationId)
            .put("authorizationId", authorizationId)
            .put("desktopId", "desktop-test")
            .put("employeeName", "Dependiente de prueba")
            .put("code", "123456")
            .put("expiresAt", now + 240_000L)
            .put("desktopPublicKey", desktopPublicPem)
            .put("createdAt", Instant.ofEpochMilli(now).toString())
        val desktopSigner = Signature.getInstance("Ed25519", provider)
        desktopSigner.initSign(desktopKeys.private)
        desktopSigner.update(CanonicalJson.stringify(descriptor).toByteArray(StandardCharsets.UTF_8))
        descriptor.put(
            "signature",
            JSONObject()
                .put("algorithm", "Ed25519")
                .put("value", Base64.encodeToString(desktopSigner.sign(), Base64.NO_WRAP))
        )

        val manager = DeviceEnrollmentRequestFactory(context)
        val verified = manager.importAuthorizationDescriptor(descriptor.toString())
        assertEquals(installationId, verified.installationId)
        assertEquals(authorizationId, verified.authorizationId)

        val requestJson = manager.createEnrollmentRequest("Samsung Android")
        val request = JSONObject(requestJson)
        assertEquals("procontrol.device-enrollment-request", request.getString("format"))
        assertEquals(2, request.getInt("version"))
        assertEquals(installationId, request.getString("installationId"))
        assertEquals(authorizationId, request.getString("authorizationId"))
        assertEquals("123456", request.getString("code"))
        assertTrue(request.getString("deviceId").startsWith("device_"))

        val deviceSigningKey = KeyFactory.getInstance("Ed25519", provider).generatePublic(
            X509EncodedKeySpec(decodePem(request.getString("devicePublicKey")))
        )
        val requestSignature = request.getJSONObject("signature")
        val requestVerifier = Signature.getInstance("Ed25519", provider)
        requestVerifier.initVerify(deviceSigningKey)
        requestVerifier.update(
            CanonicalJson.stringify(CanonicalJson.withoutSignature(request))
                .toByteArray(StandardCharsets.UTF_8)
        )
        assertTrue(requestVerifier.verify(Base64.decode(requestSignature.getString("value"), Base64.DEFAULT)))

        val rsaPublic = KeyFactory.getInstance("RSA", provider).generatePublic(
            X509EncodedKeySpec(decodePem(request.getString("deviceEncryptionPublicKey")))
        ) as RSAPublicKey
        assertEquals(3072, rsaPublic.modulus.bitLength())
        assertEquals(65537L, rsaPublic.publicExponent.toLong())

        val secondExport = manager.createEnrollmentRequest("Different label must not replace the first request")
        assertEquals(requestJson, secondExport)

        val phoneIdentity = manager.createDeviceIdentityToken("Samsung Galaxy")
        val identityAgain = DeviceEnrollmentRequestFactory(context).createDeviceIdentityToken("Another label")
        assertEquals(phoneIdentity.deviceId, identityAgain.deviceId)
        assertEquals(
            "El ID firmado de este teléfono debe conservarse idéntico entre aperturas de ProVenta.",
            phoneIdentity.token,
            identityAgain.token
        )
    }

    private fun toPem(der: ByteArray): String {
        val encoded = Base64.encodeToString(der, Base64.NO_WRAP)
        return "-----BEGIN PUBLIC KEY-----\n" +
            encoded.chunked(64).joinToString("\n") +
            "\n-----END PUBLIC KEY-----\n"
    }

    private fun decodePem(pem: String): ByteArray = Base64.decode(
        pem.replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() },
        Base64.DEFAULT
    )
}
