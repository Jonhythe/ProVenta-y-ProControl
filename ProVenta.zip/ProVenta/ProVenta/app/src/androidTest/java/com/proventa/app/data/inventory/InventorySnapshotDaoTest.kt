package com.proventa.app.data.inventory

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.InventorySnapshotEntity
import com.proventa.app.data.entities.ProductEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InventorySnapshotDaoTest {
    private fun product(productId: String, posId: String, revision: String, name: String = productId) = ProductEntity(
        productId = productId,
        posId = posId,
        name = name,
        family = "granos",
        unit = "lb",
        cupCashPriceMinor = 100,
        cupTransferPriceMinor = 108,
        transferMode = "percentage",
        transferPercentBasisPoints = 800,
        foreignPriceMinor = 150,
        foreignCurrency = "USD",
        customCurrencyLabel = null,
        foreignCurrencyScale = 2,
        availableQuantityMicros = 1_000_000,
        catalogAliasesJson = "[]",
        catalogRevision = revision,
        updatedAt = System.currentTimeMillis()
    )

    private fun snapshot(
        posId: String,
        packageId: String,
        hash: String,
        count: Int,
        generatedAt: Long = System.currentTimeMillis()
    ) = InventorySnapshotEntity(
            posId = posId,
            posName = "POS de prueba",
            usdCupRateMicros = 410_000_000L,
            installationId = "pcinst_0123456789abcdef0123456789abcdef",
            deviceId = "device-test",
            packageId = packageId,
            payloadHash = hash,
            generatedAt = generatedAt,
            importedAt = System.currentTimeMillis(),
            productCount = count
        )

    @Test
    fun snapshotReplacementIsAtomicAndDuplicateImportIsIdempotent() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val posId = "pos-snapshot-" + System.currentTimeMillis()
        val firstHash = "a".repeat(64)
        val secondHash = "b".repeat(64)
        val firstPackageId = "package-first-" + posId
        val secondPackageId = "package-second-" + posId
        val firstGeneratedAt = System.currentTimeMillis()

        assertTrue(
            dao.applyInventorySnapshot(
                snapshot(posId, firstPackageId, firstHash, 1, generatedAt = firstGeneratedAt),
                listOf(product("old-product-" + posId, posId, firstHash))
            )
        )
        assertFalse(
            dao.applyInventorySnapshot(
                snapshot(posId, firstPackageId, firstHash, 1, generatedAt = firstGeneratedAt),
                listOf(product("old-product-" + posId, posId, firstHash))
            )
        )

        assertTrue(
            dao.applyInventorySnapshot(
                snapshot(posId, secondPackageId, secondHash, 1, generatedAt = firstGeneratedAt + 1_000L),
                listOf(product("new-product-" + posId, posId, secondHash))
            )
        )
        val stored = dao.searchProducts(posId, "")
        assertEquals(1, stored.size)
        assertEquals("new-product-" + posId, stored.single().productId)
        assertEquals(secondHash, dao.getInventorySnapshot(posId)?.payloadHash)
    }
    @Test
    fun sameProductIdCanExistIndependentlyInDifferentPos() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val suffix = System.currentTimeMillis()
        val posA = "pos-same-product-a-$suffix"
        val posB = "pos-same-product-b-$suffix"
        val revisionA = "a".repeat(64)
        val revisionB = "b".repeat(64)

        assertTrue(dao.applyInventorySnapshot(
            snapshot(posA, "pkg-a-$suffix", revisionA, 1),
            listOf(product("shared-product-id", posA, revisionA, "Producto del POS A"))
        ))
        assertTrue(dao.applyInventorySnapshot(
            snapshot(posB, "pkg-b-$suffix", revisionB, 1),
            listOf(product("shared-product-id", posB, revisionB, "Producto del POS B"))
        ))

        assertEquals("Producto del POS A", dao.getActiveProduct(posA, "shared-product-id")?.name)
        assertEquals("Producto del POS B", dao.getActiveProduct(posB, "shared-product-id")?.name)
    }

    @Test
    fun olderSnapshotCannotRollBackCurrentInventory() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val now = System.currentTimeMillis()
        val posId = "pos-anti-rollback-$now"
        val currentHash = "c".repeat(64)
        val oldHash = "d".repeat(64)
        assertTrue(dao.applyInventorySnapshot(
            snapshot(posId, "pkg-current-$now", currentHash, 1, generatedAt = now),
            listOf(product("current-product", posId, currentHash))
        ))

        try {
            dao.applyInventorySnapshot(
                snapshot(posId, "pkg-old-$now", oldHash, 1, generatedAt = now - 1_000L),
                listOf(product("old-product", posId, oldHash))
            )
            throw AssertionError("Se aceptó un snapshot más antiguo que el inventario actual.")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message.orEmpty().contains("anterior"))
        }
        assertEquals(currentHash, dao.getInventorySnapshot(posId)?.payloadHash)
        assertEquals("current-product", dao.searchProducts(posId, "").single().productId)
    }

    @Test
    fun snapshotForSamePosCannotBeReplacedByAnotherInstallationOrPhone() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val now = System.currentTimeMillis()
        val posId = "pos-scope-lock-$now"
        val currentHash = "e".repeat(64)
        val replacementHash = "f".repeat(64)
        assertTrue(dao.applyInventorySnapshot(
            snapshot(posId, "pkg-scope-current-$now", currentHash, 1, generatedAt = now),
            listOf(product("scope-current-product", posId, currentHash))
        ))
        val foreignSnapshot = snapshot(
            posId, "pkg-scope-foreign-$now", replacementHash, 1, generatedAt = now + 2_000L
        ).copy(
            installationId = "pcinst_fedcba9876543210fedcba9876543210",
            deviceId = "another-device"
        )
        try {
            dao.applyInventorySnapshot(
                foreignSnapshot,
                listOf(product("scope-foreign-product", posId, replacementHash))
            )
            throw AssertionError("Se permitió reemplazar el inventario de otra instalación/teléfono.")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message.orEmpty().contains("otra instalación o teléfono"))
        }
        assertEquals(currentHash, dao.getInventorySnapshot(posId)?.payloadHash)
        assertEquals("scope-current-product", dao.searchProducts(posId, "").single().productId)
    }

    @Test
    fun identicalNewerSnapshotRefreshesSourceTimestampWithoutDuplicatingInventory() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val now = System.currentTimeMillis()
        val posId = "pos-identical-newer-$now"
        val hash = "7".repeat(64)
        val first = snapshot(posId, "pkg-identical-first-$now", hash, 1, generatedAt = now)
        val newer = snapshot(posId, "pkg-identical-newer-$now", hash, 1, generatedAt = now + 5_000L)
        val firstProduct = product("identical-product-$now", posId, hash, "Producto idéntico")

        assertTrue(dao.applyInventorySnapshot(first, listOf(firstProduct)))
        assertFalse(dao.applyInventorySnapshot(newer, listOf(firstProduct)))

        val stored = dao.getInventorySnapshot(posId)
        assertEquals(newer.packageId, stored?.packageId)
        assertEquals(newer.generatedAt, stored?.generatedAt)
        assertEquals(1, dao.searchProducts(posId, "").size)
        assertEquals("Producto idéntico", dao.getActiveProduct(posId, firstProduct.productId)?.name)
    }

}
