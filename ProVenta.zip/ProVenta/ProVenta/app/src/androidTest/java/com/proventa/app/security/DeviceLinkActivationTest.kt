package com.proventa.app.security

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DeviceLinkActivationTest {
    @Test
    fun signedPvla2CodeActivatesWithoutQrPvlinkOrSeparatePin() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SecureLocalStore(context)
        store.delete("device_authorization_descriptor")
        store.delete("activation_attempts")

        try {
            val now = System.currentTimeMillis()
            val fixture = DeviceLinkTestSupport.create(
                context = context,
                authorizedPosId = "pos_pvla2_direct_activation",
                employeeName = "José Dependiente",
                nowMillis = now
            )
            val activationCode = ProVentaActivationCode.encode(fixture.rawDescriptor)
            assertTrue(activationCode.startsWith("PVLA2:"))

            val manager = DeviceEnrollmentRequestFactory(context)
            val activated = manager.activateWithActivationCode(activationCode, now)
            assertEquals(4, activated.version)
            assertEquals(fixture.authorizationId, activated.authorizationId)
            assertEquals(fixture.phoneKeys.deviceId, activated.deviceId)
            assertEquals(fixture.authorizedPosId, activated.authorizedPosId)
            assertEquals("José Dependiente", activated.employeeName)
            assertEquals(fixture.authorizationId, manager.trustedInstallationAuthorization()?.authorizationId)

            // Repeating the exact same signed code is idempotent on the same phone.
            val replayed = manager.activateWithActivationCode(activationCode, now + 1L)
            assertEquals(fixture.authorizationId, replayed.authorizationId)

            // A valid ProControl signature cannot transfer this code to a different device ID.
            val provider = BouncyCastleProvider()
            if (java.security.Security.getProvider(provider.name) == null) {
                java.security.Security.addProvider(provider)
            }
            val foreign = JSONObject(fixture.rawDescriptor)
            foreign.put("deviceId", "device_${"0".repeat(32)}")
            foreign.remove("signature")
            val signer = java.security.Signature.getInstance("Ed25519", provider)
            signer.initSign(fixture.desktopKeys.private)
            signer.update(CanonicalJson.stringify(foreign).toByteArray(Charsets.UTF_8))
            foreign.put(
                "signature",
                JSONObject().put("algorithm", "Ed25519")
                    .put("value", java.util.Base64.getEncoder().encodeToString(signer.sign()))
            )
            val foreignCode = ProVentaActivationCode.encode(foreign.toString())
            assertThrows(IllegalArgumentException::class.java) {
                manager.activateWithActivationCode(foreignCode, now + 2L)
            }
            assertEquals(fixture.authorizationId, manager.trustedInstallationAuthorization()?.authorizationId)

            val last = activationCode.last()
            val damaged = activationCode.dropLast(1) + if (last == '0') '1' else '0'
            assertThrows(IllegalArgumentException::class.java) {
                manager.activateWithActivationCode(damaged, now + 3L)
            }
            assertEquals(fixture.authorizationId, manager.trustedInstallationAuthorization()?.authorizationId)
        } finally {
            store.delete("device_authorization_descriptor")
            store.delete("activation_attempts")
        }
    }

    @Test
    fun v4AuthorizationCanOnlyBePersistedAfterValidPvlinkAndPin() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SecureLocalStore(context)
        store.delete("device_authorization_descriptor")
        store.delete("activation_attempts")

        val fixture = DeviceLinkTestSupport.create(
            context = context,
            authorizedPosId = "pos_activation_guard",
            employeeName = "Dependiente de prueba"
        )
        val manager = DeviceEnrollmentRequestFactory(context)

        assertThrows(IllegalArgumentException::class.java) {
            manager.importAuthorizationDescriptor(
                rawJson = fixture.rawDescriptor,
                expectedDeviceId = fixture.phoneKeys.deviceId,
                expectedDevicePublicKeyHash = fixture.deviceSigningPublicKeyHash
            )
        }
        assertNull(manager.trustedInstallationAuthorization())

        assertThrows(IllegalArgumentException::class.java) {
            manager.activateWithEnvelope("00000000", fixture.envelopeJson)
        }
        assertNull(manager.trustedInstallationAuthorization())

        val activated = manager.activateWithEnvelope(fixture.pin, fixture.envelopeJson)
        assertEquals(4, activated.version)
        assertEquals(fixture.authorizationId, activated.authorizationId)
        assertEquals(fixture.authorizedPosId, activated.authorizedPosId)
        assertTrue(activated.permanent)
        assertEquals(fixture.authorizationId, manager.trustedInstallationAuthorization()?.authorizationId)

        // Issue a later authorization from the same ProControl installation for
        // another POS, then prove the still-unexpired previous .pvlink cannot roll
        // the phone back to its former POS.
        val replacementNow = System.currentTimeMillis() + 2L
        val replacement = DeviceLinkTestSupport.create(
            context = context,
            authorizedPosId = "pos_activation_guard_replaced",
            employeeName = "Dependiente de prueba",
            nowMillis = replacementNow,
            issuerKeyPair = fixture.desktopKeys
        )
        val replacementVerified = manager.activateWithEnvelope(
            replacement.pin,
            replacement.envelopeJson,
            replacementNow
        )
        assertEquals(fixture.installationId, replacementVerified.installationId)
        assertEquals("pos_activation_guard_replaced", replacementVerified.authorizedPosId)
        assertEquals(replacement.authorizationId, manager.trustedInstallationAuthorization()?.authorizationId)

        assertThrows(IllegalArgumentException::class.java) {
            manager.activateWithEnvelope(fixture.pin, fixture.envelopeJson, replacementNow + 1L)
        }
        val finalAuthorization = manager.trustedInstallationAuthorization()
        assertEquals(replacement.authorizationId, finalAuthorization?.authorizationId)
        assertEquals("pos_activation_guard_replaced", finalAuthorization?.authorizedPosId)
    }
    @Test
    fun malformedAttemptCounterFailsClosedAndStartsBoundedLockout() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SecureLocalStore(context)
        store.delete("device_authorization_descriptor")
        store.delete("activation_attempts")
        val now = System.currentTimeMillis()
        val fixture = DeviceLinkTestSupport.create(
            context = context,
            authorizedPosId = "pos_activation_counter_guard",
            employeeName = "Dependiente de prueba",
            nowMillis = now
        )
        // A max-failure count without a lockout timestamp is a corrupt state;
        // it must not be interpreted as zero failures.
        store.put(
            "activation_attempts",
            JSONObject().put("failures", 5).put("lockedUntil", 0L)
                .toString().toByteArray(Charsets.UTF_8)
        )

        val error = assertThrows(IllegalStateException::class.java) {
            DeviceEnrollmentRequestFactory(context).activateWithEnvelope(fixture.pin, fixture.envelopeJson, now)
        }
        assertTrue(error.message.orEmpty().contains("registro de intentos está dañado"))
        val storedBytes = store.get("activation_attempts") ?: throw AssertionError("No se guardó el bloqueo.")
        try {
            val record = JSONObject(String(storedBytes, Charsets.UTF_8))
            assertEquals(5, record.getInt("failures"))
            val lockoutUntil = record.getLong("lockedUntil")
            assertTrue(lockoutUntil > now)
            assertTrue(lockoutUntil - now <= 15 * 60 * 1000L)
        } finally {
            storedBytes.fill(0)
        }
    }

}
