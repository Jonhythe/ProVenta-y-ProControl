package com.proventa.app.security

import android.util.Base64
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import org.junit.runner.RunWith
import java.nio.charset.StandardCharsets
import java.security.Signature
import java.security.KeyPairGenerator

@RunWith(AndroidJUnit4::class)
class DevicePackageAcknowledgementVerifierTest {
    @Test
    fun acceptsOnlyTerminalAcknowledgementSignedByTheLinkedInstallation() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        SecureLocalStore(context).delete("device_authorization_descriptor")
        SecureLocalStore(context).delete("activation_attempts")
        val provider = BouncyCastleProvider()
        val now = System.currentTimeMillis()
        val fixture = DeviceLinkTestSupport.create(
            context = context,
            authorizedPosId = "pos_ack_test",
            employeeName = "Dependiente de prueba",
            nowMillis = now
        )
        val activated = DeviceLinkTestSupport.activate(context, fixture, now)
        assertEquals(4, activated.version)
        val desktopKeys = fixture.desktopKeys
        val desktopPem = fixture.desktopPublicKeyPem
        val desktopId = fixture.desktopDeviceId
        val deviceId = fixture.phoneKeys.deviceId
        val packageId = java.util.UUID.randomUUID().toString()
        val payloadHash = "a".repeat(64)
        val ackNow = System.currentTimeMillis()
        val ack = JSONObject()
            .put("format", "procontrol.package-ack")
            .put("version", 1)
            .put("desktopId", desktopId)
            .put("desktopPublicKey", desktopPem)
            .put("deviceId", deviceId)
            .put("packageId", packageId)
            .put("packageType", "sale_batch")
            .put("payloadHash", payloadHash)
            .put("status", "reconciled")
            .put("result", "applied")
            .put("receivedAt", ackNow - 1000L)
            .put("appliedAt", ackNow - 500L)
            .put("acknowledgedAt", ackNow)
        sign(ack, desktopKeys.private, provider)

        val verified = DevicePackageAcknowledgementVerifier(context).verify(
            ack.toString(), packageId, "sale_batch", payloadHash
        )
        assertEquals(packageId, verified.packageId)
        assertEquals("applied", verified.result)
        assertEquals("reconciled", verified.status)

        val tampered = JSONObject(ack.toString()).put("receivedAt", ackNow + 1L)
        assertThrows(IllegalArgumentException::class.java) {
            DevicePackageAcknowledgementVerifier(context).verify(
                tampered.toString(), packageId, "sale_batch", payloadHash
            )
        }
        // Even a correctly signed acknowledgement is rejected when its event
        // timestamps claim that receipt happened after final acknowledgement.
        tampered.remove("signature")
        sign(tampered, desktopKeys.private, provider)
        assertThrows(IllegalArgumentException::class.java) {
            DevicePackageAcknowledgementVerifier(context).verify(
                tampered.toString(), packageId, "sale_batch", payloadHash
            )
        }

        val otherDesktopKeys = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val wrongSigner = JSONObject(ack.toString())
            .put("desktopPublicKey", toPem(otherDesktopKeys.public.encoded))
        wrongSigner.remove("signature")
        sign(wrongSigner, otherDesktopKeys.private, provider)
        assertThrows(IllegalArgumentException::class.java) {
            DevicePackageAcknowledgementVerifier(context).verify(
                wrongSigner.toString(), packageId, "sale_batch", payloadHash
            )
        }
    }

    private fun sign(document: JSONObject, privateKey: java.security.PrivateKey, provider: BouncyCastleProvider) {
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(privateKey)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put("signature", JSONObject().put("algorithm", "Ed25519")
            .put("value", Base64.encodeToString(signer.sign(), Base64.NO_WRAP)))
    }

    private fun toPem(der: ByteArray): String =
        "-----BEGIN PUBLIC KEY-----\n" +
            Base64.encodeToString(der, Base64.NO_WRAP).chunked(64).joinToString("\n") +
            "\n-----END PUBLIC KEY-----\n"
}
