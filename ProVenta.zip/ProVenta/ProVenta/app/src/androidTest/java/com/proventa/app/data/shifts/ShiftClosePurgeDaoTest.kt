package com.proventa.app.data.shifts

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.*
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.security.MessageDigest

@RunWith(AndroidJUnit4::class)
class ShiftClosePurgeDaoTest {
    private fun permit(permitId: String, posId: String, deviceId: String, sequence: Long, status: String, now: Long) =
        ShiftPermitEntity(
            permitId = permitId,
            installationId = "installation-$posId",
            authorizationId = "authorization-$posId",
            desktopDeviceId = "desktop-test",
            posId = posId,
            deviceId = deviceId,
            employee = "Trabajador de prueba",
            sequence = sequence,
            shiftId = "shift-$permitId",
            startsAt = now - 60_000,
            endsAt = now + 60_000,
            emergencyEnabled = false,
            emergencyMaxSales = 0,
            emergencyExpiresAt = null,
            emergencyReason = null,
            issuedAt = now - 60_000,
            signature = "signature-$permitId",
            permitJson = "{}",
            status = status,
            importedAt = now
        )

    private fun packageRow(
        packageId: String,
        deviceId: String,
        type: String,
        aggregateId: String,
        status: String = "ACKNOWLEDGED",
        now: Long = System.currentTimeMillis()
    ) = OutboxPackageEntity(
        packageId = packageId,
        deviceId = deviceId,
        packageType = type,
        payloadHash = "a".repeat(64),
        envelopeJson = "{\"packageId\":\"$packageId\"}",
        aggregateId = aggregateId,
        status = status,
        createdAt = now,
        acknowledgementJson = if (status == "PENDING") null else "{}",
        acknowledgedAt = if (status == "PENDING") null else now
    )

    private fun product(posId: String, productId: String, now: Long) = ProductEntity(
        productId = productId,
        posId = posId,
        name = "Producto $productId",
        family = "prueba",
        unit = "ud",
        cupCashPriceMinor = 100,
        cupTransferPriceMinor = 108,
        transferMode = "percentage",
        transferPercentBasisPoints = 800,
        foreignPriceMinor = null,
        foreignCurrency = null,
        customCurrencyLabel = null,
        foreignCurrencyScale = null,
        availableQuantityMicros = 2_000_000,
        catalogAliasesJson = "[]",
        catalogRevision = "revision-$posId",
        updatedAt = now,
        active = true
    )

    private fun snapshot(posId: String, now: Long) = InventorySnapshotEntity(
        posId = posId,
        posName = "POS $posId",
        usdCupRateMicros = 400_000_000,
        exchangeRatesJson = "{}",
        installationId = "installation-$posId",
        deviceId = "device-$posId",
        packageId = "snapshot-$posId",
        payloadHash = "b".repeat(64),
        generatedAt = now,
        importedAt = now,
        productCount = 1
    )

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    @Test
    fun closingPosPurgesItsEntireOperationalHistoryButPreservesCurrentCloseAndOtherPos() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val now = System.currentTimeMillis()
        val suffix = now.toString()
        val posA = "pos-purge-a-$suffix"
        val posB = "pos-purge-b-$suffix"
        val deviceA = "device-a-$suffix"
        val deviceB = "device-b-$suffix"
        val currentPermitId = "current-permit-$suffix"
        val historicalPermitId = "historical-permit-$suffix"
        val otherPermitId = "other-permit-$suffix"
        val currentCloseId = "current-close-$suffix"
        val historicalOpenId = "historical-open-$suffix"
        val historicalCloseId = "historical-close-$suffix"
        val currentOpenId = "current-open-$suffix"
        val otherOpenId = "other-open-$suffix"

        dao.replaceProducts(listOf(product(posA, "product-a-$suffix", now), product(posB, "product-b-$suffix", now)))
        dao.saveInventorySnapshot(snapshot(posA, now))
        dao.saveInventorySnapshot(snapshot(posB, now))
        dao.insertShiftPermit(permit(historicalPermitId, posA, deviceA, 1, "CLOSED", now - 10_000))
        dao.insertShiftPermit(permit(currentPermitId, posA, deviceA, 2, "CLOSE_PENDING", now))
        dao.insertShiftPermit(permit(otherPermitId, posB, deviceB, 1, "OPENED", now))

        dao.insertOutboxPackage(packageRow(historicalOpenId, deviceA, "shift_open", historicalPermitId))
        dao.insertOutboxPackage(packageRow(historicalCloseId, deviceA, "shift_close", historicalPermitId))
        dao.insertOutboxPackage(packageRow(currentOpenId, deviceA, "shift_open", currentPermitId))
        dao.insertOutboxPackage(packageRow(currentCloseId, deviceA, "shift_close", currentPermitId, "PENDING", now))
        dao.insertOutboxPackage(packageRow(otherOpenId, deviceB, "shift_open", otherPermitId))

        val oldDraft = ShiftCloseDraftEntity(historicalPermitId, "shift-$historicalPermitId", posA, "{\"draft\":\"old\"}", now - 10_000)
        val currentDraft = ShiftCloseDraftEntity(currentPermitId, "shift-$currentPermitId", posA, "{\"draft\":\"current\"}", now)
        val otherDraft = ShiftCloseDraftEntity(otherPermitId, "shift-$otherPermitId", posB, "{\"draft\":\"other\"}", now)
        dao.saveShiftCloseDraft(oldDraft)
        dao.saveShiftCloseDraft(currentDraft)
        dao.saveShiftCloseDraft(otherDraft)

        val saleId = "sale-purge-$suffix"
        val lineId = "line-purge-$suffix"
        dao.insertSale(SaleEntity(saleId, posA, "old-shift", "SYNCED", now, now, "idem-$suffix"))
        dao.insertSaleLines(listOf(SaleLineEntity(
            lineId, saleId, "product-a-$suffix", "Producto", "ud", 1_000_000,
            100, 100, "CUP", null, 2
        )))
        dao.insertSaleTotals(listOf(SaleCurrencyTotalEntity("total-$suffix", saleId, "CUP", null, 2, 100)))
        dao.insertPayments(listOf(SalePaymentEntity(
            "payment-$suffix", lineId, "CASH", 100, "CUP", 2, null, null, null
        )))
        val saleOperationId = "sale-operation-$suffix"
        dao.enqueueOperation(OutboxOperationEntity(
            saleOperationId, "sale-operation-idem-$suffix", "sale", saleId,
            "{}", "c".repeat(64), "ACKNOWLEDGED", now
        ))
        val salePackageId = "sale-package-$suffix"
        dao.insertOutboxPackage(packageRow(salePackageId, deviceA, "sale_batch", saleId))

        val transferId = "transfer-purge-$suffix"
        val receiptId = "receipt-purge-$suffix"
        dao.insertGoodsReceipt(GoodsReceiptEntity(
            receiptId = receiptId,
            transferId = transferId,
            posId = posA,
            status = "CONFIRMED",
            confirmationCodeHash = "d".repeat(64),
            packageHash = "e".repeat(64),
            manifestJson = "{}",
            finalAuthorizationHash = "f".repeat(64),
            discrepancyReason = null,
            confirmedAt = now,
            createdAt = now,
            updatedAt = now
        ))
        dao.enqueueOperation(OutboxOperationEntity(
            "receipt-operation-$suffix", "receipt-operation-idem-$suffix", "goods_receipt", transferId,
            "{}", "1".repeat(64), "ACKNOWLEDGED", now
        ))
        dao.insertOutboxPackage(packageRow("receipt-package-$suffix", deviceA, "goods_receipt", transferId))

        val snapshotJson = dao.buildShiftCloseRecoverySnapshot(posA, currentPermitId)
        val snapshotDocument = JSONObject(snapshotJson)
        assertEquals(2, snapshotDocument.getJSONArray("shiftPermits").length())
        assertEquals(6, snapshotDocument.getJSONArray("outboxPackages").length())
        assertEquals(2, snapshotDocument.getJSONArray("shiftCloseDrafts").length())
        assertEquals(1, snapshotDocument.getJSONArray("sales").length())
        assertEquals(1, snapshotDocument.getJSONArray("goodsReceipts").length())

        assertTrue(dao.purgeClosedShiftDataAfterVerifiedArchive(posA, currentPermitId, sha256(snapshotJson)))
        assertTrue(dao.isClosedShiftBusinessDataCleared(posA, currentPermitId))

        assertEquals(0, dao.searchProducts(posA, "").size)
        assertEquals(1, dao.searchProducts(posB, "").size)
        assertNull(dao.getInventorySnapshot(posA))
        assertNotNull(dao.getInventorySnapshot(posB))
        assertNull(dao.getSale(saleId)) // Verifies the sale's lines, totals and payments cascade away.
        assertEquals(0, dao.listGoodsReceipts(posA).size)
        assertEquals(0, dao.countRecoveryDrafts(posA))
        assertEquals(0, dao.countRecoveryHistoricalShiftPermits(posA, currentPermitId))

        assertNull(dao.getOutboxPackage(historicalOpenId))
        assertNull(dao.getOutboxPackage(historicalCloseId))
        assertNull(dao.getOutboxPackage(currentOpenId))
        assertNotNull(dao.getOutboxPackage(currentCloseId))
        assertNotNull(dao.getOutboxPackage(otherOpenId))
        assertNotNull(dao.getShiftPermit(currentPermitId))
        assertNull(dao.getShiftPermit(historicalPermitId))
        assertNotNull(dao.getShiftPermit(otherPermitId))
        assertEquals(1, dao.listOutboxPackagesForRecovery(posA).size)
        assertEquals(currentCloseId, dao.listOutboxPackagesForRecovery(posA).single().packageId)
        assertEquals(1, dao.listShiftPermitsForRecovery(posA).size)
        assertEquals(currentPermitId, dao.listShiftPermitsForRecovery(posA).single().permitId)
        assertEquals(1, dao.listShiftCloseDraftsForRecovery(posB).size)
    }

    @Test
    fun aChangedPosSnapshotAbortsCleanupAndLeavesEveryRecordUntouched() = runBlocking {
        val dao = ProVentaDatabaseFactory.get(
            InstrumentationRegistry.getInstrumentation().targetContext
        ).proVentaDao()
        val now = System.currentTimeMillis()
        val suffix = now.toString()
        val posId = "pos-purge-rollback-$suffix"
        val deviceId = "device-purge-rollback-$suffix"
        val permitId = "permit-purge-rollback-$suffix"
        val packageId = "close-purge-rollback-$suffix"
        val before = product(posId, "product-rollback-$suffix", now)
        dao.replaceProducts(listOf(before))
        dao.insertShiftPermit(permit(permitId, posId, deviceId, 1, "CLOSE_PENDING", now))
        dao.insertOutboxPackage(packageRow(packageId, deviceId, "shift_close", permitId, "PENDING", now))
        val originalSnapshot = dao.buildShiftCloseRecoverySnapshot(posId, permitId)
        dao.replaceProducts(listOf(before.copy(availableQuantityMicros = 9_000_000)))

        try {
            dao.purgeClosedShiftDataAfterVerifiedArchive(posId, permitId, sha256(originalSnapshot))
            throw AssertionError("Se permitió limpiar un POS cuyo contenido cambió después del respaldo.")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message.orEmpty().contains("cambiaron después de crear el respaldo"))
        }
        assertEquals(9_000_000L, dao.searchProducts(posId, "").single().availableQuantityMicros)
        assertNotNull(dao.getShiftPermit(permitId))
        assertNotNull(dao.getOutboxPackage(packageId))
    }
}
