package com.proventa.app.security

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.Signature
import java.security.interfaces.RSAPublicKey
import java.security.spec.X509EncodedKeySpec
import android.util.Base64

@RunWith(AndroidJUnit4::class)
class DeviceKeyManagerTest {
    @Test
    fun createsPersistentEd25519AndRsa3072Identity() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val manager = DeviceKeyManager(context)
        val first = manager.getOrCreate()
        val second = DeviceKeyManager(context).getOrCreate()

        assertEquals(first.deviceId, second.deviceId)
        assertEquals(first.signingPublicPem, second.signingPublicPem)
        assertEquals(first.encryptionPublicPem, second.encryptionPublicPem)

        val provider = BouncyCastleProvider()
        val rsaPublic = KeyFactory.getInstance("RSA", provider).generatePublic(
            X509EncodedKeySpec(decodePem(first.encryptionPublicPem))
        ) as RSAPublicKey
        assertEquals(3072, rsaPublic.modulus.bitLength())
        assertEquals(65537L, rsaPublic.publicExponent.toLong())

        val challenge = "proventa-device-key-proof".toByteArray(StandardCharsets.UTF_8)
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(first.signingPrivateKey)
        signer.update(challenge)
        val signature = signer.sign()
        val verifier = Signature.getInstance("Ed25519", provider)
        verifier.initVerify(
            KeyFactory.getInstance("Ed25519", provider).generatePublic(
                X509EncodedKeySpec(decodePem(first.signingPublicPem))
            )
        )
        verifier.update(challenge)
        assertTrue(verifier.verify(signature))
        assertNotEquals("", first.deviceId)
    }

    private fun decodePem(pem: String): ByteArray = Base64.decode(
        pem.replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() },
        Base64.DEFAULT
    )
}
