package com.proventa.app.ui.screens

import com.google.zxing.BarcodeFormat
import com.google.zxing.DecodeHintType
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.ResultPoint
import com.google.zxing.common.GridSampler
import com.google.zxing.common.PerspectiveTransform
import com.google.zxing.common.BitMatrix
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.BinaryBitmap
import com.google.zxing.qrcode.decoder.Decoder
import com.google.zxing.qrcode.detector.Detector
import org.junit.Test
import java.io.File
import java.util.EnumMap

/** Diagnostic-only: exposes ZXing finder/alignment points and tests bounded alignment refinement. */
class QrDetectorAlignmentProbeTest {
    private fun fixture(name: String): ByteArray =
        javaClass.classLoader!!.getResourceAsStream("procontrol-pvla2/$name")!!.use { it.readBytes() }

    @Test
    fun reportDetectedPointsAndAlignmentRefinement() {
        val expected = String(fixture("procontrol-pvla2-token.txt"), Charsets.US_ASCII).trim()
        val frame = fixture("procontrol-pvla2-560px-1280x720.luma")
        val source = PlanarYUVLuminanceSource(frame, 1280, 720, 0, 0, 1280, 720, false)
        val bitmap = BinaryBitmap(HybridBinarizer(source))
        val image = bitmap.blackMatrix
        val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
            put(DecodeHintType.POSSIBLE_FORMATS, listOf(BarcodeFormat.QR_CODE))
            put(DecodeHintType.TRY_HARDER, true)
            put(DecodeHintType.CHARACTER_SET, "UTF-8")
        }
        val report = StringBuilder()
        report.appendLine("ZXING DETECTOR ALIGNMENT PROBE")
        report.appendLine("Expected length=${expected.length}; frame=1280x720")
        report.appendLine("Reader direct: ${runCatching { com.google.zxing.qrcode.QRCodeReader().decode(bitmap, hints).text }.fold({ "OK len=${it.length} exact=${it == expected}" }, { it.javaClass.simpleName })}")

        val detection = runCatching { Detector(image).detect(hints) }.getOrElse {
            report.appendLine("Detector failed: ${it.javaClass.name}: ${it.message}")
            writeReport(report)
            return
        }
        val dim = detection.bits.width
        val points = detection.points
        report.appendLine("sampledBits=${detection.bits.width}x${detection.bits.height}; pointCount=${points.size}")
        points.forEachIndexed { index, p -> report.appendLine("point[$index]=(${p.x},${p.y})") }
        report.appendLine("Detector matrix decode: ${runCatching { Decoder().decode(detection.bits, hints).text }.fold({ "OK len=${it.length} exact=${it == expected}" }, { it.javaClass.simpleName })}")

        if (points.size < 3) {
            report.appendLine("Not enough finder points for custom sampling")
            writeReport(report)
            return
        }
        // ZXing order: bottom-left, top-left, top-right, optional alignment pattern.
        val bl = points[0]
        val tl = points[1]
        val tr = points[2]
        val alignment = points.getOrNull(3)

        fun decodeWith(brOrAlignment: ResultPoint, sourceBottomRight: Float): String {
            val transform = PerspectiveTransform.quadrilateralToQuadrilateral(
                3.5f, 3.5f,
                dim - 3.5f, 3.5f,
                sourceBottomRight, sourceBottomRight,
                3.5f, dim - 3.5f,
                tl.x, tl.y,
                tr.x, tr.y,
                brOrAlignment.x, brOrAlignment.y,
                bl.x, bl.y
            )
            val sampled = GridSampler.getInstance().sampleGrid(image, dim, dim, transform)
            return Decoder().decode(sampled, hints).text
        }

        // First: exact same alignment point/geometry as the stock Detector.
        if (alignment != null) {
            report.appendLine("Original alignment decode: ${runCatching { decodeWith(alignment, dim - 6.5f) }.fold({ "OK len=${it.length} exact=${it == expected}" }, { it.javaClass.simpleName })}")
        } else {
            report.appendLine("No alignment point found")
        }

        // Second: ignore the alignment point and use the three-finder affine estimate.
        val affineBr = ResultPoint(tr.x - tl.x + bl.x, tr.y - tl.y + bl.y)
        report.appendLine("Affine BR=(${affineBr.x},${affineBr.y}); decode=${runCatching { decodeWith(affineBr, dim - 3.5f) }.fold({ "OK len=${it.length} exact=${it == expected}" }, { it.javaClass.simpleName })}")

        // Third: bounded sub-module refinement of the detected alignment point.
        // No image crop, scaling, segmentation, payload reconstruction, or regenerated QR.
        if (alignment != null) {
            var attempts = 0
            var exact: String? = null
            var exactOffset: Pair<Int, Int>? = null
            var firstSuccess: String? = null
            var firstSuccessOffset: Pair<Int, Int>? = null
            for (radius in listOf(2, 4, 6, 8, 10, 12)) {
                for (dy in -radius..radius) {
                    for (dx in -radius..radius) {
                        if (kotlin.math.abs(dx) != radius && kotlin.math.abs(dy) != radius) continue
                        attempts++
                        val candidate = ResultPoint(alignment.x + dx, alignment.y + dy)
                        val decoded = runCatching { decodeWith(candidate, dim - 6.5f) }.getOrNull()
                        if (decoded != null && firstSuccess == null) {
                            firstSuccess = decoded
                            firstSuccessOffset = dx to dy
                        }
                        if (decoded == expected) {
                            exact = decoded
                            exactOffset = dx to dy
                            break
                        }
                    }
                    if (exact != null) break
                }
                if (exact != null) break
            }
            report.appendLine("Alignment perimeter attempts=$attempts")
            report.appendLine("First successful decode=${firstSuccess?.let { "len=${it.length} exact=${it == expected} offset=${firstSuccessOffset}" } ?: "none"}")
            report.appendLine("Exact payload decode=${exact?.let { "YES offset=$exactOffset" } ?: "NO"}")
        }
        writeReport(report)
    }

    private fun writeReport(report: StringBuilder) {
        val candidates = listOf(File("build"), File("app/build"), File("../app/build"))
        val build = candidates.firstOrNull { it.exists() && (it.resolve("test-results").exists() || it.resolve("reports").exists()) } ?: File("app/build")
        val output = build.resolve("qr-detector-alignment-probe.txt")
        output.parentFile?.mkdirs()
        output.writeText(report.toString(), Charsets.UTF_8)
        println(report.toString())
        println("Report: ${output.absolutePath}")
    }
}
