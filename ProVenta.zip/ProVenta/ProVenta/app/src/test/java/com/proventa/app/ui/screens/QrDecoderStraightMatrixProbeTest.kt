package com.proventa.app.ui.screens

import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import org.junit.Test
import java.io.File
import java.util.EnumMap

/** Diagnostic-only: checks whether ZXing can read the same modules after geometric normalization. */
class QrDecoderStraightMatrixProbeTest {
    private fun bytes(name: String): ByteArray =
        javaClass.classLoader!!.getResourceAsStream("procontrol-pvla2/$name")!!.use { it.readBytes() }

    @Test
    fun reportStraightenedMatrixCompatibility() {
        val expected = String(bytes("procontrol-pvla2-token.txt"), Charsets.US_ASCII).trim()
        val cases = listOf(
            "center" to "straight-center-1280x720.luma",
            "left96" to "straight-left96-1280x720.luma",
            "right560" to "straight-right560-1280x720.luma"
        )
        val report = StringBuilder()
        report.appendLine("ZXING STRAIGHT MATRIX PROBE")
        report.appendLine("Expected token length=${expected.length}; prefix=${expected.take(14)}")
        report.appendLine("Source matrix was perspective-normalized by OpenCV from the same original camera fixture; modules were not regenerated.")

        for ((label, file) in cases) {
            val frame = bytes(file)
            report.appendLine("CASE $label; dimensions=1280x720; bytes=${frame.size}")
            val production = runCatching {
                decodeQrPayloadsFromLuma(frame, 1280, 720, 0, singleQrOnly = true)
            }
            val values = production.getOrNull().orEmpty()
            report.appendLine("  productionDecoder=${if (production.isSuccess) "OK" else production.exceptionOrNull()?.javaClass?.simpleName}; count=${values.size}; exact=${values == listOf(expected)}; lengths=${values.map { it.length }}")

            val source = PlanarYUVLuminanceSource(frame, 1280, 720, 0, 0, 1280, 720, false)
            for ((kind, binarizer) in listOf(
                "Hybrid" to { s: com.google.zxing.LuminanceSource -> HybridBinarizer(s) },
                "Global" to { s: com.google.zxing.LuminanceSource -> GlobalHistogramBinarizer(s) }
            )) {
                for (pure in listOf(false, true)) {
                    val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
                        put(DecodeHintType.POSSIBLE_FORMATS, listOf(BarcodeFormat.QR_CODE))
                        put(DecodeHintType.TRY_HARDER, true)
                        put(DecodeHintType.CHARACTER_SET, "UTF-8")
                        if (pure) put(DecodeHintType.PURE_BARCODE, true)
                    }
                    val decoded = runCatching {
                        QRCodeReader().decode(BinaryBitmap(binarizer(source)), hints).text
                    }
                    report.appendLine("  $kind pure=$pure => ${if (decoded.isSuccess) "OK len=${decoded.getOrNull()?.length} exact=${decoded.getOrNull() == expected}" else decoded.exceptionOrNull()?.javaClass?.simpleName}")
                }
            }
        }

        val candidates = listOf(File("build"), File("app/build"), File("../app/build"))
        val build = candidates.firstOrNull { it.exists() && (it.resolve("test-results").exists() || it.resolve("reports").exists()) } ?: File("app/build")
        val output = build.resolve("qr-straight-matrix-probe.txt")
        output.parentFile?.mkdirs()
        output.writeText(report.toString(), Charsets.UTF_8)
        println("QR straight matrix probe: ${output.absolutePath}")
        println(report.toString())
    }
}
