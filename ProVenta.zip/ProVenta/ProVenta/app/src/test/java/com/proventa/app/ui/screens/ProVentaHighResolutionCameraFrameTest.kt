package com.proventa.app.ui.screens

import java.nio.ByteBuffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProVentaHighResolutionCameraFrameTest {
    private fun fixture(name: String): ByteArray =
        javaClass.classLoader!!.getResourceAsStream("procontrol-pvla2/$name")!!.use { it.readBytes() }

    @Test
    fun normalizesTwelveMegapixelCameraFrameAndDecodesTheSameSinglePvla2Qr() {
        val expectedToken = String(fixture("procontrol-pvla2-token.txt"), Charsets.US_ASCII).trim()
        val source = fixture("procontrol-pvla2-560px-1280x720.luma")
        val sourceWidth = 1280
        val sourceHeight = 720
        assertEquals(sourceWidth * sourceHeight, source.size)

        // Simulate a true 4032x3024 (12.2MP) 4:3 CameraX luminance plane.
        // The 16:9 source is scaled to the sensor width and letterboxed vertically.
        val cameraWidth = 4032
        val cameraHeight = 3024
        val sourceScale = cameraWidth.toDouble() / sourceWidth.toDouble()
        val contentHeight = (sourceHeight * sourceScale).toInt()
        val topPadding = (cameraHeight - contentHeight) / 2
        val rowStride = cameraWidth
        val camera = ByteArray(cameraWidth * cameraHeight) { 0xFF.toByte() }
        for (cameraY in 0 until contentHeight) {
            val sourceY = (cameraY.toDouble() / sourceScale).toInt().coerceIn(0, sourceHeight - 1)
            val destinationRow = (topPadding + cameraY) * rowStride
            val sourceRow = sourceY * sourceWidth
            for (cameraX in 0 until cameraWidth) {
                val sourceX = (cameraX.toDouble() / sourceScale).toInt().coerceIn(0, sourceWidth - 1)
                camera[destinationRow + cameraX] = source[sourceRow + sourceX]
            }
        }

        assertTrue("El fotograma simulado debe superar el límite anterior", camera.size.toLong() > MAX_QR_ANALYSIS_PIXELS)
        val normalized = copyCameraLumaPlane(
            sourceBuffer = ByteBuffer.wrap(camera),
            width = cameraWidth,
            height = cameraHeight,
            rowStride = rowStride,
            pixelStride = 1
        )
        assertTrue(normalized.data.size.toLong() <= MAX_QR_ANALYSIS_PIXELS)
        assertEquals(normalized.width * normalized.height, normalized.data.size)
        for (rotation in listOf(0, 90, 180, 270)) {
            assertEquals(
                "La cámara de alta resolución debe conservar el mismo QR PVLA2 (rotación $rotation)",
                listOf(expectedToken),
                decodeQrPayloadsFromLuma(
                    normalized.data,
                    normalized.width,
                    normalized.height,
                    rotationDegrees = rotation,
                    singleQrOnly = true
                )
            )
        }
    }
}
