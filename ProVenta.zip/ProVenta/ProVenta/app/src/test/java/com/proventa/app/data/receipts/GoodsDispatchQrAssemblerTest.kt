package com.proventa.app.data.receipts

import java.util.Base64
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GoodsDispatchQrAssemblerTest {
    @Test
    fun reconstructsOutOfOrderProControlFramesAndAcceptsDuplicates() {
        val document = """{"dispatchId":"dispatch_001","posName":"Punto Ñ","items":[1,2,3]}"""
        val bytes = document.toByteArray(Charsets.UTF_8)
        val chunks = bytes.toList().chunked(40).map { it.toByteArray() }
        val token = "DISPATC1"
        val frames = chunks.mapIndexed { index, chunk ->
            val encoded = Base64.getUrlEncoder().withoutPadding().encodeToString(chunk)
            "PCQ1|T|" + token + "|" +
                (index + 1).toString().padStart(2, '0') + "/" +
                chunks.size.toString().padStart(2, '0') + "|" + encoded
        }

        val assembler = GoodsDispatchQrAssembler()
        val first = assembler.add(frames.last())
        assertNull(first.completeDocument)
        assertEquals(1, first.receivedFrames)
        assertEquals(chunks.size, first.totalFrames)

        val duplicate = assembler.add(frames.last())
        assertEquals(1, duplicate.receivedFrames)

        var completed: String? = null
        frames.dropLast(1).reversed().forEach { frame ->
            val progress = assembler.add(frame)
            if (progress.completeDocument != null) completed = progress.completeDocument
        }
        assertEquals(document, completed)
        assertNull(assembler.currentProgress())
    }

    @Test
    fun rejectsConflictingDuplicateFrames() {
        val assembler = GoodsDispatchQrAssembler()
        val firstChunk = ByteArray(40) { it.toByte() }
        val changedChunk = ByteArray(40) { (it + 1).toByte() }
        val firstEncoded = Base64.getUrlEncoder().withoutPadding().encodeToString(firstChunk)
        val changedEncoded = Base64.getUrlEncoder().withoutPadding().encodeToString(changedChunk)
        val frame = "PCQ1|T|DISPATC1|01/02|" + firstEncoded
        assembler.add(frame)
        val changed = "PCQ1|T|DISPATC1|01/02|" + changedEncoded
        val error = runCatching { assembler.add(changed) }.exceptionOrNull()
        assertTrue(error is IllegalArgumentException)
    }

    @Test
    fun rejectsWrongQrKindAndFrameIndex() {
        val assembler = GoodsDispatchQrAssembler()
        assertTrue(runCatching { assembler.add("PCQ1|P|DISPATC1|01/01|YWJj") }.isFailure)
        assertTrue(runCatching { assembler.add("PCQ1|T|DISPATC1|02/01|YWJj") }.isFailure)
    }
}
