package com.proventa.app.ui.screens

import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.LuminanceSource
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.multi.qrcode.QRCodeMultiReader
import com.google.zxing.qrcode.QRCodeReader
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File
import java.util.EnumMap

/** Temporary diagnostic only. Does not modify production code or existing tests. */
class QrDecoderDiagnosticProbeTest {
    private data class Region(val name: String, val bytes: ByteArray, val width: Int, val height: Int)

    @Test
    fun writeDecoderProbeReport() {
        val loader = javaClass.classLoader!!
        val frame = loader.getResourceAsStream(
            "procontrol-pvla2/procontrol-pvla2-560px-1280x720.luma"
        )!!.use { it.readBytes() }
        val expectedToken = loader.getResourceAsStream(
            "procontrol-pvla2/procontrol-pvla2-token.txt"
        )!!.use { String(it.readBytes(), Charsets.US_ASCII).trim() }
        val width = 1280
        val height = 720
        assertEquals("Unexpected fixture byte count", width * height, frame.size)

        val regions = mutableListOf(Region("full-frame", frame, width, height))
        // Reproduce the existing off-center test exactly, diagnostic-only.
        val cropSide = 560
        val qrTop = (height - cropSide) / 2
        val sourceBlock = ByteArray(cropSide * cropSide)
        for (row in 0 until cropSide) {
            System.arraycopy(frame, (qrTop + row) * width + 360, sourceBlock, row * cropSide, cropSide)
        }
        for (left in listOf(96, 360, 560)) {
            val shifted = ByteArray(width * height) { 0xff.toByte() }
            for (row in 0 until cropSide) {
                System.arraycopy(sourceBlock, row * cropSide, shifted, (qrTop + row) * width + left, cropSide)
            }
            regions += Region("shifted-frame-x$left", shifted, width, height)
        }

        val report = StringBuilder()
        report.appendLine("ZXING DIAGNOSTIC PROBE")
        report.appendLine("frame=${width}x${height}; bytes=${frame.size}")
        report.appendLine("expectedTokenLength=${expectedToken.length}; expectedPrefix=${expectedToken.take(14)}")
        report.appendLine("This test is diagnostic-only. It does not edit production code or existing tests.")

        val binarizers = listOf<Pair<String, (LuminanceSource) -> com.google.zxing.Binarizer>>(
            "HybridBinarizer" to { source -> HybridBinarizer(source) },
            "GlobalHistogramBinarizer" to { source -> GlobalHistogramBinarizer(source) }
        )

        for (region in regions) {
            // The original test stops at the first failed assertion; its first
            // orientation is 0 degrees, so probe that exact failing orientation.
            val base = PlanarYUVLuminanceSource(
                region.bytes, region.width, region.height,
                0, 0, region.width, region.height, false
            )
                val sources = listOf("normal" to base, "inverted" to base.invert())
                for ((sourceName, source) in sources) {
                    for ((binarizerName, makeBinarizer) in binarizers) {
                        val matrixInfo = try {
                            val matrix = makeBinarizer(source).blackMatrix
                            val rect = matrix.enclosingRectangle
                            "blackMatrix=${matrix.width}x${matrix.height}; bounds=${rect?.contentToString() ?: "none"}"
                        } catch (error: Exception) {
                            "blackMatrix-error=${error.javaClass.simpleName}:${error.message}"
                        }
                        report.appendLine("REGION ${region.name} / rotation=0 / $sourceName / $binarizerName / $matrixInfo")

                        for (tryHarder in listOf(false, true)) {
                            for (pure in listOf(false, true)) {
                                val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
                                    put(DecodeHintType.POSSIBLE_FORMATS, listOf(BarcodeFormat.QR_CODE))
                                    put(DecodeHintType.CHARACTER_SET, "UTF-8")
                                    if (tryHarder) put(DecodeHintType.TRY_HARDER, true)
                                    if (pure) put(DecodeHintType.PURE_BARCODE, true)
                                }
                                val label = "tryHarder=$tryHarder pure=$pure"
                                try {
                                    val text = QRCodeReader().decode(
                                        BinaryBitmap(makeBinarizer(source)), hints
                                    ).text
                                    report.appendLine(
                                        "  QRCodeReader $label => OK len=${text.length} matchesExpected=${text == expectedToken} prefix=${text.take(14)}"
                                    )
                                } catch (error: Exception) {
                                    report.appendLine("  QRCodeReader $label => ${error.javaClass.simpleName}: ${error.message}")
                                }
                            }
                        }
                        try {
                            val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
                                put(DecodeHintType.POSSIBLE_FORMATS, listOf(BarcodeFormat.QR_CODE))
                                put(DecodeHintType.CHARACTER_SET, "UTF-8")
                                put(DecodeHintType.TRY_HARDER, true)
                            }
                            val results = QRCodeMultiReader().decodeMultiple(BinaryBitmap(makeBinarizer(source)), hints)
                            report.appendLine(
                                "  QRCodeMultiReader => OK count=${results.size} matchesExpected=${results.any { it.text == expectedToken }} lens=${results.map { it.text.length }}"
                            )
                        } catch (error: Exception) {
                            report.appendLine("  QRCodeMultiReader => ${error.javaClass.simpleName}: ${error.message}")
                        }
                    }
                }
        }

        // Gradle's Test task usually runs with app/ as its working directory;
        // also support environments that use the repository root instead.
        val currentDir = File(System.getProperty("user.dir"))
        val buildCandidates = listOf(
            currentDir.resolve("build"),
            currentDir.resolve("app/build"),
            currentDir.parentFile?.resolve("app/build")
        ).filterNotNull()
        val buildDir = buildCandidates.firstOrNull {
            File(it, "test-results/testDebugUnitTest").exists()
        } ?: currentDir.resolve("build")
        val output = buildDir.resolve("qr-decoder-probe.txt")
        output.parentFile?.mkdirs()
        output.writeText(report.toString(), Charsets.UTF_8)
        println("QR decoder probe report: ${output.absolutePath}")
        println(report.toString())
    }
}
