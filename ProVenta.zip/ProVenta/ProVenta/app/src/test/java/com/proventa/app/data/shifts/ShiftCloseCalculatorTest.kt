package com.proventa.app.data.shifts

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ShiftCloseCalculatorTest {
    @Test
    fun countsCupBillsAndUsdWithCurrentRate() {
        val result = ShiftCloseCalculator.summarizeMoney(
            cupDenominations = mapOf("100" to "2", "50" to "1"),
            foreignDenominations = mapOf("USD" to mapOf("10" to "1")),
            transferCupText = "25.50",
            payments = listOf(
                ShiftPaymentSummary("CUP", "CASH", 20_000, 2),
                ShiftPaymentSummary("USD", "CASH", 1_000, 2),
                ShiftPaymentSummary("CUP", "TRANSFER", 5_000, 2)
            ),
            exchangeRatesMicros = mapOf("USD" to 400_000_000L)
        )
        assertEquals(25_000L, result.cupCashMinor)
        assertEquals(400_000L, result.foreignCashCupMinor)
        assertEquals(2_550L, result.transferCupMinor)
        assertEquals(427_550L, result.countedTotalCupMinor)
        assertEquals(425_000L, result.expectedSalesCupMinor)
        assertEquals(2_550L, result.differenceCupMinor)
    }

    @Test
    fun discreteUnitsRejectFractionsButWeightUnitsAllowThem() {
        assertEquals(1_000_000L, ShiftCloseCalculator.quantityToMicros("1", "u"))
        assertEquals(1_250_000L, ShiftCloseCalculator.quantityToMicros("1.25", "lb"))
        assertThrows(IllegalArgumentException::class.java) {
            ShiftCloseCalculator.quantityToMicros("1.5", "pqt")
        }
        assertThrows(IllegalArgumentException::class.java) {
            ShiftCloseCalculator.quantityToMicros("-1", "kg")
        }
    }

    @Test
    fun ipvIncludesOnlyConfirmedReceiptsInOpeningBalance() {
        assertEquals(
            3_500_000L,
            ShiftCloseCalculator.ipvQuantityMicros(
                openingMicros = 10_000_000L,
                receivedMicros = 2_000_000L,
                finalMicros = 8_500_000L
            )
        )
        assertThrows(ArithmeticException::class.java) {
            ShiftCloseCalculator.ipvQuantityMicros(Long.MAX_VALUE, 1L, 0L)
        }
    }

    @Test
    fun missingRateBlocksForeignCashAndSalesConversion() {
        assertThrows(IllegalStateException::class.java) {
            ShiftCloseCalculator.summarizeMoney(
                cupDenominations = emptyMap(),
                foreignDenominations = mapOf("USD" to mapOf("5" to "1")),
                transferCupText = "",
                payments = emptyList(),
                exchangeRatesMicros = emptyMap()
            )
        }
        assertThrows(IllegalStateException::class.java) {
            ShiftCloseCalculator.expectedSalesCupMinor(
                listOf(ShiftPaymentSummary("EUR", "CASH", 1_000, 2)),
                emptyMap()
            )
        }
    }

    @Test
    fun denominationCountsMustBeWholeAndNonNegative() {
        assertThrows(IllegalArgumentException::class.java) {
            ShiftCloseCalculator.denominationTotalMinor(mapOf("100" to "1.5"))
        }
        assertThrows(IllegalArgumentException::class.java) {
            ShiftCloseCalculator.denominationTotalMinor(mapOf("100" to "-1"))
        }
    }
}
