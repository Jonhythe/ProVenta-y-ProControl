package com.proventa.app.ui.screens

import com.google.zxing.BarcodeFormat
import com.google.zxing.DecodeHintType
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.ResultPoint
import com.google.zxing.BinaryBitmap
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.common.PerspectiveTransform
import com.google.zxing.common.GridSampler
import com.google.zxing.qrcode.decoder.Decoder
import com.google.zxing.qrcode.detector.Detector
import org.junit.Test
import java.io.File
import java.util.EnumMap
import kotlin.math.abs
import kotlin.math.roundToInt

/** Diagnostic only: verifies a version-24 candidate and valid alignment centers from one full frame. */
class QrVersionAlignmentProbeTest {
    private fun fixture(name: String): ByteArray =
        javaClass.classLoader!!.getResourceAsStream("procontrol-pvla2/$name")!!.use { it.readBytes() }

    private data class Point(val x: Float, val y: Float)

    private fun findAlignment(
        image: com.google.zxing.common.BitMatrix,
        predicted: Point,
        ux: Point,
        vy: Point,
        radius: Int
    ): Pair<Point, Int> {
        var best = -1
        var bestX = predicted.x.roundToInt()
        var bestY = predicted.y.roundToInt()
        for (dy in -radius..radius) {
            for (dx in -radius..radius) {
                var score = 0
                for (row in -2..2) {
                    for (col in -2..2) {
                        val px = (predicted.x + dx + col * ux.x + row * vy.x).roundToInt()
                        val py = (predicted.y + dy + col * ux.y + row * vy.y).roundToInt()
                        if (px !in 0 until image.width || py !in 0 until image.height) continue
                        val expectedBlack = abs(col) == 2 || abs(row) == 2 || (col == 0 && row == 0)
                        if (image.get(px, py) == expectedBlack) score++
                    }
                }
                if (score > best) {
                    best = score
                    bestX = predicted.x.roundToInt() + dx
                    bestY = predicted.y.roundToInt() + dy
                }
                if (best == 25) return Point(bestX.toFloat(), bestY.toFloat()) to best
            }
        }
        return Point(bestX.toFloat(), bestY.toFloat()) to best
    }

    @Test
    fun testVersion24WithActualAlignmentPatterns() {
        val expected = String(fixture("procontrol-pvla2-token.txt"), Charsets.US_ASCII).trim()
        val report = StringBuilder("ZXING VERSION / ALIGNMENT PROBE\n")
        val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
            put(DecodeHintType.POSSIBLE_FORMATS, listOf(BarcodeFormat.QR_CODE))
            put(DecodeHintType.TRY_HARDER, true)
            put(DecodeHintType.CHARACTER_SET, "UTF-8")
        }
        val dimension = 113 // OpenCV's straight matrix from this same camera frame is 113x113 (QR version 24).
        val finderModuleSpan = dimension - 7f
        val centers = listOf(106 to 80, 80 to 106, 80 to 80)

        for (left in listOf(360, 96, 560)) {
            val base = fixture("procontrol-pvla2-560px-1280x720.luma")
            val shifted = if (left == 360) base else ByteArray(1280 * 720) { 0xFF.toByte() }.also { out ->
                val top = (720 - 560) / 2
                for (row in 0 until 560) {
                    System.arraycopy(base, (top + row) * 1280 + 360, out, (top + row) * 1280 + left, 560)
                }
            }
            val source = PlanarYUVLuminanceSource(shifted, 1280, 720, 0, 0, 1280, 720, false)
            val bitmap = BinaryBitmap(HybridBinarizer(source))
            val black = bitmap.blackMatrix
            val detection = try {
                Detector(black).detect(hints)
            } catch (error: Exception) {
                report.appendLine("left=$left detector=${error.javaClass.simpleName}")
                continue
            }
            val points = detection.points
            val bl = points[0]
            val tl = points[1]
            val tr = points[2]
            val ux = Point((tr.x - tl.x) / finderModuleSpan, (tr.y - tl.y) / finderModuleSpan)
            val vy = Point((bl.x - tl.x) / finderModuleSpan, (bl.y - tl.y) / finderModuleSpan)
            report.appendLine("left=$left detectorDimension=${detection.bits.width}; BL=(${bl.x},${bl.y}) TL=(${tl.x},${tl.y}) TR=(${tr.x},${tr.y})")
            for ((ax, ay) in centers) {
                val predicted = Point(
                    tl.x + (ax - 3.5f) * ux.x + (ay - 3.5f) * vy.x,
                    tl.y + (ax - 3.5f) * ux.y + (ay - 3.5f) * vy.y
                )
                val (found, score) = findAlignment(black, predicted, ux, vy, radius = 22)
                val transform = PerspectiveTransform.quadrilateralToQuadrilateral(
                    3.5f, 3.5f,
                    dimension - 3.5f, 3.5f,
                    ax.toFloat(), ay.toFloat(),
                    3.5f, dimension - 3.5f,
                    tl.x, tl.y,
                    tr.x, tr.y,
                    found.x, found.y,
                    bl.x, bl.y
                )
                val decoded = runCatching {
                    val sampled = GridSampler.getInstance().sampleGrid(black, dimension, dimension, transform)
                    Decoder().decode(sampled, hints).text
                }.getOrNull()
                report.appendLine("  align=($ax,$ay) predicted=(${predicted.x},${predicted.y}) found=(${found.x},${found.y}) patternScore=$score/25 decode=${decoded?.let { "OK len=${it.length} exact=${it == expected}" } ?: "FAIL"}")
                if (decoded == expected) break
            }
        }
        writeReport(report)
    }

    private fun writeReport(report: StringBuilder) {
        val output = File("app/build/qr-version-alignment-probe.txt")
        output.parentFile?.mkdirs()
        output.writeText(report.toString(), Charsets.UTF_8)
        println(report.toString())
        println("Report: ${output.absolutePath}")
    }
}
