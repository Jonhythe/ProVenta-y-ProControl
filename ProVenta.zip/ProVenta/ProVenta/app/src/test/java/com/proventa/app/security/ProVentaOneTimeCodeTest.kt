package com.proventa.app.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ProVentaOneTimeCodeTest {
    @Test
    fun normalizesLegacySixDigitAndCurrentEightDigitCodes() {
        assertEquals("123456", ProVentaOneTimeCode.normalize("12 34-56x"))
        assertEquals("", ProVentaOneTimeCode.normalize("abc"))
        assertEquals("12345678", ProVentaOneTimeCode.normalize("123456789"))
        assertEquals("12345678", ProVentaOneTimeCode.normalize("12 34-5678x"))
    }

    @Test
    fun recognizesOnlyProControlAuthorizationQrPayloads() {
        val descriptor = """{"format":"procontrol.device-authorization","version":1,"code":"123456","employeeName":"Trabajador Ñ"}"""
        val transport = "PCD1:" + java.util.Base64.getUrlEncoder().withoutPadding()
            .encodeToString(descriptor.toByteArray(Charsets.UTF_8))
        assertEquals(descriptor, ProVentaOneTimeCode.descriptorFromQrPayload(transport))
        assertEquals(descriptor, ProVentaOneTimeCode.descriptorFromQrPayload(descriptor))
        assertNull(ProVentaOneTimeCode.descriptorFromQrPayload("123456"))
        assertNull(ProVentaOneTimeCode.descriptorFromQrPayload("""{"format":"other","code":"123456"}"""))
        assertNull(ProVentaOneTimeCode.descriptorFromQrPayload("PCD1:***"))
        assertEquals("123456", ProVentaOneTimeCode.fromQrPayload("123456"))
        assertEquals("12345678", ProVentaOneTimeCode.fromQrPayload("12345678"))
        assertNull(ProVentaOneTimeCode.fromQrPayload("1234567"))
        assertNull(ProVentaOneTimeCode.fromQrPayload(descriptor))
    }
}
