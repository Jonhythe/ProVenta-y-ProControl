package com.proventa.app.security

import java.nio.charset.StandardCharsets
import java.util.Base64
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.json.JSONObject

class DeviceAuthorizationQrAssemblerTest {
    @Test
    fun qrFragmentsRebuildTheExactDescriptorAcceptedByThePvla2FileDecoder() {
        val descriptor = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 4)
            .put("permanent", true)
            .put("authorizationId", "auth_12345678-1234-1234-1234-123456789012")
            .put("deviceId", "device_1234567890abcdef1234567890abcdef")
            .put("authorizedPosId", "pos_demo_01")
            .put("authorizedPosName", "Punto de Venta Principal")
            .put("employeeName", "José Dependiente")
            .put("notes", "Descriptor de prueba QR en varios fragmentos para asegurar reconstrucción exacta.")
            .toString()
        val rawBytes = descriptor.toByteArray(StandardCharsets.UTF_8)
        val chunkBytes = 40
        val total = (rawBytes.size + chunkBytes - 1) / chunkBytes
        assertTrue("La prueba debe crear varios fragmentos", total > 1)

        val frames = (0 until total).map { index ->
            val start = index * chunkBytes
            val end = minOf(rawBytes.size, start + chunkBytes)
            val chunk = rawBytes.copyOfRange(start, end)
            val encoded = Base64.getUrlEncoder().withoutPadding().encodeToString(chunk)
            val frameNumber = (index + 1).toString().padStart(2, '0')
            val totalNumber = total.toString().padStart(2, '0')
            "PCQ1|D|AUTHQR01|$frameNumber/$totalNumber|$encoded"
        }

        val assembler = DeviceAuthorizationQrAssembler()
        var completed: String? = null
        frames.forEachIndexed { index, frame ->
            val progress = assembler.add(frame)
            if (index < frames.lastIndex) assertNull(progress.completeDescriptor)
            completed = progress.completeDescriptor ?: completed
        }
        assertNotNull(completed)
        assertEquals(descriptor, completed)

        // La ruta QR se convierte en el mismo PVLA2 token que se escribe en el archivo.
        val fileToken = ProVentaActivationCode.encode(descriptor)
        val qrToken = ProVentaActivationCode.encode(completed!!)
        assertEquals(fileToken, qrToken)
        assertEquals(descriptor, ProVentaActivationCode.decode(qrToken))
    }

    @Test
    fun assemblerRejectsNonAuthorizationQrAndResetsBetweenDifferentSequences() {
        val assembler = DeviceAuthorizationQrAssembler()
        val invalid = runCatching { assembler.add("PCQ1|T|AUTHQR01|01/01|QUJD") }
        assertTrue("Un QR de transferencia no debe poder utilizarse como autorización", invalid.isFailure)

        val bytes = "x".repeat(60).toByteArray(StandardCharsets.UTF_8)
        val first = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes.copyOfRange(0, 40))
        val second = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes.copyOfRange(40, 60))
        assembler.add("PCQ1|D|AUTHQR01|01/02|$first")
        val next = assembler.add("PCQ1|D|AUTHQR02|01/01|$second")
        assertEquals(1, next.receivedFrames)
        assertEquals(1, next.totalFrames)
        assertEquals(String(bytes.copyOfRange(40, 60), StandardCharsets.UTF_8), next.completeDescriptor)
    }
}
