package com.proventa.app.data.sales

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class SaleDraftFactoryTest {
    private fun line(id: String, currency: String = "CUP") = SaleLineDraft(
        lineId = id,
        productId = "product-$id",
        productName = "Producto $id",
        unit = "ud",
        quantityMicros = 1_000_000,
        unitPriceMinor = 1_250,
        currency = currency,
        currencyScale = 2
    )

    @Test
    fun buildsMixedCurrencySaleWithSeparateLinePayments() {
        val bundle = SaleDraftFactory.create(
            saleId = "sale-1",
            posId = "pos-1",
            shiftId = "shift-1",
            idempotencyKey = "idem-1",
            status = SaleStatus.PENDING_SYNC,
            lines = listOf(line("cup"), line("usd", "USD")),
            paymentsByLine = mapOf(
                "cup" to listOf(
                    PaymentDraft("cash-1", PaymentMethod.CASH, 500, "CUP", 2),
                    PaymentDraft("transfer-1", PaymentMethod.TRANSFER, 750, "CUP", 2, "5551234", "OP-55")
                ),
                "usd" to listOf(
                    PaymentDraft("cash-2", PaymentMethod.CASH, 1_250, "USD", 2)
                )
            ),
            now = 100L
        )

        assertEquals(2, bundle.totals.size)
        assertEquals(1_250L, bundle.totals.first { it.currency == "CUP" }.amountMinor)
        assertEquals(3, bundle.payments.size)
    }

    @Test
    fun draftCanRemainPartiallyPaidButPendingSyncCannot() {
        val partial = SaleDraftFactory.create(
            "sale-draft", "pos", "shift", "idem-draft", SaleStatus.DRAFT,
            listOf(line("draft-line")),
            mapOf("draft-line" to listOf(PaymentDraft("p1", PaymentMethod.CASH, 100, "CUP", 2))),
            100L
        )
        assertEquals("DRAFT", partial.sale.status)

        assertThrows(IllegalArgumentException::class.java) {
            SaleDraftFactory.create(
                "sale-pending", "pos", "shift", "idem-pending", SaleStatus.PENDING_SYNC,
                listOf(line("pending-line")),
                mapOf("pending-line" to listOf(PaymentDraft("p2", PaymentMethod.CASH, 100, "CUP", 2))),
                100L
            )
        }
    }

    @Test
    fun preservesCustomCurrencyLabelForOtra() {
        val customLine = line("custom", "OTRA").copy(currencyLabel = "Moneda local")
        val bundle = SaleDraftFactory.create(
            "sale-custom", "pos", "shift", "idem-custom", SaleStatus.PENDING_SYNC,
            listOf(customLine),
            mapOf("custom" to listOf(PaymentDraft("custom-payment", PaymentMethod.CASH, 1_250, "OTRA", 2))),
            100L
        )
        assertEquals("Moneda local", bundle.lines.single().currencyLabel)
        assertEquals("Moneda local", bundle.totals.single().currencyLabel)
    }

    @Test
    fun transferRequiresPhoneAndOperationNumber() {
        assertThrows(IllegalArgumentException::class.java) {
            SaleDraftFactory.create(
                "sale-transfer", "pos", "shift", "idem-transfer", SaleStatus.DRAFT,
                listOf(line("transfer-line")),
                mapOf("transfer-line" to listOf(
                    PaymentDraft("p1", PaymentMethod.TRANSFER, 1_250, "CUP", 2)
                )),
                100L
            )
        }
    }
}
