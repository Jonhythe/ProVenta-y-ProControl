package com.proventa.app.data.receipts

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertThrows
import org.junit.Test

class GoodsReceiptWorkflowTest {
    @Test
    fun requiresOwnerConfirmationAndFinalAuthorizationBeforeInventoryCanBeConfirmed() {
        assertTrue(
            GoodsReceiptWorkflow.canTransition(
                ReceiptStatus.PENDING_REVIEW,
                ReceiptStatus.PENDING_OWNER_CONFIRMATION
            )
        )
        assertTrue(
            GoodsReceiptWorkflow.canTransition(
                ReceiptStatus.PENDING_OWNER_CONFIRMATION,
                ReceiptStatus.AWAITING_FINAL_ACK
            )
        )
        assertFalse(
            GoodsReceiptWorkflow.canTransition(
                ReceiptStatus.AWAITING_FINAL_ACK,
                ReceiptStatus.CONFIRMED
            )
        )
        assertTrue(
            GoodsReceiptWorkflow.canTransition(
                ReceiptStatus.AWAITING_FINAL_ACK,
                ReceiptStatus.CONFIRMED,
                finalAuthorizationValidated = true
            )
        )
    }

    @Test
    fun confirmedReceiptIsTerminal() {
        assertFalse(
            GoodsReceiptWorkflow.canTransition(
                ReceiptStatus.CONFIRMED,
                ReceiptStatus.PENDING_REVIEW
            )
        )
        assertThrows(IllegalArgumentException::class.java) {
            GoodsReceiptWorkflow.requireTransition(
                ReceiptStatus.AWAITING_FINAL_ACK,
                ReceiptStatus.CONFIRMED
            )
        }
    }
}
