package com.proventa.app.security

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.charset.StandardCharsets
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.time.Instant
import java.util.Base64
import java.util.UUID

class DeviceAuthorizationV6MonthlyAuthorizationTest {
    private val provider = org.bouncycastle.jce.provider.BouncyCastleProvider()

    @Test
    fun acceptsCurrentV6QrAndPreservesRenewalSequence() {
        val now = 1_750_000_000_000L
        val desktop = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val phone = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val document = descriptor(desktop, phone, now, now + 60_000, 2)

        val verified = DeviceAuthorizationDescriptorVerifier().verify(
            document.toString(),
            nowMillis = now,
            expectedDeviceId = document.getString("deviceId"),
            expectedDevicePublicKeyHash = document.getString("deviceSigningPublicKeyHash")
        )

        assertEquals(6, verified.version)
        assertEquals(2L, verified.renewalSequence)
        assertEquals(now + 60_000, verified.expiresAt)
        assertEquals(installationId(desktop), verified.installationId)
    }

    @Test
    fun rejectsExpiredOverlongAndUnsequencedV6QrCodes() {
        val now = 1_750_000_000_000L
        val desktop = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val phone = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val verifier = DeviceAuthorizationDescriptorVerifier()
        val expectedDeviceId = "device_${"b".repeat(32)}"
        val expectedKeyHash = sha256(phone.public.encoded)

        listOf(
            descriptor(desktop, phone, now - 60_000, now - 1, 1),
            descriptor(desktop, phone, now, now + 5 * 60_000 + 1, 1),
            descriptor(desktop, phone, now, now + 60_000, 0)
        ).forEach { invalid ->
            val result = runCatching {
                verifier.verify(
                    invalid.toString(), nowMillis = now,
                    expectedDeviceId = expectedDeviceId,
                    expectedDevicePublicKeyHash = expectedKeyHash
                )
            }
            assertTrue(result.isFailure)
        }
    }

    private fun descriptor(
        desktop: KeyPair,
        phone: KeyPair,
        createdAt: Long,
        expiresAt: Long,
        renewalSequence: Long
    ): JSONObject {
        val installationId = installationId(desktop)
        val short = installationId.removePrefix("pcinst_").take(16).uppercase()
        val document = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 6)
            .put("permanent", true)
            .put("installationId", installationId)
            .put("installationCode", "PC-${short.substring(0, 4)}-${short.substring(4, 8)}-${short.substring(8, 12)}-${short.substring(12, 16)}")
            .put("authorizationId", "auth_${UUID.randomUUID()}")
            .put("deviceId", "device_${"b".repeat(32)}")
            .put("deviceSigningPublicKeyHash", sha256(phone.public.encoded))
            .put("authorizationScope", "installation")
            .put("employeeName", "Dependiente V6")
            .put("code", "12345678")
            .put("expiresAt", expiresAt)
            .put("renewalSequence", renewalSequence)
            .put("createdAt", Instant.ofEpochMilli(createdAt).toString())
            .put("desktopPublicKey", pem(desktop))

        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(desktop.private)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put("signature", JSONObject()
            .put("algorithm", "Ed25519")
            .put("value", Base64.getEncoder().encodeToString(signer.sign())))
        return document
    }

    private fun installationId(desktop: KeyPair): String =
        "pcinst_${sha256(desktop.public.encoded).take(32)}"

    private fun pem(keyPair: KeyPair): String =
        "-----BEGIN PUBLIC KEY-----\n" +
            Base64.getEncoder().encodeToString(keyPair.public.encoded).chunked(64).joinToString("\n") +
            "\n-----END PUBLIC KEY-----\n"

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
