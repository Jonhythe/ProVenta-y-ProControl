package com.proventa.app.security

import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.time.Instant
import java.util.Base64
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.Security
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import java.security.spec.MGF1ParameterSpec
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.spec.SecretKeySpec

class DeviceBoundActivationTest {
    private val provider = BouncyCastleProvider()

    @Test
    fun permanentActivationIsSignedAndAcceptedOnlyByTheTargetPhone() {
        val desktopKeys = ed25519()
        val phoneKeys = ed25519()
        val deviceId = "device_phone_12345678"
        val now = System.currentTimeMillis()
        val desktopPem = pem(desktopKeys.public.encoded)
        val installationId = "pcinst_" + sha256(desktopKeys.public.encoded).take(32)
        val publicKeyHash = sha256(phoneKeys.public.encoded)
        val descriptor = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 2)
            .put("permanent", true)
            .put("installationId", installationId)
            .put("authorizationId", "auth_12345678-1234-1234-1234-123456789012")
            .put("desktopId", "desktop-test")
            .put("employeeName", "Trabajador Prueba")
            .put("code", "123456")
            .put("expiresAt", now - 60_000L)
            .put("deviceId", deviceId)
            .put("devicePublicKeyHash", publicKeyHash)
            .put("desktopPublicKey", desktopPem)
            .put("createdAt", Instant.ofEpochMilli(now).toString())

        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(desktopKeys.private)
        signer.update(CanonicalJson.stringify(descriptor).toByteArray(Charsets.UTF_8))
        descriptor.put(
            "signature",
            JSONObject().put("algorithm", "Ed25519")
                .put("value", Base64.getEncoder().encodeToString(signer.sign()))
        )
        val json = descriptor.toString()
        val activationCode = ProVentaActivationCode.encode(json)
        assertTrue(activationCode.startsWith("PVLA2:"))

        assertEquals(json, ProVentaActivationCode.decode(activationCode))
        val groupedForMonitor = activationCode.removePrefix("PVLA2:")
            .chunked(8).joinToString(" ")
        val recognizedPhotoText = """
            CODIGO DE ACTIVACION PROVENTA
            PVLA2
            $groupedForMonitor
            FIN DEL CODIGO
        """.trimIndent()
        val codeReadFromPhoto = ProVentaActivationCode.extractFromRecognizedText(recognizedPhotoText)
        assertEquals(activationCode, codeReadFromPhoto)
        assertEquals(json, ProVentaActivationCode.decode(codeReadFromPhoto!!))

        val last = activationCode.last()
        val damaged = activationCode.dropLast(1) + if (last == '0') '1' else '0'
        assertTrue("A damaged photo must fail the checksum", runCatching {
            ProVentaActivationCode.decode(damaged)
        }.isFailure)
        val verifier = DeviceAuthorizationDescriptorVerifier()
        val verified = verifier.verify(
            rawJson = json,
            expectedDeviceId = deviceId,
            expectedDevicePublicKeyHash = publicKeyHash
        )
        assertEquals(deviceId, verified.deviceId)
        assertTrue(verified.permanent)
        assertEquals("Trabajador Prueba", verified.employeeName)

        assertTrue(runCatching {
            verifier.verify(
                rawJson = json,
                expectedDeviceId = "device_another_phone",
                expectedDevicePublicKeyHash = publicKeyHash
            )
        }.isFailure)
        assertTrue(runCatching {
            verifier.verify(
                rawJson = json,
                expectedDeviceId = deviceId,
                expectedDevicePublicKeyHash = "0".repeat(64)
            )
        }.isFailure)
    }

    @Test
    fun decryptsTheExactProControlV4DeviceLinkEnvelopeAndEightDigitPin() {
        if (Security.getProvider(provider.name) == null) Security.addProvider(provider)
        val desktopKeys = ed25519()
        val phoneSigningKeys = ed25519()
        val phoneEncryptionKeys = KeyPairGenerator.getInstance("RSA", provider).apply {
            initialize(3072)
        }.generateKeyPair()
        val deviceId = "device_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
        val authorizationId = "auth_87654321-1234-1234-1234-123456789012"
        val now = System.currentTimeMillis()
        val createdAt = Instant.ofEpochMilli(now).toString()
        val desktopPem = pem(desktopKeys.public.encoded)
        val phoneHash = sha256(phoneSigningKeys.public.encoded)
        val installationId = "pcinst_" + sha256(desktopKeys.public.encoded).take(32)
        val installationCode = installationCode(installationId)
        val posId = "pos_worker_01"
        val descriptor = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 4)
            .put("permanent", true)
            .put("installationId", installationId)
            .put("installationCode", installationCode)
            .put("authorizedPosId", posId)
            .put("authorizationId", authorizationId)
            .put("employeeName", "Dependiente PVLINK")
            .put("code", "04281736")
            .put("expiresAt", now + 5 * 60 * 1000L)
            .put("deviceId", deviceId)
            .put("deviceSigningPublicKeyHash", phoneHash)
            .put("desktopPublicKey", desktopPem)
            .put("createdAt", createdAt)
        val descriptorSigner = Signature.getInstance("Ed25519", provider)
        descriptorSigner.initSign(desktopKeys.private)
        descriptorSigner.update(CanonicalJson.stringify(descriptor).toByteArray(StandardCharsets.UTF_8))
        descriptor.put(
            "signature",
            JSONObject().put("algorithm", "Ed25519")
                .put("value", Base64.getEncoder().encodeToString(descriptorSigner.sign()))
        )
        val rawJson = CanonicalJson.stringify(descriptor)
        val plaintext = rawJson.toByteArray(StandardCharsets.UTF_8)
        val payloadHash = sha256(plaintext)

        // This mirrors ProControl mobile-bridge/store.js::_createV4DeviceLink:
        // canonical header AAD, nested encryption metadata, separate GCM tag,
        // payload hash, signerPublicKey and a second Ed25519 signature over the envelope.
        val header = JSONObject()
            .put("format", "procontrol.device-link")
            .put("version", 1)
            .put("algorithm", "RSA-OAEP-256+A256GCM")
            .put("installationId", installationId)
            .put("installationCode", installationCode)
            .put("authorizationId", authorizationId)
            .put("deviceId", deviceId)
            .put("authorizedPosId", posId)
            .put("createdAt", createdAt)
            .put("expiresAt", now + 5 * 60 * 1000L)
            .put("payloadHash", payloadHash)
            .put("signerPublicKey", desktopPem)
        val dataKey = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val aes = Cipher.getInstance("AES/GCM/NoPadding")
        aes.init(Cipher.ENCRYPT_MODE, SecretKeySpec(dataKey, "AES"), GCMParameterSpec(128, iv))
        aes.updateAAD(CanonicalJson.stringify(header).toByteArray(StandardCharsets.UTF_8))
        val combined = aes.doFinal(plaintext)
        val rsa = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", provider)
        rsa.init(
            Cipher.ENCRYPT_MODE,
            phoneEncryptionKeys.public,
            OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT)
        )
        val wrappedKey = rsa.doFinal(dataKey)
        dataKey.fill(0)
        plaintext.fill(0)

        val envelope = JSONObject(header.toString())
            .put("encryption", JSONObject()
                .put("keyWrap", "RSA-OAEP-SHA256")
                .put("contentCipher", "AES-256-GCM")
                .put("wrappedKey", Base64.getEncoder().encodeToString(wrappedKey))
                .put("iv", Base64.getEncoder().encodeToString(iv))
                .put("tag", Base64.getEncoder().encodeToString(combined.copyOfRange(combined.size - 16, combined.size))))
            .put("ciphertext", Base64.getEncoder().encodeToString(combined.copyOfRange(0, combined.size - 16)))
        val envelopeSigner = Signature.getInstance("Ed25519", provider)
        envelopeSigner.initSign(desktopKeys.private)
        envelopeSigner.update(CanonicalJson.stringify(envelope).toByteArray(StandardCharsets.UTF_8))
        envelope.put("signature", JSONObject()
            .put("algorithm", "Ed25519")
            .put("value", Base64.getEncoder().encodeToString(envelopeSigner.sign())))

        val (openedJson, openedAuthorizationId) = DeviceActivationEnvelope.decrypt(
            envelopeJson = envelope.toString(),
            encryptionPrivateKey = phoneEncryptionKeys.private,
            expectedDeviceId = deviceId
        )
        assertEquals(rawJson, CanonicalJson.stringify(JSONObject(openedJson)))
        assertEquals(authorizationId, openedAuthorizationId)

        val verified = DeviceAuthorizationDescriptorVerifier().verify(
            rawJson = openedJson,
            expectedDeviceId = deviceId,
            expectedDevicePublicKeyHash = phoneHash
        )
        assertEquals("04281736", verified.code)
        assertEquals(4, JSONObject(verified.rawJson).optInt("version"))
        assertEquals(installationCode, verified.installationCode)
        assertEquals(posId, verified.authorizedPosId)
        assertEquals(phoneHash, verified.deviceSigningPublicKeyHash)
        // ProControl v4 intentionally omits the legacy desktopId field.
        assertEquals(installationId, verified.desktopId)
        assertTrue(verified.permanent)

        assertTrue(runCatching {
            DeviceActivationEnvelope.decrypt(envelope.toString(), phoneEncryptionKeys.private, "device_cccccccccccccccccccccccccccccccc")
        }.isFailure)
        val wrongPhoneKeys = KeyPairGenerator.getInstance("RSA", provider).apply {
            initialize(3072)
        }.generateKeyPair()
        assertTrue(runCatching {
            DeviceActivationEnvelope.decrypt(envelope.toString(), wrongPhoneKeys.private, deviceId)
        }.isFailure)
        val damagedEncryption = JSONObject(envelope.toString())
            .put("encryption", JSONObject(envelope.getJSONObject("encryption").toString())
                .put("tag", Base64.getEncoder().encodeToString(ByteArray(16))))
        assertTrue(runCatching {
            DeviceActivationEnvelope.decrypt(damagedEncryption.toString(), phoneEncryptionKeys.private, deviceId)
        }.isFailure)
        val damagedOuterSignature = JSONObject(envelope.toString())
            .put("signerPublicKey", pem(ed25519().public.encoded))
        assertTrue(runCatching {
            DeviceActivationEnvelope.decrypt(damagedOuterSignature.toString(), phoneEncryptionKeys.private, deviceId)
        }.isFailure)
    }

    @Test
    fun rejectsPlainNumbersAndMalformedActivationCodes() {
        assertTrue(runCatching { ProVentaActivationCode.decode("123456") }.isFailure)
        assertTrue(runCatching { ProVentaActivationCode.decode("PVLA2:not-a-valid-code!") }.isFailure)
    }

    private fun installationCode(installationId: String): String {
        val hex = installationId.removePrefix("pcinst_").take(16).uppercase()
        return "PC-${hex.substring(0, 4)}-${hex.substring(4, 8)}-${hex.substring(8, 12)}-${hex.substring(12, 16)}"
    }

    private fun ed25519(): KeyPair {
        if (Security.getProvider(provider.name) == null) Security.addProvider(provider)
        return KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
    }

    private fun pem(der: ByteArray): String {
        val body = Base64.getEncoder().encodeToString(der).chunked(64).joinToString("\n")
        return "-----BEGIN PUBLIC KEY-----\n$body\n-----END PUBLIC KEY-----\n"
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
}
