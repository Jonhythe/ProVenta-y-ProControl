package com.proventa.app.security

import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.time.Instant
import java.util.Base64
import java.util.UUID
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class DeviceV4SignedKeyBindingTest {
    @Test
    fun acceptsIdReconciliationOnlyWhenSignedPhoneKeyMatches() {
        val provider = BouncyCastleProvider()
        val desktopPair = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val phonePair = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val desktopPem = toPem(desktopPair.public.encoded)
        val phoneHash = sha256(phonePair.public.encoded)
        val desktopHash = sha256(desktopPair.public.encoded)
        val installationId = "pcinst_${desktopHash.take(32)}"
        val short = desktopHash.take(16).uppercase()
        val installationCode = "PC-${short.substring(0, 4)}-${short.substring(4, 8)}-${short.substring(8, 12)}-${short.substring(12, 16)}"
        val authorizedDeviceId = "device_${"a".repeat(32)}"
        val currentLocalDeviceId = "device_${"b".repeat(32)}"
        val now = System.currentTimeMillis()
        val document = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 4)
            .put("permanent", true)
            .put("installationId", installationId)
            .put("installationCode", installationCode)
            .put("authorizationId", "auth_${UUID.randomUUID()}")
            .put("deviceId", authorizedDeviceId)
            .put("deviceSigningPublicKeyHash", phoneHash)
            .put("authorizedPosId", "pos_test_01")
            .put("authorizedPosName", "POS de prueba")
            .put("employeeName", "Dependiente de prueba")
            .put("code", "12345678")
            .put("expiresAt", now + 600_000L)
            .put("createdAt", Instant.ofEpochMilli(now).toString())
            .put("desktopPublicKey", desktopPem)
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(desktopPair.private)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put("signature", JSONObject()
            .put("algorithm", "Ed25519")
            .put("value", Base64.getEncoder().encodeToString(signer.sign())))

        val verified = DeviceAuthorizationDescriptorVerifier().verify(
            rawJson = document.toString(),
            nowMillis = now,
            expectedDeviceId = currentLocalDeviceId,
            expectedDevicePublicKeyHash = phoneHash
        )

        // The signer-authorized device ID is returned for the caller to persist
        // only after DeviceKeyManager proves the same Ed25519 private key exists.
        assertEquals(authorizedDeviceId, verified.deviceId)
    }

    @Test
    fun rejectsAValidlySignedAuthorizationWhenPhoneKeyFingerprintIsDifferent() {
        val provider = BouncyCastleProvider()
        val desktopPair = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val enrolledPhonePair = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val currentPhonePair = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val desktopHash = sha256(desktopPair.public.encoded)
        val installationId = "pcinst_${desktopHash.take(32)}"
        val short = desktopHash.take(16).uppercase()
        val installationCode = "PC-${short.substring(0, 4)}-${short.substring(4, 8)}-${short.substring(8, 12)}-${short.substring(12, 16)}"
        val deviceId = "device_${"c".repeat(32)}"
        val now = System.currentTimeMillis()
        val document = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 4)
            .put("permanent", true)
            .put("installationId", installationId)
            .put("installationCode", installationCode)
            .put("authorizationId", "auth_${UUID.randomUUID()}")
            .put("deviceId", deviceId)
            .put("deviceSigningPublicKeyHash", sha256(enrolledPhonePair.public.encoded))
            .put("authorizedPosId", "pos_test_01")
            .put("employeeName", "Dependiente de prueba")
            .put("code", "12345678")
            .put("expiresAt", now + 600_000L)
            .put("createdAt", Instant.ofEpochMilli(now).toString())
            .put("desktopPublicKey", toPem(desktopPair.public.encoded))
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(desktopPair.private)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put("signature", JSONObject()
            .put("algorithm", "Ed25519")
            .put("value", Base64.getEncoder().encodeToString(signer.sign())))

        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationDescriptorVerifier().verify(
                rawJson = document.toString(),
                nowMillis = now,
                expectedDeviceId = deviceId,
                expectedDevicePublicKeyHash = sha256(currentPhonePair.public.encoded)
            )
        }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }

    private fun toPem(der: ByteArray): String =
        "-----BEGIN PUBLIC KEY-----\n" +
            Base64.getEncoder().encodeToString(der).chunked(64).joinToString("\n") +
            "\n-----END PUBLIC KEY-----\n"
}
