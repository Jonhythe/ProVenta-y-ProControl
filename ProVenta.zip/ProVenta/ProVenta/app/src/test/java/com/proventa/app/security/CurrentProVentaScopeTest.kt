package com.proventa.app.security

import org.junit.Assert.assertThrows
import org.junit.Test

class CurrentProVentaScopeTest {
    private val scope = CurrentProVentaScope(
        installationId = "pcinst_a",
        authorizationId = "auth_current",
        posId = "pos_current",
        deviceId = "device_current",
        employeeName = "Dependiente"
    )

    @Test
    fun acceptsOnlyTheAuthorizedPos() {
        scope.requirePos("pos_current")
        assertThrows(IllegalArgumentException::class.java) {
            scope.requirePos("pos_other")
        }
    }

    @Test
    fun rejectsPermitFromAnotherInstallationAuthorizationPosOrDevice() {
        scope.requirePermitScope("pcinst_a", "auth_current", "pos_current", "device_current")
        assertThrows(IllegalArgumentException::class.java) {
            scope.requirePermitScope("pcinst_other", "auth_current", "pos_current", "device_current")
        }
        assertThrows(IllegalArgumentException::class.java) {
            scope.requirePermitScope("pcinst_a", "auth_old", "pos_current", "device_current")
        }
        assertThrows(IllegalArgumentException::class.java) {
            scope.requirePermitScope("pcinst_a", "auth_current", "pos_other", "device_current")
        }
        assertThrows(IllegalArgumentException::class.java) {
            scope.requirePermitScope("pcinst_a", "auth_current", "pos_current", "device_other")
        }
    }
}
