package com.proventa.app.data.money

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class MoneyMathTest {
    @Test
    fun calculatesFractionalQuantityWithoutFloatingPoint() {
        assertEquals(375L, MoneyMath.lineTotalMinor(250L, 1_500_000L))
    }

    @Test
    fun roundsHalfUpAtOneMinorUnit() {
        assertEquals(1L, MoneyMath.lineTotalMinor(1L, 500_000L))
        assertEquals(0L, MoneyMath.lineTotalMinor(1L, 499_999L))
    }

    @Test
    fun rejectsNegativeInputsAndOverflow() {
        assertThrows(IllegalArgumentException::class.java) {
            MoneyMath.lineTotalMinor(-1L, 1_000_000L)
        }
        assertThrows(ArithmeticException::class.java) {
            MoneyMath.lineTotalMinor(Long.MAX_VALUE, Long.MAX_VALUE)
        }
    }

    @Test
    fun convertsSnapshotDecimalsToExactMinorUnitsAndMicros() {
        assertEquals(10_025L, MoneyMath.decimalToMinorUnits(100.25))
        assertEquals(12_500_000L, MoneyMath.decimalToMicros(12.5))
        assertEquals(825, MoneyMath.percentToBasisPoints(8.25))
    }

    @Test
    fun rejectsUnsupportedPrecisionAndNegativeSnapshotValues() {
        assertThrows(ArithmeticException::class.java) {
            MoneyMath.decimalToMinorUnits(1.005)
        }
        assertThrows(IllegalArgumentException::class.java) {
            MoneyMath.decimalToMicros(-1)
        }
    }

    @Test
    fun sumsMinorAmountsWithOverflowProtection() {
        assertEquals(300L, MoneyMath.sumMinorAmounts(listOf(100L, 200L)))
        assertThrows(ArithmeticException::class.java) {
            MoneyMath.sumMinorAmounts(listOf(Long.MAX_VALUE, 1L))
        }
    }
}
