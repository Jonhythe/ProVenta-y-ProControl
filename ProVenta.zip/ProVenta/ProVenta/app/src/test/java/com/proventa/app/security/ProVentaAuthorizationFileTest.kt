package com.proventa.app.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ProVentaAuthorizationFileTest {
    private val validCode = "PVLA2:" + "A".repeat(128)

    @Test
    fun decodesOfficialAuthorizationFile() {
        val decoded = ProVentaAuthorizationFile.decode(
            "ProVenta Codigo.pvla2",
            (validCode + "\n").toByteArray(Charsets.UTF_8)
        )
        assertEquals(validCode, decoded)
    }

    @Test
    fun acceptsIncrementedFilenameWithoutOverwritingOldExports() {
        val decoded = ProVentaAuthorizationFile.decode(
            "ProVenta Codigo (2).pvla2",
            validCode.toByteArray(Charsets.UTF_8)
        )
        assertEquals(validCode, decoded)
    }

    @Test
    fun rejectsOtherFilesAndOversizedDocuments() {
        assertThrows(IllegalArgumentException::class.java) {
            ProVentaAuthorizationFile.decode("otro-archivo.txt", validCode.toByteArray(Charsets.UTF_8))
        }
        assertThrows(IllegalArgumentException::class.java) {
            ProVentaAuthorizationFile.decode("ProVenta Codigo.pvla2", ByteArray(64 * 1024 + 1))
        }
    }

    @Test
    fun rejectsWrongPayload() {
        assertThrows(IllegalArgumentException::class.java) {
            ProVentaAuthorizationFile.decode("ProVenta Codigo.pvla2", "PIN=1234".toByteArray(Charsets.UTF_8))
        }
    }
}
