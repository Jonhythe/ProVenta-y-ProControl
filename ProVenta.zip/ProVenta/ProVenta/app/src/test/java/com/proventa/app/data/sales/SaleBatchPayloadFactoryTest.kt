package com.proventa.app.data.sales

import com.proventa.app.data.entities.SaleEntity
import com.proventa.app.data.entities.SaleLineEntity
import com.proventa.app.data.entities.SalePaymentEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class SaleBatchPayloadFactoryTest {
    private fun sale(id: String = "sale-test") = SaleEntity(
        saleId = id,
        posId = "pos_test_01",
        shiftId = "shift_test_01",
        status = "PENDING_SYNC",
        createdAt = 1_800_000_000_000L,
        updatedAt = 1_800_000_000_000L,
        idempotencyKey = "idem-" + id
    )

    private fun line(
        id: String,
        currency: String = "CUP",
        priceMinor: Long = 250,
        totalMinor: Long = 500,
        quantityMicros: Long = 2_000_000L
    ) = SaleLineEntity(
        lineId = id,
        saleId = "sale-test",
        productId = "product-" + id,
        productNameSnapshot = "Producto " + id,
        unitSnapshot = "lb",
        quantityMicros = quantityMicros,
        unitPriceMinor = priceMinor,
        lineTotalMinor = totalMinor,
        currency = currency,
        currencyLabel = null,
        currencyScale = 2
    )

    private fun payment(
        lineId: String,
        method: String = "CASH",
        amountMinor: Long = 500,
        phone: String? = null,
        operation: String? = null
    ) = SalePaymentEntity(
        paymentId = "payment-" + lineId,
        saleLineId = lineId,
        method = method,
        amountMinor = amountMinor,
        currency = if (lineId == "usd-line") "USD" else "CUP",
        currencyScale = 2,
        transferPhone = phone,
        transferOperationNumber = operation,
        evidenceUri = null
    )

    @Test
    fun createsProControlCompatibleCupCashTicketWithoutBoxPresentation() {
        val payload = SaleBatchPayloadFactory.create(
            sale(),
            listOf(line("cup-line")),
            listOf(payment("cup-line")),
            "Punto A",
            "Operador",
            "permit-test-01",
            null
        )
        val transaction = payload.getJSONArray("transactions").getJSONObject(0)
        val item = transaction.getJSONArray("items").getJSONObject(0)

        assertEquals(1, payload.getJSONArray("transactions").length())
        assertEquals(1, SaleBatchPayloadFactory.countDesktopTickets(
            listOf(line("cup-line")),
            listOf(payment("cup-line"))
        ))
        assertEquals("sale-test_cup_cash", transaction.getString("id"))
        assertEquals("sale-test_cup_cash", transaction.getString("idempotencyKey"))
        assertEquals("permit-test-01", transaction.getString("shiftPermitId"))
        assertEquals("cash", transaction.getString("paymentMethod"))
        assertEquals("CUP", transaction.getString("currency"))
        assertEquals(5.0, transaction.getDouble("totalNative"), 0.000001)
        assertEquals(5.0, transaction.getDouble("totalCUP"), 0.000001)
        assertEquals("unit", item.getString("presentation"))
        assertEquals("lb", item.getString("baseUnit"))
        assertEquals(2.0, item.getDouble("baseQty"), 0.000001)
    }

    @Test
    fun splitsMixedPaymentMethodsAndUsdIntoLinkedLedgerTickets() {
        val cupLine = line("cup-line")
        val transferLine = line("transfer-line")
        val usdLine = line("usd-line", "USD", 150, 300)
        val payload = SaleBatchPayloadFactory.create(
            sale(),
            listOf(cupLine, transferLine, usdLine),
            listOf(
                payment("cup-line"),
                payment("transfer-line", "TRANSFER", 500, "55512345", "OP-100"),
                payment("usd-line", "CASH", 300)
            ),
            "Punto A",
            "Operador",
            "permit-test-02",
            410_000_000L
        )
        val transactions = payload.getJSONArray("transactions")
        assertEquals(3, transactions.length())
        assertEquals(
            3,
            SaleBatchPayloadFactory.countDesktopTickets(
                listOf(cupLine, transferLine, usdLine),
                listOf(
                    payment("cup-line"),
                    payment("transfer-line", "TRANSFER", 500, "55512345", "OP-100"),
                    payment("usd-line", "CASH", 300)
                )
            )
        )

        val methods = (0 until transactions.length()).map {
            transactions.getJSONObject(it).getString("paymentMethod")
        }.toSet()
        assertEquals(setOf("cash", "transfer", "usd"), methods)

        val usd = (0 until transactions.length())
            .map { transactions.getJSONObject(it) }
            .single { it.getString("currency") == "USD" }
        assertEquals(3.0, usd.getDouble("totalNative"), 0.000001)
        assertEquals(1230.0, usd.getDouble("totalCUP"), 0.000001)
        assertEquals("sale-test", usd.getString("mobileOrderId"))

        val transfer = (0 until transactions.length())
            .map { transactions.getJSONObject(it) }
            .single { it.getString("paymentMethod") == "transfer" }
        val transferItem = transfer.getJSONArray("items").getJSONObject(0)
        assertEquals("55512345", transferItem.getString("transferPhone"))
        assertEquals("OP-100", transferItem.getString("transferOperationNumber"))
    }

    @Test
    fun rejectsCurrenciesWithoutAnApprovedDesktopConversionRate() {
        val euroLine = line("euro-line", "EUR")
        val euroPayment = payment("euro-line").copy(currency = "EUR")
        assertThrows(UnsupportedOperationException::class.java) {
            SaleBatchPayloadFactory.create(
                sale(),
                listOf(euroLine),
                listOf(euroPayment),
                "Punto A",
                "Operador",
                "permit-test-03",
                410_000_000L
            )
        }
    }

    @Test
    fun rejectsSplitPaymentsForOneLineUntilDesktopSupportsLinePaymentBreakdown() {
        val row = line("cup-line")
        val payments = listOf(
            payment("cup-line", "CASH", 250),
            payment("cup-line", "TRANSFER", 250, "55512345", "OP-101")
        )
        assertThrows(UnsupportedOperationException::class.java) {
            SaleBatchPayloadFactory.create(
                sale(),
                listOf(row),
                payments,
                "Punto A",
                "Operador",
                "permit-test-04",
                null
            )
        }
    }
}
