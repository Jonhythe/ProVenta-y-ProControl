package com.proventa.app.security

import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.time.Instant
import java.util.Base64

class DeviceAuthorizationV5InstallationScopeTest {
    private val provider = BouncyCastleProvider()

    @Test
    fun acceptsSignedV5InstallationAuthorizationWithoutPermanentPos() {
        val desktop = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val phone = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val desktopHash = sha256(desktop.public.encoded)
        val phoneHash = sha256(phone.public.encoded)
        val installationId = "pcinst_${desktopHash.take(32)}"
        val installationCode = installationCode(installationId)
        val deviceId = "device_${"a".repeat(32)}"
        val now = System.currentTimeMillis()
        val document = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 5)
            .put("permanent", true)
            .put("authorizationScope", "installation")
            .put("installationId", installationId)
            .put("installationCode", installationCode)
            .put("authorizationId", "auth_${java.util.UUID.randomUUID()}")
            .put("deviceId", deviceId)
            .put("deviceSigningPublicKeyHash", phoneHash)
            .put("employeeName", "Dependiente V5")
            .put("code", "12345678")
            .put("expiresAt", now - 60_000L)
            .put("createdAt", Instant.ofEpochMilli(now).toString())
            .put("desktopPublicKey", pem(desktop.public.encoded))
        sign(document, desktop.private)

        val activationCode = ProVentaActivationCode.encode(document.toString())
        assertEquals(document.toString(), ProVentaActivationCode.decode(activationCode))
        assertEquals(document.toString(), ProVentaOneTimeCode.descriptorFromQrPayload(document.toString()))

        val verified = DeviceAuthorizationDescriptorVerifier().verify(
            rawJson = document.toString(),
            expectedDeviceId = deviceId,
            expectedDevicePublicKeyHash = phoneHash
        )
        assertEquals(5, verified.version)
        assertEquals(installationId, verified.installationId)
        assertEquals(installationCode, verified.installationCode)
        assertEquals(deviceId, verified.deviceId)
        assertEquals("Dependiente V5", verified.employeeName)
        assertNull(verified.authorizedPosId)
        assertTrue(verified.permanent)
    }

    @Test
    fun rejectsV5AuthorizationThatPinsAPosOrUsesWrongScope() {
        val desktop = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val phone = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val desktopHash = sha256(desktop.public.encoded)
        val phoneHash = sha256(phone.public.encoded)
        val installationId = "pcinst_${desktopHash.take(32)}"
        val deviceId = "device_${"b".repeat(32)}"
        val now = System.currentTimeMillis()
        val base = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 5)
            .put("permanent", true)
            .put("authorizationScope", "installation")
            .put("installationId", installationId)
            .put("installationCode", installationCode(installationId))
            .put("authorizationId", "auth_${java.util.UUID.randomUUID()}")
            .put("deviceId", deviceId)
            .put("deviceSigningPublicKeyHash", phoneHash)
            .put("employeeName", "Dependiente V5")
            .put("code", "87654321")
            .put("expiresAt", now - 1_000L)
            .put("createdAt", Instant.ofEpochMilli(now).toString())
            .put("desktopPublicKey", pem(desktop.public.encoded))

        val pinnedPos = JSONObject(base.toString()).put("authorizedPosId", "pos_fixed")
        sign(pinnedPos, desktop.private)
        assertTrue(runCatching {
            DeviceAuthorizationDescriptorVerifier().verify(
                pinnedPos.toString(), expectedDeviceId = deviceId,
                expectedDevicePublicKeyHash = phoneHash
            )
        }.isFailure)

        val wrongScope = JSONObject(base.toString()).put("authorizationScope", "pos")
        sign(wrongScope, desktop.private)
        assertTrue(runCatching {
            DeviceAuthorizationDescriptorVerifier().verify(
                wrongScope.toString(), expectedDeviceId = deviceId,
                expectedDevicePublicKeyHash = phoneHash
            )
        }.isFailure)

        assertTrue(runCatching {
            DeviceAuthorizationDescriptorVerifier().verify(
                base.toString(), expectedDeviceId = deviceId,
                expectedDevicePublicKeyHash = "0".repeat(64)
            )
        }.isFailure)
    }

    private fun sign(document: JSONObject, privateKey: java.security.PrivateKey) {
        document.remove("signature")
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(privateKey)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put("signature", JSONObject()
            .put("algorithm", "Ed25519")
            .put("value", Base64.getEncoder().encodeToString(signer.sign())))
    }

    private fun installationCode(installationId: String): String {
        val hex = installationId.removePrefix("pcinst_").take(16).uppercase()
        return "PC-${hex.substring(0, 4)}-${hex.substring(4, 8)}-${hex.substring(8, 12)}-${hex.substring(12, 16)}"
    }

    private fun pem(der: ByteArray): String =
        "-----BEGIN PUBLIC KEY-----\n" + Base64.getEncoder().encodeToString(der).chunked(64).joinToString("\n") +
            "\n-----END PUBLIC KEY-----\n"

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
