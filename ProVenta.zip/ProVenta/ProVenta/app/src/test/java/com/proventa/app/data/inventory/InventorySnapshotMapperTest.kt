package com.proventa.app.data.inventory

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class InventorySnapshotMapperTest {
    private val hash = "a".repeat(64)

    @Test
    fun mapsCupAndForeignPricesWithoutLosingTransferRulesOrAliases() {
        val payload = """
            {
              "schema":"proventa.inventory-snapshot",
              "schemaVersion":1,
              "installationId":"pcinst_0123456789abcdef0123456789abcdef",
              "posId":"pos_01",
              "generatedAt":"2026-11-08T12:00:00.000Z",
              "exchangeRates":{"USD_CUP":410},
              "catalog":[{"productId":"rice_01","name":"Arroz","unit":"lb","family":"granos","aliases":["arroz blanco","arroz"]}],
              "inventory":[{
                "productId":"rice_01","name":"Arroz","unit":"lb","family":"granos","qty":12.5,
                "sale":100,"saleTransf":108,"saleTransfMode":"percentage","saleTransfPercent":8,
                "saleUSD":1.5,"saleCurrency":"USD"
              }]
            }
        """.trimIndent()

        val product = InventorySnapshotMapper.map(payload, hash).single()
        assertEquals("pos_01", product.posId)
        assertEquals(10_000L, product.cupCashPriceMinor)
        assertEquals(10_800L, product.cupTransferPriceMinor)
        assertEquals(800, product.transferPercentBasisPoints)
        assertEquals(150L, product.foreignPriceMinor)
        assertEquals("USD", product.foreignCurrency)
        assertEquals(12_500_000L, product.availableQuantityMicros)
        assertEquals(410_000_000L, InventorySnapshotMapper.usdCupRateMicros(payload))
        assertEquals(hash, product.catalogRevision)
        assertEquals("[\"arroz blanco\",\"arroz\"]", product.catalogAliasesJson)
    }

    @Test
    fun preservesOnlyPositiveCurrencyConversionRatesFromDesktopSnapshot() {
        val payload = """
            {
              "schema":"proventa.inventory-snapshot","schemaVersion":1,
              "installationId":"pcinst_0123456789abcdef0123456789abcdef",
              "posId":"pos_01","generatedAt":"2026-11-08T12:00:00.000Z",
              "exchangeRates":{"USD_CUP":410,"EUR_CUP":450,"INVALID_CUP":0,"MALFORMED":"x"},
              "catalog":[],
              "inventory":[]
            }
        """.trimIndent()
        val rates = org.json.JSONObject(InventorySnapshotMapper.exchangeRatesJson(payload))
        assertEquals(410.0, rates.getDouble("USD_CUP"), 0.0)
        assertEquals(450.0, rates.getDouble("EUR_CUP"), 0.0)
        assertEquals(false, rates.has("INVALID_CUP"))
        assertEquals(false, rates.has("MALFORMED"))
    }

    @Test
    fun rejectsPricesOrQuantitiesWithUnsupportedPrecision() {
        val payload = """
            {
              "schema":"proventa.inventory-snapshot","schemaVersion":1,
              "installationId":"pcinst_0123456789abcdef0123456789abcdef",
              "posId":"pos_01","generatedAt":"2026-11-08T12:00:00.000Z",
              "catalog":[],
              "inventory":[{"productId":"p1","name":"Producto","unit":"ud","qty":1,"sale":1.005}]
            }
        """.trimIndent()
        assertThrows(ArithmeticException::class.java) {
            InventorySnapshotMapper.map(payload, hash)
        }
    }

    @Test
    fun requiresCustomCurrencyNameForOtra() {
        val payload = """
            {
              "schema":"proventa.inventory-snapshot","schemaVersion":1,
              "installationId":"pcinst_0123456789abcdef0123456789abcdef",
              "posId":"pos_01","generatedAt":"2026-11-08T12:00:00.000Z",
              "catalog":[],
              "inventory":[{"productId":"p1","name":"Producto","unit":"ud","qty":1,"saleUSD":1,"saleCurrency":"OTRA"}]
            }
        """.trimIndent()
        assertThrows(IllegalArgumentException::class.java) {
            InventorySnapshotMapper.map(payload, hash)
        }
    }
}
