package com.proventa.app.ui.screens

import java.nio.ByteBuffer
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CameraLumaPlaneCompatibilityTest {
    @Test
    fun acceptsHighResolutionSamsungStyleAnalysisFramesAndBoundsMemory() {
        // 4032x3024 is a common full-resolution 12MP camera stream. CameraX may
        // still deliver this despite a 1280x720 target-resolution request.
        val width = 4032
        val height = 3024
        val bytes = ByteArray(width * height) { (it % 251).toByte() }
        val frame = copyCameraLumaPlane(
            sourceBuffer = ByteBuffer.wrap(bytes),
            width = width,
            height = height,
            rowStride = width,
            pixelStride = 1
        )

        assertTrue(frame.width > 0)
        assertTrue(frame.height > 0)
        assertTrue(frame.data.size.toLong() <= MAX_QR_ANALYSIS_PIXELS)
        assertEquals(frame.width * frame.height, frame.data.size)
        val sourceX = (((0 + 0.5) * width.toDouble()) / frame.width.toDouble()).toInt()
        val sourceY = (((0 + 0.5) * height.toDouble()) / frame.height.toDouble()).toInt()
        assertEquals(bytes[sourceY * width + sourceX], frame.data[0])
        val originalRatio = width.toDouble() / height.toDouble()
        val normalizedRatio = frame.width.toDouble() / frame.height.toDouble()
        assertTrue(kotlin.math.abs(originalRatio - normalizedRatio) < 0.005)
    }

    @Test
    fun respectsPaddedRowsAndTwoBytePixelStride() {
        val width = 4
        val height = 3
        val rowStride = 12
        val pixelStride = 2
        val source = ByteArray(rowStride * height)
        val expected = ByteArray(width * height)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val value = (10 + y * width + x).toByte()
                source[y * rowStride + x * pixelStride] = value
                expected[y * width + x] = value
            }
        }

        val frame = copyCameraLumaPlane(
            sourceBuffer = ByteBuffer.wrap(source),
            width = width,
            height = height,
            rowStride = rowStride,
            pixelStride = pixelStride
        )

        assertEquals(width, frame.width)
        assertEquals(height, frame.height)
        assertArrayEquals(expected, frame.data)
    }

    @Test
    fun preservesSupportedLowResolutionFramesWithoutResizing() {
        val data = ByteArray(640 * 480) { (it % 127).toByte() }
        val frame = copyCameraLumaPlane(
            sourceBuffer = ByteBuffer.wrap(data),
            width = 640,
            height = 480,
            rowStride = 640,
            pixelStride = 1
        )
        assertEquals(640, frame.width)
        assertEquals(480, frame.height)
        assertArrayEquals(data, frame.data)
    }

    @Test
    fun honoursNonZeroByteBufferPosition() {
        val prefix = ByteArray(7) { 99 }
        val pixels = byteArrayOf(1, 2, 3, 4, 5, 6)
        val buffer = ByteBuffer.wrap(prefix + pixels)
        buffer.position(prefix.size)
        val frame = copyCameraLumaPlane(buffer, 3, 2, 3, 1)
        assertArrayEquals(pixels, frame.data)
    }
}
