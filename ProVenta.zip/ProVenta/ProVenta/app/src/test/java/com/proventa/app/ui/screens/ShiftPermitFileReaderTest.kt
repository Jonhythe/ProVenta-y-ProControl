package com.proventa.app.ui.screens

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.Assert.assertThrows
import java.io.ByteArrayInputStream

class ShiftPermitFileReaderTest {
    private val validDocument = """{"format":"procontrol.shift-permit","version":2}"""

    @Test
    fun acceptsPlainUtf8AndAValidUtf8Bom() {
        val plain = validDocument.toByteArray(Charsets.UTF_8)
        assertEquals(validDocument, readPermitLimited(ByteArrayInputStream(plain)))
        val withBom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + plain
        assertEquals(validDocument, readPermitLimited(ByteArrayInputStream(withBom)))
    }

    @Test
    fun emptyAndWhitespaceOnlyFilesReportTheirActualCondition() {
        val empty = assertThrows(IllegalArgumentException::class.java) {
            readPermitLimited(ByteArrayInputStream(ByteArray(0)))
        }
        assertTrue(empty.message.orEmpty().contains("0 bytes"))

        val whitespace = assertThrows(IllegalArgumentException::class.java) {
            readPermitLimited(ByteArrayInputStream("  \n\t".toByteArray(Charsets.UTF_8)))
        }
        assertTrue(whitespace.message.orEmpty().contains("texto vacío"))
    }

    @Test
    fun malformedUtf8IsNotSilentlyReplaced() {
        val malformed = byteArrayOf(0x7B, 0x22, 0xC3.toByte(), 0x28, 0x22, 0x7D)
        val error = assertThrows(IllegalArgumentException::class.java) {
            readPermitLimited(ByteArrayInputStream(malformed))
        }
        assertTrue(error.message.orEmpty().contains("UTF-8 válido"))
    }

    @Test
    fun oversizedFilesAreRejectedBeforeJsonParsing() {
        val oversized = ByteArray(64 * 1024 + 1) { 0x20 }
        val error = assertThrows(IllegalArgumentException::class.java) {
            readPermitLimited(ByteArrayInputStream(oversized))
        }
        assertTrue(error.message.orEmpty().contains("64 KiB"))
    }
}
