package com.proventa.app.security

import java.util.Base64
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.time.Instant

class DeviceAuthorizationDescriptorVerifierTest {
    @Test
    fun verifiesProControlStyleInstallationBoundDescriptor() {
        val provider = BouncyCastleProvider()
        val pair = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val publicPem = toPem(pair.public.encoded)
        val fingerprint = MessageDigest.getInstance("SHA-256").digest(pair.public.encoded)
            .joinToString("") { "%02x".format(it) }
        val now = System.currentTimeMillis()
        val document = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 1)
            .put("installationId", "pcinst_" + fingerprint.take(32))
            .put("authorizationId", "auth_" + java.util.UUID.randomUUID())
            .put("desktopId", "desktop-test")
            .put("employeeName", "Dependiente de prueba")
            .put("code", "123456")
            .put("expiresAt", now + 240_000L)
            .put("desktopPublicKey", publicPem)
            .put("createdAt", Instant.ofEpochMilli(now).toString())
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(pair.private)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put(
            "signature",
            JSONObject().put("algorithm", "Ed25519")
                .put("value", Base64.getEncoder().encodeToString(signer.sign()))
        )

        val verified = DeviceAuthorizationDescriptorVerifier().verify(document.toString(), now)
        assertEquals(document.getString("installationId"), verified.installationId)
        assertEquals(document.getString("authorizationId"), verified.authorizationId)
    }

    @Test
    fun rejectsTamperingAndExpiredCodes() {
        val provider = BouncyCastleProvider()
        val pair = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val publicPem = toPem(pair.public.encoded)
        val fingerprint = MessageDigest.getInstance("SHA-256").digest(pair.public.encoded)
            .joinToString("") { "%02x".format(it) }
        val now = System.currentTimeMillis()
        val document = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 1)
            .put("installationId", "pcinst_" + fingerprint.take(32))
            .put("authorizationId", "auth_" + java.util.UUID.randomUUID())
            .put("desktopId", "desktop-test")
            .put("employeeName", "Dependiente")
            .put("code", "123456")
            .put("expiresAt", now + 240_000L)
            .put("desktopPublicKey", publicPem)
            .put("createdAt", Instant.ofEpochMilli(now).toString())
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(pair.private)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put("signature", JSONObject().put("algorithm", "Ed25519")
            .put("value", Base64.getEncoder().encodeToString(signer.sign())))

        val tampered = JSONObject(document.toString()).put("code", "999999")
        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationDescriptorVerifier().verify(tampered.toString(), now)
        }
        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationDescriptorVerifier().verify(document.toString(), now + 300_000L)
        }
    }

    @Test
    fun verifiesProControlV4WithoutLegacyDesktopIdAndUsesSigningKeyHashField() {
        val provider = BouncyCastleProvider()
        val desktop = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val phone = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val publicPem = toPem(desktop.public.encoded)
        val phoneHash = MessageDigest.getInstance("SHA-256").digest(phone.public.encoded)
            .joinToString("") { "%02x".format(it) }
        val fingerprint = MessageDigest.getInstance("SHA-256").digest(desktop.public.encoded)
            .joinToString("") { "%02x".format(it) }
        val installationId = "pcinst_" + fingerprint.take(32)
        val short = fingerprint.take(16).uppercase()
        val installationCode = "PC-${short.substring(0, 4)}-${short.substring(4, 8)}-${short.substring(8, 12)}-${short.substring(12, 16)}"
        val deviceId = "device_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        val now = System.currentTimeMillis()
        val document = JSONObject()
            .put("format", "procontrol.device-authorization")
            .put("version", 4)
            .put("installationId", installationId)
            .put("installationCode", installationCode)
            .put("authorizationId", "auth_" + java.util.UUID.randomUUID())
            .put("deviceId", deviceId)
            .put("deviceSigningPublicKeyHash", phoneHash)
            .put("authorizedPosId", "pos_centro_01")
            .put("employeeName", "Dependiente V4")
            .put("code", "87654321")
            .put("permanent", true)
            .put("expiresAt", now - 1000L)
            .put("createdAt", Instant.ofEpochMilli(now).toString())
            .put("desktopPublicKey", publicPem)
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(desktop.private)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put("signature", JSONObject()
            .put("algorithm", "Ed25519")
            .put("value", Base64.getEncoder().encodeToString(signer.sign())))

        val verified = DeviceAuthorizationDescriptorVerifier().verify(
            rawJson = document.toString(),
            expectedDeviceId = deviceId,
            expectedDevicePublicKeyHash = phoneHash
        )
        assertEquals(4, verified.version)
        assertEquals(installationId, verified.desktopId)
        assertEquals(installationCode, verified.installationCode)
        assertEquals("pos_centro_01", verified.authorizedPosId)
        assertEquals(phoneHash, verified.deviceSigningPublicKeyHash)

        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationDescriptorVerifier().verify(
                rawJson = document.toString(),
                expectedDeviceId = deviceId,
                expectedDevicePublicKeyHash = "0".repeat(64)
            )
        }
    }

    private fun toPem(der: ByteArray): String =
        "-----BEGIN PUBLIC KEY-----\n" +
            Base64.getEncoder().encodeToString(der).chunked(64).joinToString("\n") +
            "\n-----END PUBLIC KEY-----\n"
}
