package com.proventa.app.security

import org.json.JSONObject
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceAuthorizationReplacementPolicyTest {
    private val installationId = "pcinst_0123456789abcdef0123456789abcdef"
    private val installationCode = "PC-0123-4567-89AB-CDEF"
    private val deviceId = "device_phone_12345678"
    private val deviceHash = "a".repeat(64)

    @Test
    fun allowsOnlyAnExactReimportOfTheCurrentAuthorization() {
        val current = descriptor("auth_current_12345678901234567890", "pos_one", "2026-11-11T10:00:00Z")
        DeviceAuthorizationReplacementPolicy.validate(current.toString(), verified(current))

        val changed = descriptor("auth_current_12345678901234567890", "pos_two", "2026-11-11T10:00:00Z")
        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationReplacementPolicy.validate(current.toString(), verified(changed))
        }
    }

    @Test
    fun rejectsReplayOfAnOlderAuthorizationFromTheSameInstallation() {
        val current = descriptor("auth_new_12345678901234567890", "pos_two", "2026-11-11T11:00:00Z")
        val older = descriptor("auth_old_12345678901234567890", "pos_one", "2026-11-11T10:59:59Z")
        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationReplacementPolicy.validate(current.toString(), verified(older))
        }
    }

    @Test
    fun permitsAnExplicitNewerAuthorizationToMoveThePhoneToAnotherPos() {
        val current = descriptor("auth_old_12345678901234567890", "pos_one", "2026-11-11T10:00:00Z")
        val replacement = descriptor("auth_new_12345678901234567890", "pos_two", "2026-11-11T10:00:01Z")
        DeviceAuthorizationReplacementPolicy.validate(current.toString(), verified(replacement))
        assertTrue(verified(replacement).authorizedPosId == "pos_two")
    }

    @Test
    fun rejectsDowngradeBetweenLegacyAuthorizationVersionsToo() {
        val current = descriptor(
            "auth_current_12345678901234567890", "pos_one", "2026-11-11T10:00:00Z", version = 3
        )
        val olderFormat = descriptor(
            "auth_new_12345678901234567890", "pos_one", "2026-11-11T10:00:01Z", version = 2
        )
        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationReplacementPolicy.validate(current.toString(), verified(olderFormat))
        }
    }

    @Test
    fun requiresANewerSequenceForRenewalsOfTheSameV6Authorization() {
        val current = monthlyDescriptor(4)
        val replay = monthlyDescriptor(4)
        val renewal = monthlyDescriptor(5)

        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationReplacementPolicy.validate(current.toString(), verified(replay))
        }
        DeviceAuthorizationReplacementPolicy.validate(current.toString(), verified(renewal))
    }

    @Test
    fun rejectsSwitchingToAnotherInstallationAndRejectsFormatDowngrade() {
        val current = descriptor("auth_current_12345678901234567890", "pos_one", "2026-11-11T10:00:00Z")
        val otherInstallation = descriptor(
            "auth_new_12345678901234567890", "pos_two", "2026-11-11T10:00:01Z",
            installation = "pcinst_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        )
        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationReplacementPolicy.validate(current.toString(), verified(otherInstallation))
        }
        val legacy = JSONObject(otherInstallation.toString())
            .put("installationId", installationId)
            .put("version", 3)
        val legacyVerified = verified(legacy)
        assertThrows(IllegalArgumentException::class.java) {
            DeviceAuthorizationReplacementPolicy.validate(current.toString(), legacyVerified)
        }
    }

    private fun descriptor(
        authorizationId: String,
        posId: String,
        createdAt: String,
        installation: String = installationId,
        version: Int = 4
    ) = JSONObject()
        .put("format", "procontrol.device-authorization")
        .put("version", version)
        .put("permanent", true)
        .put("installationId", installation)
        .put("installationCode", installationCode)
        .put("authorizedPosId", posId)
        .put("authorizationId", authorizationId)
        .put("deviceId", deviceId)
        .put("deviceSigningPublicKeyHash", deviceHash)
        .put("employeeName", "Dependiente")
        .put("code", "12345678")
        .put("createdAt", createdAt)

    private fun monthlyDescriptor(sequence: Long) = JSONObject()
        .put("format", "procontrol.device-authorization")
        .put("version", 6)
        .put("permanent", true)
        .put("installationId", installationId)
        .put("installationCode", installationCode)
        .put("authorizationScope", "installation")
        .put("authorizationId", "auth_monthly_12345678901234567890")
        .put("deviceId", deviceId)
        .put("deviceSigningPublicKeyHash", deviceHash)
        .put("employeeName", "Dependiente")
        .put("code", "12345678")
        .put("renewalSequence", sequence)
        .put("createdAt", "2026-11-11T10:00:00Z")

    private fun verified(document: JSONObject): VerifiedDeviceAuthorization {
        val raw = document.toString()
        return VerifiedDeviceAuthorization(
            installationId = document.optString("installationId"),
            authorizationId = document.optString("authorizationId"),
            desktopId = document.optString("installationId"),
            code = document.optString("code"),
            employeeName = document.optString("employeeName"),
            expiresAt = 0L,
            desktopPublicKeyPem = "",
            rawJson = raw,
            deviceId = document.optString("deviceId"),
            permanent = document.optBoolean("permanent"),
            version = document.optInt("version"),
            installationCode = document.optString("installationCode"),
            authorizedPosId = document.optString("authorizedPosId"),
            deviceSigningPublicKeyHash = document.optString("deviceSigningPublicKeyHash"),
            renewalSequence = document.optLong("renewalSequence", 0L)
        )
    }
}
