package com.proventa.app.security

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test

class CanonicalJsonTest {
    @Test
    fun sortsObjectKeysRecursivelyAndPreservesArrayOrder() {
        val json = JSONObject()
            .put("z", 1)
            .put("a", JSONObject().put("b", "text").put("a", true))
            .put("items", org.json.JSONArray().put(3).put(2).put(1))
        assertEquals(
            """{"a":{"a":true,"b":"text"},"items":[3,2,1],"z":1}""",
            CanonicalJson.stringify(json)
        )
    }

    @Test
    fun usesJsonStringifyCompatibleEscapes() {
        val json = JSONObject().put("value", "line\nquote\"slash\\")
        assertEquals("""{"value":"line\nquote\"slash\\"}""", CanonicalJson.stringify(json))
    }
}
