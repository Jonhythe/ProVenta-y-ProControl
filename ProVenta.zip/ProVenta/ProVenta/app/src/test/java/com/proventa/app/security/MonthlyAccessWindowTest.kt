package com.proventa.app.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class MonthlyAccessWindowTest {
    private val zoneId = "UTC"
    private val installationId = "pcinst_${"a".repeat(32)}"
    private val authorizationId = "auth_12345678-1234-1234-1234-123456789012"

    @Test
    fun expiresAtThreeAmOneCalendarMonthLaterAndClampsMonthEnd() {
        val january31 = Instant.parse("2025-01-31T17:00:00Z").toEpochMilli()
        val window = MonthlyAccessWindow.create(
            installationId, authorizationId, 1, january31, 10_000, 7, zoneId
        )

        assertEquals(Instant.parse("2025-02-28T03:00:00Z").toEpochMilli(), window.expiresAtMillis)
        assertEquals("UTC", window.zoneId)
        assertEquals(
            Instant.parse("2024-02-29T03:00:00Z").toEpochMilli(),
            MonthlyAccessWindow.expiryFor(Instant.parse("2024-01-31T17:00:00Z").toEpochMilli(), zoneId)
        )
        assertEquals(
            Instant.parse("2025-05-30T03:00:00Z").toEpochMilli(),
            MonthlyAccessWindow.expiryFor(Instant.parse("2025-04-30T17:00:00Z").toEpochMilli(), zoneId)
        )
    }

    @Test
    fun allowsNormalElapsedTimeAndExpiresAtDeadline() {
        val activatedAt = Instant.parse("2025-01-01T17:00:00Z").toEpochMilli()
        val window = MonthlyAccessWindow.create(
            installationId, authorizationId, 3, activatedAt, 100_000, 12, zoneId
        )
        val fiveMinutesLater = MonthlyAccessWindow.check(
            window, installationId, authorizationId, 3,
            activatedAt + 5 * 60_000, 100_000 + 5 * 60_000, 12
        )

        assertTrue(fiveMinutesLater.isActive)
        assertNull(fiveMinutesLater.failure)
        assertEquals(activatedAt + 5 * 60_000, fiveMinutesLater.record?.lastWallClockMillis)
        assertFalse(
            MonthlyAccessWindow.check(
                window, installationId, authorizationId, 3,
                window.expiresAtMillis, 100_000 + (window.expiresAtMillis - activatedAt), 12
            ).isActive
        )
        assertEquals(
            MonthlyAccessFailure.EXPIRED,
            MonthlyAccessWindow.check(
                window, installationId, authorizationId, 3,
                window.expiresAtMillis, 100_000 + (window.expiresAtMillis - activatedAt), 12
            ).failure
        )
    }

    @Test
    fun rejectsClockRollbackForwardDriftAndAuthorizationChanges() {
        val activatedAt = Instant.parse("2025-01-01T17:00:00Z").toEpochMilli()
        val window = MonthlyAccessWindow.create(
            installationId, authorizationId, 4, activatedAt, 50_000, 2, zoneId
        )
        val checks = listOf(
            MonthlyAccessWindow.check(
                window, installationId, authorizationId, 4,
                activatedAt - MonthlyAccessWindow.CLOCK_TOLERANCE_MILLIS - 1, 50_001, 2
            ),
            MonthlyAccessWindow.check(
                window, installationId, authorizationId, 4,
                activatedAt + 2 * MonthlyAccessWindow.CLOCK_TOLERANCE_MILLIS, 50_000 + 20_000, 2
            ),
            MonthlyAccessWindow.check(
                window, installationId, authorizationId, 5,
                activatedAt + 1_000, 51_000, 2
            ),
            MonthlyAccessWindow.check(
                window, installationId, "auth_87654321-4321-4321-4321-210987654321", 4,
                activatedAt + 1_000, 51_000, 2
            )
        )

        assertEquals(MonthlyAccessFailure.CLOCK_CHANGED, checks[0].failure)
        assertEquals(MonthlyAccessFailure.CLOCK_CHANGED, checks[1].failure)
        assertEquals(MonthlyAccessFailure.AUTHORIZATION_CHANGED, checks[2].failure)
        assertEquals(MonthlyAccessFailure.AUTHORIZATION_CHANGED, checks[3].failure)
    }

    @Test
    fun rejectsRollbackAfterRebootAndInvalidStoredRecord() {
        val activatedAt = Instant.parse("2025-01-01T17:00:00Z").toEpochMilli()
        val window = MonthlyAccessWindow.create(
            installationId, authorizationId, 1, activatedAt, 80_000, 2, zoneId
        )
        val afterRebootRollback = MonthlyAccessWindow.check(
            window, installationId, authorizationId, 1,
            activatedAt - MonthlyAccessWindow.CLOCK_TOLERANCE_MILLIS - 1, 1_000, 3
        )
        val malformed = MonthlyAccessWindow.check(
            window.copy(expiresAtMillis = window.expiresAtMillis + 1),
            installationId, authorizationId, 1,
            activatedAt + 1_000, 81_000, 2
        )

        assertEquals(MonthlyAccessFailure.CLOCK_CHANGED, afterRebootRollback.failure)
        assertEquals(MonthlyAccessFailure.INVALID_RECORD, malformed.failure)
    }
}
