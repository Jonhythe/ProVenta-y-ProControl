package com.proventa.app.data.receipts

enum class ReceiptStatus {
    PENDING_REVIEW,
    PENDING_OWNER_CONFIRMATION,
    AWAITING_FINAL_ACK,
    CONFIRMED,
    DISCREPANCY,
    REJECTED
}

object GoodsReceiptWorkflow {
    fun canTransition(
        from: ReceiptStatus,
        to: ReceiptStatus,
        finalAuthorizationValidated: Boolean = false
    ): Boolean = when (from) {
        ReceiptStatus.PENDING_REVIEW ->
            to in setOf(
                ReceiptStatus.PENDING_OWNER_CONFIRMATION,
                ReceiptStatus.DISCREPANCY,
                ReceiptStatus.REJECTED
            )
        ReceiptStatus.PENDING_OWNER_CONFIRMATION ->
            to in setOf(
                ReceiptStatus.AWAITING_FINAL_ACK,
                ReceiptStatus.DISCREPANCY,
                ReceiptStatus.REJECTED
            )
        ReceiptStatus.AWAITING_FINAL_ACK -> when (to) {
            ReceiptStatus.CONFIRMED -> finalAuthorizationValidated
            ReceiptStatus.DISCREPANCY, ReceiptStatus.REJECTED -> true
            else -> false
        }
        ReceiptStatus.CONFIRMED,
        ReceiptStatus.DISCREPANCY,
        ReceiptStatus.REJECTED -> false
    }

    fun requireTransition(
        from: ReceiptStatus,
        to: ReceiptStatus,
        finalAuthorizationValidated: Boolean = false
    ) {
        require(canTransition(from, to, finalAuthorizationValidated)) {
            "Transición de entrada no permitida: $from → $to."
        }
    }
}
