package com.proventa.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.dao.ProVentaDao
import com.proventa.app.data.entities.InventorySnapshotEntity
import com.proventa.app.data.entities.OutboxPackageEntity
import com.proventa.app.data.outbox.PackageAcknowledgementImporter
import com.proventa.app.data.entities.ProductEntity
import com.proventa.app.data.money.MoneyMath
import com.proventa.app.data.sales.PaymentDraft
import com.proventa.app.data.sales.PaymentMethod
import com.proventa.app.data.sales.SaleLineDraft
import com.proventa.app.data.sales.SaleRecordingService
import com.proventa.app.security.CurrentProVentaScopeProvider
import com.proventa.app.ui.theme.Gold
import com.proventa.app.ui.theme.NavyElevated
import com.proventa.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.math.BigDecimal
import java.util.UUID
import java.io.InputStream
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets

private enum class SalePriceOption { CUP_CASH, CUP_TRANSFER, FOREIGN_CASH }

private data class CartLineUi(
    val product: ProductEntity,
    val quantityText: String = "1",
    val priceOption: SalePriceOption,
    val transferPhone: String = "",
    val transferOperation: String = ""
)

private data class ResolvedSalePrice(
    val amountMinor: Long,
    val currency: String,
    val scale: Int,
    val label: String?
)

@Composable
fun SalesScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scopeProvider = remember(context) { CurrentProVentaScopeProvider(context.applicationContext) }
    var dao by remember { mutableStateOf<ProVentaDao?>(null) }
    var snapshots by remember { mutableStateOf<List<InventorySnapshotEntity>>(emptyList()) }
    var selectedPosId by remember { mutableStateOf("") }
    var searchText by remember { mutableStateOf("") }
    var showCart by remember { mutableStateOf(false) }
    var activeShiftId by remember { mutableStateOf<String?>(null) }
    var shiftMessage by remember { mutableStateOf("Comprobando turno autorizado…") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Selecciona productos para preparar una venta.") }
    val cart = remember { mutableStateListOf<CartLineUi>() }
    var packageToExport by remember { mutableStateOf<OutboxPackageEntity?>(null) }
    var pendingSalePackageCount by remember { mutableIntStateOf(0) }
    var localOnlySaleCount by remember { mutableIntStateOf(0) }
    var salePackagesNeedingReview by remember { mutableIntStateOf(0) }
    var syncMessage by remember {
        mutableStateOf("Las ventas no se eliminan del teléfono hasta importar un acuse válido de ProControl.")
    }

    val exportSalesPackageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val packageData = packageToExport
        if (uri == null || packageData == null) {
            packageToExport = null
            if (uri == null) syncMessage = "Exportación cancelada. El paquete sigue pendiente."
        } else {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val output = context.contentResolver.openOutputStream(uri, "w")
                            ?: throw IllegalStateException("No se pudo abrir el archivo de destino.")
                        output.use {
                            it.write(packageData.envelopeJson.toByteArray(StandardCharsets.UTF_8))
                        }
                    }
                    syncMessage = "Paquete " + packageData.packageId +
                        " exportado. Impórtalo en ProControl y después trae su acuse .pcack."
                } catch (error: Exception) {
                    syncMessage = error.message ?: "No se pudo exportar el paquete de ventas."
                } finally {
                    packageToExport = null
                }
            }
        }
    }

    val importSalesAckLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                try {
                    val rawAck = withContext(Dispatchers.IO) {
                        val input = context.contentResolver.openInputStream(uri)
                            ?: throw IllegalStateException("No se pudo leer el archivo de acuse.")
                        input.use { readUtf8Limited(it, 64 * 1024) }
                    }
                    val packageId = org.json.JSONObject(rawAck).optString("packageId")
                    val currentPackage = withContext(Dispatchers.IO) {
                        dao?.getOutboxPackage(packageId)
                    }
                    require(currentPackage?.packageType == "sale_batch") {
                        "Este acuse no corresponde a un paquete de ventas de este teléfono."
                    }
                    val result = withContext(Dispatchers.IO) {
                        PackageAcknowledgementImporter(context.applicationContext).importAcknowledgement(rawAck)
                    }
                    val counts = withContext(Dispatchers.IO) {
                        val currentDao = dao ?: throw IllegalStateException("La base local no está disponible.")
                        Triple(
                            currentDao.listPendingSalePackages(selectedPosId).size,
                            currentDao.countPendingSalesWithoutPackage(selectedPosId),
                            currentDao.countSalePackagesNeedingReview(selectedPosId)
                        )
                    }
                    pendingSalePackageCount = counts.first
                    localOnlySaleCount = counts.second
                    salePackagesNeedingReview = counts.third
                    syncMessage = if (result.result == "applied") {
                        "ProControl confirmó la venta. El registro local quedó marcado como sincronizado."
                    } else {
                        "ProControl devolvió " + result.result +
                            ". La venta se conserva en el teléfono para revisar el rechazo o conflicto."
                    }
                } catch (error: Exception) {
                    syncMessage = error.message ?: "No se pudo verificar el acuse de ProControl."
                } finally {
                    busy = false
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        busy = true
        try {
            val prepared = withContext(Dispatchers.IO) {
                val currentDao = ProVentaDatabaseFactory.get(context.applicationContext).proVentaDao()
                val active = runCatching { scopeProvider.requireCurrent() }.getOrNull()
                val activeSnapshots = if (active == null) emptyList() else {
                    currentDao.listInventorySnapshots().filter {
                        it.posId == active.posId &&
                            it.installationId == active.installationId &&
                            it.deviceId == active.deviceId
                    }
                }
                val posId = activeSnapshots.firstOrNull()?.posId.orEmpty()
                val counts = if (posId.isBlank()) Triple(0, 0, 0) else Triple(
                    currentDao.listPendingSalePackages(posId).size,
                    currentDao.countPendingSalesWithoutPackage(posId),
                    currentDao.countSalePackagesNeedingReview(posId)
                )
                Triple(currentDao, activeSnapshots, counts)
            }
            dao = prepared.first
            snapshots = prepared.second
            selectedPosId = snapshots.firstOrNull()?.posId.orEmpty()
            pendingSalePackageCount = prepared.third.first
            localOnlySaleCount = prepared.third.second
            salePackagesNeedingReview = prepared.third.third
        } catch (error: Exception) {
            message = error.message ?: "No se pudo abrir el inventario local."
        } finally {
            busy = false
        }
    }

    LaunchedEffect(selectedPosId, dao) {
        val currentDao = dao ?: return@LaunchedEffect
        if (selectedPosId.isBlank()) return@LaunchedEffect
        val permit = withContext(Dispatchers.IO) {
            val active = scopeProvider.requireCurrent()
            active.requirePos(selectedPosId)
            currentDao.getConfirmedShiftPermit(
                posId = active.posId,
                installationId = active.installationId,
                authorizationId = active.authorizationId,
                deviceId = active.deviceId,
                now = System.currentTimeMillis()
            )
        }
        activeShiftId = permit?.shiftId
        shiftMessage = if (permit == null) {
            "No hay un turno abierto y confirmado por ProControl. Ve a Inicio para importar el permiso y confirmar la apertura."
        } else {
            "Turno activo · " + permit.employee + " · " + selectedPosId
        }
    }

    val productFlow = remember(selectedPosId, dao) {
        val currentDao = dao
        if (selectedPosId.isBlank() || currentDao == null) flowOf(emptyList<ProductEntity>())
        else currentDao.observeProducts(selectedPosId)
    }
    val products by productFlow.collectAsState(initial = emptyList())
    val filteredProducts = remember(products, searchText) {
        val query = searchText.trim().lowercase()
        if (query.isBlank()) products else products.filter { product ->
            product.name.lowercase().contains(query) ||
                product.productId.lowercase().contains(query) ||
                product.family.lowercase().contains(query) ||
                aliasesContainSales(product.catalogAliasesJson, query)
        }
    }

    val cartTotals = remember(cart.toList()) {
        cart.mapNotNull { line ->
            val price = resolvePrice(line) ?: return@mapNotNull null
            val quantity = parseQuantityMicros(line.quantityText) ?: return@mapNotNull null
            val total = runCatching { MoneyMath.lineTotalMinor(price.amountMinor, quantity) }.getOrNull()
                ?: return@mapNotNull null
            Triple(price.currency to price.label, price.scale, total)
        }.groupBy { it.first }.mapValues { (_, rows) ->
            rows.first().second to MoneyMath.sumMinorAmounts(rows.map { it.third })
        }.toSortedMap(compareBy<Pair<String, String?>> { it.first }.thenBy { it.second })
    }

    fun updateCartLine(index: Int, transform: (CartLineUi) -> CartLineUi) {
        if (index in cart.indices) cart[index] = transform(cart[index])
    }

    fun addProduct(product: ProductEntity) {
        val existingIndex = cart.indexOfFirst { it.product.productId == product.productId }
        if (existingIndex >= 0) {
            val existing = cart[existingIndex]
            val currentQty = parseQuantityMicros(existing.quantityText) ?: MoneyMath.QUANTITY_SCALE
            val nextQty = runCatching { Math.addExact(currentQty, MoneyMath.QUANTITY_SCALE) }.getOrNull()
            if (nextQty == null || nextQty > product.availableQuantityMicros) {
                message = "No hay existencias suficientes de " + product.name + "."
            } else {
                cart[existingIndex] = existing.copy(quantityText = BigDecimal.valueOf(nextQty, 6).stripTrailingZeros().toPlainString())
                message = product.name + " añadido al carrito."
            }
            return
        }
        if (product.availableQuantityMicros <= 0L) {
            message = "Este producto no tiene existencias disponibles."
            return
        }
        val option = when {
            product.cupCashPriceMinor != null -> SalePriceOption.CUP_CASH
            product.cupTransferPriceMinor != null -> SalePriceOption.CUP_TRANSFER
            product.foreignPriceMinor != null -> SalePriceOption.FOREIGN_CASH
            else -> null
        }
        if (option == null) {
            message = "Este producto no tiene un precio de venta disponible."
            return
        }
        cart.add(CartLineUi(product = product, priceOption = option))
        message = product.name + " añadido al carrito."
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Ventas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Venta rápida", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
                if (cart.isNotEmpty()) {
                    Button(onClick = { showCart = !showCart }, modifier = Modifier.heightIn(min = 44.dp)) {
                        Text(if (showCart) "Productos" else "Ver carrito · ${cart.size}")
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Punto de venta", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                val selected = snapshots.firstOrNull { it.posId == selectedPosId }
                Text(
                    selected?.posName?.ifBlank { selectedPosId } ?: "Sin inventario autorizado",
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NavyElevated)
            ) {
                Text(
                    shiftMessage,
                    modifier = Modifier.padding(12.dp),
                    color = if (activeShiftId != null) Gold else TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Sincronización con ProControl", fontWeight = FontWeight.Bold)
                    Text(
                        pendingSalePackageCount.toString() + " paquetes de venta pendientes · " +
                            localOnlySaleCount.toString() + " ventas locales sin paquete compatible",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                try {
                                    val next = withContext(Dispatchers.IO) {
                                        dao?.listPendingSalePackages(selectedPosId)
                                            ?.firstOrNull()
                                    }
                                    if (next == null) {
                                        syncMessage = "No hay paquetes de venta exportables pendientes."
                                    } else {
                                        packageToExport = next
                                        exportSalesPackageLauncher.launch(
                                            "ProVenta-Ventas-" + next.packageId + ".pcoutbox"
                                        )
                                    }
                                } catch (error: Exception) {
                                    syncMessage = error.message ?: "No se pudo preparar el paquete."
                                }
                            }
                        },
                        enabled = !busy && pendingSalePackageCount > 0,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) {
                        Text("Exportar siguiente paquete de ventas")
                    }
                    Button(
                        onClick = { importSalesAckLauncher.launch(arrayOf("*/*")) },
                        enabled = !busy && pendingSalePackageCount > 0,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) {
                        Text("Importar acuse .pcack")
                    }
                    Text(syncMessage, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    if (salePackagesNeedingReview > 0) {
                        Text(
                            "$salePackagesNeedingReview paquetes rechazados o en conflicto requieren revisión en ProControl. Las ventas originales siguen conservadas en este teléfono.",
                            color = Gold,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (localOnlySaleCount > 0) {
                        Text(
                            "Hay ventas en monedas o combinaciones que el puente actual de ProControl aún no puede contabilizar. Se conservan localmente y no se exportan con una conversión inventada.",
                            color = Gold,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
        if (snapshots.isEmpty()) {
            item {
                Text(
                    "No hay inventario cargado. Importa primero el archivo .pcinv autorizado desde la sección Stock.",
                    color = TextSecondary
                )
            }
        } else if (!showCart) {
            item {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Buscar producto") },
                    placeholder = { Text("Nombre, código o familia") }
                )
            }
            item {
                Text("${filteredProducts.size} productos", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
            }
            items(filteredProducts, key = { it.productId }) { product ->
                ProductPickerCard(product = product, onAdd = { addProduct(product) })
            }
            if (filteredProducts.isEmpty()) {
                item { Text("No se encontraron productos.", color = TextSecondary) }
            }
        } else {
            item {
                Text("Tu carrito", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Ajusta cantidades y el método de pago de cada producto.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
            items(cart.toList(), key = { it.product.productId }) { line ->
                val index = cart.indexOfFirst { it.product.productId == line.product.productId }
                if (index >= 0) {
                    CartLineCard(
                        line = line,
                        onQuantityChange = { value -> updateCartLine(index) { it.copy(quantityText = value.take(16)) } },
                        onPriceOptionChange = { option -> updateCartLine(index) { it.copy(priceOption = option) } },
                        onPhoneChange = { value -> updateCartLine(index) { it.copy(transferPhone = value.take(40)) } },
                        onOperationChange = { value -> updateCartLine(index) { it.copy(transferOperation = value.take(80)) } },
                        onRemove = { cart.removeAt(index) }
                    )
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().pointerInput(product.productId) {
                        var horizontalDrag = 0f
                        detectHorizontalDragGestures(
                            onHorizontalDrag = { _, dragAmount -> horizontalDrag += dragAmount },
                            onDragEnd = {
                                if (horizontalDrag >= 80f) onAdd()
                                horizontalDrag = 0f
                            },
                            onDragCancel = { horizontalDrag = 0f }
                        )
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyElevated)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Total de la venta", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (cartTotals.isEmpty()) {
                            Text("Revisa cantidades y precios.", color = TextSecondary)
                        } else {
                            cartTotals.forEach { (currencyKey, value) ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(currencyKey.second?.takeIf { currencyKey.first == "OTRA" } ?: currencyKey.first, color = TextSecondary)
                                    Text(formatSaleMoney(value.second, value.first), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Button(
                            onClick = {
                                scope.launch {
                                    busy = true
                                    message = "Guardando venta y actualizando existencias locales…"
                                    try {
                                        val lines = cart.map { line ->
                                            val price = resolvePrice(line)
                                                ?: throw IllegalArgumentException("Falta un precio para " + line.product.name + ".")
                                            val quantity = parseQuantityMicros(line.quantityText)
                                                ?: throw IllegalArgumentException("Cantidad inválida para " + line.product.name + ".")
                                            require(quantity > 0 && quantity <= line.product.availableQuantityMicros) {
                                                "La cantidad de " + line.product.name + " supera las existencias."
                                            }
                                            SaleLineDraft(
                                                lineId = "line_" + UUID.randomUUID().toString().replace("-", ""),
                                                productId = line.product.productId,
                                                productName = line.product.name,
                                                unit = line.product.unit,
                                                quantityMicros = quantity,
                                                unitPriceMinor = price.amountMinor,
                                                currency = price.currency,
                                                currencyScale = price.scale,
                                                currencyLabel = price.label
                                            )
                                        }
                                        val payments = cart.zip(lines).associate { (line, draft) ->
                                            val price = resolvePrice(line)!!
                                            val method = if (line.priceOption == SalePriceOption.CUP_TRANSFER) PaymentMethod.TRANSFER else PaymentMethod.CASH
                                            val payment = PaymentDraft(
                                                paymentId = "pay_" + UUID.randomUUID().toString().replace("-", ""),
                                                method = method,
                                                amountMinor = draft.lineTotalMinor,
                                                currency = price.currency,
                                                currencyScale = price.scale,
                                                transferPhone = if (method == PaymentMethod.TRANSFER) line.transferPhone.trim() else null,
                                                transferOperationNumber = if (method == PaymentMethod.TRANSFER) line.transferOperation.trim() else null
                                            )
                                            draft.lineId to listOf(payment)
                                        }
                                        val saved = withContext(Dispatchers.IO) {
                                            val recorded = SaleRecordingService(context.applicationContext).record(
                                                posId = selectedPosId,
                                                lines = lines,
                                                paymentsByLine = payments
                                            )
                                            val currentDao = ProVentaDatabaseFactory.get(context.applicationContext).proVentaDao()
                                            val pending = currentDao.listPendingSalePackages(selectedPosId).size
                                            val localOnly = currentDao.countPendingSalesWithoutPackage(selectedPosId)
                                            Triple(recorded, pending, localOnly)
                                        }
                                        val result = saved.first
                                        pendingSalePackageCount = saved.second
                                        localOnlySaleCount = saved.third
                                        cart.clear()
                                        showCart = false
                                        message = if (result.packageId != null) {
                                            "Venta guardada y paquete firmado preparado: " + result.packageId +
                                                ". Debes exportarlo por USB e importar el acuse de ProControl."
                                        } else {
                                            "Venta guardada localmente. No se exportó: " +
                                                (result.exportWarning ?: "la moneda aún no es compatible con el puente.")
                                        }
                                    } catch (error: Exception) {
                                        message = error.message ?: "No se pudo guardar la venta."
                                    } finally {
                                        busy = false
                                    }
                                }
                            },
                            enabled = !busy && activeShiftId != null && cart.isNotEmpty() &&
                                cart.all { line ->
                                    val price = resolvePrice(line)
                                    val quantity = parseQuantityMicros(line.quantityText)
                                    price != null && quantity != null && quantity > 0 &&
                                        quantity <= line.product.availableQuantityMicros &&
                                        (line.priceOption != SalePriceOption.CUP_TRANSFER ||
                                            (line.transferPhone.isNotBlank() && line.transferOperation.isNotBlank()))
                                },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
                        ) {
                            Text(if (busy) "Guardando…" else "Confirmar venta")
                        }
                        Text(
                            "La venta queda guardada localmente. La sincronización con ProControl se realizará mediante el paquete de operaciones.",
                            color = TextSecondary,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
        item { Text(message, color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun ProductPickerCard(product: ProductEntity, onAdd: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(product.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge)
            Text(
                product.family + " · " + product.unit + " · Disponible: " + formatSaleQuantity(product.availableQuantityMicros),
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
            val prices = buildList {
                product.cupCashPriceMinor?.let { add("Efectivo CUP: " + formatSaleMoney(it, 2)) }
                product.cupTransferPriceMinor?.let { add("Transferencia CUP: " + formatSaleMoney(it, 2)) }
                product.foreignPriceMinor?.let {
                    add((product.customCurrencyLabel ?: product.foreignCurrency ?: "USD") + ": " + formatSaleMoney(it, product.foreignCurrencyScale ?: 2))
                }
            }
            if (prices.isNotEmpty()) {
                Text(prices.joinToString("  ·  "), color = Gold, style = MaterialTheme.typography.bodySmall)
            } else {
                Text("Sin precio disponible", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
            Text(
                "Desliza a la derecha para añadir",
                color = TextSecondary,
                style = MaterialTheme.typography.labelSmall
            )
            Button(
                onClick = onAdd,
                enabled = product.availableQuantityMicros > 0 && prices.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().heightIn(min = 42.dp)
            ) { Text("Añadir al carrito") }
        }
    }
}

@Composable
private fun CartLineCard(
    line: CartLineUi,
    onQuantityChange: (String) -> Unit,
    onPriceOptionChange: (SalePriceOption) -> Unit,
    onPhoneChange: (String) -> Unit,
    onOperationChange: (String) -> Unit,
    onRemove: () -> Unit
) {
    val price = resolvePrice(line)
    val total = runCatching {
        val quantity = parseQuantityMicros(line.quantityText) ?: return@runCatching null
        if (price == null) null else MoneyMath.lineTotalMinor(price.amountMinor, quantity)
    }.getOrNull()
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(line.product.name, fontWeight = FontWeight.SemiBold)
            Text("Existencias: " + formatSaleQuantity(line.product.availableQuantityMicros) + " " + line.product.unit, color = TextSecondary, style = MaterialTheme.typography.labelSmall)
            OutlinedTextField(
                value = line.quantityText,
                onValueChange = onQuantityChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Cantidad (" + line.product.unit + ")") }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (line.product.cupCashPriceMinor != null) {
                    Button(
                        onClick = { onPriceOptionChange(SalePriceOption.CUP_CASH) },
                        enabled = line.priceOption != SalePriceOption.CUP_CASH,
                        modifier = Modifier.weight(1f).heightIn(min = 40.dp)
                    ) { Text("Efectivo") }
                }
                if (line.product.cupTransferPriceMinor != null) {
                    Button(
                        onClick = { onPriceOptionChange(SalePriceOption.CUP_TRANSFER) },
                        enabled = line.priceOption != SalePriceOption.CUP_TRANSFER,
                        modifier = Modifier.weight(1f).heightIn(min = 40.dp)
                    ) { Text("Transferencia") }
                }
                if (line.product.foreignPriceMinor != null) {
                    Button(
                        onClick = { onPriceOptionChange(SalePriceOption.FOREIGN_CASH) },
                        enabled = line.priceOption != SalePriceOption.FOREIGN_CASH,
                        modifier = Modifier.weight(1f).heightIn(min = 40.dp)
                    ) { Text(line.product.customCurrencyLabel ?: line.product.foreignCurrency ?: "USD") }
                }
            }
            if (line.priceOption == SalePriceOption.CUP_TRANSFER) {
                OutlinedTextField(
                    value = line.transferPhone,
                    onValueChange = onPhoneChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Teléfono de la transferencia") }
                )
                OutlinedTextField(
                    value = line.transferOperation,
                    onValueChange = onOperationChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Número de operación") }
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("Total de este producto", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                    Text(
                        if (total != null && price != null) formatSaleMoney(total, price.scale) + " " + (price.label?.takeIf { price.currency == "OTRA" } ?: price.currency) else "Revisa la cantidad",
                        color = Gold,
                        fontWeight = FontWeight.Bold
                    )
                }
                Button(onClick = onRemove, modifier = Modifier.heightIn(min = 40.dp)) { Text("Quitar") }
            }
        }
    }
}

private fun resolvePrice(line: CartLineUi): ResolvedSalePrice? = when (line.priceOption) {
    SalePriceOption.CUP_CASH -> line.product.cupCashPriceMinor?.let { ResolvedSalePrice(it, "CUP", 2, null) }
    SalePriceOption.CUP_TRANSFER -> line.product.cupTransferPriceMinor?.let { ResolvedSalePrice(it, "CUP", 2, null) }
    SalePriceOption.FOREIGN_CASH -> line.product.foreignPriceMinor?.let {
        ResolvedSalePrice(it, line.product.foreignCurrency ?: "USD", line.product.foreignCurrencyScale ?: 2, line.product.customCurrencyLabel)
    }
}

private fun parseQuantityMicros(value: String): Long? = runCatching {
    val normalized = value.trim().replace(',', '.')
    require(normalized.isNotBlank())
    BigDecimal(normalized).movePointRight(6).setScale(0, java.math.RoundingMode.UNNECESSARY).longValueExact()
}.getOrNull()

private fun formatSaleMoney(amountMinor: Long, scale: Int): String =
    BigDecimal.valueOf(amountMinor, scale).setScale(scale).toPlainString()

private fun formatSaleQuantity(quantityMicros: Long): String =
    BigDecimal.valueOf(quantityMicros, 6).stripTrailingZeros().toPlainString()

private fun aliasesContainSales(aliasesJson: String, query: String): Boolean = try {
    val aliases = JSONArray(aliasesJson)
    (0 until aliases.length()).any { aliases.optString(it).lowercase().contains(query) }
} catch (_: Exception) {
    false
}

private fun readUtf8Limited(input: InputStream, maximumBytes: Int): String {
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(4096)
    var total = 0
    while (true) {
        val count = input.read(buffer)
        if (count < 0) break
        total += count
        require(total <= maximumBytes) { "El archivo de acuse supera el tamaño permitido." }
        output.write(buffer, 0, count)
    }
    return output.toString(StandardCharsets.UTF_8.name())
}
