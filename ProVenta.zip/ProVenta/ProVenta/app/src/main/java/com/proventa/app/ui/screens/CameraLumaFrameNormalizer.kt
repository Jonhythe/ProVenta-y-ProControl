package com.proventa.app.ui.screens

import java.nio.ByteBuffer

/**
 * Compact, tightly-packed luminance frame passed from CameraX to ZXing.
 * CameraX is allowed to choose a sensor-supported resolution different from the
 * requested target; this data class records the actual normalized dimensions.
 */
internal data class CameraLumaFrame(
    val data: ByteArray,
    val width: Int,
    val height: Int
)

internal const val MAX_QR_ANALYSIS_PIXELS = 2_500_000L
private const val MAX_CAMERA_SOURCE_PIXELS = Int.MAX_VALUE.toLong()

/**
 * Copies the Y (luminance) plane while respecting CameraX rowStride/pixelStride.
 * If a device supplies a high-resolution analysis stream (including 50MP/200MP
 * sensor-sized analysis buffers where CameraX/driver memory permits) despite the
 * preferred 1280x720 target, it is downsampled to the largest frame
 * accepted by the QR decoder. No crop or region-of-interest is used: the entire
 * camera field is retained, which allows scanners to find a QR anywhere in frame.
 */
internal fun copyCameraLumaPlane(
    sourceBuffer: ByteBuffer,
    width: Int,
    height: Int,
    rowStride: Int,
    pixelStride: Int,
    maxOutputPixels: Long = MAX_QR_ANALYSIS_PIXELS
): CameraLumaFrame {
    val sourcePixels = width.toLong() * height.toLong()
    require(width > 0 && height > 0 && sourcePixels in 1..MAX_CAMERA_SOURCE_PIXELS) {
        "La cámara del teléfono devolvió dimensiones de imagen no válidas."
    }
    require(rowStride > 0 && pixelStride > 0 && maxOutputPixels > 0L) {
        "La cámara devolvió un formato de imagen no compatible."
    }

    val buffer = sourceBuffer.duplicate()
    val base = buffer.position().toLong()
    val limit = buffer.limit().toLong()
    require(base >= 0L && base < limit) {
        "El plano de imagen de la cámara está vacío."
    }

    // Scale only when required. A square-root scale preserves the camera's
    // aspect ratio and caps memory/ZXing work independently of sensor size.
    val scale = minOf(1.0, kotlin.math.sqrt(maxOutputPixels.toDouble() / sourcePixels.toDouble()))
    var outputWidth = maxOf(1, kotlin.math.floor(width.toDouble() * scale).toInt())
    var outputHeight = maxOf(1, kotlin.math.floor(height.toDouble() * scale).toInt())
    while (outputWidth.toLong() * outputHeight.toLong() > maxOutputPixels) {
        if (outputWidth >= outputHeight && outputWidth > 1) outputWidth-- else if (outputHeight > 1) outputHeight-- else break
    }
    val outputPixels = outputWidth.toLong() * outputHeight.toLong()
    require(outputPixels in 1..maxOutputPixels && outputPixels <= Int.MAX_VALUE.toLong()) {
        "No se pudo normalizar la resolución de la cámara."
    }

    val output = ByteArray(outputPixels.toInt())
    for (outY in 0 until outputHeight) {
        val sourceY = minOf(
            height - 1,
            (((outY + 0.5) * height.toDouble()) / outputHeight.toDouble()).toInt()
        )
        val rowStart = base + sourceY.toLong() * rowStride.toLong()
        for (outX in 0 until outputWidth) {
            val sourceX = minOf(
                width - 1,
                (((outX + 0.5) * width.toDouble()) / outputWidth.toDouble()).toInt()
            )
            val sourceIndex = rowStart + sourceX.toLong() * pixelStride.toLong()
            require(sourceIndex >= base && sourceIndex < limit) {
                "El plano de luminancia de la cámara está incompleto o tiene un stride inválido."
            }
            output[outY * outputWidth + outX] = buffer.get(sourceIndex.toInt())
        }
    }
    return CameraLumaFrame(output, outputWidth, outputHeight)
}

