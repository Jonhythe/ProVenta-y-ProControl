package com.proventa.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.system.Os
import android.system.OsConstants
import android.security.keystore.KeyProperties
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypted, private recovery archive for a POS shift. The source database is never
 * cleared unless this class has written the archive, reopened it, decrypted it,
 * and verified its authenticated metadata and source fingerprint.
 */
class ShiftCloseRecoveryArchive(context: Context) {
    private val appContext = context.applicationContext
    private val directory = File(appContext.noBackupFilesDir, "shift-close-recovery")

    data class VerifiedArchive(
        val file: File,
        val snapshotSha256: String,
        val archiveSha256: String,
        val bytes: Long,
        val productUnits: Map<String, String>
    )

    fun createOrVerify(
        packageId: String,
        posId: String,
        permitId: String,
        packagePayloadHash: String,
        snapshotCanonicalJson: String
    ): VerifiedArchive {
        require(isSafeId(packageId) && isSafeId(permitId) && posId.isNotBlank() && posId.length <= 120) {
            "La identidad del respaldo de cierre no es válida. No se borró ningún dato."
        }
        require(packagePayloadHash.matches(Regex("[a-f0-9]{64}"))) {
            "La huella del cierre no es válida. No se borró ningún dato."
        }
        val snapshot = JSONObject(snapshotCanonicalJson)
        require(snapshot.optString("format") == SNAPSHOT_FORMAT && snapshot.optInt("version") == 1 &&
            snapshot.optString("posId") == posId && snapshot.optString("permitId") == permitId) {
            "El respaldo no corresponde exactamente al POS y turno seleccionados. No se borró ningún dato."
        }
        val snapshotHash = sha256(snapshotCanonicalJson.toByteArray(StandardCharsets.UTF_8))
        if (!directory.exists() && !directory.mkdirs()) {
            throw IllegalStateException("Android no pudo crear la carpeta privada del respaldo. No se borró ningún dato.")
        }
        require(directory.isDirectory && directory.canWrite()) {
            "La carpeta privada del respaldo no está disponible. No se borró ningún dato."
        }
        val finalFile = File(directory, "$permitId-$packageId.pvarchive")
        if (finalFile.exists()) {
            val verified = verifyExisting(finalFile, packageId, posId, permitId, packagePayloadHash, snapshotHash)
            syncArchiveDirectory()
            return verified
        }

        val archiveDocument = JSONObject()
            .put("format", ARCHIVE_FORMAT)
            .put("version", 1)
            .put("packageId", packageId)
            .put("posId", posId)
            .put("permitId", permitId)
            .put("packagePayloadHash", packagePayloadHash)
            .put("snapshotSha256", snapshotHash)
            .put("createdAt", System.currentTimeMillis())
            .put("snapshot", snapshot)
        val plaintext = CanonicalJson.stringify(archiveDocument).toByteArray(StandardCharsets.UTF_8)
        require(plaintext.size <= MAX_ARCHIVE_PLAINTEXT_BYTES) {
            "El respaldo supera el límite seguro de 48 MB. No se borró ningún dato."
        }
        val encrypted = encrypt(plaintext)
        val tempFile = File(directory, ".${finalFile.name}.${System.nanoTime()}.tmp")
        try {
            FileOutputStream(tempFile).use { output ->
                output.write(encrypted)
                output.flush()
                output.fd.sync()
            }
            require(tempFile.isFile && tempFile.length() == encrypted.size.toLong() && tempFile.length() > HEADER.size + 12L) {
                "El respaldo temporal no se escribió completo. No se borró ningún dato."
            }
            // renameTo is atomic within the same directory/filesystem. Never replace an existing archive.
            require(!finalFile.exists() && tempFile.renameTo(finalFile)) {
                "No se pudo finalizar el archivo privado de recuperación. No se borró ningún dato."
            }
            // Flush the directory entry itself before Room is allowed to purge source rows.
            // If the filesystem cannot confirm this, the caller aborts and retains the source.
            syncArchiveDirectory()
            val verified = verifyExisting(finalFile, packageId, posId, permitId, packagePayloadHash, snapshotHash)
            require(verified.bytes == finalFile.length()) {
                "El tamaño del respaldo leído no coincide con el guardado. No se borró ningún dato."
            }
            return verified
        } catch (error: Exception) {
            if (tempFile.exists()) tempFile.delete()
            throw error
        } finally {
            plaintext.fill(0)
            encrypted.fill(0)
        }
    }


    private fun syncArchiveDirectory() {
        // O_DIRECTORY is not exposed by every Android SDK level. Open read-only,
        // then validate the opened descriptor itself before syncing the directory.
        val directoryFd = Os.open(directory.absolutePath, OsConstants.O_RDONLY, 0)
        try {
            val mode = Os.fstat(directoryFd).st_mode
            check((mode and POSIX_FILE_TYPE_MASK) == POSIX_DIRECTORY_TYPE) {
                "La ruta privada del respaldo dejó de ser una carpeta. No se borró ningún dato."
            }
            // A failure here must propagate: the caller must retain the source rows.
            Os.fsync(directoryFd)
        } finally {
            Os.close(directoryFd)
        }
    }

    fun hasArchive(packageId: String, posId: String, permitId: String): Boolean {
        if (!isSafeId(packageId) || !isSafeId(permitId) || posId.isBlank() || posId.length > 120) return false
        return File(directory, "$permitId-$packageId.pvarchive").isFile
    }

    fun verifyExistingAfterClear(
        packageId: String,
        posId: String,
        permitId: String,
        packagePayloadHash: String
    ): VerifiedArchive {
        require(isSafeId(packageId) && isSafeId(permitId) && posId.isNotBlank() &&
            packagePayloadHash.matches(Regex("[a-f0-9]{64}"))) {
            "La identidad del cierre no es verificable. No se modificó ningún dato."
        }
        val file = File(directory, "$permitId-$packageId.pvarchive")
        require(file.isFile && file.length() in (HEADER.size + 13L)..MAX_ARCHIVE_FILE_BYTES) {
            "No existe una copia de recuperación verificada para este cierre. Los datos permanecen protegidos."
        }
        val encrypted = FileInputStream(file).use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var count = 0
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                count += read
                require(count <= MAX_ARCHIVE_FILE_BYTES) { "El respaldo privado supera el tamaño permitido." }
                output.write(buffer, 0, read)
            }
            output.toByteArray()
        }
        val plaintext = decrypt(encrypted)
        try {
            val document = JSONObject(decodeUtf8Strict(plaintext))
            require(document.optString("format") == ARCHIVE_FORMAT && document.optInt("version") == 1 &&
                document.optString("packageId") == packageId && document.optString("posId") == posId &&
                document.optString("permitId") == permitId &&
                document.optString("packagePayloadHash") == packagePayloadHash) {
                "La copia de recuperación no corresponde a este paquete, POS y turno. No se borró ningún dato."
            }
            val snapshot = document.optJSONObject("snapshot")
                ?: throw IllegalStateException("La copia no contiene los datos del turno. No se borró ningún dato.")
            val snapshotHash = sha256(CanonicalJson.stringify(snapshot).toByteArray(StandardCharsets.UTF_8))
            require(snapshotHash == document.optString("snapshotSha256")) {
                "La copia de recuperación no supera la comprobación SHA-256. No se borró ningún dato."
            }
            return VerifiedArchive(file, snapshotHash, sha256(encrypted), file.length(), extractProductUnits(snapshot))
        } finally {
            plaintext.fill(0)
            encrypted.fill(0)
        }
    }

    private fun verifyExisting(
        file: File,
        packageId: String,
        posId: String,
        permitId: String,
        packagePayloadHash: String,
        expectedSnapshotHash: String
    ): VerifiedArchive {
        require(file.isFile && file.length() in (HEADER.size + 13L)..MAX_ARCHIVE_FILE_BYTES) {
            "El archivo privado de recuperación no existe completo o supera el límite permitido. No se borró ningún dato."
        }
        val encrypted = FileInputStream(file).use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var count = 0
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                count += read
                require(count <= MAX_ARCHIVE_FILE_BYTES) { "El respaldo privado supera el tamaño permitido." }
                output.write(buffer, 0, read)
            }
            output.toByteArray()
        }
        val plaintext = decrypt(encrypted)
        try {
            val document = JSONObject(decodeUtf8Strict(plaintext))
            require(document.optString("format") == ARCHIVE_FORMAT && document.optInt("version") == 1) {
                "El respaldo guardado no tiene el formato esperado. No se borró ningún dato."
            }
            require(document.optString("packageId") == packageId && document.optString("posId") == posId &&
                document.optString("permitId") == permitId &&
                document.optString("packagePayloadHash") == packagePayloadHash) {
                "El respaldo pertenece a otro cierre o POS. No se borró ningún dato."
            }
            val storedSnapshot = document.optJSONObject("snapshot")
                ?: throw IllegalStateException("El respaldo no contiene la foto de los datos. No se borró ningún dato.")
            val canonicalSnapshot = CanonicalJson.stringify(storedSnapshot)
            val actualSnapshotHash = sha256(canonicalSnapshot.toByteArray(StandardCharsets.UTF_8))
            require(actualSnapshotHash == expectedSnapshotHash && document.optString("snapshotSha256") == expectedSnapshotHash) {
                "La huella de la copia de recuperación no coincide. No se borró ningún dato."
            }
            val archiveHash = sha256(encrypted)
            return VerifiedArchive(file, actualSnapshotHash, archiveHash, file.length(), extractProductUnits(storedSnapshot))
        } finally {
            plaintext.fill(0)
            encrypted.fill(0)
        }
    }

    private fun extractProductUnits(snapshot: JSONObject): Map<String, String> {
        val rows = snapshot.optJSONArray("products")
            ?: throw IllegalStateException("La copia no contiene la lista original de productos.")
        val result = linkedMapOf<String, String>()
        for (index in 0 until rows.length()) {
            val row = rows.optJSONObject(index)
                ?: throw IllegalStateException("Una fila de productos del respaldo no es válida.")
            if (!row.optBoolean("active", true)) continue
            val id = row.optString("productId")
            val unit = row.optString("unit")
            require(id.isNotBlank() && unit.isNotBlank() && result.put(id, unit) == null) {
                "La copia contiene productos activos sin ID, unidad o repetidos."
            }
        }
        return result
    }

    private fun encrypt(plaintext: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, recoveryKey())
        val iv = cipher.iv
        require(iv.size == 12) { "Android generó un vector de cifrado de tamaño inesperado." }
        val ciphertext = cipher.doFinal(plaintext)
        return ByteBuffer.allocate(HEADER.size + 1 + iv.size + ciphertext.size)
            .put(HEADER)
            .put(iv.size.toByte())
            .put(iv)
            .put(ciphertext)
            .array()
    }

    private fun decrypt(encrypted: ByteArray): ByteArray {
        require(encrypted.size > HEADER.size + 1 + 12 + 16) { "El respaldo cifrado está incompleto." }
        val buffer = ByteBuffer.wrap(encrypted)
        val header = ByteArray(HEADER.size)
        buffer.get(header)
        require(MessageDigest.isEqual(header, HEADER)) { "El encabezado del respaldo cifrado no coincide." }
        val ivLength = buffer.get().toInt() and 0xff
        require(ivLength == 12 && buffer.remaining() > ivLength + 16) { "El respaldo tiene un vector de cifrado inválido." }
        val iv = ByteArray(ivLength)
        buffer.get(iv)
        val ciphertext = ByteArray(buffer.remaining())
        buffer.get(ciphertext)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, recoveryKey(), GCMParameterSpec(128, iv))
            cipher.doFinal(ciphertext)
        } catch (error: Exception) {
            throw IllegalStateException("Android no pudo autenticar y descifrar la copia de recuperación. No se borró ningún dato.", error)
        } finally {
            ciphertext.fill(0)
            iv.fill(0)
        }
    }

    private fun recoveryKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = store.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun decodeUtf8Strict(bytes: ByteArray): String = StandardCharsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)
        .decode(ByteBuffer.wrap(bytes))
        .toString()

    private fun isSafeId(value: String): Boolean = value.matches(Regex("[A-Za-z0-9_-]{8,120}"))

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }

    companion object {
        private const val KEY_ALIAS = "proventa_shift_close_recovery_aes_v1"
        private const val SNAPSHOT_FORMAT = "proventa.shift-close-recovery-snapshot"
        private const val ARCHIVE_FORMAT = "proventa.shift-close-recovery-archive"
        private const val MAX_ARCHIVE_PLAINTEXT_BYTES = 48 * 1024 * 1024
        private const val MAX_ARCHIVE_FILE_BYTES = 50 * 1024 * 1024
        // POSIX stat(2) file-type bits: S_IFMT and S_IFDIR.
        private const val POSIX_FILE_TYPE_MASK = 0xF000
        private const val POSIX_DIRECTORY_TYPE = 0x4000
        private val HEADER = "PVARCH01".toByteArray(StandardCharsets.US_ASCII)
    }
}
