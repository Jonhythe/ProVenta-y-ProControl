package com.proventa.app.security

import android.content.Context
import android.util.Base64
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.RSAKeyGenParameterSpec
import java.security.spec.RSAPublicKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.UUID

data class DeviceKeyMaterial(
    val deviceId: String,
    val signingPrivateKey: PrivateKey,
    val signingPublicPem: String,
    val encryptionPrivateKey: PrivateKey,
    val encryptionPublicPem: String
)

/**
 * Device private keys are encrypted at rest by SecureLocalStore (AES-256-GCM),
 * whose wrapping key is non-exportable in Android Keystore.
 */
class DeviceKeyManager(context: Context) {
    private val secureStore = SecureLocalStore(context.applicationContext)
    private val provider = BouncyCastleProvider()

    @Synchronized
    fun getOrCreate(): DeviceKeyMaterial {
        val stored = secureStore.get(KEY_BUNDLE_RECORD)
        if (stored != null) return decodeBundle(stored)

        val signingPair = KeyPairGenerator.getInstance("Ed25519", provider).generateKeyPair()
        val encryptionGenerator = KeyPairGenerator.getInstance("RSA", provider)
        encryptionGenerator.initialize(
            RSAKeyGenParameterSpec(3072, RSAKeyGenParameterSpec.F4),
            SecureRandom()
        )
        val encryptionPair = encryptionGenerator.generateKeyPair()
        val deviceId = "device_" + UUID.randomUUID().toString().replace("-", "")

        val bundle = JSONObject()
            .put("deviceId", deviceId)
            .put("signingPrivatePkcs8", Base64.encodeToString(signingPair.private.encoded, Base64.NO_WRAP))
            .put("signingPublicSpki", Base64.encodeToString(signingPair.public.encoded, Base64.NO_WRAP))
            .put("encryptionPrivatePkcs8", Base64.encodeToString(encryptionPair.private.encoded, Base64.NO_WRAP))
            .put("encryptionPublicSpki", Base64.encodeToString(encryptionPair.public.encoded, Base64.NO_WRAP))
        secureStore.put(KEY_BUNDLE_RECORD, bundle.toString().toByteArray(StandardCharsets.UTF_8))

        return DeviceKeyMaterial(
            deviceId = deviceId,
            signingPrivateKey = signingPair.private,
            signingPublicPem = toPem(signingPair.public.encoded),
            encryptionPrivateKey = encryptionPair.private,
            encryptionPublicPem = toPem(encryptionPair.public.encoded)
        )
    }

    /**
     * Updates only the local deviceId when a ProControl v4 descriptor proves that
     * this exact Ed25519 key is already enrolled under another signed deviceId.
     * This never changes or imports signing/encryption keys. A constant-time
     * SHA-256 comparison and a private/public-key challenge are required first.
     */
    @Synchronized
    internal fun adoptAuthorizedDeviceId(authorizedDeviceId: String, expectedSigningPublicKeyHash: String) =
        synchronized(IDENTITY_RECONCILIATION_LOCK) {
            adoptAuthorizedDeviceIdLocked(authorizedDeviceId, expectedSigningPublicKeyHash)
        }

    private fun adoptAuthorizedDeviceIdLocked(authorizedDeviceId: String, expectedSigningPublicKeyHash: String) {
        require(authorizedDeviceId.matches(Regex("device_[a-f0-9]{32}"))) {
            "El ID de teléfono firmado por ProControl no tiene un formato válido."
        }
        require(expectedSigningPublicKeyHash.matches(Regex("[a-f0-9]{64}"))) {
            "La huella de clave de ProControl no tiene un formato válido."
        }

        val current = getOrCreate()
        val pemBody = current.signingPublicPem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() }
        val publicDer = Base64.decode(pemBody, Base64.NO_WRAP)
        try {
            val actualHash = MessageDigest.getInstance("SHA-256").digest(publicDer)
                .joinToString("") { "%02x".format(it) }
            require(MessageDigest.isEqual(
                actualHash.toByteArray(StandardCharsets.US_ASCII),
                expectedSigningPublicKeyHash.toByteArray(StandardCharsets.US_ASCII)
            )) {
                "El código fue emitido para otra clave de seguridad. Exporta un ID .pvid nuevo desde este teléfono y genera otra autorización."
            }

            // Prove the persisted private key still corresponds to the public key
            // whose fingerprint ProControl signed before rewriting the encrypted ID.
            val challenge = "ProVenta-device-id-migration:$authorizedDeviceId".toByteArray(StandardCharsets.UTF_8)
            val signer = Signature.getInstance("Ed25519", provider)
            signer.initSign(current.signingPrivateKey)
            signer.update(challenge)
            val proof = signer.sign()
            val publicKey = KeyFactory.getInstance("Ed25519", provider).generatePublic(
                X509EncodedKeySpec(publicDer)
            )
            val verifier = Signature.getInstance("Ed25519", provider)
            verifier.initVerify(publicKey)
            verifier.update(challenge)
            require(verifier.verify(proof)) {
                "La clave privada local no corresponde a la identidad criptográfica registrada. No se modificó el ID."
            }

            if (current.deviceId == authorizedDeviceId) return
            val stored = secureStore.get(KEY_BUNDLE_RECORD)
                ?: throw IllegalStateException("No existe el registro de identidad local para actualizar.")
            val originalBundleBytes = stored.copyOf()
            var writeAttempted = false
            try {
                val bundle = JSONObject(String(stored, StandardCharsets.UTF_8))
                require(bundle.optString("deviceId") == current.deviceId) {
                    "La identidad local cambió durante la verificación. Vuelve a importar la autorización."
                }
                val storedSigningPublic = Base64.decode(
                    bundle.getString("signingPublicSpki"),
                    Base64.NO_WRAP
                )
                require(MessageDigest.isEqual(storedSigningPublic, publicDer)) {
                    "La clave pública local cambió durante la verificación. No se modificó el ID."
                }
                bundle.put("deviceId", authorizedDeviceId)
                writeAttempted = true
                secureStore.put(KEY_BUNDLE_RECORD, bundle.toString().toByteArray(StandardCharsets.UTF_8))

                // Read the encrypted record back before reporting success. Only
                // the ID may differ; both public keys (and therefore the paired
                // private keys) must remain exactly the same.
                val reloaded = getOrCreate()
                require(reloaded.deviceId == authorizedDeviceId &&
                    reloaded.signingPublicPem == current.signingPublicPem &&
                    reloaded.encryptionPublicPem == current.encryptionPublicPem) {
                    "No se pudo confirmar la actualización segura del ID del teléfono."
                }
            } catch (error: Exception) {
                // A failed verification must not leave half-migrated identity state.
                if (writeAttempted) {
                    try {
                        secureStore.put(KEY_BUNDLE_RECORD, originalBundleBytes)
                    } catch (rollbackError: Exception) {
                        error.addSuppressed(rollbackError)
                    }
                }
                throw error
            } finally {
                originalBundleBytes.fill(0)
                stored.fill(0)
            }
        } finally {
            publicDer.fill(0)
        }
    }

    private fun decodeBundle(bytes: ByteArray): DeviceKeyMaterial {
        try {
            val bundle = JSONObject(String(bytes, StandardCharsets.UTF_8))
            val deviceId = bundle.getString("deviceId")
            require(deviceId.matches(Regex("[A-Za-z0-9_-]{8,100}"))) {
                "La identidad guardada del dispositivo no es válida."
            }
            val signingPrivateBytes = Base64.decode(bundle.getString("signingPrivatePkcs8"), Base64.NO_WRAP)
            val signingPublicBytes = Base64.decode(bundle.getString("signingPublicSpki"), Base64.NO_WRAP)
            val encryptionPrivateBytes = Base64.decode(bundle.getString("encryptionPrivatePkcs8"), Base64.NO_WRAP)
            val encryptionPublicBytes = Base64.decode(bundle.getString("encryptionPublicSpki"), Base64.NO_WRAP)
            try {
                val signingFactory = KeyFactory.getInstance("Ed25519", provider)
                val encryptionFactory = KeyFactory.getInstance("RSA", provider)
                val signingPrivate = signingFactory.generatePrivate(PKCS8EncodedKeySpec(signingPrivateBytes))
                val signingPublic = signingFactory.generatePublic(X509EncodedKeySpec(signingPublicBytes))
                val encryptionPrivate = encryptionFactory.generatePrivate(PKCS8EncodedKeySpec(encryptionPrivateBytes))
                val encryptionPublic = encryptionFactory.generatePublic(X509EncodedKeySpec(encryptionPublicBytes))
                return DeviceKeyMaterial(
                    deviceId,
                    signingPrivate,
                    toPem(signingPublic.encoded),
                    encryptionPrivate,
                    toPem(encryptionPublic.encoded)
                )
            } finally {
                signingPrivateBytes.fill(0)
                signingPublicBytes.fill(0)
                encryptionPrivateBytes.fill(0)
                encryptionPublicBytes.fill(0)
            }
        } finally {
            bytes.fill(0)
        }
    }

    private fun toPem(der: ByteArray): String {
        val encoded = Base64.encodeToString(der, Base64.NO_WRAP)
        val body = encoded.chunked(64).joinToString("\n")
        return "-----BEGIN PUBLIC KEY-----\n$body\n-----END PUBLIC KEY-----\n"
    }

    private companion object {
        const val KEY_BUNDLE_RECORD = "device_identity_bundle"
        val IDENTITY_RECONCILIATION_LOCK = Any()
    }
}
