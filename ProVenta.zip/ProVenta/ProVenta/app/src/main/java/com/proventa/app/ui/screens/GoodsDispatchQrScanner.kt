package com.proventa.app.ui.screens

import android.content.Context
import android.content.ContextWrapper
import android.hardware.camera2.CaptureRequest
import android.os.SystemClock
import android.util.Size
import android.view.Surface
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.annotation.OptIn
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.zxing.BarcodeFormat
import com.google.zxing.ChecksumException
import com.google.zxing.FormatException
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.NotFoundException
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.BitMatrix
import com.google.zxing.common.GridSampler
import com.google.zxing.common.PerspectiveTransform
import com.google.zxing.qrcode.decoder.Decoder
import com.google.zxing.qrcode.decoder.Version
import com.google.zxing.qrcode.detector.Detector
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.multi.qrcode.QRCodeMultiReader
import com.google.zxing.qrcode.QRCodeReader
import java.util.EnumMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.sqrt

@OptIn(markerClass = [ExperimentalCamera2Interop::class])
@Composable
fun GoodsDispatchQrScanner(
    onFrames: (List<String>) -> Unit,
    onError: (String) -> Unit,
    instruction: String = "Apunta la cámara a un único código QR y espera a que el lector lo detecte.",
    singleQrOnly: Boolean = false
) {
    val context = LocalContext.current
    val latestOnFrames by rememberUpdatedState(onFrames)
    val latestOnError by rememberUpdatedState(onError)
    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    var activeCameraControl by remember { mutableStateOf<CameraControl?>(null) }
    var hasFlashUnit by remember { mutableStateOf(false) }
    var torchEnabled by remember { mutableStateOf(false) }
    val executor = remember { Executors.newSingleThreadExecutor() }

    LaunchedEffect(activeCameraControl, torchEnabled) {
        activeCameraControl?.enableTorch(torchEnabled)
    }

    DisposableEffect(executor) {
        onDispose { executor.shutdownNow() }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Enfoque automático · lectura continua",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelMedium
            )
            if (hasFlashUnit) {
                TextButton(onClick = { torchEnabled = !torchEnabled }) {
                    Text(if (torchEnabled) "Flash ON" else "Flash", maxLines = 1, softWrap = false)
                }
            }
        }
        Box(
            modifier = Modifier.fillMaxWidth().height(380.dp),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { viewContext ->
                    PreviewView(viewContext).apply {
                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        previewView = this
                    }
                },
                update = { previewView = it }
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.90f)
                    .aspectRatio(1f)
                    .border(3.dp, Color(0xFFFFD36A), RoundedCornerShape(22.dp))
            )
            Text(
                "Muestra el QR completo a la cámara. ProVenta lo detectará automáticamente en el campo de visión.",
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color(0x99000000))
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                color = Color.White,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }

    DisposableEffect(previewView) {
        val view = previewView
        val lifecycleOwner = context.findLifecycleOwner()
        if (view == null || lifecycleOwner == null) {
            latestOnError("No se pudo preparar la cámara de este teléfono.")
            onDispose { }
        } else {
            val providerFuture = ProcessCameraProvider.getInstance(context)
            var provider: ProcessCameraProvider? = null
            var analysis: ImageAnalysis? = null
            val rotation = view.display?.rotation ?: Surface.ROTATION_0

            providerFuture.addListener({
                try {
                    val cameraProvider = providerFuture.get()
                    provider = cameraProvider
                    val previewBuilder = Preview.Builder()
                        .setTargetRotation(rotation)
                    // Solicita enfoque automático continuo como en un escáner de QR nativo.
                    Camera2Interop.Extender(previewBuilder)
                        .setCaptureRequestOption(
                            CaptureRequest.CONTROL_AF_MODE,
                            CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                        )
                        .setCaptureRequestOption(
                            CaptureRequest.CONTROL_AE_MODE,
                            CaptureRequest.CONTROL_AE_MODE_ON
                        )
                    val preview = previewBuilder.build()
                        .also { it.setSurfaceProvider(view.surfaceProvider) }

                    val analysisResolution = ResolutionSelector.Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                        .setResolutionStrategy(
                            ResolutionStrategy(
                                Size(1280, 720),
                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                            )
                        )
                        .build()
                    val imageAnalysis = ImageAnalysis.Builder()
                        .setResolutionSelector(analysisResolution)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                        .setTargetRotation(rotation)
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                    analysis = imageAnalysis
                    imageAnalysis.setAnalyzer(
                        executor,
                        GoodsDispatchImageAnalyzer(
                            singleQrOnly = singleQrOnly,
                            onFrames = { codes -> latestOnFrames(codes) },
                            onError = { message -> latestOnError(message) }
                        )
                    )

                    cameraProvider.unbindAll()
                    val camera = cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        imageAnalysis
                    )
                    activeCameraControl = camera.cameraControl
                    hasFlashUnit = camera.cameraInfo.hasFlashUnit()
                    // Primera medición de foco en el centro; el AF continuo permanece activo.
                    view.post {
                        if (view.width > 0 && view.height > 0) {
                            runCatching {
                                val center = view.meteringPointFactory.createPoint(
                                    view.width / 2f,
                                    view.height / 2f
                                )
                                camera.cameraControl.startFocusAndMetering(
                                    FocusMeteringAction.Builder(center, FocusMeteringAction.FLAG_AF)
                                        .setAutoCancelDuration(2, TimeUnit.SECONDS)
                                        .build()
                                )
                            }
                        }
                    }
                } catch (error: Exception) {
                    latestOnError(error.message ?: "No se pudo iniciar la cámara.")
                }
            }, ContextCompat.getMainExecutor(context))

            onDispose {
                analysis?.clearAnalyzer()
                activeCameraControl = null
                hasFlashUnit = false
                torchEnabled = false
                try {
                    provider?.unbindAll()
                } catch (_: Exception) {
                    // The camera may already have been released by Android lifecycle.
                }
            }
        }
    }

    Text(
        instruction,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        style = MaterialTheme.typography.bodySmall
    )
}

private class GoodsDispatchImageAnalyzer(
    private val singleQrOnly: Boolean,
    private val onFrames: (List<String>) -> Unit,
    private val onError: (String) -> Unit
) : ImageAnalysis.Analyzer {
    private var lastScanAt = 0L
    private var lastGuidanceAt = SystemClock.elapsedRealtime()
    private val minScanIntervalMs = if (singleQrOnly) 140L else 160L
    private val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
        put(DecodeHintType.POSSIBLE_FORMATS, listOf(BarcodeFormat.QR_CODE))
        put(DecodeHintType.TRY_HARDER, true)
    }

    override fun analyze(image: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastScanAt < minScanIntervalMs) return
            lastScanAt = now

            val plane = image.planes.firstOrNull() ?: return
            val frame = copyCameraLumaPlane(
                sourceBuffer = plane.buffer,
                width = image.width,
                height = image.height,
                rowStride = plane.rowStride,
                pixelStride = plane.pixelStride
            )
            val values = decodeQrPayloadsFromLuma(
                frame.data,
                frame.width,
                frame.height,
                image.imageInfo.rotationDegrees,
                singleQrOnly = singleQrOnly
            )
            if (values.isNotEmpty()) {
                lastGuidanceAt = now
                onFrames(values)
            } else if (singleQrOnly && now - lastGuidanceAt >= 2500L) {
                lastGuidanceAt = now
                onError("Todavía no se reconoce el QR. Acércalo hasta que ocupe casi todo el recuadro y evita reflejos.")
            }
        } catch (_: NotFoundException) {
            // Most camera frames do not contain a readable QR symbol.
        } catch (error: Exception) {
            // Report unexpected camera-frame failures occasionally; never stop the analyzer.
            val now = SystemClock.elapsedRealtime()
            if (singleQrOnly && now - lastGuidanceAt >= 2500L) {
                lastGuidanceAt = now
                onError(error.message ?: "No se pudo analizar la imagen de la cámara.")
            }
        } finally {
            image.close()
        }
    }

}


/**
 * Same decode path used by CameraX, exposed internally so a JVM test can feed
 * a real single-symbol QR frame through ZXing without requiring physical camera hardware.
 */
internal fun decodeQrPayloadsFromLuma(
    data: ByteArray,
    width: Int,
    height: Int,
    rotationDegrees: Int,
    singleQrOnly: Boolean = false
): List<String> {
    require(width > 0 && height > 0 && width.toLong() * height <= MAX_QR_ANALYSIS_PIXELS) {
        "Resolución de cámara no válida."
    }
    require(data.size == width * height) { "El fotograma de cámara está incompleto." }
    val rotated = rotateQrLuma(data, width, height, rotationDegrees)

    // Analiza el fotograma completo, ya normalizado proporcionalmente a un
    // tamaño seguro para ZXing. No recorta, no aplica zoom ni limita la búsqueda
    // a una ventana central; el QR puede aparecer en cualquier parte del campo.
    val luminance = PlanarYUVLuminanceSource(
        rotated.first,
        rotated.second,
        rotated.third,
        0,
        0,
        rotated.second,
        rotated.third,
        false
    )
    val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
        put(DecodeHintType.POSSIBLE_FORMATS, listOf(BarcodeFormat.QR_CODE))
        put(DecodeHintType.CHARACTER_SET, "UTF-8")
        put(DecodeHintType.TRY_HARDER, true)
    }

    if (singleQrOnly) {
        // Autorización: un único QR Model 2 convencional dentro de un solo
        // fotograma. Todos los intentos usan el fotograma COMPLETO; no hay ROI,
        // recorte, zoom, escalado, división, temporizador ni reensamblado.
        // Se prueban binarizadores alternativos sobre la misma captura para
        // tolerar diferencias de brillo, contraste y polaridad de la pantalla.
        val luminanceVariants = listOf(luminance, luminance.invert())
        val binarizerFactories: List<
            (com.google.zxing.LuminanceSource) -> com.google.zxing.Binarizer
        > = listOf(
            { source -> HybridBinarizer(source) },
            { source -> GlobalHistogramBinarizer(source) }
        )

        for (source in luminanceVariants) {
            for (createBinarizer in binarizerFactories) {
                // PURE_BARCODE se reserva como alternativa final del mismo
                // fotograma; el intento normal con patrones de búsqueda va primero.
                for (pureBarcode in listOf(false, true)) {
                    val attemptHints = EnumMap<DecodeHintType, Any>(hints).apply {
                        if (pureBarcode) put(DecodeHintType.PURE_BARCODE, true)
                    }
                    val decoded = try {
                        QRCodeReader().decode(
                            BinaryBitmap(createBinarizer(source)),
                            attemptHints
                        ).text
                    } catch (_: NotFoundException) {
                        null
                    } catch (_: ChecksumException) {
                        null
                    } catch (_: FormatException) {
                        null
                    }
                    if (!decoded.isNullOrBlank()) return listOf(decoded)
                }
            }
        }

        // Compatibility fallback for high-version PVLA2 symbols. In this QR
        // fixture ZXing identifies the three finder patterns but estimates
        // version 23 (109 modules) instead of the actual version 24 (113).
        // Its fourth point is consequently the wrong alignment coordinate.
        // Keep the full-frame detector points, try nearby legal QR versions,
        // locate a real alignment pattern from that version's standard center
        // table, and let ZXing's GridSampler + Decoder validate the recovered
        // matrix. No crop, zoom, split, multi-frame merge or QR reconstruction.
        for (source in luminanceVariants) {
            for (createBinarizer in binarizerFactories) {
                val blackMatrix = try {
                    BinaryBitmap(createBinarizer(source)).blackMatrix
                } catch (_: Exception) {
                    null
                } ?: continue
                val decoded = decodeSingleQrUsingVersionAlignment(blackMatrix, hints)
                if (!decoded.isNullOrBlank()) return listOf(decoded)
            }
        }
        return emptyList()
    }

    // El lector de despachos múltiples conserva su recorrido original.
    val multiDecoded = try {
        QRCodeMultiReader().decodeMultiple(BinaryBitmap(HybridBinarizer(luminance)), hints)
            .mapNotNull { it.text?.takeIf(String::isNotBlank) }
            .distinct()
    } catch (_: NotFoundException) {
        emptyList()
    } catch (_: ChecksumException) {
        emptyList()
    } catch (_: FormatException) {
        emptyList()
    }
    if (multiDecoded.isNotEmpty()) return multiDecoded

    return try {
        listOf(QRCodeReader().decode(BinaryBitmap(HybridBinarizer(luminance)), hints).text)
            .filter(String::isNotBlank)
    } catch (_: NotFoundException) {
        emptyList()
    } catch (_: ChecksumException) {
        emptyList()
    } catch (_: FormatException) {
        emptyList()
    }
}

private data class QrModuleVector(val x: Float, val y: Float)

private data class QrAlignmentMatch(
    val x: Float,
    val y: Float,
    val score: Int
)

/**
 * Repairs a one-version under-estimate from ZXing's initial detector by using
 * the three finder centers and a real alignment pattern from a nearby QR
 * version. The recovered matrix is still decoded by ZXing's own QR Decoder.
 */
private fun decodeSingleQrUsingVersionAlignment(
    black: BitMatrix,
    hints: Map<DecodeHintType, Any>
): String? {
    val detection = try {
        Detector(black).detect(hints)
    } catch (_: Exception) {
        return null
    }

    val points = detection.points
    if (points.size < 3) return null

    // ZXing's detector point order is bottom-left, top-left, top-right,
    // followed (when found) by its guessed alignment point. Ignore point[3]:
    // it was derived from the incorrect version estimate in the failing case.
    val bottomLeft = points[0]
    val topLeft = points[1]
    val topRight = points[2]

    val estimatedDimension = detection.bits.width
    val estimatedVersion = ((estimatedDimension - 17) / 4).coerceIn(1, 40)
    // The known ProControl frame is under-estimated by one version. Try that
    // first, then the estimate and nearby alternatives for other payload sizes.
    val versionCandidates = listOf(
        estimatedVersion + 1,
        estimatedVersion,
        estimatedVersion + 2,
        estimatedVersion - 1,
        estimatedVersion + 3,
        estimatedVersion - 2
    ).filter { it in 1..40 }.distinct()

    for (versionNumber in versionCandidates) {
        val version = try {
            Version.getVersionForNumber(versionNumber)
        } catch (_: Exception) {
            continue
        }
        val dimension = version.dimensionForVersion
        val centers = version.alignmentPatternCenters
        if (centers.size < 2 || dimension < 25) continue

        // Distance between finder-pattern centers is dimension - 7 modules.
        val finderModuleSpan = dimension - 7f
        if (finderModuleSpan <= 0f) continue
        val moduleX = QrModuleVector(
            (topRight.x - topLeft.x) / finderModuleSpan,
            (topRight.y - topLeft.y) / finderModuleSpan
        )
        val moduleY = QrModuleVector(
            (bottomLeft.x - topLeft.x) / finderModuleSpan,
            (bottomLeft.y - topLeft.y) / finderModuleSpan
        )
        val pitchX = sqrt(moduleX.x * moduleX.x + moduleX.y * moduleX.y)
        val pitchY = sqrt(moduleY.x * moduleY.x + moduleY.y * moduleY.y)
        val searchRadius = ceil(maxOf(pitchX, pitchY) * 4.75f).toInt().coerceIn(8, 48)

        val last = centers.last()
        val penultimate = centers[centers.lastIndex - 1]
        val orderedPairs = buildList {
            // Prioritize the valid outer alignment cells used by ProControl's
            // high-density symbol, then inspect the remaining standard cells.
            // The bottom-right alignment pattern is the strongest fourth
            // correspondence and matches ZXing's standard QR transform.
            add(last to last)
            add(last to penultimate)
            add(penultimate to last)
            add(penultimate to penultimate)
            for (x in centers.reversed()) {
                for (y in centers.reversed()) add(x to y)
            }
        }.distinct().filterNot { (x, y) ->
            // Alignment cells overlapping the three finder patterns are absent.
            (x == 6 && y == 6) ||
                (x == 6 && y == last) ||
                (x == last && y == 6)
        }

        for ((alignmentX, alignmentY) in orderedPairs) {
            // Version.alignmentPatternCenters stores zero-based module indices.
            // Grid sampling uses module centers, so convert index 106 to 106.5.
            val alignmentCenterX = alignmentX.toFloat() + 0.5f
            val alignmentCenterY = alignmentY.toFloat() + 0.5f
            val predictedX = topLeft.x +
                (alignmentCenterX - 3.5f) * moduleX.x +
                (alignmentCenterY - 3.5f) * moduleY.x
            val predictedY = topLeft.y +
                (alignmentCenterX - 3.5f) * moduleX.y +
                (alignmentCenterY - 3.5f) * moduleY.y

            val match = findQrAlignmentPattern(
                black = black,
                predictedX = predictedX,
                predictedY = predictedY,
                moduleX = moduleX,
                moduleY = moduleY,
                radius = searchRadius
            ) ?: continue
            // A 5x5 alignment pattern has 25 known black/white samples.
            // Permit limited camera noise; the QR checksum and PVLA2
            // Ed25519 verification remain the final acceptance gates.
            if (match.score < 21) continue

            val transform = try {
                PerspectiveTransform.quadrilateralToQuadrilateral(
                    3.5f, 3.5f,
                    dimension - 3.5f, 3.5f,
                    alignmentCenterX, alignmentCenterY,
                    3.5f, dimension - 3.5f,
                    topLeft.x, topLeft.y,
                    topRight.x, topRight.y,
                    match.x, match.y,
                    bottomLeft.x, bottomLeft.y
                )
            } catch (_: Exception) {
                continue
            }

            val decoded = try {
                val sampled = GridSampler.getInstance().sampleGrid(
                    black,
                    dimension,
                    dimension,
                    transform
                )
                Decoder().decode(sampled, hints).text
            } catch (_: Exception) {
                null
            }
            if (!decoded.isNullOrBlank()) return decoded
        }
    }
    return null
}

/** Finds the 5x5 black/white/black alignment target around a projected center. */
private fun findQrAlignmentPattern(
    black: BitMatrix,
    predictedX: Float,
    predictedY: Float,
    moduleX: QrModuleVector,
    moduleY: QrModuleVector,
    radius: Int
): QrAlignmentMatch? {
    var bestScore = -1
    var bestX = predictedX.roundToInt()
    var bestY = predictedY.roundToInt()

    for (dy in -radius..radius) {
        for (dx in -radius..radius) {
            var score = 0
            var samples = 0
            for (row in -2..2) {
                for (column in -2..2) {
                    val px = (
                        predictedX + dx + column * moduleX.x + row * moduleY.x
                    ).roundToInt()
                    val py = (
                        predictedY + dy + column * moduleX.y + row * moduleY.y
                    ).roundToInt()
                    if (px !in 0 until black.width || py !in 0 until black.height) continue
                    samples++
                    val expectedBlack = abs(column) == 2 ||
                        abs(row) == 2 ||
                        (column == 0 && row == 0)
                    if (black.get(px, py) == expectedBlack) score++
                }
            }
            if (samples == 25 && score > bestScore) {
                bestScore = score
                bestX = predictedX.roundToInt() + dx
                bestY = predictedY.roundToInt() + dy
            }
            if (bestScore == 25) {
                return QrAlignmentMatch(bestX.toFloat(), bestY.toFloat(), bestScore)
            }
        }
    }
    return if (bestScore >= 21) {
        QrAlignmentMatch(bestX.toFloat(), bestY.toFloat(), bestScore)
    } else {
        null
    }
}

internal fun rotateQrLuma(
    data: ByteArray,
    width: Int,
    height: Int,
    degrees: Int
): Triple<ByteArray, Int, Int> = when (((degrees % 360) + 360) % 360) {
    90 -> {
        val result = ByteArray(data.size)
        val newWidth = height
        val newHeight = width
        for (y in 0 until height) for (x in 0 until width) {
            val newX = height - 1 - y
            val newY = x
            result[newY * newWidth + newX] = data[y * width + x]
        }
        Triple(result, newWidth, newHeight)
    }
    180 -> {
        val result = ByteArray(data.size)
        for (y in 0 until height) for (x in 0 until width) {
            result[(height - 1 - y) * width + (width - 1 - x)] = data[y * width + x]
        }
        Triple(result, width, height)
    }
    270 -> {
        val result = ByteArray(data.size)
        val newWidth = height
        val newHeight = width
        for (y in 0 until height) for (x in 0 until width) {
            val newX = y
            val newY = width - 1 - x
            result[newY * newWidth + newX] = data[y * width + x]
        }
        Triple(result, newWidth, newHeight)
    }
    else -> Triple(data, width, height)
}

private tailrec fun Context.findLifecycleOwner(): LifecycleOwner? = when (this) {
    is LifecycleOwner -> this
    is ContextWrapper -> baseContext.findLifecycleOwner()
    else -> null
}
