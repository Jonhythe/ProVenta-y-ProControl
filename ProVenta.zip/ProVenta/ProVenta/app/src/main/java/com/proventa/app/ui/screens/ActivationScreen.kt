package com.proventa.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.OfflineBolt
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.proventa.app.ui.theme.AppBackground
import com.proventa.app.ui.theme.Gold
import com.proventa.app.ui.theme.GoldSoft
import com.proventa.app.ui.theme.Navy
import com.proventa.app.ui.theme.NavySurface
import com.proventa.app.ui.theme.Success
import com.proventa.app.ui.theme.TextPrimary
import com.proventa.app.ui.theme.TextSecondary

@Composable
fun ActivationScreen(renewalMode: Boolean = false, onActivated: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(AppBackground),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                ActivationHero(renewalMode)
                if (renewalMode) {
                    Text(
                        "La identidad de este teléfono ya está vinculada. No exportes otro .pvid: escanea el QR nuevo que emite el Dueño en ProControl.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                } else {
                    ActivationRoadmap()
                }
            }
        }
        if (!renewalMode) item { DeviceLinkCard() }
        item { InventoryActivationCard(renewalMode = renewalMode, onActivated = onActivated) }
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 3.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = Gold, modifier = Modifier.size(16.dp))
                Text(
                    "Los datos del negocio permanecen en el teléfono y en el PC autorizado. ProVenta no necesita cuenta, nube ni conexión a Internet para este proceso.",
                    modifier = Modifier.padding(start = 8.dp),
                    color = TextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun ActivationHero(renewalMode: Boolean) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.linearGradient(listOf(Color(0xFF243B5E), Navy, Color(0xFF0D1729))),
                shape = shape
            )
            .padding(19.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(48.dp),
                    shape = RoundedCornerShape(15.dp),
                    color = Gold.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, Gold.copy(alpha = 0.42f))
                ) {
                    Icon(Icons.Outlined.Security, contentDescription = null, tint = GoldSoft, modifier = Modifier.padding(11.dp))
                }
                Column(modifier = Modifier.weight(1f).padding(start = 12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("PROVENTA", color = GoldSoft, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                    Text(if (renewalMode) "Renovación mensual" else "Validación inicial", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                Surface(shape = CircleShape, color = Gold.copy(alpha = 0.12f), border = BorderStroke(1.dp, Gold.copy(alpha = 0.3f))) {
                    Text("CONFIGURACIÓN", modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp), color = GoldSoft, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
            Text(
                if (renewalMode) {
                    "La validación mensual venció o el reloj del teléfono cambió. Escanea un QR de renovación firmado por el Dueño para continuar; tus registros locales se conservan."
                } else {
                    "Primero exporta la identidad de este teléfono para que el Dueño lo autorice en la instalación ProControl. El punto de venta se asignará después mediante cada permiso de turno firmado."
                },
                color = Color(0xFFD2DBE7),
                style = MaterialTheme.typography.bodyMedium
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = Success.copy(alpha = 0.13f), border = BorderStroke(1.dp, Success.copy(alpha = 0.28f))) {
                    Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.OfflineBolt, contentDescription = null, tint = Success, modifier = Modifier.size(15.dp))
                        Text("  FUNCIONA SIN INTERNET", color = Success, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
                Text("Ed25519 · USB / QR", color = Color(0xFFD2DBE7), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun ActivationRoadmap() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        border = BorderStroke(1.dp, Gold.copy(alpha = 0.22f))
    ) {
        Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Text("TU ACTIVACIÓN EN 3 PASOS", color = Gold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            RoadmapRow("01", "Exportar identidad", "Envía el archivo .pvid de este teléfono al Dueño por USB. ")
            RoadmapRow("02", "Validar el teléfono", "Escanea el QR firmado que muestra ProControl.")
            RoadmapRow("03", "Recibir turno e inventario", "Importa el permiso .pcpermit y después el inventario .pcinv de ese POS.")
        }
    }
}

@Composable
private fun RoadmapRow(number: String, title: String, detail: String) {
    Row(verticalAlignment = Alignment.Top) {
        Surface(shape = CircleShape, color = Gold.copy(alpha = 0.12f), border = BorderStroke(1.dp, Gold.copy(alpha = 0.35f))) {
            Text(number, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp), color = Gold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
        Column(modifier = Modifier.padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = TextPrimary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(detail, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}
