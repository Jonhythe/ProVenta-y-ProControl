package com.proventa.app.data.receipts

/**
 * Created only after a final ProControl authorization package has passed
 * signature, installation, transfer ID, payload-hash and local-device checks.
 */
class VerifiedFinalAuthorization internal constructor(
    val transferId: String,
    val packageHash: String,
    val authorizationHash: String,
    val installationId: String,
    val deviceId: String
)
