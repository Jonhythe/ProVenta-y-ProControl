package com.proventa.app.security

import android.content.Context
import android.util.Base64
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.Signature
import java.time.Instant
import java.util.UUID

data class SignedDeviceOperationPackage(
    val packageId: String,
    val deviceId: String,
    val type: String,
    val payloadHash: String,
    val createdAt: Long,
    val envelopeJson: String
)

/**
 * Creates the exact procontrol.offline-package v1 envelope expected by
 * MobileBridgeStore.importOfflineBundle().
 */
class DeviceOperationPackageFactory(context: Context) {
    private val enrollment = DeviceEnrollmentRequestFactory(context.applicationContext)
    private val keyManager = DeviceKeyManager(context.applicationContext)
    private val scopeProvider = CurrentProVentaScopeProvider(context.applicationContext)
    private val provider = BouncyCastleProvider()

    suspend fun create(
        type: String,
        payload: JSONObject,
        createdAt: Long = System.currentTimeMillis()
    ): SignedDeviceOperationPackage {
        require(type in VALID_TYPES) { "Tipo de operación móvil no admitido." }
        require(createdAt > 0 && createdAt <= System.currentTimeMillis() + CLOCK_SKEW_MILLIS) {
            "Fecha de operación inválida."
        }
        val authorization = enrollment.trustedInstallationAuthorization(createdAt)
            ?: throw IllegalStateException("Este teléfono no tiene una ficha de autorización ProControl.")
        require(authorization.permanent && authorization.version >= 4) {
            "Solo se pueden firmar operaciones con una autorización permanente."
        }
        val scope = scopeProvider.requireCurrent(createdAt)
        val keys = keyManager.getOrCreate()
        require(authorization.deviceId == keys.deviceId && scope.deviceId == keys.deviceId) {
            "La identidad criptográfica del teléfono no coincide con la autorización vigente."
        }
        requirePayloadPosScope(type, payload, scope.posId)
        val payloadJson = CanonicalJson.stringify(payload)
        val payloadBytes = payloadJson.toByteArray(StandardCharsets.UTF_8)
        require(payloadBytes.size <= MAX_PAYLOAD_BYTES) { "El paquete supera el tamaño máximo de 2 MB." }
        val payloadHash = sha256(payloadBytes)
        val packageId = UUID.randomUUID().toString()
        val document = JSONObject()
            .put("format", PACKAGE_FORMAT)
            .put("version", 1)
            .put("packageId", packageId)
            .put("deviceId", keys.deviceId)
            .put("type", type)
            .put("createdAt", Instant.ofEpochMilli(createdAt).toString())
            .put("payload", payload)
            .put("payloadHash", payloadHash)
            .put("signerPublicKey", keys.signingPublicPem)

        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(keys.signingPrivateKey)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put(
            "signature",
            JSONObject()
                .put("algorithm", "Ed25519")
                .put("value", Base64.encodeToString(signer.sign(), Base64.NO_WRAP))
        )
        val envelopeJson = document.toString(2)
        require(envelopeJson.toByteArray(StandardCharsets.UTF_8).size <= MAX_ENVELOPE_BYTES) {
            "El archivo firmado supera el tamaño máximo permitido."
        }
        return SignedDeviceOperationPackage(
            packageId = packageId,
            deviceId = keys.deviceId,
            type = type,
            payloadHash = payloadHash,
            createdAt = createdAt,
            envelopeJson = envelopeJson
        )
    }

    private fun requirePayloadPosScope(type: String, payload: JSONObject, authorizedPosId: String) {
        val payloadPosIds = when (type) {
            "sale_batch" -> {
                val transactions = payload.optJSONArray("transactions")
                    ?: throw IllegalArgumentException("El paquete de ventas no contiene transacciones.")
                require(transactions.length() in 1..500) { "El paquete de ventas está vacío o supera el límite de transacciones." }
                (0 until transactions.length()).map { index ->
                    transactions.optJSONObject(index)?.optString("posId")?.takeIf { it.isNotBlank() }
                        ?: throw IllegalArgumentException("Una transacción de venta no identifica su punto de venta.")
                }
            }
            "goods_receipt" -> listOf(
                payload.optString("posId").takeIf { it.isNotBlank() }
                    ?: throw IllegalArgumentException("La recepción no identifica su punto de venta.")
            )
            "shift_open", "shift_close" -> {
                val shift = payload.optJSONObject("shift")
                    ?: throw IllegalArgumentException("La operación de turno no contiene sus datos de turno.")
                val shiftPos = shift.optString("posId").takeIf { it.isNotBlank() }
                    ?: throw IllegalArgumentException("El turno no identifica su punto de venta.")
                if (type == "shift_close") {
                    val report = payload.optJSONObject("closingReport")
                        ?: throw IllegalArgumentException("El cierre no contiene el informe de conciliación.")
                    val reportPos = report.optString("posId").takeIf { it.isNotBlank() }
                        ?: throw IllegalArgumentException("El informe de cierre no identifica su punto de venta.")
                    listOf(shiftPos, reportPos)
                } else listOf(shiftPos)
            }
            "return", "heartbeat" -> {
                val optionalPos = payload.optString("posId")
                if (optionalPos.isBlank()) emptyList() else listOf(optionalPos)
            }
            else -> throw IllegalArgumentException("Tipo de operación móvil no admitido.")
        }
        require(payloadPosIds.all { it == authorizedPosId }) {
            "La operación contiene datos de un punto de venta distinto del autorizado para este teléfono."
        }
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    private companion object {
        const val PACKAGE_FORMAT = "procontrol.offline-package"
        const val MAX_PAYLOAD_BYTES = 1_900_000
        const val MAX_ENVELOPE_BYTES = 2 * 1024 * 1024
        const val CLOCK_SKEW_MILLIS = 5 * 60 * 1000L
        val VALID_TYPES = setOf(
            "sale_batch", "goods_receipt", "shift_open", "shift_close", "return", "heartbeat"
        )
    }
}
