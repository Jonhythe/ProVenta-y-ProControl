package com.proventa.app.data.sales

import android.content.Context
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.OutboxPackageEntity
import com.proventa.app.security.CurrentProVentaScopeProvider
import com.proventa.app.security.DeviceOperationPackageFactory
import java.util.UUID

data class RecordedSale(
    val saleId: String,
    val shiftId: String,
    val lineCount: Int,
    val currencyTotals: List<Pair<String, Long>>,
    val packageId: String?,
    val exportWarning: String?
)

class SaleRecordingService(context: Context) {
    private val appContext = context.applicationContext
    private val dao = ProVentaDatabaseFactory.get(appContext).proVentaDao()
    private val packageFactory = DeviceOperationPackageFactory(appContext)
    private val scopeProvider = CurrentProVentaScopeProvider(appContext)

    suspend fun record(
        posId: String,
        lines: List<SaleLineDraft>,
        paymentsByLine: Map<String, List<PaymentDraft>>,
        nowMillis: Long = System.currentTimeMillis()
    ): RecordedSale {
        require(posId.isNotBlank()) { "Selecciona un punto de venta." }
        require(lines.isNotEmpty()) { "Añade al menos un producto." }
        val scope = scopeProvider.requireCurrent(nowMillis)
        scope.requirePos(posId)

        val permit = dao.getConfirmedShiftPermit(
            posId = scope.posId,
            installationId = scope.installationId,
            authorizationId = scope.authorizationId,
            deviceId = scope.deviceId,
            now = nowMillis
        ) ?: throw IllegalStateException("No hay un turno abierto y confirmado por ProControl para la autorización actual de este teléfono.")
        scope.requirePermitScope(
            permit.installationId,
            permit.authorizationId,
            permit.posId,
            permit.deviceId
        )
        val shiftId = permit.shiftId
            ?: throw IllegalStateException("El permiso confirmado no contiene un identificador de turno.")

        if (permit.emergencyEnabled) {
            val emergencyExpiry = permit.emergencyExpiresAt
                ?: throw IllegalStateException("El permiso de emergencia no tiene vencimiento.")
            require(nowMillis <= emergencyExpiry) { "El permiso de emergencia ha vencido." }
        }

        val saleId = "sale_" + UUID.randomUUID().toString().replace("-", "")
        val bundle = SaleDraftFactory.create(
            saleId = saleId,
            posId = posId,
            shiftId = shiftId,
            idempotencyKey = "sale-idem-" + UUID.randomUUID().toString().replace("-", ""),
            status = SaleStatus.PENDING_SYNC,
            lines = lines,
            paymentsByLine = paymentsByLine,
            now = nowMillis
        )

        if (permit.emergencyEnabled) {
            val usedTickets = dao.countShiftSales(shiftId, scope.posId)
            val newTickets = SaleBatchPayloadFactory.countDesktopTickets(
                bundle.lines,
                bundle.payments
            )
            val projectedTickets = usedTickets.toLong() + newTickets.toLong()
            require(projectedTickets <= permit.emergencyMaxSales.toLong()) {
                "Esta orden generaría $newTickets tickets en ProControl. Ya se utilizaron $usedTickets de " +
                    "${permit.emergencyMaxSales} tickets autorizados para la emergencia."
            }
        }
        val snapshot = dao.getInventorySnapshotForScope(
            posId = scope.posId,
            installationId = scope.installationId,
            deviceId = scope.deviceId
        ) ?: throw IllegalStateException("No existe un snapshot de inventario válido para la autorización y el teléfono actuales.")
        val payload = try {
            SaleBatchPayloadFactory.create(
                sale = bundle.sale,
                lines = bundle.lines,
                payments = bundle.payments,
                posName = snapshot.posName.ifBlank { posId },
                employee = permit.employee,
                shiftPermitId = permit.permitId,
                usdCupRateMicros = snapshot.usdCupRateMicros
            )
        } catch (unsupported: UnsupportedOperationException) {
            // The full sale remains durable locally. Do not disguise a currency
            // or payment mode that the current ProControl ledger cannot account for.
            dao.saveSaleBundle(bundle.sale, bundle.lines, bundle.totals, bundle.payments)
            return RecordedSale(
                saleId = saleId,
                shiftId = shiftId,
                lineCount = bundle.lines.size,
                currencyTotals = bundle.totals.map { it.currency to it.amountMinor },
                packageId = null,
                exportWarning = unsupported.message
                    ?: "ProControl todavía no admite la moneda o el método de pago de esta venta."
            )
        }

        val signedPackage = packageFactory.create(
            type = "sale_batch",
            payload = payload,
            createdAt = nowMillis
        )
        val outboxPackage = OutboxPackageEntity(
            packageId = signedPackage.packageId,
            deviceId = signedPackage.deviceId,
            packageType = signedPackage.type,
            payloadHash = signedPackage.payloadHash,
            envelopeJson = signedPackage.envelopeJson,
            aggregateId = saleId,
            status = "PENDING",
            createdAt = signedPackage.createdAt,
            acknowledgementJson = null,
            acknowledgedAt = null
        )

        // The sale, stock deduction and signed export package commit together.
        // A crash cannot leave a sale deducted from stock without its retryable outbox.
        dao.saveSaleBundle(
            bundle.sale,
            bundle.lines,
            bundle.totals,
            bundle.payments,
            outboxPackage
        )
        return RecordedSale(
            saleId = saleId,
            shiftId = shiftId,
            lineCount = bundle.lines.size,
            currencyTotals = bundle.totals.map { it.currency to it.amountMinor },
            packageId = signedPackage.packageId,
            exportWarning = null
        )
    }
}
