package com.proventa.app.data.receipts

import android.content.Context
import android.util.Base64
import com.proventa.app.security.CanonicalJson
import com.proventa.app.security.DeviceAuthorizationDescriptorVerifier
import com.proventa.app.security.DeviceEnrollmentRequestFactory
import com.proventa.app.security.VerifiedDeviceAuthorization
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.time.Instant

class VerifiedGoodsDispatchManifest internal constructor(
    val installationId: String,
    val desktopId: String,
    val dispatchId: String,
    val posId: String,
    val posName: String,
    val createdAt: Long,
    val expiresAt: Long,
    val itemsHash: String,
    val confirmationCodeHash: String,
    val itemsJson: String,
    val rawJson: String
)

/**
 * Verifies the signed ProControl goods-dispatch manifest before it is stored.
 * The eight-digit confirmation code is deliberately not embedded in the QR;
 * only its SHA-256 hash is present in this document.
 */
class GoodsDispatchManifestVerifier(context: Context) {
    private val enrollment = DeviceEnrollmentRequestFactory(context.applicationContext)
    private val provider = BouncyCastleProvider()

    fun verify(
        rawJson: String,
        expectedPosId: String? = null,
        nowMillis: Long = System.currentTimeMillis()
    ): VerifiedGoodsDispatchManifest {
        val authorization = enrollment.trustedInstallationAuthorization(nowMillis)
            ?: throw IllegalStateException("Este teléfono no está vinculado a una instalación ProControl.")
        return verifyWithAuthorization(rawJson, authorization, expectedPosId, nowMillis)
    }

    internal fun verifyWithAuthorization(
        rawJson: String,
        authorization: VerifiedDeviceAuthorization,
        expectedPosId: String? = null,
        nowMillis: Long = System.currentTimeMillis()
    ): VerifiedGoodsDispatchManifest {
        require(rawJson.toByteArray(StandardCharsets.UTF_8).size in 1..64 * 1024) {
            "El manifiesto de despacho está vacío o supera el tamaño permitido."
        }
        val document = JSONObject(rawJson)
        require(
            document.optString("format") == FORMAT &&
                document.optInt("version") == 1
        ) { "El QR no contiene un manifiesto de despacho ProControl compatible." }

        val installationId = document.optString("installationId")
        val desktopId = document.optString("desktopId")
        val dispatchId = document.optString("dispatchId")
        val posId = document.optString("posId")
        val posName = document.optString("posName").trim()
        val createdAtText = document.optString("createdAt")
        val createdAt = runCatching { Instant.parse(createdAtText).toEpochMilli() }
            .getOrElse { throw IllegalArgumentException("La fecha del despacho no es válida.") }
        val expiresAt = exactLong(document.opt("expiresAt"), "expiresAt")
        val itemsHash = document.optString("itemsHash").lowercase()
        val confirmationCodeHash = document.optString("confirmationCodeHash").lowercase()
        val items = document.optJSONArray("items")
            ?: throw IllegalArgumentException("El manifiesto no contiene productos.")

        require(installationId == authorization.installationId) {
            "El despacho pertenece a otra instalación ProControl."
        }
        if (authorization.version < 4) {
            require(desktopId == authorization.desktopId) {
                "El despacho fue emitido por otra computadora."
            }
        } else {
            // In v4 ProControl places its control-plane deviceId here, not the
            // legacy desktopId. Installation scope plus pinned Ed25519 key and
            // the manifest signature authenticate the emitting installation.
            require(desktopId.isNotBlank() && desktopId.length <= 120) {
                "El manifiesto no identifica correctamente la instancia emisora."
            }
        }
        require(dispatchId.matches(Regex("[A-Za-z0-9:_-]{8,120}"))) {
            "El identificador del despacho no es válido."
        }
        require(posId.matches(Regex("[A-Za-z0-9:_-]{1,160}"))) {
            "El punto de venta del despacho no es válido."
        }
        // V4 authorizations are fixed to one POS. V5+ authorizations identify
        // the installation; the signed dispatch and active shift permit scope
        // each operation to its POS instead.
        if (authorization.version == 4) {
            require(!authorization.authorizedPosId.isNullOrBlank() && posId == authorization.authorizedPosId) {
                "El despacho no pertenece al único punto de venta autorizado para este teléfono."
            }
        }
        if (expectedPosId != null) require(posId == expectedPosId) {
            "El despacho pertenece a otro punto de venta."
        }
        require(posName.isNotBlank() && posName.length <= 160) {
            "El manifiesto no identifica correctamente el punto de venta."
        }
        require(createdAt > 0 && expiresAt > createdAt && nowMillis <= expiresAt) {
            "El manifiesto de despacho ha caducado o contiene fechas inválidas."
        }
        require(items.length() in 1..MAX_ITEMS) {
            "El manifiesto debe contener entre 1 y 300 productos."
        }
        require(itemsHash.matches(Regex("[a-f0-9]{64}")) &&
            confirmationCodeHash.matches(Regex("[a-f0-9]{64}"))) {
            "El manifiesto contiene una huella digital inválida."
        }
        require(!document.has("confirmationCode")) {
            "El manifiesto QR no debe contener el código de confirmación en claro."
        }

        val pinnedKey = parseEd25519PublicKey(authorization.desktopPublicKeyPem)
        val suppliedKey = parseEd25519PublicKey(document.optString("desktopPublicKey"))
        require(MessageDigest.isEqual(pinnedKey.encoded, suppliedKey.encoded)) {
            "La clave firmante del manifiesto no coincide con la instalación vinculada."
        }
        val signatureObject = document.optJSONObject("signature")
            ?: throw IllegalArgumentException("El manifiesto no contiene firma digital.")
        require(signatureObject.optString("algorithm") == "Ed25519") {
            "El algoritmo de firma del manifiesto no es compatible."
        }
        val signatureBytes = try {
            Base64.decode(signatureObject.getString("value"), Base64.DEFAULT)
        } catch (_: Exception) {
            throw IllegalArgumentException("La firma del manifiesto no tiene un formato válido.")
        }
        val signatureVerifier = Signature.getInstance("Ed25519", provider)
        signatureVerifier.initVerify(pinnedKey)
        signatureVerifier.update(
            CanonicalJson.stringify(CanonicalJson.withoutSignature(document))
                .toByteArray(StandardCharsets.UTF_8)
        )
        require(signatureVerifier.verify(signatureBytes)) {
            "La firma digital de ProControl no es válida; el manifiesto pudo ser modificado."
        }

        val seenProductIds = HashSet<String>()
        for (index in 0 until items.length()) {
            val item = items.optJSONObject(index)
                ?: throw IllegalArgumentException("El producto " + (index + 1) + " del manifiesto no es válido.")
            val productId = item.optString("productId")
            val name = item.optString("name").trim()
            val unit = item.optString("unit").trim().lowercase()
            require(productId.matches(Regex("[A-Za-z0-9:_-]{1,160}")) && seenProductIds.add(productId)) {
                "El manifiesto contiene un identificador vacío o duplicado."
            }
            require(name.isNotBlank() && name.length <= 180) {
                "El manifiesto contiene un nombre de producto inválido."
            }
            require(unit in VALID_UNITS) {
                "La unidad de " + name + " no está admitida por ProControl."
            }
            val quantity = decimal(item, "quantity")
            require(quantity > BigDecimal.ZERO && quantity <= MAX_QUANTITY) {
                "La cantidad de " + name + " no es válida."
            }
            for (field in PRICE_FIELDS) {
                val price = decimal(item, field)
                require(price >= BigDecimal.ZERO && price <= MAX_PRICE) {
                    "El precio " + field + " de " + name + " no es válido."
                }
            }
            val currency = item.optString("saleCurrency", "USD").trim().uppercase()
            require(currency in VALID_CURRENCIES) {
                "La moneda de " + name + " no está admitida por ProControl."
            }
            val customCurrency = item.optString("saleCustomCurrency", "").trim()
            if (currency == "OTRA") {
                require(customCurrency.isNotBlank() && customCurrency.length <= 40 &&
                    customCurrency.uppercase() !in RESERVED_CURRENCIES) {
                    "La moneda personalizada de " + name + " no es válida."
                }
            }
            val transferMode = item.opt("saleTransfMode")
            if (transferMode != null && transferMode !== JSONObject.NULL) {
                require(transferMode == "percentage" || transferMode == "manual") {
                    "El método de precio por transferencia de " + name + " no es válido."
                }
            }
            val percentValue = item.opt("saleTransfPercent")
            if (percentValue != null && percentValue !== JSONObject.NULL) {
                val percent = decimal(item, "saleTransfPercent")
                require(percent >= BigDecimal.ZERO && percent <= BigDecimal.valueOf(100)) {
                    "El porcentaje de transferencia de " + name + " no es válido."
                }
            }
            val aliases = item.optJSONArray("aliases")
            if (aliases != null) {
                require(aliases.length() <= 50) { "El manifiesto contiene demasiados alias para " + name + "." }
                for (aliasIndex in 0 until aliases.length()) {
                    require(aliases.optString(aliasIndex).length <= 100) {
                        "Un alias de " + name + " supera la longitud permitida."
                    }
                }
            }
        }

        val actualItemsHash = sha256(CanonicalJson.stringify(items).toByteArray(StandardCharsets.UTF_8))
        require(actualItemsHash == itemsHash) {
            "El contenido de los productos no coincide con la huella del despacho."
        }

        return VerifiedGoodsDispatchManifest(
            installationId = installationId,
            desktopId = desktopId,
            dispatchId = dispatchId,
            posId = posId,
            posName = posName,
            createdAt = createdAt,
            expiresAt = expiresAt,
            itemsHash = itemsHash,
            confirmationCodeHash = confirmationCodeHash,
            itemsJson = CanonicalJson.stringify(items),
            rawJson = CanonicalJson.stringify(document)
        )
    }

    private fun parseEd25519PublicKey(pem: String): java.security.PublicKey {
        require(pem.length in 100..8192 && pem.contains("BEGIN PUBLIC KEY")) {
            "La clave pública de ProControl no es válida."
        }
        val base64 = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() }
        val bytes = try {
            Base64.decode(base64, Base64.DEFAULT)
        } catch (_: Exception) {
            throw IllegalArgumentException("La clave pública de ProControl tiene un formato inválido.")
        }
        return KeyFactory.getInstance("Ed25519", provider)
            .generatePublic(X509EncodedKeySpec(bytes))
    }

    private fun decimal(objectValue: JSONObject, field: String): BigDecimal {
        val value = objectValue.opt(field)
        if (value == null || value === JSONObject.NULL || value == "") return BigDecimal.ZERO
        require(value is Number) { "El campo " + field + " debe ser numérico." }
        return try {
            BigDecimal(value.toString())
        } catch (_: NumberFormatException) {
            throw IllegalArgumentException("El campo " + field + " contiene un número inválido.")
        }
    }

    private fun exactLong(value: Any?, field: String): Long {
        require(value is Number) { "El campo " + field + " no es numérico." }
        return try {
            BigDecimal(value.toString()).longValueExact()
        } catch (_: ArithmeticException) {
            throw IllegalArgumentException("El campo " + field + " debe ser un entero exacto.")
        }
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    private companion object {
        const val FORMAT = "procontrol.goods-dispatch"
        const val MAX_ITEMS = 300
        val MAX_QUANTITY = BigDecimal("100000000")
        val MAX_PRICE = BigDecimal("1000000000")
        val PRICE_FIELDS = listOf("sale", "saleTransf", "saleUSD")
        val VALID_UNITS = setOf("u", "pqt", "lb", "kg", "lt")
        val VALID_CURRENCIES = setOf("USD", "EUR", "MLC", "OTRA")
        val RESERVED_CURRENCIES = setOf("CUP", "USD", "EUR", "MLC", "OTRA")
    }
}
