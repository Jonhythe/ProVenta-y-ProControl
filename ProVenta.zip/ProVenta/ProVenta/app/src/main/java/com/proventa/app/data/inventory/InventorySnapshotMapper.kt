package com.proventa.app.data.inventory

import com.proventa.app.data.entities.ProductEntity
import com.proventa.app.data.money.MoneyMath
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

/**
 * Maps the exact ProControl inventory-snapshot v1 contract into the local POS
 * catalogue. Values with more precision than the mobile ledger supports fail
 * closed instead of being silently rounded.
 */
object InventorySnapshotMapper {
    fun usdCupRateMicros(payloadJson: String): Long? {
        val payload = JSONObject(payloadJson)
        val rates = payload.optJSONObject("exchangeRates") ?: return null
        val value = rates.opt("USD_CUP")
        if (value == null || value === JSONObject.NULL) return null
        require(value is Number) { "La tasa USD/CUP del snapshot no es válida." }
        val rate = MoneyMath.decimalToMicros(value)
        require(rate > 0) { "La tasa USD/CUP debe ser mayor que cero." }
        return rate
    }

    fun exchangeRatesJson(payloadJson: String): String {
        val rates = JSONObject(payloadJson).optJSONObject("exchangeRates") ?: return "{}"
        val safeRates = JSONObject()
        val keys = rates.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = rates.opt(key)
            if (key.matches(Regex("[A-Za-z0-9_:-]{1,80}")) && value is Number &&
                value.toDouble().isFinite() && value.toDouble() > 0.0
            ) {
                safeRates.put(key, value)
            }
        }
        return safeRates.toString()
    }

    fun map(payloadJson: String, payloadHash: String): List<ProductEntity> {
        require(payloadHash.matches(Regex("[a-f0-9]{64}"))) { "Hash del snapshot inválido." }
        val payload = JSONObject(payloadJson)
        require(payload.optString("schema") == "proventa.inventory-snapshot" &&
            payload.optInt("schemaVersion") == 1) {
            "Formato de inventario no compatible."
        }
        val installationId = payload.optString("installationId")
        require(installationId.matches(Regex("pcinst_[a-f0-9]{32}"))) {
            "Identidad de instalación inválida."
        }
        val posId = payload.optString("posId")
        require(posId.matches(Regex("[A-Za-z0-9:_-]{1,160}"))) { "Punto de venta inválido." }
        val updatedAt = Instant.parse(payload.getString("generatedAt")).toEpochMilli()

        val catalogById = HashMap<String, JSONObject>()
        val catalog = payload.optJSONArray("catalog") ?: JSONArray()
        for (index in 0 until catalog.length()) {
            val row = catalog.optJSONObject(index) ?: continue
            val id = row.optString("productId")
            if (id.isNotBlank()) catalogById[id] = row
        }

        val inventory = payload.optJSONArray("inventory")
            ?: throw IllegalArgumentException("El snapshot no contiene inventario.")
        val seen = HashSet<String>()
        return (0 until inventory.length()).map { index ->
            val row = inventory.getJSONObject(index)
            val productId = row.optString("productId")
            val name = row.optString("name").trim()
            val unit = row.optString("unit").trim()
            require(productId.matches(Regex("[A-Za-z0-9:_-]{1,160}")) && seen.add(productId)) {
                "Identificador de producto inválido o duplicado."
            }
            require(name.isNotEmpty() && name.length <= 200 && unit.isNotEmpty() && unit.length <= 40) {
                "El producto $productId no tiene nombre o unidad válidos."
            }

            val catalogRow = catalogById[productId]
            val family = row.optString("family").ifBlank {
                catalogRow?.optString("family").orEmpty()
            }
            val aliases = JSONArray()
            val aliasRows = catalogRow?.optJSONArray("aliases")
            if (aliasRows != null) {
                for (aliasIndex in 0 until aliasRows.length()) {
                    val alias = aliasRows.optString(aliasIndex).trim()
                    if (alias.isNotEmpty()) aliases.put(alias.take(100))
                }
            }

            val quantityValue = row.opt("qty")
            require(quantityValue is Number) { "Existencias inválidas para $productId." }
            val quantityMicros = MoneyMath.decimalToMicros(quantityValue)
            val cupCash = optionalMinor(row, "sale", 2)
            val cupTransfer = optionalMinor(row, "saleTransf", 2)
            val foreignPrice = optionalMinor(row, "saleUSD", 2)

            val transferMode = row.optString("saleTransfMode").lowercase()
                .takeIf { it == "percentage" || it == "manual" }
            val transferPercent = if (transferMode == "percentage") {
                val value = row.opt("saleTransfPercent")
                require(value is Number) { "Falta el porcentaje de transferencia para $productId." }
                MoneyMath.percentToBasisPoints(value)
            } else null

            val currencyValue = row.optString("saleCurrency").uppercase()
                .takeIf { it.isNotBlank() }
                ?: if (foreignPrice != null) "USD" else null
            if (currencyValue != null) {
                require(currencyValue in setOf("USD", "EUR", "MLC", "OTRA")) {
                    "Moneda extranjera no reconocida para $productId."
                }
            }
            val customCurrency = row.optString("saleCustomCurrency").trim().takeIf { it.isNotEmpty() }
            if (currencyValue == "OTRA") {
                require(!customCurrency.isNullOrBlank() && customCurrency.length <= 40) {
                    "Falta el nombre de la moneda personalizada para $productId."
                }
            }

            ProductEntity(
                productId = productId,
                posId = posId,
                name = name,
                family = family,
                unit = unit,
                cupCashPriceMinor = cupCash,
                cupTransferPriceMinor = cupTransfer,
                transferMode = transferMode,
                transferPercentBasisPoints = transferPercent,
                foreignPriceMinor = foreignPrice,
                foreignCurrency = currencyValue,
                customCurrencyLabel = if (currencyValue == "OTRA") customCurrency else null,
                foreignCurrencyScale = if (foreignPrice != null) 2 else null,
                availableQuantityMicros = quantityMicros,
                catalogAliasesJson = aliases.toString(),
                catalogRevision = payloadHash,
                updatedAt = updatedAt,
                active = true
            )
        }
    }

    private fun optionalMinor(row: JSONObject, field: String, scale: Int): Long? {
        val value = row.opt(field)
        if (value == null || value === JSONObject.NULL) return null
        require(value is Number) { "Precio $field inválido." }
        return MoneyMath.decimalToMinorUnits(value, scale)
    }
}
