package com.proventa.app.data

import android.content.Context
import com.proventa.app.security.SecureLocalStore
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import java.security.SecureRandom
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Creates Room over SQLCipher. The random SQLCipher passphrase is wrapped by
 * SecureLocalStore, whose AES key is held in Android Keystore.
 */
object ProVentaDatabaseFactory {
    private const val DATABASE_NAME = "proventa-secure.db"
    private const val PASSPHRASE_RECORD = "sqlcipher_passphrase"

    private val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(database: SupportSQLiteDatabase) {
            database.execSQL(
                "ALTER TABLE goods_receipts ADD COLUMN manifestJson TEXT NOT NULL DEFAULT ''"
            )
        }
    }
    private val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(database: SupportSQLiteDatabase) {
            database.execSQL(
                "ALTER TABLE inventory_snapshots ADD COLUMN exchangeRatesJson TEXT NOT NULL DEFAULT '{}'"
            )
            database.execSQL("""
                CREATE TABLE IF NOT EXISTS shift_close_drafts (
                    permitId TEXT NOT NULL,
                    shiftId TEXT NOT NULL,
                    posId TEXT NOT NULL,
                    draftJson TEXT NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    PRIMARY KEY(permitId)
                )
            """)
            database.execSQL("CREATE INDEX IF NOT EXISTS index_shift_close_drafts_posId ON shift_close_drafts(posId)")
            database.execSQL("CREATE INDEX IF NOT EXISTS index_shift_close_drafts_updatedAt ON shift_close_drafts(updatedAt)")
        }
    }
    private val MIGRATION_3_4 = object : Migration(3, 4) {
        override fun migrate(database: SupportSQLiteDatabase) {
            database.execSQL("""
                CREATE TABLE products_new (
                    productId TEXT NOT NULL,
                    posId TEXT NOT NULL,
                    name TEXT NOT NULL,
                    family TEXT NOT NULL,
                    unit TEXT NOT NULL,
                    cupCashPriceMinor INTEGER,
                    cupTransferPriceMinor INTEGER,
                    transferMode TEXT,
                    transferPercentBasisPoints INTEGER,
                    foreignPriceMinor INTEGER,
                    foreignCurrency TEXT,
                    customCurrencyLabel TEXT,
                    foreignCurrencyScale INTEGER,
                    availableQuantityMicros INTEGER NOT NULL,
                    catalogAliasesJson TEXT NOT NULL,
                    catalogRevision TEXT NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    active INTEGER NOT NULL,
                    PRIMARY KEY(posId, productId)
                )
            """.trimIndent())
            database.execSQL("""
                INSERT INTO products_new (
                    productId, posId, name, family, unit,
                    cupCashPriceMinor, cupTransferPriceMinor, transferMode,
                    transferPercentBasisPoints, foreignPriceMinor, foreignCurrency,
                    customCurrencyLabel, foreignCurrencyScale, availableQuantityMicros,
                    catalogAliasesJson, catalogRevision, updatedAt, active
                )
                SELECT
                    productId, posId, name, family, unit,
                    cupCashPriceMinor, cupTransferPriceMinor, transferMode,
                    transferPercentBasisPoints, foreignPriceMinor, foreignCurrency,
                    customCurrencyLabel, foreignCurrencyScale, availableQuantityMicros,
                    catalogAliasesJson, catalogRevision, updatedAt, active
                FROM products
            """.trimIndent())
            database.execSQL("DROP TABLE products")
            database.execSQL("ALTER TABLE products_new RENAME TO products")
            database.execSQL("CREATE INDEX index_products_posId_name ON products(posId, name)")
        }
    }

    @Volatile private var instance: ProVentaDatabase? = null

    fun get(context: Context): ProVentaDatabase {
        return instance ?: synchronized(this) {
            instance ?: create(context.applicationContext).also { instance = it }
        }
    }

    private fun create(context: Context): ProVentaDatabase {
        System.loadLibrary("sqlcipher")
        val databaseFile = context.getDatabasePath(DATABASE_NAME)
        val secureStore = SecureLocalStore(context)
        val existingPassphrase = secureStore.get(PASSPHRASE_RECORD)

        val passphrase = when {
            existingPassphrase != null -> existingPassphrase
            databaseFile.exists() -> throw IllegalStateException(
                "La base de datos existe, pero no se encuentra su clave segura. Se bloqueó la apertura para evitar pérdida de datos."
            )
            else -> ByteArray(32).also { SecureRandom().nextBytes(it) }.also {
                secureStore.put(PASSPHRASE_RECORD, it)
            }
        }

        val factory = SupportOpenHelperFactory(passphrase, null, true)
        return Room.databaseBuilder(
            context,
            ProVentaDatabase::class.java,
            databaseFile.absolutePath
        )
            .openHelperFactory(factory)
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
            .build()
    }
}
