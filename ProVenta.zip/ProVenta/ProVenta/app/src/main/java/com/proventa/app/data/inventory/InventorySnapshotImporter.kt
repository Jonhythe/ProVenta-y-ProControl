package com.proventa.app.data.inventory

import android.content.Context
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.InventorySnapshotEntity
import com.proventa.app.security.CurrentProVentaScopeProvider
import com.proventa.app.security.DeviceDataPackageDecryptor
import org.json.JSONObject
import java.time.Instant

data class InventoryImportResult(
    val applied: Boolean,
    val posId: String,
    val productCount: Int,
    val packageId: String,
    val payloadHash: String
)

/**
 * The only entry point for importing a device-bound ProControl inventory file.
 * Signature/decryption validation happens before any database write.
 */
class InventorySnapshotImporter(context: Context) {
    private val appContext = context.applicationContext
    private val decryptor = DeviceDataPackageDecryptor(appContext)
    private val database = ProVentaDatabaseFactory.get(appContext)
    private val scopeProvider = CurrentProVentaScopeProvider(appContext)

    suspend fun importPackage(
        envelopeJson: String,
        expectedPosId: String? = null
    ): InventoryImportResult {
        val scope = scopeProvider.requireCurrent()
        val requestedPosId = expectedPosId ?: scope.posId
        scope.requirePos(requestedPosId)
        val verified = decryptor.decrypt(envelopeJson, requestedPosId)
        scope.requirePos(verified.posId)
        require(
            verified.installationId == scope.installationId &&
                verified.authorizationId == scope.authorizationId &&
                verified.deviceId == scope.deviceId
        ) { "El inventario pertenece a otra instalación, autorización o teléfono." }
        val products = InventorySnapshotMapper.map(verified.payloadJson, verified.payloadHash)
        val payload = JSONObject(verified.payloadJson)
        val generatedAt = Instant.parse(payload.getString("generatedAt")).toEpochMilli()
        val snapshot = InventorySnapshotEntity(
            posId = verified.posId,
            posName = verified.posName,
            usdCupRateMicros = InventorySnapshotMapper.usdCupRateMicros(verified.payloadJson),
            exchangeRatesJson = InventorySnapshotMapper.exchangeRatesJson(verified.payloadJson),
            installationId = verified.installationId,
            deviceId = verified.deviceId,
            packageId = verified.packageId,
            payloadHash = verified.payloadHash,
            generatedAt = generatedAt,
            importedAt = System.currentTimeMillis(),
            productCount = products.size
        )
        val applied = database.proVentaDao().applyInventorySnapshot(snapshot, products)
        return InventoryImportResult(
            applied = applied,
            posId = verified.posId,
            productCount = products.size,
            packageId = verified.packageId,
            payloadHash = verified.payloadHash
        )
    }
}
