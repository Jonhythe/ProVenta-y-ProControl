package com.proventa.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.ShiftPermitEntity
import com.proventa.app.data.outbox.PackageAcknowledgementImporter
import com.proventa.app.data.shifts.ShiftOpenService
import com.proventa.app.security.DeviceEnrollmentRequestFactory
import com.proventa.app.security.DeviceKeyManager
import com.proventa.app.data.shifts.ShiftPermitImporter
import com.proventa.app.security.SignedDeviceOperationPackage
import com.proventa.app.ui.theme.Gold
import com.proventa.app.ui.theme.NavyElevated
import com.proventa.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Date

@Composable
fun ShiftPermitCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enrollment = remember(context) { DeviceEnrollmentRequestFactory(context.applicationContext) }
    val keyManager = remember(context) { DeviceKeyManager(context.applicationContext) }
    var permits by remember { mutableStateOf<List<ShiftPermitEntity>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Importa el permiso .pcpermit emitido por ProControl.") }
    var packageToExport by remember { mutableStateOf<SignedDeviceOperationPackage?>(null) }

    suspend fun refresh() {
        permits = withContext(Dispatchers.IO) {
            val authorization = enrollment.trustedInstallationAuthorization()
                ?: return@withContext emptyList()
            val deviceId = keyManager.getOrCreate().deviceId
            if (authorization.deviceId != deviceId) return@withContext emptyList()
            ProVentaDatabaseFactory.get(context.applicationContext).proVentaDao().listShiftPermitsForDevice(
                installationId = authorization.installationId,
                authorizationId = authorization.authorizationId,
                deviceId = deviceId
            )
        }
    }

    val importPermitLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                message = "Verificando permiso y firma del PC…"
                try {
                    val raw = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { readPermitLimited(it) }
                            ?: throw IllegalStateException("No se pudo abrir el permiso.")
                    }
                    val result = withContext(Dispatchers.IO) {
                        ShiftPermitImporter(context.applicationContext).importPermit(raw)
                    }
                    refresh()
                    message = if (result.imported) {
                        "Permiso aceptado para " + result.employee + " · " + result.posId + "."
                    } else {
                        "Este permiso ya estaba importado; no se duplicó."
                    }
                } catch (error: Exception) {
                    message = error.message ?: "No se pudo importar el permiso."
                } finally {
                    busy = false
                }
            }
        }
    }

    val exportPackageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val packageData = packageToExport
        if (uri != null && packageData != null) {
            scope.launch {
                busy = true
                try {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri, "w")?.use { output ->
                            output.write(packageData.envelopeJson.toByteArray(Charsets.UTF_8))
                            output.flush()
                        } ?: throw IllegalStateException("No se pudo guardar el paquete de apertura.")
                    }
                    message = "Apertura exportada. Copia el archivo .pcoutbox al PC; el dueño debe importarlo y aceptar la apertura."
                } catch (error: Exception) {
                    message = error.message ?: "No se pudo exportar la apertura."
                } finally {
                    busy = false
                    packageToExport = null
                }
            }
        } else {
            packageToExport = null
            busy = false
        }
    }

    val importAcknowledgementLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                message = "Verificando el acuse firmado de ProControl…"
                try {
                    val raw = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { readPermitLimited(it) }
                            ?: throw IllegalStateException("No se pudo abrir el acuse.")
                    }
                    val result = withContext(Dispatchers.IO) {
                        PackageAcknowledgementImporter(context.applicationContext).importAcknowledgement(raw)
                    }
                    refresh()
                    message = if (result.applied) {
                        if (result.result == "applied") "ProControl confirmó la apertura del turno."
                        else "ProControl respondió: " + result.result + ". Revisa el estado con el dueño."
                    } else {
                        "Este acuse ya había sido procesado."
                    }
                } catch (error: Exception) {
                    message = error.message ?: "No se pudo verificar el acuse."
                } finally {
                    busy = false
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        runCatching { refresh() }.onFailure {
            message = it.message ?: "No se pudieron leer los permisos guardados."
        }
    }

    val now = System.currentTimeMillis()
    val current = permits.firstOrNull {
        when (it.status) {
            "ISSUED" -> it.endsAt > now
            "OPEN_PENDING_REVIEW", "OPENED", "CLOSE_PENDING" -> true
            else -> false
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = NavyElevated)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Permiso de turno", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (current == null) {
                Text(
                    "No hay un permiso vigente guardado. Sin permiso firmado no se habilitarán ventas ni cierres.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text(current.employee, color = Gold, fontWeight = FontWeight.SemiBold)
                Text(
                    if (current.startsAt > now) "Programado" else current.statusLabel(),
                    color = Gold,
                    style = MaterialTheme.typography.labelSmall
                )
                Text("Punto de venta: " + current.posId, style = MaterialTheme.typography.bodySmall)
                Text(
                    "Horario: " + formatPermitDate(current.startsAt) + " – " + formatPermitDate(current.endsAt),
                    style = MaterialTheme.typography.bodySmall
                )
                Text("Secuencia: " + current.sequence, color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                if (current.emergencyEnabled) {
                    Text(
                        "Emergencia: máximo " + current.emergencyMaxSales + " ventas.",
                        color = Gold,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (current.status == "ISSUED") {
                    Button(
                        onClick = {
                            scope.launch {
                                busy = true
                                message = "Creando apertura firmada…"
                                try {
                                    val packageData = withContext(Dispatchers.IO) {
                                        ShiftOpenService(context.applicationContext)
                                            .createOrGetOpeningPackage(current.permitId)
                                    }
                                    packageToExport = packageData
                                    exportPackageLauncher.launch("ProVenta-apertura.pcoutbox")
                                    refresh()
                                } catch (error: Exception) {
                                    message = error.message ?: "No se pudo abrir el turno."
                                    busy = false
                                }
                            }
                        },
                        enabled = !busy && current.startsAt <= now,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) {
                        Text("Iniciar turno y exportar apertura")
                    }
                } else if (current.status == "OPEN_PENDING_REVIEW") {
                    Button(
                        onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val packageData = withContext(Dispatchers.IO) {
                                        ShiftOpenService(context.applicationContext)
                                            .createOrGetOpeningPackage(current.permitId)
                                    }
                                    packageToExport = packageData
                                    exportPackageLauncher.launch("ProVenta-apertura.pcoutbox")
                                } catch (error: Exception) {
                                    message = error.message ?: "No se pudo recuperar la apertura pendiente."
                                    busy = false
                                }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) {
                        Text("Volver a exportar apertura")
                    }
                    Button(
                        onClick = { importAcknowledgementLauncher.launch(arrayOf("*/*")) },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) {
                        Text("Importar acuse .pcack")
                    }
                } else if (current.status == "OPENED") {
                    Text(
                        if (current.endsAt <= now) "El horario autorizado terminó. Debe cerrarse y conciliarse este turno." else "Turno confirmado por ProControl. El registro de ventas se habilitará sobre este turno.",
                        color = Gold,
                        style = MaterialTheme.typography.bodySmall
                    )
                } else if (current.status == "CLOSE_PENDING") {
                    Text(
                        "Cierre enviado. Esperando confirmación final de ProControl.",
                        color = Gold,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            Button(
                onClick = { importPermitLauncher.launch(arrayOf("*/*")) },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
            ) {
                Text("Importar permiso .pcpermit")
            }
            Text(message, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun ShiftPermitEntity.statusLabel(): String = when (status) {
    "ISSUED" -> "Permiso emitido"
    "OPEN_PENDING_REVIEW" -> "Apertura pendiente de confirmación"
    "OPENED" -> "Turno abierto y confirmado"
    "CLOSE_PENDING" -> "Cierre pendiente"
    else -> status
}

internal fun readPermitLimited(input: java.io.InputStream): String {
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(4096)
    var total = 0
    while (true) {
        val count = input.read(buffer)
        if (count < 0) break
        require(count == 0 || total <= 64 * 1024 - count) {
            "El archivo supera el límite comprobable de 64 KiB. No se ha importado ni modificado ningún permiso."
        }
        total += count
        if (count > 0) output.write(buffer, 0, count)
    }
    require(total > 0) { "El archivo seleccionado está vacío (0 bytes). Selecciona el .pcpermit exportado por ProControl." }
    val bytes = output.toByteArray()
    try {
        var offset = 0
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            offset = 3 // UTF-8 BOM válido; no es daño del archivo.
        }
        val decoded = try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes, offset, bytes.size - offset)).toString()
        } catch (error: java.nio.charset.CharacterCodingException) {
            throw IllegalArgumentException("El archivo se pudo leer, pero contiene bytes que no forman texto UTF-8 válido. ProControl debe volver a exportar el permiso; no se importó nada.", error)
        }
        require(decoded.isNotBlank()) { "El archivo contiene texto vacío. No se importó ningún permiso." }
        return decoded
    } finally {
        bytes.fill(0)
    }
}

private fun formatPermitDate(timestamp: Long): String =
    java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT)
        .format(Date(timestamp))
