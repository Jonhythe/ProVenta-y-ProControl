package com.proventa.app.ui.screens

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.dao.ProVentaDao
import com.proventa.app.data.entities.GoodsReceiptEntity
import com.proventa.app.data.outbox.PackageAcknowledgementImporter
import com.proventa.app.data.receipts.GoodsDispatchQrAssembler
import com.proventa.app.data.receipts.GoodsReceiptService
import com.proventa.app.data.receipts.ReceiptStatus
import com.proventa.app.security.CurrentProVentaScopeProvider
import com.proventa.app.security.SignedDeviceOperationPackage
import com.proventa.app.ui.theme.Gold
import com.proventa.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.InputStream
import java.math.BigDecimal

private data class GoodsReceiptRowUi(
    val productId: String,
    val name: String,
    val quantity: String,
    val unit: String,
    val priceSummary: String
)

@Composable
fun GoodsReceiptsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scopeProvider = remember(context) { CurrentProVentaScopeProvider(context.applicationContext) }
    val qrAssembler = remember { GoodsDispatchQrAssembler() }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    var dao by remember { mutableStateOf<ProVentaDao?>(null) }
    var service by remember { mutableStateOf<GoodsReceiptService?>(null) }
    var acknowledgementImporter by remember { mutableStateOf<PackageAcknowledgementImporter?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Escanea el QR del despacho que preparó ProControl o importa su manifiesto desde USB.") }
    var scannerOpen by remember { mutableStateOf(false) }
    var scannerProgress by remember { mutableStateOf("Aún no se han leído fragmentos QR.") }
    var receipts by remember { mutableStateOf<List<GoodsReceiptEntity>>(emptyList()) }
    val confirmationCodes = remember { mutableStateMapOf<String, String>() }
    var packageToExport by remember { mutableStateOf<SignedDeviceOperationPackage?>(null) }
    var packageFileName by remember { mutableStateOf("ProVenta-Entrada.pcoutbox") }
    var acknowledgementReceiptId by remember { mutableStateOf<String?>(null) }

    suspend fun refreshReceipts() {
        val currentDao = dao ?: return
        receipts = withContext(Dispatchers.IO) {
            val active = scopeProvider.requireCurrent()
            currentDao.listGoodsReceipts(active.posId).filter { receipt ->
                runCatching {
                    val manifest = JSONObject(receipt.manifestJson)
                    manifest.optString("installationId") == active.installationId &&
                        manifest.optString("posId") == active.posId
                }.getOrDefault(false)
            }
        }
    }

    suspend fun importManifestText(rawJson: String, token: String?) {
        busy = true
        message = "Verificando firma del manifiesto, POS, productos y huella…"
        try {
            val result = withContext(Dispatchers.IO) {
                (service ?: throw IllegalStateException("La recepción todavía se está preparando."))
                    .importManifest(rawJson, token)
            }
            refreshReceipts()
            scannerProgress = "Manifiesto verificado."
            message = if (result.duplicate) {
                "Este despacho ya estaba importado. No se creó una segunda recepción."
            } else {
                "Despacho de " + result.posId + " verificado: " + result.productCount + " productos. Revisa cantidades y precios antes de confirmar."
            }
        } finally {
            busy = false
        }
    }

    val manifestLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val raw = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use {
                            readReceiptTextLimited(it, MAX_MANIFEST_BYTES)
                        } ?: throw IllegalStateException("No se pudo abrir el manifiesto.")
                    }
                    importManifestText(raw, null)
                } catch (error: Exception) {
                    message = error.message ?: "No se pudo importar el manifiesto de despacho."
                    busy = false
                }
            }
        }
    }

    val acknowledgementLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                try {
                    val raw = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use {
                            readReceiptTextLimited(it, MAX_ACK_BYTES)
                        } ?: throw IllegalStateException("No se pudo abrir el acuse.")
                    }
                    val document = JSONObject(raw)
                    val packageId = document.optString("packageId")
                    val packageEntity = withContext(Dispatchers.IO) {
                        (dao ?: throw IllegalStateException("La base local no está lista."))
                            .getOutboxPackage(packageId)
                    } ?: throw IllegalArgumentException("El acuse no corresponde a un paquete local.")
                    require(packageEntity.packageType == "goods_receipt") {
                        "Este acuse no pertenece a una recepción de mercancía."
                    }
                    val selectedReceipt = acknowledgementReceiptId
                    if (selectedReceipt != null) {
                        val receipt = withContext(Dispatchers.IO) {
                            (dao ?: throw IllegalStateException("La base local no está lista."))
                                .getGoodsReceipt(selectedReceipt)
                        } ?: throw IllegalArgumentException("No se encontró la recepción seleccionada.")
                        require(packageEntity.aggregateId == receipt.transferId) {
                            "El acuse corresponde a otro despacho."
                        }
                    }
                    val result = withContext(Dispatchers.IO) {
                        (acknowledgementImporter
                            ?: throw IllegalStateException("El verificador de acuses no está listo."))
                            .importAcknowledgement(raw)
                    }
                    refreshReceipts()
                    message = when (result.result) {
                        "applied" -> "ProControl confirmó la recepción. El stock local se actualizó solo si el snapshot era anterior al despacho; el inventario central no se volvió a mover."
                        "rejected" -> "ProControl rechazó la recepción. La evidencia se conserva para revisión."
                        "conflict" -> "ProControl detectó un conflicto. La evidencia se conserva y requiere revisión."
                        else -> "Acuse procesado: " + result.result
                    }
                } catch (error: Exception) {
                    message = error.message ?: "No se pudo verificar el acuse de ProControl."
                } finally {
                    busy = false
                }
            }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                try {
                    val selectedPackage = packageToExport
                        ?: throw IllegalStateException("No hay un paquete de entrada preparado.")
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri, "w")?.use { output ->
                            output.write(selectedPackage.envelopeJson.toByteArray(Charsets.UTF_8))
                            output.flush()
                        } ?: throw IllegalStateException("No se pudo guardar el archivo de salida.")
                    }
                    message = "Paquete firmado exportado. Copia " + packageFileName + " a la computadora mediante USB; conserva la recepción hasta importar el acuse .pcack."
                    packageToExport = null
                } catch (error: Exception) {
                    message = error.message ?: "No se pudo exportar el paquete de recepción."
                } finally {
                    busy = false
                }
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            qrAssembler.reset()
            scannerProgress = "Apunta a la cuadrícula QR de ProControl."
            scannerOpen = true
        } else {
            message = "La cámara no fue autorizada. Puedes importar el manifiesto firmado como archivo desde USB."
        }
    }

    LaunchedEffect(Unit) {
        busy = true
        try {
            val prepared = withContext(Dispatchers.IO) {
                val database = ProVentaDatabaseFactory.get(context.applicationContext)
                Triple(
                    database.proVentaDao(),
                    GoodsReceiptService(context.applicationContext),
                    PackageAcknowledgementImporter(context.applicationContext)
                )
            }
            dao = prepared.first
            service = prepared.second
            acknowledgementImporter = prepared.third
            refreshReceipts()
        } catch (error: Exception) {
            message = error.message ?: "No se pudo preparar el módulo de entradas."
        } finally {
            busy = false
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Entradas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Recepción de mercancía por QR o archivo USB, con doble confirmación y acuse firmado.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val granted = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.CAMERA
                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        if (granted) {
                            qrAssembler.reset()
                            scannerProgress = "Apunta a la cuadrícula QR de ProControl."
                            scannerOpen = true
                        } else {
                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) { Text("Escanear QR") }
                Button(
                    onClick = { manifestLauncher.launch(arrayOf("application/json", "text/plain")) },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) { Text("Importar USB") }
            }
        }
        if (scannerOpen) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Escaneo de despacho", fontWeight = FontWeight.Bold)
                        GoodsDispatchQrScanner(
                            onFrames = { decodedFrames ->
                                mainHandler.post {
                                    decodedFrames.filter { it.startsWith("PCQ1|T|") }.forEach { frame ->
                                        try {
                                            val progress = qrAssembler.add(frame)
                                            scannerProgress = "Fragmentos recibidos: " +
                                                progress.receivedFrames + " / " + progress.totalFrames
                                            val complete = progress.completeDocument
                                            if (complete != null && scannerOpen) {
                                                scannerOpen = false
                                                busy = true
                                                scope.launch {
                                                    try {
                                                        importManifestText(complete, progress.token)
                                                    } catch (error: Exception) {
                                                        message = error.message ?: "El manifiesto reconstruido no superó la verificación."
                                                        busy = false
                                                    }
                                                }
                                            }
                                        } catch (error: Exception) {
                                            scannerProgress = error.message ?: "Fragmento QR no válido."
                                        }
                                    }
                                }
                            },
                            onError = { error ->
                                mainHandler.post { scannerProgress = error }
                            }
                        )
                        Text(scannerProgress, color = Gold, style = MaterialTheme.typography.bodySmall)
                        Button(
                            onClick = {
                                scannerOpen = false
                                qrAssembler.reset()
                            },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                        ) { Text("Cerrar escáner") }
                    }
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Flujo protegido", fontWeight = FontWeight.SemiBold)
                    Text(
                        "El QR contiene el manifiesto firmado y la huella del código. El dependiente introduce aparte el código de ocho dígitos impreso por ProControl. La app no cambia el inventario central; ProControl valida y concilia la evidencia.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            Text("Recepciones", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        if (receipts.isEmpty()) {
            item {
                Text("Todavía no hay despachos importados.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
        }
        items(receipts, key = { it.receiptId }) { receipt ->
            GoodsReceiptCard(
                receipt = receipt,
                code = confirmationCodes[receipt.receiptId].orEmpty(),
                busy = busy,
                onCodeChange = { confirmationCodes[receipt.receiptId] = it.filter(Char::isDigit).take(8) },
                onReview = {
                    scope.launch {
                        busy = true
                        try {
                            withContext(Dispatchers.IO) {
                                (service ?: throw IllegalStateException("El módulo no está listo."))
                                    .markReviewed(receipt.receiptId)
                            }
                            refreshReceipts()
                            message = "Revisión guardada. Introduce el código de ocho dígitos que aparece debajo del QR en ProControl."
                        } catch (error: Exception) {
                            message = error.message ?: "No se pudo completar la revisión."
                        } finally {
                            busy = false
                        }
                    }
                },
                onConfirm = {
                    scope.launch {
                        busy = true
                        try {
                            val packageData = withContext(Dispatchers.IO) {
                                (service ?: throw IllegalStateException("El módulo no está listo."))
                                    .createConfirmationPackage(
                                        receipt.receiptId,
                                        confirmationCodes[receipt.receiptId].orEmpty()
                                    )
                            }
                            packageToExport = packageData
                            packageFileName = "ProVenta-Entrada-" + receipt.transferId + ".pcoutbox"
                            exportLauncher.launch(packageFileName)
                            refreshReceipts()
                            message = "Recepción verificada localmente y paquete firmado preparado. La recepción seguirá pendiente hasta el acuse final de ProControl."
                        } catch (error: Exception) {
                            message = error.message ?: "No se pudo preparar el paquete de recepción."
                        } finally {
                            busy = false
                        }
                    }
                },
                onExportAgain = {
                    scope.launch {
                        busy = true
                        try {
                            val stored = withContext(Dispatchers.IO) {
                                (dao ?: throw IllegalStateException("La base local no está lista."))
                                    .getOutboxPackageForAggregate(receipt.transferId, "goods_receipt")
                                    ?: throw IllegalStateException("No existe un paquete pendiente para este despacho.")
                            }
                            packageToExport = SignedDeviceOperationPackage(
                                packageId = stored.packageId,
                                deviceId = stored.deviceId,
                                type = stored.packageType,
                                payloadHash = stored.payloadHash,
                                createdAt = stored.createdAt,
                                envelopeJson = stored.envelopeJson
                            )
                            packageFileName = "ProVenta-Entrada-" + receipt.transferId + ".pcoutbox"
                            exportLauncher.launch(packageFileName)
                        } catch (error: Exception) {
                            message = error.message ?: "No se pudo recuperar el paquete pendiente."
                        } finally {
                            busy = false
                        }
                    }
                },
                onImportAck = {
                    acknowledgementReceiptId = receipt.receiptId
                    acknowledgementLauncher.launch(arrayOf("application/json", "text/plain"))
                }
            )
        }
        item {
            Text(message, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun GoodsReceiptCard(
    receipt: GoodsReceiptEntity,
    code: String,
    busy: Boolean,
    onCodeChange: (String) -> Unit,
    onReview: () -> Unit,
    onConfirm: () -> Unit,
    onExportAgain: () -> Unit,
    onImportAck: () -> Unit
) {
    val rows = remember(receipt.manifestJson) { parseGoodsReceiptRows(receipt.manifestJson) }
    val manifest = remember(receipt.manifestJson) {
        runCatching { JSONObject(receipt.manifestJson) }.getOrNull()
    }
    val posName = manifest?.optString("posName")?.takeIf { it.isNotBlank() } ?: receipt.posId

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(posName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text("Despacho " + receipt.transferId, color = TextSecondary, style = MaterialTheme.typography.labelSmall)
            Text(goodsReceiptStatusLabel(receipt.status), color = Gold, style = MaterialTheme.typography.labelMedium)
            rows.forEach { row ->
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(row.name + " · " + row.quantity + " " + row.unit, fontWeight = FontWeight.SemiBold)
                    Text(row.priceSummary, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    Text("ID: " + row.productId, color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (rows.isEmpty()) {
                Text("No se pudieron leer los productos del manifiesto.", color = MaterialTheme.colorScheme.error)
            }
            when (receipt.status) {
                ReceiptStatus.PENDING_REVIEW.name -> Button(
                    onClick = onReview,
                    enabled = !busy && rows.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                ) { Text("He revisado productos y cantidades") }

                ReceiptStatus.PENDING_OWNER_CONFIRMATION.name -> {
                    OutlinedTextField(
                        value = code,
                        onValueChange = onCodeChange,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        label = { Text("Código de confirmación (8 dígitos)") }
                    )
                    Button(
                        onClick = onConfirm,
                        enabled = !busy && code.length == 8,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                    ) { Text("Confirmar y preparar envío") }
                }

                ReceiptStatus.AWAITING_FINAL_ACK.name -> {
                    Text(
                        "El paquete debe importarse en ProControl. No se borra la recepción ni se modifica el stock local hasta verificar el acuse.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Button(
                        onClick = onExportAgain,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                    ) { Text("Exportar paquete .pcoutbox") }
                    Button(
                        onClick = onImportAck,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                    ) { Text("Importar acuse .pcack") }
                }

                ReceiptStatus.CONFIRMED.name -> Text(
                    "Recepción confirmada por ProControl. No se volvió a mover el inventario central.",
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodySmall
                )

                ReceiptStatus.DISCREPANCY.name,
                ReceiptStatus.REJECTED.name -> Text(
                    receipt.discrepancyReason ?: "ProControl requiere revisar esta recepción. La evidencia original se conserva.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private fun parseGoodsReceiptRows(rawJson: String): List<GoodsReceiptRowUi> = try {
    val items = JSONObject(rawJson).getJSONArray("items")
    (0 until items.length()).mapNotNull { index ->
        val item = items.optJSONObject(index) ?: return@mapNotNull null
        val currency = item.optString("saleCurrency", "USD")
        val custom = item.optString("saleCustomCurrency", "")
        val foreignLabel = if (currency == "OTRA") custom else currency
        val summary = "Efectivo CUP: " + formatDispatchNumber(item.opt("sale")) +
            " · Transferencia CUP: " + formatDispatchNumber(item.opt("saleTransf")) +
            " · " + foreignLabel + ": " + formatDispatchNumber(item.opt("saleUSD"))
        GoodsReceiptRowUi(
            productId = item.optString("productId"),
            name = item.optString("name"),
            quantity = formatDispatchNumber(item.opt("quantity")),
            unit = item.optString("unit"),
            priceSummary = summary
        )
    }
} catch (_: Exception) {
    emptyList()
}

private fun goodsReceiptStatusLabel(status: String): String = when (status) {
    ReceiptStatus.PENDING_REVIEW.name -> "Pendiente de revisar productos"
    ReceiptStatus.PENDING_OWNER_CONFIRMATION.name -> "Revisión completada · falta el código impreso"
    ReceiptStatus.AWAITING_FINAL_ACK.name -> "Enviado · pendiente de confirmación de ProControl"
    ReceiptStatus.CONFIRMED.name -> "Confirmado por ProControl"
    ReceiptStatus.DISCREPANCY.name -> "Conflicto · requiere revisión"
    ReceiptStatus.REJECTED.name -> "Rechazado por ProControl"
    else -> status
}

private fun formatDispatchNumber(value: Any?): String = try {
    if (value == null) "0"
    else BigDecimal(value.toString()).stripTrailingZeros().toPlainString()
} catch (_: Exception) {
    "0"
}

private fun readReceiptTextLimited(input: InputStream, maximumBytes: Int): String {
    val output = java.io.ByteArrayOutputStream()
    val buffer = ByteArray(4096)
    var total = 0
    while (true) {
        val count = input.read(buffer)
        if (count < 0) break
        total += count
        require(total <= maximumBytes) { "El archivo supera el tamaño permitido." }
        output.write(buffer, 0, count)
    }
    return output.toString(Charsets.UTF_8.name())
}

private const val MAX_MANIFEST_BYTES = 64 * 1024
private const val MAX_ACK_BYTES = 64 * 1024
