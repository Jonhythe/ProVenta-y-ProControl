package com.proventa.app.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.proventa.app.data.entities.GoodsReceiptEntity
import com.proventa.app.data.entities.InventorySnapshotEntity
import com.proventa.app.data.entities.OutboxOperationEntity
import com.proventa.app.data.entities.OutboxPackageEntity
import com.proventa.app.data.entities.ProductEntity
import com.proventa.app.data.entities.SaleCurrencyTotalEntity
import com.proventa.app.data.entities.SaleEntity
import com.proventa.app.data.entities.SaleLineEntity
import com.proventa.app.data.entities.SalePaymentEntity
import com.proventa.app.data.entities.ShiftPermitEntity
import com.proventa.app.data.entities.ShiftCloseDraftEntity
import com.proventa.app.data.shifts.ShiftProductSalesSummary
import com.proventa.app.data.shifts.ShiftPaymentSummary
import com.proventa.app.data.money.MoneyMath
import com.proventa.app.data.receipts.GoodsReceiptWorkflow
import com.proventa.app.data.receipts.ReceiptStatus
import com.proventa.app.data.receipts.VerifiedFinalAuthorization
import com.proventa.app.data.sales.SaleStatus
import com.proventa.app.security.VerifiedPackageAcknowledgement
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest
import java.time.Instant
import org.json.JSONObject

@Dao
interface ProVentaDao {
    private fun sha256ReceiptAuthorization(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    @Query("SELECT * FROM products WHERE posId = :posId AND productId = :productId AND active = 1 LIMIT 1")
    suspend fun getActiveProduct(posId: String, productId: String): ProductEntity?

    @Query("""
        UPDATE products
        SET availableQuantityMicros = :newQuantity
        WHERE posId = :posId
          AND productId = :productId
          AND active = 1
          AND availableQuantityMicros = :expectedQuantity
    """)
    suspend fun updateAvailableQuantity(
        posId: String,
        productId: String,
        expectedQuantity: Long,
        newQuantity: Long
    ): Int

    @Query("SELECT * FROM products WHERE posId = :posId AND active = 1 ORDER BY name COLLATE NOCASE")
    fun observeProducts(posId: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE posId = :posId AND active = 1 ORDER BY name COLLATE NOCASE")
    suspend fun listActiveProducts(posId: String): List<ProductEntity>

    @Query("""
        SELECT l.productId AS productId, COALESCE(SUM(l.quantityMicros), 0) AS quantityMicros
        FROM sale_lines l
        INNER JOIN sales s ON s.saleId = l.saleId
        WHERE s.shiftId = :shiftId AND s.posId = :posId
          AND s.status IN ('PENDING_SYNC', 'SYNCED')
        GROUP BY l.productId
    """)
    suspend fun getShiftProductSalesSummary(shiftId: String, posId: String): List<ShiftProductSalesSummary>

    @Query("""
        SELECT l.currency AS currency, p.method AS method,
               COALESCE(SUM(p.amountMinor), 0) AS amountMinor,
               l.currencyScale AS currencyScale
        FROM sales s
        INNER JOIN sale_lines l ON l.saleId = s.saleId
        INNER JOIN sale_payments p ON p.saleLineId = l.lineId
        WHERE s.shiftId = :shiftId AND s.posId = :posId
          AND s.status IN ('PENDING_SYNC', 'SYNCED')
        GROUP BY l.currency, p.method, l.currencyScale
        ORDER BY l.currency, p.method
    """)
    suspend fun getShiftPaymentSummary(shiftId: String, posId: String): List<ShiftPaymentSummary>

    @Query("""
        SELECT * FROM products
        WHERE posId = :posId AND active = 1
          AND (name LIKE '%' || :query || '%' OR productId LIKE '%' || :query || '%')
        ORDER BY name COLLATE NOCASE
        LIMIT 60
    """)
    suspend fun searchProducts(posId: String, query: String): List<ProductEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun replaceProducts(products: List<ProductEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveInventorySnapshot(snapshot: InventorySnapshotEntity)

    @Query("SELECT * FROM inventory_snapshots ORDER BY importedAt DESC")
    suspend fun listInventorySnapshots(): List<InventorySnapshotEntity>

    @Query("SELECT * FROM inventory_snapshots WHERE posId = :posId AND installationId = :installationId AND deviceId = :deviceId LIMIT 1")
    suspend fun getInventorySnapshotForScope(posId: String, installationId: String, deviceId: String): InventorySnapshotEntity?

    @Query("SELECT * FROM inventory_snapshots WHERE posId = :posId LIMIT 1")
    suspend fun getInventorySnapshot(posId: String): InventorySnapshotEntity?

    @Query("SELECT * FROM inventory_snapshots WHERE packageId = :packageId LIMIT 1")
    suspend fun getInventorySnapshotByPackageId(packageId: String): InventorySnapshotEntity?

    @Transaction
    suspend fun applyInventorySnapshot(
        snapshot: InventorySnapshotEntity,
        products: List<ProductEntity>
    ): Boolean {
        require(snapshot.productCount == products.size) { "El recuento de productos no coincide con el snapshot." }
        require(products.map { it.productId }.distinct().size == products.size) {
            "El snapshot contiene identificadores de producto duplicados."
        }
        require(products.all { it.posId == snapshot.posId && it.catalogRevision == snapshot.payloadHash }) {
            "El snapshot contiene productos de otro POS o de otra revisión."
        }
        require(snapshot.posId.isNotBlank() && snapshot.installationId.isNotBlank() &&
            snapshot.deviceId.isNotBlank() && snapshot.packageId.isNotBlank() &&
            snapshot.payloadHash.matches(Regex("[a-f0-9]{64}")) && snapshot.generatedAt > 0L) {
            "El snapshot no contiene una identidad, huella o fecha válidas."
        }
        val alreadyApplied = getInventorySnapshotByPackageId(snapshot.packageId)
        if (alreadyApplied != null) {
            require(
                alreadyApplied.posId == snapshot.posId &&
                    alreadyApplied.installationId == snapshot.installationId &&
                    alreadyApplied.deviceId == snapshot.deviceId &&
                    alreadyApplied.payloadHash == snapshot.payloadHash
            ) { "El identificador de paquete ya fue usado con otro contenido o alcance." }
            return false
        }
        val currentSnapshot = getInventorySnapshot(snapshot.posId)
        if (currentSnapshot != null) {
            require(
                currentSnapshot.installationId == snapshot.installationId &&
                    currentSnapshot.deviceId == snapshot.deviceId
            ) { "El POS ya contiene inventario vinculado a otra instalación o teléfono. No se sobrescribió." }
            if (currentSnapshot.payloadHash == snapshot.payloadHash) {
                // Identical stock may arrive in a newer signed export. Refresh its
                // source timestamp so later dispatch reconciliation knows that
                // this snapshot already includes events preceding that export.
                if (snapshot.generatedAt > currentSnapshot.generatedAt) {
                    saveInventorySnapshot(snapshot)
                }
                return false
            }
            require(snapshot.generatedAt > currentSnapshot.generatedAt) {
                "El inventario recibido es anterior o tiene la misma fecha que el inventario ya aplicado. Se rechazó para evitar una reversión."
            }
        }
        replaceProducts(products)
        deleteProductsOutsideRevision(snapshot.posId, snapshot.payloadHash)
        saveInventorySnapshot(snapshot)
        return true
    }

    @Query("DELETE FROM products WHERE posId = :posId AND catalogRevision != :revision")
    suspend fun deleteProductsOutsideRevision(posId: String, revision: String)

    @Query("""
        SELECT * FROM shift_permits
        WHERE posId = :posId
          AND installationId = :installationId
          AND authorizationId = :authorizationId
          AND deviceId = :deviceId
          AND status = 'OPENED'
          AND shiftId IS NOT NULL
          AND startsAt <= :now
          AND endsAt > :now
        ORDER BY sequence DESC
        LIMIT 1
    """)
    suspend fun getConfirmedShiftPermit(
        posId: String,
        installationId: String,
        authorizationId: String,
        deviceId: String,
        now: Long
    ): ShiftPermitEntity?

    @Query("""
        SELECT COALESCE(SUM(
            (
                SELECT COUNT(*) FROM (
                    SELECT l.currency, p.method
                    FROM sale_lines l
                    INNER JOIN sale_payments p ON p.saleLineId = l.lineId
                    WHERE l.saleId = sales.saleId
                    GROUP BY l.currency, p.method
                )
            )
        ), 0)
        FROM sales
        WHERE shiftId = :shiftId AND posId = :posId
    """)
    suspend fun countShiftSales(shiftId: String, posId: String): Int

    @Query("UPDATE products SET availableQuantityMicros = availableQuantityMicros - :quantityMicros WHERE posId = :posId AND productId = :productId AND active = 1 AND availableQuantityMicros >= :quantityMicros")
    suspend fun deductLocalStock(posId: String, productId: String, quantityMicros: Long): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertSale(sale: SaleEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertSaleTotals(totals: List<SaleCurrencyTotalEntity>)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertSaleLines(lines: List<SaleLineEntity>)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPayments(payments: List<SalePaymentEntity>)

    @Transaction
    suspend fun saveSaleBundle(
        sale: SaleEntity,
        lines: List<SaleLineEntity>,
        totals: List<SaleCurrencyTotalEntity>,
        payments: List<SalePaymentEntity>,
        outboxPackage: OutboxPackageEntity? = null
    ) {
        require(sale.status in SaleStatus.entries.map { it.name }) { "Estado de venta no reconocido." }
        require(lines.isNotEmpty()) { "La venta debe contener al menos un producto." }
        require(lines.all { it.saleId == sale.saleId }) { "Hay líneas que pertenecen a otra venta." }
        require(lines.all { line ->
            line.quantityMicros > 0 &&
                line.unitPriceMinor >= 0 &&
                line.lineTotalMinor == MoneyMath.lineTotalMinor(line.unitPriceMinor, line.quantityMicros)
        }) { "La venta contiene cantidades o importes inválidos." }
        require(totals.isNotEmpty() && totals.all { it.saleId == sale.saleId }) {
            "La venta debe tener totales por moneda válidos."
        }
        require(totals.all { it.amountMinor >= 0 && it.currencyScale in 0..6 }) {
            "Hay totales con importe o escala monetaria inválidos."
        }
        require(lines.all { line -> totals.any { it.currency == line.currency && it.currencyLabel == line.currencyLabel && it.currencyScale == line.currencyScale } }) {
            "La escala de moneda de los totales no coincide con las líneas."
        }
        require(totals.map { it.currency }.distinct().size == totals.size) {
            "Hay totales duplicados para una misma moneda."
        }
        val calculatedTotals = lines.groupBy { it.currency }.mapValues { (_, currencyLines) ->
            MoneyMath.sumMinorAmounts(currencyLines.map { it.lineTotalMinor })
        }
        val declaredTotals = totals.associate { it.currency to it.amountMinor }
        require(calculatedTotals == declaredTotals) {
            "Los totales por moneda no coinciden con las líneas de la venta."
        }
        require(payments.all { payment -> lines.any { it.lineId == payment.saleLineId } }) {
            "Hay pagos asociados a una línea inexistente."
        }
        val linesById = lines.associateBy { it.lineId }
        require(payments.all { payment ->
            val line = linesById[payment.saleLineId]!!
            payment.amountMinor > 0 &&
                payment.currency == line.currency &&
                payment.currencyScale == line.currencyScale
        }) { "Hay pagos con importe o moneda inválidos." }
        require(payments.all { payment ->
            payment.method in setOf("CASH", "TRANSFER") &&
                (payment.method != "TRANSFER" ||
                    (!payment.transferPhone.isNullOrBlank() && !payment.transferOperationNumber.isNullOrBlank()))
        }) { "Los pagos por transferencia requieren teléfono y número de operación." }
        val paymentsByLine = payments.groupBy { it.saleLineId }
        require(paymentsByLine.all { (lineId, linePayments) ->
            MoneyMath.sumMinorAmounts(linePayments.map { it.amountMinor }) <=
                linesById[lineId]!!.lineTotalMinor
        }) { "Los pagos superan el importe de una línea." }
        if (sale.status != SaleStatus.DRAFT.name) {
            require(lines.all { line ->
                paymentsByLine[line.lineId]?.let { linePayments -> MoneyMath.sumMinorAmounts(linePayments.map { it.amountMinor }) } == line.lineTotalMinor
            }) { "Una venta completada debe tener todos sus importes pagados." }
        }

        lines.forEach { line ->
            require(deductLocalStock(sale.posId, line.productId, line.quantityMicros) == 1) {
                "No hay existencias suficientes de " + line.productNameSnapshot + " o el inventario cambió."
            }
        }
        insertSale(sale)
        insertSaleLines(lines)
        insertSaleTotals(totals)
        if (payments.isNotEmpty()) insertPayments(payments)
        if (outboxPackage != null) {
            require(outboxPackage.packageType == "sale_batch" && outboxPackage.aggregateId == sale.saleId) {
                "El paquete de ventas no está vinculado a la venta guardada."
            }
            insertOutboxPackage(outboxPackage)
        }
    }

    @Query("SELECT * FROM sale_currency_totals WHERE saleId = :saleId ORDER BY currency")
    suspend fun getSaleCurrencyTotals(saleId: String): List<SaleCurrencyTotalEntity>

    @Query("SELECT * FROM sales WHERE saleId = :saleId LIMIT 1")
    suspend fun getSale(saleId: String): SaleEntity?

    @Query("""
        UPDATE sales
        SET status = :newStatus, updatedAt = :updatedAt
        WHERE saleId = :saleId AND status = 'PENDING_SYNC'
    """)
    suspend fun updateSaleSyncStatus(saleId: String, newStatus: String, updatedAt: Long): Int

    @Query("""
        SELECT COUNT(*) FROM sales s
        WHERE s.posId = :posId
          AND s.status = 'PENDING_SYNC'
          AND NOT EXISTS (
              SELECT 1 FROM outbox_packages p
              WHERE p.aggregateId = s.saleId AND p.packageType = 'sale_batch'
          )
    """)
    suspend fun countPendingSalesWithoutPackage(posId: String): Int

    @Query("""
        SELECT COUNT(*) FROM outbox_packages p
        INNER JOIN sales s ON s.saleId = p.aggregateId
        WHERE s.posId = :posId
          AND p.packageType = 'sale_batch'
          AND p.status IN ('REJECTED', 'CONFLICT')
    """)
    suspend fun countSalePackagesNeedingReview(posId: String): Int

    @Query("SELECT COUNT(*) FROM sales WHERE posId=:posId AND status != 'SYNCED'")
    suspend fun countSalesNotSynced(posId: String): Int

    @Query("""
        SELECT p.* FROM outbox_packages p
        INNER JOIN sales s ON s.saleId = p.aggregateId
        WHERE s.posId = :posId
          AND p.packageType = 'sale_batch'
          AND p.status = 'PENDING'
        ORDER BY p.createdAt ASC
    """)
    suspend fun listPendingSalePackages(posId: String): List<OutboxPackageEntity>

    @Query("SELECT * FROM sales WHERE posId = :posId AND shiftId = :shiftId ORDER BY createdAt DESC")
    fun observeShiftSales(posId: String, shiftId: String): Flow<List<SaleEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertOutboxPackage(packageEntity: OutboxPackageEntity)

    @Query("SELECT * FROM outbox_packages WHERE packageId = :packageId LIMIT 1")
    suspend fun getOutboxPackage(packageId: String): OutboxPackageEntity?

    @Query("SELECT * FROM outbox_packages WHERE aggregateId = :aggregateId AND packageType = :packageType ORDER BY createdAt DESC LIMIT 1")
    suspend fun getOutboxPackageForAggregate(aggregateId: String, packageType: String): OutboxPackageEntity?

    @Query("SELECT * FROM outbox_packages WHERE status = 'PENDING' ORDER BY createdAt ASC")
    suspend fun listPendingOutboxPackages(): List<OutboxPackageEntity>

    @Query("""
        UPDATE shift_permits
        SET status = :newStatus, shiftId = COALESCE(:shiftId, shiftId)
        WHERE permitId = :permitId AND status = :expectedStatus
    """)
    suspend fun updateShiftPermitStatus(
        permitId: String,
        expectedStatus: String,
        newStatus: String,
        shiftId: String?
    ): Int

    @Transaction
    suspend fun storeShiftOpenPackage(
        permitId: String,
        shiftId: String,
        packageEntity: OutboxPackageEntity
    ) {
        require(packageEntity.packageType == "shift_open" && packageEntity.aggregateId == permitId) {
            "El paquete no corresponde a la apertura de este permiso."
        }
        val existing = getOutboxPackageForAggregate(permitId, "shift_open")
        if (existing != null) {
            require(existing.packageId == packageEntity.packageId && existing.envelopeJson == packageEntity.envelopeJson) {
                "Este permiso ya tiene otra solicitud de apertura."
            }
            return
        }
        val updated = updateShiftPermitStatus(
            permitId = permitId,
            expectedStatus = "ISSUED",
            newStatus = "OPEN_PENDING_REVIEW",
            shiftId = shiftId
        )
        require(updated == 1) { "El permiso ya no está disponible para abrir el turno." }
        insertOutboxPackage(packageEntity)
    }

    @Query("""
        UPDATE outbox_packages
        SET status = :status,
            acknowledgementJson = :acknowledgementJson,
            acknowledgedAt = :acknowledgedAt
        WHERE packageId = :packageId AND acknowledgementJson IS NULL
    """)
    suspend fun updateOutboxPackageAcknowledgement(
        packageId: String,
        status: String,
        acknowledgementJson: String,
        acknowledgedAt: Long
    ): Int

    @Transaction
    suspend fun applyPackageAcknowledgement(
        acknowledgement: VerifiedPackageAcknowledgement
    ): Boolean {
        val packageEntity = getOutboxPackage(acknowledgement.packageId)
            ?: throw IllegalArgumentException("No existe el paquete de salida al que pertenece este acuse.")
        require(
            packageEntity.deviceId == acknowledgement.deviceId &&
                packageEntity.packageType == acknowledgement.packageType &&
                packageEntity.payloadHash == acknowledgement.payloadHash
        ) { "El acuse no coincide con el paquete local." }
        if (packageEntity.acknowledgementJson != null) {
            require(packageEntity.acknowledgementJson == acknowledgement.rawJson) {
                "El paquete ya tiene un acuse diferente."
            }
            return false
        }
        val localStatus = when (acknowledgement.result) {
            "applied" -> "APPLIED"
            "rejected" -> "REJECTED"
            "conflict" -> "CONFLICT"
            else -> throw IllegalArgumentException("Resultado de acuse no reconocido.")
        }
        val updated = updateOutboxPackageAcknowledgement(
            packageId = acknowledgement.packageId,
            status = localStatus,
            acknowledgementJson = acknowledgement.rawJson,
            acknowledgedAt = acknowledgement.acknowledgedAt
        )
        require(updated == 1) { "El acuse ya fue procesado." }

        if (packageEntity.packageType == "shift_open") {
            val permitId = packageEntity.aggregateId
                ?: throw IllegalStateException("El paquete de apertura no tiene permiso asociado.")
            val nextPermitStatus = if (acknowledgement.result == "applied") "OPENED" else "REJECTED"
            require(updateShiftPermitStatus(
                permitId,
                "OPEN_PENDING_REVIEW",
                nextPermitStatus,
                null
            ) == 1) { "El permiso ya no está pendiente de confirmación." }
        } else if (packageEntity.packageType == "shift_close") {
            val permitId = packageEntity.aggregateId
                ?: throw IllegalStateException("El paquete de cierre no tiene permiso asociado.")
            val nextPermitStatus = if (acknowledgement.result == "applied") "COMPLETED" else "OPENED"
            require(updateShiftPermitStatus(
                permitId,
                "CLOSE_PENDING",
                nextPermitStatus,
                null
            ) == 1) { "El permiso ya no está pendiente de cierre." }
            if (acknowledgement.result == "applied") deleteShiftCloseDraft(permitId)
        } else if (packageEntity.packageType == "sale_batch") {
            val saleId = packageEntity.aggregateId
                ?: throw IllegalStateException("El paquete de ventas no tiene una venta asociada.")
            val nextSaleStatus = if (acknowledgement.result == "applied") "SYNCED" else "REJECTED"
            require(updateSaleSyncStatus(saleId, nextSaleStatus, acknowledgement.acknowledgedAt) == 1) {
                "La venta no está pendiente de sincronización o ya cambió de estado."
            }
        } else if (packageEntity.packageType == "goods_receipt") {
            val dispatchId = packageEntity.aggregateId
                ?: throw IllegalStateException("El paquete de recepción no tiene un despacho asociado.")
            val receipt = getReceiptByTransferId(dispatchId)
                ?: throw IllegalStateException("No existe la recepción local asociada al paquete.")
            if (acknowledgement.result == "applied") {
                val manifest = JSONObject(receipt.manifestJson)
                val authorization = VerifiedFinalAuthorization(
                    transferId = dispatchId,
                    packageHash = packageEntity.payloadHash,
                    authorizationHash = sha256ReceiptAuthorization(acknowledgement.rawJson),
                    installationId = manifest.optString("installationId"),
                    deviceId = packageEntity.deviceId
                )
                require(confirmGoodsReceipt(
                    receipt.receiptId,
                    authorization,
                    acknowledgement.acknowledgedAt
                ) == 1) {
                    "El acuse final no coincide con la recepción pendiente."
                }
            } else {
                val nextReceiptStatus = if (acknowledgement.result == "conflict") {
                    ReceiptStatus.DISCREPANCY
                } else {
                    ReceiptStatus.REJECTED
                }
                GoodsReceiptWorkflow.requireTransition(
                    ReceiptStatus.AWAITING_FINAL_ACK,
                    nextReceiptStatus
                )
                val explanation = if (acknowledgement.result == "conflict") {
                    "ProControl detectó un conflicto al conciliar la recepción."
                } else {
                    "ProControl rechazó la recepción. Revisa el despacho en la computadora."
                }
                require(updateReceiptFinalDecision(
                    receipt.receiptId,
                    nextReceiptStatus.name,
                    explanation,
                    acknowledgement.acknowledgedAt
                ) == 1) {
                    "La recepción ya no estaba pendiente de confirmación."
                }
            }
        }
        return true
    }

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertShiftPermit(permit: ShiftPermitEntity)

    @Query("""
        SELECT * FROM shift_permits
        WHERE installationId = :installationId
          AND authorizationId = :authorizationId
          AND posId = :posId
          AND deviceId = :deviceId
        ORDER BY importedAt DESC
    """)
    suspend fun listShiftPermits(
        installationId: String,
        authorizationId: String,
        posId: String,
        deviceId: String
    ): List<ShiftPermitEntity>

    @Query("""
        SELECT * FROM shift_permits
        WHERE installationId = :installationId
          AND authorizationId = :authorizationId
          AND deviceId = :deviceId
        ORDER BY importedAt DESC
    """)
    suspend fun listShiftPermitsForDevice(
        installationId: String,
        authorizationId: String,
        deviceId: String
    ): List<ShiftPermitEntity>

    @Query("""
        SELECT * FROM shift_permits
        WHERE installationId = :installationId
          AND authorizationId = :authorizationId
          AND deviceId = :deviceId
          AND permitId != :excludingPermitId
          AND (
              status IN ('OPEN_PENDING_REVIEW', 'OPENED', 'CLOSE_PENDING')
              OR (status = 'ISSUED' AND startsAt <= :now AND endsAt > :now)
          )
        ORDER BY importedAt DESC
    """)
    suspend fun listActiveShiftPermitsForDevice(
        installationId: String,
        authorizationId: String,
        deviceId: String,
        excludingPermitId: String,
        now: Long
    ): List<ShiftPermitEntity>

    @Query("SELECT * FROM shift_close_drafts WHERE permitId = :permitId LIMIT 1")
    suspend fun getShiftCloseDraft(permitId: String): ShiftCloseDraftEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveShiftCloseDraft(draft: ShiftCloseDraftEntity)

    @Query("DELETE FROM shift_close_drafts WHERE permitId = :permitId")
    suspend fun deleteShiftCloseDraft(permitId: String)

    @Transaction
    suspend fun storeShiftClosePackage(
        permitId: String,
        packageEntity: OutboxPackageEntity
    ) {
        require(packageEntity.packageType == "shift_close" && packageEntity.aggregateId == permitId) {
            "El paquete de cierre no corresponde al permiso seleccionado."
        }
        val permit = getShiftPermit(permitId)
            ?: throw IllegalArgumentException("No se encontró el permiso del turno.")
        require(permit.shiftId.isNullOrBlank().not() && permit.shiftId == readShiftId(packageEntity.envelopeJson)) {
            "El paquete no corresponde al ID del turno autorizado."
        }
        val existing = getOutboxPackageForAggregate(permitId, "shift_close")
        if (existing != null && existing.acknowledgementJson == null && existing.status == "PENDING") {
            require(existing.packageId == packageEntity.packageId && existing.envelopeJson == packageEntity.envelopeJson) {
                "Ya existe otra solicitud de cierre pendiente para este turno."
            }
            return
        }
        require(permit.status == "OPENED") {
            "El turno no está abierto o ya tiene una solicitud de cierre pendiente."
        }
        val updated = updateShiftPermitStatus(
            permitId = permitId,
            expectedStatus = "OPENED",
            newStatus = "CLOSE_PENDING",
            shiftId = permit.shiftId
        )
        require(updated == 1) { "El turno cambió de estado antes de guardar el cierre." }
        insertOutboxPackage(packageEntity)
    }

    private fun readShiftId(envelopeJson: String): String {
        val envelope = JSONObject(envelopeJson)
        val shift = envelope.optJSONObject("payload")?.optJSONObject("shift")
            ?: throw IllegalArgumentException("El paquete de cierre no contiene el turno.")
        return shift.optString("id")
    }

    @Query("SELECT * FROM shift_permits WHERE permitId = :permitId LIMIT 1")
    suspend fun getShiftPermit(permitId: String): ShiftPermitEntity?

    @Query("SELECT MAX(sequence) FROM shift_permits WHERE posId = :posId AND deviceId = :deviceId")
    suspend fun getMaxShiftSequence(posId: String, deviceId: String): Long?

    @Query("""
        SELECT * FROM shift_permits
        WHERE posId = :posId
          AND (
              status IN ('OPEN_PENDING_REVIEW', 'OPENED', 'CLOSE_PENDING')
              OR (status = 'ISSUED' AND endsAt > :now)
          )
        ORDER BY sequence DESC
        LIMIT 1
    """)
    suspend fun getActiveShiftPermit(posId: String, now: Long): ShiftPermitEntity?

    @Query("SELECT * FROM shift_permits WHERE posId = :posId ORDER BY sequence DESC")
    fun observeShiftPermits(posId: String): Flow<List<ShiftPermitEntity>>

    @Transaction
    suspend fun importShiftPermit(permit: ShiftPermitEntity): Boolean {
        val existing = getShiftPermit(permit.permitId)
        if (existing != null) {
            require(existing.permitJson == permit.permitJson) {
                "El identificador del permiso ya existe con otro contenido."
            }
            return false
        }
        val maxSequence = getMaxShiftSequence(permit.posId, permit.deviceId) ?: 0L
        require(permit.sequence > maxSequence) {
            "La secuencia del permiso no es posterior a la última recibida."
        }
        require(getActiveShiftPermit(permit.posId, permit.importedAt) == null) {
            "Este punto de venta ya tiene un turno o permiso activo."
        }
        val deviceHasOtherActiveShift = listActiveShiftPermitsForDevice(
            installationId = permit.installationId,
            authorizationId = permit.authorizationId,
            deviceId = permit.deviceId,
            excludingPermitId = permit.permitId,
            now = permit.importedAt
        ).isNotEmpty()
        require(!deviceHasOtherActiveShift) {
            "Este teléfono ya tiene un permiso o turno activo en otro punto de venta. Debe terminar o resolverse primero el turno anterior."
        }
        insertShiftPermit(permit)
        return true
    }

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertGoodsReceipt(receipt: GoodsReceiptEntity)

    @Query("SELECT * FROM goods_receipts WHERE transferId = :transferId LIMIT 1")
    suspend fun getReceiptByTransferId(transferId: String): GoodsReceiptEntity?

    @Query("SELECT * FROM goods_receipts WHERE receiptId = :receiptId LIMIT 1")
    suspend fun getGoodsReceipt(receiptId: String): GoodsReceiptEntity?

    @Query("SELECT * FROM goods_receipts WHERE posId = :posId ORDER BY createdAt DESC")
    suspend fun listGoodsReceipts(posId: String): List<GoodsReceiptEntity>

    @Query("""
        SELECT * FROM goods_receipts
        WHERE posId = :posId
          AND status = 'CONFIRMED'
          AND confirmedAt IS NOT NULL
          AND confirmedAt > :afterMillis
        ORDER BY confirmedAt ASC
    """)
    suspend fun listConfirmedShiftGoodsReceipts(posId: String, afterMillis: Long): List<GoodsReceiptEntity>

    @Transaction
    suspend fun storeGoodsReceiptManifest(receipt: GoodsReceiptEntity): Boolean {
        require(receipt.receiptId.isNotBlank() && receipt.transferId.isNotBlank() &&
            receipt.posId.isNotBlank() && receipt.manifestJson.isNotBlank()) {
            "El manifiesto de recepción no contiene sus identificadores o contenido firmado."
        }
        val existing = getReceiptByTransferId(receipt.transferId)
        if (existing != null) {
            require(existing.posId == receipt.posId &&
                existing.confirmationCodeHash == receipt.confirmationCodeHash &&
                existing.manifestJson == receipt.manifestJson) {
                "El identificador del despacho ya existe con otro contenido."
            }
            return false
        }
        insertGoodsReceipt(receipt)
        return true
    }

    @Query("""
        UPDATE goods_receipts
        SET status = 'AWAITING_FINAL_ACK',
            packageHash = :payloadHash,
            updatedAt = :updatedAt
        WHERE receiptId = :receiptId AND status = 'PENDING_OWNER_CONFIRMATION'
    """)
    suspend fun updateGoodsReceiptPackage(
        receiptId: String,
        payloadHash: String,
        updatedAt: Long
    ): Int

    @Transaction
    suspend fun storeGoodsReceiptPackage(
        dispatchId: String,
        packageEntity: OutboxPackageEntity,
        updatedAt: Long
    ) {
        require(packageEntity.packageType == "goods_receipt" && packageEntity.aggregateId == dispatchId) {
            "El paquete firmado no corresponde al despacho seleccionado."
        }
        val receipt = getReceiptByTransferId(dispatchId)
            ?: throw IllegalArgumentException("No existe el manifiesto de recepción importado.")
        val existing = getOutboxPackageForAggregate(dispatchId, "goods_receipt")
        if (existing != null) {
            require(existing.packageId == packageEntity.packageId &&
                existing.payloadHash == packageEntity.payloadHash &&
                existing.envelopeJson == packageEntity.envelopeJson) {
                "Este despacho ya tiene otro paquete de recepción pendiente."
            }
            return
        }
        require(receipt.status == "PENDING_OWNER_CONFIRMATION") {
            "La recepción no está lista para enviarse a ProControl."
        }
        val updated = updateGoodsReceiptPackage(
            receiptId = receipt.receiptId,
            payloadHash = packageEntity.payloadHash,
            updatedAt = updatedAt
        )
        require(updated == 1) { "La recepción cambió de estado antes de guardar su paquete." }
        insertOutboxPackage(packageEntity)
    }

    @Query("""
        UPDATE goods_receipts
        SET status = :newStatus, updatedAt = :updatedAt
        WHERE receiptId = :receiptId
          AND status = :expectedStatus
          AND (
              (:expectedStatus = 'PENDING_REVIEW' AND :newStatus IN ('PENDING_OWNER_CONFIRMATION', 'DISCREPANCY', 'REJECTED'))
              OR (:expectedStatus = 'PENDING_OWNER_CONFIRMATION' AND :newStatus IN ('AWAITING_FINAL_ACK', 'DISCREPANCY', 'REJECTED'))
              OR (:expectedStatus = 'AWAITING_FINAL_ACK' AND :newStatus IN ('DISCREPANCY', 'REJECTED'))
          )
    """)
    suspend fun updateReceiptState(
        receiptId: String,
        expectedStatus: String,
        newStatus: String,
        updatedAt: Long
    ): Int

    @Transaction
    suspend fun transitionReceipt(
        receiptId: String,
        expectedStatus: String,
        newStatus: String,
        updatedAt: Long
    ): Int {
        val from = ReceiptStatus.valueOf(expectedStatus)
        val to = ReceiptStatus.valueOf(newStatus)
        GoodsReceiptWorkflow.requireTransition(from, to)
        return updateReceiptState(receiptId, expectedStatus, newStatus, updatedAt)
    }

    /**
     * Only a verifier-produced authorization token can complete a receipt.
     * The transfer ID and original package hash must match the pending receipt.
     */
    @Query("""
        UPDATE goods_receipts
        SET status = :newStatus,
            discrepancyReason = :reason,
            updatedAt = :updatedAt
        WHERE receiptId = :receiptId
          AND status = 'AWAITING_FINAL_ACK'
    """)
    suspend fun updateReceiptFinalDecision(
        receiptId: String,
        newStatus: String,
        reason: String,
        updatedAt: Long
    ): Int

    @Query("""
        UPDATE goods_receipts
        SET status = 'CONFIRMED',
            finalAuthorizationHash = :authorizationHash,
            confirmedAt = :updatedAt,
            updatedAt = :updatedAt
        WHERE receiptId = :receiptId
          AND transferId = :transferId
          AND packageHash = :packageHash
          AND status = 'AWAITING_FINAL_ACK'
    """)
    suspend fun updateReceiptWithFinalAuthorization(
        receiptId: String,
        transferId: String,
        packageHash: String,
        authorizationHash: String,
        updatedAt: Long
    ): Int

    @Transaction
    suspend fun confirmGoodsReceipt(
        receiptId: String,
        authorization: VerifiedFinalAuthorization,
        updatedAt: Long
    ): Int {
        require(authorization.authorizationHash.isNotBlank()) {
            "El acuse final no tiene hash de autorización."
        }
        val receipt = getGoodsReceipt(receiptId)
            ?: throw IllegalArgumentException("No existe la recepción que se va a confirmar.")
        GoodsReceiptWorkflow.requireTransition(
            ReceiptStatus.valueOf(receipt.status),
            ReceiptStatus.CONFIRMED,
            finalAuthorizationValidated = true
        )
        require(receipt.status == ReceiptStatus.AWAITING_FINAL_ACK.name &&
            receipt.transferId == authorization.transferId &&
            receipt.packageHash == authorization.packageHash) {
            "El acuse final no corresponde a este despacho y paquete firmado."
        }

        val manifest = JSONObject(receipt.manifestJson)
        require(
            manifest.optString("dispatchId") == receipt.transferId &&
                manifest.optString("posId") == receipt.posId &&
                manifest.optString("installationId") == authorization.installationId &&
                manifest.optString("itemsHash").matches(Regex("[a-f0-9]{64}"))
        ) {
            "El manifiesto de recepción no coincide con el despacho, POS o instalación autorizados."
        }
        val dispatchCreatedAt = Instant.parse(manifest.getString("createdAt")).toEpochMilli()
        val currentSnapshot = getInventorySnapshotForScope(
            posId = receipt.posId,
            installationId = authorization.installationId,
            deviceId = authorization.deviceId
        ) ?: throw IllegalStateException("No existe un inventario local para la instalación y el teléfono que recibieron esta autorización.")
        val items = manifest.getJSONArray("items")

        // A ProControl ya le aplica la salida/entrada al despachar. El teléfono
        // solo incorpora las cantidades cuando su snapshot local es anterior
        // al despacho. Si ya recibió un snapshot posterior, no vuelve a sumar.
        if (currentSnapshot.generatedAt < dispatchCreatedAt) {
            for (index in 0 until items.length()) {
                val item = items.getJSONObject(index)
                val productId = item.getString("productId")
                val unit = item.getString("unit").trim()
                val quantityValue = item.get("quantity")
                require(quantityValue is Number) {
                    "La cantidad del manifiesto no es válida para " + productId + "."
                }
                val quantityMicros = MoneyMath.decimalToMicros(quantityValue)
                require(quantityMicros > 0L) {
                    "La cantidad recibida debe ser mayor que cero para " + productId + "."
                }
                val product = getActiveProduct(receipt.posId, productId)
                    ?: throw IllegalStateException(
                        "No existe " + productId + " en el inventario local. Importa el snapshot actualizado antes de confirmar."
                    )
                require(product.unit.equals(unit, ignoreCase = true)) {
                    "La unidad de " + product.name + " no coincide con el manifiesto de ProControl."
                }
                val nextQuantity = Math.addExact(product.availableQuantityMicros, quantityMicros)
                require(updateAvailableQuantity(
                    receipt.posId,
                    productId,
                    product.availableQuantityMicros,
                    nextQuantity
                ) == 1) {
                    "Las existencias de " + product.name + " cambiaron durante la confirmación. Revisa el inventario antes de reintentar."
                }
            }
        }

        val updated = updateReceiptWithFinalAuthorization(
            receiptId = receiptId,
            transferId = authorization.transferId,
            packageHash = authorization.packageHash,
            authorizationHash = authorization.authorizationHash,
            updatedAt = updatedAt
        )
        require(updated == 1) { "La recepción ya cambió de estado antes de confirmarse." }
        return updated
    }

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun enqueueOperation(operation: OutboxOperationEntity)

    @Query("SELECT * FROM outbox_operations WHERE status = 'PENDING' ORDER BY createdAt ASC")
    suspend fun getPendingOperations(): List<OutboxOperationEntity>

    @Query("UPDATE outbox_operations SET status = :newStatus WHERE operationId = :operationId AND status = 'PENDING'")
    suspend fun markOperation(operationId: String, newStatus: String): Int

    // Snapshot completo, estrictamente limitado al POS, para conservar una copia
    // recuperable antes de borrar los datos operativos después de exportar un cierre.
    @Query("SELECT * FROM products WHERE posId = :posId ORDER BY productId")
    suspend fun listProductsForRecovery(posId: String): List<ProductEntity>

    @Query("SELECT * FROM inventory_snapshots WHERE posId = :posId LIMIT 1")
    suspend fun getSnapshotForRecovery(posId: String): InventorySnapshotEntity?

    @Query("SELECT * FROM sales WHERE posId = :posId ORDER BY saleId")
    suspend fun listSalesForRecovery(posId: String): List<SaleEntity>

    @Query("SELECT t.* FROM sale_currency_totals t INNER JOIN sales s ON s.saleId=t.saleId WHERE s.posId=:posId ORDER BY t.totalId")
    suspend fun listSaleTotalsForRecovery(posId: String): List<SaleCurrencyTotalEntity>

    @Query("SELECT l.* FROM sale_lines l INNER JOIN sales s ON s.saleId=l.saleId WHERE s.posId=:posId ORDER BY l.lineId")
    suspend fun listSaleLinesForRecovery(posId: String): List<SaleLineEntity>

    @Query("SELECT p.* FROM sale_payments p INNER JOIN sale_lines l ON l.lineId=p.saleLineId INNER JOIN sales s ON s.saleId=l.saleId WHERE s.posId=:posId ORDER BY p.paymentId")
    suspend fun listSalePaymentsForRecovery(posId: String): List<SalePaymentEntity>

    @Query("SELECT * FROM goods_receipts WHERE posId=:posId ORDER BY receiptId")
    suspend fun listGoodsReceiptsForRecovery(posId: String): List<GoodsReceiptEntity>

    @Query("SELECT COUNT(*) FROM goods_receipts WHERE posId=:posId AND status != 'CONFIRMED'")
    suspend fun countUnconfirmedGoodsReceipts(posId: String): Int

    @Query("""
        SELECT p.* FROM outbox_packages p
        WHERE p.aggregateId IN (SELECT saleId FROM sales WHERE posId=:posId)
           OR p.aggregateId IN (SELECT transferId FROM goods_receipts WHERE posId=:posId)
           OR p.aggregateId IN (SELECT permitId FROM shift_permits WHERE posId=:posId)
        ORDER BY p.packageId
    """)
    suspend fun listOutboxPackagesForRecovery(posId: String): List<OutboxPackageEntity>

    @Query("SELECT * FROM shift_permits WHERE posId=:posId ORDER BY sequence, permitId")
    suspend fun listShiftPermitsForRecovery(posId: String): List<ShiftPermitEntity>

    @Query("SELECT * FROM shift_close_drafts WHERE posId=:posId ORDER BY permitId")
    suspend fun listShiftCloseDraftsForRecovery(posId: String): List<ShiftCloseDraftEntity>

    @Query("""
        SELECT o.* FROM outbox_operations o
        WHERE o.aggregateId IN (SELECT saleId FROM sales WHERE posId=:posId)
           OR o.aggregateId IN (SELECT transferId FROM goods_receipts WHERE posId=:posId)
        ORDER BY o.operationId
    """)
    suspend fun listOutboxOperationsForRecovery(posId: String): List<OutboxOperationEntity>

    @Query("SELECT * FROM shift_close_drafts WHERE posId=:posId AND permitId=:permitId LIMIT 1")
    suspend fun getShiftCloseDraftForRecovery(posId: String, permitId: String): ShiftCloseDraftEntity?

    @Transaction
    suspend fun buildShiftCloseRecoverySnapshot(posId: String, permitId: String): String {
        require(posId.isNotBlank() && permitId.isNotBlank()) { "El POS o permiso no está identificado para el respaldo." }
        val permit = getShiftPermit(permitId)
            ?: throw IllegalStateException("No se encontró el permiso del turno que se va a respaldar.")
        require(permit.posId == posId && permit.status == "CLOSE_PENDING") {
            "El permiso no pertenece al POS seleccionado o el cierre no está pendiente. No se borró ningún dato."
        }
        require(countSalesNotSynced(posId) == 0 && countPendingSalesWithoutPackage(posId) == 0 &&
            listPendingSalePackages(posId).isEmpty() && countSalePackagesNeedingReview(posId) == 0) {
            "Este POS todavía tiene ventas que ProControl no ha confirmado con un acuse válido. Exporta los paquetes pendientes e importa sus archivos .pcack; el cierre no borró ningún dato."
        }
        require(countUnconfirmedGoodsReceipts(posId) == 0) {
            "Este POS tiene entradas de mercancía sin confirmación final de ProControl. Completa sus acuses antes de cerrar; no se borró ningún dato."
        }
        val snapshot = org.json.JSONObject()
            .put("format", "proventa.shift-close-recovery-snapshot")
            .put("version", 1)
            .put("posId", posId)
            .put("permitId", permitId)
            .put("shiftPermit", recoveryEntityJson(permit))
            .put("shiftPermits", recoveryEntitiesJson(listShiftPermitsForRecovery(posId)))
            .put("products", recoveryEntitiesJson(listProductsForRecovery(posId)))
            .put("inventorySnapshots", recoveryEntitiesJson(listOfNotNull(getSnapshotForRecovery(posId))))
            .put("sales", recoveryEntitiesJson(listSalesForRecovery(posId)))
            .put("saleCurrencyTotals", recoveryEntitiesJson(listSaleTotalsForRecovery(posId)))
            .put("saleLines", recoveryEntitiesJson(listSaleLinesForRecovery(posId)))
            .put("salePayments", recoveryEntitiesJson(listSalePaymentsForRecovery(posId)))
            .put("goodsReceipts", recoveryEntitiesJson(listGoodsReceiptsForRecovery(posId)))
            .put("outboxPackages", recoveryEntitiesJson(listOutboxPackagesForRecovery(posId)))
            .put("outboxOperations", recoveryEntitiesJson(listOutboxOperationsForRecovery(posId)))
            .put("shiftCloseDrafts", recoveryEntitiesJson(listShiftCloseDraftsForRecovery(posId)))
        return com.proventa.app.security.CanonicalJson.stringify(snapshot)
    }

    @Query("DELETE FROM outbox_operations WHERE aggregateId IN (SELECT saleId FROM sales WHERE posId=:posId) OR aggregateId IN (SELECT transferId FROM goods_receipts WHERE posId=:posId)")
    suspend fun deleteRecoveryOutboxOperations(posId: String): Int

    @Query("""
        DELETE FROM outbox_packages
        WHERE aggregateId IN (SELECT saleId FROM sales WHERE posId=:posId)
           OR aggregateId IN (SELECT transferId FROM goods_receipts WHERE posId=:posId)
           OR (
               aggregateId IN (SELECT permitId FROM shift_permits WHERE posId=:posId)
               AND NOT (aggregateId=:permitId AND packageType='shift_close')
           )
    """)
    suspend fun deleteRecoveryOutboxPackages(posId: String, permitId: String): Int

    @Query("DELETE FROM goods_receipts WHERE posId=:posId")
    suspend fun deleteRecoveryGoodsReceipts(posId: String): Int

    @Query("DELETE FROM sales WHERE posId=:posId")
    suspend fun deleteRecoverySales(posId: String): Int

    @Query("DELETE FROM products WHERE posId=:posId")
    suspend fun deleteRecoveryProducts(posId: String): Int

    @Query("DELETE FROM inventory_snapshots WHERE posId=:posId")
    suspend fun deleteRecoveryInventorySnapshot(posId: String): Int

    @Query("DELETE FROM shift_close_drafts WHERE posId=:posId")
    suspend fun deleteRecoveryCloseDrafts(posId: String): Int

    @Query("DELETE FROM shift_permits WHERE posId=:posId AND permitId != :permitId")
    suspend fun deleteRecoveryHistoricalShiftPermits(posId: String, permitId: String): Int

    @Query("SELECT COUNT(*) FROM products WHERE posId=:posId")
    suspend fun countRecoveryProducts(posId: String): Int

    @Query("SELECT COUNT(*) FROM inventory_snapshots WHERE posId=:posId")
    suspend fun countRecoverySnapshots(posId: String): Int

    @Query("SELECT COUNT(*) FROM sales WHERE posId=:posId")
    suspend fun countRecoverySales(posId: String): Int

    @Query("SELECT COUNT(*) FROM goods_receipts WHERE posId=:posId")
    suspend fun countRecoveryReceipts(posId: String): Int

    @Query("SELECT COUNT(*) FROM shift_close_drafts WHERE posId=:posId")
    suspend fun countRecoveryDrafts(posId: String): Int

    @Query("SELECT COUNT(*) FROM shift_permits WHERE posId=:posId AND permitId != :permitId")
    suspend fun countRecoveryHistoricalShiftPermits(posId: String, permitId: String): Int

    @Transaction
    suspend fun isClosedShiftBusinessDataCleared(posId: String, permitId: String): Boolean {
        val permit = getShiftPermit(permitId) ?: return false
        if (permit.posId != posId || permit.status != "CLOSE_PENDING") return false
        val retainedPackages = listOutboxPackagesForRecovery(posId)
        return countRecoveryProducts(posId) == 0 && countRecoverySnapshots(posId) == 0 &&
            countRecoverySales(posId) == 0 && countRecoveryReceipts(posId) == 0 &&
            countRecoveryDrafts(posId) == 0 &&
            countRecoveryHistoricalShiftPermits(posId, permitId) == 0 &&
            retainedPackages.size == 1 && retainedPackages.singleOrNull()?.let {
                it.packageType == "shift_close" && it.aggregateId == permitId
            } == true
    }

    @Transaction
    suspend fun purgeClosedShiftDataAfterVerifiedArchive(
        posId: String,
        permitId: String,
        expectedSnapshotSha256: String
    ): Boolean {
        require(expectedSnapshotSha256.matches(Regex("[a-f0-9]{64}"))) {
            "La huella del respaldo interno no tiene un formato verificable. No se borró ningún dato."
        }
        val permit = getShiftPermit(permitId)
            ?: throw IllegalStateException("No se encontró el permiso de turno. No se borró ningún dato.")
        require(permit.posId == posId && permit.status == "CLOSE_PENDING") {
            "El turno o POS cambió antes de limpiar los datos. No se borró ningún dato."
        }
        val closePackage = getOutboxPackageForAggregate(permitId, "shift_close")
            ?: throw IllegalStateException("Falta el archivo firmado de cierre guardado en ProVenta. No se borró ningún dato.")
        require(closePackage.packageType == "shift_close" && closePackage.deviceId == permit.deviceId &&
            closePackage.status == "PENDING" && closePackage.acknowledgementJson == null) {
            "El paquete de cierre ya cambió de estado. No se borró ningún dato."
        }
        val currentSnapshot = buildShiftCloseRecoverySnapshot(posId, permitId)
        val currentHash = java.security.MessageDigest.getInstance("SHA-256")
            .digest(currentSnapshot.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        require(currentHash == expectedSnapshotSha256) {
            "Los datos del POS cambiaron después de crear el respaldo. Se canceló el borrado y se conservó toda la información."
        }
        // Antes de borrar se enumeran también los registros históricos ligados al POS.
        // Se conservan únicamente el permiso y el paquete shift_close actuales, ya que
        // ProVenta los necesita para reexportar el cierre y recibir el .pcack firmado.
        val historicalPermitCount = listShiftPermitsForRecovery(posId).count { it.permitId != permitId }
        val oldDraftCount = listShiftCloseDraftsForRecovery(posId).size
        val recoverablePackages = listOutboxPackagesForRecovery(posId)
        val expectedPackageDeletes = recoverablePackages.count {
            !(it.aggregateId == permitId && it.packageType == "shift_close")
        }
        val expectedOperationDeletes = listOutboxOperationsForRecovery(posId).size

        val deletedOperations = deleteRecoveryOutboxOperations(posId)
        require(deletedOperations == expectedOperationDeletes) {
            "No se pudo retirar la cola operativa completa del POS. La transacción se revirtió."
        }
        val deletedPackages = deleteRecoveryOutboxPackages(posId, permitId)
        require(deletedPackages == expectedPackageDeletes) {
            "No se pudo retirar el historial de paquetes del POS. La transacción se revirtió."
        }
        deleteRecoveryGoodsReceipts(posId)
        deleteRecoverySales(posId)
        deleteRecoveryProducts(posId)
        deleteRecoveryInventorySnapshot(posId)
        val deletedDrafts = deleteRecoveryCloseDrafts(posId)
        require(deletedDrafts == oldDraftCount) {
            "No se pudieron retirar todos los borradores de cierre del POS. La transacción se revirtió."
        }
        val deletedPermits = deleteRecoveryHistoricalShiftPermits(posId, permitId)
        require(deletedPermits == historicalPermitCount) {
            "No se pudo retirar todo el historial de permisos del POS. La transacción se revirtió."
        }
        require(countRecoveryProducts(posId) == 0 && countRecoverySnapshots(posId) == 0 &&
            countRecoverySales(posId) == 0 && countRecoveryReceipts(posId) == 0 &&
            countRecoveryDrafts(posId) == 0 &&
            countRecoveryHistoricalShiftPermits(posId, permitId) == 0) {
            "La verificación posterior al borrado no coincide. La transacción se revirtió."
        }
        val remainingPackages = listOutboxPackagesForRecovery(posId)
        require(remainingPackages.size == 1 && remainingPackages.single().packageId == closePackage.packageId &&
            remainingPackages.single().packageType == "shift_close") {
            "No se conservó únicamente el paquete firmado del cierre actual. La transacción se revirtió."
        }
        require(getOutboxPackageForAggregate(permitId, "shift_close")?.packageId == closePackage.packageId) {
            "El paquete firmado necesario para reexportar el cierre no se conservó. La transacción se revirtió."
        }
        require(getShiftPermit(permitId)?.status == "CLOSE_PENDING") {
            "El permiso de cierre no se conservó. La transacción se revirtió."
        }
        return true
    }

}


private fun recoveryEntitiesJson(rows: List<Any>): org.json.JSONArray = org.json.JSONArray().also { array ->
    rows.forEach { array.put(recoveryEntityJson(it)) }
}

private fun recoveryEntityJson(entity: Any): org.json.JSONObject = org.json.JSONObject().also { json ->
    entity.javaClass.declaredFields
        .filterNot { java.lang.reflect.Modifier.isStatic(it.modifiers) || it.isSynthetic || it.name.startsWith("\$") }
        .sortedBy { it.name }
        .forEach { field ->
            field.isAccessible = true
            val value = field.get(entity)
            json.put(field.name, value ?: org.json.JSONObject.NULL)
        }
}
