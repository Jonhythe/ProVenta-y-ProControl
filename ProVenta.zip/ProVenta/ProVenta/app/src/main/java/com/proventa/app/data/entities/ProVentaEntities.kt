package com.proventa.app.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "products",
    primaryKeys = ["posId", "productId"],
    indices = [Index(value = ["posId", "name"])]
)
data class ProductEntity(
    val productId: String,
    val posId: String,
    val name: String,
    val family: String,
    val unit: String,
    val cupCashPriceMinor: Long?,
    val cupTransferPriceMinor: Long?,
    val transferMode: String?,
    val transferPercentBasisPoints: Int?,
    val foreignPriceMinor: Long?,
    val foreignCurrency: String?,
    val customCurrencyLabel: String?,
    val foreignCurrencyScale: Int?,
    val availableQuantityMicros: Long,
    val catalogAliasesJson: String,
    val catalogRevision: String,
    val updatedAt: Long,
    val active: Boolean = true
)

@Entity(
    tableName = "inventory_snapshots",
    indices = [Index(value = ["packageId"], unique = true), Index(value = ["installationId", "deviceId"])]
)
data class InventorySnapshotEntity(
    @PrimaryKey val posId: String,
    val posName: String,
    val usdCupRateMicros: Long?,
    @ColumnInfo(defaultValue = "'{}'") val exchangeRatesJson: String = "{}",
    val installationId: String,
    val deviceId: String,
    val packageId: String,
    val payloadHash: String,
    val generatedAt: Long,
    val importedAt: Long,
    val productCount: Int
)


@Entity(
    tableName = "shift_permits",
    indices = [
        Index(value = ["posId", "deviceId", "sequence"], unique = true),
        Index(value = ["posId", "status"]),
        Index(value = ["endsAt"])
    ]
)
data class ShiftPermitEntity(
    @PrimaryKey val permitId: String,
    val installationId: String,
    val authorizationId: String,
    val desktopDeviceId: String,
    val posId: String,
    val deviceId: String,
    val employee: String,
    val sequence: Long,
    val shiftId: String?,
    val startsAt: Long,
    val endsAt: Long,
    val emergencyEnabled: Boolean,
    val emergencyMaxSales: Int,
    val emergencyExpiresAt: Long?,
    val emergencyReason: String?,
    val issuedAt: Long,
    val signature: String,
    val permitJson: String,
    val status: String,
    val importedAt: Long
)

@Entity(
    tableName = "sales",
    indices = [Index(value = ["posId"]), Index(value = ["shiftId"]), Index(value = ["status"]), Index(value = ["idempotencyKey"], unique = true)]
)
data class SaleEntity(
    @PrimaryKey val saleId: String,
    val posId: String,
    val shiftId: String,
    val status: String,
    val createdAt: Long,
    val updatedAt: Long,
    val idempotencyKey: String
)


@Entity(
    tableName = "sale_currency_totals",
    foreignKeys = [
        ForeignKey(
            entity = SaleEntity::class,
            parentColumns = ["saleId"],
            childColumns = ["saleId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["saleId"]), Index(value = ["saleId", "currency"], unique = true)]
)
data class SaleCurrencyTotalEntity(
    @PrimaryKey val totalId: String,
    val saleId: String,
    val currency: String,
    val currencyLabel: String?,
    val currencyScale: Int,
    val amountMinor: Long
)

@Entity(
    tableName = "sale_lines",
    foreignKeys = [
        ForeignKey(
            entity = SaleEntity::class,
            parentColumns = ["saleId"],
            childColumns = ["saleId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["saleId"]), Index(value = ["productId"])]
)
data class SaleLineEntity(
    @PrimaryKey val lineId: String,
    val saleId: String,
    val productId: String,
    val productNameSnapshot: String,
    val unitSnapshot: String,
    val quantityMicros: Long,
    val unitPriceMinor: Long,
    val lineTotalMinor: Long,
    val currency: String,
    val currencyLabel: String?,
    val currencyScale: Int
)

@Entity(
    tableName = "sale_payments",
    foreignKeys = [
        ForeignKey(
            entity = SaleLineEntity::class,
            parentColumns = ["lineId"],
            childColumns = ["saleLineId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["saleLineId"])]
)
data class SalePaymentEntity(
    @PrimaryKey val paymentId: String,
    val saleLineId: String,
    val method: String,
    val amountMinor: Long,
    val currency: String,
    val currencyScale: Int,
    val transferPhone: String?,
    val transferOperationNumber: String?,
    val evidenceUri: String?
)


@Entity(
    tableName = "outbox_packages",
    indices = [Index(value = ["packageType", "status"]), Index(value = ["aggregateId"])]
)
data class OutboxPackageEntity(
    @PrimaryKey val packageId: String,
    val deviceId: String,
    val packageType: String,
    val payloadHash: String,
    val envelopeJson: String,
    val aggregateId: String?,
    val status: String,
    val createdAt: Long,
    val acknowledgementJson: String?,
    val acknowledgedAt: Long?
)

@Entity(
    tableName = "goods_receipts",
    indices = [Index(value = ["posId"]), Index(value = ["status"]), Index(value = ["transferId"], unique = true)]
)
data class GoodsReceiptEntity(
    @PrimaryKey val receiptId: String,
    val transferId: String,
    val posId: String,
    val status: String,
    val confirmationCodeHash: String,
    val packageHash: String,
    @ColumnInfo(defaultValue = "''") val manifestJson: String,
    val finalAuthorizationHash: String?,
    val discrepancyReason: String?,
    val confirmedAt: Long?,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "outbox_operations",
    indices = [
        Index(value = ["idempotencyKey"], unique = true),
        Index(value = ["status"]),
        Index(value = ["createdAt"])
    ]
)
data class OutboxOperationEntity(
    @PrimaryKey val operationId: String,
    val idempotencyKey: String,
    val operationType: String,
    val aggregateId: String,
    val payloadJson: String,
    val payloadSha256: String,
    val status: String,
    val createdAt: Long
)


@Entity(
    tableName = "shift_close_drafts",
    indices = [Index(value = ["posId"]), Index(value = ["updatedAt"])]
)
data class ShiftCloseDraftEntity(
    @PrimaryKey val permitId: String,
    val shiftId: String,
    val posId: String,
    val draftJson: String,
    val updatedAt: Long
)
