package com.proventa.app.ui.screens

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.proventa.app.security.DeviceEnrollmentRequestFactory
import com.proventa.app.security.ProVentaDeviceIdentity
import com.proventa.app.ui.theme.Gold
import com.proventa.app.ui.theme.Navy
import com.proventa.app.ui.theme.NavyElevated
import com.proventa.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

private const val PROVENTA_ID_FILE = "ProVenta ID.pvid"
private const val PROVENTA_ID_RELATIVE_PATH = "Download/"

@Composable
fun DeviceLinkCard(isLinked: Boolean = false) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var identity by remember { mutableStateOf<ProVentaDeviceIdentity?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Preparando la identidad segura de este teléfono…") }
    var messageIsError by remember { mutableStateOf(false) }
    var savedAlert by remember { mutableStateOf<String?>(null) }

    // Android 10+ permite guardar directamente en Descargas mediante MediaStore.
    // Android 9 o anterior conserva el selector SAF para no pedir acceso amplio al almacenamiento.
    val legacyExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            val token = identity?.token
            if (token == null) {
                message = "No se pudo preparar el ID del teléfono. Cierra y vuelve a abrir ProVenta."
                messageIsError = true
            } else {
                scope.launch {
                    busy = true
                    try {
                        withContext(Dispatchers.IO) {
                            context.contentResolver.openOutputStream(uri, "w")?.use { output ->
                                output.write(token.toByteArray(Charsets.UTF_8))
                                output.flush()
                            } ?: throw IOException("No se pudo guardar el archivo de identidad.")
                        }
                        message = "ProVenta ID.pvid guardado correctamente en la carpeta que seleccionaste. Para encontrarlo fácilmente, usa Almacenamiento interno/Download."
                        messageIsError = false
                        savedAlert = "Archivo: ProVenta ID.pvid\nUbicación: carpeta que elegiste en el selector de Android.\n\nPara encontrarlo fácilmente, guarda el archivo en Almacenamiento interno/Download."
                    } catch (error: Exception) {
                        message = error.message ?: "No se pudo guardar el archivo de identidad."
                        messageIsError = true
                    } finally {
                        busy = false
                    }
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        busy = true
        try {
            identity = withContext(Dispatchers.IO) {
                DeviceEnrollmentRequestFactory(context.applicationContext)
                    .createDeviceIdentityToken(android.os.Build.MODEL)
            }
            message = "ID seguro preparado. Guárdalo en Descargas y entrégalo al Dueño del negocio."
            messageIsError = false
        } catch (error: Exception) {
            message = error.message ?: "No se pudo preparar la identidad segura del teléfono."
            messageIsError = true
        } finally {
            busy = false
        }
    }

    if (savedAlert != null) {
        AlertDialog(
            onDismissRequest = { savedAlert = null },
            title = { Text("ProVenta ID guardado") },
            text = { Text(savedAlert.orEmpty()) },
            confirmButton = {
                TextButton(onClick = { savedAlert = null }) { Text("Aceptar") }
            }
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = NavyElevated),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("01", color = Gold, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Identidad del teléfono", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Un archivo por dispositivo", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
            }
            Text(
                "ProVenta crea un archivo firmado con la identidad de este teléfono. Se guarda fuera de la carpeta privada de la aplicación para que puedas encontrarlo y transferirlo fácilmente.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text("ID DEL DISPOSITIVO", color = TextSecondary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Text(
                    identity?.deviceId ?: if (busy) "Preparando…" else "No disponible",
                    color = Gold,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            Button(
                onClick = {
                    val token = identity?.token ?: return@Button
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        scope.launch {
                            busy = true
                            try {
                                val location = withContext(Dispatchers.IO) {
                                    saveIdentityToDownloads(context, token)
                                }
                                message = "ProVenta ID.pvid guardado correctamente. Ubicación exacta: $location"
                                messageIsError = false
                                savedAlert = "Archivo: ProVenta ID.pvid\nUbicación exacta: $location\n\nEntrega este archivo al Dueño para importarlo en ProControl."
                            } catch (error: Exception) {
                                message = error.message ?: "No se pudo guardar ProVenta ID.pvid en Descargas."
                                messageIsError = true
                            } finally {
                                busy = false
                            }
                        }
                    } else {
                        legacyExportLauncher.launch(PROVENTA_ID_FILE)
                    }
                },
                enabled = !busy && identity != null,
                modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Navy,
                    contentColor = androidx.compose.ui.graphics.Color.White
                )
            ) {
                androidx.compose.material3.Icon(Icons.Outlined.FileUpload, contentDescription = null)
                Text("  Guardar ProVenta ID en Descargas", fontWeight = FontWeight.Bold)
            }
            Text(
                message,
                color = if (messageIsError) MaterialTheme.colorScheme.error else TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/** Escribe o reemplaza únicamente el archivo oficial de identidad en Descargas públicas. */
private fun saveIdentityToDownloads(context: Context, token: String): String {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
        throw IllegalStateException("Esta versión de Android necesita el selector de archivos para guardar la identidad.")
    }
    val resolver = context.contentResolver
    val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
    val projection = arrayOf(MediaStore.MediaColumns._ID)
    val selection = "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
    val existing = resolver.query(
        collection,
        projection,
        selection,
        arrayOf(PROVENTA_ID_FILE, PROVENTA_ID_RELATIVE_PATH),
        null
    )?.use { cursor ->
        if (cursor.moveToFirst()) ContentUris.withAppendedId(collection, cursor.getLong(0)) else null
    }

    val uri: Uri = existing ?: run {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, PROVENTA_ID_FILE)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        resolver.insert(collection, values) ?: throw IOException("Android no pudo crear ProVenta ID.pvid en Descargas.")
    }

    try {
        resolver.openOutputStream(uri, "wt")?.use { output ->
            output.write(token.toByteArray(Charsets.UTF_8))
            output.flush()
        } ?: throw IOException("Android no pudo escribir ProVenta ID.pvid.")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val ready = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, ready, null, null)
        }
    } catch (error: Exception) {
        if (existing == null) runCatching { resolver.delete(uri, null, null) }
        throw error
    }
    return "Almacenamiento interno/Download/$PROVENTA_ID_FILE"
}
