package com.proventa.app.data.shifts

import android.content.Context
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.ShiftPermitEntity
import com.proventa.app.security.ShiftPermitVerifier

data class ShiftPermitImportResult(
    val imported: Boolean,
    val permitId: String,
    val posId: String,
    val employee: String,
    val sequence: Long,
    val startsAt: Long,
    val endsAt: Long
)

class ShiftPermitImporter(context: Context) {
    private val verifier = ShiftPermitVerifier(context.applicationContext)
    private val dao = ProVentaDatabaseFactory.get(context.applicationContext).proVentaDao()

    suspend fun importPermit(rawJson: String): ShiftPermitImportResult {
        val permit = verifier.verify(rawJson)
        val entity = ShiftPermitEntity(
            permitId = permit.permitId,
            installationId = permit.installationId,
            authorizationId = permit.authorizationId,
            desktopDeviceId = permit.desktopDeviceId,
            posId = permit.posId,
            deviceId = permit.deviceId,
            employee = permit.employee,
            sequence = permit.sequence,
            shiftId = null,
            startsAt = permit.startsAt,
            endsAt = permit.endsAt,
            emergencyEnabled = permit.emergencyEnabled,
            emergencyMaxSales = permit.emergencyMaxSales,
            emergencyExpiresAt = permit.emergencyExpiresAt,
            emergencyReason = permit.emergencyReason,
            issuedAt = permit.issuedAt,
            signature = permit.signature,
            permitJson = permit.rawJson,
            status = "ISSUED",
            importedAt = System.currentTimeMillis()
        )
        val imported = dao.importShiftPermit(entity)
        return ShiftPermitImportResult(
            imported = imported,
            permitId = permit.permitId,
            posId = permit.posId,
            employee = permit.employee,
            sequence = permit.sequence,
            startsAt = permit.startsAt,
            endsAt = permit.endsAt
        )
    }
}
