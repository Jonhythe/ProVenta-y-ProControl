package com.proventa.app.security

import android.content.Context
import android.util.Base64
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import java.math.BigDecimal
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.text.Normalizer
import java.util.Locale

data class VerifiedShiftPermit(
    val permitId: String,
    val installationId: String,
    val authorizationId: String,
    val installationCode: String,
    val deviceSigningPublicKeyHash: String,
    val desktopDeviceId: String,
    val posId: String,
    val deviceId: String,
    val employee: String,
    val sequence: Long,
    val startsAt: Long,
    val endsAt: Long,
    val emergencyEnabled: Boolean,
    val emergencyMaxSales: Int,
    val emergencyExpiresAt: Long?,
    val emergencyReason: String?,
    val issuedAt: Long,
    val signature: String,
    val rawJson: String
)

class ShiftPermitVerifier(context: Context) {
    private val enrollment = DeviceEnrollmentRequestFactory(context.applicationContext)
    private val keyManager = DeviceKeyManager(context.applicationContext)
    private val provider = BouncyCastleProvider()

    fun verify(
        rawJson: String,
        nowMillis: Long = System.currentTimeMillis(),
        allowExpiredForExistingPackage: Boolean = false
    ): VerifiedShiftPermit {
        require(rawJson.toByteArray(StandardCharsets.UTF_8).size <= MAX_PERMIT_BYTES) {
            "El permiso de turno supera el tamaño permitido."
        }
        val authorization = enrollment.trustedInstallationAuthorization(nowMillis)
            ?: throw IllegalStateException("Importa primero la ficha de autorización de ProControl.")
        val deviceKeys = keyManager.getOrCreate()
        val document = try {
            JSONObject(rawJson)
        } catch (error: org.json.JSONException) {
            throw IllegalArgumentException(
                "El archivo se leyó correctamente, pero su contenido no tiene una estructura JSON completa (posición aproximada ${error.message ?: "desconocida"}). Puede haberse truncado o modificado; vuelve a exportarlo desde ProControl. No se importó ningún permiso.",
                error
            )
        }
        require(
            document.optString("format") == "procontrol.shift-permit" &&
                document.optInt("version") == 2
        ) { "Formato de permiso de turno no compatible." }

        val permitId = document.optString("permitId")
        val desktopDeviceId = document.optString("desktopDeviceId")
        val permitInstallationId = document.optString("installationId")
        val permitInstallationCode = document.optString("installationCode")
        val permitAuthorizationId = document.optString("authorizationId")
        val permitDeviceSigningPublicKeyHash = document.optString("deviceSigningPublicKeyHash")
        val permitAuthorizedPosId = document.optString("authorizedPosId")
        val posId = document.optString("posId")
        val deviceId = document.optString("deviceId")
        val employee = document.optString("employee").trim()
        val sequence = exactLong(document.opt("sequence"), "sequence")
        val startsAt = exactLong(document.opt("startsAt"), "startsAt")
        val endsAt = exactLong(document.opt("endsAt"), "endsAt")
        val issuedAt = exactLong(document.opt("issuedAt"), "issuedAt")
        val installationId = authorization.installationId
        val authorizationId = authorization.authorizationId

        require(permitInstallationId == installationId) {
            "El permiso pertenece a otra instalación ProControl."
        }
        require(permitInstallationCode == authorization.installationCode) {
            "El código identificador del PC no coincide con la licencia del teléfono."
        }
        require(permitAuthorizationId == authorizationId) {
            "El permiso no corresponde a la autorización actual de este teléfono."
        }
        if (authorization.version < 5) {
            require(authorization.authorizedPosId == posId) {
                "La autorización anterior de este teléfono no corresponde al punto de venta del permiso."
            }
        }
        require(permitAuthorizedPosId == posId) {
            "El permiso firmado no corresponde al punto de venta indicado."
        }
        require(permitDeviceSigningPublicKeyHash.matches(Regex("[a-f0-9]{64}")) &&
            !authorization.deviceSigningPublicKeyHash.isNullOrBlank() &&
            MessageDigest.isEqual(
                permitDeviceSigningPublicKeyHash.toByteArray(StandardCharsets.US_ASCII),
                authorization.deviceSigningPublicKeyHash.toByteArray(StandardCharsets.US_ASCII)
            )) {
            "La huella de la clave del teléfono no coincide con la autorización ProControl."
        }
        require(permitId.matches(UUID_PATTERN)) { "Identificador de permiso inválido." }
        // V4 descriptors do not carry a desktopId. The permit is already signed
        // by the public key pinned to installationId in the device authorization.
        if (authorization.version < 4) {
            require(desktopDeviceId == authorization.desktopId) { "El permiso fue emitido por otro PC." }
        } else {
            require(desktopDeviceId.isNotBlank() && desktopDeviceId.length <= 120) {
                "Identidad emisora del permiso inválida."
            }
        }
        require(posId.matches(POS_ID_PATTERN)) { "Punto de venta del permiso inválido." }
        require(deviceId == deviceKeys.deviceId) { "El permiso está destinado a otro teléfono." }
        require(employee.isNotBlank() && employee.length <= 100) { "Nombre de trabajador inválido." }
        val expectedEmployee = normalizeEmployee(authorization.employeeName)
        require(normalizeEmployee(employee) == expectedEmployee) {
            "El trabajador del permiso no coincide con la autorización del teléfono."
        }
        require(sequence >= 1) { "Secuencia de turno inválida." }
        require(startsAt > 0 && endsAt > startsAt && endsAt - startsAt <= MAX_SHIFT_MILLIS) {
            "Ventana horaria del permiso inválida."
        }
        require(
            endsAt > nowMillis || (allowExpiredForExistingPackage && endsAt > startsAt)
        ) { "El permiso de turno ya caducó." }
        require(issuedAt > 0 && issuedAt <= endsAt) {
            "Fecha de emisión del permiso inválida."
        }

        val desktopPem = document.optString("desktopPublicKey")
        val pinnedKey = parseEd25519PublicKey(authorization.desktopPublicKeyPem)
        val permitKey = parseEd25519PublicKey(desktopPem)
        require(MessageDigest.isEqual(pinnedKey.encoded, permitKey.encoded)) {
            "La clave firmante del permiso no coincide con la instalación vinculada."
        }
        val signature = document.optString("signature")
        val signatureBytes = try {
            Base64.decode(signature, Base64.DEFAULT)
        } catch (_: Exception) {
            throw IllegalArgumentException("Firma del permiso inválida.")
        }
        val signatureVerifier = Signature.getInstance("Ed25519", provider)
        signatureVerifier.initVerify(pinnedKey)
        signatureVerifier.update(
            CanonicalJson.stringify(CanonicalJson.withoutSignature(document))
                .toByteArray(StandardCharsets.UTF_8)
        )
        require(signatureVerifier.verify(signatureBytes)) {
            "La firma del permiso no es válida o el archivo fue modificado."
        }

        val emergency = document.optJSONObject("emergency")
            ?: throw IllegalArgumentException("Falta la política de emergencia del permiso.")
        val emergencyEnabled = emergency.opt("enabled") as? Boolean
            ?: throw IllegalArgumentException("Indicador de emergencia inválido.")
        val emergencyMaxSales = exactInt(emergency.opt("maxSales"), "emergency.maxSales")
        val emergencyExpiresValue = emergency.opt("expiresAt")
        val emergencyExpiresAt = if (emergencyExpiresValue == null || emergencyExpiresValue === JSONObject.NULL) {
            null
        } else {
            exactLong(emergencyExpiresValue, "emergency.expiresAt")
        }
        val emergencyReasonValue = emergency.opt("reason")
        val emergencyReason = when {
            emergencyReasonValue == null || emergencyReasonValue === JSONObject.NULL -> null
            emergencyReasonValue is String -> emergencyReasonValue
            else -> throw IllegalArgumentException("Razón de emergencia inválida.")
        }
        if (emergencyEnabled) {
            require(emergencyMaxSales in 1..50) { "Límite de emergencia inválido." }
            require(emergencyExpiresAt != null &&
                emergencyExpiresAt > startsAt &&
                emergencyExpiresAt <= endsAt &&
                emergencyExpiresAt - issuedAt <= MAX_EMERGENCY_MILLIS) {
                "La caducidad de emergencia no es válida."
            }
            require(!emergencyReason.isNullOrBlank() && emergencyReason.trim().length >= 8 && emergencyReason.length <= 240) {
                "La razón de emergencia no es válida."
            }
        } else {
            require(emergencyMaxSales == 0 && emergencyExpiresAt == null && (emergencyReason == null || emergencyReason.isEmpty())) {
                "El permiso contiene límites de emergencia sin activar."
            }
        }

        return VerifiedShiftPermit(
            permitId = permitId,
            installationId = installationId,
            authorizationId = authorizationId,
            installationCode = permitInstallationCode,
            deviceSigningPublicKeyHash = permitDeviceSigningPublicKeyHash,
            desktopDeviceId = desktopDeviceId,
            posId = posId,
            deviceId = deviceId,
            employee = employee,
            sequence = sequence,
            startsAt = startsAt,
            endsAt = endsAt,
            emergencyEnabled = emergencyEnabled,
            emergencyMaxSales = emergencyMaxSales,
            emergencyExpiresAt = emergencyExpiresAt,
            emergencyReason = emergencyReason,
            issuedAt = issuedAt,
            signature = signature,
            rawJson = CanonicalJson.stringify(document)
        )
    }

    private fun parseEd25519PublicKey(pem: String): java.security.PublicKey {
        require(pem.length in 100..8192 && pem.contains("BEGIN PUBLIC KEY")) {
            "Clave pública de firma inválida."
        }
        val base64 = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() }
        return KeyFactory.getInstance("Ed25519", provider)
            .generatePublic(X509EncodedKeySpec(Base64.decode(base64, Base64.DEFAULT)))
    }

    private fun exactInt(value: Any?, field: String): Int {
        require(value is Number) { "El campo " + field + " no es numérico." }
        return try {
            BigDecimal(value.toString()).intValueExact()
        } catch (_: ArithmeticException) {
            throw IllegalArgumentException("El campo " + field + " debe ser un entero exacto.")
        }
    }

    private fun exactLong(value: Any?, field: String): Long {
        require(value is Number) { "El campo " + field + " no es numérico." }
        return try {
            BigDecimal(value.toString()).longValueExact()
        } catch (_: ArithmeticException) {
            throw IllegalArgumentException("El campo " + field + " debe ser un entero exacto.")
        }
    }

    private fun normalizeEmployee(value: String): String =
        Normalizer.normalize(value.trim(), Normalizer.Form.NFC).lowercase(Locale.ROOT)

    private companion object {
        const val MAX_PERMIT_BYTES = 64 * 1024
        const val MAX_SHIFT_MILLIS = 24 * 60 * 60 * 1000L
        const val MAX_EMERGENCY_MILLIS = 4 * 60 * 60 * 1000L
        val UUID_PATTERN = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
        val POS_ID_PATTERN = Regex("[A-Za-z0-9:_-]{1,160}")
    }
}
