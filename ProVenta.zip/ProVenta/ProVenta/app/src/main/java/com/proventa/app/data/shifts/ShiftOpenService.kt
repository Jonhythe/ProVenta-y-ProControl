package com.proventa.app.data.shifts

import android.content.Context
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.OutboxPackageEntity
import com.proventa.app.security.CurrentProVentaScopeProvider
import com.proventa.app.security.DeviceOperationPackageFactory
import com.proventa.app.security.SignedDeviceOperationPackage
import org.json.JSONObject
import java.util.UUID

class ShiftOpenService(context: Context) {
    private val appContext = context.applicationContext
    private val dao = ProVentaDatabaseFactory.get(appContext).proVentaDao()
    private val packageFactory = DeviceOperationPackageFactory(appContext)
    private val scopeProvider = CurrentProVentaScopeProvider(appContext)

    suspend fun createOrGetOpeningPackage(
        permitId: String,
        nowMillis: Long = System.currentTimeMillis()
    ): SignedDeviceOperationPackage {
        val permit = dao.getShiftPermit(permitId)
            ?: throw IllegalArgumentException("No se encontró el permiso de turno.")
        val scope = scopeProvider.requireCurrent(nowMillis)
        scope.requirePermitScope(permit.installationId, permit.authorizationId, permit.posId, permit.deviceId)
        val existing = dao.getOutboxPackageForAggregate(permitId, "shift_open")
        val permitStatusAllowsExistingPackage =
            existing != null && permit.status in setOf("OPEN_PENDING_REVIEW", "OPENED")
        val verifiedPermit = com.proventa.app.security.ShiftPermitVerifier(appContext).verify(
            rawJson = permit.permitJson,
            nowMillis = nowMillis,
            allowExpiredForExistingPackage = permitStatusAllowsExistingPackage
        )
        require(
            verifiedPermit.permitId == permit.permitId &&
                verifiedPermit.installationId == permit.installationId &&
                verifiedPermit.authorizationId == permit.authorizationId &&
                verifiedPermit.posId == permit.posId &&
                verifiedPermit.deviceId == permit.deviceId &&
                verifiedPermit.employee == permit.employee &&
                verifiedPermit.sequence == permit.sequence &&
                verifiedPermit.startsAt == permit.startsAt &&
                verifiedPermit.endsAt == permit.endsAt
        ) {
            "El permiso guardado no coincide con su ficha firmada, el teléfono actual o el punto de venta autorizado."
        }
        if (existing != null) {
            require(existing.deviceId == scope.deviceId) {
                "El paquete de apertura pertenece a otro teléfono autorizado."
            }
            require(permit.status == "OPEN_PENDING_REVIEW" || permit.status == "OPENED") {
                "El permiso tiene un paquete de apertura en un estado inesperado."
            }
            return SignedDeviceOperationPackage(
                packageId = existing.packageId,
                deviceId = existing.deviceId,
                type = existing.packageType,
                payloadHash = existing.payloadHash,
                createdAt = existing.createdAt,
                envelopeJson = existing.envelopeJson
            )
        }
        require(permit.status == "ISSUED") { "Este permiso ya fue utilizado o no puede abrir un turno." }
        require(nowMillis >= permit.startsAt && nowMillis <= permit.endsAt) {
            "El turno solo puede abrirse dentro del horario autorizado."
        }

        val shiftId = permit.shiftId ?: "shift_" + UUID.randomUUID().toString().replace("-", "")
        val shift = JSONObject()
            .put("id", shiftId)
            .put("permitId", permit.permitId)
            .put("posId", permit.posId)
            .put("sequence", permit.sequence)
            .put("startedAt", nowMillis)
        val openingInventory = org.json.JSONArray()
        dao.listActiveProducts(permit.posId).forEach { product ->
            openingInventory.put(
                JSONObject()
                    .put("productId", product.productId)
                    .put("name", product.name)
                    .put("unit", product.unit)
                    .put("quantityMicros", product.availableQuantityMicros)
            )
        }
        shift.put("initialInventory", openingInventory)

        val signed = packageFactory.create(
            type = "shift_open",
            payload = JSONObject().put("shift", shift),
            createdAt = nowMillis
        )
        val entity = OutboxPackageEntity(
            packageId = signed.packageId,
            deviceId = signed.deviceId,
            packageType = signed.type,
            payloadHash = signed.payloadHash,
            envelopeJson = signed.envelopeJson,
            aggregateId = permitId,
            status = "PENDING",
            createdAt = signed.createdAt,
            acknowledgementJson = null,
            acknowledgedAt = null
        )
        dao.storeShiftOpenPackage(permitId, shiftId, entity)
        return signed
    }
}
