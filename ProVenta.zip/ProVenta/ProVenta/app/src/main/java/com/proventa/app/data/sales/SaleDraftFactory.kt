package com.proventa.app.data.sales

import com.proventa.app.data.entities.SaleCurrencyTotalEntity
import com.proventa.app.data.entities.SaleEntity
import com.proventa.app.data.entities.SaleLineEntity
import com.proventa.app.data.entities.SalePaymentEntity
import com.proventa.app.data.money.MoneyMath

enum class SaleStatus { DRAFT, PENDING_SYNC, SYNCED, REJECTED }
enum class PaymentMethod { CASH, TRANSFER }

data class SaleLineDraft(
    val lineId: String,
    val productId: String,
    val productName: String,
    val unit: String,
    val quantityMicros: Long,
    val unitPriceMinor: Long,
    val currency: String,
    val currencyScale: Int,
    val currencyLabel: String? = null
) {
    val lineTotalMinor: Long
        get() = MoneyMath.lineTotalMinor(unitPriceMinor, quantityMicros)
}

data class PaymentDraft(
    val paymentId: String,
    val method: PaymentMethod,
    val amountMinor: Long,
    val currency: String,
    val currencyScale: Int,
    val transferPhone: String? = null,
    val transferOperationNumber: String? = null,
    val evidenceUri: String? = null
)

data class SaleBundle(
    val sale: SaleEntity,
    val lines: List<SaleLineEntity>,
    val totals: List<SaleCurrencyTotalEntity>,
    val payments: List<SalePaymentEntity>
)

object SaleDraftFactory {
    fun create(
        saleId: String,
        posId: String,
        shiftId: String,
        idempotencyKey: String,
        status: SaleStatus,
        lines: List<SaleLineDraft>,
        paymentsByLine: Map<String, List<PaymentDraft>>,
        now: Long
    ): SaleBundle {
        require(saleId.isNotBlank() && posId.isNotBlank() && shiftId.isNotBlank()) {
            "La venta debe tener identificador, punto de venta y turno."
        }
        require(idempotencyKey.isNotBlank()) { "Falta la clave de idempotencia de la venta." }
        require(lines.isNotEmpty()) { "Añade al menos un producto a la venta." }
        require(lines.map { it.lineId }.distinct().size == lines.size) {
            "La venta contiene identificadores de línea duplicados."
        }
        require(lines.all { line ->
            line.lineId.isNotBlank() &&
                line.productId.isNotBlank() &&
                line.productName.isNotBlank() &&
                line.unit.isNotBlank() &&
                line.quantityMicros > 0 &&
                line.unitPriceMinor >= 0 &&
                line.currency.matches(Regex("[A-Z]{3,4}")) &&
                line.currencyScale in 0..6 &&
                (line.currency != "OTRA" || (!line.currencyLabel.isNullOrBlank() && line.currencyLabel.length <= 40))
        }) { "Hay una línea con datos de producto, cantidad, precio o moneda inválidos." }

        val lineIds = lines.map { it.lineId }.toSet()
        require(paymentsByLine.keys.all { it in lineIds }) {
            "Hay pagos asociados a una línea que no pertenece a esta venta."
        }

        val entityLines = lines.map { line ->
            SaleLineEntity(
                lineId = line.lineId,
                saleId = saleId,
                productId = line.productId,
                productNameSnapshot = line.productName,
                unitSnapshot = line.unit,
                quantityMicros = line.quantityMicros,
                unitPriceMinor = line.unitPriceMinor,
                lineTotalMinor = line.lineTotalMinor,
                currency = line.currency,
                currencyLabel = line.currencyLabel,
                currencyScale = line.currencyScale
            )
        }

        val entityPayments = lines.flatMap { line ->
            (paymentsByLine[line.lineId] ?: emptyList()).map { payment ->
                require(payment.paymentId.isNotBlank() && payment.amountMinor > 0) {
                    "Hay un pago con identificador o importe inválido."
                }
                require(payment.currency == line.currency && payment.currencyScale == line.currencyScale) {
                    "El pago debe usar la misma moneda y escala que el artículo."
                }
                when (payment.method) {
                    PaymentMethod.CASH -> require(
                        payment.transferPhone.isNullOrBlank() && payment.transferOperationNumber.isNullOrBlank()
                    ) { "Un pago en efectivo no debe contener datos de transferencia." }
                    PaymentMethod.TRANSFER -> require(
                        !payment.transferPhone.isNullOrBlank() &&
                            !payment.transferOperationNumber.isNullOrBlank()
                    ) { "La transferencia requiere teléfono y número de operación." }
                }
                SalePaymentEntity(
                    paymentId = payment.paymentId,
                    saleLineId = line.lineId,
                    method = payment.method.name,
                    amountMinor = payment.amountMinor,
                    currency = payment.currency,
                    currencyScale = payment.currencyScale,
                    transferPhone = payment.transferPhone,
                    transferOperationNumber = payment.transferOperationNumber,
                    evidenceUri = payment.evidenceUri
                )
            }
        }

        require(entityPayments.map { it.paymentId }.distinct().size == entityPayments.size) {
            "La venta contiene identificadores de pago duplicados."
        }

        val paymentsByLineEntities = entityPayments.groupBy { it.saleLineId }
        entityLines.forEach { line ->
            val paid = MoneyMath.sumMinorAmounts(
                (paymentsByLineEntities[line.lineId] ?: emptyList()).map { it.amountMinor }
            )
            require(paid <= line.lineTotalMinor) { "Los pagos superan el importe del artículo." }
            if (status != SaleStatus.DRAFT) {
                require(paid == line.lineTotalMinor) {
                    "No se puede enviar una venta si quedan artículos sin pagar completamente."
                }
            }
        }

        require(entityLines.groupBy { it.currency }.values.all { currencyLines ->
            currencyLines.map { it.currencyScale }.distinct().size == 1 &&
                currencyLines.map { it.currencyLabel }.distinct().size == 1
        }) { "Una misma moneda no puede usar escalas diferentes en la misma venta." }

        val totals = entityLines.groupBy { it.currency }
            .map { (currency, currencyLines) ->
                val scale = currencyLines.first().currencyScale
                SaleCurrencyTotalEntity(
                    totalId = "$saleId-$currency",
                    saleId = saleId,
                    currency = currency,
                    currencyLabel = currencyLines.first().currencyLabel,
                    currencyScale = scale,
                    amountMinor = MoneyMath.sumMinorAmounts(currencyLines.map { it.lineTotalMinor })
                )
            }
            .sortedBy { it.currency }

        val sale = SaleEntity(
            saleId = saleId,
            posId = posId,
            shiftId = shiftId,
            status = status.name,
            createdAt = now,
            updatedAt = now,
            idempotencyKey = idempotencyKey
        )
        return SaleBundle(sale, entityLines, totals, entityPayments)
    }
}
