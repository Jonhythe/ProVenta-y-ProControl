package com.proventa.app.security

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.PrivateKey
import java.security.spec.MGF1ParameterSpec
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.spec.SecretKeySpec
import java.security.spec.X509EncodedKeySpec
import java.time.Instant
import java.util.Base64
import java.util.Locale
import java.util.zip.DataFormatException
import java.util.zip.Deflater
import java.util.zip.Inflater
import java.io.ByteArrayOutputStream

object ProVentaOneTimeCode {
    /** Supports legacy six-digit codes and current eight-digit v4 PINs. */
    fun normalize(value: String): String = value.filter { it in '0'..'9' }.take(8)

    fun fromQrPayload(payload: String): String? {
        val candidate = payload.trim()
        return candidate.takeIf { it.matches(Regex("(?:[0-9]{6}|[0-9]{8})")) }
    }

    fun descriptorFromQrPayload(payload: String): String? {
        val candidate = payload.trim()
        return runCatching {
            // PCD1 carries the UTF-8 JSON as ASCII-only Base64URL so QR readers
            // cannot reinterpret accented names using a different default charset.
            val descriptor = if (candidate.startsWith("PCD1:")) {
                val encoded = candidate.removePrefix("PCD1:")
                require(encoded.isNotEmpty() && encoded.matches(Regex("[A-Za-z0-9_-]+")))
                val bytes = Base64.getUrlDecoder().decode(encoded)
                StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                    .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                    .decode(java.nio.ByteBuffer.wrap(bytes))
                    .toString()
            } else {
                candidate
            }
            val document = JSONObject(descriptor)
            descriptor.takeIf {
                document.optString("format") == "procontrol.device-authorization" &&
                    document.optInt("version") in 1..6 &&
                    document.optString("code").matches(
                        Regex(if (document.optInt("version") >= 3) "[0-9]{8}" else "[0-9]{6}")
                    )
            }
        }.getOrNull()
    }
}
data class VerifiedDeviceAuthorization(
    val installationId: String,
    val authorizationId: String,
    /** Legacy desktop identifier. V4 binds the signer through installationId + Ed25519 key. */
    val desktopId: String,
    val code: String,
    val employeeName: String,
    val expiresAt: Long,
    val desktopPublicKeyPem: String,
    val rawJson: String,
    val deviceId: String? = null,
    val permanent: Boolean = false,
    val version: Int = 1,
    val installationCode: String? = null,
    val authorizedPosId: String? = null,
    val deviceSigningPublicKeyHash: String? = null,
    val authorizedPosName: String? = null,
    val renewalSequence: Long = 0L
)

data class ProVentaDeviceIdentity(
    val deviceId: String,
    val token: String
)

object ProVentaActivationCode {
    private const val PREFIX = "PVLA2:"
    private const val ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
    private const val MAX_COMPRESSED_BYTES = 16 * 1024
    private const val MAX_JSON_BYTES = 64 * 1024

    /**
     * Encodes the already Ed25519-signed ProControl descriptor as a compact,
     * clipboard-friendly Crockford Base32 code. The checksum detects typing or
     * clipboard corruption before JSON parsing or signature verification.
     */
    fun encode(rawJson: String): String {
        val input = rawJson.toByteArray(StandardCharsets.UTF_8)
        require(input.size <= MAX_JSON_BYTES) { "La autorización supera el tamaño permitido." }
        val deflater = Deflater(9, true)
        val compressed = try {
            deflater.setInput(input)
            deflater.finish()
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(4096)
            while (!deflater.finished()) {
                val count = deflater.deflate(buffer)
                if (count <= 0) break
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        } finally {
            deflater.end()
        }
        val checksum = MessageDigest.getInstance("SHA-256").digest(compressed).copyOf(4)
        return PREFIX + encodeBase32(compressed + checksum)
    }

    fun decode(value: String): String {
        val compact = value.uppercase(Locale.ROOT)
            .filterNot { it.isWhitespace() || it == '-' || it == ':' }
        require(compact.startsWith("PVLA2")) {
            "Código incorrecto. Introduce el código PVLA2 generado por ProControl."
        }
        val encoded = compact.removePrefix("PVLA2")
        require(encoded.length in 40..4000 && encoded.all { it in ALPHABET }) {
            "Código incorrecto. El texto de activación está incompleto o contiene caracteres ilegibles."
        }
        val packed = decodeBase32(encoded)
        require(packed.size > 5) { "Código incorrecto. El contenido está incompleto." }
        val compressed = packed.copyOfRange(0, packed.size - 4)
        val suppliedChecksum = packed.copyOfRange(packed.size - 4, packed.size)
        val actualChecksum = MessageDigest.getInstance("SHA-256").digest(compressed).copyOf(4)
        require(MessageDigest.isEqual(suppliedChecksum, actualChecksum)) {
            "Código incorrecto. El texto se copió incompleto o contiene caracteres ilegibles."
        }
        val inflater = Inflater(true)
        val jsonBytes = try {
            inflater.setInput(compressed)
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(4096)
            while (!inflater.finished()) {
                val count = try {
                    inflater.inflate(buffer)
                } catch (_: DataFormatException) {
                    throw IllegalArgumentException("Código incorrecto. El contenido no es válido.")
                }
                if (count > 0) {
                    output.write(buffer, 0, count)
                    require(output.size() <= MAX_JSON_BYTES) {
                        "Código incorrecto. El contenido supera el tamaño permitido."
                    }
                } else if (inflater.needsDictionary() || inflater.needsInput()) {
                    break
                } else {
                    throw IllegalArgumentException("Código incorrecto. El código está incompleto.")
                }
            }
            require(inflater.finished()) { "Código incorrecto. No se pudo recuperar todo el código." }
            output.toByteArray()
        } finally {
            inflater.end()
        }
        val json = try {
            StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                .decode(java.nio.ByteBuffer.wrap(jsonBytes))
                .toString()
        } catch (_: Exception) {
            throw IllegalArgumentException("Código incorrecto. El contenido no es texto válido.")
        }
        val document = JSONObject(json)
        require(document.optString("format") == "procontrol.device-authorization" &&
            document.optInt("version") in 2..6 && document.optBoolean("permanent")) {
            "Código incorrecto. No es una autorización permanente válida de ProControl."
        }
        return json
    }

    /**
     * Legacy compatibility helper for printed PVLA2 text. Current activation uses
     * the signed clipboard/file token or the one-symbol camera reader, but keeping
     * this extractor preserves older tests and integrations. The resulting token
     * still has to pass the PVLA2 checksum and ProControl Ed25519 verification.
     */
    fun extractFromRecognizedText(text: String): String? {
        val normalized = text.uppercase(Locale.ROOT).replace('Í', 'I')
        val prefixMatch = Regex("P\\s*V\\s*L\\s*A\\s*[2Z]").find(normalized) ?: return null
        val tail = normalized.substring(prefixMatch.range.last + 1)
        val terminator = Regex("FIN\\s*(?:DEL\\s*)?COD(?:I|1)GO").find(tail)
        val body = if (terminator != null) tail.substring(0, terminator.range.first) else tail
        val payload = buildString {
            for (char in body) {
                val normalizedChar = when (char) {
                    'O' -> '0'
                    'I', 'L' -> '1'
                    else -> char
                }
                if (normalizedChar in ALPHABET) append(normalizedChar)
            }
        }
        if (payload.length !in 40..4000) return null
        return PREFIX + payload
    }

    private fun encodeBase32(bytes: ByteArray): String {
        val result = StringBuilder((bytes.size * 8 + 4) / 5)
        var buffer = 0
        var bits = 0
        for (byte in bytes) {
            buffer = (buffer shl 8) or (byte.toInt() and 0xff)
            bits += 8
            while (bits >= 5) {
                bits -= 5
                result.append(ALPHABET[(buffer ushr bits) and 31])
            }
        }
        if (bits > 0) result.append(ALPHABET[(buffer shl (5 - bits)) and 31])
        return result.toString()
    }

    private fun decodeBase32(encoded: String): ByteArray {
        val output = ByteArrayOutputStream((encoded.length * 5) / 8)
        var buffer = 0
        var bits = 0
        for (char in encoded) {
            val value = ALPHABET.indexOf(char)
            require(value >= 0) { "Código incorrecto. Contiene caracteres que no pertenecen al alfabeto de activación." }
            buffer = (buffer shl 5) or value
            bits += 5
            if (bits >= 8) {
                bits -= 8
                output.write((buffer ushr bits) and 0xff)
            }
        }
        if (bits > 0) {
            require((buffer and ((1 shl bits) - 1)) == 0) {
                "Código incorrecto. El último bloque está incompleto."
            }
        }
        return output.toByteArray()
    }
}

class DeviceAuthorizationDescriptorVerifier {
    private val provider = BouncyCastleProvider()

    fun verify(
        rawJson: String,
        nowMillis: Long = System.currentTimeMillis(),
        enforceCodeExpiry: Boolean = true,
        expectedDeviceId: String? = null,
        expectedDevicePublicKeyHash: String? = null
    ): VerifiedDeviceAuthorization {
        require(rawJson.toByteArray(StandardCharsets.UTF_8).size <= MAX_DESCRIPTOR_BYTES) {
            "La ficha de autorización supera el tamaño permitido."
        }
        val document = JSONObject(rawJson)
        val version = document.optInt("version")
        require(document.optString("format") == FORMAT && version in 1..6) {
            "La ficha no es una autorización ProVenta compatible."
        }
        val installationId = document.optString("installationId")
        val authorizationId = document.optString("authorizationId")
        // ProControl v4 intentionally no longer publishes a separate desktopId.
        // Its Ed25519 public key fingerprints installationId, which is the stable
        // cross-version identity used by the mobile protocol.
        val desktopId = document.optString("desktopId").takeIf { it.isNotBlank() }
            ?: if (version >= 4) installationId else ""
        val code = document.optString("code")
        val employeeName = document.optString("employeeName").trim()
        val expiresAt = document.optLong("expiresAt", -1L)
        val desktopPublicKeyPem = document.optString("desktopPublicKey")
        val createdAt = document.optString("createdAt")
        val renewalSequence = document.optLong("renewalSequence", 0L)
        val createdAtMillis = runCatching { Instant.parse(createdAt).toEpochMilli() }.getOrNull()
        if (version >= 6 && enforceCodeExpiry) {
            require(renewalSequence >= 1L && expiresAt > nowMillis &&
                createdAtMillis != null && expiresAt > createdAtMillis &&
                expiresAt - createdAtMillis <= QR_CODE_TTL_MILLIS) {
                "El QR de autorización ha vencido o contiene una secuencia y vigencia inválidas."
            }
        }
        val deviceId = document.optString("deviceId").takeIf { it.isNotBlank() }
        val permanent = document.optBoolean("permanent", false)
        val installationCode = document.optString("installationCode").takeIf { it.isNotBlank() }
        val authorizedPosId = document.optString("authorizedPosId").takeIf { it.isNotBlank() }
        val authorizedPosName = document.optString("authorizedPosName").trim().takeIf { it.isNotBlank() }
        require(authorizedPosName == null || authorizedPosName.length <= 100) { "Nombre del punto de venta inválido." }
        require(installationId.matches(Regex("pcinst_[a-f0-9]{32}"))) { "Identidad de instalación inválida." }
        require(authorizationId.matches(Regex("auth_[A-Za-z0-9-]{20,60}"))) { "Identificador de autorización inválido." }
        if (version < 4) {
            require(desktopId.isNotBlank() && desktopId.length <= 120) { "Identidad del PC inválida." }
        }
        val expectedCodeLength = if (version >= 3) 8 else 6
        require(code.matches(Regex("[0-9]{$expectedCodeLength}"))) { "Código de vinculación inválido." }
        require(employeeName.length in 2..100) { "Nombre de trabajador inválido." }
        if (enforceCodeExpiry && !permanent) require(expiresAt > nowMillis) { "El código de vinculación ha caducado." }
        require(runCatching { Instant.parse(createdAt) }.isSuccess) { "Fecha de emisión inválida." }

        val signatureObject = document.optJSONObject("signature")
            ?: throw IllegalArgumentException("La ficha no contiene firma digital.")
        require(signatureObject.optString("algorithm") == "Ed25519") {
            "Algoritmo de firma no compatible."
        }
        val publicKey = parseEd25519PublicKey(desktopPublicKeyPem)
        val expectedInstallationId = installationFingerprint(publicKey.encoded)
        require(expectedInstallationId == installationId) {
            "La identidad de instalación no corresponde a la clave pública incluida."
        }
        if (version >= 4) {
            require(installationCode != null && installationCode == installationCodeFromId(installationId)) {
                "La identidad corta no corresponde a esta instalación ProControl."
            }
        }
        if (version == 4) {
            require(authorizedPosId != null && authorizedPosId.matches(Regex("[A-Za-z0-9:_-]{1,160}"))) {
                "Código incorrecto. La autorización anterior no está asignada a un punto de venta."
            }
        } else if (version >= 5) {
            require(document.optString("authorizationScope") == "installation" && authorizedPosId == null) {
                "La autorización v5 debe pertenecer a la instalación completa y no incluir un POS fijo."
            }
        }
        if (version >= 2) {
            val validDeviceId = if (version >= 4) {
                deviceId?.matches(Regex("device_[a-f0-9]{32}")) == true
            } else {
                deviceId != null && deviceId.matches(Regex("[A-Za-z0-9_-]{8,100}"))
            }
            require(permanent && validDeviceId) {
                "Código incorrecto. La autorización no contiene un ID de teléfono válido."
            }
            if (version >= 4) {
                require(expectedDeviceId != null && expectedDeviceId.matches(Regex("device_[a-f0-9]{32}"))) {
                    "No se pudo leer la identidad local de este teléfono. Abre ProVenta y vuelve a exportar su ID."
                }
                require(expectedDevicePublicKeyHash != null && expectedDevicePublicKeyHash.matches(Regex("[a-f0-9]{64}"))) {
                    "No se pudo comprobar la clave de seguridad de este teléfono."
                }
            } else {
                require(expectedDeviceId != null) {
                    "No se pudo leer la identidad local de este teléfono."
                }
            }
        }

        val signatureBytes = try {
            Base64.getDecoder().decode(signatureObject.getString("value"))
        } catch (_: Exception) {
            throw IllegalArgumentException("La firma digital no tiene un formato válido.")
        }
        val verifier = Signature.getInstance("Ed25519", provider)
        verifier.initVerify(publicKey)
        verifier.update(CanonicalJson.stringify(CanonicalJson.withoutSignature(document)).toByteArray(StandardCharsets.UTF_8))
        require(verifier.verify(signatureBytes)) { "La firma de ProControl no es válida; la ficha pudo ser modificada." }

        // The device binding is evaluated only after the descriptor's own
        // Ed25519 signature is proven. V4 uses the signing-key fingerprint as
        // the canonical device proof; the human/database deviceId can then be
        // reconciled locally without importing or replacing any private key.
        if (version >= 2) {
            if (version >= 4) {
                val declaredHash = document.optString("deviceSigningPublicKeyHash")
                require(declaredHash.matches(Regex("[a-f0-9]{64}")) &&
                    expectedDevicePublicKeyHash != null &&
                    MessageDigest.isEqual(
                        declaredHash.toByteArray(StandardCharsets.US_ASCII),
                        expectedDevicePublicKeyHash.toByteArray(StandardCharsets.US_ASCII)
                    )) {
                    "Este código fue generado para otra clave criptográfica de ProVenta. Exporta un ID .pvid nuevo desde este teléfono y genera una autorización nueva en ProControl."
                }
            } else {
                val declaredHash = document.optString("devicePublicKeyHash")
                require(declaredHash.matches(Regex("[a-f0-9]{64}")) &&
                    expectedDevicePublicKeyHash != null &&
                    MessageDigest.isEqual(
                        declaredHash.toByteArray(StandardCharsets.US_ASCII),
                        expectedDevicePublicKeyHash.toByteArray(StandardCharsets.US_ASCII)
                    )) {
                    "Código incorrecto. La clave de seguridad no corresponde a este teléfono."
                }
                require(expectedDeviceId != null && deviceId == expectedDeviceId) {
                    "Código incorrecto. Este código pertenece a otro teléfono."
                }
            }
        }

        return VerifiedDeviceAuthorization(
            installationId = installationId,
            authorizationId = authorizationId,
            desktopId = desktopId,
            code = code,
            employeeName = employeeName,
            expiresAt = expiresAt,
            desktopPublicKeyPem = desktopPublicKeyPem,
            rawJson = document.toString(),
            deviceId = deviceId,
            permanent = permanent,
            version = version,
            installationCode = installationCode,
            authorizedPosId = authorizedPosId,
            authorizedPosName = authorizedPosName,
            deviceSigningPublicKeyHash = if (version >= 4) {
                document.optString("deviceSigningPublicKeyHash").takeIf { it.isNotBlank() }
            } else {
                document.optString("devicePublicKeyHash").takeIf { it.isNotBlank() }
            },
            renewalSequence = renewalSequence
        )
    }

    private fun parseEd25519PublicKey(pem: String): java.security.PublicKey {
        require(pem.length <= 8192 && pem.contains("BEGIN PUBLIC KEY")) {
            "Clave pública de ProControl inválida."
        }
        val base64 = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() }
        val der = Base64.getDecoder().decode(base64)
        return KeyFactory.getInstance("Ed25519", provider).generatePublic(X509EncodedKeySpec(der))
    }

    private fun installationCodeFromId(installationId: String): String {
        val match = Regex("^pcinst_([a-f0-9]{32})$").matchEntire(installationId)
            ?: throw IllegalArgumentException("Identidad de instalación inválida.")
        val short = match.groupValues[1].take(16).uppercase(Locale.ROOT)
        return "PC-${short.substring(0, 4)}-${short.substring(4, 8)}-${short.substring(8, 12)}-${short.substring(12, 16)}"
    }

    private fun installationFingerprint(publicKeyDer: ByteArray): String {
        val hash = MessageDigest.getInstance("SHA-256").digest(publicKeyDer)
        val hex = hash.joinToString("") { "%02x".format(it) }
        return "pcinst_" + hex.take(32)
    }

    private companion object {
        const val FORMAT = "procontrol.device-authorization"
        const val MAX_DESCRIPTOR_BYTES = 64 * 1024
        const val QR_CODE_TTL_MILLIS = 5 * 60 * 1000L
    }
}

object DeviceActivationEnvelope {
    private const val FORMAT = "procontrol.device-link"
    private const val VERSION = 1
    private const val ALGORITHM = "RSA-OAEP-256+A256GCM"
    private const val MAX_ENVELOPE_BYTES = 128 * 1024
    private const val MAX_WRAPPED_KEY_BYTES = 1024
    private const val MAX_CIPHERTEXT_BYTES = 64 * 1024
    private const val AES_KEY_BYTES = 32
    private const val GCM_IV_BYTES = 12
    private const val GCM_TAG_BYTES = 16
    private val provider = BouncyCastleProvider()
    private val headerFields = listOf(
        "format", "version", "algorithm", "installationId", "installationCode",
        "authorizationId", "deviceId", "authorizedPosId", "createdAt", "expiresAt",
        "payloadHash", "signerPublicKey"
    )

    /**
     * Opens the exact .pvlink envelope emitted by ProControl's v4 device-link flow.
     * The outer Ed25519 signature is verified before RSA/AES decryption; the GCM AAD
     * is the canonical JSON header (not a custom delimiter string).
     */
    fun decrypt(
        envelopeJson: String,
        encryptionPrivateKey: PrivateKey,
        expectedDeviceId: String,
        nowMillis: Long = System.currentTimeMillis()
    ): Pair<String, String> {
        require(envelopeJson.toByteArray(StandardCharsets.UTF_8).size in 1..MAX_ENVELOPE_BYTES) {
            "El archivo .pvlink está vacío o supera el tamaño permitido."
        }
        val envelope = JSONObject(envelopeJson)
        require(envelope.optString("format") == FORMAT &&
            envelope.optInt("version") == VERSION &&
            envelope.optString("algorithm") == ALGORITHM) {
            "El archivo no es una vinculación .pvlink v4 de ProControl."
        }

        val installationId = envelope.optString("installationId")
        val installationCode = envelope.optString("installationCode")
        val authorizationId = envelope.optString("authorizationId")
        val deviceId = envelope.optString("deviceId")
        val authorizedPosId = envelope.optString("authorizedPosId")
        val createdAt = envelope.optString("createdAt")
        val expiresAt = exactLong(envelope.opt("expiresAt"), "expiresAt")
        val payloadHash = envelope.optString("payloadHash")
        val signerPublicKeyPem = envelope.optString("signerPublicKey")

        require(installationId.matches(Regex("pcinst_[a-f0-9]{32}"))) {
            "La identidad de instalación del archivo .pvlink no es válida."
        }
        require(installationCode.matches(Regex("PC-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}"))) {
            "El código identificador de ProControl no es válido."
        }
        require(authorizationId.matches(Regex("auth_[A-Za-z0-9-]{20,60}"))) {
            "El identificador de autorización del archivo .pvlink no es válido."
        }
        require(deviceId == expectedDeviceId) {
            "Este archivo de activación pertenece a otro teléfono."
        }
        require(authorizedPosId.matches(Regex("[A-Za-z0-9:_-]{1,160}"))) {
            "El archivo .pvlink no contiene un punto de venta válido."
        }
        val createdAtMillis = try {
            Instant.parse(createdAt).toEpochMilli()
        } catch (_: Exception) {
            throw IllegalArgumentException("El archivo .pvlink contiene una fecha de emisión inválida.")
        }
        require(createdAtMillis > 0L && expiresAt > createdAtMillis && expiresAt > nowMillis) {
            "El archivo .pvlink ha caducado o contiene fechas inválidas. Solicita una autorización nueva a ProControl."
        }
        require(payloadHash.matches(Regex("[a-f0-9]{64}"))) {
            "El hash del contenido del archivo .pvlink no es válido."
        }

        // Authenticate all outer metadata and encryption fields before attempting
        // to unwrap the AES key. The signed document is the complete envelope
        // minus only its signature, exactly as signed by ProControl.
        val signatureObject = envelope.optJSONObject("signature")
            ?: throw IllegalArgumentException("El archivo .pvlink no contiene firma digital.")
        require(signatureObject.optString("algorithm") == "Ed25519") {
            "La firma exterior del archivo .pvlink no es compatible."
        }
        val signerPublicKey = parseEd25519PublicKey(signerPublicKeyPem)
        val outerSignature = decodeBoundedBase64(signatureObject.optString("value"), 64, 128)
        val outerVerifier = Signature.getInstance("Ed25519", provider)
        outerVerifier.initVerify(signerPublicKey)
        outerVerifier.update(
            CanonicalJson.stringify(CanonicalJson.withoutSignature(envelope))
                .toByteArray(StandardCharsets.UTF_8)
        )
        require(outerVerifier.verify(outerSignature)) {
            "La firma exterior del archivo .pvlink no es válida o sus metadatos fueron alterados."
        }

        val encryption = envelope.optJSONObject("encryption")
            ?: throw IllegalArgumentException("El archivo .pvlink no contiene los parámetros de cifrado.")
        require(encryption.optString("keyWrap") == "RSA-OAEP-SHA256" &&
            encryption.optString("contentCipher") == "AES-256-GCM") {
            "Los parámetros de cifrado del archivo .pvlink no son compatibles."
        }
        val wrappedKey = decodeBoundedBase64(encryption.optString("wrappedKey"), 256, MAX_WRAPPED_KEY_BYTES)
        val iv = decodeBoundedBase64(encryption.optString("iv"), GCM_IV_BYTES, GCM_IV_BYTES)
        val tag = decodeBoundedBase64(encryption.optString("tag"), GCM_TAG_BYTES, GCM_TAG_BYTES)
        val ciphertext = decodeBoundedBase64(envelope.optString("ciphertext"), 1, MAX_CIPHERTEXT_BYTES)

        val dataKey = try {
            val rsa = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", provider)
            rsa.init(
                Cipher.DECRYPT_MODE,
                encryptionPrivateKey,
                OAEPParameterSpec(
                    "SHA-256",
                    "MGF1",
                    MGF1ParameterSpec.SHA256,
                    PSource.PSpecified.DEFAULT
                )
            )
            rsa.doFinal(wrappedKey)
        } catch (_: Exception) {
            throw IllegalArgumentException("No se pudo abrir el archivo de activación en este teléfono.")
        }

        val plaintext = try {
            require(dataKey.size == AES_KEY_BYTES) { "La clave AES del archivo .pvlink no tiene 256 bits." }
            val header = JSONObject()
            headerFields.forEach { field ->
                require(envelope.has(field)) { "Falta el campo firmado $field en el archivo .pvlink." }
                header.put(field, envelope.get(field))
            }
            val aes = Cipher.getInstance("AES/GCM/NoPadding")
            aes.init(Cipher.DECRYPT_MODE, SecretKeySpec(dataKey, "AES"), GCMParameterSpec(128, iv))
            aes.updateAAD(CanonicalJson.stringify(header).toByteArray(StandardCharsets.UTF_8))
            aes.doFinal(ciphertext + tag)
        } catch (error: Exception) {
            throw SecurityException("El contenido del archivo .pvlink no superó la verificación AES-GCM.", error)
        } finally {
            dataKey.fill(0)
        }

        try {
            val actualHash = MessageDigest.getInstance("SHA-256").digest(plaintext)
                .joinToString("") { "%02x".format(it) }
            require(MessageDigest.isEqual(
                payloadHash.toByteArray(StandardCharsets.US_ASCII),
                actualHash.toByteArray(StandardCharsets.US_ASCII)
            )) { "El hash del contenido descifrado del archivo .pvlink no coincide." }

            val rawJson = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                .decode(java.nio.ByteBuffer.wrap(plaintext))
                .toString()
            val descriptor = JSONObject(rawJson)
            require(descriptor.optString("format") == "procontrol.device-authorization" &&
                descriptor.optInt("version") == 4 &&
                descriptor.optBoolean("permanent") &&
                descriptor.optString("deviceId") == deviceId &&
                descriptor.optString("authorizationId") == authorizationId &&
                descriptor.optString("installationId") == installationId &&
                descriptor.optString("installationCode") == installationCode &&
                descriptor.optString("authorizedPosId") == authorizedPosId &&
                descriptor.optString("desktopPublicKey") == signerPublicKeyPem &&
                exactLong(descriptor.opt("expiresAt"), "descriptor.expiresAt") == expiresAt &&
                descriptor.optString("createdAt") == createdAt) {
                "El contenido descifrado no coincide con la instalación, teléfono, POS o firma del archivo .pvlink."
            }
            return rawJson to authorizationId
        } finally {
            plaintext.fill(0)
        }
    }

    private fun parseEd25519PublicKey(pem: String): java.security.PublicKey {
        require(pem.length in 100..8192 && pem.contains("BEGIN PUBLIC KEY")) {
            "Clave pública firmante inválida en el archivo .pvlink."
        }
        val base64 = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() }
        val der = Base64.getDecoder().decode(base64)
        return KeyFactory.getInstance("Ed25519", provider).generatePublic(X509EncodedKeySpec(der))
    }

    private fun exactLong(value: Any?, field: String): Long {
        require(value is Number) { "El campo $field del archivo .pvlink no es numérico." }
        return try {
            java.math.BigDecimal(value.toString()).longValueExact()
        } catch (_: ArithmeticException) {
            throw IllegalArgumentException("El campo $field del archivo .pvlink debe ser un entero exacto.")
        }
    }

    private fun decodeBoundedBase64(value: String, min: Int, max: Int): ByteArray {
        require(value.isNotBlank() && value.length <= max * 2) {
            "El archivo de activación contiene datos inválidos."
        }
        val decoded = try {
            Base64.getDecoder().decode(value)
        } catch (_: Exception) {
            throw IllegalArgumentException("El archivo de activación está dañado.")
        }
        require(decoded.size in min..max) { "El archivo de activación está incompleto." }
        return decoded
    }
}

/**
 * Prevents a previously issued authorization from rolling an already activated
 * phone back to an older authorization within the same installation.
 * A deliberate replacement must carry a later signed createdAt timestamp and a new
 * authorizationId. A re-import of the exact same descriptor remains idempotent.
 */
internal object DeviceAuthorizationReplacementPolicy {
    fun validate(existingRawJson: String, candidate: VerifiedDeviceAuthorization) {
        val current = JSONObject(existingRawJson)
        require(current.optString("format") == "procontrol.device-authorization" &&
            current.optInt("version") in 1..6) {
            "La autorización guardada está dañada. No se reemplazará automáticamente."
        }
        require(current.optString("installationId") == candidate.installationId) {
            "Este teléfono ya está asociado a otra instalación ProControl. No se cambiará de empresa automáticamente."
        }

        val currentVersion = current.optInt("version")
        require(candidate.version >= currentVersion) {
            "No se permite reemplazar una autorización por un formato anterior."
        }
        if (currentVersion < 4 || candidate.version < 4) return

        val currentAuthorizationId = current.optString("authorizationId")
        if (currentAuthorizationId == candidate.authorizationId) {
            if (candidate.version >= 6) {
                val currentSequence = current.optLong("renewalSequence", 0L)
                require(candidate.renewalSequence > currentSequence) {
                    "Este QR ya fue usado o no es una renovación más reciente. Solicita un QR nuevo a ProControl."
                }
                val next = JSONObject(candidate.rawJson)
                val immutableFields = listOf(
                    "format", "installationId", "installationCode", "authorizationId",
                    "deviceId", "deviceSigningPublicKeyHash", "authorizationScope",
                    "employeeName", "permanent", "desktopPublicKey"
                )
                immutableFields.forEach { field ->
                    require(current.opt(field)?.toString() == next.opt(field)?.toString()) {
                        "El identificador de autorización ya está vinculado a otros datos. Solicita una autorización nueva a ProControl."
                    }
                }
                return
            }
            val currentContent = CanonicalJson.stringify(CanonicalJson.withoutSignature(current))
            val candidateContent = CanonicalJson.stringify(
                CanonicalJson.withoutSignature(JSONObject(candidate.rawJson))
            )
            require(currentContent == candidateContent) {
                "El identificador de autorización ya está vinculado a otros datos. Solicita una autorización nueva a ProControl."
            }
            return
        }

        val currentCreatedAt = parseCreatedAt(current.optString("createdAt"))
        val candidateCreatedAt = parseCreatedAt(JSONObject(candidate.rawJson).optString("createdAt"))
        require(candidateCreatedAt > currentCreatedAt) {
            "Se rechazó una autorización anterior o simultánea. Para cambiar de POS, solicita un vínculo nuevo y posterior al actual."
        }
    }

    private fun parseCreatedAt(value: String): Long = try {
        Instant.parse(value).toEpochMilli()
    } catch (_: Exception) {
        throw IllegalArgumentException("La fecha de autorización guardada no es válida. No se permite reemplazarla.")
    }
}

class DeviceEnrollmentRequestFactory(context: Context) {
    private val appContext = context.applicationContext
    private val secureStore = SecureLocalStore(appContext)
    private val keyManager = DeviceKeyManager(appContext)
    private val verifier = DeviceAuthorizationDescriptorVerifier()
    private val provider = BouncyCastleProvider()

    fun createDeviceIdentityToken(deviceLabel: String): ProVentaDeviceIdentity {
        val label = deviceLabel.trim().take(80).ifBlank { "Teléfono ProVenta" }
        val keys = keyManager.getOrCreate()
        val cachedIdentity = secureStore.get(DEVICE_IDENTITY_RECORD)
        if (cachedIdentity != null) {
            try {
                val cachedJson = String(cachedIdentity, StandardCharsets.UTF_8)
                val cachedDocument = JSONObject(cachedJson)
                if (cachedDocument.optString("deviceId") == keys.deviceId &&
                    cachedDocument.optString("devicePublicKey") == keys.signingPublicPem &&
                    cachedDocument.optString("deviceEncryptionPublicKey") == keys.encryptionPublicPem
                ) {
                    val cachedEncoded = Base64.getUrlEncoder().withoutPadding()
                        .encodeToString(cachedJson.toByteArray(StandardCharsets.UTF_8))
                    return ProVentaDeviceIdentity(keys.deviceId, "PVID1:$cachedEncoded")
                }
            } finally {
                cachedIdentity.fill(0)
            }
        }
        val document = JSONObject()
            .put("format", "proventa.device-identity")
            .put("version", 1)
            .put("deviceId", keys.deviceId)
            .put("label", label)
            .put("devicePublicKey", keys.signingPublicPem)
            .put("deviceEncryptionPublicKey", keys.encryptionPublicPem)
            .put("createdAt", Instant.now().toString())
        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(keys.signingPrivateKey)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        document.put(
            "signature",
            JSONObject().put("algorithm", "Ed25519")
                .put("value", Base64.getEncoder().encodeToString(signer.sign()))
        )
        val signedIdentity = document.toString()
        secureStore.put(DEVICE_IDENTITY_RECORD, signedIdentity.toByteArray(StandardCharsets.UTF_8))
        val encoded = Base64.getUrlEncoder().withoutPadding()
            .encodeToString(signedIdentity.toByteArray(StandardCharsets.UTF_8))
        return ProVentaDeviceIdentity(keys.deviceId, "PVID1:$encoded")
    }

    /**
     * Activates the signed PVLA2 descriptor generated by ProControl.
     * The UI can obtain the same descriptor either from the .pvla2 file or by
     * reassembling the PCQ1/D QR frames; both transports call this identical
     * signature/device/POS verifier. No .pvlink file or separate PIN is needed.
     */
    @Synchronized
    fun activateWithActivationCode(
        activationCode: String,
        nowMillis: Long = System.currentTimeMillis()
    ): VerifiedDeviceAuthorization {
        checkActivationAttemptAllowed(nowMillis)
        try {
            val rawJson = ProVentaActivationCode.decode(activationCode)
            val keys = keyManager.getOrCreate()
            val localSigningKeyHash = publicKeySha256(keys.signingPublicPem)
            val verified = verifier.verify(
                rawJson = rawJson,
                nowMillis = nowMillis,
                expectedDeviceId = keys.deviceId,
                expectedDevicePublicKeyHash = localSigningKeyHash
            )
            require(
                verified.permanent && verified.version == 6 &&
                    verified.authorizedPosId.isNullOrBlank() &&
                    verified.renewalSequence >= 1L
            ) {
                "El QR no contiene una autorización mensual vigente de ProControl. Escanea un QR nuevo del Dueño."
            }
            val authorizedDeviceId = verified.deviceId
                ?: throw IllegalArgumentException("La autorización no contiene el ID firmado del teléfono.")
            if (authorizedDeviceId != keys.deviceId) {
                // Rebind the local record ID only after Ed25519 signature validation
                // and a constant-time match of the enrolled phone's signing key.
                keyManager.adoptAuthorizedDeviceId(authorizedDeviceId, localSigningKeyHash)
            }
            persistVerifiedAuthorization(verified, nowMillis)
            clearActivationAttempts()
            return verified
        } catch (error: Exception) {
            registerActivationFailure(nowMillis)
            throw error
        }
    }

    /**
     * Legacy file-envelope entry retained for migration/regression tests only.
     * The current UI activates v4 from the signed PVLA2 clipboard token instead.
     */
    @Synchronized
    fun activateWithEnvelope(
        activationCode: String,
        envelopeJson: String,
        nowMillis: Long = System.currentTimeMillis()
    ): VerifiedDeviceAuthorization {
        checkActivationAttemptAllowed(nowMillis)
        try {
            val keys = keyManager.getOrCreate()
            val (rawJson, envelopeAuthorizationId) = DeviceActivationEnvelope.decrypt(
                envelopeJson = envelopeJson,
                encryptionPrivateKey = keys.encryptionPrivateKey,
                expectedDeviceId = keys.deviceId,
                nowMillis = nowMillis
            )
            // V4 can only be persisted after opening the signed, device-encrypted
            // .pvlink envelope. Never route this through the legacy descriptor importer.
            val verified = verifier.verify(
                rawJson = rawJson,
                nowMillis = nowMillis,
                expectedDeviceId = keys.deviceId,
                expectedDevicePublicKeyHash = publicKeySha256(keys.signingPublicPem)
            )
            require(verified.version == 4 && verified.permanent) {
                "La vinculación móvil requiere una autorización permanente v4 dentro de un archivo .pvlink."
            }
            require(verified.authorizationId == envelopeAuthorizationId) {
                "El archivo de activación no corresponde a la autorización declarada."
            }
            verifyActivationPin(verified, activationCode)
            persistVerifiedAuthorization(verified, nowMillis)
            clearActivationAttempts()
            return verified
        } catch (error: Exception) {
            registerActivationFailure(nowMillis)
            throw error
        }
    }

    private fun verifyActivationPin(verified: VerifiedDeviceAuthorization, suppliedCode: String) {
        val code = suppliedCode.trim()
        require(code.matches(Regex("[0-9]{8}")) &&
            MessageDigest.isEqual(
                code.toByteArray(StandardCharsets.US_ASCII),
                verified.code.toByteArray(StandardCharsets.US_ASCII)
            )) {
            "El PIN de ocho cifras no coincide con la autorización firmada por ProControl."
        }
    }

    private fun checkActivationAttemptAllowed(nowMillis: Long) {
        val bytes = secureStore.get(ACTIVATION_ATTEMPTS_RECORD) ?: return
        try {
            val record = try {
                JSONObject(String(bytes, StandardCharsets.UTF_8))
            } catch (_: Exception) {
                null
            }
            val failures = record?.optInt("failures", -1) ?: -1
            val lockedUntil = record?.optLong("lockedUntil", -1L) ?: -1L
            val validCounterState = when {
                failures in 0 until MAX_ACTIVATION_FAILURES -> lockedUntil == 0L
                failures == MAX_ACTIVATION_FAILURES ->
                    lockedUntil > 0L && lockedUntil - nowMillis <= ACTIVATION_LOCKOUT_MS
                else -> false
            }
            if (record == null || !validCounterState) {
                val newLockoutUntil = Math.addExact(nowMillis, ACTIVATION_LOCKOUT_MS)
                secureStore.put(
                    ACTIVATION_ATTEMPTS_RECORD,
                    JSONObject().put("failures", MAX_ACTIVATION_FAILURES)
                        .put("lockedUntil", newLockoutUntil)
                        .toString().toByteArray(StandardCharsets.UTF_8)
                )
                throw IllegalStateException("El registro de intentos está dañado. Por seguridad, la activación queda bloqueada durante 15 minutos.")
            }
            if (lockedUntil > nowMillis) {
                val remainingSeconds = ((lockedUntil - nowMillis + 999L) / 1000L).coerceAtLeast(1L)
                throw IllegalStateException("Demasiados intentos. Vuelve a probar en $remainingSeconds segundos.")
            }
            if (lockedUntil > 0L && lockedUntil <= nowMillis) {
                secureStore.put(
                    ACTIVATION_ATTEMPTS_RECORD,
                    JSONObject().put("failures", 0).put("lockedUntil", 0L)
                        .toString().toByteArray(StandardCharsets.UTF_8)
                )
            }
        } finally {
            bytes.fill(0)
        }
    }

    private fun registerActivationFailure(nowMillis: Long) {
        val bytes = secureStore.get(ACTIVATION_ATTEMPTS_RECORD)
        val failures = try {
            if (bytes == null) {
                0
            } else {
                val record = JSONObject(String(bytes, StandardCharsets.UTF_8))
                val storedFailures = record.optInt("failures", -1)
                val storedLockout = record.optLong("lockedUntil", -1L)
                require(storedFailures in 0..MAX_ACTIVATION_FAILURES && storedLockout >= 0L)
                storedFailures
            }
        } catch (_: Exception) {
            // A malformed local counter must never reset the brute-force limit.
            MAX_ACTIVATION_FAILURES - 1
        } finally {
            bytes?.fill(0)
        }
        val nextFailures = (failures + 1).coerceAtMost(MAX_ACTIVATION_FAILURES)
        val lockedUntil = if (nextFailures >= MAX_ACTIVATION_FAILURES) {
            nowMillis + ACTIVATION_LOCKOUT_MS
        } else 0L
        secureStore.put(
            ACTIVATION_ATTEMPTS_RECORD,
            JSONObject().put("failures", nextFailures).put("lockedUntil", lockedUntil)
                .toString().toByteArray(StandardCharsets.UTF_8)
        )
    }

    private fun clearActivationAttempts() {
        secureStore.put(
            ACTIVATION_ATTEMPTS_RECORD,
            JSONObject().put("failures", 0).put("lockedUntil", 0L)
                .toString().toByteArray(StandardCharsets.UTF_8)
        )
    }

    /**
     * Legacy fixture/import hook retained for pre-v4 regression tests only.
     * Production v4 authorization must enter through activateWithActivationCode().
     */
    @Synchronized
    internal fun activateWithCode(
        activationCode: String,
        nowMillis: Long = System.currentTimeMillis()
    ): VerifiedDeviceAuthorization {
        val rawJson = ProVentaActivationCode.decode(activationCode)
        val keys = keyManager.getOrCreate()
        return importAuthorizationDescriptor(
            rawJson = rawJson,
            expectedDeviceId = keys.deviceId,
            expectedDevicePublicKeyHash = publicKeySha256(keys.signingPublicPem),
            nowMillis = nowMillis
        )
    }

    /**
     * Legacy-only persistence hook. Version 4 is explicitly rejected so no app
     * path can store a v4 descriptor without validating its signed PVLA2 token.
     */
    @Synchronized
    internal fun importAuthorizationDescriptor(
        rawJson: String,
        expectedOneTimeCode: String? = null,
        expectedDeviceId: String? = null,
        expectedDevicePublicKeyHash: String? = null,
        nowMillis: Long = System.currentTimeMillis()
    ): VerifiedDeviceAuthorization {
        val verified = verifier.verify(
            rawJson = rawJson,
            nowMillis = nowMillis,
            expectedDeviceId = expectedDeviceId,
            expectedDevicePublicKeyHash = expectedDevicePublicKeyHash
        )
        require(verified.version < 4) {
            "Las autorizaciones v4 solo pueden instalarse desde un archivo .pvlink cifrado y firmado."
        }
        val expectedCode = expectedOneTimeCode?.trim()?.takeIf { it.isNotEmpty() }
        if (expectedCode != null) {
            val expectedLength = if (verified.version >= 3) 8 else 6
            require(expectedCode.matches(Regex("[0-9]{$expectedLength}")) &&
                MessageDigest.isEqual(
                    expectedCode.toByteArray(StandardCharsets.US_ASCII),
                    verified.code.toByteArray(StandardCharsets.US_ASCII)
                )) {
                "El código introducido no coincide con el código firmado de ProControl."
            }
        }
        persistVerifiedAuthorization(verified)
        return verified
    }

    @Synchronized
    private fun persistVerifiedAuthorization(
        verified: VerifiedDeviceAuthorization,
        nowMillis: Long = System.currentTimeMillis()
    ) {
        val existing = secureStore.get(AUTHORIZATION_RECORD)
        val previousAccess = secureStore.get(MONTHLY_ACCESS_RECORD)
        try {
            if (existing != null) {
                DeviceAuthorizationReplacementPolicy.validate(
                    existingRawJson = String(existing, StandardCharsets.UTF_8),
                    candidate = verified
                )
            }
            if (verified.version < 6) {
                secureStore.put(AUTHORIZATION_RECORD, verified.rawJson.toByteArray(StandardCharsets.UTF_8))
                return
            }
            require(verified.version == 6 && verified.renewalSequence >= 1L) {
                "La autorización no incluye una secuencia mensual válida."
            }
            if (previousAccess != null) {
                val oldWindow = parseMonthlyAccessRecord(previousAccess)
                if (oldWindow.authorizationId == verified.authorizationId) {
                    require(verified.renewalSequence > oldWindow.renewalSequence) {
                        "Este QR ya fue usado. Solicita un QR de renovación nuevo a ProControl."
                    }
                }
            }
            val newWindow = MonthlyAccessWindow.create(
                installationId = verified.installationId,
                authorizationId = verified.authorizationId,
                renewalSequence = verified.renewalSequence,
                nowMillis = nowMillis,
                elapsedRealtimeMillis = SystemClock.elapsedRealtime(),
                bootCount = currentBootCount(),
                zoneId = java.time.ZoneId.systemDefault().id
            )
            try {
                secureStore.put(AUTHORIZATION_RECORD, verified.rawJson.toByteArray(StandardCharsets.UTF_8))
                secureStore.put(MONTHLY_ACCESS_RECORD, monthlyAccessRecordJson(newWindow).toByteArray(StandardCharsets.UTF_8))
            } catch (writeError: Exception) {
                try {
                    if (existing == null) secureStore.delete(AUTHORIZATION_RECORD)
                    else secureStore.put(AUTHORIZATION_RECORD, existing)
                    if (previousAccess == null) secureStore.delete(MONTHLY_ACCESS_RECORD)
                    else secureStore.put(MONTHLY_ACCESS_RECORD, previousAccess)
                } catch (rollbackError: Exception) {
                    writeError.addSuppressed(rollbackError)
                }
                throw writeError
            }
        } finally {
            existing?.fill(0)
            previousAccess?.fill(0)
        }
    }

    fun hasStoredAuthorizationRecord(): Boolean {
        val bytes = secureStore.get(AUTHORIZATION_RECORD) ?: return false
        bytes.fill(0)
        return true
    }

    fun monthlyAccessExpiryMillis(): Long? {
        val bytes = secureStore.get(MONTHLY_ACCESS_RECORD) ?: return null
        return try {
            parseMonthlyAccessRecord(bytes).expiresAtMillis
        } finally {
            bytes.fill(0)
        }
    }

    @Synchronized
    fun trustedInstallationAuthorization(nowMillis: Long = System.currentTimeMillis()): VerifiedDeviceAuthorization? {
        val bytes = secureStore.get(AUTHORIZATION_RECORD) ?: return null
        return try {
            val keys = keyManager.getOrCreate()
            val localSigningKeyHash = publicKeySha256(keys.signingPublicPem)
            val verified = verifier.verify(
                String(bytes, StandardCharsets.UTF_8),
                nowMillis,
                enforceCodeExpiry = false,
                expectedDeviceId = keys.deviceId,
                expectedDevicePublicKeyHash = localSigningKeyHash
            )
            val authorizedDeviceId = verified.deviceId
            if (verified.version >= 4 && !authorizedDeviceId.isNullOrBlank() && authorizedDeviceId != keys.deviceId) {
                keyManager.adoptAuthorizedDeviceId(authorizedDeviceId, localSigningKeyHash)
            }
            if (!verified.permanent || verified.version != 6) return null
            val accessBytes = secureStore.get(MONTHLY_ACCESS_RECORD) ?: return null
            try {
                val storedWindow = parseMonthlyAccessRecord(accessBytes)
                val checked = MonthlyAccessWindow.check(
                    record = storedWindow,
                    installationId = verified.installationId,
                    authorizationId = verified.authorizationId,
                    renewalSequence = verified.renewalSequence,
                    nowMillis = nowMillis,
                    elapsedRealtimeMillis = SystemClock.elapsedRealtime(),
                    bootCount = currentBootCount()
                )
                val updatedWindow = checked.record ?: return null
                if (updatedWindow.lastWallClockMillis - storedWindow.lastWallClockMillis >= ACCESS_WINDOW_CHECKPOINT_MILLIS ||
                    updatedWindow.bootCount != storedWindow.bootCount) {
                    secureStore.put(
                        MONTHLY_ACCESS_RECORD,
                        monthlyAccessRecordJson(updatedWindow).toByteArray(StandardCharsets.UTF_8)
                    )
                }
                verified
            } finally {
                accessBytes.fill(0)
            }
        } finally {
            bytes.fill(0)
        }
    }

    private fun currentBootCount(): Int = try {
        Settings.Global.getInt(appContext.contentResolver, Settings.Global.BOOT_COUNT, -1)
    } catch (_: Exception) {
        -1
    }

    private fun monthlyAccessRecordJson(record: MonthlyAccessRecord): String = JSONObject()
        .put("format", MONTHLY_ACCESS_FORMAT)
        .put("version", 1)
        .put("installationId", record.installationId)
        .put("authorizationId", record.authorizationId)
        .put("renewalSequence", record.renewalSequence)
        .put("activatedAtMillis", record.activatedAtMillis)
        .put("expiresAtMillis", record.expiresAtMillis)
        .put("zoneId", record.zoneId)
        .put("lastWallClockMillis", record.lastWallClockMillis)
        .put("lastElapsedRealtimeMillis", record.lastElapsedRealtimeMillis)
        .put("bootCount", record.bootCount)
        .toString()

    private fun parseMonthlyAccessRecord(bytes: ByteArray): MonthlyAccessRecord {
        val document = JSONObject(String(bytes, StandardCharsets.UTF_8))
        require(document.optString("format") == MONTHLY_ACCESS_FORMAT && document.optInt("version") == 1) {
            "El registro de vigencia mensual no tiene un formato compatible."
        }
        return MonthlyAccessRecord(
            installationId = document.getString("installationId"),
            authorizationId = document.getString("authorizationId"),
            renewalSequence = document.getLong("renewalSequence"),
            activatedAtMillis = document.getLong("activatedAtMillis"),
            expiresAtMillis = document.getLong("expiresAtMillis"),
            zoneId = document.getString("zoneId"),
            lastWallClockMillis = document.getLong("lastWallClockMillis"),
            lastElapsedRealtimeMillis = document.getLong("lastElapsedRealtimeMillis"),
            bootCount = document.getInt("bootCount")
        )
    }

    fun pendingAuthorization(nowMillis: Long = System.currentTimeMillis()): VerifiedDeviceAuthorization? {
        val bytes = secureStore.get(AUTHORIZATION_RECORD) ?: return null
        return try {
            val keys = keyManager.getOrCreate()
            val localSigningKeyHash = publicKeySha256(keys.signingPublicPem)
            val verified = verifier.verify(
                String(bytes, StandardCharsets.UTF_8),
                nowMillis,
                enforceCodeExpiry = true,
                expectedDeviceId = keys.deviceId,
                expectedDevicePublicKeyHash = localSigningKeyHash
            )
            val authorizedDeviceId = verified.deviceId
            if (verified.version >= 4 && !authorizedDeviceId.isNullOrBlank() && authorizedDeviceId != keys.deviceId) {
                keyManager.adoptAuthorizedDeviceId(authorizedDeviceId, localSigningKeyHash)
            }
            verified
        } catch (_: IllegalArgumentException) {
            null
        } finally {
            bytes.fill(0)
        }
    }

    @Synchronized
    fun createEnrollmentRequest(deviceLabel: String, nowMillis: Long = System.currentTimeMillis()): String {
        val label = deviceLabel.trim()
        require(label.isNotEmpty() && label.length <= 80) {
            "Escribe una etiqueta para identificar este teléfono (máximo 80 caracteres)."
        }
        val authorizationBytes = secureStore.get(AUTHORIZATION_RECORD)
            ?: throw IllegalStateException("Primero valida el código permanente de ProControl para este teléfono.")
        var deviceKeys = keyManager.getOrCreate()
        val localSigningKeyHash = publicKeySha256(deviceKeys.signingPublicPem)
        val authorization = try {
            verifier.verify(
                String(authorizationBytes, StandardCharsets.UTF_8),
                nowMillis,
                expectedDeviceId = deviceKeys.deviceId,
                expectedDevicePublicKeyHash = localSigningKeyHash
            )
        } finally {
            authorizationBytes.fill(0)
        }
        val authorizedDeviceId = authorization.deviceId
        if (authorization.version >= 4 && !authorizedDeviceId.isNullOrBlank() && authorizedDeviceId != deviceKeys.deviceId) {
            keyManager.adoptAuthorizedDeviceId(authorizedDeviceId, localSigningKeyHash)
            deviceKeys = keyManager.getOrCreate()
        }

        val cacheRecord = enrollmentRecordId(authorization.authorizationId)
        val cached = secureStore.get(cacheRecord)
        if (cached != null) {
            try {
                val cachedJson = JSONObject(String(cached, StandardCharsets.UTF_8))
                val cacheStillMatchesIdentity =
                    cachedJson.optString("authorizationId") == authorization.authorizationId &&
                    cachedJson.optString("deviceId") == deviceKeys.deviceId &&
                    cachedJson.optString("devicePublicKey") == deviceKeys.signingPublicPem
                if (cacheStillMatchesIdentity) {
                    return String(cached, StandardCharsets.UTF_8)
                }
                // An older cached enrollment request must not keep the pre-migration
                // ID after a v4 signed-key reconciliation.
                secureStore.delete(cacheRecord)
            } finally {
                cached.fill(0)
            }
        }

        val document = JSONObject()
            .put("format", "procontrol.device-enrollment-request")
            .put("version", 2)
            .put("installationId", authorization.installationId)
            .put("authorizationId", authorization.authorizationId)
            .put("code", authorization.code)
            .put("deviceId", deviceKeys.deviceId)
            .put("label", label)
            .put("devicePublicKey", deviceKeys.signingPublicPem)
            .put("deviceEncryptionPublicKey", deviceKeys.encryptionPublicPem)
            .put("createdAt", Instant.ofEpochMilli(nowMillis).toString())

        val signer = Signature.getInstance("Ed25519", provider)
        signer.initSign(deviceKeys.signingPrivateKey)
        signer.update(CanonicalJson.stringify(document).toByteArray(StandardCharsets.UTF_8))
        val signature = Base64.getEncoder().encodeToString(signer.sign())
        document.put(
            "signature",
            JSONObject().put("algorithm", "Ed25519").put("value", signature)
        )

        val result = document.toString(2)
        secureStore.put(cacheRecord, result.toByteArray(StandardCharsets.UTF_8))
        return result
    }

    private fun publicKeySha256(publicKeyPem: String): String {
        val base64 = publicKeyPem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() }
        val der = Base64.getDecoder().decode(base64)
        return MessageDigest.getInstance("SHA-256").digest(der)
            .joinToString("") { "%02x".format(it) }
    }

    private fun enrollmentRecordId(authorizationId: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(authorizationId.toByteArray(StandardCharsets.UTF_8))
        val shortHash = digest.take(20).joinToString("") { "%02x".format(it) }
        return "enrollment_$shortHash"
    }

    private companion object {
        const val AUTHORIZATION_RECORD = "device_authorization_descriptor"
        const val MONTHLY_ACCESS_RECORD = "monthly_access_window"
        const val MONTHLY_ACCESS_FORMAT = "proventa.monthly-access-window"
        const val ACCESS_WINDOW_CHECKPOINT_MILLIS = 30 * 1000L
        const val ACTIVATION_ATTEMPTS_RECORD = "activation_attempts"
        const val MAX_ACTIVATION_FAILURES = 5
        const val ACTIVATION_LOCKOUT_MS = 15 * 60 * 1000L
        const val DEVICE_IDENTITY_RECORD = "proventa_signed_device_identity"
    }
}
