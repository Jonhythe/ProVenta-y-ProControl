package com.proventa.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.ui.graphics.vector.ImageVector

enum class AppDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    HOME("inicio", "Inicio", Icons.Filled.Storefront),
    SALES("ventas", "Ventas", Icons.Filled.PointOfSale),
    RECEIPTS("entradas", "Entradas", Icons.Filled.QrCodeScanner),
    INVENTORY("inventario", "Stock", Icons.Filled.Inventory2),
    CLOSING("cierre", "Cierre", Icons.Filled.Assessment)
}
