package com.proventa.app.data.sales

import com.proventa.app.data.entities.SaleEntity
import com.proventa.app.data.entities.SaleLineEntity
import com.proventa.app.data.entities.SalePaymentEntity
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant

/**
 * Maps one locally saved ProVenta order to the current ProControl sales-ledger
 * contract. ProControl accepts one currency/payment method per ticket, so a
 * mixed cart is split into linked sub-tickets that share mobileOrderId.
 *
 * The current desktop contract can account for CUP and USD only. EUR, MLC and
 * custom currencies are deliberately rejected until ProControl carries their
 * actual conversion rates and accounting rules; they must never be mislabeled
 * as CUP or silently combined with another currency.
 */
object SaleBatchPayloadFactory {
    private data class MappedLine(
        val currency: String,
        val paymentMethod: String,
        val nativeTotal: BigDecimal,
        val cupTotal: BigDecimal,
        val json: JSONObject
    )

    /**
     * Counts the distinct ticket groups that ProControl will receive from this
     * order. Emergency permits are consumed per desktop ticket, not per mobile
     * cart, because the desktop bridge counts payload.transactions.
     */
    fun countDesktopTickets(
        lines: List<SaleLineEntity>,
        payments: List<SalePaymentEntity>
    ): Int {
        require(lines.isNotEmpty()) { "La venta debe contener al menos un artículo." }
        val linesById = lines.associateBy { it.lineId }
        require(payments.isNotEmpty() && payments.all { it.saleLineId in linesById }) {
            "No se pueden contar tickets con pagos incompletos o líneas inexistentes."
        }
        return payments.map { payment ->
            val line = linesById[payment.saleLineId]
                ?: throw IllegalArgumentException("El pago no pertenece a una línea de la venta.")
            line.currency.uppercase() to payment.method.uppercase()
        }.distinct().size
    }

    fun create(
        sale: SaleEntity,
        lines: List<SaleLineEntity>,
        payments: List<SalePaymentEntity>,
        posName: String,
        employee: String,
        shiftPermitId: String,
        usdCupRateMicros: Long?
    ): JSONObject {
        require(sale.status == SaleStatus.PENDING_SYNC.name) {
            "Solo se pueden exportar ventas pendientes de sincronización."
        }
        require(sale.saleId.isNotBlank() && sale.posId.isNotBlank() && sale.shiftId.isNotBlank()) {
            "La venta no contiene una identidad completa de POS y turno."
        }
        require(posName.isNotBlank() && employee.isNotBlank() && shiftPermitId.isNotBlank()) {
            "Falta el nombre del punto, trabajador o permiso del turno."
        }
        require(lines.isNotEmpty() && lines.size <= 100) {
            "El ticket debe contener entre 1 y 100 artículos."
        }
        require(lines.all { it.saleId == sale.saleId }) {
            "Hay líneas que pertenecen a otra venta."
        }

        val paymentGroups = payments.groupBy { it.saleLineId }
        require(paymentGroups.keys.all { key -> lines.any { it.lineId == key } }) {
            "Hay pagos asociados a una línea inexistente."
        }

        val usdRate = usdCupRateMicros?.takeIf { it > 0L }?.let {
            BigDecimal.valueOf(it, 6)
        }
        val mappedLines = lines.map { line ->
            val linePayments = paymentGroups[line.lineId].orEmpty()
            if (linePayments.size != 1) throw UnsupportedOperationException(
                "El artículo " + line.productNameSnapshot +
                    " tiene varios métodos de pago; el registro actual de ProControl todavía no admite ese desglose por línea."
            )
            val payment = linePayments.single()
            require(payment.currency == line.currency && payment.currencyScale == line.currencyScale) {
                "El pago de " + line.productNameSnapshot + " usa una moneda o escala distinta al artículo."
            }
            require(payment.amountMinor == line.lineTotalMinor) {
                "El pago de " + line.productNameSnapshot + " no cubre exactamente el importe del artículo."
            }
            if (line.currencyScale != 2) throw UnsupportedOperationException(
                "ProControl solo admite actualmente dos decimales para " + line.currency + "."
            )

            val currency = line.currency.uppercase()
            if (currency != "CUP" && currency != "USD") throw UnsupportedOperationException(
                "La moneda " + currency +
                    " todavía no tiene una conversión contable compatible en ProControl. La venta se conservará en el teléfono."
            )
            val method = when {
                currency == "USD" && payment.method == "CASH" -> "usd"
                currency == "CUP" && payment.method == "CASH" -> "cash"
                currency == "CUP" && payment.method == "TRANSFER" -> "transfer"
                else -> throw UnsupportedOperationException(
                    "La combinación de moneda y método de pago de " + line.productNameSnapshot +
                        " todavía no es compatible con ProControl."
                )
            }
            if (method == "transfer") {
                require(!payment.transferPhone.isNullOrBlank() &&
                    !payment.transferOperationNumber.isNullOrBlank()) {
                    "La transferencia de " + line.productNameSnapshot +
                        " necesita teléfono y número de operación."
                }
            }

            val nativeUnitPrice = BigDecimal.valueOf(line.unitPriceMinor, line.currencyScale)
            val nativeTotal = BigDecimal.valueOf(line.lineTotalMinor, line.currencyScale)
                .setScale(2, RoundingMode.UNNECESSARY)
            val quantity = BigDecimal.valueOf(line.quantityMicros, 6)
            val lineCupTotal = if (currency == "USD") {
                val rate = usdRate
                    ?: throw UnsupportedOperationException(
                        "El snapshot del punto no contiene la tasa USD/CUP. La venta se conservará en el teléfono sin exportarla."
                    )
                nativeTotal.multiply(rate).setScale(2, RoundingMode.HALF_UP)
            } else {
                nativeTotal
            }

            val item = JSONObject()
                .put("productId", line.productId)
                .put("name", line.productNameSnapshot)
                .put("baseUnit", line.unitSnapshot)
                .put("presentation", "unit")
                .put("presentationQty", quantity)
                .put("presentationLabel", line.unitSnapshot)
                .put("unitsPerBox", JSONObject.NULL)
                .put("unitsPerBoxAtSale", JSONObject.NULL)
                .put("baseQty", quantity)
                .put("unitPrice", nativeUnitPrice)
                .put("currency", currency)
                .put("lineTotal", nativeTotal)
                .put("exchangeRate", if (currency == "USD") usdRate else JSONObject.NULL)
                .put("lineTotalCUP", lineCupTotal)
                .put("paymentMethod", payment.method.lowercase())

            if (payment.method == "TRANSFER") {
                item.put("transferPhone", payment.transferPhone!!.trim())
                item.put("transferOperationNumber", payment.transferOperationNumber!!.trim())
            }

            MappedLine(currency, method, nativeTotal, lineCupTotal, item)
        }

        val groups = LinkedHashMap<Pair<String, String>, MutableList<MappedLine>>()
        mappedLines.forEach { row ->
            groups.getOrPut(row.currency to row.paymentMethod) { mutableListOf() }.add(row)
        }

        val transactions = JSONArray()
        groups.forEach { (groupKey, groupLines) ->
            val currency = groupKey.first
            val method = groupKey.second
            val transactionId = sale.saleId + "_" + currency.lowercase() + "_" + method
            val nativeTotal = groupLines.fold(BigDecimal.ZERO) { total, row ->
                total.add(row.nativeTotal)
            }.setScale(2, RoundingMode.HALF_UP)
            val cupTotal = groupLines.fold(BigDecimal.ZERO) { total, row ->
                total.add(row.cupTotal)
            }.setScale(2, RoundingMode.HALF_UP)
            val items = JSONArray()
            groupLines.forEach { items.put(it.json) }

            val transaction = JSONObject()
                .put("id", transactionId)
                .put("idempotencyKey", transactionId)
                .put("schemaVersion", 1)
                .put("kind", "sale")
                .put("source", "mobile")
                .put("ts", Instant.ofEpochMilli(sale.createdAt).toString())
                .put("posId", sale.posId)
                .put("posName", posName)
                .put("user", employee)
                .put("paymentMethod", method)
                .put("currency", currency)
                .put("exchangeRate", if (currency == "USD") usdRate else JSONObject.NULL)
                .put("note", "Venta móvil ProVenta " + sale.saleId)
                .put("items", items)
                .put("totalNative", nativeTotal)
                .put("totalCUP", cupTotal)
                .put("status", "pending-close")
                .put("closingId", JSONObject.NULL)
                .put("reconciledAt", JSONObject.NULL)
                .put("shiftPermitId", shiftPermitId)
                .put("mobileOrderId", sale.saleId)
            transactions.put(transaction)
        }

        return JSONObject()
            .put("schemaVersion", 1)
            .put("permitId", shiftPermitId)
            .put("transactions", transactions)
    }
}
