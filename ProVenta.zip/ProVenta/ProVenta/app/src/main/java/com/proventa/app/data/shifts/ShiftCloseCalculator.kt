package com.proventa.app.data.shifts

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

data class ShiftCloseMoneyTotals(
    val cupCashMinor: Long,
    val foreignCashCupMinor: Long,
    val transferCupMinor: Long,
    val countedTotalCupMinor: Long,
    val expectedSalesCupMinor: Long,
    val differenceCupMinor: Long,
    val foreignNativeTotalsMinor: Map<String, Long>
)

object ShiftCloseCalculator {
    private val discreteUnits = setOf("u", "ud", "uds", "unidad", "unidades", "pqt", "paquete", "pieza", "piezas", "botella", "botellas", "caja", "cajas")

    fun quantityToMicros(text: String, unit: String): Long {
        val value = BigDecimal(text.trim().replace(',', '.'))
        require(value.signum() >= 0) { "El conteo no puede ser negativo." }
        if (unit.trim().lowercase(Locale.ROOT) in discreteUnits) {
            require(value.stripTrailingZeros().scale() <= 0) {
                "La unidad $unit solo admite cantidades enteras."
            }
        }
        return value.movePointRight(6).setScale(0, RoundingMode.UNNECESSARY).longValueExact()
    }

    fun ipvQuantityMicros(openingMicros: Long, receivedMicros: Long, finalMicros: Long): Long {
        require(openingMicros >= 0L && receivedMicros >= 0L && finalMicros >= 0L) {
            "El cálculo IPV no admite cantidades negativas."
        }
        return Math.subtractExact(Math.addExact(openingMicros, receivedMicros), finalMicros)
    }

    fun denominationTotalMinor(denominations: Map<String, String>): Long {
        return denominations.entries.fold(0L) { total, entry ->
            val denomination = entry.key.toLongOrNull()
                ?: throw IllegalArgumentException("Hay una denominación de efectivo inválida.")
            val countText = entry.value.trim()
            if (countText.isEmpty()) return@fold total
            val count = countText.toLongOrNull()
                ?: throw IllegalArgumentException("La cantidad de billetes debe ser un número entero.")
            require(denomination > 0L && count >= 0L) {
                "No se admiten denominaciones ni cantidades negativas."
            }
            Math.addExact(total, Math.multiplyExact(Math.multiplyExact(denomination, count), 100L))
        }
    }

    fun convertNativeMinorToCupMinor(nativeMinor: Long, rateMicros: Long): Long {
        require(nativeMinor >= 0L && rateMicros > 0L) {
            "El importe y la tasa de conversión deben ser positivos."
        }
        return BigDecimal.valueOf(nativeMinor)
            .multiply(BigDecimal.valueOf(rateMicros))
            .divide(BigDecimal.valueOf(1_000_000L), 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    fun expectedSalesCupMinor(
        payments: List<ShiftPaymentSummary>,
        exchangeRatesMicros: Map<String, Long>
    ): Long {
        return payments.fold(0L) { total, payment ->
            require(payment.currencyScale == 2) {
                "La moneda ${payment.currency} no usa dos decimales y aún no se puede conciliar en el cierre móvil."
            }
            val currency = payment.currency.uppercase(Locale.ROOT)
            val converted = if (currency == "CUP") {
                payment.amountMinor
            } else {
                val rate = exchangeRatesMicros[currency]
                    ?: throw IllegalStateException("Falta la tasa ${currency}/CUP del último inventario importado.")
                convertNativeMinorToCupMinor(payment.amountMinor, rate)
            }
            Math.addExact(total, converted)
        }
    }

    fun summarizeMoney(
        cupDenominations: Map<String, String>,
        foreignDenominations: Map<String, Map<String, String>>,
        transferCupText: String,
        payments: List<ShiftPaymentSummary>,
        exchangeRatesMicros: Map<String, Long>
    ): ShiftCloseMoneyTotals {
        val cupCash = denominationTotalMinor(cupDenominations)
        val foreignTotals = LinkedHashMap<String, Long>()
        var foreignCup = 0L
        foreignDenominations.forEach { (rawCurrency, denominations) ->
            val currency = rawCurrency.uppercase(Locale.ROOT)
            if (currency == "CUP") return@forEach
            val nativeTotal = denominationTotalMinor(denominations)
            foreignTotals[currency] = nativeTotal
            if (nativeTotal > 0L) {
                val rate = exchangeRatesMicros[currency]
                    ?: throw IllegalStateException("No existe una tasa ${currency}/CUP válida en el inventario importado.")
                foreignCup = Math.addExact(foreignCup, convertNativeMinorToCupMinor(nativeTotal, rate))
            }
        }
        val transfer = if (transferCupText.isBlank()) 0L else {
            val parsed = BigDecimal(transferCupText.trim())
            require(parsed.signum() >= 0) { "La transferencia no puede ser negativa." }
            parsed.movePointRight(2).setScale(0, RoundingMode.UNNECESSARY).longValueExact()
        }
        val expected = expectedSalesCupMinor(payments, exchangeRatesMicros)
        val counted = Math.addExact(Math.addExact(cupCash, foreignCup), transfer)
        return ShiftCloseMoneyTotals(
            cupCashMinor = cupCash,
            foreignCashCupMinor = foreignCup,
            transferCupMinor = transfer,
            countedTotalCupMinor = counted,
            expectedSalesCupMinor = expected,
            differenceCupMinor = Math.subtractExact(counted, expected),
            foreignNativeTotalsMinor = foreignTotals
        )
    }
}
