package com.proventa.app.ui.theme

import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF14233F)
val NavySurface = Color(0xFFFFFFFF)
val NavyElevated = Color(0xFFFFFFFF)
val Gold = Color(0xFF8A6514)
val GoldSoft = Color(0xFFE7C46E)
val TextPrimary = Color(0xFF18263B)
val TextSecondary = Color(0xFF617084)
val AppBackground = Color(0xFFF4F6F9)
val Success = Color(0xFF247A5A)
val Warning = Color(0xFF9A6812)
val Danger = Color(0xFFB54747)
