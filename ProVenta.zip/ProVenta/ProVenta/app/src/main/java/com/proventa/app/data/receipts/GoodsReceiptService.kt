package com.proventa.app.data.receipts

import android.content.Context
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.GoodsReceiptEntity
import com.proventa.app.data.entities.OutboxPackageEntity
import com.proventa.app.security.CurrentProVentaScopeProvider
import com.proventa.app.security.DeviceOperationPackageFactory
import com.proventa.app.security.SignedDeviceOperationPackage
import org.json.JSONObject
import java.security.MessageDigest
import java.time.Instant
import java.util.UUID

data class ImportedGoodsReceipt(
    val receiptId: String,
    val dispatchId: String,
    val posId: String,
    val productCount: Int,
    val duplicate: Boolean
)

/**
 * Offline goods-receipt flow:
 * 1) verify a ProControl-signed dispatch manifest (from the QR frames or USB),
 * 2) let the worker review the immutable product list,
 * 3) require the separate eight-digit code printed by ProControl,
 * 4) create a signed goods_receipt package tied to the active POS/shift permit,
 * 5) wait for the authenticated .pcack before confirming the receipt locally.
 *
 * This flow records receipt evidence only. The desktop dispatch already updated
 * its inventory, so importing the evidence must never decrement stock again.
 */
class GoodsReceiptService(context: Context) {
    private val appContext = context.applicationContext
    private val dao = ProVentaDatabaseFactory.get(appContext).proVentaDao()
    private val verifier = GoodsDispatchManifestVerifier(appContext)
    private val packageFactory = DeviceOperationPackageFactory(appContext)
    private val scopeProvider = CurrentProVentaScopeProvider(appContext)

    suspend fun importManifest(
        rawJson: String,
        qrToken: String? = null,
        nowMillis: Long = System.currentTimeMillis()
    ): ImportedGoodsReceipt {
        val scope = scopeProvider.requireCurrent(nowMillis)
        val manifest = verifier.verify(rawJson, expectedPosId = scope.posId, nowMillis = nowMillis)
        scope.requirePos(manifest.posId)
        if (qrToken != null) {
            val expectedToken = manifest.dispatchId
                .filter { it.isLetterOrDigit() }
                .take(8)
                .padEnd(8, '0')
            require(qrToken == expectedToken) {
                "Los fragmentos QR no corresponden al identificador de este despacho."
            }
        }
        val snapshot = dao.getInventorySnapshotForScope(
            posId = scope.posId,
            installationId = scope.installationId,
            deviceId = scope.deviceId
        )
        require(snapshot != null) {
            "Primero importa el inventario autorizado del punto " + manifest.posName + " en este teléfono e instalación."
        }
        val receiptId = "receipt_" + manifest.dispatchId
        val receipt = GoodsReceiptEntity(
            receiptId = receiptId,
            transferId = manifest.dispatchId,
            posId = manifest.posId,
            status = ReceiptStatus.PENDING_REVIEW.name,
            confirmationCodeHash = manifest.confirmationCodeHash,
            packageHash = manifest.itemsHash,
            manifestJson = manifest.rawJson,
            finalAuthorizationHash = null,
            discrepancyReason = null,
            confirmedAt = null,
            createdAt = nowMillis,
            updatedAt = nowMillis
        )
        val inserted = dao.storeGoodsReceiptManifest(receipt)
        val stored = dao.getReceiptByTransferId(manifest.dispatchId)
            ?: throw IllegalStateException("No se pudo conservar el manifiesto de recepción.")
        val items = JSONObject(stored.manifestJson).getJSONArray("items")
        return ImportedGoodsReceipt(
            receiptId = stored.receiptId,
            dispatchId = stored.transferId,
            posId = stored.posId,
            productCount = items.length(),
            duplicate = !inserted
        )
    }

    suspend fun markReviewed(receiptId: String, nowMillis: Long = System.currentTimeMillis()): Boolean {
        val receipt = dao.getGoodsReceipt(receiptId)
            ?: throw IllegalArgumentException("No se encontró la recepción seleccionada.")
        requireReceiptScope(receipt, nowMillis)
        if (receipt.status == ReceiptStatus.PENDING_OWNER_CONFIRMATION.name) return false
        require(receipt.status == ReceiptStatus.PENDING_REVIEW.name) {
            "La recepción ya avanzó a otro estado y no se puede revisar de nuevo."
        }
        val updated = dao.transitionReceipt(
            receiptId = receiptId,
            expectedStatus = ReceiptStatus.PENDING_REVIEW.name,
            newStatus = ReceiptStatus.PENDING_OWNER_CONFIRMATION.name,
            updatedAt = nowMillis
        )
        require(updated == 1) { "La recepción cambió de estado durante la revisión." }
        return true
    }

    suspend fun createConfirmationPackage(
        receiptId: String,
        confirmationCode: String,
        nowMillis: Long = System.currentTimeMillis()
    ): SignedDeviceOperationPackage {
        val receipt = dao.getGoodsReceipt(receiptId)
            ?: throw IllegalArgumentException("No se encontró la recepción seleccionada.")
        val scope = requireReceiptScope(receipt, nowMillis)
        val existing = dao.getOutboxPackageForAggregate(receipt.transferId, "goods_receipt")
        if (existing != null) {
            require(existing.deviceId == scope.deviceId) {
                "El paquete de recepción pertenece a otro teléfono autorizado."
            }
            require(receipt.status == ReceiptStatus.AWAITING_FINAL_ACK.name) {
                "El despacho ya tiene otro paquete de recepción."
            }
            return existing.toSignedPackage()
        }
        require(receipt.status == ReceiptStatus.PENDING_OWNER_CONFIRMATION.name) {
            "Primero revisa los productos y cantidades de esta recepción."
        }

        val manifest = verifier.verify(
            receipt.manifestJson,
            expectedPosId = receipt.posId,
            nowMillis = nowMillis
        )
        val code = confirmationCode.trim()
        require(code.matches(Regex("[0-9]{8}"))) {
            "Introduce el código de confirmación de ocho dígitos impreso por ProControl."
        }
        require(
            MessageDigest.isEqual(
                sha256(code).toByteArray(Charsets.US_ASCII),
                manifest.confirmationCodeHash.toByteArray(Charsets.US_ASCII)
            )
        ) { "El código no coincide con el despacho. No se enviaron datos." }

        val permit = dao.getConfirmedShiftPermit(
            posId = scope.posId,
            installationId = scope.installationId,
            authorizationId = scope.authorizationId,
            deviceId = scope.deviceId,
            now = nowMillis
        ) ?: throw IllegalStateException(
            "No hay un turno abierto y confirmado por ProControl para la autorización actual de este teléfono."
        )
        scope.requirePermitScope(permit.installationId, permit.authorizationId, permit.posId, permit.deviceId)
        require(nowMillis >= manifest.createdAt && nowMillis <= manifest.expiresAt) {
            "El despacho aún no está vigente o ya caducó."
        }

        val payload = JSONObject()
            .put("schemaVersion", 1)
            .put("dispatchId", manifest.dispatchId)
            .put("posId", manifest.posId)
            .put("shiftPermitId", permit.permitId)
            .put("confirmationCode", code)
            .put("itemsHash", manifest.itemsHash)
            .put("items", JSONObject(manifest.rawJson).getJSONArray("items"))
            .put("receivedAt", Instant.ofEpochMilli(nowMillis).toString())

        val signed = packageFactory.create(
            type = "goods_receipt",
            payload = payload,
            createdAt = nowMillis
        )
        val entity = OutboxPackageEntity(
            packageId = signed.packageId,
            deviceId = signed.deviceId,
            packageType = signed.type,
            payloadHash = signed.payloadHash,
            envelopeJson = signed.envelopeJson,
            aggregateId = receipt.transferId,
            status = "PENDING",
            createdAt = signed.createdAt,
            acknowledgementJson = null,
            acknowledgedAt = null
        )
        dao.storeGoodsReceiptPackage(receipt.transferId, entity, nowMillis)
        return signed
    }

    private suspend fun requireReceiptScope(
        receipt: GoodsReceiptEntity,
        nowMillis: Long
    ): com.proventa.app.security.CurrentProVentaScope {
        val scope = scopeProvider.requireCurrent(nowMillis)
        scope.requirePos(receipt.posId)
        val manifest = JSONObject(receipt.manifestJson)
        require(
            manifest.optString("installationId") == scope.installationId &&
                manifest.optString("posId") == scope.posId &&
                manifest.optString("dispatchId") == receipt.transferId &&
                manifest.optString("itemsHash").matches(Regex("[a-f0-9]{64}")) &&
                receipt.receiptId == "receipt_${receipt.transferId}"
        ) {
            "La recepción pertenece a otro despacho, instalación o punto de venta."
        }
        require(dao.getInventorySnapshotForScope(scope.posId, scope.installationId, scope.deviceId) != null) {
            "La recepción ya no corresponde al inventario autorizado y vigente de este teléfono."
        }
        return scope
    }

    private fun OutboxPackageEntity.toSignedPackage() = SignedDeviceOperationPackage(
        packageId = packageId,
        deviceId = deviceId,
        type = packageType,
        payloadHash = payloadHash,
        createdAt = createdAt,
        envelopeJson = envelopeJson
    )

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
