package com.proventa.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.dao.ProVentaDao
import com.proventa.app.data.entities.InventorySnapshotEntity
import com.proventa.app.data.entities.ProductEntity
import com.proventa.app.data.inventory.InventorySnapshotImporter
import com.proventa.app.security.CurrentProVentaScopeProvider
import com.proventa.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.math.BigDecimal
import org.json.JSONArray

@Composable
fun InventoryScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scopeProvider = remember(context) { CurrentProVentaScopeProvider(context.applicationContext) }
    var dao by remember { mutableStateOf<ProVentaDao?>(null) }
    var importer by remember { mutableStateOf<InventorySnapshotImporter?>(null) }
    var snapshots by remember { mutableStateOf<List<InventorySnapshotEntity>>(emptyList()) }
    var selectedPosId by remember { mutableStateOf("") }
    var searchText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Importa el archivo .pcinv que preparó ProControl.") }

    suspend fun refreshSnapshots() {
        val currentDao = dao ?: return
        val active = withContext(Dispatchers.IO) { runCatching { scopeProvider.requireCurrent() }.getOrNull() }
        snapshots = if (active == null) {
            emptyList()
        } else {
            withContext(Dispatchers.IO) {
                currentDao.listInventorySnapshots().filter {
                    it.posId == active.posId &&
                        it.installationId == active.installationId &&
                        it.deviceId == active.deviceId
                }
            }
        }
        selectedPosId = snapshots.firstOrNull()?.posId.orEmpty()
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                message = "Verificando firma, descifrando y aplicando inventario…"
                try {
                    val envelope = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { readLimited(it, MAX_PACKAGE_BYTES) }
                            ?: throw IllegalStateException("No se pudo abrir el archivo.")
                    }
                    val result = withContext(Dispatchers.IO) {
                        (importer ?: throw IllegalStateException("La base local todavía se está preparando.")).importPackage(envelope)
                    }
                    refreshSnapshots()
                    require(result.posId == selectedPosId || snapshots.any { it.posId == result.posId }) {
                        "El paquete importado no corresponde al punto de venta autorizado en esta pantalla."
                    }
                    message = if (result.applied) {
                        "Inventario de " + result.posId + " aplicado: " + result.productCount + " productos."
                    } else {
                        "Este paquete ya estaba aplicado. No se duplicó el inventario."
                    }
                } catch (error: Exception) {
                    message = error.message ?: "No se pudo importar el inventario."
                } finally {
                    busy = false
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        busy = true
        try {
            val prepared = withContext(Dispatchers.IO) {
                val database = ProVentaDatabaseFactory.get(context.applicationContext)
                Pair(database.proVentaDao(), InventorySnapshotImporter(context.applicationContext))
            }
            dao = prepared.first
            importer = prepared.second
            refreshSnapshots()
        } catch (error: Exception) {
            message = error.message ?: "No se pudo preparar el inventario local."
        } finally {
            busy = false
        }
    }
    val productFlow = remember(selectedPosId, dao) {
        val currentDao = dao
        if (selectedPosId.isBlank() || currentDao == null) {
            flowOf<List<ProductEntity>>(emptyList())
        } else {
            currentDao.observeProducts(selectedPosId)
        }
    }
    val products by productFlow.collectAsState(initial = emptyList())
    val filteredProducts = remember(products, searchText) {
        val query = searchText.trim().lowercase()
        if (query.isEmpty()) products
        else products.filter { product ->
            product.name.lowercase().contains(query) ||
                product.productId.lowercase().contains(query) ||
                product.family.lowercase().contains(query) ||
                aliasesContain(product.catalogAliasesJson, query)
        }
    }
    val selectedSnapshot = snapshots.firstOrNull { it.posId == selectedPosId }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Inventario", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Consulta de solo lectura. Los precios y existencias oficiales llegan desde ProControl.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        item {
            Button(
                onClick = { importLauncher.launch(arrayOf("*/*")) },
                enabled = !busy && importer != null,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
            ) {
                Text("Importar inventario .pcinv")
            }
        }
        item {
            Text(message, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        if (snapshots.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Todavía no hay inventario", fontWeight = FontWeight.Bold)
                        Text(
                            "Primero vincula el teléfono con ProControl. Después importa el paquete cifrado del punto de venta mediante USB.",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        } else {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Punto de venta", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Text(
                        selectedSnapshot?.posName?.ifBlank { selectedPosId } ?: selectedPosId,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    selectedSnapshot?.usdCupRateMicros?.let { rate ->
                        Text("Tasa USD/CUP: " + formatQuantity(rate), color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(
                        (selectedSnapshot?.productCount ?: products.size).toString() +
                            " productos · actualizado " +
                            (selectedSnapshot?.let { formatDate(it.importedAt) } ?: "—"),
                        color = TextSecondary,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            item {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Buscar producto") },
                    placeholder = { Text("Nombre o familia") }
                )
            }
            if (filteredProducts.isEmpty()) {
                item {
                    Text(
                        if (products.isEmpty()) "Este punto de venta no tiene productos en el snapshot."
                        else "No hay productos que coincidan con la búsqueda.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                items(filteredProducts, key = { it.productId }) { product ->
                    InventoryProductCard(product)
                }
            }
        }
    }
}

@Composable
private fun InventoryProductCard(product: ProductEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(product.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(
                listOf(product.family, product.unit).filter { it.isNotBlank() }.joinToString(" · "),
                color = TextSecondary,
                style = MaterialTheme.typography.labelSmall
            )
            Text(
                "Existencia: " + formatQuantity(product.availableQuantityMicros) + " " + product.unit,
                style = MaterialTheme.typography.bodyMedium
            )
            product.cupCashPriceMinor?.let {
                Text("Efectivo CUP: " + formatMinor(it, 2), style = MaterialTheme.typography.bodySmall)
            }
            product.cupTransferPriceMinor?.let {
                val suffix = if (product.transferMode == "percentage" && product.transferPercentBasisPoints != null) {
                    " (" + BigDecimal.valueOf(product.transferPercentBasisPoints.toLong(), 2)
                        .stripTrailingZeros().toPlainString() + "%)"
                } else ""
                Text("Transferencia CUP: " + formatMinor(it, 2) + suffix, style = MaterialTheme.typography.bodySmall)
            }
            if (product.foreignPriceMinor != null && product.foreignCurrency != null) {
                val currencyLabel = if (product.foreignCurrency == "OTRA") {
                    product.customCurrencyLabel ?: "OTRA"
                } else product.foreignCurrency
                Text(
                    "Precio " + currencyLabel + ": " +
                        formatMinor(product.foreignPriceMinor, product.foreignCurrencyScale ?: 2),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private fun aliasesContain(aliasesJson: String, query: String): Boolean {
    return try {
        val aliases = JSONArray(aliasesJson)
        (0 until aliases.length()).any { aliases.optString(it).lowercase().contains(query) }
    } catch (_: Exception) {
        false
    }
}

private fun formatMinor(amountMinor: Long, scale: Int): String =
    BigDecimal.valueOf(amountMinor, scale).setScale(scale).toPlainString()

private fun formatQuantity(quantityMicros: Long): String =
    BigDecimal.valueOf(quantityMicros, 6).stripTrailingZeros().toPlainString()

private fun formatDate(timestamp: Long): String =
    java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT)
        .format(java.util.Date(timestamp))

private fun readLimited(input: java.io.InputStream, maximumBytes: Int): String {
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    var total = 0
    while (true) {
        val count = input.read(buffer)
        if (count < 0) break
        total += count
        require(total <= maximumBytes) { "El paquete supera el tamaño máximo permitido." }
        output.write(buffer, 0, count)
    }
    return output.toString(Charsets.UTF_8.name())
}

private const val MAX_PACKAGE_BYTES = 17 * 1024 * 1024
