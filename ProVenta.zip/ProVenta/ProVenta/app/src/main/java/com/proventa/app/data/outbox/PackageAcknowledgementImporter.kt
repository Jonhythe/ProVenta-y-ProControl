package com.proventa.app.data.outbox

import android.content.Context
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.security.CurrentProVentaScopeProvider
import com.proventa.app.security.DevicePackageAcknowledgementVerifier
import org.json.JSONObject

data class PackageAcknowledgementImportResult(
    val applied: Boolean,
    val packageId: String,
    val result: String,
    val packageType: String
)

class PackageAcknowledgementImporter(context: Context) {
    private val appContext = context.applicationContext
    private val dao = ProVentaDatabaseFactory.get(appContext).proVentaDao()
    private val verifier = DevicePackageAcknowledgementVerifier(appContext)
    private val scopeProvider = CurrentProVentaScopeProvider(appContext)

    suspend fun importAcknowledgement(rawJson: String): PackageAcknowledgementImportResult {
        require(rawJson.toByteArray(Charsets.UTF_8).size <= 64 * 1024) {
            "El acuse supera el tamaño permitido."
        }
        val document = JSONObject(rawJson)
        val packageId = document.optString("packageId")
        val packageEntity = dao.getOutboxPackage(packageId)
            ?: throw IllegalArgumentException("No existe un paquete local con ese identificador.")
        requirePackageScope(packageEntity)
        val verified = verifier.verify(
            rawJson = rawJson,
            expectedPackageId = packageEntity.packageId,
            expectedType = packageEntity.packageType,
            expectedPayloadHash = packageEntity.payloadHash
        )
        val applied = dao.applyPackageAcknowledgement(verified)
        return PackageAcknowledgementImportResult(
            applied = applied,
            packageId = verified.packageId,
            result = verified.result,
            packageType = verified.packageType
        )
    }

    private suspend fun requirePackageScope(packageEntity: com.proventa.app.data.entities.OutboxPackageEntity) {
        val scope = scopeProvider.requireCurrent()
        require(packageEntity.deviceId == scope.deviceId) {
            "El paquete pendiente pertenece a otro teléfono autorizado."
        }
        when (packageEntity.packageType) {
            "sale_batch" -> {
                val saleId = packageEntity.aggregateId?.takeIf { it.isNotBlank() }
                    ?: throw IllegalArgumentException("El paquete de ventas no está asociado a una venta local.")
                val sale = dao.getSale(saleId)
                    ?: throw IllegalArgumentException("No existe la venta local asociada al paquete.")
                scope.requirePos(sale.posId)
                val payload = JSONObject(packageEntity.envelopeJson).optJSONObject("payload")
                    ?: throw IllegalArgumentException("El paquete de ventas no contiene su contenido firmado.")
                val transactions = payload.optJSONArray("transactions")
                    ?: throw IllegalArgumentException("El paquete de ventas no contiene transacciones.")
                require(transactions.length() > 0) { "El paquete de ventas está vacío." }
                for (index in 0 until transactions.length()) {
                    val transaction = transactions.optJSONObject(index)
                        ?: throw IllegalArgumentException("El paquete contiene una transacción inválida.")
                    scope.requirePos(transaction.optString("posId"))
                    require(transaction.optString("mobileOrderId") == saleId) {
                        "El paquete contiene una transacción que no pertenece a la venta local seleccionada."
                    }
                }
            }
            "goods_receipt" -> {
                val transferId = packageEntity.aggregateId?.takeIf { it.isNotBlank() }
                    ?: throw IllegalArgumentException("El paquete de recepción no identifica el despacho.")
                val receipt = dao.getReceiptByTransferId(transferId)
                    ?: throw IllegalArgumentException("No existe la recepción local asociada al paquete.")
                scope.requirePos(receipt.posId)
                val manifest = JSONObject(receipt.manifestJson)
                val payload = JSONObject(packageEntity.envelopeJson).optJSONObject("payload")
                    ?: throw IllegalArgumentException("El paquete de recepción no contiene su contenido firmado.")
                require(
                    manifest.optString("installationId") == scope.installationId &&
                        manifest.optString("posId") == scope.posId &&
                        payload.optString("dispatchId") == transferId &&
                        payload.optString("posId") == scope.posId &&
                        payload.optString("itemsHash") == manifest.optString("itemsHash")
                ) {
                    "El paquete de recepción no coincide con el despacho, instalación o punto de venta autorizado."
                }
            }
            "shift_open", "shift_close" -> {
                val permitId = packageEntity.aggregateId?.takeIf { it.isNotBlank() }
                    ?: throw IllegalArgumentException("El paquete de turno no identifica su permiso.")
                val permit = dao.getShiftPermit(permitId)
                    ?: throw IllegalArgumentException("No existe el permiso local asociado al paquete.")
                scope.requirePermitScope(
                    permit.installationId,
                    permit.authorizationId,
                    permit.posId,
                    permit.deviceId
                )
                val payload = JSONObject(packageEntity.envelopeJson).optJSONObject("payload")
                    ?: throw IllegalArgumentException("El paquete de turno no contiene su contenido firmado.")
                val shift = payload.optJSONObject("shift")
                    ?: throw IllegalArgumentException("El paquete de turno no identifica el turno.")
                require(
                    shift.optString("posId") == scope.posId &&
                        shift.optString("permitId") == permit.permitId &&
                        (permit.shiftId.isNullOrBlank() || shift.optString("id") == permit.shiftId)
                ) { "El paquete de turno no corresponde al permiso y POS autorizados." }
                if (packageEntity.packageType == "shift_close") {
                    val report = payload.optJSONObject("closingReport")
                        ?: throw IllegalArgumentException("El cierre no contiene el informe de conciliación.")
                    scope.requirePos(report.optString("posId"))
                }
            }
            "return", "heartbeat" -> {
                val payload = JSONObject(packageEntity.envelopeJson).optJSONObject("payload")
                    ?: throw IllegalArgumentException("El paquete no contiene su contenido firmado.")
                val payloadPosId = payload.optString("posId")
                if (payloadPosId.isNotBlank()) scope.requirePos(payloadPosId)
            }
            else -> throw IllegalArgumentException("Tipo de paquete no reconocido.")
        }
    }
}
