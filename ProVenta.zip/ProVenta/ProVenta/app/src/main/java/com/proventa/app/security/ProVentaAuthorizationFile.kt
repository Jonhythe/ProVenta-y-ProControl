package com.proventa.app.security

import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets

object ProVentaAuthorizationFile {
    private const val MAX_FILE_BYTES = 64 * 1024
    private val allowedName = Regex("""ProVenta Codigo(?: \(\d+\))?\.pvla2""", RegexOption.IGNORE_CASE)

    fun decode(fileName: String, bytes: ByteArray): String {
        require(allowedName.matches(fileName.trim())) {
            "Selecciona el archivo ProVenta Codigo.pvla2 exportado desde ProControl."
        }
        require(bytes.isNotEmpty() && bytes.size <= MAX_FILE_BYTES) {
            "El archivo ProVenta Codigo.pvla2 está vacío o supera el tamaño permitido."
        }
        val text = StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes))
            .toString()
            .trim()
        require(text.startsWith("PVLA2:") && text.length in 46..4006) {
            "El archivo no contiene una autorización PVLA2 válida de ProControl."
        }
        return text
    }
}
