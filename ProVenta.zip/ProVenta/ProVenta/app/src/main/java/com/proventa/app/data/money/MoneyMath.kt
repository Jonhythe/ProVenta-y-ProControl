package com.proventa.app.data.money

import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode

/**
 * Currency-safe calculations using integer minor units and quantity micros.
 * Rounds half up once at the final line amount, never through Double.
 */
object MoneyMath {
    const val QUANTITY_SCALE = 1_000_000L

    fun lineTotalMinor(unitPriceMinor: Long, quantityMicros: Long): Long {
        require(unitPriceMinor >= 0) { "El precio no puede ser negativo." }
        require(quantityMicros >= 0) { "La cantidad no puede ser negativa." }

        val numerator = BigInteger.valueOf(unitPriceMinor)
            .multiply(BigInteger.valueOf(quantityMicros))
        val denominator = BigInteger.valueOf(QUANTITY_SCALE)
        val division = numerator.divideAndRemainder(denominator)
        val rounded = if (division[1].multiply(BigInteger.valueOf(2L)) >= denominator) {
            division[0].add(BigInteger.ONE)
        } else {
            division[0]
        }
        val result = rounded.toLong()
        if (BigInteger.valueOf(result) != rounded) {
            throw ArithmeticException("El importe excede el rango admitido.")
        }
        return result
    }

    fun decimalToMinorUnits(value: Number, currencyScale: Int = 2): Long {
        require(currencyScale in 0..6) { "Escala monetaria no admitida." }
        val decimal = BigDecimal(value.toString())
        require(decimal.signum() >= 0) { "El precio no puede ser negativo." }
        return decimal
            .movePointRight(currencyScale)
            .setScale(0, RoundingMode.UNNECESSARY)
            .longValueExact()
    }

    fun decimalToMicros(value: Number): Long {
        val decimal = BigDecimal(value.toString())
        require(decimal.signum() >= 0) { "La cantidad no puede ser negativa." }
        return decimal
            .movePointRight(6)
            .setScale(0, RoundingMode.UNNECESSARY)
            .longValueExact()
    }

    fun percentToBasisPoints(value: Number): Int {
        val decimal = BigDecimal(value.toString())
        require(decimal.signum() >= 0) { "El porcentaje no puede ser negativo." }
        return decimal
            .movePointRight(2)
            .setScale(0, RoundingMode.UNNECESSARY)
            .intValueExact()
    }

    fun sumMinorAmounts(amounts: Iterable<Long>): Long =
        amounts.fold(0L) { total, amount ->
            require(amount >= 0) { "No se pueden sumar importes negativos." }
            Math.addExact(total, amount)
        }
}
