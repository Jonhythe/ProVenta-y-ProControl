package com.proventa.app.security

import android.content.Context
import android.util.Base64
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

class VerifiedPackageAcknowledgement internal constructor(
    val packageId: String,
    val deviceId: String,
    val packageType: String,
    val payloadHash: String,
    val status: String,
    val result: String,
    val receivedAt: Long,
    val appliedAt: Long?,
    val acknowledgedAt: Long,
    val rawJson: String
)

class DevicePackageAcknowledgementVerifier(context: Context) {
    private val enrollment = DeviceEnrollmentRequestFactory(context.applicationContext)
    private val keyManager = DeviceKeyManager(context.applicationContext)
    private val provider = BouncyCastleProvider()

    fun verify(
        rawJson: String,
        expectedPackageId: String,
        expectedType: String,
        expectedPayloadHash: String
    ): VerifiedPackageAcknowledgement {
        require(rawJson.toByteArray(StandardCharsets.UTF_8).size <= MAX_ACK_BYTES) {
            "El acuse de ProControl supera el tamaño permitido."
        }
        val authorization = enrollment.trustedInstallationAuthorization()
            ?: throw IllegalStateException("No hay una instalación ProControl vinculada.")
        val deviceId = keyManager.getOrCreate().deviceId
        val ack = JSONObject(rawJson)
        require(ack.optString("format") == "procontrol.package-ack" && ack.optInt("version") == 1) {
            "Formato de acuse no compatible."
        }
        val packageId = ack.optString("packageId")
        val ackDeviceId = ack.optString("deviceId")
        val packageType = ack.optString("packageType")
        val payloadHash = ack.optString("payloadHash")
        val status = ack.optString("status")
        val result = ack.optString("result")
        val desktopId = ack.optString("desktopId")
        val desktopPem = ack.optString("desktopPublicKey")
        require(packageId == expectedPackageId && packageId.matches(Regex("[A-Za-z0-9_-]{8,100}"))) {
            "El acuse corresponde a otro paquete."
        }
        require(ackDeviceId == deviceId) { "El acuse corresponde a otro teléfono." }
        require(packageType == expectedType && payloadHash == expectedPayloadHash) {
            "El contenido del acuse no coincide con el paquete enviado."
        }
        require(payloadHash.matches(Regex("[a-f0-9]{64}"))) { "Hash del acuse inválido." }
        require(status in TERMINAL_STATUSES) { "ProControl todavía no ha emitido un resultado final." }
        val expectedResult = if (status == "reconciled") "applied" else status
        require(result == expectedResult) { "Resultado del acuse incoherente." }
        if (authorization.version < 4) {
            require(desktopId == authorization.desktopId) { "El acuse procede de otro PC." }
        } else {
            // ProControl v4's desktopId is not the installation identity. The
            // issuer is pinned by installationId -> Ed25519 public key in the
            // signed authorization; package-ack is verified against that key.
            require(desktopId.isNotBlank() && desktopId.length <= 120) {
                "El acuse no identifica correctamente la instancia emisora."
            }
        }

        val pinnedKey = parseEd25519PublicKey(authorization.desktopPublicKeyPem)
        val suppliedKey = parseEd25519PublicKey(desktopPem)
        require(MessageDigest.isEqual(pinnedKey.encoded, suppliedKey.encoded)) {
            "La clave firmante del acuse no coincide con la instalación vinculada."
        }
        val signatureObject = ack.optJSONObject("signature")
            ?: throw IllegalArgumentException("El acuse no contiene firma digital.")
        require(signatureObject.optString("algorithm") == "Ed25519") {
            "Algoritmo de firma del acuse no compatible."
        }
        val signatureBytes = Base64.decode(signatureObject.getString("value"), Base64.DEFAULT)
        val signatureVerifier = Signature.getInstance("Ed25519", provider)
        signatureVerifier.initVerify(pinnedKey)
        signatureVerifier.update(
            CanonicalJson.stringify(CanonicalJson.withoutSignature(ack))
                .toByteArray(StandardCharsets.UTF_8)
        )
        require(signatureVerifier.verify(signatureBytes)) { "La firma del acuse no es válida." }

        val receivedAt = exactLong(ack.opt("receivedAt"), "receivedAt")
        val acknowledgedAt = exactLong(ack.opt("acknowledgedAt"), "acknowledgedAt")
        val appliedValue = ack.opt("appliedAt")
        val appliedAt = if (appliedValue == null || appliedValue === JSONObject.NULL) null
            else exactLong(appliedValue, "appliedAt")
        require(receivedAt > 0L && acknowledgedAt >= receivedAt) {
            "El acuse contiene una secuencia temporal inválida."
        }
        require(appliedAt == null || appliedAt in receivedAt..acknowledgedAt) {
            "La fecha de aplicación del acuse está fuera del intervalo de recepción."
        }
        return VerifiedPackageAcknowledgement(
            packageId = packageId,
            deviceId = ackDeviceId,
            packageType = packageType,
            payloadHash = payloadHash,
            status = status,
            result = result,
            receivedAt = receivedAt,
            appliedAt = appliedAt,
            acknowledgedAt = acknowledgedAt,
            rawJson = CanonicalJson.stringify(ack)
        )
    }

    private fun parseEd25519PublicKey(pem: String): java.security.PublicKey {
        require(pem.length in 100..8192 && pem.contains("BEGIN PUBLIC KEY")) {
            "Clave pública del PC inválida."
        }
        val base64 = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() }
        return KeyFactory.getInstance("Ed25519", provider)
            .generatePublic(X509EncodedKeySpec(Base64.decode(base64, Base64.DEFAULT)))
    }

    private fun exactLong(value: Any?, field: String): Long {
        require(value is Number) { "El campo " + field + " no es numérico." }
        return try {
            java.math.BigDecimal(value.toString()).longValueExact()
        } catch (_: ArithmeticException) {
            throw IllegalArgumentException("El campo " + field + " debe ser un entero exacto.")
        }
    }

    private companion object {
        const val MAX_ACK_BYTES = 64 * 1024
        val TERMINAL_STATUSES = setOf("reconciled", "rejected", "conflict")
    }
}
