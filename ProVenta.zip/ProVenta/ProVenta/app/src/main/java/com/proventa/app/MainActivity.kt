package com.proventa.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.proventa.app.ui.ProVentaApp
import com.proventa.app.ui.screens.WelcomeScreen
import com.proventa.app.ui.theme.ProVentaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            ProVentaTheme {
                var welcomeComplete by rememberSaveable { mutableStateOf(false) }
                SideEffect {
                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                    controller.isAppearanceLightStatusBars = welcomeComplete
                    controller.isAppearanceLightNavigationBars = welcomeComplete
                }
                Box(Modifier.fillMaxSize()) {
                    ProVentaApp()
                    if (!welcomeComplete) {
                        WelcomeScreen(onContinue = { welcomeComplete = true })
                    }
                }
            }
        }
    }
}
