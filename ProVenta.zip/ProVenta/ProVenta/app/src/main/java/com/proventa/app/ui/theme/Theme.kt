package com.proventa.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val ProVentaColors = lightColorScheme(
    primary = Navy,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    secondary = Gold,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    background = AppBackground,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavyElevated,
    onSurfaceVariant = TextSecondary,
    error = Danger,
    outline = androidx.compose.ui.graphics.Color(0xFFCBD3DE),
    outlineVariant = androidx.compose.ui.graphics.Color(0xFFE1E6ED)
)

@Composable
fun ProVentaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ProVentaColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
