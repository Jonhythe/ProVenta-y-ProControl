package com.proventa.app.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.ProductEntity
import com.proventa.app.data.entities.ShiftPermitEntity
import com.proventa.app.data.outbox.PackageAcknowledgementImporter
import com.proventa.app.data.shifts.ShiftCloseCalculator
import com.proventa.app.data.shifts.ShiftCloseContext
import com.proventa.app.data.shifts.ShiftCloseMoneyTotals
import com.proventa.app.data.shifts.ShiftCloseService
import com.proventa.app.data.shifts.ShiftPaymentSummary
import com.proventa.app.security.SignedDeviceOperationPackage
import com.proventa.app.security.CanonicalJson
import com.proventa.app.security.DeviceKeyManager
import com.proventa.app.security.ShiftCloseRecoveryArchive
import com.proventa.app.ui.theme.Danger
import com.proventa.app.ui.theme.Gold
import com.proventa.app.ui.theme.NavyElevated
import com.proventa.app.ui.theme.Success
import com.proventa.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.util.Locale

private val CUP_DENOMINATIONS = listOf(1, 3, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000)
private val USD_DENOMINATIONS = listOf(1, 2, 5, 10, 20, 50, 100)
private val EUR_DENOMINATIONS = listOf(1, 2, 5, 10, 20, 50, 100, 200, 500)
private val OTHER_DENOMINATIONS = listOf(1, 3, 5, 10, 20, 50, 100, 200, 500, 1000)

private data class ShiftCloseDraftUi(
    val counts: Map<String, String> = emptyMap(),
    val cupCash: Map<String, String> = emptyMap(),
    val foreignCash: Map<String, Map<String, String>> = emptyMap(),
    val transferCup: String = "",
    val notes: String = ""
) {
    fun toJson(): String {
        val countObject = JSONObject()
        counts.forEach { (id, value) -> countObject.put(id, value) }
        val cupObject = JSONObject()
        cupCash.forEach { (denomination, count) -> cupObject.put(denomination, count) }
        val foreignObject = JSONObject()
        foreignCash.forEach { (currency, denominations) ->
            val values = JSONObject()
            denominations.forEach { (denomination, count) -> values.put(denomination, count) }
            foreignObject.put(currency, values)
        }
        return JSONObject()
            .put("schemaVersion", 1)
            .put("counts", countObject)
            .put("cupCash", cupObject)
            .put("foreignCash", foreignObject)
            .put("transferCup", transferCup)
            .put("notes", notes.take(500))
            .toString()
    }

    companion object {
        fun fromJson(raw: String?): ShiftCloseDraftUi {
            if (raw.isNullOrBlank()) return ShiftCloseDraftUi()
            return runCatching {
                val json = JSONObject(raw)
                require(json.optInt("schemaVersion") == 1)
                val counts = json.optJSONObject("counts") ?: JSONObject()
                val cup = json.optJSONObject("cupCash") ?: JSONObject()
                val foreign = json.optJSONObject("foreignCash") ?: JSONObject()
                val foreignMap = buildMap {
                    val keys = foreign.keys()
                    while (keys.hasNext()) {
                        val currency = keys.next()
                        val values = foreign.optJSONObject(currency) ?: continue
                        put(currency, jsonStringMap(values))
                    }
                }
                ShiftCloseDraftUi(
                    counts = jsonStringMap(counts),
                    cupCash = jsonStringMap(cup),
                    foreignCash = foreignMap,
                    transferCup = json.optString("transferCup"),
                    notes = json.optString("notes")
                )
            }.getOrDefault(ShiftCloseDraftUi())
        }

        private fun jsonStringMap(json: JSONObject): Map<String, String> = buildMap {
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                put(key, json.optString(key))
            }
        }
    }
}

@Composable
fun ClosingScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val service = remember(context) { ShiftCloseService(context.applicationContext) }
    val dao = remember(context) { ProVentaDatabaseFactory.get(context.applicationContext).proVentaDao() }

    var shiftContext by remember { mutableStateOf<ShiftCloseContext?>(null) }
    var draft by remember { mutableStateOf(ShiftCloseDraftUi()) }
    var step by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var closeCompleted by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Cargando el turno autorizado…") }
    var packageToExport by remember { mutableStateOf<SignedDeviceOperationPackage?>(null) }
    var showExportConfirmation by remember { mutableStateOf(false) }

    suspend fun refreshContext() {
        val loaded = withContext(Dispatchers.IO) { service.loadLatestContext() }
        shiftContext = loaded
        if (loaded != null) draft = ShiftCloseDraftUi.fromJson(loaded.draftJson)
    }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        val packageData = packageToExport
        if (uri == null || packageData == null) {
            message = if (uri == null) {
                "No se exportó el archivo (selector cancelado). El cierre y todos los datos siguen guardados en ProVenta."
            } else {
                "No se encontró el paquete de cierre en memoria. Los datos siguen guardados en ProVenta."
            }
            packageToExport = null
            busy = false
        } else {
            scope.launch {
                try {
                    message = "Guardando el cierre y comprobando el archivo exportado…"
                    var archiveWarning: String? = null
                    val archiveResult = withContext(Dispatchers.IO) {
                        val expectedBytes = packageData.envelopeJson.toByteArray(Charsets.UTF_8)
                        require(expectedBytes.isNotEmpty() && expectedBytes.size <= 2 * 1024 * 1024) {
                            "El paquete de cierre está vacío o supera 2 MiB. No se borró ningún dato."
                        }
                        context.contentResolver.openOutputStream(uri, "w")?.use { output ->
                            output.write(expectedBytes)
                            output.flush()
                        } ?: throw IllegalStateException("El proveedor de archivos no permitió guardar el cierre. No se borró ningún dato.")

                        val readBackBytes = context.contentResolver.openInputStream(uri)?.use { readCloseBytesLimited(it, 2 * 1024 * 1024) }
                            ?: throw IllegalStateException("El archivo se escribió, pero Android no permitió volver a abrirlo para verificarlo. No se borró ningún dato.")
                        try {
                            require(MessageDigest.isEqual(expectedBytes, readBackBytes)) {
                                "El archivo exportado no coincide byte por byte con el cierre firmado que conserva ProVenta. No se borró ningún dato. Vuelve a exportarlo en otra ubicación."
                            }
                            val raw = decodeCloseUtf8Strict(readBackBytes)
                            val activeContext = shiftContext
                                ?: throw IllegalStateException("No se encontró el contexto del POS que se está cerrando. No se borró ningún dato.")
                            val archive = ShiftCloseRecoveryArchive(context.applicationContext)
                            val businessDataCleared = dao.isClosedShiftBusinessDataCleared(
                                activeContext.permit.posId,
                                activeContext.permit.permitId
                            )
                            // Si el teléfono ya completó una purga anterior, intentamos validar
                            // la copia privada. Si esa copia fue eliminada/dañada después, no
                            // volvemos a purgar ni bloqueamos la reexportación del cierre firmado.
                            val archiveAttempt = if (businessDataCleared) runCatching {
                                require(archive.hasArchive(packageData.packageId, activeContext.permit.posId, activeContext.permit.permitId)) {
                                    "No se encontró la copia privada cifrada de recuperación en este teléfono."
                                }
                                archive.verifyExistingAfterClear(
                                    packageId = packageData.packageId,
                                    posId = activeContext.permit.posId,
                                    permitId = activeContext.permit.permitId,
                                    packagePayloadHash = packageData.payloadHash
                                )
                            } else null
                            val preVerifiedArchive = archiveAttempt?.getOrNull()
                            archiveWarning = archiveAttempt?.exceptionOrNull()?.message
                            val expectedProductUnits = preVerifiedArchive?.productUnits
                                ?: if (businessDataCleared) productUnitsFromSignedClose(raw)
                                else activeContext.products.associate { it.productId to it.unit }
                            val verifiedPayloadHash = verifyCloseEnvelope(
                                raw = raw,
                                expected = packageData,
                                permit = activeContext.permit,
                                productUnits = expectedProductUnits,
                                keyManager = DeviceKeyManager(context.applicationContext)
                            )
                            val storedPackage = dao.getOutboxPackage(packageData.packageId)
                                ?: throw IllegalStateException("El paquete exportado no aparece en la base de datos local. No se borró ningún dato.")
                            require(storedPackage.packageType == "shift_close" &&
                                storedPackage.deviceId == packageData.deviceId &&
                                storedPackage.payloadHash == verifiedPayloadHash &&
                                storedPackage.envelopeJson == packageData.envelopeJson &&
                                storedPackage.status == "PENDING" && storedPackage.acknowledgementJson == null) {
                                "El archivo no coincide con el cierre pendiente guardado en este teléfono. No se borró ningún dato."
                            }
                            val verifiedArchive = when {
                                preVerifiedArchive != null -> preVerifiedArchive
                                businessDataCleared -> null // Nunca repetir una purga ya completada.
                                else -> {
                                    val snapshot = dao.buildShiftCloseRecoverySnapshot(
                                        activeContext.permit.posId,
                                        activeContext.permit.permitId
                                    )
                                    val recovered = archive.createOrVerify(
                                        packageId = packageData.packageId,
                                        posId = activeContext.permit.posId,
                                        permitId = activeContext.permit.permitId,
                                        packagePayloadHash = verifiedPayloadHash,
                                        snapshotCanonicalJson = snapshot
                                    )
                                    require(recovered.productUnits == expectedProductUnits) {
                                        "El respaldo no coincide con el catálogo que se incluyó en el cierre. No se borró ningún dato."
                                    }
                                    val purged = dao.purgeClosedShiftDataAfterVerifiedArchive(
                                        activeContext.permit.posId,
                                        activeContext.permit.permitId,
                                        recovered.snapshotSha256
                                    )
                                    require(purged) { "La base de datos no confirmó la limpieza transaccional. No se dio por completada la operación." }
                                    recovered
                                }
                            }
                            if (verifiedArchive != null) {
                                require(verifiedArchive.file.isFile && verifiedArchive.bytes > 0L) {
                                    "La copia de recuperación no está disponible después de la verificación. No se dio por completada la operación."
                                }
                            }
                            verifiedArchive
                        } finally {
                            expectedBytes.fill(0)
                            readBackBytes.fill(0)
                        }
                    }
                    message = if (archiveResult != null) {
                        "Cierre exportado y verificado (archivo, SHA-256 y firma Ed25519). Se creó/verificó una copia privada cifrada de recuperación (${archiveResult.bytes} bytes). Los datos operativos de este POS se limpiaron en una sola transacción; el permiso y el cierre firmado se conservaron para recibir el acuse."
                    } else {
                        "Cierre firmado exportado y verificado. Este POS ya estaba limpio por una exportación anterior; no se repitió ningún borrado. ADVERTENCIA: no se pudo verificar la copia privada local de recuperación (${archiveWarning ?: "motivo no disponible"}). Conserva este archivo y entrégalo a ProControl cuanto antes."
                    }
                    refreshContext()
                } catch (error: Exception) {
                    message = (error.message ?: "No se pudo verificar el archivo exportado.") + " Los datos del POS no se eliminaron, salvo que una operación anterior ya hubiera terminado correctamente."
                } finally {
                    packageToExport = null
                    busy = false
                }
            }
        }
    }

    val acknowledgementLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true
                message = "Verificando el acuse firmado de ProControl…"
                try {
                    val raw = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { readCloseFileLimited(it, 64 * 1024) }
                            ?: throw IllegalStateException("No se pudo abrir el acuse.")
                    }
                    val packageId = JSONObject(raw).optString("packageId")
                    val packageEntity = withContext(Dispatchers.IO) { dao.getOutboxPackage(packageId) }
                    require(packageEntity?.packageType == "shift_close") {
                        "Este acuse no pertenece a un cierre de turno de este teléfono."
                    }
                    val result = withContext(Dispatchers.IO) {
                        PackageAcknowledgementImporter(context.applicationContext).importAcknowledgement(raw)
                    }
                    if (result.result == "applied") {
                        closeCompleted = true
                        message = "ProControl confirmó la solicitud. El turno quedó completado."
                        shiftContext = null
                    } else {
                        refreshContext()
                        message = "ProControl respondió: ${result.result}. El turno vuelve a estar disponible para revisar el cierre."
                        step = 2
                    }
                } catch (error: Exception) {
                    message = error.message ?: "No se pudo verificar el acuse."
                } finally {
                    busy = false
                }
            }
        }
    }

    if (showExportConfirmation && packageToExport != null) {
        AlertDialog(
            onDismissRequest = {
                if (!busy) {
                    showExportConfirmation = false
                    packageToExport = null
                    message = "Operación retrocedida. El turno y todos sus datos permanecen en ProVenta."
                }
            },
            title = { Text("Confirmar exportación y limpieza del POS") },
            text = {
                Text(
                    "Al continuar, ProVenta guardará el archivo de cierre y comprobará su contenido, su firma y su lectura posterior. Solo después de verificar también una copia privada cifrada de recuperación, eliminará de este teléfono los datos operativos de ESTE POS: productos y existencias locales, ventas, líneas, pagos, entradas recibidas, borradores y paquetes operativos relacionados. " +
                        "El permiso y el cierre firmado se conservarán para poder recibir el acuse de ProControl. Si falla cualquier comprobación o el almacenamiento no puede confirmar el archivo, no se borrarán los datos.\n\n¿Deseas continuar?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExportConfirmation = false
                        busy = true
                        message = "Selecciona dónde guardar el archivo de cierre. Todavía no se ha eliminado ningún dato."
                        exportLauncher.launch("ProVenta-Cierre.pcoutbox")
                    },
                    enabled = !busy
                ) { Text("Continuar") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showExportConfirmation = false
                        packageToExport = null
                        message = "Operación retrocedida. El turno y todos sus datos permanecen en ProVenta."
                    },
                    enabled = !busy
                ) { Text("Retroceder") }
            }
        )
    }

    LaunchedEffect(Unit) {
        try {
            refreshContext()
            if (shiftContext == null) message = "No hay un turno abierto y confirmado en este teléfono."
        } catch (error: Exception) {
            message = error.message ?: "No se pudo cargar el cierre."
        } finally {
            loading = false
        }
    }

    LaunchedEffect(shiftContext?.permit?.permitId, draft) {
        val current = shiftContext
        if (current?.permit?.status == "OPENED") {
            delay(450)
            runCatching {
                withContext(Dispatchers.IO) { service.saveDraft(current, draft.toJson()) }
            }.onFailure {
                message = it.message ?: "No se pudo guardar el borrador del cierre."
            }
        }
    }

    val current = shiftContext
    if (loading) {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Cierre", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(message, color = TextSecondary)
        }
        return
    }
    if (closeCompleted) {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Turno completado", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("El dueño confirmó el cierre en ProControl. No se puede volver a enviar este turno.", color = Success)
            Text(message, color = TextSecondary)
        }
        return
    }
    if (current == null) {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Cierre de turno", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(message, color = TextSecondary)
            Text("Importa y confirma el permiso de turno desde Inicio para habilitar el cierre.", color = TextSecondary)
        }
        return
    }

    val permit = current.permit
    val pending = permit.status == "CLOSE_PENDING"
    val currencyCodes = (listOf("USD", "EUR", "MLC") + current.exchangeRatesMicros.keys)
        .filter { it != "CUP" }.distinct().sortedWith(compareBy({ listOf("USD", "EUR", "MLC").indexOf(it).let { index -> if (index < 0) 3 else index } }, { it }))
    val cupTotal = runCatching { ShiftCloseCalculator.denominationTotalMinor(draft.cupCash) }.getOrDefault(0L)
    val foreignTotals = currencyCodes.associateWith { currency ->
        runCatching { ShiftCloseCalculator.denominationTotalMinor(draft.foreignCash[currency].orEmpty()) }.getOrDefault(0L)
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Cierre de turno", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("${permit.employee} · ${permit.posId}", color = Gold, style = MaterialTheme.typography.bodyMedium)
            Text("Secuencia ${permit.sequence} · ${permit.shiftId}", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
        }
        if (current.openingInventoryAvailable.not()) {
            InfoCard("Apertura sin inventario inicial", "Este turno fue abierto antes de guardar el stock inicial. Se podrá informar el conteo actual, pero el IPV desde la apertura no estará disponible.")
        }
        if (pending) {
            InfoCard("Cierre enviado", "ProControl debe revisar el paquete. El conteo y el efectivo quedan bloqueados hasta importar el acuse firmado.")
            val savedPackage = current.pendingPackage
            if (savedPackage != null && savedPackage.acknowledgementJson == null) {
                Button(
                    onClick = {
                        packageToExport = savedPackage.toSignedClosePackage()
                        showExportConfirmation = true
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
                ) { Text("Volver a exportar cierre") }
            }
            Button(
                onClick = { acknowledgementLauncher.launch(arrayOf("*/*")) },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
            ) { Text("Importar acuse .pcack") }
            Text(message, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            return@Column
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            StepButton("1 · Productos", step == 0, Modifier.weight(1f)) { step = 0 }
            StepButton("2 · Dinero", step == 1, Modifier.weight(1f)) { step = 1 }
            StepButton("3 · Revisar", step == 2, Modifier.weight(1f)) { step = 2 }
        }

        when (step) {
            0 -> ProductCountStep(
                context = current,
                draft = draft,
                onChange = { draft = draft.copy(counts = it) },
                modifier = Modifier.weight(1f),
                onNext = { step = 1 }
            )
            1 -> MoneyCountStep(
                draft = draft,
                currencyCodes = currencyCodes,
                onCupChange = { draft = draft.copy(cupCash = it) },
                onForeignChange = { currency, values ->
                    draft = draft.copy(foreignCash = draft.foreignCash + (currency to values))
                },
                onTransferChange = { draft = draft.copy(transferCup = it) },
                modifier = Modifier.weight(1f),
                onNext = { step = 2 }
            )
            else -> ReviewStep(
                context = current,
                draft = draft,
                cupTotalMinor = cupTotal,
                foreignTotalsMinor = foreignTotals,
                onNotesChange = { draft = draft.copy(notes = it) },
                modifier = Modifier.weight(1f),
                onBack = { step = 1 },
                onSubmit = {
                    scope.launch {
                        busy = true
                        message = "Preparando el informe y firmando el cierre…"
                        try {
                            val report = buildClosingReport(current, draft)
                            val signed = withContext(Dispatchers.IO) {
                                service.createOrGetClosePackage(permit.permitId, report.toString())
                            }
                            withContext(Dispatchers.IO) {
                                dao.getOutboxPackage(signed.packageId)
                                    ?: throw IllegalStateException("No se guardó el paquete firmado del cierre.")
                            }
                            shiftContext = withContext(Dispatchers.IO) { service.loadLatestContext() }
                            packageToExport = signed
                            showExportConfirmation = true
                            message = "El cierre quedó firmado y guardado internamente. Revisa la advertencia antes de exportarlo y limpiar este POS."
                        } catch (error: Exception) {
                            message = error.message ?: "No se pudo preparar el cierre."
                            busy = false
                        }
                    }
                },
                busy = busy
            )
        }
        Text(message, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun StepButton(title: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, modifier = modifier.heightIn(min = 46.dp)) { Text(title, maxLines = 1) }
    } else {
        TextButton(onClick = onClick, modifier = modifier.heightIn(min = 46.dp)) { Text(title, maxLines = 1) }
    }
}

@Composable
private fun ProductCountStep(
    context: ShiftCloseContext,
    draft: ShiftCloseDraftUi,
    onChange: (Map<String, String>) -> Unit,
    modifier: Modifier = Modifier,
    onNext: () -> Unit
) {
    val counted = context.products.count { !draft.counts[it.productId].isNullOrBlank() }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = modifier) {
        item {
            Text("Cuenta el stock físico", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("$counted de ${context.products.size} productos contados. Escribe lo que hay realmente; no lo que debería haber.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        items(context.products, key = { it.productId }) { product ->
            ProductCountCard(
                product = product,
                openingQuantityMicros = context.openingQuantitiesMicros[product.productId],
                receivedQuantityMicros = context.receivedQuantitiesMicros[product.productId] ?: 0L,
                soldQuantityMicros = context.soldQuantitiesMicros[product.productId] ?: 0L,
                draftValue = draft.counts[product.productId].orEmpty(),
                onValueChange = { value -> onChange(draft.counts + (product.productId to value)) }
            )
        }
        item {
            Button(
                onClick = onNext,
                enabled = context.products.isNotEmpty() && counted == context.products.size,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
            ) { Text("Continuar al efectivo") }
        }
    }
}

@Composable
private fun ProductCountCard(
    product: ProductEntity,
    openingQuantityMicros: Long?,
    receivedQuantityMicros: Long,
    soldQuantityMicros: Long,
    draftValue: String,
    onValueChange: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NavyElevated)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(product.name, fontWeight = FontWeight.SemiBold, maxLines = 2)
            Text(
                "Sistema: ${formatQuantity(product.availableQuantityMicros)} ${product.unit} · Vendido: ${formatQuantity(soldQuantityMicros)}",
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
            if (openingQuantityMicros != null) {
                Text(
                    "Al abrir: ${formatQuantity(openingQuantityMicros)} · Entradas: ${formatQuantity(receivedQuantityMicros)} ${product.unit}",
                    color = TextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            OutlinedTextField(
                value = draftValue,
                onValueChange = { onValueChange(it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.replace(',', '.')) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Cantidad física (${product.unit})") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        }
    }
}

@Composable
private fun MoneyCountStep(
    draft: ShiftCloseDraftUi,
    currencyCodes: List<String>,
    onCupChange: (Map<String, String>) -> Unit,
    onForeignChange: (String, Map<String, String>) -> Unit,
    onTransferChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    onNext: () -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = modifier) {
        item {
            Text("Cuenta el dinero", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Anota cuántos billetes tienes de cada valor. Las tasas salen del último inventario importado.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        item {
            Text("Efectivo CUP", color = Gold, fontWeight = FontWeight.Bold)
        }
        items(CUP_DENOMINATIONS) { denomination ->
            DenominationInput(
                label = "${denomination} CUP",
                count = draft.cupCash[denomination.toString()].orEmpty(),
                onCount = { onCupChange(draft.cupCash + (denomination.toString() to it)) }
            )
        }
        currencyCodes.forEach { currency ->
            item { Text("Efectivo $currency", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
            items(denominationsFor(currency)) { denomination ->
                DenominationInput(
                    label = "${denomination} $currency",
                    count = draft.foreignCash[currency]?.get(denomination.toString()).orEmpty(),
                    onCount = {
                        val values = draft.foreignCash[currency].orEmpty() + (denomination.toString() to it)
                        onForeignChange(currency, values)
                    }
                )
            }
        }
        item {
            OutlinedTextField(
                value = draft.transferCup,
                onValueChange = { onTransferChange(it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.replace(',', '.')) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Total de transferencias recibidas (CUP)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            Button(
                onClick = onNext,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
            ) { Text("Revisar cierre") }
        }
    }
}

@Composable
private fun DenominationInput(label: String, count: String, onCount: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 13.dp))
        OutlinedTextField(
            value = count,
            onValueChange = { value -> onCount(value.filter(Char::isDigit).take(6)) },
            modifier = Modifier.width(112.dp),
            label = { Text("Billetes") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
    }
}

@Composable
private fun ReviewStep(
    context: ShiftCloseContext,
    draft: ShiftCloseDraftUi,
    cupTotalMinor: Long,
    foreignTotalsMinor: Map<String, Long>,
    modifier: Modifier = Modifier,
    onNotesChange: (String) -> Unit,
    onBack: () -> Unit,
    onSubmit: () -> Unit,
    busy: Boolean
) {
    val money = runCatching {
        ShiftCloseCalculator.summarizeMoney(
            cupDenominations = draft.cupCash,
            foreignDenominations = draft.foreignCash,
            transferCupText = draft.transferCup,
            payments = context.paymentTotals,
            exchangeRatesMicros = context.exchangeRatesMicros
        )
    }
    val countErrors = context.products.filter { product ->
        val value = draft.counts[product.productId]?.trim().orEmpty()
        value.isEmpty() || runCatching { ShiftCloseCalculator.quantityToMicros(value, product.unit) }.isFailure
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = modifier) {
        item {
            Text("Resumen del turno", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("${context.products.size - countErrors.size} de ${context.products.size} productos contados", color = if (countErrors.isEmpty()) Success else Danger)
            if (countErrors.isNotEmpty()) {
                InfoCard("Faltan conteos", "Debes completar todos los productos antes de enviar el cierre.")
            }
        }
        item {
            SummaryRow("Efectivo CUP", formatMoney(cupTotalMinor))
            foreignTotalsMinor.forEach { (currency, total) ->
                SummaryRow("Efectivo $currency", "${formatMoney(total)} $currency")
            }
        }
        item {
            val result = money.getOrNull()
            if (result != null) {
                SummaryRow("Transferencias", formatMoney(result.transferCupMinor))
                SummaryRow("Total contado (equivalente CUP)", formatMoney(result.countedTotalCupMinor), emphasized = true)
                SummaryRow("Ventas registradas esperadas", formatMoney(result.expectedSalesCupMinor))
                SummaryRow(
                    if (result.differenceCupMinor > 0) "Sobrante" else if (result.differenceCupMinor < 0) "Faltante" else "Diferencia",
                    formatMoney(kotlin.math.abs(result.differenceCupMinor)),
                    emphasized = true
                )
            } else {
                InfoCard("Falta información", money.exceptionOrNull()?.message ?: "No se pudo calcular el total.")
            }
        }
        item {
            Text("Productos para revisar", color = Gold, fontWeight = FontWeight.Bold)
        }
        items(context.products, key = { it.productId }) { product ->
            val finalMicros = runCatching { ShiftCloseCalculator.quantityToMicros(draft.counts[product.productId].orEmpty(), product.unit) }.getOrNull()
            val difference = finalMicros?.let { product.availableQuantityMicros - it }
            val opening = context.openingQuantitiesMicros[product.productId]
            val received = context.receivedQuantitiesMicros[product.productId] ?: 0L
            val ipv = if (context.openingInventoryAvailable && finalMicros != null && opening != null) {
                runCatching { ShiftCloseCalculator.ipvQuantityMicros(opening, received, finalMicros) }.getOrNull()
            } else null
            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                Text(product.name, fontWeight = FontWeight.SemiBold)
                Text(
                    if (difference == null) "Conteo pendiente"
                    else "Sistema: ${formatQuantity(product.availableQuantityMicros)} · Físico: ${formatQuantity(finalMicros)} · Diferencia de sistema: ${formatQuantity(difference)} ${product.unit}" +
                        (ipv?.let { " · IPV: ${formatQuantity(it)}" } ?: ""),
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        item {
            OutlinedTextField(
                value = draft.notes,
                onValueChange = onNotesChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Observaciones (opcional)") },
                minLines = 2,
                maxLines = 3
            )
            if (context.openingInventoryAvailable) {
                Text("El informe incluye existencias al abrir el turno y el IPV calculado desde ese stock.", color = Success, style = MaterialTheme.typography.bodySmall)
            } else {
                Text("El IPV desde la apertura no se incluirá porque no existe un inventario inicial capturado.", color = Danger, style = MaterialTheme.typography.bodySmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = onBack, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Volver") }
                Button(
                    onClick = onSubmit,
                    enabled = !busy && countErrors.isEmpty() && money.isSuccess && context.products.isNotEmpty(),
                    modifier = Modifier.weight(1f).heightIn(min = 52.dp)
                ) { Text(if (busy) "Preparando…" else "Firmar y exportar") }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String, emphasized: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontWeight = if (emphasized) FontWeight.Bold else FontWeight.Normal)
        Text(value, color = if (emphasized) Gold else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(13.dp),
        colors = CardDefaults.cardColors(containerColor = NavyElevated)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun denominationsFor(currency: String): List<Int> = when (currency.uppercase(Locale.ROOT)) {
    "USD" -> USD_DENOMINATIONS
    "EUR" -> EUR_DENOMINATIONS
    else -> OTHER_DENOMINATIONS
}

private fun formatQuantity(micros: Long): String = BigDecimal.valueOf(micros, 6)
    .stripTrailingZeros().toPlainString()

private fun formatMoney(minor: Long): String = BigDecimal.valueOf(minor, 2)
    .setScale(2, RoundingMode.HALF_UP).toPlainString()

private fun buildClosingReport(context: ShiftCloseContext, draft: ShiftCloseDraftUi): JSONObject {
    require(context.products.isNotEmpty()) { "Este turno no tiene productos que contar." }
    val productRows = JSONArray()
    context.products.forEach { product ->
        val countText = draft.counts[product.productId]?.trim().orEmpty()
        require(countText.isNotEmpty()) { "Falta contar ${product.name}." }
        val finalMicros = ShiftCloseCalculator.quantityToMicros(countText, product.unit)
        val opening = context.openingQuantitiesMicros[product.productId]
        val received = context.receivedQuantitiesMicros[product.productId] ?: 0L
        val row = JSONObject()
            .put("productId", product.productId)
            .put("name", product.name)
            .put("unit", product.unit)
            .put("systemExpectedQuantityMicros", product.availableQuantityMicros)
            .put("finalQuantityMicros", finalMicros)
            .put("soldQuantityMicros", context.soldQuantitiesMicros[product.productId] ?: 0L)
            .put("receivedQuantityMicros", received)
            .put("systemStockDifferenceMicros", Math.subtractExact(product.availableQuantityMicros, finalMicros))
        if (context.openingInventoryAvailable && opening != null) {
            row.put("openingQuantityMicros", opening)
            row.put("ipvQuantityMicros", ShiftCloseCalculator.ipvQuantityMicros(opening, received, finalMicros))
        } else {
            row.put("openingQuantityMicros", JSONObject.NULL)
            row.put("ipvQuantityMicros", JSONObject.NULL)
        }
        productRows.put(row)
    }
    val totals = ShiftCloseCalculator.summarizeMoney(
        cupDenominations = draft.cupCash,
        foreignDenominations = draft.foreignCash,
        transferCupText = draft.transferCup,
        payments = context.paymentTotals,
        exchangeRatesMicros = context.exchangeRatesMicros
    )
    val currencyDetails = JSONObject()
    currencyDetails.put("CUP", JSONObject().put("denominations", stringMapToJson(draft.cupCash)).put("nativeTotalMinor", totals.cupCashMinor))
    totals.foreignNativeTotalsMinor.forEach { (currency, nativeTotal) ->
        currencyDetails.put(
            currency,
            JSONObject()
                .put("denominations", stringMapToJson(draft.foreignCash[currency].orEmpty()))
                .put("nativeTotalMinor", nativeTotal)
                .put("rateMicros", context.exchangeRatesMicros[currency] ?: JSONObject.NULL)
        )
    }
    val payments = JSONArray()
    context.paymentTotals.forEach { payment ->
        payments.put(
            JSONObject()
                .put("currency", payment.currency)
                .put("method", payment.method)
                .put("amountMinor", payment.amountMinor)
                .put("currencyScale", payment.currencyScale)
        )
    }
    val cash = JSONObject()
        .put("currencies", currencyDetails)
        .put("cupCashMinor", totals.cupCashMinor)
        .put("foreignCashCupMinor", totals.foreignCashCupMinor)
        .put("transferCupMinor", totals.transferCupMinor)
        .put("countedTotalCupMinor", totals.countedTotalCupMinor)
        .put("expectedSalesCupMinor", totals.expectedSalesCupMinor)
        .put("differenceCupMinor", totals.differenceCupMinor)
    return JSONObject()
        .put("schemaVersion", 1)
        .put("posId", context.permit.posId)
        .put("permitId", context.permit.permitId)
        .put("shiftId", context.permit.shiftId)
        .put("employee", context.permit.employee)
        .put("createdAt", Instant.now().toString())
        .put("openingInventoryAvailable", context.openingInventoryAvailable)
        .put("products", productRows)
        .put("paymentTotals", payments)
        .put("cash", cash)
        .put("notes", draft.notes.take(500))
}

private fun stringMapToJson(values: Map<String, String>): JSONObject = JSONObject().also { result ->
    values.forEach { (key, value) -> result.put(key, value) }
}

private fun productUnitsFromSignedClose(raw: String): Map<String, String> {
    val document = try { JSONObject(raw) } catch (error: org.json.JSONException) {
        throw IllegalArgumentException("El cierre firmado almacenado no se puede volver a leer como JSON completo.", error)
    }
    val payload = document.optJSONObject("payload")
        ?: throw IllegalArgumentException("El cierre firmado no contiene su payload.")
    val report = payload.optJSONObject("closingReport")
        ?: throw IllegalArgumentException("El cierre firmado no contiene su informe de inventario.")
    val rows = report.optJSONArray("products")
        ?: throw IllegalArgumentException("El cierre firmado no contiene la lista de productos.")
    val result = linkedMapOf<String, String>()
    for (index in 0 until rows.length()) {
        val row = rows.optJSONObject(index)
            ?: throw IllegalArgumentException("La fila ${index + 1} del cierre firmado no es válida.")
        val id = row.optString("productId")
        val unit = row.optString("unit")
        require(id.isNotBlank() && unit.isNotBlank() && result.put(id, unit) == null) {
            "El cierre firmado contiene productos sin ID/unidad o IDs repetidos."
        }
    }
    return result
}

private fun readCloseBytesLimited(input: java.io.InputStream, maxBytes: Int): ByteArray {
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    var total = 0
    while (true) {
        val count = input.read(buffer)
        if (count < 0) break
        require(count == 0 || total <= maxBytes - count) { "El archivo supera el límite de $maxBytes bytes." }
        total += count
        if (count > 0) output.write(buffer, 0, count)
    }
    require(total > 0) { "El archivo exportado está vacío." }
    return output.toByteArray()
}

private fun readCloseFileLimited(input: java.io.InputStream, maxBytes: Int): String =
    decodeCloseUtf8Strict(readCloseBytesLimited(input, maxBytes))

private fun decodeCloseUtf8Strict(bytes: ByteArray): String {
    var offset = 0
    if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) offset = 3
    return Charsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)
        .decode(ByteBuffer.wrap(bytes, offset, bytes.size - offset))
        .toString()
}

private fun verifyCloseEnvelope(
    raw: String,
    expected: SignedDeviceOperationPackage,
    permit: ShiftPermitEntity,
    productUnits: Map<String, String>,
    keyManager: DeviceKeyManager
): String {
    val doc = try { JSONObject(raw) } catch (error: org.json.JSONException) {
        throw IllegalArgumentException("El archivo exportado se pudo leer, pero no contiene un JSON completo: ${error.message ?: "estructura no reconocida"}.", error)
    }
    require(doc.optString("format") == "procontrol.offline-package" && doc.optInt("version") == 1) {
        "El archivo guardado no declara el formato procontrol.offline-package v1 esperado."
    }
    require(doc.optString("packageId") == expected.packageId && doc.optString("deviceId") == expected.deviceId &&
        doc.optString("type") == "shift_close") {
        "El archivo guardado identifica otro paquete, otro teléfono o una operación distinta del cierre."
    }
    require(expected.type == "shift_close") { "El paquete local no es de tipo cierre de turno." }
    val payload = doc.optJSONObject("payload")
        ?: throw IllegalArgumentException("El archivo no contiene el objeto payload del cierre.")
    val actualPayloadHash = MessageDigest.getInstance("SHA-256")
        .digest(CanonicalJson.stringify(payload).toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
    require(actualPayloadHash == doc.optString("payloadHash") && actualPayloadHash == expected.payloadHash) {
        "La huella SHA-256 del contenido no coincide con el paquete firmado almacenado en ProVenta."
    }
    val keys = keyManager.getOrCreate()
    require(keys.deviceId == expected.deviceId) { "La identidad local cambió; el cierre pertenece a otro teléfono." }
    val suppliedPublicPem = doc.optString("signerPublicKey")
    fun normalizePem(value: String) = value.filterNot { it.isWhitespace() }
    require(normalizePem(suppliedPublicPem) == normalizePem(keys.signingPublicPem)) {
        "La clave pública del firmante no coincide con la identidad criptográfica de este teléfono."
    }
    val pemBody = suppliedPublicPem
        .replace("-----BEGIN PUBLIC KEY-----", "")
        .replace("-----END PUBLIC KEY-----", "")
        .filterNot { it.isWhitespace() }
    val publicBytes = try { Base64.decode(pemBody, Base64.NO_WRAP) } catch (error: Exception) {
        throw IllegalArgumentException("La clave pública del cierre no se puede decodificar.", error)
    }
    val signatureObject = doc.optJSONObject("signature")
        ?: throw IllegalArgumentException("El archivo no contiene la firma digital del cierre.")
    require(signatureObject.optString("algorithm") == "Ed25519") { "El cierre no declara el algoritmo de firma Ed25519 esperado." }
    val signatureBytes = try { Base64.decode(signatureObject.optString("value"), Base64.DEFAULT) } catch (error: Exception) {
        throw IllegalArgumentException("La firma digital del archivo no tiene una codificación válida.", error)
    }
    try {
        val publicKey = KeyFactory.getInstance("Ed25519", BouncyCastleProvider())
            .generatePublic(X509EncodedKeySpec(publicBytes))
        val verifier = Signature.getInstance("Ed25519", BouncyCastleProvider())
        verifier.initVerify(publicKey)
        verifier.update(CanonicalJson.stringify(CanonicalJson.withoutSignature(doc)).toByteArray(Charsets.UTF_8))
        require(verifier.verify(signatureBytes)) { "La firma Ed25519 no coincide con el contenido exportado." }
    } finally {
        publicBytes.fill(0)
        signatureBytes.fill(0)
    }
    val shift = payload.optJSONObject("shift")
        ?: throw IllegalArgumentException("El paquete no contiene la identidad del turno.")
    val report = payload.optJSONObject("closingReport")
        ?: throw IllegalArgumentException("El paquete no contiene el informe final de cierre.")
    val shiftId = permit.shiftId ?: throw IllegalArgumentException("El permiso local no tiene un ID de turno.")
    require(payload.optString("shiftPermitId") == permit.permitId &&
        shift.optString("permitId") == permit.permitId && shift.optString("id") == shiftId &&
        shift.optString("posId") == permit.posId &&
        report.optString("permitId") == permit.permitId &&
        report.optString("shiftId") == shiftId && report.optString("posId") == permit.posId) {
        "El cierre firmado no pertenece exactamente al POS y al turno que se están exportando."
    }
    val reportProducts = report.optJSONArray("products")
        ?: throw IllegalArgumentException("El informe firmado no contiene las cantidades finales por producto.")
    val expectedById = productUnits
    val seen = linkedSetOf<String>()
    for (index in 0 until reportProducts.length()) {
        val row = reportProducts.optJSONObject(index)
            ?: throw IllegalArgumentException("La fila ${index + 1} del inventario final no es válida.")
        val id = row.optString("productId")
        require(id.isNotBlank() && seen.add(id)) { "El informe contiene un producto sin identificador o repetido." }
        val expectedUnit = expectedById[id] ?: throw IllegalArgumentException("El informe incluye un producto ajeno al inventario de este POS.")
        require(row.optString("unit") == expectedUnit) { "La unidad del producto ${row.optString("name", id)} no coincide con la copia de recuperación del POS." }
        val finalValue = row.opt("finalQuantityMicros")
        require(finalValue is Number) {
            "La cantidad final del producto ${row.optString("name", id)} no es numérica en microunidades."
        }
        val finalMicros = try {
            BigDecimal(finalValue.toString()).longValueExact()
        } catch (error: Exception) {
            throw IllegalArgumentException("La cantidad final del producto ${row.optString("name", id)} no es un entero exacto o está fuera del rango admitido.", error)
        }
        require(finalMicros in 0L..9_007_199_254_740_991L) {
            "La cantidad final del producto ${row.optString("name", id)} supera el límite entero seguro que ProControl puede representar. No se borró ningún dato."
        }
    }
    require(seen == expectedById.keys) {
        "El cierre no contiene exactamente todos los productos activos del POS. Faltan ${expectedById.keys.minus(seen).size}; sobran ${seen.minus(expectedById.keys).size}."
    }
    return actualPayloadHash
}

private fun com.proventa.app.data.entities.OutboxPackageEntity.toSignedClosePackage() =
    SignedDeviceOperationPackage(
        packageId = packageId,
        deviceId = deviceId,
        type = packageType,
        payloadHash = payloadHash,
        createdAt = createdAt,
        envelopeJson = envelopeJson
    )
