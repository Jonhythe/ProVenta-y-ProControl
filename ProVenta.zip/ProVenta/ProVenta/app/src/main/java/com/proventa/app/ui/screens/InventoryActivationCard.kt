package com.proventa.app.ui.screens

import android.Manifest
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.proventa.app.security.DeviceEnrollmentRequestFactory
import com.proventa.app.security.VerifiedDeviceAuthorization
import com.proventa.app.ui.theme.Danger
import com.proventa.app.ui.theme.Gold
import com.proventa.app.ui.theme.NavyElevated
import com.proventa.app.ui.theme.Success
import com.proventa.app.ui.theme.TextPrimary
import com.proventa.app.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun InventoryActivationCard(renewalMode: Boolean, onActivated: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    var busy by remember { mutableStateOf(false) }
    var scannerOpen by remember { mutableStateOf(false) }
    var scannerProgress by remember { mutableStateOf("Listo para detectar el QR único de ProControl.") }
    var message by remember {
        mutableStateOf(if (renewalMode) "Escanea el QR mensual nuevo que muestra ProControl." else "Escanea el QR que muestra ProControl para vincular este teléfono.")
    }
    var isError by remember { mutableStateOf(false) }
    var successDetails by remember { mutableStateOf<String?>(null) }

    suspend fun activateToken(token: String, sourceName: String) {
        busy = true
        isError = false
        message = "Verificando firma Ed25519, identidad de este teléfono e instalación ProControl…"
        try {
            val activated = withContext(Dispatchers.IO) {
                val enrollment = DeviceEnrollmentRequestFactory(context.applicationContext)
                val verified = enrollment.activateWithActivationCode(token)
                verified to enrollment.monthlyAccessExpiryMillis()
            }
            val verified = activated.first
            val expiry = activated.second?.let { java.text.DateFormat.getDateTimeInstance().format(java.util.Date(it)) } ?: "no disponible"
            val installationWide = verified.version >= 5 && verified.authorizedPosId.isNullOrBlank()
            val posName = if (installationWide) "Asignación por permiso de turno" else (verified.authorizedPosName ?: "POS ${verified.authorizedPosId ?: "sin identificador"}")
            val posId = verified.authorizedPosId ?: if (installationWide) "Se define en cada turno" else "No informado"
            successDetails = "Método utilizado: $sourceName\n\nAutorización verificada por firma Ed25519.\n\nTrabajador: ${verified.employeeName}\nAlcance: ${if (installationWide) "Instalación completa de ProControl" else "Autorización anterior ligada a POS"}\nPunto de venta: $posName\nID del POS: $posId\nID de este teléfono: ${verified.deviceId}\nInstalación ProControl: ${verified.installationId}\nVálida hasta: $expiry\n\nLa autorización quedó guardada de forma segura en este teléfono. Cada turno seguirá necesitando un permiso firmado para un POS concreto."
            message = if (installationWide) "ProVenta quedó validado hasta $expiry. El Dueño asignará el POS mediante cada permiso de turno." else "ProVenta quedó autorizado para $posName ($posId)."
            isError = false
        } catch (error: Exception) {
            isError = true
            message = error.message ?: "La autorización no superó la verificación."
        } finally {
            busy = false
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            scannerProgress = "Apunta la cámara al único QR PVLA2 de ProControl."
            scannerOpen = true
        } else {
            isError = true
            message = "No se concedió permiso para la cámara. Es necesario permitir el escaneo del QR de ProControl."
        }
    }

    if (successDetails != null) {
        AlertDialog(
            onDismissRequest = { successDetails = null; onActivated() },
            title = { Text(if (renewalMode) "ProVenta renovado correctamente" else "ProVenta activado correctamente") },
            text = { Text(successDetails.orEmpty()) },
            confirmButton = {
                TextButton(onClick = { successDetails = null; onActivated() }) {
                    Text("Entrar a ProVenta")
                }
            }
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, Gold.copy(alpha = 0.28f)),
        colors = CardDefaults.cardColors(containerColor = NavyElevated),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("02", color = Gold, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(if (renewalMode) "Renovar ProVenta" else "Activar ProVenta", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Escanea el QR firmado de ProControl", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
            }
            Text(
                if (renewalMode) "Escanea el QR nuevo que genera el Dueño. El teléfono ya está vinculado y no necesita volver a exportar su identidad." else "Escanea el QR que genera el Dueño en ProControl. La identidad de este teléfono solo se entrega una vez.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
            OutlinedButton(
                onClick = {
                    val granted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.CAMERA
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (granted) {
                        scannerProgress = "Apunta la cámara al único QR PVLA2 de ProControl."
                        scannerOpen = true
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Gold.copy(alpha = 0.65f))
            ) {
                Text(if (scannerOpen) "Escáner QR abierto" else "Escanear código QR de ProControl", fontWeight = FontWeight.Bold)
            }

            if (scannerOpen) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Gold.copy(alpha = 0.35f))
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("Escaneo de autorización ProVenta", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(
                            "Mantén el teléfono frente a la pantalla de ProControl y encuadra el QR completo. La cámara lo detectará en una sola lectura.",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                        GoodsDispatchQrScanner(
                            singleQrOnly = true,
                            instruction = "Enfoca el único QR PVLA2 que aparece en ProControl. Cuando se detecte, la autorización se verificará automáticamente.",
                            onFrames = { decodedFrames ->
                                mainHandler.post {
                                    if (!scannerOpen || busy) return@post
                                    val activationCode = decodedFrames.firstOrNull { value ->
                                        value.startsWith("PVLA2:")
                                    }
                                    if (activationCode == null) {
                                        if (decodedFrames.isNotEmpty()) {
                                            scannerProgress = "QR detectado, pero no es una autorización PVLA2 de ProControl. Mantén la cámara sobre el QR correcto."
                                        }
                                        return@post
                                    }

                                    // Una lectura entrega el QR firmado y ligado a este teléfono.
                                    busy = true
                                    scannerOpen = false
                                    scannerProgress = "QR único detectado. Verificando autorización…"
                                    scope.launch {
                                        activateToken(activationCode, "QR único PVLA2 de ProControl")
                                    }
                                }
                            },
                            onError = { error ->
                                mainHandler.post {
                                    if (scannerOpen && !busy) scannerProgress = error
                                }
                            }
                        )
                        Text(scannerProgress, color = Gold, style = MaterialTheme.typography.bodySmall)
                        TextButton(
                            onClick = {
                                scannerOpen = false
                                scannerProgress = "Escaneo cancelado. Puedes volver a escanear el QR cuando quieras."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Cerrar escáner") }
                    }
                }
            }

            Text(
                "Seguridad: el QR tiene una vigencia de 5 minutos, se firma con Ed25519 y queda ligado a la identidad de este teléfono. Cada renovación incrementa una secuencia para impedir reutilizar QR anteriores. Cada turno sigue necesitando un permiso firmado para un POS concreto.",
                color = TextSecondary,
                style = MaterialTheme.typography.labelSmall
            )
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(13.dp),
                colors = CardDefaults.cardColors(containerColor = (if (isError) Danger else Success).copy(alpha = 0.08f)),
                border = BorderStroke(1.dp, (if (isError) Danger else Success).copy(alpha = 0.25f))
            ) {
                Text(
                    message,
                    modifier = Modifier.padding(12.dp),
                    color = TextPrimary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
