package com.proventa.app.data.shifts

data class ShiftProductSalesSummary(
    val productId: String,
    val quantityMicros: Long
)

data class ShiftPaymentSummary(
    val currency: String,
    val method: String,
    val amountMinor: Long,
    val currencyScale: Int
)
