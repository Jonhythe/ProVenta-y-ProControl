package com.proventa.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.proventa.app.ui.theme.TextSecondary

@Composable
fun ModuleScreen(title: String, description: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(description, color = TextSecondary, style = MaterialTheme.typography.bodyLarge)
        Text(
            "Módulo planificado. La lógica comercial se implementará y probará antes de habilitarlo.",
            color = TextSecondary,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
