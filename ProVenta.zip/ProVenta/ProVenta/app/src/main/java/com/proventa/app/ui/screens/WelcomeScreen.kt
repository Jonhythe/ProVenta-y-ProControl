package com.proventa.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import com.proventa.app.R
import com.proventa.app.ui.theme.Gold
import com.proventa.app.ui.theme.GoldSoft
import kotlinx.coroutines.delay

@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    var finished by remember { mutableStateOf(false) }
    val latestOnContinue by rememberUpdatedState(onContinue)
    val finish = {
        if (!finished) {
            finished = true
            latestOnContinue()
        }
    }

    LaunchedEffect(Unit) {
        delay(4_900L)
        finish()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0A1B31), Color(0xFF061226), Color(0xFF02060D))
                )
            )
            .clickable(onClick = finish)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .border(
                    BorderStroke(1.dp, Gold.copy(alpha = 0.2f)),
                    RoundedCornerShape(20.dp)
                )
        )
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = maxHeight)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                WelcomeFrame(onContinue = finish)
            }
        }
    }
}

@Composable
private fun WelcomeFrame(onContinue: () -> Unit) {
    val frameShape = RoundedCornerShape(26.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, Gold.copy(alpha = 0.72f)), frameShape)
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF102947), Color(0xFF061225), Color(0xFF0A1B31))
                ),
                frameShape
            )
            .padding(horizontal = 20.dp, vertical = 26.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(17.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .border(BorderStroke(1.dp, GoldSoft), CircleShape)
                .background(Color(0xFF08192E), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(25.dp)) {
                val centerX = size.width / 2f
                val centerY = size.height / 2f
                val diamond = Path().apply {
                    moveTo(centerX, size.height * 0.08f)
                    lineTo(size.width * 0.92f, centerY)
                    lineTo(centerX, size.height * 0.92f)
                    lineTo(size.width * 0.08f, centerY)
                    close()
                }
                drawPath(diamond, GoldSoft, style = Stroke(width = 1.4.dp.toPx()))
                drawLine(GoldSoft, androidx.compose.ui.geometry.Offset(centerX, size.height * 0.2f), androidx.compose.ui.geometry.Offset(centerX, size.height * 0.8f), 1.dp.toPx())
                drawLine(GoldSoft, androidx.compose.ui.geometry.Offset(size.width * 0.2f, centerY), androidx.compose.ui.geometry.Offset(size.width * 0.8f, centerY), 1.dp.toPx())
            }
        }

        MarbleBrandPlaque()

        Text(
            "Desarrollado por",
            color = GoldSoft,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        Image(
            painter = painterResource(R.drawable.roninlab_logo),
            contentDescription = "Logo de Ronin Lab",
            contentScale = ContentScale.Fit,
            modifier = Modifier.size(82.dp)
        )
        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp),
            shape = RoundedCornerShape(9.dp),
            border = BorderStroke(1.dp, Gold),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF174A7B),
                contentColor = Color(0xFFF8F0D8)
            )
        ) {
            Text("Entrar a ProVenta", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
        Text(
            "La bienvenida continuará automáticamente",
            color = Color(0xFFB8C5D4).copy(alpha = 0.68f),
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun MarbleBrandPlaque() {
    val plaqueShape = RoundedCornerShape(17.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(plaqueShape)
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFFD8DAD9),
                        Color(0xFFBEC4C8),
                        Color(0xFFE5E3DC),
                        Color(0xFFAEB6BD),
                        Color(0xFFD9DAD6)
                    )
                )
            )
            .marbleVeins()
            .border(BorderStroke(1.dp, Gold), plaqueShape)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 25.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text(
                "SISTEMA DE VENTAS",
                color = Color(0xFF425365),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.2.sp,
                textAlign = TextAlign.Center
            )
            Text(
                "ProVenta",
                color = Color(0xFF0A2342),
                fontFamily = FontFamily.Serif,
                fontSize = 52.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-1.5).sp,
                maxLines = 1,
                textAlign = TextAlign.Center
            )
            Text(
                "VENTAS · INVENTARIO · CAJA",
                color = Color(0xFF12365B),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

private fun Modifier.marbleVeins(): Modifier = drawBehind {
    val darkVein = Color(0xFF28394B).copy(alpha = 0.13f)
    val lightVein = Color.White.copy(alpha = 0.34f)
    val strokeWidth = 1.dp.toPx()

    val firstVein = Path().apply {
        moveTo(-size.width * 0.08f, size.height * 0.26f)
        cubicTo(size.width * 0.2f, size.height * 0.08f, size.width * 0.34f, size.height * 0.44f, size.width * 0.58f, size.height * 0.27f)
        cubicTo(size.width * 0.76f, size.height * 0.14f, size.width * 0.88f, size.height * 0.37f, size.width * 1.08f, size.height * 0.2f)
    }
    val secondVein = Path().apply {
        moveTo(-size.width * 0.05f, size.height * 0.78f)
        cubicTo(size.width * 0.19f, size.height * 0.61f, size.width * 0.33f, size.height * 0.95f, size.width * 0.53f, size.height * 0.73f)
        cubicTo(size.width * 0.72f, size.height * 0.52f, size.width * 0.87f, size.height * 0.88f, size.width * 1.06f, size.height * 0.64f)
    }
    drawPath(firstVein, darkVein, style = Stroke(width = strokeWidth * 2f))
    drawPath(secondVein, lightVein, style = Stroke(width = strokeWidth))
}
