package com.proventa.app.security

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.DateTimeException

data class MonthlyAccessRecord(
    val installationId: String,
    val authorizationId: String,
    val renewalSequence: Long,
    val activatedAtMillis: Long,
    val expiresAtMillis: Long,
    val zoneId: String,
    val lastWallClockMillis: Long,
    val lastElapsedRealtimeMillis: Long,
    val bootCount: Int
)

enum class MonthlyAccessFailure {
    EXPIRED,
    CLOCK_CHANGED,
    AUTHORIZATION_CHANGED,
    INVALID_RECORD
}

data class MonthlyAccessCheck(
    val record: MonthlyAccessRecord?,
    val failure: MonthlyAccessFailure?
) {
    val isActive: Boolean get() = record != null && failure == null
}

object MonthlyAccessWindow {
    const val CLOCK_TOLERANCE_MILLIS = 30 * 1000L

    fun create(
        installationId: String,
        authorizationId: String,
        renewalSequence: Long,
        nowMillis: Long,
        elapsedRealtimeMillis: Long,
        bootCount: Int,
        zoneId: String
    ): MonthlyAccessRecord {
        require(installationId.matches(Regex("pcinst_[a-f0-9]{32}")))
        require(authorizationId.matches(Regex("auth_[A-Za-z0-9-]{20,60}")))
        require(renewalSequence >= 1L)
        require(nowMillis > 0L && elapsedRealtimeMillis >= 0L)
        val zone = ZoneId.of(zoneId)
        val currentDate = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
        val dueDate = currentDate.plusMonths(1)
        val expiry = dueDate.atTime(LocalTime.of(3, 0)).atZone(zone).toInstant().toEpochMilli()
        require(expiry > nowMillis)
        return MonthlyAccessRecord(
            installationId = installationId,
            authorizationId = authorizationId,
            renewalSequence = renewalSequence,
            activatedAtMillis = nowMillis,
            expiresAtMillis = expiry,
            zoneId = zone.id,
            lastWallClockMillis = nowMillis,
            lastElapsedRealtimeMillis = elapsedRealtimeMillis,
            bootCount = bootCount
        )
    }

    fun check(
        record: MonthlyAccessRecord,
        installationId: String,
        authorizationId: String,
        renewalSequence: Long,
        nowMillis: Long,
        elapsedRealtimeMillis: Long,
        bootCount: Int
    ): MonthlyAccessCheck {
        if (record.renewalSequence < 1L ||
            record.expiresAtMillis <= record.activatedAtMillis ||
            record.lastWallClockMillis < record.activatedAtMillis ||
            record.lastElapsedRealtimeMillis < 0L ||
            runCatching { expiryFor(record.activatedAtMillis, record.zoneId) }.getOrNull() != record.expiresAtMillis) {
            return MonthlyAccessCheck(null, MonthlyAccessFailure.INVALID_RECORD)
        }
        if (record.installationId != installationId ||
            record.authorizationId != authorizationId ||
            record.renewalSequence != renewalSequence) {
            return MonthlyAccessCheck(null, MonthlyAccessFailure.AUTHORIZATION_CHANGED)
        }
        if (nowMillis < record.lastWallClockMillis - CLOCK_TOLERANCE_MILLIS) {
            return MonthlyAccessCheck(null, MonthlyAccessFailure.CLOCK_CHANGED)
        }
        if (record.bootCount >= 0 && bootCount == record.bootCount) {
            val wallDelta = nowMillis - record.lastWallClockMillis
            val elapsedDelta = elapsedRealtimeMillis - record.lastElapsedRealtimeMillis
            val drift = wallDelta - elapsedDelta
            if (elapsedDelta < 0L || drift > CLOCK_TOLERANCE_MILLIS || drift < -CLOCK_TOLERANCE_MILLIS) {
                return MonthlyAccessCheck(null, MonthlyAccessFailure.CLOCK_CHANGED)
            }
        }
        if (nowMillis >= record.expiresAtMillis) {
            return MonthlyAccessCheck(null, MonthlyAccessFailure.EXPIRED)
        }
        return MonthlyAccessCheck(
            record.copy(
                lastWallClockMillis = maxOf(record.lastWallClockMillis, nowMillis),
                lastElapsedRealtimeMillis = elapsedRealtimeMillis,
                bootCount = bootCount
            ),
            null
        )
    }

    fun expiryFor(nowMillis: Long, zoneId: String): Long {
        val zone = try {
            ZoneId.of(zoneId)
        } catch (_: DateTimeException) {
            throw IllegalArgumentException("La zona horaria del teléfono no es válida.")
        }
        val dueDate: LocalDate = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate().plusMonths(1)
        return dueDate.atTime(3, 0).atZone(zone).toInstant().toEpochMilli()
    }
}
