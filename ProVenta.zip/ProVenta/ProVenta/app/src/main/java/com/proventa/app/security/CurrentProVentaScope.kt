package com.proventa.app.security

import android.content.Context
import com.proventa.app.data.ProVentaDatabaseFactory

/**
 * Immutable, locally verified scope for the one ProControl installation and POS
 * currently authorized on this phone. All service-layer operations use this
 * instead of trusting a POS identifier supplied by the UI.
 */
data class CurrentProVentaScope(
    val installationId: String,
    val authorizationId: String,
    val posId: String,
    val deviceId: String,
    val employeeName: String
) {
    fun requirePos(candidatePosId: String) {
        require(candidatePosId.isNotBlank() && candidatePosId == posId) {
            "Este teléfono solo está autorizado para el punto de venta $posId."
        }
    }

    fun requirePermitScope(
        permitInstallationId: String,
        permitAuthorizationId: String,
        permitPosId: String,
        permitDeviceId: String
    ) {
        require(
            permitInstallationId == installationId &&
                permitAuthorizationId == authorizationId &&
                permitPosId == posId &&
                permitDeviceId == deviceId
        ) {
            "El permiso pertenece a otra instalación, autorización, teléfono o punto de venta."
        }
    }
}

class CurrentProVentaScopeProvider(context: Context) {
    private val appContext = context.applicationContext
    private val enrollment = DeviceEnrollmentRequestFactory(appContext)
    private val keyManager = DeviceKeyManager(appContext)
    private val dao = ProVentaDatabaseFactory.get(appContext).proVentaDao()

    suspend fun requireCurrent(nowMillis: Long = System.currentTimeMillis()): CurrentProVentaScope {
        val authorization = enrollment.trustedInstallationAuthorization(nowMillis)
            ?: throw IllegalStateException("Este teléfono no tiene una autorización permanente válida de ProControl.")
        val deviceId = authorization.deviceId?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("La autorización actual no está vinculada a la identidad de este teléfono.")
        require(authorization.permanent && authorization.version >= 4) {
            "La operación requiere una autorización permanente de ProControl."
        }
        val localIdentity = keyManager.getOrCreate()
        require(localIdentity.deviceId == deviceId) {
            "La identidad local no coincide con el dispositivo autorizado."
        }
        val posId = if (authorization.version < 5) {
            authorization.authorizedPosId?.takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("La autorización anterior no contiene un punto de venta.")
        } else {
            val activePermits = dao.listShiftPermitsForDevice(
                installationId = authorization.installationId,
                authorizationId = authorization.authorizationId,
                deviceId = deviceId
            ).filter { permit ->
                val started = permit.startsAt <= nowMillis
                started && (
                    permit.status in setOf("OPEN_PENDING_REVIEW", "OPENED", "CLOSE_PENDING") ||
                        (permit.status == "ISSUED" && permit.endsAt > nowMillis)
                    )
            }
            require(activePermits.size == 1) {
                when {
                    activePermits.isEmpty() -> "Este teléfono está autorizado para la instalación, pero todavía no tiene un permiso de turno vigente. Importa el permiso firmado que emitió ProControl."
                    else -> "Hay más de un permiso de turno vigente para este teléfono. Se bloqueó la operación hasta resolver el conflicto con el Dueño."
                }
            }
            activePermits.single().posId
        }
        require(posId.matches(Regex("[A-Za-z0-9:_-]{1,160}"))) { "El permiso no contiene un punto de venta válido." }
        return CurrentProVentaScope(
            installationId = authorization.installationId,
            authorizationId = authorization.authorizationId,
            posId = posId,
            deviceId = deviceId,
            employeeName = authorization.employeeName
        )
    }
}
