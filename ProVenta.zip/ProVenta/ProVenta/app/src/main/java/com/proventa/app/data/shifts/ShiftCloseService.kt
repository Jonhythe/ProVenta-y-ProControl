package com.proventa.app.data.shifts

import android.content.Context
import com.proventa.app.data.ProVentaDatabaseFactory
import com.proventa.app.data.entities.InventorySnapshotEntity
import com.proventa.app.data.entities.OutboxPackageEntity
import com.proventa.app.data.entities.ProductEntity
import com.proventa.app.data.entities.ShiftPermitEntity
import com.proventa.app.security.CurrentProVentaScopeProvider
import com.proventa.app.security.DeviceOperationPackageFactory
import com.proventa.app.security.SignedDeviceOperationPackage
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.util.Locale
import java.util.UUID
import java.time.Instant

data class ShiftCloseContext(
    val permit: ShiftPermitEntity,
    val products: List<ProductEntity>,
    val openingQuantitiesMicros: Map<String, Long>,
    val soldQuantitiesMicros: Map<String, Long>,
    val receivedQuantitiesMicros: Map<String, Long>,
    val paymentTotals: List<ShiftPaymentSummary>,
    val exchangeRatesMicros: Map<String, Long>,
    val openingInventoryAvailable: Boolean,
    val draftJson: String?,
    val pendingPackage: OutboxPackageEntity?
)

class ShiftCloseService(context: Context) {
    private val appContext = context.applicationContext
    private val dao = ProVentaDatabaseFactory.get(appContext).proVentaDao()
    private val packageFactory = DeviceOperationPackageFactory(appContext)
    private val scopeProvider = CurrentProVentaScopeProvider(appContext)

    suspend fun loadLatestContext(): ShiftCloseContext? {
        val scope = runCatching { scopeProvider.requireCurrent() }.getOrNull() ?: return null
        val permits = dao.listShiftPermits(
            installationId = scope.installationId,
            authorizationId = scope.authorizationId,
            posId = scope.posId,
            deviceId = scope.deviceId
        )
        val permit = permits.firstOrNull { it.status == "OPENED" || it.status == "CLOSE_PENDING" }
            ?: return null
        scope.requirePermitScope(permit.installationId, permit.authorizationId, permit.posId, permit.deviceId)
        val shiftId = permit.shiftId ?: throw IllegalStateException("El permiso no tiene un identificador de turno confirmado.")
        val allProducts = dao.listActiveProducts(permit.posId)
        val soldRows = dao.getShiftProductSalesSummary(shiftId, scope.posId)
        val sold = soldRows.associate { it.productId to it.quantityMicros }
        val openingPackage = dao.getOutboxPackageForAggregate(permit.permitId, "shift_open")
        require(openingPackage == null || openingPackage.deviceId == scope.deviceId) {
            "El paquete de apertura pertenece a otro teléfono autorizado."
        }
        val opening = openingPackage?.let { parseOpeningInventory(it.envelopeJson) }.orEmpty()
        val shiftOpenedAt = openingPackage?.acknowledgedAt ?: permit.importedAt
        val receivedReceipts = dao.listConfirmedShiftGoodsReceipts(permit.posId, shiftOpenedAt).filter { receipt ->
            runCatching {
                val manifest = JSONObject(receipt.manifestJson)
                manifest.optString("installationId") == scope.installationId &&
                    manifest.optString("posId") == scope.posId
            }.getOrDefault(false)
        }
        val received = parseConfirmedReceipts(receivedReceipts)
        // El cierre representa el inventario final absoluto del POS. También deben
        // contarse artículos activos que hoy estén en cero; omitirlos dejaría stock
        // anterior sin posibilidad de ponerlo a cero en ProControl.
        val products = allProducts
        val snapshot = dao.getInventorySnapshotForScope(
            posId = scope.posId,
            installationId = scope.installationId,
            deviceId = scope.deviceId
        )
        val visibleProductIds = products.map { it.productId }.toSet()
        val openingInventoryComplete = opening.isNotEmpty() &&
            opening.filterValues { it > 0L }.keys.all { it in visibleProductIds } &&
            received.filterValues { it > 0L }.keys.all { it in visibleProductIds }
        val pendingClosePackage = dao.getOutboxPackageForAggregate(permit.permitId, "shift_close")
        require(pendingClosePackage == null || pendingClosePackage.deviceId == scope.deviceId) {
            "El paquete de cierre pertenece a otro teléfono autorizado."
        }
        return ShiftCloseContext(
            permit = permit,
            products = products,
            openingQuantitiesMicros = opening,
            soldQuantitiesMicros = sold,
            receivedQuantitiesMicros = received,
            paymentTotals = dao.getShiftPaymentSummary(shiftId, scope.posId),
            exchangeRatesMicros = parseRates(snapshot),
            openingInventoryAvailable = openingInventoryComplete,
            draftJson = dao.getShiftCloseDraft(permit.permitId)?.draftJson,
            pendingPackage = pendingClosePackage
        )
    }

    suspend fun saveDraft(context: ShiftCloseContext, draftJson: String) {
        val currentPermit = dao.getShiftPermit(context.permit.permitId)
            ?: throw IllegalStateException("El permiso del turno ya no existe.")
        val scope = scopeProvider.requireCurrent()
        scope.requirePermitScope(currentPermit.installationId, currentPermit.authorizationId, currentPermit.posId, currentPermit.deviceId)
        require(
            currentPermit.status == "OPENED" &&
                currentPermit.shiftId == context.permit.shiftId &&
                currentPermit.posId == context.permit.posId
        ) { "El turno ya no admite cambios porque su estado o alcance cambió." }
        require(draftJson.toByteArray(Charsets.UTF_8).size <= MAX_DRAFT_BYTES) {
            "El borrador del cierre supera el tamaño permitido."
        }
        val document = JSONObject(draftJson)
        require(document.optInt("schemaVersion") == 1) { "Versión de borrador no compatible." }
        val shiftId = currentPermit.shiftId
            ?: throw IllegalStateException("El turno no tiene ID.")
        dao.saveShiftCloseDraft(
            com.proventa.app.data.entities.ShiftCloseDraftEntity(
                permitId = currentPermit.permitId,
                shiftId = shiftId,
                posId = currentPermit.posId,
                draftJson = draftJson,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun createOrGetClosePackage(
        permitId: String,
        closingReportJson: String,
        nowMillis: Long = System.currentTimeMillis()
    ): SignedDeviceOperationPackage {
        val permit = dao.getShiftPermit(permitId)
            ?: throw IllegalArgumentException("No se encontró el permiso de turno.")
        val scope = scopeProvider.requireCurrent(nowMillis)
        scope.requirePermitScope(permit.installationId, permit.authorizationId, permit.posId, permit.deviceId)
        val existing = dao.getOutboxPackageForAggregate(permitId, "shift_close")
        if (permit.status == "CLOSE_PENDING") {
            require(existing != null && existing.deviceId == scope.deviceId &&
                existing.status == "PENDING" && existing.acknowledgementJson == null) {
                "El cierre está pendiente, pero no se encontró su paquete exportable."
            }
            return existing.toSignedPackage()
        }
        require(permit.status == "OPENED") { "Solo se puede cerrar un turno confirmado y abierto." }
        val shiftId = permit.shiftId?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("El turno no tiene un identificador confirmado.")
        require(nowMillis >= permit.startsAt) {
            "El turno todavía no ha comenzado según el horario autorizado."
        }
        val report = JSONObject(closingReportJson)
        require(report.optInt("schemaVersion") == 1) { "El informe de cierre no tiene una versión compatible." }
        val reportProducts = report.optJSONArray("products")
            ?: throw IllegalArgumentException("El informe de cierre no contiene la lista final de productos.")
        require(report.optJSONObject("cash") != null) { "El informe de cierre no contiene el conteo de caja." }
        require(report.optString("posId") == permit.posId && report.optString("permitId") == permit.permitId &&
            report.optString("shiftId") == shiftId) {
            "El informe identifica otro POS, permiso o turno. No se firmó el cierre."
        }
        val currentProducts = dao.listActiveProducts(permit.posId)
        val expectedIds = currentProducts.map { it.productId }.toSet()
        val reportedIds = linkedSetOf<String>()
        for (index in 0 until reportProducts.length()) {
            val row = reportProducts.optJSONObject(index)
                ?: throw IllegalArgumentException("El producto ${index + 1} del cierre no es un objeto válido.")
            val productId = row.optString("productId")
            require(productId.isNotBlank() && reportedIds.add(productId)) {
                "El cierre contiene un producto sin ID o repetido. No se firmó el archivo."
            }
            val source = currentProducts.firstOrNull { it.productId == productId }
                ?: throw IllegalArgumentException("El cierre contiene un producto que no pertenece al POS autorizado.")
            val finalValue = row.opt("finalQuantityMicros")
            val finalMicros = try {
                require(finalValue is Number) { "La cantidad final debe ser un número entero de microunidades." }
                BigDecimal(finalValue.toString()).longValueExact()
            } catch (error: Exception) {
                throw IllegalArgumentException(
                    "El producto ${source.name} tiene una cantidad final fraccionaria, ausente o fuera del rango entero admitido. No se firmó el cierre.",
                    error
                )
            }
            require(row.optString("unit") == source.unit && finalMicros in 0L..MAX_SAFE_JSON_INTEGER) {
                "El producto ${source.name} tiene una unidad o cantidad final no válida. No se firmó el cierre."
            }
        }
        require(reportedIds == expectedIds) {
            val missing = expectedIds - reportedIds
            val extra = reportedIds - expectedIds
            "El cierre no representa todo el inventario activo del POS (faltan ${missing.size} y sobran ${extra.size} productos). No se firmó ni exportó."
        }
        val shift = JSONObject()
            .put("id", shiftId)
            .put("permitId", permitId)
            .put("posId", permit.posId)
            .put("closedAt", Instant.ofEpochMilli(nowMillis).toString())
        val payload = JSONObject()
            .put("schemaVersion", 1)
            .put("shiftPermitId", permitId)
            .put("shift", shift)
            .put("closingReport", report)
        val signed = packageFactory.create("shift_close", payload, nowMillis)
        val entity = OutboxPackageEntity(
            packageId = signed.packageId,
            deviceId = signed.deviceId,
            packageType = signed.type,
            payloadHash = signed.payloadHash,
            envelopeJson = signed.envelopeJson,
            aggregateId = permitId,
            status = "PENDING",
            createdAt = signed.createdAt,
            acknowledgementJson = null,
            acknowledgedAt = null
        )
        dao.storeShiftClosePackage(permitId, entity)
        return signed
    }

    private fun parseConfirmedReceipts(
        receipts: List<com.proventa.app.data.entities.GoodsReceiptEntity>
    ): Map<String, Long> {
        val totals = LinkedHashMap<String, Long>()
        receipts.forEach { receipt ->
            val manifest = JSONObject(receipt.manifestJson)
            val items = manifest.getJSONArray("items")
            for (index in 0 until items.length()) {
                val item = items.getJSONObject(index)
                val productId = item.getString("productId")
                require(productId.isNotBlank()) { "Una entrada confirmada contiene un producto sin ID." }
                val quantityValue = item.get("quantity")
                val quantityMicros = BigDecimal(quantityValue.toString())
                    .movePointRight(6)
                    .setScale(0, java.math.RoundingMode.UNNECESSARY)
                    .longValueExact()
                require(quantityMicros > 0L) { "Una entrada confirmada contiene una cantidad inválida." }
                totals[productId] = Math.addExact(totals[productId] ?: 0L, quantityMicros)
            }
        }
        return totals
    }

    private fun parseOpeningInventory(envelopeJson: String): Map<String, Long> {
        return runCatching {
            val shift = JSONObject(envelopeJson).getJSONObject("payload").getJSONObject("shift")
            val rows = shift.optJSONArray("initialInventory") ?: return@runCatching emptyMap()
            buildMap {
                for (index in 0 until rows.length()) {
                    val item = rows.getJSONObject(index)
                    val id = item.getString("productId")
                    val quantity = item.getLong("quantityMicros")
                    require(id.isNotBlank() && quantity >= 0L)
                    put(id, quantity)
                }
            }
        }.getOrDefault(emptyMap())
    }

    private fun parseRates(snapshot: InventorySnapshotEntity?): Map<String, Long> {
        if (snapshot == null) return emptyMap()
        return runCatching {
            val rates = JSONObject(snapshot.exchangeRatesJson)
            buildMap {
                val keys = rates.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    if (!key.endsWith("_CUP")) continue
                    val currency = key.removeSuffix("_CUP").uppercase(Locale.ROOT)
                    val value = rates.opt(key)
                    if (currency.matches(Regex("[A-Z0-9_-]{2,20}")) && value is Number) {
                        val rate = BigDecimal(value.toString()).movePointRight(6).longValueExact()
                        if (rate > 0L) put(currency, rate)
                    }
                }
            }
        }.getOrDefault(emptyMap())
    }

    private fun OutboxPackageEntity.toSignedPackage() = SignedDeviceOperationPackage(
        packageId = packageId,
        deviceId = deviceId,
        type = packageType,
        payloadHash = payloadHash,
        createdAt = createdAt,
        envelopeJson = envelopeJson
    )

    private companion object {
        const val MAX_DRAFT_BYTES = 1024 * 1024
        // El informe también se consume en JavaScript (Number); evita perder precisión al conciliarlo.
        const val MAX_SAFE_JSON_INTEGER = 9_007_199_254_740_991L
    }
}
