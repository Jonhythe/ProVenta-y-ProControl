package com.proventa.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.GeneralSecurityException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Small encrypted record store for local ProVenta data.
 *
 * Files are placed in noBackupFilesDir and encrypted with an AES-256-GCM key
 * generated inside Android Keystore. Record identifiers are validated before
 * they are used as file names. This is a storage primitive, not a database.
 */
class SecureLocalStore(context: Context) {
    private val directory = File(context.noBackupFilesDir, DIRECTORY_NAME).apply {
        if (!exists() && !mkdirs()) {
            throw IllegalStateException("No se pudo crear el almacenamiento privado de ProVenta.")
        }
    }

    @Synchronized
    @Throws(GeneralSecurityException::class, java.io.IOException::class)
    fun put(recordId: String, plaintext: ByteArray) {
        validateRecordId(recordId)
        require(plaintext.size <= MAX_RECORD_BYTES - 64) { "El registro cifrado supera el tamaño permitido." }
        val key = getOrCreateKey()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key)
        cipher.updateAAD(recordId.toByteArray(Charsets.UTF_8))
        val encrypted = cipher.doFinal(plaintext)

        val output = ByteArrayOutputStream()
        DataOutputStream(output).use { data ->
            data.writeInt(MAGIC)
            data.writeInt(FORMAT_VERSION)
            data.writeInt(cipher.iv.size)
            data.write(cipher.iv)
            data.writeInt(encrypted.size)
            data.write(encrypted)
        }

        val target = File(directory, "$recordId.pvdata")
        val temporary = File(directory, "$recordId.tmp")
        FileOutputStream(temporary).use { stream ->
            stream.write(output.toByteArray())
            stream.fd.sync()
        }
        try {
            Files.move(
                temporary.toPath(),
                target.toPath(),
                StandardCopyOption.REPLACE_EXISTING,
                StandardCopyOption.ATOMIC_MOVE
            )
        } catch (_: Exception) {
            try {
                Files.move(temporary.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            } catch (fallbackError: Exception) {
                temporary.delete()
                throw java.io.IOException("No se pudo guardar el registro cifrado.", fallbackError)
            }
        }
    }

    @Synchronized
    @Throws(GeneralSecurityException::class, java.io.IOException::class)
    fun get(recordId: String): ByteArray? {
        validateRecordId(recordId)
        val file = File(directory, "$recordId.pvdata")
        if (!file.exists()) return null

        DataInputStream(FileInputStream(file)).use { input ->
            if (input.readInt() != MAGIC) throw java.io.IOException("Formato de registro no reconocido.")
            if (input.readInt() != FORMAT_VERSION) throw java.io.IOException("Versión de registro no compatible.")

            val ivLength = input.readInt()
            if (ivLength != GCM_IV_LENGTH) throw java.io.IOException("Vector de inicialización inválido.")
            val iv = ByteArray(ivLength)
            input.readFully(iv)

            val encryptedLength = input.readInt()
            if (encryptedLength < GCM_TAG_LENGTH_BYTES || encryptedLength > MAX_RECORD_BYTES || encryptedLength > file.length()) {
                throw java.io.IOException("Contenido cifrado inválido.")
            }
            val encrypted = ByteArray(encryptedLength)
            input.readFully(encrypted)
            if (input.read() != -1) throw java.io.IOException("El registro contiene datos sobrantes.")

            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getExistingKey(), GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
            cipher.updateAAD(recordId.toByteArray(Charsets.UTF_8))
            return cipher.doFinal(encrypted)
        }
    }

    @Synchronized
    @Throws(java.io.IOException::class)
    fun delete(recordId: String): Boolean {
        validateRecordId(recordId)
        val file = File(directory, "$recordId.pvdata")
        return !file.exists() || file.delete()
    }

    private fun getOrCreateKey(): SecretKey {
        val existing = loadKey()
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun getExistingKey(): SecretKey =
        loadKey() ?: throw GeneralSecurityException("La clave local de ProVenta no existe; no se puede descifrar.")

    private fun loadKey(): SecretKey? {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        return (keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry)?.secretKey
    }

    private fun validateRecordId(recordId: String) {
        require(recordId.matches(Regex("[A-Za-z0-9_-]{1,80}"))) {
            "Identificador de registro no válido."
        }
    }

    private companion object {
        const val DIRECTORY_NAME = "secure_records"
        const val KEY_ALIAS = "proventa_local_aes_v1"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val MAGIC = 0x50564431 // PVD1
        const val FORMAT_VERSION = 1
        const val GCM_IV_LENGTH = 12
        const val GCM_TAG_LENGTH_BITS = 128
        const val GCM_TAG_LENGTH_BYTES = GCM_TAG_LENGTH_BITS / 8
        const val MAX_RECORD_BYTES = 32 * 1024 * 1024
    }
}
