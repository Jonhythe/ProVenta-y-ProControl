package com.proventa.app.data.receipts

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.util.Base64

data class GoodsDispatchQrProgress(
    val token: String,
    val receivedFrames: Int,
    val totalFrames: Int,
    val completeDocument: String?
)

/**
 * Reassembles the PCQ1/T QR frames emitted by ProControl's local QR encoder.
 * Frames are transport only; the reconstructed JSON must still pass the
 * Ed25519 GoodsDispatchManifestVerifier before it is trusted.
 */
class GoodsDispatchQrAssembler {
    private var activeToken: String? = null
    private var expectedFrames: Int = 0
    private val chunks = HashMap<Int, ByteArray>()

    @Synchronized
    fun add(frame: String): GoodsDispatchQrProgress {
        val fields = frame.split('|', limit = 5)
        require(fields.size == 5 && fields[0] == "PCQ1" && fields[1] == "T") {
            "Este QR no es un fragmento de despacho ProControl."
        }
        val token = fields[2]
        require(token.matches(Regex("[A-Za-z0-9]{8}"))) {
            "El identificador de la secuencia QR no es válido."
        }
        val sequence = fields[3].split('/', limit = 2)
        require(sequence.size == 2 &&
            sequence[0].matches(Regex("[0-9]{2}")) &&
            sequence[1].matches(Regex("[0-9]{2}"))) {
            "El número de fragmento QR no tiene un formato válido."
        }
        val index = sequence[0].toInt()
        val total = sequence[1].toInt()
        require(total in 1..99 && index in 1..total) {
            "El fragmento QR está fuera de la secuencia permitida."
        }
        val chunk = decodeBase64Url(fields[4])
        require(chunk.isNotEmpty() && chunk.size <= CHUNK_BYTES) {
            "El fragmento QR contiene una cantidad de datos no válida."
        }
        if (index < total) require(chunk.size == CHUNK_BYTES) {
            "Un fragmento intermedio QR está incompleto."
        }

        if (activeToken != token) {
            reset()
            activeToken = token
            expectedFrames = total
        } else {
            require(expectedFrames == total) {
                "Los fragmentos QR pertenecen a secuencias incompatibles."
            }
        }

        val previous = chunks[index]
        if (previous != null) {
            require(previous.contentEquals(chunk)) {
                "Se recibió contenido distinto para un fragmento QR repetido."
            }
        } else {
            chunks[index] = chunk
        }

        if (chunks.size != expectedFrames) {
            return GoodsDispatchQrProgress(token, chunks.size, expectedFrames, null)
        }

        val output = ByteArrayOutputStream()
        for (part in 1..expectedFrames) {
            val bytes = chunks[part]
                ?: throw IllegalStateException("Falta el fragmento QR " + part + ".")
            output.write(bytes)
        }
        val complete = decodeUtf8(output.toByteArray())
        val result = GoodsDispatchQrProgress(token, expectedFrames, expectedFrames, complete)
        reset()
        return result
    }

    @Synchronized
    fun reset() {
        activeToken = null
        expectedFrames = 0
        chunks.clear()
    }

    @Synchronized
    fun currentProgress(): Pair<Int, Int>? =
        activeToken?.let { chunks.size to expectedFrames }

    private fun decodeBase64Url(value: String): ByteArray {
        require(value.isNotBlank() && value.matches(Regex("[A-Za-z0-9_-]+"))) {
            "La codificación de un fragmento QR no es válida."
        }
        return try {
            Base64.getUrlDecoder().decode(value)
        } catch (_: IllegalArgumentException) {
            throw IllegalArgumentException("No se pudo descodificar un fragmento QR.")
        }
    }

    private fun decodeUtf8(bytes: ByteArray): String {
        require(bytes.isNotEmpty() && bytes.size <= MAX_DOCUMENT_BYTES) {
            "El manifiesto reconstruido está vacío o supera el tamaño permitido."
        }
        return try {
            StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes))
                .toString()
        } catch (_: Exception) {
            throw IllegalArgumentException("El manifiesto QR no contiene texto UTF-8 válido.")
        }
    }

    private companion object {
        const val CHUNK_BYTES = 40
        const val MAX_DOCUMENT_BYTES = 8192
    }
}
