package com.proventa.app.security

import android.content.Context
import android.util.Base64
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.MGF1ParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import java.security.spec.X509EncodedKeySpec
import java.time.Instant
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class VerifiedInventorySnapshot(
    val packageId: String,
    val installationId: String,
    val authorizationId: String,
    val deviceId: String,
    val posId: String,
    val posName: String,
    val payloadHash: String,
    val payloadJson: String,
    val inventoryCount: Int
)

/**
 * Verifies and decrypts ProControl's procontrol.device-data-package v1.
 * No inventory is persisted until the caller has accepted this verified result.
 */
class DeviceDataPackageDecryptor(context: Context) {
    private val enrollment = DeviceEnrollmentRequestFactory(context.applicationContext)
    private val keyManager = DeviceKeyManager(context.applicationContext)
    private val provider = BouncyCastleProvider()

    fun decrypt(
        envelopeJson: String,
        expectedPosId: String? = null,
        nowMillis: Long = System.currentTimeMillis()
    ): VerifiedInventorySnapshot {
        require(envelopeJson.toByteArray(StandardCharsets.UTF_8).size <= MAX_ENVELOPE_BYTES) {
            "El paquete cifrado supera el tamaño permitido."
        }
        val authorization = enrollment.trustedInstallationAuthorization(nowMillis)
            ?: throw IllegalStateException("Este teléfono no tiene una instalación ProControl vinculada.")
        val keys = keyManager.getOrCreate()
        return decryptWithMaterial(envelopeJson, authorization, keys, expectedPosId, nowMillis)
    }

    internal fun decryptWithMaterial(
        envelopeJson: String,
        authorization: VerifiedDeviceAuthorization,
        keys: DeviceKeyMaterial,
        expectedPosId: String? = null,
        nowMillis: Long = System.currentTimeMillis()
    ): VerifiedInventorySnapshot {
        require(envelopeJson.toByteArray(StandardCharsets.UTF_8).size <= MAX_ENVELOPE_BYTES) {
            "El paquete cifrado supera el tamaño permitido."
        }
        val envelope = JSONObject(envelopeJson)

        require(envelope.optString("format") == FORMAT && envelope.optInt("version") == 1) {
            "Formato de paquete ProVenta no compatible."
        }
        require(envelope.optString("algorithm") == ALGORITHM) { "Algoritmos del paquete no compatibles." }
        val packageId = envelope.optString("packageId")
        val installationId = envelope.optString("installationId")
        val authorizationId = envelope.optString("authorizationId")
        val deviceId = envelope.optString("deviceId")
        val posId = envelope.optString("posId")
        val type = envelope.optString("type")
        val createdAt = envelope.optString("createdAt")
        val expiresAt = envelope.optLong("expiresAt", -1L)
        val payloadHash = envelope.optString("payloadHash")
        require(packageId.matches(Regex("[A-Za-z0-9_-]{8,100}"))) { "Identificador de paquete inválido." }
        require(installationId == authorization.installationId) { "El paquete pertenece a otra instalación ProControl." }
        require(authorizationId == authorization.authorizationId) { "El paquete no corresponde a la autorización de este teléfono." }
        require(deviceId == keys.deviceId) { "El paquete está cifrado para otro teléfono." }
        require(posId.matches(Regex("[A-Za-z0-9:_-]{1,160}"))) { "Punto de venta del paquete inválido." }
        if (authorization.version < 5) {
            require(!authorization.authorizedPosId.isNullOrBlank() && posId == authorization.authorizedPosId) {
                "El paquete pertenece a un punto de venta distinto de la autorización anterior de este teléfono."
            }
        }
        require(expectedPosId != null) {
            "Antes de importar el inventario debes importar el permiso de turno firmado para el POS de destino."
        }
        if (expectedPosId != null) require(posId == expectedPosId) { "El paquete pertenece a otro punto de venta." }
        require(type == "inventory_snapshot") { "Este tipo de paquete todavía no se puede importar." }
        require(expiresAt > nowMillis) { "El paquete de inventario ha caducado." }
        require(runCatching { Instant.parse(createdAt) }.isSuccess) { "Fecha del paquete inválida." }
        require(payloadHash.matches(Regex("[a-f0-9]{64}"))) { "Hash de contenido inválido." }

        val pinnedSigner = parseEd25519PublicKey(authorization.desktopPublicKeyPem)
        val envelopeSigner = parseEd25519PublicKey(envelope.optString("signerPublicKey"))
        require(MessageDigest.isEqual(pinnedSigner.encoded, envelopeSigner.encoded)) {
            "La firma del paquete no pertenece a la instalación vinculada."
        }

        val signatureObject = envelope.optJSONObject("signature")
            ?: throw IllegalArgumentException("El paquete no contiene firma digital.")
        require(signatureObject.optString("algorithm") == "Ed25519") { "Firma de paquete no compatible." }
        val signatureBytes = Base64.decode(signatureObject.getString("value"), Base64.DEFAULT)
        val signatureVerifier = Signature.getInstance("Ed25519", provider)
        signatureVerifier.initVerify(pinnedSigner)
        signatureVerifier.update(
            CanonicalJson.stringify(CanonicalJson.withoutSignature(envelope))
                .toByteArray(StandardCharsets.UTF_8)
        )
        require(signatureVerifier.verify(signatureBytes)) {
            "La firma de ProControl no es válida; el paquete pudo ser alterado."
        }

        val encryption = envelope.optJSONObject("encryption")
            ?: throw IllegalArgumentException("Faltan los parámetros de cifrado.")
        require(encryption.optString("keyWrap") == "RSA-OAEP-SHA256") { "Formato de clave envuelta no compatible." }
        require(encryption.optString("contentCipher") == "AES-256-GCM") { "Cifrado de contenido no compatible." }

        val wrappedKey = Base64.decode(encryption.getString("wrappedKey"), Base64.DEFAULT)
        val iv = Base64.decode(encryption.getString("iv"), Base64.DEFAULT)
        val tag = Base64.decode(encryption.getString("tag"), Base64.DEFAULT)
        val ciphertext = Base64.decode(envelope.getString("ciphertext"), Base64.DEFAULT)
        require(iv.size == GCM_IV_BYTES && tag.size == GCM_TAG_BYTES) { "Parámetros AES-GCM inválidos." }
        require(ciphertext.size <= MAX_CONTENT_BYTES) { "El contenido del paquete es demasiado grande." }

        val contentKey = try {
            val rsa = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", provider)
            rsa.init(
                Cipher.DECRYPT_MODE,
                keys.encryptionPrivateKey,
                OAEPParameterSpec(
                    "SHA-256",
                    "MGF1",
                    MGF1ParameterSpec.SHA256,
                    PSource.PSpecified.DEFAULT
                )
            )
            rsa.doFinal(wrappedKey)
        } catch (_: Exception) {
            throw SecurityException("No se pudo abrir la clave del paquete para este teléfono.")
        }

        val plaintext = try {
            require(contentKey.size == AES_KEY_BYTES) { "La clave AES del paquete no tiene 256 bits." }
            val header = JSONObject()
            HEADER_FIELDS.forEach { field -> header.put(field, envelope.get(field)) }
            val aes = Cipher.getInstance("AES/GCM/NoPadding")
            aes.init(
                Cipher.DECRYPT_MODE,
                SecretKeySpec(contentKey, "AES"),
                GCMParameterSpec(GCM_TAG_BITS, iv)
            )
            aes.updateAAD(CanonicalJson.stringify(header).toByteArray(StandardCharsets.UTF_8))
            aes.doFinal(ciphertext + tag)
        } catch (_: Exception) {
            throw SecurityException("El contenido no superó la verificación AES-GCM.")
        } finally {
            contentKey.fill(0)
        }

        try {
            val actualHash = sha256(plaintext)
            require(actualHash == payloadHash) { "El hash del inventario descifrado no coincide." }
            val payloadJson = String(plaintext, StandardCharsets.UTF_8)
            val payload = JSONObject(payloadJson)
            require(payload.optString("schema") == "proventa.inventory-snapshot" &&
                payload.optInt("schemaVersion") == 1) {
                "Versión del snapshot de inventario no compatible."
            }
            require(payload.optString("installationId") == installationId &&
                payload.optString("posId") == posId) {
                "El contenido no coincide con el encabezado firmado."
            }
            val posName = payload.optString("posName").trim().take(160)
            val inventory = payload.optJSONArray("inventory")
                ?: throw IllegalArgumentException("El snapshot no contiene inventario.")
            require(inventory.length() <= MAX_PRODUCTS) { "El snapshot contiene demasiados productos." }
            val productIds = HashSet<String>()
            for (index in 0 until inventory.length()) {
                val row = inventory.getJSONObject(index)
                val productId = row.optString("productId")
                require(productId.matches(Regex("[A-Za-z0-9:_-]{1,160}")) && productIds.add(productId)) {
                    "El snapshot contiene identificadores de producto inválidos o duplicados."
                }
                require(row.optString("name").isNotBlank() && row.optString("unit").isNotBlank()) {
                    "El snapshot contiene un producto sin nombre o unidad."
                }
                val quantity = row.optDouble("qty", Double.NaN)
                require(quantity.isFinite() && quantity >= 0.0) { "El snapshot contiene existencias inválidas." }
            }
            return VerifiedInventorySnapshot(
                packageId = packageId,
                installationId = installationId,
                authorizationId = authorizationId,
                deviceId = deviceId,
                posId = posId,
                posName = posName,
                payloadHash = payloadHash,
                payloadJson = payloadJson,
                inventoryCount = inventory.length()
            )
        } finally {
            plaintext.fill(0)
        }
    }

    private fun parseEd25519PublicKey(pem: String): java.security.PublicKey {
        require(pem.length in 100..8192 && pem.contains("BEGIN PUBLIC KEY")) {
            "Clave pública de firma inválida."
        }
        val base64 = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .filterNot { it.isWhitespace() }
        val der = Base64.decode(base64, Base64.DEFAULT)
        return KeyFactory.getInstance("Ed25519", provider).generatePublic(X509EncodedKeySpec(der))
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    private companion object {
        const val FORMAT = "procontrol.device-data-package"
        const val ALGORITHM = "RSA-OAEP-256+A256GCM"
        const val MAX_ENVELOPE_BYTES = 17 * 1024 * 1024
        const val MAX_CONTENT_BYTES = 16 * 1024 * 1024
        const val MAX_PRODUCTS = 100_000
        const val AES_KEY_BYTES = 32
        const val GCM_IV_BYTES = 12
        const val GCM_TAG_BYTES = 16
        const val GCM_TAG_BITS = 128
        val HEADER_FIELDS = listOf(
            "format", "version", "algorithm", "packageId", "installationId",
            "authorizationId", "deviceId", "posId", "type", "createdAt",
            "expiresAt", "payloadHash", "signerPublicKey"
        )
    }
}
