package com.proventa.app.security

import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal

/**
 * Stable JSON compatible with ProControl's stableJson(): object keys are sorted
 * recursively, arrays retain order, and strings use JSON.stringify-style escapes.
 */
object CanonicalJson {
    fun stringify(value: Any?): String = when {
        value == null || value === JSONObject.NULL -> "null"
        value is JSONObject -> {
            val keys = value.keys().asSequence().toList().sorted()
            keys.joinToString(prefix = "{", postfix = "}", separator = ",") { key ->
                quote(key) + ":" + stringify(value.get(key))
            }
        }
        value is JSONArray -> (0 until value.length()).joinToString(
            prefix = "[", postfix = "]", separator = ","
        ) { index -> stringify(value.get(index)) }
        value is String -> quote(value)
        value is Boolean -> if (value) "true" else "false"
        value is Number -> normalizeNumber(value)
        else -> throw IllegalArgumentException("Tipo no serializable en JSON canónico: \${value.javaClass.name}")
    }

    fun withoutSignature(document: JSONObject): JSONObject {
        val copy = JSONObject(document.toString())
        copy.remove("signature")
        return copy
    }

    private fun normalizeNumber(number: Number): String {
        val decimal = try {
            BigDecimal(number.toString()).stripTrailingZeros()
        } catch (_: NumberFormatException) {
            throw IllegalArgumentException("Número no válido en JSON canónico.")
        }
        return if (decimal.compareTo(BigDecimal.ZERO) == 0) "0" else decimal.toPlainString()
    }

    private fun quote(value: String): String {
        val out = StringBuilder(value.length + 2).append('"')
        value.forEach { char ->
            when (char) {
                '"' -> out.append("\\\"")
                '\\' -> out.append("\\\\")
                '\b' -> out.append("\\b")
                '\u000C' -> out.append("\\f")
                '\n' -> out.append("\\n")
                '\r' -> out.append("\\r")
                '\t' -> out.append("\\t")
                else -> if (char.code < 0x20) {
                    out.append("\\u").append(char.code.toString(16).padStart(4, '0'))
                } else {
                    out.append(char)
                }
            }
        }
        return out.append('"').toString()
    }
}
