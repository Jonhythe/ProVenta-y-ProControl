package com.proventa.app.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.proventa.app.data.dao.ProVentaDao
import com.proventa.app.data.entities.GoodsReceiptEntity
import com.proventa.app.data.entities.InventorySnapshotEntity
import com.proventa.app.data.entities.OutboxOperationEntity
import com.proventa.app.data.entities.OutboxPackageEntity
import com.proventa.app.data.entities.ProductEntity
import com.proventa.app.data.entities.SaleCurrencyTotalEntity
import com.proventa.app.data.entities.ShiftPermitEntity
import com.proventa.app.data.entities.ShiftCloseDraftEntity
import com.proventa.app.data.entities.SaleEntity
import com.proventa.app.data.entities.SaleLineEntity
import com.proventa.app.data.entities.SalePaymentEntity

@Database(
    entities = [
        ProductEntity::class,
        InventorySnapshotEntity::class,
        ShiftPermitEntity::class,
        SaleEntity::class,
        SaleCurrencyTotalEntity::class,
        SaleLineEntity::class,
        SalePaymentEntity::class,
        GoodsReceiptEntity::class,
        OutboxOperationEntity::class,
        OutboxPackageEntity::class,
        ShiftCloseDraftEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class ProVentaDatabase : RoomDatabase() {
    abstract fun proVentaDao(): ProVentaDao
}
