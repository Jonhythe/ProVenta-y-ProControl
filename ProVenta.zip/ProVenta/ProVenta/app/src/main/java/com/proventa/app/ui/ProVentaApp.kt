package com.proventa.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.proventa.app.security.DeviceEnrollmentRequestFactory
import com.proventa.app.security.DeviceKeyManager
import com.proventa.app.ui.screens.ActivationScreen
import com.proventa.app.ui.screens.DashboardScreen
import com.proventa.app.ui.screens.InventoryScreen
import com.proventa.app.ui.screens.GoodsReceiptsScreen
import com.proventa.app.ui.screens.ModuleScreen
import com.proventa.app.ui.screens.SalesScreen
import com.proventa.app.ui.screens.ClosingScreen
import com.proventa.app.ui.theme.TextSecondary
import com.proventa.app.ui.theme.GoldSoft
import com.proventa.app.ui.theme.Navy
import com.proventa.app.ui.theme.AppBackground
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

@Composable
fun ProVentaApp() {
    val context = LocalContext.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    var startupComplete by remember { mutableStateOf(false) }
    var installationLinked by remember { mutableStateOf(false) }
    var renewalMode by remember { mutableStateOf(false) }
    var startupError by remember { mutableStateOf<String?>(null) }
    var activationRefresh by remember { mutableStateOf(0) }

    LaunchedEffect(activationRefresh) {
        startupComplete = false
        startupError = null
        try {
            val state = withContext(Dispatchers.IO) {
                val enrollment = DeviceEnrollmentRequestFactory(context.applicationContext)
                val hasSavedAuthorization = enrollment.hasStoredAuthorizationRecord()
                val authorization = enrollment.trustedInstallationAuthorization()
                val deviceId = DeviceKeyManager(context.applicationContext).getOrCreate().deviceId
                val active = authorization != null && authorization.permanent &&
                    authorization.version == 6 && authorization.authorizedPosId.isNullOrBlank() &&
                    authorization.deviceId == deviceId
                active to hasSavedAuthorization
            }
            installationLinked = state.first
            renewalMode = !state.first && state.second
        } catch (error: Exception) {
            startupError = error.message ?: "No se pudo abrir el almacenamiento cifrado."
        } finally {
            startupComplete = true
        }
    }

    LaunchedEffect(installationLinked, activationRefresh) {
        if (!installationLinked) return@LaunchedEffect
        val enrollment = DeviceEnrollmentRequestFactory(context.applicationContext)
        while (isActive) {
            val expiresAt = withContext(Dispatchers.IO) { enrollment.monthlyAccessExpiryMillis() }
            if (expiresAt == null) {
                installationLinked = false
                renewalMode = withContext(Dispatchers.IO) { enrollment.hasStoredAuthorizationRecord() }
                break
            }
            val remaining = expiresAt - System.currentTimeMillis()
            if (remaining <= 0L) {
                installationLinked = false
                renewalMode = withContext(Dispatchers.IO) { enrollment.hasStoredAuthorizationRecord() }
                break
            }
            delay(minOf(30_000L, remaining.coerceAtLeast(1L)))
            val stillActive = withContext(Dispatchers.IO) {
                enrollment.trustedInstallationAuthorization() != null
            }
            if (!stillActive) {
                installationLinked = false
                renewalMode = withContext(Dispatchers.IO) { enrollment.hasStoredAuthorizationRecord() }
                break
            }
        }
    }

    if (!startupComplete) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else if (startupError != null) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("ProVenta", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Almacenamiento protegido", style = MaterialTheme.typography.titleMedium)
            Text(startupError ?: "", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            Text(
                "No se creó una base nueva para evitar sobrescribir datos cifrados existentes.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
        }
    } else if (!installationLinked) {
        ActivationScreen(
            renewalMode = renewalMode,
            onActivated = {
                startupComplete = false
                installationLinked = false
                activationRefresh++
            }
        )
    } else {
        Scaffold(
            containerColor = AppBackground,
            topBar = {
                val pageTitle = when (currentRoute) {
                    AppDestination.SALES.route -> "Ventas"
                    AppDestination.RECEIPTS.route -> "Entradas"
                    AppDestination.INVENTORY.route -> "Inventario"
                    AppDestination.CLOSING.route -> "Cierre de turno"
                    else -> "Resumen del negocio"
                }
                Surface(color = Navy, shadowElevation = 3.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            Text(
                                "PROVENTA",
                                color = GoldSoft,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.2.sp
                            )
                            Text(
                                pageTitle,
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            "LOCAL",
                            color = Color.White.copy(alpha = 0.78f),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = Color.White,
                    contentColor = Navy,
                    tonalElevation = 3.dp
                ) {
                    AppDestination.entries.forEach { destination ->
                        NavigationBarItem(
                            selected = currentRoute == destination.route,
                            onClick = {
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { androidx.compose.material3.Icon(destination.icon, null) },
                            label = { Text(destination.label, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Navy,
                                selectedTextColor = Navy,
                                indicatorColor = Color(0xFFE9EFF8),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = AppDestination.HOME.route,
                modifier = Modifier.padding(padding)
            ) {
                composable(AppDestination.HOME.route) { DashboardScreen() }
                composable(AppDestination.SALES.route) {
                    SalesScreen()
                }
                composable(AppDestination.RECEIPTS.route) {
                    GoodsReceiptsScreen()
                }
                composable(AppDestination.INVENTORY.route) { InventoryScreen() }
                composable(AppDestination.CLOSING.route) {
                    ClosingScreen()
                }
            }
        }
    }
}
