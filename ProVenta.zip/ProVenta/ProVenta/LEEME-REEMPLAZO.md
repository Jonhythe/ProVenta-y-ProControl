# LEEME — ProVenta Compose r7

1. Extrae el ZIP directamente en la raíz del proyecto ProVenta.
2. Conserva las rutas relativas y acepta reemplazar los dos tests. Se agregan el host debug y su manifest.
3. No reemplaces Gradle, `src/main/AndroidManifest.xml`, pantallas de producción ni archivos de seguridad.

Desde la raíz ejecuta primero las dos clases por separado:

```powershell
.\gradlew.bat --no-daemon :app:connectedDebugAndroidTest "-Pandroid.testInstrumentationRunnerArguments.class=com.proventa.app.ui.CompactPhoneLayoutTest"
.\gradlew.bat --no-daemon :app:connectedDebugAndroidTest "-Pandroid.testInstrumentationRunnerArguments.class=com.proventa.app.ui.CompactInventoryScreenTest"
```

Si ambas pasan, ejecuta toda la batería:

```powershell
.\gradlew.bat --no-daemon :app:connectedDebugAndroidTest
```

Si el test vuelve a fallar por ausencia de jerarquía, comparte el stack trace completo y `adb logcat -d -t 2500` inmediatamente después del fallo. No se debe ocultar el timeout ni desactivar las aserciones.
