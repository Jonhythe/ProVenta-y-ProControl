[CmdletBinding()]
param(
    [string]$SdkRoot = $(if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } elseif ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' })
)

$ErrorActionPreference = 'Stop'

function Stop-WithMessage([string]$Message) {
    Write-Host "ERROR: $Message" -ForegroundColor Red
    exit 1
}

New-Item -ItemType Directory -Path $SdkRoot -Force | Out-Null
$sdkManagerCandidates = @(
    (Join-Path $SdkRoot 'cmdline-tools\latest\bin\sdkmanager.bat'),
    (Join-Path $SdkRoot 'cmdline-tools\bin\sdkmanager.bat')
)
$sdkManager = $sdkManagerCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

if (-not $sdkManager) {
    Stop-WithMessage "No se encontró sdkmanager.bat. Descarga Android SDK Command-line Tools para Windows desde https://developer.android.com/studio y coloca su contenido en '$SdkRoot\cmdline-tools\latest\'. Debe existir '$SdkRoot\cmdline-tools\latest\bin\sdkmanager.bat'. Después vuelve a ejecutar este script."
}

[Environment]::SetEnvironmentVariable('ANDROID_SDK_ROOT', $SdkRoot, 'User')
[Environment]::SetEnvironmentVariable('ANDROID_HOME', $SdkRoot, 'User')
$env:ANDROID_SDK_ROOT = $SdkRoot
$env:ANDROID_HOME = $SdkRoot
$env:PATH = "$(Join-Path $SdkRoot 'platform-tools');$(Split-Path -Parent $sdkManager);$env:PATH"

Write-Host 'Primero acepta las licencias del SDK. Responde y cuando sdkmanager lo solicite.' -ForegroundColor Cyan
& $sdkManager "--sdk_root=$SdkRoot" '--licenses'
if ($LASTEXITCODE -ne 0) {
    Stop-WithMessage 'No se pudieron aceptar las licencias del Android SDK.'
}

Write-Host 'Instalando Android SDK Platform 36, Build Tools 36.0.0 y Platform-Tools...' -ForegroundColor Cyan
& $sdkManager "--sdk_root=$SdkRoot" 'platforms;android-36' 'build-tools;36.0.0' 'platform-tools'
if ($LASTEXITCODE -ne 0) {
    Stop-WithMessage 'sdkmanager no pudo instalar todos los paquetes requeridos.'
}

$required = @(
    (Join-Path $SdkRoot 'platforms\android-36\android.jar'),
    (Join-Path $SdkRoot 'platform-tools\adb.exe'),
    (Join-Path $SdkRoot 'build-tools\36.0.0\aapt2.exe')
)
$missing = @($required | Where-Object { -not (Test-Path -LiteralPath $_) })
if ($missing.Count -gt 0) {
    Stop-WithMessage "La instalación terminó, pero faltan estos archivos: $($missing -join ', ')"
}

Write-Host "Android SDK preparado correctamente en: $SdkRoot" -ForegroundColor Green
Write-Host 'Cierra y vuelve a abrir PowerShell para que las variables de entorno de usuario se apliquen en otras sesiones.'
