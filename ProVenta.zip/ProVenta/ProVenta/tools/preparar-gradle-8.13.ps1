[CmdletBinding()]
param(
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'ProVenta\Tools'),
    [switch]$ForceDownload
)

$ErrorActionPreference = 'Stop'
$GradleVersion = '8.13'
$ArchiveName = "gradle-$GradleVersion-bin.zip"
$ExpectedSha256 = '20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78'
$InstallDirectory = Join-Path $InstallRoot "gradle-$GradleVersion"
$GradleExecutable = Join-Path $InstallDirectory 'bin\gradle.bat'

function Stop-WithMessage([string]$Message) {
    throw $Message
}

if (-not $ForceDownload -and (Test-Path -LiteralPath $GradleExecutable)) {
    $versionOutput = (& $GradleExecutable --version 2>&1 | Out-String)
    if ($LASTEXITCODE -eq 0 -and $versionOutput -match 'Gradle 8\.13') {
        Write-Host "Gradle $GradleVersion ya está preparado en: $InstallDirectory" -ForegroundColor Green
        Write-Output $GradleExecutable
        return
    }
}

if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
    Stop-WithMessage 'Windows no proporcionó LOCALAPPDATA. Ejecuta el script desde una sesión normal de usuario.'
}

New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
$downloadPath = Join-Path $env:TEMP $ArchiveName
$temporaryPath = "$downloadPath.download"
$urls = @(
    "https://services.gradle.org/distributions/$ArchiveName",
    "https://downloads.gradle.org/distributions/$ArchiveName"
)

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$downloaded = $false
$lastError = $null

foreach ($url in $urls) {
    try {
        Write-Host "Descargando Gradle $GradleVersion desde el servidor oficial..." -ForegroundColor Cyan
        Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
        Invoke-WebRequest -Uri $url -OutFile $temporaryPath -UseBasicParsing

        if (-not (Test-Path -LiteralPath $temporaryPath) -or (Get-Item -LiteralPath $temporaryPath).Length -lt 50MB) {
            throw 'La descarga está incompleta o el servidor no entregó el archivo ZIP esperado.'
        }

        $actualSha256 = (Get-FileHash -LiteralPath $temporaryPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualSha256 -ne $ExpectedSha256) {
            throw "La suma SHA-256 no coincide. Esperada: $ExpectedSha256. Recibida: $actualSha256."
        }

        Move-Item -LiteralPath $temporaryPath -Destination $downloadPath -Force
        $downloaded = $true
        break
    }
    catch {
        $lastError = $_.Exception.Message
        Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
        Write-Warning "No se pudo completar la descarga desde $url : $lastError"
    }
}

if (-not $downloaded) {
    Stop-WithMessage "No se pudo descargar Gradle $GradleVersion. Comprueba la conexión y vuelve a ejecutar. Detalle: $lastError"
}

try {
    Write-Host 'Verificación SHA-256 correcta. Instalando Gradle en el perfil del usuario...' -ForegroundColor Cyan
    Expand-Archive -LiteralPath $downloadPath -DestinationPath $InstallRoot -Force
}
catch {
    Stop-WithMessage "No se pudo extraer Gradle: $($_.Exception.Message)"
}
finally {
    Remove-Item -LiteralPath $downloadPath -Force -ErrorAction SilentlyContinue
}

if (-not (Test-Path -LiteralPath $GradleExecutable)) {
    Stop-WithMessage "La extracción terminó, pero no apareció $GradleExecutable."
}

$installedVersion = (& $GradleExecutable --version 2>&1 | Out-String)
if ($LASTEXITCODE -ne 0 -or $installedVersion -notmatch 'Gradle 8\.13') {
    Stop-WithMessage 'La comprobación final de Gradle 8.13 no fue satisfactoria.'
}

Write-Host "Gradle $GradleVersion instalado y verificado: $InstallDirectory" -ForegroundColor Green
Write-Output $GradleExecutable
