﻿[CmdletBinding()]
param(
    [switch]$RunAndroidTests
)

# Strict handling for PowerShell cmdlets. Native process stderr is handled
# explicitly so Java/Gradle diagnostics do not abort the script by themselves.
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false

function Stop-WithMessage([string]$Message) {
    Write-Host "ERROR: $Message" -ForegroundColor Red
    # A terminating error stops this script but leaves an interactive PowerShell
    # window open for the user. 'exit 1' could close the whole PowerShell host.
    throw "PROVENTA_ERROR: $Message"
}

$ProjectRoot = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'settings.gradle.kts'))) {
    Stop-WithMessage "No se encontró settings.gradle.kts en la raíz calculada: $ProjectRoot. Comprueba que el script esté dentro de la carpeta tools del proyecto ProVenta."
}
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'app'))) {
    Stop-WithMessage "No se encontró la carpeta app en: $ProjectRoot"
}
Set-Location -LiteralPath $ProjectRoot

function Invoke-NativeCapture {
    param(
        [Parameter(Mandatory = $true)]
        [string]$FilePath,
        [string]$Arguments = ''
    )

    if (-not (Test-Path -LiteralPath $FilePath)) {
        throw "No existe el ejecutable indicado: $FilePath"
    }

    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $extension = [System.IO.Path]::GetExtension($FilePath).ToLowerInvariant()

    if ($extension -eq '.bat' -or $extension -eq '.cmd') {
        $commandProcessor = $env:ComSpec
        if ([string]::IsNullOrWhiteSpace($commandProcessor)) {
            $commandProcessor = 'cmd.exe'
        }
        $startInfo.FileName = $commandProcessor
        $commandLine = '"' + $FilePath + '"'
        if (-not [string]::IsNullOrWhiteSpace($Arguments)) {
            $commandLine += ' ' + $Arguments
        }
        $startInfo.Arguments = '/d /s /c "' + $commandLine + '"'
    }
    else {
        $startInfo.FileName = $FilePath
        $startInfo.Arguments = $Arguments
    }

    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    try {
        if (-not $process.Start()) {
            throw "No se pudo iniciar el proceso: $FilePath"
        }

        # Read both streams asynchronously to avoid blocking if either pipe fills.
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $process.WaitForExit()
        $stdout = $stdoutTask.GetAwaiter().GetResult()
        $stderr = $stderrTask.GetAwaiter().GetResult()
        $parts = @($stdout, $stderr) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

        return [PSCustomObject]@{
            ExitCode = $process.ExitCode
            Output   = ($parts -join [Environment]::NewLine).Trim()
        }
    }
    finally {
        $process.Dispose()
    }
}

function Resolve-Java {
    $javaExe = $null

    if (-not [string]::IsNullOrWhiteSpace($env:JAVA_HOME)) {
        $javaHomeExe = Join-Path $env:JAVA_HOME 'bin\java.exe'
        if (Test-Path -LiteralPath $javaHomeExe) {
            $javaExe = $javaHomeExe
        }
    }

    if (-not $javaExe) {
        $javaCommand = Get-Command java -ErrorAction SilentlyContinue
        if ($javaCommand -and $javaCommand.Source) {
            $javaExe = $javaCommand.Source
        }
    }

    if (-not $javaExe) {
        Stop-WithMessage 'No se encontró Java. Instala JDK 17 y configura JAVA_HOME o PATH.'
    }

    try {
        $javaResult = Invoke-NativeCapture -FilePath $javaExe -Arguments '-version'
    }
    catch {
        Stop-WithMessage "No se pudo ejecutar Java: $($_.Exception.Message)"
    }

    $versionOutput = $javaResult.Output
    if ($javaResult.ExitCode -ne 0 -or $versionOutput -notmatch '(?:version|openjdk)\s+"?(\d+)') {
        Write-Host $versionOutput
        Stop-WithMessage 'No se pudo identificar una versión Java funcional.'
    }

    $major = [int]$Matches[1]
    if ($major -ne 17) {
        Write-Host $versionOutput
        Stop-WithMessage "Este proyecto está preparado para JDK 17. Se detectó Java $major. Configura JAVA_HOME con la carpeta del JDK 17."
    }

    $javaBin = Split-Path -Parent $javaExe
    $javacExe = Join-Path $javaBin 'javac.exe'
    if (-not (Test-Path -LiteralPath $javacExe)) {
        Stop-WithMessage "Se encontró java.exe, pero no javac.exe en $javaBin. Se necesita un JDK 17 completo, no solamente un JRE."
    }
    $javacResult = Invoke-NativeCapture -FilePath $javacExe -Arguments '-version'
    if ($javacResult.ExitCode -ne 0 -or $javacResult.Output -notmatch 'javac\s+17(?:\.|$)') {
        Write-Host $javacResult.Output
        Stop-WithMessage 'El compilador javac debe ser de la misma versión mayor: JDK 17.'
    }

    # Ensure Gradle inherits the same JDK that was just validated.
    if ([string]::IsNullOrWhiteSpace($env:JAVA_HOME)) {
        $jdkHome = Split-Path -Parent $javaBin
        if (Test-Path -LiteralPath (Join-Path $jdkHome 'bin\javac.exe')) {
            $env:JAVA_HOME = $jdkHome
        }
    }

    Write-Host "JDK 17 detectado y javac validado: $javaExe" -ForegroundColor Green
}

function Resolve-AndroidSdk {
    $candidates = @(
        $env:ANDROID_SDK_ROOT,
        $env:ANDROID_HOME,
        (Join-Path $env:LOCALAPPDATA 'Android\Sdk')
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique

    foreach ($candidate in $candidates) {
        $platformJar = Join-Path $candidate 'platforms\android-36\android.jar'
        $adbExe = Join-Path $candidate 'platform-tools\adb.exe'
        $aaptExe = Join-Path $candidate 'build-tools\36.0.0\aapt.exe'
        if ((Test-Path -LiteralPath $platformJar) -and
            (Test-Path -LiteralPath $adbExe) -and
            (Test-Path -LiteralPath $aaptExe)) {
            $env:ANDROID_HOME = $candidate
            $env:ANDROID_SDK_ROOT = $candidate
            return $candidate
        }
    }

    Stop-WithMessage 'Falta algún componente del SDK: Android SDK Platform 36, Build-Tools 36.0.0 o Platform-Tools (ADB). Revisa la carpeta C:\Users\<usuario>\AppData\Local\Android\Sdk.'
}

function Resolve-Gradle {
    $candidates = @()
    $gradleCommand = Get-Command gradle -ErrorAction SilentlyContinue
    if ($gradleCommand -and $gradleCommand.Source) {
        $candidates += $gradleCommand.Source
    }

    $candidates += 'C:\Gradle\gradle-8.13\bin\gradle.bat'
    if (-not [string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
        $candidates += (Join-Path $env:USERPROFILE 'gradle\gradle-8.13\bin\gradle.bat')
    }

    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate)) {
            try {
                $result = Invoke-NativeCapture -FilePath $candidate -Arguments '--version'
                if ($result.ExitCode -eq 0 -and $result.Output -match 'Gradle 8\.13') {
                    return $candidate
                }
            }
            catch {
                # Continue to the next known Gradle location.
            }
        }
    }

    $preparer = Join-Path $PSScriptRoot 'preparar-gradle-8.13.ps1'
    if (Test-Path -LiteralPath $preparer) {
        try {
            $prepared = @(& $preparer)
            $gradlePath = $prepared |
                Where-Object { $_ -is [string] -and $_ -match 'gradle\.bat$' } |
                Select-Object -Last 1
            if ($gradlePath -and (Test-Path -LiteralPath $gradlePath)) {
                $result = Invoke-NativeCapture -FilePath $gradlePath -Arguments '--version'
                if ($result.ExitCode -eq 0 -and $result.Output -match 'Gradle 8\.13') {
                    return $gradlePath
                }
            }
        }
        catch {
            Stop-WithMessage "No se pudo preparar Gradle 8.13: $($_.Exception.Message)"
        }
    }

    Stop-WithMessage 'No se encontró Gradle 8.13. Se esperaba C:\Gradle\gradle-8.13\bin\gradle.bat o Gradle 8.13 en PATH.'
}

function Invoke-Gradle([string]$GradlePath, [string]$Task) {
    Write-Host "`n>>> Ejecutando tarea Gradle: $Task" -ForegroundColor Cyan

    # In Windows PowerShell 5.1 native stderr is exposed as ErrorRecord objects.
    # Temporarily use Continue and merge stderr into the live output stream so
    # normal Gradle warnings/errors do not abort before LASTEXITCODE is checked.
    $previousErrorActionPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $GradlePath --no-daemon --console=plain --stacktrace $Task 2>&1 |
            ForEach-Object { Write-Host $_ }
        $gradleExitCode = $LASTEXITCODE
    }
    catch {
        Stop-WithMessage "No se pudo iniciar Gradle para la tarea '$Task': $($_.Exception.Message)"
    }
    finally {
        $ErrorActionPreference = $previousErrorActionPreference
    }

    if ($null -eq $gradleExitCode -or $gradleExitCode -ne 0) {
        Stop-WithMessage "La tarea Gradle '$Task' falló. Código de salida: $gradleExitCode. Revisa el primer error de Gradle mostrado arriba."
    }
}

function Assert-AndroidDevice([string]$SdkRoot) {
    $adb = Join-Path $SdkRoot 'platform-tools\adb.exe'
    if (-not (Test-Path -LiteralPath $adb)) {
        Stop-WithMessage "No se encontró ADB: $adb"
    }

    $startResult = Invoke-NativeCapture -FilePath $adb -Arguments 'start-server'
    if ($startResult.Output) {
        Write-Host $startResult.Output
    }
    if ($startResult.ExitCode -ne 0) {
        Stop-WithMessage 'ADB no pudo iniciar el servidor. Comprueba Platform-Tools.'
    }

    $devicesResult = Invoke-NativeCapture -FilePath $adb -Arguments 'devices'
    if ($devicesResult.ExitCode -ne 0) {
        Write-Host $devicesResult.Output
        Stop-WithMessage 'ADB no pudo enumerar los dispositivos USB.'
    }

    $deviceLines = @($devicesResult.Output -split '\r?\n')
    $deviceRows = @($deviceLines | Where-Object { $_ -match '^\S+\s+(device|offline|unauthorized)\s*$' })
    $readyDevices = @($deviceRows | Where-Object { $_ -match '\sdevice\s*$' })

    if ($readyDevices.Count -eq 0) {
        Write-Host ($devicesResult.Output)
        Stop-WithMessage 'No hay un teléfono/emulador autorizado. Conecta el móvil por USB, activa Depuración USB y acepta la autorización RSA que aparece en el teléfono.'
    }

    Write-Host 'Dispositivo Android autorizado:' -ForegroundColor Green
    foreach ($device in $readyDevices) {
        Write-Host "  $device"
    }
}

# Validate all tools and expected project structure before starting a build.
Resolve-Java
$SdkRoot = Resolve-AndroidSdk
$GradlePath = Resolve-Gradle

$gradleVersion = Invoke-NativeCapture -FilePath $GradlePath -Arguments '--version'
if ($gradleVersion.ExitCode -ne 0 -or $gradleVersion.Output -notmatch 'Gradle 8\.13') {
    Write-Host $gradleVersion.Output
    Stop-WithMessage 'El proyecto debe ejecutarse con Gradle 8.13.'
}

Write-Host "Raíz del proyecto: $ProjectRoot" -ForegroundColor Green
Write-Host "Android SDK: $SdkRoot" -ForegroundColor Green
Write-Host "Gradle: $GradlePath" -ForegroundColor Green

Invoke-Gradle $GradlePath ':app:assembleDebug'
Invoke-Gradle $GradlePath ':app:testDebugUnitTest'

if ($RunAndroidTests) {
    Assert-AndroidDevice $SdkRoot

    $nodeCommand = Get-Command node -ErrorAction SilentlyContinue
    if (-not $nodeCommand -or -not $nodeCommand.Source) {
        Stop-WithMessage 'Las pruebas instrumentadas requieren Node.js 22 o superior.'
    }
    $nodeResult = Invoke-NativeCapture -FilePath $nodeCommand.Source -Arguments '--version'
    $nodeVersionOutput = $nodeResult.Output.Trim()
    if ($nodeResult.ExitCode -ne 0 -or $nodeVersionOutput -notmatch '^v?(\d+)') {
        Stop-WithMessage "No se pudo identificar la versión de Node.js: $nodeVersionOutput"
    }
    if ([int]$Matches[1] -lt 22) {
        Stop-WithMessage "Se requiere Node.js 22 o superior. Detectado: $nodeVersionOutput"
    }

    Write-Host 'Se iniciarán las pruebas instrumentadas en el dispositivo Android conectado.' -ForegroundColor Cyan
    Invoke-Gradle $GradlePath ':app:connectedDebugAndroidTest'
}

$Apk = Join-Path $ProjectRoot 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path -LiteralPath $Apk)) {
    Stop-WithMessage "Gradle terminó, pero no se encontró el APK esperado: $Apk"
}

$apkHash = (Get-FileHash -LiteralPath $Apk -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "`nCOMPILACIÓN Y PRUEBAS COMPLETADAS CORRECTAMENTE" -ForegroundColor Green
Write-Host "APK: $Apk"
Write-Host "SHA-256: $apkHash"
if (-not $RunAndroidTests) {
    Write-Host 'Aviso: no se ejecutaron pruebas instrumentadas. Conecta el teléfono y vuelve a ejecutar el script con -RunAndroidTests cuando quieras probarlas.' -ForegroundColor Yellow
}
