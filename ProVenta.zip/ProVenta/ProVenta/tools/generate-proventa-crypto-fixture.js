'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

function stableJson(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return '[' + value.map(stableJson).join(',') + ']';
  if (value && typeof value === 'object') {
    return '{' + Object.keys(value).sort().map(key =>
      JSON.stringify(key) + ':' + stableJson(value[key])
    ).join(',') + '}';
  }
  if (typeof value === 'number' && !Number.isFinite(value)) {
    throw new Error('Los datos contienen un número no finito.');
  }
  if (typeof value === 'undefined' || typeof value === 'function' || typeof value === 'symbol') {
    throw new Error('Los datos contienen un valor no serializable.');
  }
  return JSON.stringify(value);
}

const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
const signedFields = document => {
  const copy = { ...document };
  delete copy.signature;
  return Buffer.from(stableJson(copy), 'utf8');
};
const toPem = key => key.export({ type: 'spki', format: 'pem' }).toString();

const desktop = crypto.generateKeyPairSync('ed25519');
const deviceEncryption = crypto.generateKeyPairSync('rsa', {
  modulusLength: 3072,
  publicExponent: 0x10001
});
const desktopPublicKeyPem = toPem(desktop.publicKey);
const installationId = 'pcinst_' + sha256(
  desktop.publicKey.export({ type: 'spki', format: 'der' })
).slice(0, 32);
const authorizationId = 'auth_' + crypto.randomUUID();
const deviceId = 'device_node_fixture_01';
const posId = 'pos_node_fixture_01';
const nowMillis = Date.now();

const payload = {
  schema: 'proventa.inventory-snapshot',
  schemaVersion: 1,
  installationId,
  posId,
  posName: 'POS fixture Node',
  generatedAt: new Date(nowMillis).toISOString(),
  exchangeRates: { USD_CUP: 410 },
  catalog: [
    { productId: 'product_rice_01', name: 'Arroz', unit: 'lb', family: 'granos' }
  ],
  inventory: [
    {
      productId: 'product_rice_01',
      name: 'Arroz',
      unit: 'lb',
      family: 'granos',
      qty: 12.5,
      sale: 100,
      saleTransf: 108,
      saleTransfMode: 'percentage',
      saleTransfPercent: 8,
      saleUSD: 1.5,
      saleCurrency: 'USD'
    }
  ]
};
const payloadJson = stableJson(payload);
const payloadHash = sha256(payloadJson);
const expiresAt = nowMillis + 24 * 60 * 60 * 1000;
const header = {
  format: 'procontrol.device-data-package',
  version: 1,
  algorithm: 'RSA-OAEP-256+A256GCM',
  packageId: crypto.randomUUID(),
  installationId,
  authorizationId,
  deviceId,
  posId,
  type: 'inventory_snapshot',
  createdAt: new Date(nowMillis).toISOString(),
  expiresAt,
  payloadHash,
  signerPublicKey: desktopPublicKeyPem
};

const contentKey = crypto.randomBytes(32);
const iv = crypto.randomBytes(12);
const cipher = crypto.createCipheriv('aes-256-gcm', contentKey, iv);
cipher.setAAD(Buffer.from(stableJson(header), 'utf8'));
const ciphertext = Buffer.concat([
  cipher.update(payloadJson, 'utf8'),
  cipher.final()
]);
const tag = cipher.getAuthTag();
const wrappedKey = crypto.publicEncrypt({
  key: deviceEncryption.publicKey,
  padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
  oaepHash: 'sha256'
}, contentKey);
contentKey.fill(0);

const envelope = {
  ...header,
  encryption: {
    keyWrap: 'RSA-OAEP-SHA256',
    contentCipher: 'AES-256-GCM',
    wrappedKey: wrappedKey.toString('base64'),
    iv: iv.toString('base64'),
    tag: tag.toString('base64')
  },
  ciphertext: ciphertext.toString('base64')
};
envelope.signature = {
  algorithm: 'Ed25519',
  value: crypto.sign(null, signedFields(envelope), desktop.privateKey).toString('base64')
};

const fixture = {
  nowMillis,
  installationId,
  authorizationId,
  deviceId,
  posId,
  desktopPublicKeyPem,
  encryptionPrivatePkcs8: deviceEncryption.privateKey
    .export({ type: 'pkcs8', format: 'der' }).toString('base64'),
  envelope
};

const targetDirectory = path.resolve(__dirname, '../app/src/androidTest/assets');
fs.mkdirSync(targetDirectory, { recursive: true });
const target = path.join(targetDirectory, 'proventa-node-envelope-fixture.json');
fs.writeFileSync(target, JSON.stringify(fixture, null, 2), { encoding: 'utf8', mode: 0o600 });
process.stdout.write('Node crypto fixture generated for Android interoperability tests.\n');
