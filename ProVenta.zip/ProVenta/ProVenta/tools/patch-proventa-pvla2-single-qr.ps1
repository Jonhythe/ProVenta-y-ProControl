$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$authPath = Join-Path $projectRoot 'app\src\main\java\com\proventa\app\security\DeviceAuthorization.kt'
$scannerPath = Join-Path $projectRoot 'app\src\main\java\com\proventa\app\ui\screens\GoodsDispatchQrScanner.kt'
$blockPath = Join-Path $PSScriptRoot 'proventa-single-qr-decoder-block.txt'

foreach ($required in @($authPath, $scannerPath, $blockPath)) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
        throw "No se encuentra el archivo requerido: $required. No se modificó ningún archivo."
    }
}

$auth = [System.IO.File]::ReadAllText($authPath)
$scanner = [System.IO.File]::ReadAllText($scannerPath)
$decoderBlock = [System.IO.File]::ReadAllText($blockPath).Replace("`r`n", "`n").Replace("`n", "`r`n")

# 1) PVLA2: ProControl emite descriptor v4; el decodificador móvil no debe
# rechazarlo por limitarse a la versión 2.
$oldVersionCheck = 'document.optInt("version") == 2'
$newVersionCheck = 'document.optInt("version") in 2..4'
if ($auth.Contains($newVersionCheck)) {
    Write-Host '[OK] El decodificador PVLA2 ya admite las versiones 2 a 4.' -ForegroundColor Green
} elseif ($auth.Contains($oldVersionCheck)) {
    $occurrences = ([regex]::Matches($auth, [regex]::Escape($oldVersionCheck))).Count
    if ($occurrences -ne 1) {
        throw "Se esperaba una sola comprobación de versión PVLA2 y se encontraron $occurrences. No se modificó ningún archivo."
    }
    $auth = $auth.Replace($oldVersionCheck, $newVersionCheck)
    Write-Host '[FIX] El decodificador PVLA2 ahora admite versiones 2, 3 y 4.' -ForegroundColor Green
} else {
    throw 'No se reconoce la comprobación de versión de ProVentaActivationCode.decode(). No se modificó ningún archivo.'
}

# 2) ProControl v4 firma deviceSigningPublicKeyHash. Las versiones anteriores
# conservan el nombre legado devicePublicKeyHash. No se permite fallback entre
# ambos campos: cada versión debe utilizar exactamente el campo de su contrato.
$oldHashRead = '            val declaredHash = document.optString("devicePublicKeyHash")'
$newHashRead = '            val declaredHashField = if (version >= 4) "deviceSigningPublicKeyHash" else "devicePublicKeyHash"' + "`r`n" + '            val declaredHash = document.optString(declaredHashField)'
if ($auth.Contains('val declaredHashField = if (version >= 4)')) {
    Write-Host '[OK] El verificador ya lee el campo de huella correcto por versión.' -ForegroundColor Green
} elseif ($auth.Contains($oldHashRead)) {
    $occurrences = ([regex]::Matches($auth, [regex]::Escape($oldHashRead))).Count
    if ($occurrences -ne 1) {
        throw "Se esperaba una sola lectura de devicePublicKeyHash y se encontraron $occurrences. No se modificó ningún archivo."
    }
    $auth = $auth.Replace($oldHashRead, $newHashRead)
    Write-Host '[FIX] El verificador v4 ahora consume deviceSigningPublicKeyHash.' -ForegroundColor Green
} else {
    throw 'No se reconoce la lectura de la huella de clave de dispositivo. No se modificó ningún archivo.'
}

# 3) El lector de activación busca en el cuadro central, el fotograma completo
# y ventanas cuadradas solapadas. El flujo multi-QR de despachos se mantiene
# separado y no se cambia el formato/seguridad de la autorización.
$scannerAlreadyPatched = $scanner.Contains('private fun decodeSingleQrAcrossFrame(') -and
                         $scanner.Contains('return decodeSingleQrAcrossFrame(')
if ($scannerAlreadyPatched) {
    Write-Host '[OK] El escáner ya tiene búsqueda de QR en todo el fotograma.' -ForegroundColor Green
} else {
    $startMarker = 'internal fun decodeQrPayloadsFromLuma('
    $endMarker = 'internal fun rotateQrLuma('
    $start = $scanner.IndexOf($startMarker, [StringComparison]::Ordinal)
    if ($start -lt 0) { throw 'No se encontró la función decodeQrPayloadsFromLuma(). No se modificó ningún archivo.' }
    $end = $scanner.IndexOf($endMarker, $start, [StringComparison]::Ordinal)
    if ($end -lt 0) { throw 'No se encontró el límite rotateQrLuma(). No se modificó ningún archivo.' }
    if (-not $decoderBlock.StartsWith($startMarker, [StringComparison]::Ordinal)) {
        throw 'El bloque del escáner no tiene el encabezado esperado. No se modificó ningún archivo.'
    }
    if ($decoderBlock.Contains($endMarker)) {
        throw 'El bloque del escáner incluye la función de rotación; se cancela para evitar duplicados.'
    }
    $scanner = $scanner.Substring(0, $start) + $decoderBlock + "`r`n`r`n" + $scanner.Substring($end)
    Write-Host '[FIX] El lector QR ahora busca también fuera del centro de la imagen.' -ForegroundColor Green
}

# Todas las validaciones se realizan antes de escribir. Se preserva UTF-8 sin BOM.
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[System.IO.File]::WriteAllText($authPath, $auth, $utf8NoBom)
[System.IO.File]::WriteAllText($scannerPath, $scanner, $utf8NoBom)

Write-Host ''
Write-Host 'Parche aplicado. No se modificaron pruebas, claves, bases de datos ni archivos de ProControl.' -ForegroundColor Green
Write-Host "Actualizado: $authPath"
Write-Host "Actualizado: $scannerPath"
