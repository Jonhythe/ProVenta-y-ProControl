'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = relative => fs.readFileSync(path.join(root, relative), 'utf8');
const dao = read('app/src/main/java/com/proventa/app/data/dao/ProVentaDao.kt');
const close = read('app/src/main/java/com/proventa/app/ui/screens/ClosingScreen.kt');
const archive = read('app/src/main/java/com/proventa/app/security/ShiftCloseRecoveryArchive.kt');
const verifier = read('app/src/main/java/com/proventa/app/security/ShiftPermitVerifier.kt');
const picker = read('app/src/main/java/com/proventa/app/ui/screens/ShiftPermitCard.kt');
const service = read('app/src/main/java/com/proventa/app/data/shifts/ShiftCloseService.kt');
const opening = read('app/src/main/java/com/proventa/app/data/shifts/ShiftOpenService.kt');
const purgeTest = read('app/src/androidTest/java/com/proventa/app/data/shifts/ShiftClosePurgeDaoTest.kt');
const readerTest = read('app/src/test/java/com/proventa/app/ui/screens/ShiftPermitFileReaderTest.kt');
const importerTest = read('app/src/androidTest/java/com/proventa/app/data/shifts/ShiftPermitImporterTest.kt');
const buildLauncher = read('COMPILAR_PROVENTA.bat');
const buildScript = read('tools/compilar-y-probar-windows.ps1');
let count = 0;
function has(condition, message) { count++; assert.ok(condition, message); }

has(close.includes('Confirmar exportación y limpieza del POS') && close.includes('Text("Continuar")') && close.includes('Text("Retroceder")'), 'El usuario debe confirmar expresamente o retroceder sin borrar datos.');
has(close.includes('openInputStream(uri)') && close.includes('MessageDigest.isEqual(expectedBytes, readBackBytes)'), 'ProVenta vuelve a leer el destino real y compara todos los bytes antes de borrar.');
has(close.includes('verifyCloseEnvelope') && close.includes('Ed25519') && close.includes('SHA-256'), 'El archivo se valida con identidad, huella de contenido y firma Ed25519.');
has(close.includes('createOrVerify') && close.includes('purgeClosedShiftDataAfterVerifiedArchive'), 'El respaldo privado debe quedar verificado antes de iniciar la purga.');
has(close.includes('archive.hasArchive') && close.includes('verifyExistingAfterClear'), 'La reexportación posterior a una limpieza exige comprobar el respaldo existente.');
has(close.includes('productUnitsFromSignedClose(raw)') && close.includes('Nunca repetir una purga ya completada'), 'Si la copia auxiliar se pierde después de una purga ya terminada, el cierre firmado se puede volver a exportar sin volver a borrar.');
has(close.includes('9_007_199_254_740_991L') && close.includes('longValueExact()'), 'El cierre impide borrar datos para cantidades que ProControl no podría representar con exactitud.');
has(archive.includes('AES/GCM/NoPadding') && archive.includes('AndroidKeyStore'), 'La copia de recuperación usa AES-GCM con clave protegida por Android Keystore.');
has(archive.includes('noBackupFilesDir') && archive.includes('fd.sync()'), 'La copia se guarda en el espacio privado de ProVenta y fuerza la escritura antes de verificarla.');
has(archive.includes('MessageDigest.getInstance("SHA-256")') && archive.includes('snapshotSha256'), 'La copia autentica la huella SHA-256 del conjunto recuperable.');
has(archive.includes('Os.fsync(directoryFd)') && archive.includes('Os.fstat(directoryFd)') &&
  archive.includes('POSIX_FILE_TYPE_MASK') && archive.includes('POSIX_DIRECTORY_TYPE') &&
  archive.includes('syncArchiveDirectory()'), 'La carpeta del respaldo se abre, valida como directorio y sincroniza antes de purgar la base; un fallo de fsync cancela el borrado.');
has(dao.includes('countSalesNotSynced(posId) == 0') && dao.includes('listPendingSalePackages(posId).isEmpty()'), 'No se purga si hay ventas no sincronizadas o paquetes de venta pendientes.');
has(dao.includes('countPendingSalesWithoutPackage(posId) == 0') && dao.includes('countSalePackagesNeedingReview(posId) == 0'), 'No se purga si hay ventas sin paquete o rechazadas/conflictivas que requieren revisión.');
has(dao.includes('countUnconfirmedGoodsReceipts(posId) == 0'), 'No se purga si quedan recepciones sin confirmación final.');
has(dao.includes('currentHash == expectedSnapshotSha256'), 'Antes del borrado se vuelve a calcular la huella de toda la información del POS.');
has(dao.includes('@Transaction\n    suspend fun purgeClosedShiftDataAfterVerifiedArchive'), 'La eliminación se ejecuta en una transacción Room.');
has(dao.includes('getOutboxPackageForAggregate(permitId, "shift_close")?.packageId == closePackage.packageId') && dao.includes('getShiftPermit(permitId)?.status == "CLOSE_PENDING"'), 'El paquete firmado de cierre y el permiso se conservan para el acuse.');
has(dao.includes('DELETE FROM products WHERE posId=:posId') && dao.includes('DELETE FROM sales WHERE posId=:posId') && dao.includes('DELETE FROM goods_receipts WHERE posId=:posId'), 'La purga se restringe a productos, ventas y recepciones del POS seleccionado.');
has(dao.includes('listShiftPermitsForRecovery(posId)') && dao.includes('listShiftCloseDraftsForRecovery(posId)') && dao.includes('shiftPermits'), 'El respaldo privado incluye todo el historial de permisos y borradores del POS, no solo el turno actual.');
has(dao.includes('deleteRecoveryHistoricalShiftPermits') && dao.includes('DELETE FROM shift_permits WHERE posId=:posId AND permitId != :permitId'), 'La limpieza elimina permisos antiguos del POS y conserva únicamente el permiso del cierre actual.');
has(dao.includes("NOT (aggregateId=:permitId AND packageType='shift_close')") && dao.includes('remainingPackages.size == 1'), 'La limpieza elimina paquetes operativos antiguos y conserva solo el paquete firmado del cierre actual.');
has(dao.includes('deleteRecoveryCloseDrafts(posId)') && dao.includes('countRecoveryDrafts(posId) == 0'), 'La purga elimina y comprueba todos los borradores de cierre del POS.');
has(purgeTest.includes('closingPosPurgesItsEntireOperationalHistoryButPreservesCurrentCloseAndOtherPos') && purgeTest.includes('aChangedPosSnapshotAbortsCleanupAndLeavesEveryRecordUntouched'), 'La prueba instrumentada cubre limpieza completa, aislamiento de otro POS y reversión ante cambio de huella.');
has(picker.includes('onMalformedInput(CodingErrorAction.REPORT)') && picker.includes('onUnmappableCharacter(CodingErrorAction.REPORT)'), 'La importación de permisos detecta UTF-8 realmente malformado, sin sustituir bytes silenciosamente.');
has(picker.includes('UTF-8 BOM válido; no es daño del archivo') && picker.includes('total > 0'), 'La importación admite BOM UTF-8 y distingue archivos vacíos.');
has(readerTest.includes('acceptsPlainUtf8AndAValidUtf8Bom') && readerTest.includes('malformedUtf8IsNotSilentlyReplaced') && readerTest.includes('oversizedFilesAreRejectedBeforeJsonParsing'), 'Las pruebas unitarias cubren UTF-8 correcto, BOM, bytes inválidos y límite máximo del permiso.');
has(verifier.includes('JSON completa') && verifier.includes('firma del permiso no es válida o el archivo fue modificado'), 'Los fallos del permiso describen una causa concreta de lectura o firma.');
has(importerTest.includes('initialInventory') && importerTest.includes('other-pos-product-') && importerTest.includes('in-scope-product-') && importerTest.includes('verifiesAndImportsOnlyTheSignedPermitForThisDeviceAndPos'), 'La prueba instrumentada demuestra que la apertura exporta solo productos del POS firmado y excluye los de otro POS.');
has(/importPermit\(\"\{\\\"format\\\":\\\"procontrol\.shift-permit\\\",\\\"version\\\":2/.test(importerTest) && verifier.includes('JSON completa'), 'La prueba instrumentada rechaza un permiso JSON truncado con un error de estructura real.');
has(opening.includes('dao.listActiveProducts(permit.posId)') && opening.includes('.put("posId", permit.posId)'), 'La apertura solo incluye el inventario del POS contenido en el permiso firmado.')
has(service.includes('dao.listActiveProducts(permit.posId)') && service.includes('MAX_SAFE_JSON_INTEGER'), 'El cierre valida las cantidades del POS autorizado y el rango exacto de interoperabilidad.');
has(buildLauncher.includes('tools\\compilar-y-probar-windows.ps1') && !buildLauncher.includes('ps1.ps1'), 'El lanzador de Windows debe apuntar al nombre real del script, sin extensión duplicada.');
has(buildScript.includes("Join-Path $ProjectRoot 'gradlew.bat'") && buildScript.includes('gradle-wrapper.jar'), 'La compilación debe utilizar el Gradle Wrapper incluido y comprobar sus archivos.');
has(buildScript.includes("':app:lintDebug'") && buildScript.includes("':app:testDebugUnitTest'") && buildScript.includes("':app:assembleDebug'"), 'La validación de ProVenta debe ejecutar pruebas unitarias, Android Lint y generar el APK.');
console.log(`ProVenta shift-close safety: ${count} static assertions passed.`);
