$ErrorActionPreference = 'Stop'

function Replace-ExactOnce {
    param(
        [Parameter(Mandatory = $true)][string]$RelativePath,
        [Parameter(Mandatory = $true)][string]$OldText,
        [Parameter(Mandatory = $true)][string]$NewText
    )

    $path = Join-Path (Get-Location).Path $RelativePath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "No se encontró el archivo esperado: $RelativePath"
    }

    $content = [System.IO.File]::ReadAllText($path)
    $count = ([regex]::Matches($content, [regex]::Escape($OldText))).Count
    if ($count -ne 1) {
        throw "Se esperaba una sola coincidencia en $RelativePath, pero se encontraron $count. No se modificó este archivo."
    }

    $backup = "$path.before-pvla2-fixture-fix.bak"
    if (-not (Test-Path -LiteralPath $backup)) {
        Copy-Item -LiteralPath $path -Destination $backup
    }

    $updated = $content.Replace($OldText, $NewText)
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($path, $updated, $utf8NoBom)
    Write-Host "Corregido: $RelativePath" -ForegroundColor Green
}

$descriptorTest = 'app\src\test\java\com\proventa\app\security\DeviceAuthorizationDescriptorVerifierTest.kt'
$activationTest = 'app\src\test\java\com\proventa\app\security\DeviceBoundActivationTest.kt'

# Each v4 fixture must use the same canonical device ID form produced by PVID1.
Replace-ExactOnce -RelativePath $descriptorTest `
    -OldText 'device_phone_v4_1234' `
    -NewText 'device_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'

Replace-ExactOnce -RelativePath $activationTest `
    -OldText 'device_phone_87654321' `
    -NewText 'device_bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'

# Use a different, but syntactically valid, v4 ID in the negative .pvlink test.
Replace-ExactOnce -RelativePath $activationTest `
    -OldText 'DeviceActivationEnvelope.decrypt(envelope.toString(), phoneEncryptionKeys.private, "device_another_phone")' `
    -NewText 'DeviceActivationEnvelope.decrypt(envelope.toString(), phoneEncryptionKeys.private, "device_cccccccccccccccccccccccccccccccc")'

Write-Host ''
Write-Host 'Fixtures v4 actualizadas. Código de producción sin cambios.' -ForegroundColor Green
Write-Host 'Ahora ejecuta: .\gradlew.bat --no-daemon :app:testDebugUnitTest'
