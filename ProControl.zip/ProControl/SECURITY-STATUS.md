# Estado de seguridad y procedencia de ProControl

## Fuente incorporada

- Archivo de origen: `ProControl-GitHub-Source-20261106 (1).zip`.
- SHA-256 verificado por GitHub Actions: `6c039379e003bdf6ab5ff01d1638fca08cdc647e0e026816da43d70ebd62fe14`.
- Tamaño registrado por GitHub: 5.590.242 bytes.
- El workflow de inspección extrajo 152 entradas en un runner Windows temporal. La fuente del proyecto quedó incorporada en `app/`, `docs/` y `licensor/`.
- Archivos importados bajo esas tres carpetas: 148 (registrados individualmente en `SOURCE-FILE-MANIFEST.json`).
- El informe del runner no detectó nombres de claves privadas, patrones habituales de tokens/PEM, comandos de exclusión o desactivación de antivirus ni cabeceras MZ/PE.
- El propietario indicó que Avast no detectó amenazas en el ZIP ni en la carpeta extraída. Ese resultado es comunicado por el propietario, no una certificación independiente.

La inspección fue estática y la extracción se realizó sin ejecutar archivos del ZIP. Ningún escaneo estático ni resultado de antivirus garantiza ausencia absoluta de malware.

## Entorno y automatización

La compilación se realiza en un runner Windows x64 hospedado por GitHub, no en el PC donde se detectó Expiro. El proceso usa Node 24, el lockfile del proyecto, pruebas de fuente, construcción NSIS y creación de distribución por carpetas. Los artefactos se acompañan de hashes SHA-256.

El primer intento de CI detectó una prueba sensible a CRLF/LF. Se añadió `.gitattributes` para fijar los finales de línea y la siguiente ejecución pasó `npm run check-source`. La generación NSIS y la distribución por carpetas deben terminar y validarse antes de considerar que el paquete es instalable.

## Claves de licencia

La clave privada Ed25519 anterior se considera comprometida por exposición en un paquete previo. No debe reutilizarse. El repositorio contiene solo la clave pública actualmente integrada; `licensor/ROTACION-CLAVE-REQUERIDA.txt` documenta la rotación pendiente.

La compilación técnica no firma ni emite licencias y no utiliza secretos privados. Nunca subir `licensor/private/`, archivos `*.pckey`, claves PEM privadas, generadores finales que incorporen paquetes cifrados, tokens, archivos `.env` ni registros administrativos.

## Estado de distribución

**NO DISTRIBUIR A CLIENTES** hasta completar:

1. La revisión de la compilación NSIS y la distribución por carpetas.
2. Una prueba real de instalación limpia, ejecución y desinstalación en Windows x64.
3. La rotación Ed25519: integrar la clave pública nueva en la app y conservar la nueva clave privada fuera del repositorio con permisos mínimos.
4. Las pruebas de emisión/verificación con el nuevo par de claves y la validación final de artefactos.

La firma Authenticode no se está aplicando en este workflow. La generación del icono/recursos del ejecutable no equivale a una firma digital.
