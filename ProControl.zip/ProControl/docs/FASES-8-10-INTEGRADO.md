# ProControl — Fases 8, 9 y 10 integradas

## Alcance

Esta entrega consolida la preparación de escritorio para el futuro intercambio móvil, la conciliación comercial y la recuperación. El intercambio de esta fase es **por archivos locales/USB**: no abre un servidor HTTP ni un listener TCP. La app móvil todavía debe desarrollarse y probarse aparte; este documento define el contrato de datos con el que tendrá que interoperar.

## Flujo de extremo a extremo

1. En ProControl, abre **Administración → Dispositivos y sincronización móvil**.
2. Selecciona un punto de venta y un rol limitado (Operador o Supervisor). Genera el código temporal y exporta la ficha `.pcpair` firmada.
3. Conserva la ficha como credencial temporal; cópiala a la memoria USB únicamente para el dispositivo que se vaya a vincular. El código caduca aproximadamente en cinco minutos y es de un solo uso.
4. Cuando exista la app móvil, esta leerá la ficha, generará su propia clave Ed25519 y completará la vinculación. El escritorio almacena la clave pública del dispositivo, el rol y el POS asignados.
5. El escritorio puede exportar `.pcpkg` con una instantánea de catálogo/stock. La app móvil futura leerá esa instantánea y preparará paquetes de operación firmados con la clave privada del dispositivo.
6. Importa el `.pcpkg` recibido desde USB. El escritorio valida estructura, tamaño, hash SHA-256, firma Ed25519, estado del dispositivo, rol y alcance de POS. Un paquete importado queda en `pending_review`; no cambia inventario automáticamente.
7. Revisa el paquete. **Aceptar para conciliación no aplica cambios**. Después de previsualizarlo, pulsa **Validar y conciliar**. El reconciliador vuelve a validar el contenido y aplica los cambios compatibles dentro de la transacción lógica de DataStore; el recibo de conciliación se guarda en la base local del puente.
8. Si el paquete falla validación o presenta un ID usado con contenido diferente, no lo apliques: márcalo como conflicto/rechazado y resuelve la diferencia manualmente.

## Formato de paquete firmado `.pcpkg`

JSON UTF-8, máximo 2 MiB de payload (con una tolerancia adicional pequeña para el sobre). El sobre de versión 1 contiene:

- `format`: `procontrol.offline-package`
- `version`: `1`
- `packageId`: UUID del paquete
- `deviceId`: ID del dispositivo emisor
- `type`: tipo de operación
- `createdAt`: fecha ISO-8601
- `payload`: objeto de datos
- `payloadHash`: SHA-256 del JSON canónico del payload
- `signerPublicKey`: clave pública Ed25519 registrada para el dispositivo
- `signature`: firma Ed25519 sobre el sobre canónico (sin el campo `signature`)

El orden de las propiedades del JSON no cambia el hash porque se usa JSON canónico al verificar. La firma no sustituye las validaciones comerciales: cada operación se valida además contra el estado de ProControl.

### Tipos de paquete admitidos

- `inventory_snapshot`: instantánea de solo lectura. Compara diferencias y escribe auditoría; **no sobrescribe existencias**.
- `sale_batch`: `{ schemaVersion: 1, transactions: [...] }`. Entre 1 y 250 tickets con el esquema validado por `SalesLedgerOps`. Cada ticket identifica `id`, `posId`, moneda, forma de pago, importes y líneas. Cada línea identifica `productId`, `presentation` (`unit` o `box`), `presentationQty`, `unitsPerBox` cuando es caja, `baseUnit`, `baseQty`, precio e importes. El POS debe existir y tener activo el registro de tickets.
- `return`: `{ schemaVersion: 1, transactions: [...] }`. Entre 1 y 100 operaciones de devolución; cada una debe referir `returnOf` a un ticket original ya existente. Esta entrega admite devolución completa, no parcial. El ticket original permanece inalterado y se crea una operación inversa.
- `transfer`: `{ schemaVersion: 1, transfer: { id, source, destination, items: [...] } }`. Cada línea lleva `productId`, nombre, unidad base y cantidad base. `source`/`destination` son referencias POS conocidas o `warehouse`. Se bloquean unidades incompatibles, stock insuficiente y duplicados contradictorios.
- `shift_open`: `{ schemaVersion: 1, shift: { id, posId, startedAt } }`. Habilita el registro de tickets móvil para ese POS y queda auditado.
- `shift_close`: `{ schemaVersion: 1, shift: { id, posId, ... } }`. Se registra como solicitud; el recuento físico y el cierre de caja deben completarse en el escritorio. No cierra caja automáticamente.
- `heartbeat`: evento de estado auditado.

Los nombres/campos de los tickets deben coincidir con el contrato real de `renderer/sales-ledger.js`. La app móvil futura debe usar IDs estables e idempotentes; no generar otro ID al reintentar el mismo envío.

## Seguridad y conciliación

- No se expone un listener de red. El transporte implementado es archivo local/USB.
- Código de emparejamiento corto, temporal, de un solo uso y limitado a un POS y rol.
- Los privilegios `admin` no se conceden con el código temporal mientras no exista autorización de mayor nivel.
- Los dispositivos revocados o sin clave pública registrada no pueden introducir paquetes firmados.
- El escritorio rechaza firmas, hashes, IDs o alcances POS no válidos.
- Los paquetes importados requieren revisión y aceptación explícita; se vuelven a validar antes de aplicar.
- Los tickets originales no se editan mediante una devolución. La devolución se registra por separado.
- Reintentos idénticos son idempotentes; un ID reutilizado con contenido distinto se bloquea como conflicto.
- No se cambia el contenido de una instantánea para hacerla coincidir con el escritorio.
- Las transacciones de `DataStore` revierten el estado en memoria si falla una operación; como el almacenamiento principal renderer tiene varias claves, una interrupción de escritura requiere comprobar y, si es necesario, restaurar la copia de seguridad antes de continuar.

## Copia de seguridad y recuperación

Los scripts están en `tools/backup-procontrol.ps1` y `tools/restore-procontrol.ps1`.

Crear copia (cierra antes ProControl):

```powershell
cd D:\ProControl\app
.\tools\backup-procontrol.ps1 -Destination 'E:\Backups\ProControl'
```

Restaurar una copia (cerrando antes ProControl; usa la misma cuenta de Windows porque la clave privada del puente se protege con DPAPI):

```powershell
cd D:\ProControl\app
.\tools\restore-procontrol.ps1 -BackupPath 'E:\Backups\ProControl\ProControl-Backup-AAAAmmdd-HHmmss'
```

La copia incluye solo una lista permitida de datos de ProControl y la identidad del puente. No contiene ni modifica `license.dat` ni la clave privada del emisor de licencias. La restauración valida el manifiesto y los hashes primero y deja una copia previa. Guarda el respaldo en un dispositivo seguro.

## Qué se prueba y qué queda pendiente

Las pruebas Node de esta entrega comprueban la verificación de firmas, hashes, restricciones por POS/rol, duplicados, reglas de conciliación, conversiones unidad/caja, devolución completa, transferencias repetidas, eventos de turno, instantáneas de solo lectura y aspectos estáticos de copia/restauración. Son pruebas automatizadas de lógica con datos simulados.

**No es posible certificar todavía el intercambio real con un teléfono**: la app móvil no existe en esta entrega. Cuando se desarrolle, será necesario probar emparejamiento, clave privada móvil, firma de paquetes en el teléfono, copiar por USB, importar/responder, interrupciones físicas, pérdida del teléfono, revocación y reconciliación con datos reales. También hay que abrir la interfaz en Windows y generar/inspeccionar el instalador; este entorno no puede ejecutar la ventana gráfica de Electron de la máquina del usuario.
