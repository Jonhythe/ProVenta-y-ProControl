# ProControl — Parte 2: fases 4, 5 y 6

**Estado:** candidato técnico para validación en Windows. Esta entrega se aplica sobre la Parte 1 `Validada`; no es un instalador ni una sustitución completa de la carpeta del proyecto.

## Fase 4 — Importación durable e idempotente

- El puente mantiene un diario `reconciliation_jobs` asociado a cada paquete entrante. Se registran huella, estado, intentos, último error y recibo final.
- La aplicación requiere las transiciones `accepted_for_reconciliation` → `applying` → `applied`. Un ACK no puede cerrar un trabajo si no comenzó un intento.
- Un fallo se registra como reintentable; una repetición con el mismo ID y contenido se reconoce como duplicada. Reutilizar un ID con otra huella se rechaza.
- Antes de cambiar el estado del puente, el reconciliador guarda un recibo durable (`mobile-package-receipt:<packageId>`) dentro del mismo guardado del libro comercial. Si el proceso cae después del guardado comercial pero antes del ACK SQLite, el reintento encuentra el recibo y no vuelve a descontar stock ni duplicar tickets.
- Los estados de transferencia se registran como eventos de auditoría con claves de idempotencia únicas. El cierre del paquete y el evento final de transferencia se confirman en una transacción SQLite; un error finalizador no se ignora.
- Las bases del puente y de comercio son almacenes distintos: no se afirma que exista una transacción atómica entre ellas. La recuperación compara el recibo comercial durable con el diario del puente.

## Fase 5 — Tickets, transferencias y cierres pendientes

- La recepción de un cierre móvil crea una solicitud pendiente, no un cierre financiero. No modifica el efectivo, el conteo físico, el IPV ni la sesión de cierre de escritorio.
- La bandeja de cierres solo presenta solicitudes cuyo paquete ha sido aceptado para conciliación o ya se ha conciliado. La confirmación o rechazo exige una autorización privilegiada.
- La repetición de una misma decisión es idempotente. Un rechazo restaura el permiso a estado abierto sin borrar la solicitud original ni el historial.
- El ID del turno se persiste al recibir `shift_open`. `shift_close` debe referirse exactamente a ese ID, al mismo POS y al permiso firmado. No se puede cerrar un turno diferente.
- Los paquetes de ventas, devoluciones y transferencias siguen usando el libro de ventas y el modelo de unidades existente; los tickets originales y el historial no se eliminan. Las diferencias de transferencia se conservan como estado/evento de auditoría.
- Las fórmulas comerciales no se redefinen: PPP, tasa USD del cierre, efectivo y transferencia separados e IPV = stock inicial menos conteo final. El cierre monetario final continúa en el escritorio.

## Fase 6 — Permisos y emergencia limitada

- Los permisos de turno llevan firma Ed25519 y quedan ligados a POS, dispositivo, secuencia y ventana temporal. La secuencia debe crecer y no se emite otro permiso mientras exista uno activo para el mismo POS.
- Cada evento de venta debe incluir el mismo `shiftPermitId`, POS y ventana que el permiso. Se rechazan marcas de tiempo muy futuras, fuera del turno o de otro turno.
- La emergencia está desactivada en permisos nuevos. Solo el Dueño puede solicitarla, con motivo, vencimiento no superior a cuatro horas, vencimiento dentro del turno y cuota de 1 a 50 tickets.
- Cada paquete de venta consumido para la cuota queda registrado en el almacén SQLite junto con su huella. Repetir un paquete no consume cuota de nuevo; superar la cuota o enviar devoluciones en emergencia se rechaza.
- La importación de eventos móviles que pueden afectar ventas/stock exige `CON_APP` y validación del permiso, independientemente de que el control estricto de licencias POS para ventas de escritorio esté activado. Esto evita usar la compatibilidad de escritorio como bypass del control móvil.
- **Bloqueo de producción conservado:** `MOBILE_APP_READY` sigue en `false`. No se pueden activar `CON APP` ni emitir permisos operativos en la aplicación normal hasta desarrollar y probar la aplicación móvil real. La prueba integrada altera el objeto de control solo en memoria dentro de una carpeta temporal, nunca en una instalación real.

## Pruebas incluidas

- `tools/test-phase4-6-hardening.js`: flujo sintético de permisos, firma, cuota de emergencia, paquete de apertura, ventas repetidas, cierre pendiente, validación de turno y transferencias.
- `tools/test-mobile-bridge.js`: diario de recuperación y prohibición de ACK prematuro.
- `tools/test-mobile-reconcile.js`: recibo comercial durable y recuperación sin doble movimiento.
- `tools/test-mobile-control-plane.js`: historial de transferencias, transiciones e idempotencia.

## Límites conocidos

- No existe aún una app móvil real; no se certifica emparejamiento, operación móvil ni ida y vuelta de extremo a extremo.
- La suite `npm run check-source` pasa en el entorno disponible.
- `npm run check` no termina en Linux: `tools/test-license.js` necesita leer el identificador de máquina Windows. La ejecución se detiene antes de ejecutar `check-no-secrets`.
- `tools/check-no-secrets.js`, ejecutado por separado, escanea el código fuente pero termina con error porque no se ha construido un `app.asar`. La ausencia de un `app.asar` no permite afirmar que el instalador está libre de secretos.
- No se han probado la interfaz gráfica, el esquema real del usuario, el respaldo/restauración ni el instalador en Windows. Todo eso queda como criterio de aceptación antes de publicar.
