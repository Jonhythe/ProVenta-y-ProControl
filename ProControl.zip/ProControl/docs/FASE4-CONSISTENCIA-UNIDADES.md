# Fase 4 — Consistencia de cajas y unidades en operaciones existentes

## Alcance

Esta fase complementa el selector de cajas con reglas consistentes para las operaciones ya existentes de ProControl. No reemplaza la aplicación completa.

- El inventario continúa almacenándose en la unidad base. Una compra de `2 cajas × 15` aporta `30` unidades individuales.
- La corrección de una compra compara el stock corregido en unidades base, no compara 2 cajas como si fueran 2 unidades.
- El formulario de correcciones muestra la unidad histórica y el factor unidades/caja. Si una compra antigua por caja no guardó el factor, la corrección se bloquea en lugar de adivinar.
- Las cantidades de traslado y devolución siguen siendo cantidades de la unidad base. Las pantallas muestran también la equivalencia en cajas cuando el producto tiene un factor y la equivalencia es exacta.
- El cierre ya expresa el producto vendido como unidades individuales y, cuando hay factor, agrega su equivalente en cajas completas más unidades sueltas.
- Se incorpora el archivo `tools/test-license-core-only.js` requerido por el script `npm run check-source` de la estructura móvil preparada; no modifica el motor de licencias.

## Reglas contables

- La cantidad física base es entera para `u` y `caja`; para `caja` se convierte usando el factor guardado en esa línea histórica.
- El valor monetario histórico de la compra permanece como `cantidad de paquetes × precio del paquete`; el coste unitario utilizado por el inventario se expresa sobre las unidades físicas base.
- No se permite corregir una compra por cajas si falta el contenido histórico de la caja.
- Las operaciones de transferencia y devolución no convierten cantidades por segunda vez: mueven unidades base y solo las describen con equivalencia visual.

## Límites de esta fase

El cierre de ProControl calcula ventas a partir de la diferencia entre el stock inicial y el conteo final; no es un libro de tickets por línea de venta. Por tanto, esta fase no introduce un precio de caja independiente, descuentos por caja ni un registro de cada venta como caja frente a unidades sueltas. Para eso se requiere una fase posterior de ventas transaccionales, manteniendo la trazabilidad histórica y el proceso de cierre actual.

## Validación

Se deben ejecutar en Windows, en una copia del proyecto y con datos de prueba:

```powershell
npm run check-source
npm start
```

Comprobar manualmente compra, corrección de compra, traslado, devolución y cierre. No dar por validado el instalador hasta ejecutar `npm run check` y compilar en Windows.
