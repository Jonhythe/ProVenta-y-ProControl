# Guía del usuario — Registros antiguos

## ¿Para qué sirve?

Los registros antiguos conservan el detalle completo de operaciones históricas sin llenar las pantallas de cientos de filas. ProControl mantiene los 50 registros más recientes por sección y archiva los más antiguos que sea seguro mover.

Los archivos se agrupan por sección y día. El Dueño puede elegir una sección, un día y navegar con **Anterior** y **Siguiente**. La ficha muestra primero un resumen fácil de leer; el JSON completo está en **Ver detalle completo del registro (avanzado)**.

## Cómo activarlo

1. Inicia sesión como **Dueño**.
2. En el historial de una sección pulsa **Revisar registros antiguos**.
3. Introduce la contraseña actual del Dueño y pulsa **Activar archivo seguro**.
4. Guarda el código de recuperación fuera de la computadora y confirma que lo guardaste. El código solo aparece una vez.
5. ProControl comprobará la integridad y luego archivará automáticamente los registros antiguos que sean seguros. También puedes usar **Archivar registros antiguos** para ejecutar la operación manualmente.

Solo el rol Dueño puede abrir la bóveda. Administrador y Económico no pueden abrirla ni cambiar sus credenciales.

## ¿Qué significa el resumen de cada sección?

- **Entradas/compras:** fecha, proveedor, cantidad de líneas e importe.
- **Transferencias:** origen, destinos, producto, cantidad y estado.
- **Cierres:** punto de venta, responsable, ingresos y resultado; indica si se calculó con tickets o con conteo/IPV.
- **Sesiones:** usuario, entrada, salida y duración.
- **Correcciones/devoluciones:** tipo, responsable y descripción.

Los registros se archivan solo cuando están cerrados y ya no hacen falta para una operación pendiente. Los tickets detallados de venta permanecen en el libro de ventas para preservar devoluciones y conciliación.

## Si aparece una alerta de integridad

Si falta un archivo cifrado, la huella no coincide o existe un archivo huérfano, no continúes archivando ni intentes borrar archivos manualmente. La alerta informa que no se ha borrado nada. Conserva una copia de la carpeta de datos y del respaldo más reciente y pide revisión antes de hacer cambios.

## Contraseña y código de recuperación

La bóveda deriva una envoltura criptográfica de la contraseña del Dueño. Si olvidas la contraseña, el código permite recuperar la misma clave maestra y volver a establecer la envoltura con la contraseña vigente. El código no se almacena en ProControl: si se pierde y también se pierde la contraseña, los archivos cifrados no se podrán recuperar.

Por seguridad, al cerrar la ventana de registros antiguos se bloquea la bóveda. También se bloquea automáticamente cuando caduca la autorización del Dueño (cinco minutos). Para volver a consultar detalles tendrás que introducir de nuevo la contraseña. El código de recuperación se elimina de la pantalla al bloquearse.

Exporta un respaldo solo con la bóveda desbloqueada. Al restaurar un respaldo que contiene históricos, también se requiere la contraseña que abría la bóveda cuando se creó esa copia o el código de recuperación de esa copia.
