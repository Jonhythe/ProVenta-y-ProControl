# ProVenta — Fase 3: separar autorización de instalación y permiso operativo POS/turno

**Estado:** separación de alcance implementada en el código fuente y cubierta por pruebas automatizadas. La emisión operativa, `CON APP` y los paquetes comerciales siguen bloqueados en producción porque `MOBILE_APP_READY` continúa en `false`.

## Problema corregido

La Fase 2 registra cada teléfono nuevo con `pos_id = NULL`, porque su autorización pertenece a la instalación de ProControl y no a un punto de venta. El puente y el plano de control todavía conservaban validaciones heredadas que exigían un POS fijo, lo cual impedía utilizar el teléfono autorizado en otro punto.

## Cambios realizados

1. **Autorización permanente por instalación:** el backend comprueba en cada importación que la autorización del dispositivo sigue activa, que pertenece a la identidad de instalación y que el registro está asociado al mismo `device_id`.
2. **Permiso operativo por POS y turno:** `issueShiftPermit` ya no exige que un teléfono de instalación tenga `pos_id`. Comprueba que el dispositivo está autorizado, que el empleado coincide con el trabajador registrado, y emite un permiso Ed25519 que sí queda limitado a un POS, dispositivo, trabajador, secuencia y ventana horaria.
3. **Asignación a otro POS:** el mismo teléfono de empresa puede recibir permisos separados para diferentes POS. La regla de un solo turno operativo activo por POS se conserva.
4. **Validación de paquetes:** ventas, aperturas y cierres deben declarar un único POS. El plano de control verifica el permiso firmado contra el dispositivo, POS, secuencia y fecha del evento. Los paquetes que mezclan POS se rechazan.
5. **Revocación:** el alcance se vuelve a comprobar en cada paquete entrante. Una autorización invalidada no puede seguir usando permisos de turno emitidos anteriormente.
6. **Compatibilidad:** los dispositivos heredados que sí tenían `pos_id` conservan la restricción al POS con el que se emparejaron.
7. **Interfaz administrativa:** el selector de dispositivos incluye teléfonos autorizados para toda la instalación, aunque tengan `posId` vacío, muestra el trabajador asociado y propone ese nombre al emitir el permiso.

## Restricciones que siguen activas

- `MOBILE_APP_READY = false` en el plano de control de producción. Por eso la emisión real de permisos, el cambio a `CON APP` y las operaciones comerciales permanecen cerrados hasta integrar y probar Android.
- Un permiso operativo no es una autorización permanente ni sustituye la autorización por instalación. El primero habilita un POS/turno concreto; la segunda identifica el teléfono perteneciente a la empresa.
- El tipo de paquete `transfer` que llega desde móviles sigue limitado al modelo heredado por POS. El nuevo flujo de recepción de mercancía de ProVenta requiere un permiso/paquete de transferencia dirigido y firmado por el escritorio; no se ha habilitado para operadores nuevos.
- Los paquetes salientes de inventario, catálogo, tasas, turnos y transferencias todavía no están cifrados para una clave de dispositivo destinatario. Sus exportaciones continúan bloqueadas.
- Todavía no existe el ciclo completo PC → USB → Android → USB → PC con un teléfono Android real.

## Pruebas

- `test-mobile-control-plane.js`: 39 comprobaciones aprobadas. Incluye dispositivo sin POS fijo, dos POS para el mismo teléfono, coincidencia del nombre del trabajador, permisos firmados y revocación.
- `test-mobile-bridge-ui.js`: 41 comprobaciones aprobadas. Incluye selección de teléfonos autorizados a nivel de instalación.
- `test-phase4-6-hardening.js`: 35 comprobaciones aprobadas. Mantiene compatibilidad de paquetes heredados por POS.
- La batería `npm run check-source` completó sus comprobaciones funcionales, pero su último paso de herramienta NSIS no pudo ejecutarse porque este entorno no tiene `electron-builder` instalado.

Estas pruebas son de código fuente y fixtures aislados. No sustituyen un build Windows, una prueba USB real, una compilación APK ni pruebas de campo.

## Siguiente trabajo obligatorio en ProControl

1. Paquetes de salida cifrados para el dispositivo destinatario y firmados por la instalación; incluir versión de esquema, hash, ID único, POS objetivo y control de repetición.
2. Exportación dirigida de catálogo, precios, tasas e inventario del POS, con el corte de inventario y los permisos vigentes.
3. Contrato de ventas por línea, para que cada producto de una venta pueda usar un método de pago distinto, con conciliación correcta del libro de ventas y del efectivo/divisas.
4. Evidencias de transferencia (teléfono, referencia/operación y captura) asociadas a cada pago, incluidas en el registro y la conciliación de ProControl.
5. Flujo nuevo de despacho/recepción de mercancía: preparar sin descontar inventario, autorización de recepción, confirmación final y aplicación exactamente una vez.
6. Cierre móvil completo: revisión de ventas, conteo físico, efectivo, transferencias, divisas, diferencias e IPV, con confirmación en ProControl.
7. Implementación Android de `.pcpair`, clave de dispositivo, cifrado local, `.pcdevice`, permisos, QR/fragmentos y acuses.
8. Pruebas de extremo a extremo en PC y teléfonos reales y validación del build/instalador.
