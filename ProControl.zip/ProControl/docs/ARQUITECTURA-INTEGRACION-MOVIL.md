# ProControl — arquitectura preparada para futura app móvil

## Estado real

Esta arquitectura prepara el **lado de escritorio** sin afirmar que la app Android ya esté terminada. El puente no abre puertos, no crea servidor y no usa nube. Se añadió la exportación de snapshots `.pcinv` cifrados para un dispositivo autorizado, pero todavía no existe el descifrador Android ni el recorrido probado con teléfono físico. No se modifica el inventario/cierre del PC al exportar.

## Componentes agregados

- `electron/mobile-bridge/store.js`: persistencia SQLite separada (`%APPDATA%/ProControl/mobile-bridge.db`), esquema versionable, códigos de emparejamiento de un solo uso (6 dígitos, 5 minutos), dispositivos/roles, recepción idempotente, hash SHA-256, paquetes pendientes, acuses y auditoría.
- IPC validado en `electron/main.js`: endpoints del puente solo accesibles desde páginas principales `app://` y con licencia de escritorio válida.
- `window.PCMobileBridge` en `electron/preload.js`: interfaz limitada para que la futura UI de escritorio pueda administrar el puente sin exponer Node.js al renderer.
- `tools/test-mobile-bridge.js`: pruebas de emparejamiento, caducidad lógica por esquema, duplicados, conflictos de ID/hash, autorización y decisión de paquete.

## Contrato de paquete v1 (propuesto)

```json
{
  "protocolVersion": 1,
  "packageId": "UUID o ID único estable",
  "deviceId": "ID persistente generado por la app móvil",
  "type": "sale_batch",
  "createdAt": "ISO-8601 UTC",
  "shiftId": "ID de turno",
  "payload": {},
  "payloadHash": "SHA-256 del JSON canónico de payload"
}
```

Tipos iniciales reservados: `inventory_snapshot`, `sale_batch`, `shift_open`, `shift_close`, `transfer`, `return`, `heartbeat`. El contrato es preliminar; al crear la app móvil habrá que versionarlo y validarlo contra sus modelos reales.

## API de escritorio disponible

`window.PCMobileBridge` expone `status()`, `createPairingCode()`, `pairDevice(input)`, `listDevices()`, `setDeviceEnabled(input)`, `receivePackage(input)`, `listPendingPackages()`, `getPackage(packageId)` y `decidePackage(input)`.

Decisiones válidas: `accepted_for_reconciliation`, `rejected`, `conflict`. **Aceptar para conciliación no aplica datos al inventario**; únicamente marca el estado. La integración con POS, ventas y cierres debe añadirse en una fase posterior con transacciones atómicas y pruebas de regresión.

## Seguridad y límites

- Los códigos se almacenan como hash y se consumen una sola vez. El rol queda asociado al código creado desde el escritorio; el dispositivo emparejado no puede asignarse privilegios a sí mismo.
- El enrolamiento v2 incorpora una clave pública RSA del teléfono firmada por su clave Ed25519. Los enrolamientos v1 pueden conservarse, pero no reciben snapshots cifrados.
- Cada dispositivo debe estar registrado y habilitado.
- El hash SHA-256 del payload es obligatorio. Los paquetes repetidos con el mismo ID, dispositivo y hash se reconocen como duplicados; mismo ID con otro dispositivo o contenido se rechaza.
- La recepción y su auditoría se guardan en una transacción. Las decisiones aceptada/rechazada son terminales; los conflictos cuentan como pendientes hasta que se resuelvan.
- Se aplica una matriz mínima de tipos permitidos por rol (operator/supervisor/admin); se deberá revisar con el flujo comercial definitivo al crear la app móvil.
- Los paquetes entrantes firmados mantienen límite de 2 MiB. Los snapshots salientes cifrados tienen límite de contenido de 16 MiB y vencimiento de 24 horas.
- Se guarda auditoría local y no se guardan secretos de nube.
- Los roles son una estructura inicial, no sustituyen aún a los permisos funcionales por operación.
- Los snapshots salientes `.pcinv` ya usan RSA-OAEP-SHA256 + AES-256-GCM y firma Ed25519 de la instalación, dirigidos a una clave RSA del dispositivo registrada en enrolamiento v2. La exportación se guarda como archivo local para traslado USB; no hay listener ni transporte de red.
- El descifrado Android, el intercambio de retorno, la reanudación por fragmentos del paquete cifrado y la aplicación a ventas/cierres siguen pendientes. No habilitar `CON APP` ni `MOBILE_APP_READY` hasta completar esas fases y probar teléfonos reales.

## Siguientes fases al crear la app móvil

1. Confirmar plataforma (Android primero, iOS si corresponde), framework y capacidades de USB/red local.
2. Congelar contrato JSON/CBOR, esquema de productos/unidades, IDs estables y versión del protocolo.
3. Implementar transporte explícito (USB/importación de paquete como primer modo sin red; luego LAN con autenticación mutua), límites, cifrado y reanudación por bloques.
4. Diseñar UI para emparejar, revocar dispositivos, revisar conflictos y conciliar turnos.
5. Integrar ventas individuales con el POS y cierres mediante transacciones y reglas de idempotencia.
6. Probar desconexiones, paquetes duplicados, reloj incorrecto, restauración de respaldo, revocación, dos móviles y migraciones reales.

## Prueba

Ejecutar `node tools/test-mobile-bridge.js` desde `app`. La prueba requiere una versión de Node que incluya `node:sqlite`; la versión integrada con Electron es la referencia de producción. Para comprobar el código antes de compilar, ejecutar `npm run check-source`. Después de generar `dist_final` con `npm run dist`, ejecutar `npm run check` en Windows: esa verificación de publicación requiere el `app.asar` compilado y consulta el identificador del equipo. No se afirma aquí que se haya compilado un instalador Windows.
