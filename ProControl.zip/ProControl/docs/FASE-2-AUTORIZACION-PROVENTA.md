# ProVenta — Fase 2: autorización por instalación y dispositivo

**Estado:** backend y administración inicial implementados en el código fuente; integración Android y entrega de datos todavía bloqueadas.

## Objetivo

Autorizar un teléfono para una instalación concreta de ProControl. La autorización no queda ligada a un POS ni a un turno. La asignación operativa a POS/turno debe resolverse mediante permisos independientes emitidos por ProControl.

## Interfaz de ProControl

En `Punto de Venta`, en la barra lateral izquierda, se añadió **Generar código ProVenta**. La administración solicita credenciales y el proceso principal vuelve a comprobar que la sesión corresponde al rol `Dueño`. El rol Administrador no puede emitir, listar, invalidar ni importar estas autorizaciones mediante los endpoints nuevos.

El registro conserva:

- Identificador de autorización e identidad de la instalación.
- Nombre del trabajador y datos de contacto/referencia cifrados mediante `safeStorage` de Electron.
- Fecha de emisión y vencimiento del código.
- Identificador y etiqueta del dispositivo al completar la vinculación.
- Estado: pendiente, activo, invalidado o sustituido.
- Relación entre autorización anterior y sustituta.

## Identidad de la instalación

El identificador `pcinst_...` se deriva de la huella SHA-256 de la clave pública Ed25519 persistente del puente. Se guarda en `bridge_meta`. Si la clave cambia y deja de coincidir con la identidad guardada, el puente se bloquea con `INSTALLATION_IDENTITY_MISMATCH`; no genera silenciosamente una identidad nueva. La copia de seguridad de la identidad y sus claves sigue siendo importante.

## Contrato de vinculación

1. El Dueño genera una autorización con un código numérico temporal de un solo uso.
2. ProControl puede exportar la ficha firmada `.pcpair` (`procontrol.device-authorization`, versión 1). Contiene identidad de instalación, autorización, trabajador, código, vencimiento y clave pública del escritorio; la firma es Ed25519.
3. La app Android (pendiente de implementar) creará una clave Ed25519 en Android Keystore y un identificador aleatorio local del dispositivo.
4. Android construirá una solicitud `.pcdevice` (`procontrol.device-enrollment-request`, versión 1) con identidad de instalación, autorización, código, ID/etiqueta del dispositivo, clave pública Android y firma Ed25519 del dispositivo.
5. El Dueño importa el archivo `.pcdevice` por USB. ProControl valida formato, instalación exacta, clave y firma del teléfono, código no vencido/no consumido y autorización pendiente. El uso del código se consume atómicamente.
6. Si es una sustitución, el dispositivo previo queda deshabilitado y la autorización anterior pasa a `superseded` cuando el nuevo teléfono completa la vinculación.

**Duración provisional:** el código conserva el TTL de cinco minutos que ya utilizaba el puente heredado. Es un valor implementado para esta fase, pendiente de confirmar como política definitiva. No es una decisión funcional permanente aprobada por el usuario.

## Teléfono perdido o roto

El botón **Teléfono perdido / roto** primero invalida la autorización anterior y después prepara la sustitución. Esto evita dejar activo el teléfono anterior durante la espera del nuevo. Una vez vinculado el reemplazo, la autorización anterior se marca como sustituida y su dispositivo permanece deshabilitado.

## Rechazo de otras instalaciones y revocación

- Una ficha emitida por otra instalación falla por `INSTALLATION_MISMATCH`.
- Solicitudes de enrolamiento sin firma válida o con contenido alterado se rechazan.
- Un código se consume una sola vez; una segunda importación se rechaza.
- Un dispositivo invalidado no se puede reactivar desde el interruptor heredado.
- Los dispositivos históricos ligados a POS se conservan como registros heredados; no se convierten silenciosamente en autorización por instalación.

## Protección temporal de datos

Se han deshabilitado los IPC heredados para alta POS y los IPC genéricos de exportación de paquetes de catálogo/inventario. Los paquetes de datos de ProControl todavía no están cifrados y ligados a un dispositivo destinatario concreto, por lo que no deben exportarse a USB/QR hasta implementar y probar esa protección. La importación de paquetes firmados desde un teléfono existente sigue separada y valida el dispositivo autorizado.

No se ha habilitado `MOBILE_APP_READY` ni el modo `CON APP`. Esta fase no entrega inventario, catálogo ni datos de la empresa a ningún teléfono.

## Límite de revocación offline

Si un teléfono ya recibió datos y permanece desconectado, ProControl no puede borrar instantáneamente esos datos de forma remota. La revocación bloquea futuras entregas y operaciones cuando vuelva a existir intercambio con ProControl. La app Android debe cifrar su base local y proteger las claves con Android Keystore; no se debe prometer borrado remoto estando desconectada.

## Migración

Las columnas se agregan con migraciones compatibles (`_ensureColumn`). Los registros POS heredados mantienen sus campos `pos_id`; no se borran. La nueva tabla `device_authorizations` es independiente. No se debe borrar la base de datos de puente ni regenerar claves para aplicar esta fase.

## Validación realizada en entorno de desarrollo

- `test-mobile-bridge.js`: 37 aserciones.
- `test-proventa-authorization.js`: 36 aserciones.
- `test-proventa-authorization-ui.js`: 24 aserciones.
- `test-mobile-bridge-ui.js`: 41 aserciones en la entrega acumulada de Fases 2–3.
- `test-mobile-control-plane.js`: 39 aserciones en la entrega acumulada de Fases 2–3.
- `test-phase4-6-hardening.js`: 35 aserciones.
- `test-phase7-9.js`: 17 aserciones.
- `test-offline-recovery.js`: 14 aserciones.
- `test-sales-write-policy.js`: 22 aserciones.
- `test-local-qr.js`: 8 aserciones.
- `test-package-fragments.js`: 8 aserciones.
- `check-source-syntax.js`: 78 archivos JavaScript y 6 scripts inline.

Estos son tests automatizados de código fuente en Node.js. No equivalen a una compilación de Electron/Windows, ni a una prueba Android real, ni a una prueba USB con teléfonos físicos.

## Pendiente para la siguiente fase

1. Implementar el lector `.pcpair` y la generación `.pcdevice` desde Android Keystore.
2. Probar el ciclo completo PC → USB → Android → USB → PC.
3. Cifrar y ligar cada paquete de datos saliente al identificador del dispositivo autorizado y a la identidad de instalación.
4. La separación de autorización por instalación y permiso operativo POS/turno se implementa en la Fase 3; véase `FASE-3-ALCANCE-POS-PERMISOS-PROVENTA.md`.
5. No habilitar importación de inventario/ventas en Android hasta implementar el cifrado dirigido y validar el ciclo de extremo a extremo.
