# ProControl — Copias de seguridad y recuperación

## Antes de copiar o restaurar

1. Cierra ProControl por completo.
2. Verifica que no haya procesos de ProControl/Electron usando la base de datos.
3. Usa una unidad protegida y con espacio suficiente.
4. No envíes las copias de seguridad por canales públicos: contienen datos del negocio.

## Crear una copia verificada

Desde PowerShell:

```powershell
cd D:\ProControl\app
.\tools\backup-procontrol.ps1 -Destination 'E:\Backups\ProControl'
```

El script guarda una carpeta fechada con `manifest.json` y hashes SHA-256. Copia los archivos de datos de `%APPDATA%\ProControl` que estén presentes y la identidad pública del puente. Si hay clave privada de firma del puente, la protege con DPAPI para el usuario Windows actual. No copia la licencia comercial ni la clave privada que firma licencias.

Verifica que se creó `manifest.json`, que los archivos declarados están presentes y conserva una segunda copia separada. No edites manualmente el manifiesto o los archivos respaldados.

## Restaurar una copia

Restaurar sobrescribe los archivos de datos permitidos y debe hacerse únicamente cuando ProControl está cerrado. Antes de copiar, el script verifica todos los hashes y crea una carpeta `ProControl-PreRestore-...` con los datos actuales.

```powershell
cd D:\ProControl\app
.\tools\restore-procontrol.ps1 -BackupPath 'E:\Backups\ProControl\ProControl-Backup-AAAAmmdd-HHmmss'
```

Sustituye el ejemplo por la ruta real. La clave privada del puente protegida con DPAPI solo puede recuperarse bajo la misma cuenta de Windows. Si cambiaste de cuenta o de equipo, no elimines una identidad de firma anterior sin planear el reemparejamiento de los teléfonos futuros.

## Validación posterior

Abre ProControl y comprueba inventario, compras, POS, tickets, cierres y auditoría. Comprueba el estado del puente, los dispositivos y los paquetes pendientes. Si aparece una diferencia entre base de datos y existencias, detén las operaciones y conserva la carpeta previa a la restauración. No recrees tickets ni importes otra vez un paquete para “arreglar” el estado, porque podría duplicar movimientos.

## Limitaciones

Este script es una protección local, no sustituye una política completa de backup 3-2-1 ni un simulacro profesional de recuperación. Debe probarse en Windows con una copia de prueba antes de confiarle la recuperación de datos de producción. No es compatible entre usuarios de Windows para recuperar la clave DPAPI del puente.
