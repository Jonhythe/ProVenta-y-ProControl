# Política de Soporte — ProControl

## Reemisión de licencia tras formateo o cambio de PC

Cuando un cliente formatea su PC o cambia de equipo, el **MachineGuid de Windows cambia** y la licencia anterior deja de ser válida (está ligada al ID de la PC). El proceso de reemisión es:

1. **Verificar al cliente**: buscar en `licensor/registro-ventas.csv` por el nombre del cliente.
2. **Confirmar identidad**: el cliente debe proporcionar el **nuevo ID de PC** (32 caracteres hexadecimales que muestra la pantalla de activación al instalar).
3. **Emitir nueva licencia**: usar `licensor/emitir-licencia.js` con el nuevo ID y el mismo nombre de cliente.
   - Si es la **1ª o 2ª reemisión en 12 meses**: se emite gratis (usar `--force` si el script lo pide).
   - Si son **3 o más reemisiones en 12 meses**: se cobra según tarifa vigente (el script avisará y exigirá `--force`).

## Respaldos de datos — Responsabilidad del cliente

> **IMPORTANTE**: Formatear la unidad C: **borra `%APPDATA%\ProControl`** y con él la base de datos (`procontrol.db`), la licencia (`license.dat`) y cualquier dato del negocio (inventario, ventas, compras, cierres de caja, personal, historial).

**El vendedor NO tiene acceso a los datos del cliente** (la app es 100% offline y local). Por eso es obligatorio que el cliente:

- Haga respaldos periódicos de la carpeta `%APPDATA%\ProControl` en **otra unidad física** (pendrive, disco externo, nube propia).
- Antes de formatear o cambiar de PC, copie esa carpeta completa a un lugar seguro.
- Tras reinstalar, pueda restaurar la carpeta para recuperar su historial.

La licencia se puede reemitir (ver arriba), **pero los datos de negocio NO se recuperan si no hay respaldo**.

## Contacto de soporte

- **Jonathan Sotero** — WhatsApp: **+53 56464332**
- Horario: lunes a sábado, 9:00–18:00 (hora de Cuba).
- Para reemisiones: enviar nombre del cliente + nuevo ID de PC (botón "Copiar" en la pantalla azul).