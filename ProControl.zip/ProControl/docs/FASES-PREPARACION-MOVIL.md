# Preparación antes de crear la app móvil

| Fase | Estado | Resultado / pendiente |
|---|---|---|
| 1. Aislar almacenamiento de integración | Preparada | SQLite separado de datos comerciales. |
| 2. Emparejamiento básico | Preparada | Código de un uso y vencimiento de 5 min; UI/QR todavía pendientes. |
| 3. Registro y revocación de dispositivo | Preparada en backend | Roles iniciales; permisos detallados por acción pendientes. |
| 4. Paquetes cifrados y snapshot | Parcial en escritorio | Enrolamiento v2 con RSA del dispositivo y exportación `.pcinv` cifrada/firmada, limitada al POS seleccionado. Descifrado Android pendiente. |
| 5. Cola de recepción/acuse | Preparada | Paquetes quedan pendientes; aún no se aplican al POS. |
| 6. Transporte USB/LAN | Parcial | Exportación local `.pcinv` para traslado por USB; importación/descifrado Android y recepción de vuelta pendientes. No hay LAN ni Wi-Fi. |
| 7. QR de emparejamiento y confirmación | No implementada | Requiere UI y definir flujo entre dispositivos. |
| 8. Ventas individuales y conciliación | No implementada | Requiere integración con modelos y cierres existentes. |
| 9. Turnos, transferencias, devoluciones y emergencia offline | Contratos iniciales solamente | Reglas comerciales y recuperación pendientes. |
| 10. Pruebas de extremo a extremo y migración | Parcial | Pruebas unitarias del puente; sin app móvil ni pruebas en Windows real. |

No se debe interpretar “preparada” como “integración completa”. La base está diseñada para poder ampliarse cuando exista la app móvil sin obligar a rehacer el sistema de licencias o la base comercial.
