# ProControl — Parte 3: fases 7, 8 y 9

**Estado:** candidato para integración en copia de prueba. El código fuente y las pruebas automatizadas se han ejecutado en un entorno Linux/Node. No se afirma que el instalador Windows ni una app móvil real hayan sido probados.

## Alcance

### Fase 7 — Modo por punto de venta y corte de inventario

- Se expone el control de modo desde la frontera IPC de Electron; las llamadas privilegiadas requieren sesión autenticada Dueño/Administrador y validación del POS actual.
- La política se registra por POS, nunca como un interruptor global de toda la instalación.
- La interfaz muestra el modo y los requisitos. Si encuentra un POS en `CON APP`, ofrece una ruta auditada para devolverlo a `SIN APP` sin borrar historiales.
- `CON APP` permanece **bloqueado en el proceso principal** mediante `MOBILE_APP_READY = false`; tener una caja licenciada, un hash de respaldo o un snapshot entregado desde el renderer no puede activar el modo.
- No se crea un snapshot operativo ni se congela stock como efecto lateral de abrir la pantalla. El corte real requerirá la app móvil y un procedimiento en Windows probado de backup, conteo físico, hash de respaldo y conciliación.

### Fase 8 — Intercambio offline, fragmentos y QR local

- Exportación/importación por archivo y USB; no se abren puertos ni se añade transporte de red.
- Los paquetes `.pcpkg` conservan su firma Ed25519 y su revisión explícita. Cuando se exportan como fragmentos, el conjunto incluye `.pcmanifest` y archivos `.pcfrag` con hash SHA-256 por pieza y hash total.
- El receptor valida forma, nombres sin rutas, cantidad, tamaño, orden, hash de cada fragmento y hash total antes de reconstruir y pasar el paquete al verificador de firma existente. Si falta una pieza o una huella no coincide, no se registra ni aplica el paquete.
- Se añade acuse persistente `procontrol.package-ack` firmado con la clave pública/privada del puente de escritorio. Solo puede crearse para un paquete en estado terminal (`reconciled`, `rejected` o `conflict`) y se verifica contra el estado y hash almacenados.
- Los acuses se guardan en SQLite para poder reabrirlos y exportarlos de nuevo; el fichero `.pcack` se escribe sin sobrescribir otro archivo.
- Se incorpora un generador QR local sin CDN ni servicios externos. El QR transporta fragmentos compactos de permisos o acuses; nunca paquetes comerciales completos. Cada QR usa el prefijo `PCQ1`, tipo (`P` permiso / `A` acuse), referencia corta, índice/conteo y un fragmento base64url. El receptor debe reconstruir todos los segmentos y verificar la firma Ed25519 del documento completo.
- No existe aún el decodificador de QR de la app móvil; no se declara validado el flujo de lectura real ni la eliminación segura de datos del móvil tras el acuse.

### Fase 9 — Validación integrada y publicación segura

- Se agregan pruebas de sintaxis, fragmentos, firma/alcance de acuses, bloqueos de modo y transporte local.
- El script `app/tools/validate-windows-release.ps1` ejecuta en Windows la batería de fuente, construye la distribución y ejecuta el escáner anti-secretos sobre `dist_final/win-unpacked/resources/app.asar`.
- `npm run check` se define como comprobación de release y debe ejecutarse después de `npm run dist` (o mediante el script PowerShell).
- El manifiesto de esta entrega enumera exactamente los archivos que se reemplazan y los que se crean.

## Pruebas ejecutadas en el entorno disponible

- `npm run check-source`: aprobado, incluida la batería preexistente.
- `test-local-qr.js`: 8 aserciones, generador y reconstrucción de fragmentos.
- `test-package-fragments.js`: 8 aserciones, reensamblaje exacto, hash por fragmento, ausencia de pieza, manifestación manipulada y no sobrescritura.
- `test-phase7-9.js`: 17 aserciones de modo fail-closed, firma, persistencia e idempotencia de acuses, integridad del acuse y cableado de IPC.
- Se decodificó con un lector QR de prueba un fragmento real `PCQ1` producido por el generador local.

## Pendiente antes de publicación

1. Ejecutar `app/tools/validate-windows-release.ps1` en Windows con las dependencias instaladas.
2. Probar una instalación limpia y una actualización, restaurar un respaldo real de prueba y confirmar las rutas de `app.asar`.
3. Hacer revisión manual del panel, exportar/leer un `.pcmanifest` con una memoria USB y probar recuperación ante interrupción.
4. Desarrollar la app móvil real, su lector/reensamblador QR y su verificación del acuse. Mantener `CON APP` y emisión de permisos operativos bloqueados hasta la aceptación de extremo a extremo.
5. Resolver la rotación de la clave privada de licencias detectada en una carga anterior antes de emitir la primera licencia a un usuario externo. Esta entrega no contiene claves privadas ni ejecuta esa rotación.

## Instalación de prueba y rollback

1. Cerrar ProControl y crear un respaldo verificable de `D:\ProControl` y `%APPDATA%\ProControl`.
2. Trabajar sobre una copia de prueba que ya contenga Parte 1 **Validada** y Parte 2 (fases 4–6). No mezclar la Parte 1 Reconciliada ni aplicar esta Parte 3 directamente sobre el ZIP original.
3. Extraer este parche en una carpeta temporal. Copiar solamente las rutas `app\...` listadas en `MANIFIESTO-PARTE3.txt` bajo la raíz `D:\ProControl` de la copia de prueba.
4. En `D:\ProControl\app`, ejecutar `npm run check-source`. Para validación de release, en Windows ejecutar `powershell -ExecutionPolicy Bypass -File .\tools\validate-windows-release.ps1`.
5. Si falla una prueba, cerrar la aplicación y restaurar los archivos de código desde el respaldo de esa copia. No restaurar encima de datos comerciales más recientes sin evaluar la diferencia.

El ZIP no contiene bases de datos, `license.dat`, claves privadas del emisor, `node_modules`, instaladores ni `app.asar`.
