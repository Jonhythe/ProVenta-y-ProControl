# ProControl — Revisión de experiencia y análisis (Parte 2)

**Fecha:** 28 de octubre de 2026  
**Base:** `ProControl_Parte1_BaseEconomica.zip`, candidato de código fuente 1.2.0  
**Estado:** pruebas automatizadas aprobadas; la validación visual/operativa en Windows sigue pendiente.

## Objetivo

Aplicar las funciones A–E acordadas sin convertir el módulo en una pantalla saturada. El principio seguido es mostrar primero el estado y las próximas acciones; esconder los detalles hasta que el usuario los solicite y nunca convertir datos desconocidos en cifras aparentemente reales.

## Cambios incluidos

1. **Navegación simplificada:** se agruparon las ocho rutas anteriores en seis secciones principales: Resumen, Dinero y movimientos, Cuentas pendientes, Proveedores y monedas, Análisis e Historial y copias. Las cuentas por cobrar/pagar y los proveedores/tasas se alternan dentro de su sección para reducir la cantidad de botones principales.
2. **A — Semáforo de salud:** reemplaza la puntuación visual opaca por estados explicables: necesita atención urgente, hay asuntos por revisar, datos insuficientes o sin alertas principales. El estado urgente se activa ante liquidez estimada negativa; vencimientos, operaciones pendientes y reposiciones generan atención. Si faltan datos, el módulo no declara estabilidad por defecto. Los motivos se pueden desplegar.
3. **Resumen despejado:** mantiene tres indicadores principales (dinero registrado en cuentas CUP, compromisos por pagar y disponible estimado tras compromisos). Las cuentas, puntos de venta y lista de reposición aparecen en secciones plegables.
4. **B — ABC y movimiento del inventario:** el ABC prioriza importes de ventas que existen en el libro local. Las devoluciones afectan el valor neto. No se inventan ingresos multiplicando unidades por el precio actual ni se suman importes nativos con monedas desconocidas. Los productos sin valor de ventas positivo aparecen como «Sin datos», no como clase A por accidente. El análisis de movimiento distingue falta de historial de una última venta antigua; la falta de registros no declara que un producto esté obsoleto.
5. **C — Simuladores:** el simulador de liquidez precarga dinero y compromisos solamente cuando proceden de los datos disponibles; cuando falta una tasa, deja el campo correspondiente vacío. Las entradas desconocidas de los simuladores de precio y reposición también se dejan vacías. Todos los simuladores explican sus supuestos y no modifican dinero, precios ni existencias.
6. **D — Comparación entre puntos de venta:** permanece bajo una sección plegable y conserva las monedas separadas. Solo se atribuyen movimientos a sucursales cuando las cuentas están asociadas a ellas.
7. **E — Historial explicable:** la vista muestra inicialmente los 50 cambios más recientes e incorpora una búsqueda que encuentra coincidencias en todo el historial almacenado. El respaldo/restauración queda plegado para no competir con la consulta diaria.
8. **Accesibilidad y legibilidad:** se añadieron indicadores de enfoque visibles, estados de salud con contraste, instrucciones breves y navegación adaptable a pantallas estrechas.
9. **Validación:** se ampliaron las pruebas de Gestión Empresarial de 30 a 41 comprobaciones, cubriendo semáforo, datos insuficientes, moneda, devolución, ABC, historial de ventas y navegación.

## Verificación realizada

- `node --check app/renderer/business-management.js`: correcto.
- `npm run check-source`: completado correctamente, incluyendo el análisis de sintaxis de la fuente y la batería de pruebas existente y ampliada.
- `node tools/test-business-management.js`: 41 pruebas aprobadas, 0 fallidas.
- El manifiesto de SHA-256 se vuelve a generar para este ZIP.

## Límites y tareas pendientes

- **No se compiló ni instaló Electron en Windows**: el paquete de código fuente no incluye `node_modules`, `app.asar` ni instaladores. No se declara validación visual o manual de las pantallas.
- La verificación del lanzamiento debe incluir la apertura del módulo, navegación, altas y liquidaciones, rol de solo lectura, transacción con segunda autorización, búsquedas de auditoría, exportación/restauración, ventas, cierres y recuperación de datos.
- El escaneo de publicación que exige el `app.asar` de `dist_final` no se puede considerar aprobado sin construir primero el artefacto.
- La rotación de la clave de licencias es un bloqueador independiente: el ZIP no contiene la clave privada ni el registro de licencias y conserva `licensor/ROTACION-CLAVE-REQUERIDA.txt`. No distribuyas ni emitas licencias con esta compilación hasta rotar y probar en una copia privada.
- Los perfiles Esencial, Gestión y Empresa siguen siendo perfiles futuros de una sola base de código, no tres aplicaciones implementadas en esta entrega.
- La automatización fiscal permanece excluida. Márgenes y liquidez son estimaciones limitadas por los datos introducidos; no incluyen gastos variables que no estén registrados ni sustituyen contabilidad profesional.

## Uso de la entrega

Extrae el ZIP en una carpeta de prueba separada. No sobrescribas la instalación funcional ni su base de datos. Primero abre el informe de la Parte 1 y el aviso de rotación de claves; después ejecuta las pruebas y la verificación manual en Windows siguiendo el checklist de pruebas manuales del proyecto.
