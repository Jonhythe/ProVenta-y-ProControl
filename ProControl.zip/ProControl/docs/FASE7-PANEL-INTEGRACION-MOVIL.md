# ProControl — Fase 7: Panel de integración móvil

## Objetivo
Añadir una interfaz de escritorio para administrar la base local del puente móvil sin activar red, USB ni sincronización comercial automática.

## Archivos
- `electron/main.js` — reemplazar; bloquea la emisión de códigos con rol `admin` hasta completar la autorización segura de roles.
- `renderer/index.html` — reemplazar; incorpora la entrada de Administración, el panel y la carga del módulo.
- `renderer/mobile-bridge-ui.js` — nuevo; gestiona la UI de emparejamiento, dispositivos y paquetes.
- `tools/test-mobile-bridge-ui.js` — nuevo; pruebas estáticas y smoke tests de la UI con un puente simulado.
- `docs/FASE7-PANEL-INTEGRACION-MOVIL.md` — nuevo.

No hay dependencias nuevas. No se modifican `main.js`, `preload.js`, `package.json`, `package-lock.json`, archivos de licencias ni la base comercial.

## Funciones
- Estado local del puente y conteo de dispositivos/paquetes.
- Generación y copia de un código de emparejamiento de seis dígitos con expiración de cinco minutos.
- Lista y habilitación/revocación de dispositivos ya emparejados.
- Inspección de paquetes pendientes, aceptación para conciliación, marca de conflicto o rechazo.
- Confirmaciones explícitas antes de cambiar el estado de un dispositivo o paquete.
- La UI solo permite entrar a Dueño/Administrador mediante `Auth.requireRole`; esto todavía no reemplaza una sesión autenticada validada por el proceso principal.

## Límites importantes
- La app móvil todavía no existe; por tanto, no puede emparejarse un teléfono real mediante este panel.
- No se genera QR ni se activa transporte USB/LAN. La conexión de transporte se implementará y probará con el código real de la futura app móvil.
- La decisión `accepted_for_reconciliation` solo marca el paquete; no aplica datos a inventario o cierres.
- El rol `admin` no puede asignarse mediante código de emparejamiento hasta implementar autorización segura de usuarios/roles. Operador y Supervisor sí están disponibles. El panel es una interfaz de administración, no sustituye una política completa de autorización por usuario/rol en el backend. No distribuir el producto como sincronización móvil operativa hasta completar autenticación/autorización, transporte autenticado y pruebas de extremo a extremo.

## Pruebas
Ejecutar en PowerShell desde `D:\ProControl\app`:

```powershell
node tools/test-mobile-bridge-ui.js
node tools/test-mobile-bridge.js
npm run check-source
npm start
```

Al estar en un entorno sin la GUI de Windows, la prueba automatizada de la interfaz simula la API. La prueba definitiva de la ventana debe hacerse en Windows.

## Ruta después de la Fase 7
- **Fase 8:** intercambio seguro de paquetes, empezando por importación/exportación explícita por archivo; transporte de red queda bloqueado hasta implementar cifrado y autenticación mutua.
- **Fase 9:** conciliación de turnos y operaciones comerciales (ventas, transferencias, devoluciones y modo offline) con autorización backend.
- **Fase 10:** pruebas completas de restauración/migración, duplicados, interrupciones, instalador Windows y app móvil real cuando esté creada.

Quedan tres fases generales planeadas después de la Fase 7. La app móvil completa se construirá como un proyecto separado y tendrá que probarse contra este contrato; no se considera incluida en esta entrega.
