# Checklist de Pruebas Manuales — ProControl 1.1.0

> Estas pruebas **NO se pueden automatizar** completamente. Ejecútelas en una VM limpia u otra PC física antes de entregar a clientes.

---

## Entorno de prueba recomendado

- **VM limpia**: Windows 10/11 64-bit, sin ProControl previo, sin antivirus de terceros (solo Defender).
- **Red**: con internet (para probar WhatsApp) pero la app funciona 100% offline.
- **Licencia de prueba**: genere una con `node licensor/emitir-licencia.js <ID> "Cliente Prueba" --dias 30` usando el ID de la VM.

---

## 1. Instalación limpia

| Paso | Acción | Resultado esperado |
|---|---|---|
| 1.1 | Ejecutar `ProControl Setup 1.1.0.exe` | Se abre instalador NSIS |
| 1.2 | SmartScreen: "Más info" → "Ejecutar" | Instalador continua |
| 1.3 | Elegir carpeta (predeterminada) → Siguiente | Copia archivos sin página de activación |
| 1.4 | Finalizar → "Ejecutar ProControl" | App abre pantalla azul de licencia |
| 1.5 | Verificar: NO hay página de activación en el instalador | ✅ |

---

## 2. Activación con licencia real

| Paso | Acción | Resultado esperado |
|---|---|---|
| 2.1 | En pantalla azul: botón 📋 Copiar ID | ID copiado al portapapeles (32 hex) |
| 2.2 | Enviar ID al soporte → recibir licencia `PCL1....` | Licencia válida para ese ID |
| 2.3 | Pegar licencia en textarea → "Activar licencia" | "✅ Licencia activada" → splash → login |
| 2.4 | Verificar: `license.dat` creado en `%APPDATA%\ProControl\` | JSON con clave `license` |
| 2.5 | Cerrar app y volver a abrir | Va directo a splash → login (sin pedir licencia) |

---

## 3. Activación por archivo .lic

| Paso | Acción | Resultado esperado |
|---|---|---|
| 3.1 | Guardar licencia recibida como `mi-licencia.lic` | Archivo de texto con PCL1... |
| 3.2 | En pantalla azul: botón "📂 Elegir archivo .lic" | Diálogo abre, filtra `*.lic` |
| 3.3 | Seleccionar archivo → Activar | Licencia activada igual que pegando texto |

---

## 4. Errores de activación (verificar mensajes)

| Caso | Entrada | Mensaje esperado |
|---|---|---|
| 4.1 | Texto vacío | "Pegue la licencia o elija un archivo .lic." |
| 4.2 | Basura (`abc123`) | "La licencia no tiene el formato correcto." |
| 4.3 | Licencia de otra PC | "Esta licencia fue emitida para otra PC." |
| 4.4 | Licencia alterada (cambiar 1 char) | "La licencia no es válida o fue modificada." |
| 4.5 | Licencia trial vencida | "La licencia de prueba ya venció." |
| 4.6 | ID ilegible (simular fallo reg.exe) | "No se pudo leer el identificador de esta PC." |

---

## 5. Flujo completo con datos

| Paso | Acción | Resultado esperado |
|---|---|---|
| 5.1 | Login: crear usuario + contraseña | Crea BD en `%APPDATA%\ProControl\procontrol.db` |
| 5.2 | Dashboard: ver KPIs en cero | Sin errores |
| 5.3 | Compras: agregar proveedor + compra | Guarda en SQLite |
| 5.4 | Inventario: agregar producto + stock | Guarda |
| 5.5 | POS: venta rápida + imprimir ticket | Ventana impresión abre, diálogo Windows |
| 5.6 | Cierre de caja: registrar arqueo | Guarda |
| 5.7 | Historial: ver movimientos | Lista datos |
| 5.8 | Personal: agregar trabajador | Guarda |
| 5.9 | Salir por botón puerta → confirmar | App cierra limpio |

---

## 6. Actualización encima (overwrite install)

| Paso | Acción | Resultado esperado |
|---|---|---|
| 6.1 | Con app cerrada, ejecutar `ProControl Setup 1.1.0.exe` otra vez | Instalador detecta versión previa |
| 6.2 | Elegir misma carpeta → Siguiente | Actualiza archivos |
| 6.3 | Abrir app | Licencia sigue válida, datos intactos, versión 1.1.0 |

---

## 7. Desinstalación

| Paso | Acción | Resultado esperado |
|---|---|---|
| 7.1 | Ejecutar `Uninstall-ProControl.exe` (como admin) | Modal SI/NO/CANCELAR |
| 7.2 | Opción **NO** (conservar datos) | Borra programa, accesos, registro. **Mantiene** `%APPDATA%\ProControl` y `%APPDATA%\procontrol-desktop` |
| 7.3 | Reinstalar → abrir app | Licencia y datos siguen ahí |
| 7.4 | Ejecutar `Uninstall-ProControl.exe` → **SÍ** (borrar todo) | Borra programa, accesos, registro, **`%APPDATA%\ProControl` Y `%APPDATA%\procontrol-desktop`** |
| 7.4 | Reinstalar → abrir app | Pide licencia de nuevo (pantalla azul) |

---

## 8. Formateo / Cambio de PC (Reemisión)

| Paso | Acción | Resultado esperado |
|---|---|---|
| 8.1 | En PC original: respaldar `%APPDATA%\ProControl` a USB | Carpeta copiada |
| 8.2 | Formatear PC / usar otra PC | Windows nuevo, MachineGuid nuevo |
| 8.3 | Instalar ProControl en PC nueva | Pantalla azul con **nuevo ID** |
| 8.4 | Enviar nuevo ID a soporte → reemisión gratis (1-2/año) | Nueva licencia `PCL1...` para nuevo ID |
| 8.5 | Activar en PC nueva | Entra al sistema |
| 8.6 | Restaurar carpeta `ProControl` desde USB a `%APPDATA%\ProControl` | Datos de negocio recuperados (inventario, ventas, etc.) |

---

## 9. Portable

| Paso | Acción | Resultado esperado |
|---|---|---|
| 9.1 | Copiar `ProControl-1.1.0-portable.exe` a USB | Archivo único |
| 9.2 | En PC limpia: ejecutar desde USB | Abre pantalla azul (sin licencia) |
| 9.3 | Activar con licencia válida para ese ID | Splash → login |
| 9.4 | Usar app, cerrar | Datos en `%APPDATA%\ProControl` (no en USB) |
| 9.5 | En otra PC: mismo USB, ejecutar | Pide licencia (ID distinto) |

---

## 10. Verificaciones de seguridad

| Verificación | Cómo comprobar | OK |
|---|---|---|
| 10.1 | `license.dat` NO contiene claves viejas (`payload`/`sig`) | ☐ |
| 10.2 | `app.asar` no tiene `TOTP_SECRET`, `LICENSE_HMAC`, `PC_SECRET` | ☐ (check-no-secrets.js) |
| 10.3 | Instalador NSIS no pide código | ☐ |
| 10.4 | `userData` = `%APPDATA%\ProControl` (no `procontrol-desktop`) | ☐ |
| 10.5 | `license.html` usa textarea + botón .lic + copiar ID + WhatsApp | ☐ |
| 10.6 | Fuses activados (runAsNode=false, onlyLoadAppFromAsar=true, etc.) | ☐ |
| 10.7 | Desinstalador SÍ borra `%APPDATA%\procontrol-desktop` | ☐ |

---

## Firma del probador

| Campo | Valor |
|---|---|
| Nombre | |
| Fecha | |
| VM / PC usada | |
| Licencia de prueba usada (ID) | |
| Resultado global | **PASS / FAIL** |
| Observaciones | |

---

**Nota**: Si alguna prueba falla, registre el fallo en `AUDITORIA-LOG.md` y corrija antes de entregar.