# Lista rápida para la demostración de ProControl — miércoles 28 de octubre de 2026

Esta lista prioriza mostrar la aplicación de PC sin poner en riesgo los datos ni instalar una compilación no validada a última hora.

## Antes de salir

- [ ] Abre la versión de ProControl para PC que ya sabes que funciona; no cambies archivos de la instalación principal a última hora.
- [ ] Cierra la aplicación y copia `%APPDATA%\ProControl` a un respaldo privado. No envíes ese respaldo por correo ni lo incluyas en un ZIP.
- [ ] Abre ProControl de nuevo y confirma que llega al panel principal sin error.
- [ ] Comprueba la navegación principal: inventario, compras, POS/ventas, ticket o impresión, historial, devoluciones, transferencias y cierre de caja.
- [ ] Si vas a probar operaciones, usa productos/valores de demostración o una copia de datos. No crees ventas ficticias en una caja con contabilidad real.
- [ ] Confirma que efectivo y transferencia se muestran por separado y que la tasa USD corresponde al cierre que estás demostrando.
- [ ] Verifica que el respaldo se pueda localizar y que conoces el procedimiento de restauración.

## Cómo presentar la app móvil

- [ ] La PC es el producto que se presenta y usa en esta primera etapa.
- [ ] Si aparece la opción móvil, explica que figura como **próxima actualización** y no está disponible todavía.
- [ ] No actives `CON APP`, no generes permisos para uso operativo y no prometas sincronización móvil activa.
- [ ] No instales la compilación candidata al cliente ni emitas licencias nuevas hasta completar la rotación local de la clave y la validación automatizada/manual en Windows.

## Después de la demostración

- [ ] Integrar el candidato en una copia de pruebas de Windows.
- [ ] Resolver la rotación de la clave privada de licencias; generar la clave nueva únicamente en la PC del propietario.
- [ ] Ejecutar las pruebas de fuente y el validador de publicación Windows.
- [ ] Validar una instalación limpia y una restauración real antes de entregar una compilación al cliente.
- [ ] Desarrollar la aplicación móvil y completar pruebas reales de ida y vuelta antes de activar `CON APP`.
