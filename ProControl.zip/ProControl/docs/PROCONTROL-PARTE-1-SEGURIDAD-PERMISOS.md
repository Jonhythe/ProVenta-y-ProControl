# ProControl — Parte 1: fases 1–3

## Alcance de esta entrega

Paquete de superposición basado en el código fuente que se recibió para revisión. Refuerza la protección de la identidad local del puente, la autorización de ventas en el proceso principal, la identidad estable de los productos, la conservación de agotados y transferencias con estados, y las licencias por punto de venta. No contiene la base comercial, `license.dat` ni la clave privada del emisor.

## Puerta de seguridad obligatoria: clave del emisor

El ZIP de origen incluía una clave privada Ed25519 de firma de licencias coincidente con su clave pública. Debe considerarse expuesta. Por esa razón se incluye `licensor/ROTACION-CLAVE-REQUERIDA.txt` y ambos emisores quedan bloqueados antes de generar licencias. No elimines ese bloqueo hasta rotar la clave con `node licensor/gen-license-keys.js --force`, verificar la clave pública en `app/electron/license-config.js` y `licensor/license_public.pem`, y probar firma/verificación. El generador exige que el bloqueo exista, respalda únicamente la configuración pública anterior, no respalda la clave privada expuesta y no quita el bloqueo. La rotación hará que licencias locales firmadas con la clave anterior dejen de validar; reemite cualquier licencia de prueba propia después de actualizar la clave. No se han emitido licencias a terceros según la información disponible, pero la licencia local que ya uses debe comprobarse antes de rotar.

La clave privada nueva debe permanecer únicamente en `licensor/private/license_private.pem`. No debe incluirse en ZIP de entrega, instalador, `app/`, repositorios ni respaldos compartidos. La carpeta `licensor/private` y su contenido no forman parte de este parche.

## Migración de identidad de productos

La migración de IDs **no se ejecuta al arrancar la interfaz**. Primero analiza los almacenes y detiene el proceso si ve nombres duplicados ambiguos, conflictos entre IDs, referencias rotas o tickets que no puede vincular con seguridad.

1. Cierra ProControl y crea una copia privada de `%APPDATA%\ProControl`. Trabaja primero con una copia de `procontrol.db`.
2. Desde `D:\ProControl\app`, ejecuta `node tools/check-product-identity-migration.js --db RUTA_DE_LA_COPIA.db --out RUTA_INFORME.json`. El modo predeterminado es solo lectura. Código de salida `2` indica que necesita revisión manual.
3. No apliques nada mientras el informe tenga conflictos. Resolverlos no significa fusionar productos solo porque se llamen igual.
4. Tras aprobar el dry-run, prueba la aplicación sobre otra copia con `node tools/check-product-identity-migration.js --db RUTA_DE_LA_COPIA_DE_PRUEBA.db --apply --confirm-apply=YES`. La herramienta crea y verifica una copia de respaldo antes de escribir, comprueba que la base no cambió entre análisis y aplicación, ejecuta los cambios en una transacción y valida lo persistido.
5. Abre ProControl con la copia de prueba y verifica inventario, ticket histórico, transferencias, devoluciones y cierres. No sustituya todavía la base real hasta hacer esta aceptación.

La migración actual trabaja sobre SQLite (`procontrol.db`). Si la instalación activa usa el almacén JSON de compatibilidad, no ejecutes esta herramienta contra él; primero debe definirse un procedimiento específico para ese backend.

## Seguridad del puente

Cuando una función de puente se utiliza en Electron, `safeStorage` protege la clave privada local con el mecanismo del sistema operativo en Windows. La migración conserva la identidad solo si la clave privada, la pública y la prueba de firma/verificación coinciden. Se conserva un respaldo cifrado verificado antes de borrar el PEM antiguo. Si falla una comprobación, el proceso se detiene; no debe generar una nueva identidad como sustitución automática.

La clave del puente móvil es distinta de la clave Ed25519 que firma licencias PCL1. La privada de licencias no se cifra con el mecanismo de clave del puente ni se copia a la app instalada.

## Licencias y modos

- Las licencias PCL1 antiguas sin tipo explícito siguen tratándose como licencias de instalación.
- Las licencias POS incluyen `posId` estable, `deviceId` e `installationMachineId`; el nombre visible del POS es descriptivo y puede cambiar sin alterar su identidad.
- La aplicación debe comprobar la autorización en el proceso principal de Electron, justo antes de guardar ventas.
- El control estricto de licencias POS continúa apagado por defecto. No lo actives en datos reales hasta haber rotado la clave del emisor y emitido/verificado una licencia por POS.
- `CON APP` y los permisos de turno permanecen bloqueados hasta que exista una app móvil real y pase pruebas de extremo a extremo. El emisor de licencia de instalación rechaza expresamente `--modo-con-app`.

## Validación realizada y límites

`npm run check-source` pasa en el entorno de prueba Linux (Node v22.16.0), incluidos los casos de clave cifrada, licencias legacy/POS, autorización de ventas, migración de productos, respaldo/recuperación SQLite, bloqueo de migración automática y rotación en carpeta temporal (14 aserciones). Los comandos de emisión se verificaron bloqueados mientras existe el archivo de bloqueo.

No se ha ejecutado la interfaz de Electron ni la compilación/instalador de Windows. `node tools/test-license.js` no completa en Linux porque busca el MachineGuid real de Windows; debe ejecutarse en Windows. El conjunto completo `npm run check` y las comprobaciones de `app.asar` están pendientes de una compilación real de Windows. Tampoco se ha analizado ni migrado una base comercial real, porque el ZIP recibido contiene código fuente, no la base de datos privada.
