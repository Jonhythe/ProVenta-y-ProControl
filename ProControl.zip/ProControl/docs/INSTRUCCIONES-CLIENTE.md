# Instrucciones para el Cliente — ProControl

## 1. Instalación

1. Descargue **`ProControl Setup 1.1.0.exe`** (el instalador).
2. Haga doble clic en el archivo descargado.
3. Si Windows muestra **"Protegió tu PC" (SmartScreen)**:
   - Haga clic en **"Más información"**.
   - Haga clic en **"Ejecutar de todos modos"**.
   - *Nota: No hay firma de código de pago (cuestan cientos de dólares al año). ProControl es software gratuito para el vendedor y no paga certificados. El aviso es normal en software sin firma.*
4. Siga el asistente:
   - Elija carpeta de destino (o deje la predeterminada).
   - **No hay página de activación en el instalador** (la activación se hace dentro de la app).
5. Al terminar, se creará el acceso directo en el Escritorio y el Menú Inicio.

## 2. Primera ejecución — Activación

1. Abra ProControl (doble clic en el acceso directo).
2. Verá la **pantalla azul de activación**:
   - **ID de esta PC**: código largo de 32 letras/números (ej: `E5A913DBE60647098605531B320F5D5F`).
   - Botón **📋 Copiar ID** — úselo para copiar el ID al portapapeles.
3. **Envíe ese ID al soporte técnico** (WhatsApp +53 56464332).
4. Recibirá su **licencia** (texto que empieza con `PCL1.`).
5. **Pegue la licencia completa** en el cuadro de texto "Pega aquí tu licencia".
   - O guarde la licencia en un archivo `.lic` y use el botón **📂 Elegir archivo .lic**.
6. Haga clic en **Activar licencia**.
7. Si es correcta: verá "✅ Licencia activada. Abriendo ProControl…" y entrará al sistema.

## 3. Uso normal

- La app abre en **pantalla completa** (F11 para salir/entrar).
- **Login**: usuario/contraseña que usted cree en el primer uso.
- Módulos: Dashboard, Compras, Inventario, Almacén, POS, Historial, Estadísticas, Personal.
- **Impresión**: los recibos se abren en ventana aparte con el diálogo de impresión de Windows.
- **Salir**: botón puerta (arriba a la derecha) → confirma en el modal bonito de la app.

## 4. Problemas comunes

| Problema | Solución |
|---|---|
| SmartScreen / Antivirus bloquea el .exe | "Más información" → "Ejecutar de todos modos". No hay virus; es falso positivo por falta de firma de pago. |
| "No se pudo leer el ID de esta PC" | Contacte a soporte. Raro: fallo leyendo el registro de Windows. |
| "Esta licencia fue emitida para otra PC" | Formateó o cambió de PC. Envíe el **nuevo ID** al soporte para reemisión (gratis 1-2 veces/año). |
| "La licencia de prueba ya venció" | Era una licencia temporal. Contacte a soporte para renovar. |
| La app no abre / se cierra sola | Verifique que no haya otra instancia abierta (Ctrl+Shift+Esc → matar ProControl.exe). Reinicie PC si persiste. |

## 5. Respaldos (¡MUY IMPORTANTE!)

**Sus datos viven en `%APPDATA%\ProControl`** (carpeta oculta de Windows).
- Si formatea C: o se rompe el disco, **pierde todo** (inventario, ventas, clientes, cierres de caja).
- **Haga respaldos semanales**: copie la carpeta `ProControl` a un USB, disco externo o nube.
- Para ver la carpeta: `Win+R` → escriba `%APPDATA%` → Enter → busque `ProControl`.

## 6. Contacto

- **Jonathan Sotero** — WhatsApp: **+53 56464332**
- Para activaciones, reemisiones, dudas de uso.