# Guía de ProControl — cierre por IPV y tickets individuales opcionales

## El flujo recomendado para tu negocio

El dependiente **no necesita usar ProControl en la PC** ni registrar cada venta individual. El dependiente trabaja con su hoja IPV impresa y hace el conteo físico. Al terminar el turno, entrega esa hoja y el dueño, administrador o económico introduce y revisa las cantidades en la computadora, con el dependiente presente si hace falta aclarar algo.

1. Abre el punto de venta correcto.
2. Entra en **Cierre diario por IPV**.
3. Compara el stock mostrado por ProControl con la hoja impresa.
4. Introduce el conteo final por producto. Si tiene cajas configuradas, separa cajas completas y unidades sueltas.
5. Registra también el efectivo, las transferencias y el desglose que corresponda.
6. Revisa las diferencias y confirma el cierre cuando todo esté conciliado.

En modo IPV, ProControl calcula una **salida estimada** por producto comparando el stock inicial con el conteo final. Esta cifra ayuda a analizar la demanda y mejorar las alertas de reposición, pero no es un desglose exacto de las ventas una por una. Compras recibidas, transferencias, devoluciones, mermas o ajustes que no se hayan registrado pueden afectar la estimación.

## Entonces, ¿qué es un ticket individual?

Un ticket es el registro digital de una venta concreta: productos, cantidades, precios, forma de pago, punto de venta, fecha y usuario que la registró. No es la hoja IPV ni el cierre de caja y no imprime papel automáticamente.

El módulo **Tickets individuales (opcional)** solo debe usarse si un dueño, administrador o económico decide registrar cada venta directamente en la computadora a medida que ocurre. No debe obligarse al dependiente a hacerlo ni deben duplicarse aquí ventas que se van a calcular por el flujo de IPV.

Cuando se confirma un ticket individual:

- Se guarda la venta en el historial.
- Se descuenta el stock inmediatamente.
- La venta individual entra en las estadísticas de demanda.
- Queda pendiente de conciliar con el siguiente cierre.

Añadir al borrador no guarda la venta ni descuenta stock. Solo al confirmarla se aplica el movimiento.

## Cómo leer las alertas de reposición

ProControl puede estimar la demanda desde dos fuentes, sin contar la misma operación dos veces:

- **Tickets individuales:** cantidades registradas en cada venta; ofrecen un historial transaccional más exacto.
- **Cierres por IPV:** estimación calculada a partir de la diferencia entre stock inicial y conteo final de los cierres que no usaron tickets individuales.

Las alertas mostrarán si la demanda viene de tickets o de cierres IPV. Si todavía no existen cierres recientes ni tickets, se utiliza el mínimo manual de stock configurado. En modo IPV, registra de forma consistente las compras, transferencias, devoluciones y ajustes para que la estimación sea lo más fiable posible.

## Cuándo cambiar al registro individual

Solo si realmente se van a registrar las ventas una por una en la PC. Haz el cambio al inicio de un turno nuevo, después de cerrar el anterior. El sistema no reconstruye tickets de turnos pasados. Si el negocio mantiene el proceso de dependiente + hoja IPV + cierre supervisado, no necesitas activar el registro de tickets individuales.

## Ejemplo de cajas y unidades

Si una caja contiene 10 unidades y la hoja IPV muestra 3 cajas completas y 2 unidades sueltas, el conteo es `3 × 10 + 2 = 32 unidades`. ProControl guarda el total base de 32 unidades. No se suman los 3 envases/cajas como si fueran productos adicionales.
