# ProControl — Fase 10A: escritorio primero (candidato)

**Propósito:** permitir presentar y validar la versión de PC ahora y entregar la aplicación móvil más adelante, sin fingir que la integración móvil ya existe.

## Alcance de esta entrega

- Integra sobre el código original recibido los parches de las fases 1–9 en un único árbol de trabajo.
- Mantiene la operación de escritorio independiente en modo `SIN APP`.
- Cambia la entrada del menú móvil a **«Aplicación móvil (próxima actualización)»**. Al abrirla muestra un aviso, no controles operativos de emparejamiento o conciliación.
- Mantiene `MOBILE_APP_READY = false` en el proceso principal y rechaza `CON_APP`.
- Añade una prueba al `check-source` que comprueba este perfil PC-first.

## Qué no significa

Esta entrega **no completa la fase 10 original**. La fase 10 original exige una aplicación móvil real, permisos y acuses implementados en el teléfono, trabajo sin conexión y pruebas de ida y vuelta. Eso queda para la actualización móvil posterior. Tampoco es un instalador de Windows ya certificado: aquí solo se han podido ejecutar pruebas de fuente.

## Reglas comerciales que se conservan

No cambiar las fórmulas existentes: PPP, tasa USD por cierre, efectivo y transferencia separados, e IPV = stock inicial − conteo final. No borrar movimientos históricos. Las correcciones deben ser estados, anulaciones o movimientos compensatorios auditables.

## Seguridad de licencias

El ZIP fuente que se recibió contenía una clave privada válida. Esta entrega **no incluye ninguna clave privada ni el registro CSV de licencias**. El archivo `licensor/ROTACION-CLAVE-REQUERIDA.txt` permanece y bloquea la emisión. La configuración pública del código fuente debe rotarse localmente antes de autorizar clientes nuevos.

El par criptográfico debe generarse en la computadora privada del propietario, no en este entorno ni en una entrega compartida. En una extracción limpia del paquete, antes de emitir licencias:

```powershell
cd D:\ProControl-PC-First\ProControl
node licensor/gen-license-keys.js
```

Ese comando crea la clave privada en `licensor/private` de esa computadora y actualiza la clave pública de la app. **No compartas la clave privada.** El bloqueo de emisión permanece. No borres el bloqueo hasta que las pruebas en Windows y el procedimiento de emisión estén aprobados. Como la clave pública cambia, una licencia firmada con la clave anterior no será válida para esa nueva compilación; no borres el archivo de licencia anterior del perfil que ya usas.

## Validación local en Windows

1. Extrae el ZIP en una carpeta nueva; no sobrescribas tu instalación que funciona.
2. Si necesitas las dependencias y tienes internet estable, abre `ProControl/app` y ejecuta `npm ci`. Si la conexión no lo permite, prepara una copia de prueba local con dependencias ya instaladas y las mismas versiones, sin copiar datos de clientes.
3. Genera las nuevas claves **solo en la carpeta privada local** como se indicó arriba.
4. En `ProControl/app`, ejecuta:

```powershell
npm run check-source
powershell -ExecutionPolicy Bypass -File .	oolsalidate-windows-release.ps1
```

El segundo comando ejecuta pruebas, construye los artefactos Windows y escanea el `app.asar`. Después aún se requieren pruebas manuales de instalación, apertura, compra, inventario, ventas, ticket, devolución, transferencia, cierre, restauración y licencia en una copia de datos.

## Para la presentación al cliente

Si necesitas enseñar la aplicación mañana, la opción conservadora es abrir la instalación de PC que ya sabes que funciona, después de hacer respaldo y comprobar los flujos principales. No instales esta compilación candidata sobre el equipo del cliente antes de superar la validación de Windows y resolver la rotación de claves. Presenta la app móvil como una actualización futura, no como una función disponible hoy.
