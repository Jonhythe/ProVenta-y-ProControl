# Ideas Futuras — ProControl (NO implementar, solo registro)

> Documento para capturar ideas valiosas que **no entran en el alcance actual**. El dueño decide cuándo/qué priorizar.

---

## 1. Función de respaldos (PRIORIDAD MÁS ALTA)

**Problema**: Hoy el cliente **debe copiar manualmente** `%APPDATA%\ProControl` a USB/nube. Si no lo hace y formatea, **pierde todo** (inventario, ventas, compras, cierres, personal, historial).

**Solución propuesta** (diseño preliminar):
- **Botón "Respaldar ahora"** en Configuración / menú lateral.
  - Abre `dialog.showSaveDialog` (filtro `.zip` o `.pcbackup`).
  - Crea ZIP con: `procontrol.db`, `procontrol.db-wal`, `procontrol.db-shm`, `license.dat`.
  - Nombre sugerido: `ProControl-backup-YYYYMMDD-HHMM.zip`.
- **Botón "Restaurar respaldo"**:
  - `dialog.showOpenDialog` (filtro `.zip` / `.pcbackup`).
  - Cierra app (o pide reinicio), descomprime en `%APPDATA%\ProControl` (sobrescribe).
- **Recordatorio automático** (opcional, configurable):
  - "Hace 7 días que no respalda. ¿Desea hacerlo ahora?".
  - Guardar preferencia en `procontrolDB` (`backup_reminder_days`, `last_backup_ts`).

**Por qué es valioso**:
- Elimina el riesgo #1 de pérdida de datos del negocio.
- Diferencia competitiva: "ProControl te avisa y te ayuda a respaldar".
- Implementación 100% local, sin servidores, gratis (JSZip o `child_process` + `tar`/`zip` nativo de Windows).

---

## 2. Fase 2 — Activación online Cloudflare Workers (PAUSADA)

**Estado**: Código completo en `worker/_pausado/` — **no desplegado**.

**Qué hace**:
- `/emit` (protegido por `EMIT_TOKEN`): genera códigos de un solo uso (6 dígitos), TTL 15 min, guarda en KV `CODES`.
- `/activate` (cliente): valida código existe/no usado/no vencido → marca `used` con `deviceId` → responde `{ok, ticket, sig}` (Ed25519).
- Ticket = JSON `{app, deviceId, type:"permanent", issuedAt, code}` firmado con clave privada del servidor.

**Ventajas si se despliega**:
- Códigos **de un solo uso** (no se pueden compartir/reutilizar).
- Control central: ver activaciones, revocar, estadísticas.
- Panel web futuro para emitir desde el celular.

**Qué falta para desplegar**:
1. Cuenta Cloudflare gratis → Workers & Pages → Create Worker.
2. KV namespace `CODES` (gratis hasta 100k lecturas/día).
3. Secrets en Worker: `LICENSE_PRIVATE_KEY` (contenido de `worker/_pausado/private_key.pem`), `EMIT_TOKEN` (aleatorio).
4. URL del worker → `app/electron/license-config.js` → `WORKER_URL`.
5. Rebuild instalador.
6. En `license.html`: botón "⚡ Activar con el servidor" aparece si `WORKER_URL` configurada.

**Nota**: El sistema actual (PCL1 offline) **ya es funcional y seguro**. Fase 2 añade comodidad (códigos de un solo uso) pero no es obligatoria.

---

## 3. Auto-actualización (electron-updater)

**Estado**: electron-builder ya prepara `APP_INSTALLER_STORE_FILE` pero **no configurado**.

**Qué necesita**:
- Servidor de actualizaciones (GitHub Releases, S3, o servidor propio con `electron-builder` `publish` config).
- En `package.json`: `"publish": { "provider": "github", "repo": "..." }` (requiere token GitHub).
- En `main.js`: `autoUpdater.checkForUpdatesAndNotify()` o manual.
- Diálogo nativo "Hay actualización → Descargar e instalar".

**Consideraciones**:
- Requiere hosting para los artifacts (GitHub Releases gratis para repos públicos; privado = pago).
- Firma de código recomendada (sin firma, SmartScreen avisará en cada actualización).
- Prioridad baja: el dueño entrega builds manualmente por WhatsApp.

---

## 4. Panel de administración web (para el vendedor)

**Estado**: Hoy `/emit` es por `curl` / CLI. Panel web permitiría emitir desde el celular.

**Mínimo viable**:
- Página estática (HTML/JS) servida gratis (Cloudflare Pages, Netlify, GitHub Pages).
- Llama a Worker `/emit` con `EMIT_TOKEN` (guardado en `localStorage` del navegador del vendedor).
- Formulario: ID cliente, nombre, días (opcional), checkbox `--force`.
- Muestra licencia generada + botón copiar/descargar `.lic`.

**Seguridad**:
- `EMIT_TOKEN` solo en navegador del vendedor (no en app).
- Worker valida token + rate limit (ej. 10 req/min por IP).

---

## 5. Mejoras de UX / Funcionales

| Idea | Descripción | Esfuerzo |
|---|---|---|
| **Tema claro/oscuro** | Toggle en Configuración (ya hay CSS variables). | Bajo |
| **Exportar a Excel/CSV** | Desde Historial, Inventario, Compras (botón "Exportar"). | Medio |
| **Multiidioma** | Español/Inglés (archivos JSON i18n). | Medio |
| **Códigos de barras** | Generar/escánear en POS e Inventario (librería `jsbarcode` + `html5-qrcode`). | Medio |
| **Múltiples almacenes** | Ya existe "Almacén" pero mejorar transferencias + stock por ubicación. | Alto |
| **Facturación electrónica** | Integración con API de DGI (Cuba) — requiere investigación legal/técnica. | Muy alto |
| **App móvil complementaria** | React Native / Capacitor para consultar stock/ventas en celular. | Muy alto |

---

## 6. Seguridad / Hardening adicional

| Idea | Descripción |
|---|---|
| **Verificación periódica de licencia** | Cada N días (ej. 30) re-verificar `license.dat` en background; si falla → modo solo lectura. |
| **Ofuscación ligera del asar** | `javascript-obfuscator` SOLO en `electron/` (no en renderer). **Advertencia**: aumenta falsos positivos AV. |
| **Comprobación de integridad en runtime** | Hash de `index.html` / `license.html` al arranque vs hash embedido; si cambia → alerta. |
| **Detección de debugging** | `process.debugPort` / `v8Inspector` — ya cubierto por fuses `enableNodeCliInspectArguments:false`. |

---

## 7. Pruebas / CI/CD

| Idea | Descripción |
|---|---|
| **GitHub Actions** | Build automático en push a `main` → artifact Setup + Portable + Uninstaller. |
| **Test E2E** | Playwright: instalar → activar → login → venta → imprimir → cerrar. |
| **Firma de builds** | Si se compra certificado: `signtool` en pipeline. |

---

## 8. Decisiones del dueño (registro)

| Fecha | Decisión | Contexto |
|---|---|---|
| 21/10/2026 | Migración a Ed25519 PCL1 offline completa | Elimina secretos compartidos, TOTP, HMAC, activación online. |
| 21/10/2026 | Fase 2 Cloudflare pausada | Código en `worker/_pausado/`. No desplegar por ahora. |
| 21/10/2026 | Sin firma de código, sin ofuscador | Gratis obligatorio (dueño en Cuba). |
| 21/10/2026 | Sin panel admin, sin auto-update | Entrega manual por WhatsApp. |
| 21/10/2026 | Respaldos = prioridad #1 post-v1.1 | Anotado aquí para no perderse. |

---

## 9. Próximos pasos sugeridos (orden de valor)

1. **Respaldos (botón + recordatorio)** — impacto directo en retención y confianza del cliente.
2. **Exportar CSV/Excel** — pedido frecuente de clientes para contabilidad.
3. **Desplegar Fase 2** — solo si el volumen de ventas justifica automatizar emisión.
4. **Panel web admin** — comodidad para el vendedor (emitir desde celular).
5. **Auto-update** — solo si hay canal de distribución (GitHub Releases público o servidor propio).

---

**Nota**: Este documento es **vivo**. Añada ideas conforme surjan. No borre, solo marque como "IMPLEMENTADO" o "DESCARTADA" con fecha.