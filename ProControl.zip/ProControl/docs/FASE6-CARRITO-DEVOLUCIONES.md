# ProControl — Fase 6: carrito, devoluciones y corrección segura de tickets

## Alcance
Esta fase extiende el registro introducido en la Fase 5 para admitir tickets con varias líneas y devoluciones completas auditables. No sustituye las pantallas de bienvenida/autenticación, los archivos de licencia ni el almacenamiento comercial completo.

## Cambios visibles
- En el formulario **Registrar venta**, el usuario añade varios productos al ticket antes de confirmar.
- Una tabla intermedia presenta producto, presentación, precio, importe y unidades base que se descontarán.
- El total del ticket se diferencia de la vista previa de la línea que se está preparando.
- Se puede quitar una línea o vaciar el borrador. El stock no cambia hasta confirmar el ticket completo.
- El historial muestra todos los productos del ticket y tiene la acción **Devolver** para devoluciones completas que todavía no hayan sido registradas.

## Comportamiento contable y de inventario
- Todas las líneas de un ticket utilizan una misma forma de pago/moneda; pagos mixtos quedan fuera de esta fase.
- Antes de guardar, se resuelven otra vez los productos actuales, se valida la equivalencia de caja y se agrega la necesidad de stock por producto para evitar que varias líneas consuman más stock del disponible.
- El ticket, el ajuste de existencias y la auditoría se guardan en la misma transacción de estado.
- Una devolución completa añade un nuevo evento negativo vinculado a `returnOf`. El ticket original no se modifica.
- La devolución repone las cantidades base y su importe negativo queda pendiente de conciliación en el siguiente cierre, incluso si el ticket original ya estaba cerrado.
- Solo se permite una devolución completa por ticket. Las devoluciones parciales, los pagos mixtos y la edición directa de tickets no forman parte de esta versión. Para corregir un ticket equivocado se registra la devolución completa y luego se registra un ticket nuevo correcto.
- Si un producto ya no está en el inventario local del punto de venta o cambió de unidad base, se bloquea la devolución; el sistema no inventa sus datos ni modifica parcialmente el ticket.

## Migración y compatibilidad
- `DataStore.SCHEMA_VERSION` pasa de 3 a 4. La nueva migración valida los tickets y exige que cada devolución apunte a un ticket original del mismo POS. No convierte ni borra el historial anterior.
- Los tickets anteriores de una sola línea siguen siendo válidos.
- No se añaden dependencias npm ni se modifica `package-lock.json`.

## Archivos del parche
- `app/renderer/index.html` — reemplazar.
- `app/renderer/sales-ledger.js` — reemplazar.
- `app/tools/test-sales-ledger.js` — reemplazar.
- `app/docs/FASE6-CARRITO-DEVOLUCIONES.md` — archivo nuevo.

## Pruebas
Ejecutar en una copia de prueba desde la raíz `app`:

```powershell
node tools/test-sales-ledger.js
npm run check-source
npm start
```

`node tools/test-sales-ledger.js` cubre tickets multi-línea, compatibilidad con tickets anteriores, devoluciones completas, duplicados, totales e ingresos netos. `npm run check-source` incluye también unidades/cajas, puente móvil y núcleo de licencias. La verificación visual debe realizarse en Windows; no se afirma que la ventana gráfica haya sido ejecutada por este entorno.
