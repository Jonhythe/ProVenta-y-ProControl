# ProControl — Fase 5: registro de ventas por presentación

## Objetivo

Añadir una base de registro de ventas con ID estable, identificador de idempotencia, punto de venta, usuario, hora, presentación, cantidad en presentación, cantidad en unidad base, precio aplicado, moneda, tasa de cambio e importe contable CUP. Esta estructura queda preparada para una futura sincronización móvil, sin implementar todavía una aplicación móvil ni un transporte teléfono-PC.

## Comportamiento

- El botón **Registrar Venta** abre el formulario de venta para el punto de venta seleccionado.
- Se puede registrar un producto por operación: unidad base o caja cuando la unidad base es `u` y hay un factor de caja entero configurado.
- Vender `2` cajas de `15` unidades registra `2 cajas`, convierte a `30` unidades base y descuenta `30` del stock inmediatamente.
- El precio de caja se propone multiplicando el precio base por el factor de caja. El usuario puede modificar el precio aplicado a esa venta; el precio elegido queda guardado en el registro.
- Se admiten pagos en CUP (efectivo o transferencia) y USD. La tasa USD usada en esa venta se guarda; la suma contable se convierte a CUP.
- Cada ticket tiene un ID UUID e `idempotencyKey`, y el registro, el descuento de stock y el evento de auditoría se guardan dentro de una transacción de estado.
- Desde que se activa el modo de tickets en un POS, el cierre usa los ingresos de los tickets pendientes. El conteo físico compara existencias del sistema con el conteo real; las diferencias se registran por producto y unidad, no se inventan como ventas.
- No se permite cerrar si hay tickets pendientes cuyo producto ya no pueda encontrarse en el inventario del POS.
- Al cerrar, los tickets pendientes se marcan como reconciliados y quedan enlazados al ID del cierre.
- Los POS existentes conservan el modo clásico hasta la confirmación de activación. La primera activación debe hacerse **al inicio de un turno nuevo, después de cerrar el turno anterior**. Las ventas anteriores no registradas como tickets no se importan automáticamente.
- Los cierres históricos existentes no se reescriben.

## Limitaciones conocidas de esta fase

- Cada operación registra un solo producto; aún no hay carrito con varias líneas en un único ticket.
- No hay todavía un libro de devoluciones, descuentos, pagos mixtos ni una lista de precio de caja persistente separada del precio base.
- El conector real con una aplicación móvil no está implementado; los IDs y el modelo de datos preparan esa futura integración.
- El entorno de desarrollo utilizado no puede confirmar la apariencia gráfica ni el funcionamiento real de Electron en Windows. Hay que probar la interfaz en una copia de la aplicación.

## Archivos de esta fase

- `renderer/index.html` — UI, persistencia de registro, validación de cierre y reconciliación.
- `renderer/sales-ledger.js` — lógica pura del registro de ventas.
- `package.json` — añade la prueba del registro a los scripts de comprobación; no cambia dependencias.
- `tools/test-sales-ledger.js` — pruebas unitarias del módulo.

## Pruebas

`npm run check-source` ejecuta las pruebas de unidades/cajas, puente móvil, núcleo de licencias y registro de ventas. Para un resultado de publicación completo, crea el build de Windows y ejecuta el verificador de secretos en ese entorno: requiere `app.asar` producido por un build y el acceso a las comprobaciones específicas de Windows.
