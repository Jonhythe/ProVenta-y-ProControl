# Fase 3 — Identidad de producto y unidades/cajas

## Cambios incluidos en esta entrega

- Se añadió `renderer/product-units.js`, módulo puro para validar el contenido entero de una caja, convertir cajas a unidades individuales y calcular una resta de stock sin permitir stock negativo.
- Se añadió `unitsPerBox` al modelo del catálogo mediante la migración de esquema 1 a 2. Los registros existentes reciben `null`; no se inventa el contenido de sus cajas.
- La migración trabaja sobre una copia del catálogo y solo la asigna después de validar todos los registros.
- Se añadieron métodos de inventario para consultar/configurar el contenido de caja por ID estable y convertir una cantidad de venta.
- En el POS se añadió la columna **Caja**, que permite configurar o quitar el número de unidades por caja para productos contados en unidades individuales. Los productos en kg, litros u otras unidades fraccionables quedan excluidos.
- La configuración se guarda mediante `DataStore.save()`. Si el guardado falla, se restaura la copia anterior del catálogo.
- En el cierre, la cantidad inferida como vendida sigue calculándose con el mecanismo anterior. Cuando el producto tiene configuración de caja, la interfaz también muestra el equivalente en cajas completas y unidades restantes.
- Se valida que compras y conteos de cierre no registren cantidades fraccionarias para unidades individuales o cajas; kg/lb/lt conservan precisión.
- La carga del módulo usa la URL explícita `app://product-units.js`, compatible con el protocolo local `app://` de Electron.
- Se añadieron pruebas unitarias para conversión, fracciones, caja sin configurar y stock insuficiente, además de una guarda para evitar regresiones en la ruta del módulo.
- El chequeo `npm run check` incluye las pruebas de unidades/cajas.

## Límites y precauciones

- No se cambiaron cantidades existentes, precios, productos, cierres ni datos reales.
- No se modificaron ni reinterpretaron los cierres históricos.
- La columna Caja configura el empaquetado y presenta el equivalente de la cantidad vendida al cierre; **no es un flujo de venta individual que descuente stock en el momento de la operación**. El POS existente infiere las ventas mediante el conteo final. Implementar ventas inmediatas por caja/unidad requiere un libro de ventas y reconciliación con el cierre; no se simuló esa operación ni se descontó stock dos veces.
- Las cantidades fraccionables (`kg`, `lb`, `lt`) conservan su precisión; la regla de enteros aplica a unidades individuales y cajas.
- Los productos agotados siguen usando el comportamiento anterior de limpieza de stock. El archivado visual sin pérdida de identidad requiere un cambio coordinado con todos los listados y reportes; no se hizo a medias.
- No se ejecutó un build de Windows ni se arrancó Electron en este entorno. La entrega requiere una prueba en Windows antes de reemplazar la instalación real.

## Pruebas ejecutadas en este entorno

- `node tools/test-product-units.js`: correcto.
- `node tools/test-license-core-only.js`: 27 correctas, 0 fallos.
- `node --check` del script principal extraído de `renderer/index.html`: correcto.
- `node --check electron/main.js`, `electron/preload.js` y `renderer/product-units.js`: correctos.
- `node tools/check-no-secrets.js`: requiere un build (`app.asar`) que no existe en esta copia y no se considera aprobado.
- `node tools/test-license.js`: depende de `MachineGuid` de Windows; no se pudo validar en Linux.
- No se hizo build de Windows ni se arrancó Electron; no se afirma que estén probados.

## Decisión de seguridad

La entrega omite la carpeta de claves privadas del emisor. La clave privada no se ha copiado a los archivos nuevos.
