# ProControl — revisión de base y Parte 1

**Fecha:** 28 de octubre de 2026  
**Base recibida:** código fuente de ProControl 1.2.0 (`ProControl(5).zip`)  
**Estado:** candidato de trabajo; no es un instalador validado para clientes.

## Qué contiene la base recibida

El proyecto ya incorpora un módulo local de Gestión Empresarial (`app/renderer/business-management.js`) conectado al almacén `procontrolDB`. Sus capacidades existentes incluyen cuentas y movimientos por moneda, cuentas por cobrar/pagar, proveedores, tasas históricas, sugerencias de reposición, análisis ABC, un indicador económico orientativo, simuladores, alertas de posibles duplicados, comparación por sucursal, auditoría y exportación/restauración de los datos del propio módulo.

Por eso no se debe reconstruir desde cero lo que ya funciona. Las pruebas existentes cubren muchas de estas reglas, aunque no sustituyen la validación visual/manual en Windows ni una prueba con datos reales del negocio.

## Correcciones incluidas en esta Parte 1

1. **Tasa para liquidez actual:** los compromisos pendientes en moneda extranjera se convierten con la última tasa registrada hasta la fecha actual, en lugar de limitarse a la tasa histórica anterior a la fecha de vencimiento. La cifra sigue identificándose como estimación.
2. **Reposición menos agresiva:** el horizonte general toma la configuración del módulo y no el mayor plazo de cualquier proveedor aplicado indiscriminadamente a todos los productos. Se conserva el plazo específico indicado en cada producto cuando existe.
3. **Detector de posibles duplicados:** se reemplazó la comparación anidada cuadrática por agrupación de una pasada, y se considera la cuenta para no señalar como duplicados dos movimientos idénticos hechos en cuentas diferentes. Siguen siendo señales que debe revisar una persona.
4. **Comparación de sucursales más eficiente:** se agregan movimientos en una pasada y se mantienen los importes separados por moneda; los cobros y pagos liquidados se incluyen en las entradas/salidas correspondientes.
5. **Margen comparable:** no se calcula el margen de un producto si el código indica dos monedas distintas o si solo una de las dos monedas está identificada. Si ambos campos están ausentes en productos antiguos, el valor continúa etiquetado como estimación.
6. **Respaldo del módulo:** cuando el perfil tiene permiso de escritura, el evento de exportación se registra antes de serializar el respaldo, de modo que la copia incluya el evento de auditoría. Un perfil de solo lectura puede exportar sin modificar el historial.
7. **Pruebas de regresión:** se añadieron cuatro comprobaciones al conjunto de Gestión Empresarial, incluida una prueba de rendimiento lógico sobre 15 000 movimientos sin duplicados.
8. **Consistencia de versión:** el emisor de licencias y los ejemplos de entrega quedan alineados con la versión actual 1.2.0.

## Resultado de las comprobaciones

- `node tools/check-source-syntax.js`: correcto; 58 archivos JavaScript y 5 bloques JavaScript inline comprobados.
- `npm run check-source`: completado con todas las pruebas aprobadas, incluidas las nuevas comprobaciones de Gestión Empresarial.
- `node tools/check-no-secrets.js`: no se puede obtener un veredicto válido de publicación porque no existe un `app.asar` compilado en el ZIP. El escáner indica que no encontró un artefacto compilado para revisar y termina con error por esa ausencia.
- No se compiló ni instaló Electron para Windows. El ZIP recibido no contiene `node_modules`, instaladores, `app.asar` ni una base de datos comercial. Deben realizarse las pruebas de instalación, apertura, licencia, ventas, cierre, respaldo y restauración en una copia de prueba de Windows.

## Seguridad de licencias — bloqueador de publicación

El archivo recibido contenía una clave privada Ed25519 del emisor y un registro local de emisión. **Ambos se han omitido de este ZIP de trabajo.** El registro puede contener información de clientes y no es necesario para ejecutar el código de la aplicación.

El bloqueo `licensor/ROTACION-CLAVE-REQUERIDA.txt` se mantiene intencionalmente. La nueva clave privada no debe generarse ni enviarse por este chat. En una extracción limpia, privada y de prueba en Windows, sigue el procedimiento de ese documento y ejecuta el generador de claves localmente. No quites el bloqueo ni emitas licencias nuevas hasta completar las comprobaciones automatizadas y manuales. La rotación cambia la clave pública de verificación, por lo que las licencias antiguas firmadas con la clave previa no serán válidas para una compilación que use la nueva clave. Mantén separada la instalación actual hasta planificar y probar la transición.

## División de trabajo acordada

### Parte 1 — fiabilidad y base económica

Esta entrega corrige riesgos puntuales de cálculo y rendimiento del módulo económico y sanea los archivos sensibles incluidos en el ZIP. Conserva la separación de datos y la lógica de ventas/inventario existente. No pretende certificar el sistema contable ni fiscal.

### Parte 2 — experiencia simple y capa de decisiones

La segunda parte deberá reorganizar el acceso a las funciones existentes y aprobadas, sin duplicar módulos ni saturar la interfaz:

- **A. Semáforo económico:** estado fácil de entender, con motivos verificables y estado neutral cuando falten datos.
- **B. ABC y mercancía inmovilizada:** datos de ventas fiables, alertas explicadas y acceso al detalle solo cuando se solicite.
- **C. Simulador:** mostrar antes/después de liquidez, compromisos conocidos y supuestos; no alterar operaciones reales.
- **D. Sucursales:** comparar solo métricas válidas y separar monedas.
- **E. Historial explicable:** rastrear operaciones y cambios sin mostrar toda la auditoría en la pantalla principal.
- Reducir la saturación del módulo, mantener el lenguaje cotidiano y presentar primero los datos esenciales, con detalles progresivos.
- Mantener los perfiles Esencial, Gestión y Empresa como configuraciones futuras de una sola base de código, no como tres aplicaciones independientes.
- No incorporar automatización fiscal, certificaciones no verificadas, costes variables inventados ni decisiones financieras ejecutadas automáticamente.

## Regla de aceptación

La calidad no se medirá por la cantidad de pantallas o indicadores. Una función solo se considerará terminada cuando sus datos sean trazables, los cálculos estén probados, el usuario pueda entender su propósito y un fallo no comprometa operaciones existentes. Los cambios se deben aplicar a una copia de trabajo; nunca sobrescribir la instalación ni la base de datos de producción durante el desarrollo.
