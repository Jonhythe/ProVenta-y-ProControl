# ProControl — código fuente y compilación en GitHub Actions

## Estructura ya incorporada

La rama `main` contiene el código fuente en:

- `app/`: aplicación Electron, recursos, herramientas, pruebas, scripts de distribución y configuración del instalador.
- `docs/`: documentación técnica y manuales del proyecto.
- `licensor/`: utilidades de licencias y plantilla del generador. No incluye claves privadas ni archivos cifrados de emisión.
- `SOURCE-FILE-MANIFEST.json`: SHA-256 de cada archivo importado y del ZIP de procedencia.

Se conserva el ZIP original en la raíz como referencia de procedencia. No se utiliza como fuente de compilación: el workflow compila directamente desde `app/`.

## Workflows disponibles

En GitHub → **Actions**:

1. **Stage ProControl source for review**: revalida el ZIP original en un runner temporal; no ejecuta sus scripts ni modifica el código versionado.
2. **Import ProControl source**: flujo de importación controlado desde el ZIP con hash fijo. Ya se ejecutó correctamente y subió `app/`, `docs/` y `licensor/`.
3. **ProControl Windows x64 — installer and folder distribution**: compila para Windows x64. Se inicia manualmente, al completar correctamente la importación o cuando se modifica `app/**`, `.gitattributes` o el propio workflow de compilación.

## Proceso de compilación

El workflow de Windows:

1. Usa Node.js 24 x64.
2. Instala el árbol fijado en `app/package-lock.json` mediante `npm ci`.
3. Ejecuta `npm run check-source`.
4. Genera el instalador NSIS x64 mediante `npm run dist`.
5. Ejecuta `node tools/build-folder-distribution.js` para crear la distribución en carpeta y su ZIP.
6. Calcula SHA-256 y sube dos artefactos independientes.

Artefactos publicados al finalizar correctamente:

- `ProControl-NSIS-Installer-Windows-x64`
- `ProControl-Folder-Distribution-Windows-x64` (carpeta distribuible, ZIP y manifiesto de hashes)

Los artefactos de Actions se conservan durante 14 días. No son una versión publicada en Releases.

## Convenciones

- `.gitattributes` fija finales de línea reproducibles para que las pruebas basadas en texto no cambien entre Windows y Linux.
- `.gitignore` excluye `node_modules/`, `dist*/`, instaladores, ZIP generados, datos locales, archivos de emisión y claves privadas.
- No subir `node_modules/`, binarios antiguos, instaladores, datos reales de clientes, `.env`, tokens, `*.pckey`, claves privadas PEM ni `licensor/private/`.

## Rotación de clave Ed25519 desde GitHub

Para rotar la clave sin usar el PC local:

1. En **Settings → Secrets and variables → Actions → New repository secret**, crea `PROCONTROL_KEY_PASSWORD` con una contraseña única de al menos 20 caracteres. Guárdala fuera del PC sospechoso y no la envíes por chat.
2. En **Actions**, ejecuta **ProControl Ed25519 license-key rotation** mediante **Run workflow**.
3. Si termina correctamente, descarga el artefacto privado `ProControl-Ed25519-OWNER-ONLY-KEY-PACKAGE`. Incluye el `.pckey` cifrado, el generador HTML final y la clave pública.
4. Guarda dos copias seguras del `.pckey` y del generador. La contraseña es el secreto `PROCONTROL_KEY_PASSWORD`; sin el archivo y la contraseña no podrás emitir licencias.
5. La acción confirma al repositorio únicamente la clave pública. No incorpora el `.pckey` ni el HTML final.
6. El cambio de clave dispara la compilación Windows. No distribuyas hasta que esa compilación pase, se prueben licencias nuevas y se complete una instalación/desinstalación en Windows x64 limpio.

El secreto solo debe contener la contraseña del paquete cifrado. No reutilices una contraseña de otro servicio.

## Estado de validación y licencias

La importación desde el ZIP pasó el análisis estático de rutas, tipos de archivo, patrones de secretos, referencias a exclusiones antivirus y cabeceras PE/MZ. Esto no garantiza ausencia absoluta de malware.

La clave privada Ed25519 anterior se considera comprometida y no debe reutilizarse. La compilación no firma ni emite licencias y no necesita secretos. **No distribuir los artefactos a clientes** hasta terminar la rotación de clave, verificar la nueva clave pública y realizar la prueba final de instalación/desinstalación en Windows.


## Generador permanente de códigos — descarga privada del dueño

La plantilla `licensor/Generador-Codigos-ProControl.template.html` solicita primero la contraseña del emisor para desbloquear la clave privada cifrada. Después de desbloquearse, el único dato que pide para emitir es el ID del equipo del cliente. Todas las licencias emitidas por esta versión son permanentes y están vinculadas al ID; no ofrece pruebas temporales ni campos de cliente.

El archivo HTML final incluye el paquete de clave privada **cifrado** y debe tratarse como material confidencial. No se versiona en el repositorio. El workflow **ProControl — owner permanent license generator** descarga el paquete cifrado del workflow de rotación original, genera el HTML final y lo publica como artefacto privado:

- `ProControl-Generador-Permanente-OWNER-ONLY`

El workflow se ejecuta automáticamente cuando cambia la plantilla, su generador de paquetes, su prueba o este README; también se puede ejecutar manualmente desde Actions. Descarga el artefacto de Actions y guarda dos copias seguras. Los artefactos expiran a los 14 días.

**No compartir el HTML con clientes, no subirlo a commits y no publicar su contenido.** La contraseña del emisor nunca forma parte del HTML ni se envía al repositorio.
