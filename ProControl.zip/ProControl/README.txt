PROCONTROL - REPARACION DE PRUEBA DE PAQUETE

Este parche incorpora el archivo tools/test-runtime-package-completeness.js que referencia el script check-source del package.json principal.

APLICACION: extraer el contenido de este ZIP sobre la carpeta raiz del proyecto ProControl, donde se encuentran package.json, tools, electron y app. No extraer dentro de la subcarpeta app.

No reemplaza package.json ni modifica codigo de la aplicacion o datos del usuario.
