﻿$ErrorActionPreference = 'Stop'
$projectRoot = 'D:\Apps\Administracion\ProControl\ProControl\app'
$sourceManifest = Join-Path $PSScriptRoot 'package.json'
$targetManifest = Join-Path $projectRoot 'package.json'

if (-not (Test-Path -LiteralPath $sourceManifest)) {
    throw "No se encontró el package.json incluido junto al script: $sourceManifest"
}
if (-not (Test-Path -LiteralPath $projectRoot)) {
    throw "No existe la carpeta del proyecto: $projectRoot"
}

$manifest = Get-Content -LiteralPath $sourceManifest -Raw | ConvertFrom-Json
if (-not $manifest.scripts.'check-source' -or -not $manifest.scripts.dist -or -not $manifest.build) {
    throw 'El manifiesto de restauración no tiene los scripts check-source/dist o la configuración build. No se modificó el proyecto.'
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = "$targetManifest.backup_$stamp"
if (Test-Path -LiteralPath $targetManifest) {
    Copy-Item -LiteralPath $targetManifest -Destination $backup
    Write-Host "COPIA_SEGURIDAD: $backup"
}
Copy-Item -LiteralPath $sourceManifest -Destination $targetManifest -Force

$check = Get-Content -LiteralPath $targetManifest -Raw | ConvertFrom-Json
if (-not $check.scripts.'check-source' -or -not $check.scripts.dist -or -not $check.build) {
    throw 'La verificación del manifiesto instalado falló.'
}
Write-Host 'MANIFESTO_PRINCIPAL_RESTAURADO'
Write-Host 'check-source: PRESENTE'
Write-Host 'dist: PRESENTE'
Write-Host 'build: PRESENTE'
Write-Host 'No se modificó app\package.json ni ningún otro archivo.'
