# ProControl — Reparación de STORE_WIPE_FAILED

## Causa corregida

El parche anterior comprobaba si `stageClearAll()` existía usando una búsqueda de texto (`includes`). El nombre también aparecía dentro del comentario de `cleanupPendingWipeStages`, por lo que el instalador omitía la creación del método real. Cuando existía `registros-antiguos`, el borrado intentaba llamar a un método inexistente y terminaba mostrando `STORE_WIPE_FAILED` sin detalle.

Este parche verifica una declaración real de método y la instala si falta. Además, reemplaza el bloque de borrado por un módulo aislado que:

- Borra el almacén SQLite principal y el JSON legado.
- Detecta todas las tablas operativas presentes en `mobile-bridge.db` y las vacía sin depender de una lista fija ni del orden de claves foráneas.
- Conserva íntegra `bridge_meta` y comprueba que `installation_id` sigue presente.
- Aparta de forma reversible los archivos cifrados históricos antes de modificar datos.
- Revierte las transacciones y restaura el JSON/archivos históricos si falla una operación antes de confirmar el borrado.
- Devuelve etapa, código y detalle del fallo. Si aparece un fallo después de un commit, lo marca como parcial en lugar de afirmar falsamente que no se modificó nada.
- Mantiene la reautenticación de Dueño en el proceso principal y no cambia la licencia ni las claves privadas.

## Instalación

1. Cierra ProControl completamente.
2. Extrae el ZIP en:
   `D:\Apps\Administracion\ProControl\ProControl\app`
   Conserva las rutas internas del ZIP.
3. Ejecuta en PowerShell:

```powershell
$ErrorActionPreference = 'Stop'
Set-Location "D:\Apps\Administracion\ProControl\ProControl\app"
node .\tools\patch-procontrol-wipe-store-failed.js
if ($LASTEXITCODE -ne 0) { throw "Falló el parche de borrado." }
```

El script guarda copias de seguridad de los archivos que modifica en:
`%LOCALAPPDATA%\ProControl\patch-backups\wipe-v2-*`

Antes de terminar ejecuta `check-source-syntax.js` y `test-authorized-store-wipe.js`. La última prueba crea bases SQLite temporales y verifica el resultado del borrado y la reversión; nunca abre ni altera las bases reales.

## Compilar

Solo después de que el script anterior termine con código 0:

```powershell
npm.cmd run check-source
if ($LASTEXITCODE -ne 0) { throw "Falló check-source. No compilar." }
npm.cmd run dist
if ($LASTEXITCODE -ne 0) { throw "Falló el instalador NSIS." }
```

Instala el nuevo `ProControl Setup 1.2.0.exe` y vuelve a probar **Borrar todos los datos**.

## Diagnóstico si todavía falla

El diálogo mostrará `Código`, `Etapa` y `Detalle`. El proceso principal también dejará un registro sin contraseña en:
`%APPDATA%\ProControl\store-wipe-errors.log`

No borres manualmente `%APPDATA%\ProControl`, `procontrol.db`, `mobile-bridge.db`, las claves ni los archivos de licencia. El propio proceso autorizado administra el reinicio conservando la identidad y licencia.
