param(
  [string]$Destination = (Join-Path $env:USERPROFILE 'Documents\ProControlBackups')
)
$ErrorActionPreference = 'Stop'
$AppRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$BridgeDbRoot = Join-Path $env:APPDATA 'ProControl'
$ElectronExe = Join-Path $AppRoot 'node_modules\electron\dist\electron.exe'
$running = @()
try { $running += Get-Process -Name 'ProControl' -ErrorAction SilentlyContinue } catch {}
if (Test-Path $ElectronExe) {
  try { $running += Get-Process -Name 'electron' -ErrorAction SilentlyContinue | Where-Object { $_.Path -and ([IO.Path]::GetFullPath($_.Path) -eq [IO.Path]::GetFullPath($ElectronExe)) } } catch {}
}
if ($running.Count -gt 0) { throw 'Cierra ProControl por completo antes de crear la copia de seguridad.' }
if (-not (Test-Path $BridgeDbRoot)) { throw "No existe la carpeta de datos esperada: $BridgeDbRoot" }
New-Item -ItemType Directory -Path $Destination -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupDir = Join-Path $Destination "ProControl-Backup-$stamp"
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
# Lista permitida: nunca se copia license.dat ni ninguna clave privada de licencias.
$allowed = @('procontrol.db','procontrol.db-wal','procontrol.db-shm','procontrol.json','mobile-bridge.db','mobile-bridge.db-wal','mobile-bridge.db-shm','mobile-bridge-desktop-public.pem','mobile-bridge-desktop-private.dpapi','mobile-bridge-desktop-private.dpapi.bak')
$manifestFiles = @()
foreach ($name in $allowed) {
  $src = Join-Path $BridgeDbRoot $name
  if (Test-Path -LiteralPath $src -PathType Leaf) {
    $dst = Join-Path $BackupDir $name
    Copy-Item -LiteralPath $src -Destination $dst
    $manifestFiles += [ordered]@{ name=$name; sha256=(Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLowerInvariant(); bytes=(Get-Item -LiteralPath $dst).Length }
  }
}
# La clave ya migrada por Electron se conserva cifrada en .dpapi y se copia tal cual;
# solo es recuperable por safeStorage del mismo usuario/Windows.
# Compatibilidad: si aún existe el PEM antiguo, se protege con DPAPI para el usuario actual.
$privatePath = Join-Path $BridgeDbRoot 'mobile-bridge-desktop-private.pem'
if (Test-Path -LiteralPath $privatePath -PathType Leaf) {
  Add-Type -AssemblyName System.Security
  $entropy = [Text.Encoding]::UTF8.GetBytes('ProControl-MobileBridge-Backup-v1')
  $plain = [IO.File]::ReadAllBytes($privatePath)
  $protected = [Security.Cryptography.ProtectedData]::Protect($plain, $entropy, [Security.Cryptography.DataProtectionScope]::CurrentUser)
  $keyName = 'mobile-bridge-desktop-private.pem.dpapi'
  [IO.File]::WriteAllBytes((Join-Path $BackupDir $keyName), $protected)
  $manifestFiles += [ordered]@{ name=$keyName; sha256=(Get-FileHash -LiteralPath (Join-Path $BackupDir $keyName) -Algorithm SHA256).Hash.ToLowerInvariant(); bytes=$protected.Length }
}
if ($manifestFiles.Count -eq 0) { throw 'No se encontraron bases de datos para respaldar.' }
$manifest = [ordered]@{ format='ProControl.Backup'; version=1; createdAt=(Get-Date).ToString('o'); scope='databases-and-bridge-identity'; files=$manifestFiles; note='No incluye licencias comerciales ni la clave privada del emisor de licencias.' }
$manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $BackupDir 'manifest.json') -Encoding UTF8
Write-Host "Copia de seguridad creada: $BackupDir" -ForegroundColor Green
Write-Host 'Guárdala en un medio seguro. La clave de firma del puente está protegida por DPAPI y solo se puede recuperar con el mismo usuario de Windows.'
