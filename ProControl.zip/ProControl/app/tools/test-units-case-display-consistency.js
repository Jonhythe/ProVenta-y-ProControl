'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');

// Las operaciones nuevas usan cantidad única en unidad base. Se conserva la
// lectura de factores antiguos solo para interpretar los registros históricos.
assert.match(html, /formatQuantityCompact\(item, qty\)/, 'Las alertas y listas compactas deben usar el formato común de cantidad.');
assert.match(html, /title="\$\{esc\(qtyTitle\)\}"/, 'Las alertas deben exponer el total de existencias en el tooltip.');
assert.match(html, /id="corr-inv-qty"/, 'La corrección de inventario debe tener un campo de cantidad total.');
assert.doesNotMatch(html, /corr-inv-box-qty|corr-inv-unit-qty/, 'La corrección de inventario no debe pedir cajas y unidades por separado.');
assert.match(html, /formatQuantityForProduct\(product, product\.qty\)/, 'El análisis de ventas debe presentar cantidades con la unidad correcta.');
assert.match(html, /unitsPerBox: Inventory\.unitsPerBoxForPOSItem\(row\.item, state\) \|\| null/, 'Los datos heredados del cierre conservan el factor histórico cuando existe.');
assert.match(html, /const transferFactor = Number\(transfer\.unitsPerBox \|\| 0\)/, 'La lectura de transferencias antiguas conserva el factor histórico guardado.');
assert.match(html, /const isRetiredUnit = \['caja', 'cajas', 'box', 'boxes'\]\.includes\(purchaseUnit\)/, 'La lectura de compras antiguas convierte registros con unidad caja a la unidad base.');
assert.match(html, /const transferQtyLabel = transferProduct \? Inventory\.formatQuantity\(transferProduct, transferBaseQty\)/, 'El historial de transferencias presenta cantidades en la unidad base.');
assert.match(html, /formatHistoryQuantityFull\(masterItem, item && item\.qty, item && item\.unitsPerBox/, 'El historial conserva compatibilidad para movimientos antiguos sin mostrar campos nuevos de caja.');
assert.match(html, /const formatClosingHistoryQty =/, 'El detalle de cierres históricos muestra las cantidades en la unidad base.');
assert.doesNotMatch(html, /data-count-kind="box"|data-count-kind="unit"/, 'Los cierres nuevos no deben reintroducir entradas de cajas separadas.');
console.log('OK: cantidades nuevas uniformes en unidad base y compatibilidad de registros históricos.');
