'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { MobileBridgeStore, PACKAGE_FORMAT, stableJson, sha256, signedFields } = require('../electron/mobile-bridge/store');
const { MobileControlPlane } = require('../electron/mobile-bridge/control-plane');
const src = path.resolve(__dirname, '..');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-phase7-9-'));
let store;
let assertions = 0;
function check(value, message) { assertions++; assert.ok(value, message); }
try {
  const now = Date.now();
  store = new MobileBridgeStore(root);
  const desktopId = 'A'.repeat(32);
  const posId = 'pos_phase789_01';
  const plane = new MobileControlPlane(store, { deviceId: desktopId, now: () => now,
    getInstallationLicense: () => ({ modules:['core','inventory','purchases','pos','closings','reports','mobile-integration'], allowedModes:['SIN_APP','CON_APP'] }) });
  store.controlPlane = plane;
  const owner = { user:'Dueño prueba', role:'Dueño' };
  const setDesktopMode = plane.setPOSMode({ posId, mode:'SIN_APP' }, owner);
  check(setDesktopMode.ok && setDesktopMode.mode === 'SIN_APP', 'records a no-mobile SIN_APP mode transition locally');
  const conApp = plane.setPOSMode({ posId, mode:'CON_APP', cutInfo:{ backupVerified:true, backupSha256:'a'.repeat(64), cutAt:now, inventorySnapshot:[] } }, owner);
  check(!conApp.ok && conApp.code === 'MOBILE_APP_NOT_AVAILABLE', 'CON APP remains fail-closed until a real mobile app exists');
  check(plane.getPOSPolicy(posId).mode === 'SIN_APP', 'a blocked cutover does not modify the current POS mode');

  const deviceKeys = crypto.generateKeyPairSync('ed25519');
  const devicePublic = deviceKeys.publicKey.export({type:'spki',format:'pem'}).toString();
  const deviceId = 'device_phase789_01';
  store.db.prepare('INSERT INTO devices(device_id,label,role,enabled,paired_at,public_key,pos_id) VALUES(?,?,?,?,?,?,?)')
    .run(deviceId, 'Dispositivo sintético', 'operator', 1, now, devicePublic, posId);
  const payload = { schemaVersion:1, status:'test-only', nonce:'N'.repeat(32) };
  const doc = { format:PACKAGE_FORMAT, version:1, packageId:'pkg_phase789_ack_01', deviceId, type:'heartbeat', createdAt:new Date(now).toISOString(), payload,
    payloadHash:sha256(stableJson(payload)), signerPublicKey:devicePublic };
  doc.signature = { algorithm:'Ed25519', value:crypto.sign(null, Buffer.from(signedFields(doc),'utf8'), deviceKeys.privateKey).toString('base64') };
  const imported = store.importOfflineBundle(JSON.stringify(doc));
  check(imported.ok, 'a valid synthetic package passes the offline signature gate');
  const pendingAck = plane.createPackageAcknowledgement(doc.packageId, owner);
  check(!pendingAck.ok && pendingAck.code === 'ACK_REQUIRES_TERMINAL_RESULT', 'acknowledgement cannot be generated while package is pending review');
  const rejected = store.markPackage(doc.packageId, 'rejected', owner.user, 'Prueba sintética');
  check(rejected.ok, 'synthetic package can be explicitly rejected');
  const ackResult = plane.createPackageAcknowledgement(doc.packageId, owner);
  check(ackResult.ok && ackResult.acknowledgement.result === 'rejected', 'desktop creates a signed rejection acknowledgement only after the decision');
  check(plane.verifyPackageAcknowledgement(ackResult.acknowledgement).ok, 'acknowledgement verifies against the pinned local desktop key and stored package');
  const duplicateAck = plane.createPackageAcknowledgement(doc.packageId, owner);
  check(duplicateAck.ok && duplicateAck.duplicate && duplicateAck.acknowledgement.signature.value === ackResult.acknowledgement.signature.value, 'repeated acknowledgement request returns the original durable signature');
  const ackHistory = plane.listPackageAcknowledgements();
  check(ackHistory.some(item => item.packageId === doc.packageId && item.result === 'rejected'), 'acknowledgement history is persisted and queryable');
  const tampered = JSON.parse(JSON.stringify(ackResult.acknowledgement)); tampered.payloadHash = 'f'.repeat(64);
  check(!plane.verifyPackageAcknowledgement(tampered).ok, 'tampered acknowledgement is rejected');
  const signatureDoc = { ...ackResult.acknowledgement }; const signature = signatureDoc.signature; delete signatureDoc.signature;
  check(crypto.verify(null, Buffer.from(stableJson(signatureDoc),'utf8'), crypto.createPublicKey(store.desktopPublicKey), Buffer.from(signature.value,'base64')), 'Ed25519 QR/file ack carries a verifiable signature');

  const main = fs.readFileSync(path.join(src,'electron','main.js'),'utf8');
  const preload = fs.readFileSync(path.join(src,'electron','preload.js'),'utf8');
  const html = fs.readFileSync(path.join(src,'renderer','index.html'),'utf8');
  check(main.includes("mobile-control:set-pos-mode") && preload.includes('setPOSMode:'), 'mode API is wired from isolated renderer to Electron main');
  check(main.includes("mobile-bridge:export-package-fragments") && main.includes('DEVICE_BOUND_EXPORT_NOT_READY') && main.includes('readFragmentSet(selected)'), 'package export remains blocked until data is bound to an authorized target device; import remains available');
  check(main.includes("mobile-control:create-package-ack") && main.includes("mobile-control:save-package-ack"), 'ack signing and save handlers are wired in main process');
  check(html.includes('app://local-qr.js') && html.includes('Exportar fragmentos para USB'), 'UI loads local QR encoder and exposes USB fragment workflow');
  check(store.status().networkListener === false, 'offline exchange does not create a network listener');
  console.log(`Phase 7–9 tests: ${assertions} assertions passed.`);
} finally {
  try { if (store) store.close(); } catch (_) {}
  fs.rmSync(root, { recursive:true, force:true });
}
