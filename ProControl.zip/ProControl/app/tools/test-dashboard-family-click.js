#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const htmlPath = path.join(__dirname, '..', 'renderer', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const checks = [
  ['family cards use existing family emoji mapping', /const emoji = \(typeof FAMILY_EMOJIS !== 'undefined'\)/.test(html) && /class="family-icon"[^>]*>\$\{emoji\}/.test(html)],
  ['family card is a keyboard-accessible button', /<button type="button" class="family-pill"/.test(html) && /aria-label="Abrir inventario de la familia/.test(html)],
  ['family card click opens exact family inventory', /onclick="Inventory\.openFamilyFromDashboard\(this\.dataset\.family\)"/.test(html)],
  ['openFamilyFromDashboard validates family presence', /openFamilyFromDashboard\(family\)[\s\S]*?appState\.inventory\.some/.test(html)],
  ['navigation goes to central warehouse', /openFamilyFromDashboard\(family\)[\s\S]*?UI\.showPage\('page-warehouse'\)/.test(html)],
  ['filter supports exact family mode', /filterWarehouse\(query, exactFamily = false\)/.test(html) && /exactFamily\s*\?\s*norm\(this\._safeFamily/.test(html)],
  ['family filter keeps family header expanded', /openFamilyFromDashboard\(family\)[\s\S]*?firstHeader\.classList\.add\('expanded'\)/.test(html)],
  ['existing filter still matches product name or family', /: \(norm\(item\.name\)\.includes\(searchTerm\) \|\| norm\(item\.family\)\.includes\(searchTerm\)\)/.test(html)],
  ['family tiles visibly enlarge icons', /#page-dashboard \.family-icon[\s\S]*?font-size: 1\.7rem !important/.test(html)],
  ['family tile content remains scrollable within card', /#page-dashboard \.family-chart-container[\s\S]*?overflow-y: auto !important/.test(html)],
  ['critical alerts have their own scroll', /#page-dashboard \.critical-list[\s\S]*?overflow-y: auto !important/.test(html)],
  ['critical alert rows gain slightly larger size', /#page-dashboard \.critical-item[\s\S]*?min-height: 34px !important/.test(html)],
  ['critical attention follows the manual threshold and is not capped', /const urgentItems = stockAlertResults\.filter\(result => result\.status !== 'ok'\)/.test(html) && /const stockAlertResults = appState\.inventory\.map/.test(html) && !/window\.InventoryStockAlerts\.evaluate\(appState\.inventory/.test(html) && !/const urgentItems = appState\.inventory[\s\S]*?\.slice\(0,\s*5\)/.test(html)],
  ['dashboard keeps page-level scroll disabled', /html, body \{ height: 100%; overflow: hidden; \}/.test(html)],
  ['family names remain HTML-escaped', /data-family="\$\{esc\(name\)\}"/.test(html) && /<span class="family-name">\$\{esc\(name\)\}<\/span>/.test(html)],
];
let failed = 0;
for (const [name, ok] of checks) {
  process.stdout.write(`${ok ? 'PASS' : 'FAIL'} - ${name}\n`);
  if (!ok) failed++;
}
process.stdout.write(`\n${checks.length - failed}/${checks.length} pruebas correctas.\n`);
if (failed) process.exit(1);
