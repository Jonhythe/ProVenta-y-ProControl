$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$appRoot = Split-Path -Parent $PSScriptRoot
Push-Location $appRoot
try {
    if ($env:OS -ne 'Windows_NT') { throw 'Este validador debe ejecutarse en Windows.' }
    if (-not (Test-Path -LiteralPath (Join-Path $appRoot 'node_modules'))) {
        throw 'No se encontro node_modules. Ejecuta primero tools/upgrade-nsis-toolchain.ps1.'
    }

    Write-Host '== 1/4 Toolchain NSIS ==' -ForegroundColor Cyan
    & node.exe 'tools/check-nsis-toolchain.js'
    if ($LASTEXITCODE -ne 0) { throw 'Toolchain NSIS no coincide con las versiones fijadas.' }

    Write-Host '== 2/4 Pruebas de fuente ==' -ForegroundColor Cyan
    & npm.cmd run check-source
    if ($LASTEXITCODE -ne 0) { throw "check-source fallo con codigo $LASTEXITCODE." }

    Write-Host '== 3/4 Build NSIS x64 limpio ==' -ForegroundColor Cyan
    & node.exe 'tools/build-clean-nsis.js'
    if ($LASTEXITCODE -ne 0) { throw "La compilacion NSIS fallo con codigo $LASTEXITCODE." }

    $latest = Get-ChildItem -LiteralPath $appRoot -Directory -Filter 'dist_setup_definitivo_*' |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if (-not $latest) { throw 'No se creo dist_setup_definitivo_*.' }

    $manifest = Get-Content -LiteralPath (Join-Path $latest.FullName 'PROCONTROL_NSIS_BUILD.json') -Raw | ConvertFrom-Json
    $asarPath = Join-Path ([string]$manifest.outputDir) 'win-unpacked\resources\app.asar'
    if (-not (Test-Path -LiteralPath $asarPath -PathType Leaf)) { throw "No se encontro app.asar: $asarPath" }

    Write-Host '== 4/4 Escaneo de secretos ==' -ForegroundColor Cyan
    & node.exe 'tools/check-no-secrets.js' '--require-build' '--build-dir' ([string]$manifest.outputDir)
    if ($LASTEXITCODE -ne 0) { throw 'El escaneo de secretos fallo.' }

    & (Join-Path $appRoot 'tools\verificar-integridad.ps1') -BuildDirectory $latest.FullName

    Write-Host "`nVALIDACION AUTOMATIZADA APROBADA." -ForegroundColor Green
    Write-Host 'Aun falta la prueba manual: instalar en una maquina limpia y verificar la desinstalacion de esa instalacion.'
}
finally {
    Pop-Location
}
