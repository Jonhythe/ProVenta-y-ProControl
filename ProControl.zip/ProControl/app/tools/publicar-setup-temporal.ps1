﻿param(
    [string]$StageDirectory = 'D:\ProControl\ProControl_preparando_20261101_223423'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$appRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$workspaceRoot = Split-Path -Parent $appRoot
Set-Location -LiteralPath $appRoot

if (-not (Test-Path -LiteralPath $StageDirectory -PathType Container)) { throw "No existe la carpeta temporal: $StageDirectory" }
$package = Get-Content -LiteralPath (Join-Path $appRoot 'package.json') -Raw | ConvertFrom-Json
$setupName = "Setup-ProControl-$($package.version)-x64.exe"
$stagedSetup = Join-Path $StageDirectory $setupName
if (-not (Test-Path -LiteralPath $stagedSetup -PathType Leaf)) { throw "No se encuentra el Setup esperado: $stagedSetup" }
$stageSize = (Get-Item -LiteralPath $stagedSetup).Length
$stageHash = (Get-FileHash -LiteralPath $stagedSetup -Algorithm SHA256).Hash.ToUpperInvariant()

$matchedManifest = $null
$matchedBuild = $null
foreach ($folder in (Get-ChildItem -LiteralPath $appRoot -Directory -Filter 'dist_setup_definitivo_*' | Sort-Object LastWriteTime -Descending)) {
    $manifestPath = Join-Path $folder.FullName 'PROCONTROL_NSIS_BUILD.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { continue }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    if ([string]$manifest.version -ne [string]$package.version -or [string]$manifest.target -ne 'nsis' -or [string]$manifest.architecture -ne 'x64') { continue }
    if ([string]$manifest.sha256 -ine $stageHash -or [int64]$manifest.sizeBytes -ne $stageSize) { continue }
    $source = [string]$manifest.setupPath
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { continue }
    $sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToUpperInvariant()
    $sourceSize = (Get-Item -LiteralPath $source).Length
    if ($sourceHash -ne $stageHash -or $sourceSize -ne $stageSize) { continue }
    $matchedManifest = $manifest
    $matchedBuild = $folder.FullName
    break
}
if (-not $matchedManifest) { throw "No hay manifiesto cuyo SHA256 y tamano coincidan con el Setup temporal ($stageHash / $stageSize). No se publicara." }

Write-Host 'CANDIDATO TEMPORAL COINCIDE CON SU BUILD' -ForegroundColor Green
Write-Host "Build: $matchedBuild"
Write-Host "Bytes: $stageSize"
Write-Host "SHA256: $stageHash"
Write-Host "MANIFIESTO DEL BUILD: $(Join-Path $matchedBuild 'PROCONTROL_NSIS_BUILD.json')"
& node.exe 'tools/nsis-integrity.js' $stagedSetup
if ($LASTEXITCODE -ne 0) { throw 'El Setup temporal no supera la validacion NSIS.' }

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$deliveryDir = Join-Path $workspaceRoot ("ProControl_Entrega_{0}_{1}" -f $package.version, $stamp)
$reportPath = Join-Path $deliveryDir 'PROCONTROL-SETUP-SHA256.txt'
if (Test-Path -LiteralPath $deliveryDir) { throw "La carpeta de destino ya existe: $deliveryDir" }
New-Item -ItemType Directory -Path $deliveryDir | Out-Null
$publishedSetup = Join-Path $deliveryDir $setupName
try {
    Copy-Item -LiteralPath $stagedSetup -Destination $publishedSetup
    $hash1 = (Get-FileHash -LiteralPath $publishedSetup -Algorithm SHA256).Hash.ToUpperInvariant()
    $size1 = (Get-Item -LiteralPath $publishedSetup).Length
    Start-Sleep -Seconds 2
    $hash2 = (Get-FileHash -LiteralPath $publishedSetup -Algorithm SHA256).Hash.ToUpperInvariant()
    $size2 = (Get-Item -LiteralPath $publishedSetup).Length
    if ($hash1 -ne $stageHash -or $hash2 -ne $stageHash -or $size1 -ne $stageSize -or $size2 -ne $stageSize) { throw 'La copia publicada no coincide con el archivo temporal.' }
    & node.exe 'tools/nsis-integrity.js' $publishedSetup
    if ($LASTEXITCODE -ne 0) { throw 'La copia final no supera la validacion NSIS.' }
} catch {
    Write-Host "Se conserva el candidato temporal: $stagedSetup" -ForegroundColor Yellow
    throw
}
@(
    'PROCONTROL - ENTREGA INMUTABLE',
    "Version: $($package.version)",
    "Archivo: $setupName",
    "Bytes: $stageSize",
    "SHA256: $stageHash",
    "Build origen: $matchedBuild",
    'NSIS CRC: PASS en candidato y copia final',
    'La entrega anterior no se movio ni sobrescribio.'
) | Set-Content -LiteralPath (Join-Path $deliveryDir 'PROCONTROL-SETUP-SHA256.txt') -Encoding UTF8

Write-Host "`nPUBLICACION INMUTABLE COMPLETADA" -ForegroundColor Green
Write-Host "CARPETA: $deliveryDir"
Write-Host "SETUP: $publishedSetup"
Write-Host "BYTES: $stageSize"
Write-Host "SHA256: $stageHash"
Write-Host "REPORTE: $reportPath"
