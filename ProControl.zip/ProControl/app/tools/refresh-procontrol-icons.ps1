﻿[CmdletBinding()]
param([string]$ExePath)
$ErrorActionPreference = 'Stop'

$desktop = [Environment]::GetFolderPath('DesktopDirectory')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$taskbarPins = Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
$searchRoots = @($desktop, $startMenu, $taskbarPins) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
$ws = New-Object -ComObject WScript.Shell

function Get-LinkInfo([string]$Path) {
  try { $s = $ws.CreateShortcut($Path); [pscustomobject]@{ Path=$Path; Target=$s.TargetPath; Icon=$s.IconLocation } }
  catch { $null }
}

if (-not $ExePath) {
  $proc = Get-CimInstance Win32_Process -Filter "Name='ProControl.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.ExecutablePath -and (Test-Path -LiteralPath $_.ExecutablePath) } | Select-Object -First 1
  if ($proc) { $ExePath = $proc.ExecutablePath }
}

$links = @()
foreach ($root in $searchRoots) {
  $links += Get-ChildItem -LiteralPath $root -Filter '*.lnk' -File -Recurse -ErrorAction SilentlyContinue
}
$linkInfos = @($links | ForEach-Object { Get-LinkInfo $_.FullName } | Where-Object { $_ })

if (-not $ExePath) {
  $candidate = $linkInfos | Where-Object {
    [IO.Path]::GetFileName($_.Target) -ieq 'ProControl.exe' -and (Test-Path -LiteralPath $_.Target)
  } | Select-Object -First 1
  if ($candidate) { $ExePath = $candidate.Target }
}
if (-not $ExePath) {
  $defaults = @(
    (Join-Path $env:LOCALAPPDATA 'Programs\ProControl\ProControl.exe'),
    (Join-Path $env:ProgramFiles 'ProControl\ProControl.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'ProControl\ProControl.exe')
  ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
  if ($defaults) { $ExePath = $defaults[0] }
}
if (-not $ExePath -or -not (Test-Path -LiteralPath $ExePath)) {
  throw 'No pude localizar ProControl.exe. Ejecuta de nuevo pasando -ExePath con la ruta del ejecutable instalado.'
}
$ExePath = (Resolve-Path -LiteralPath $ExePath).Path
$working = Split-Path -Parent $ExePath
$updated = [System.Collections.Generic.List[string]]::new()
$matched = [System.Collections.Generic.List[string]]::new()

foreach ($info in $linkInfos) {
  $isProControl = ([IO.Path]::GetFileName($info.Path) -ieq 'ProControl.lnk') -or
    ([IO.Path]::GetFileName($info.Target) -ieq 'ProControl.exe') -or
    ($info.Target -match '(?i)ProControl')
  if (-not $isProControl) { continue }
  $shortcut = $ws.CreateShortcut($info.Path)
  $shortcut.TargetPath = $ExePath
  $shortcut.WorkingDirectory = $working
  $shortcut.IconLocation = "$ExePath,0"
  $shortcut.Description = 'ProControl'
  $shortcut.Save()
  $updated.Add($info.Path)
  $matched.Add($info.Path)
}

# Ensure an up-to-date desktop shortcut exists and points explicitly to the embedded EXE icon.
$desktopLink = Join-Path $desktop 'ProControl.lnk'
if (-not (Test-Path -LiteralPath $desktopLink)) {
  $shortcut = $ws.CreateShortcut($desktopLink)
  $shortcut.TargetPath = $ExePath
  $shortcut.WorkingDirectory = $working
  $shortcut.IconLocation = "$ExePath,0"
  $shortcut.Description = 'ProControl'
  $shortcut.Save()
  $updated.Add($desktopLink)
}

# Refresh Explorer's shell image cache notifications without killing Explorer or deleting caches.
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ProControlShellRefresh {
  [DllImport("shell32.dll")] public static extern void SHChangeNotify(int eventId, uint flags, IntPtr item1, IntPtr item2);
}
'@ -ErrorAction SilentlyContinue
[ProControlShellRefresh]::SHChangeNotify(0x08000000, 0x00001000, [IntPtr]::Zero, [IntPtr]::Zero)

Write-Host 'Iconos de ProControl actualizados.' -ForegroundColor Green
Write-Host "Ejecutable: $ExePath"
Write-Host "Accesos directos actualizados: $($updated.Count)"
foreach ($item in $updated) { Write-Host "  $item" }
Write-Host 'Si un icono anclado sigue mostrando la imagen antigua, desancla SOLO ProControl y vuelve a anclarlo desde Inicio.' -ForegroundColor Yellow
