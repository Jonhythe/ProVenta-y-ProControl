$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$appRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$packagePath = Join-Path $appRoot 'package.json'
$lockPath = Join-Path $appRoot 'package-lock.json'
$backupRoot = Join-Path $appRoot 'backups'
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $backupRoot ("nsis-toolchain-before-26.18.1_" + $stamp)

if ($env:OS -ne 'Windows_NT') { throw 'Este proceso debe ejecutarse en Windows.' }
if (-not (Test-Path -LiteralPath $packagePath -PathType Leaf)) { throw "No se encontro package.json en $appRoot." }
if (-not (Test-Path -LiteralPath $lockPath -PathType Leaf)) { throw 'Falta package-lock.json; no se modifica el proyecto.' }
if (-not (Get-Command node.exe -ErrorAction SilentlyContinue)) { throw 'Node.js no esta disponible en PATH.' }
if (-not (Get-Command npm.cmd -ErrorAction SilentlyContinue)) { throw 'npm no esta disponible en PATH.' }

$pkg = Get-Content -LiteralPath $packagePath -Raw | ConvertFrom-Json
if ($pkg.name -ne 'procontrol-desktop') { throw 'El package.json no corresponde a ProControl.' }
if ([string]$pkg.devDependencies.electron -ne '39.8.10') {
    throw "Se esperaba Electron 39.8.10; se encontro $($pkg.devDependencies.electron). No se actualiza Electron en este parche."
}

New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
Copy-Item -LiteralPath $packagePath -Destination (Join-Path $backupDir 'package.json') -Force
Copy-Item -LiteralPath $lockPath -Destination (Join-Path $backupDir 'package-lock.json') -Force

Write-Host 'ACTUALIZANDO TOOLCHAIN NSIS DE PROCONTROL' -ForegroundColor Cyan
Write-Host "Copia de seguridad: $backupDir"
Write-Host 'electron-builder: 26.18.1 (rama estable v26)'
Write-Host 'Electron se conserva en 39.8.10.'

Push-Location $appRoot
try {
    & npm.cmd install --save-dev --save-exact electron-builder@26.18.1 --no-audit --no-fund --fetch-retries=5 --fetch-retry-mintimeout=20000 --fetch-retry-maxtimeout=120000
    $code = $LASTEXITCODE
    if ($code -ne 0) {
        Copy-Item -LiteralPath (Join-Path $backupDir 'package.json') -Destination $packagePath -Force
        Copy-Item -LiteralPath (Join-Path $backupDir 'package-lock.json') -Destination $lockPath -Force
        throw "npm install fallo con codigo $code. Se restauraron package.json y package-lock.json. No compiles hasta volver a ejecutar este actualizador correctamente."
    }

    & node.exe (Join-Path $appRoot 'tools\check-nsis-toolchain.js')
    if ($LASTEXITCODE -ne 0) {
        throw 'La verificacion de versiones instaladas fallo. No se debe compilar.'
    }

    & npm.cmd run check-source
    if ($LASTEXITCODE -ne 0) {
        throw 'Las pruebas de codigo fuente fallaron despues de actualizar electron-builder.'
    }

    Write-Host "`nTOOLCHAIN ACTUALIZADO Y PRUEBAS DE FUENTE APROBADAS." -ForegroundColor Green
    Write-Host 'Ya puedes ejecutar: npm run dist'
}
finally {
    Pop-Location
}
