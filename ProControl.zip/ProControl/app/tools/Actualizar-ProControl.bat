@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell.exe"
if not exist "%~dp0Actualizar-ProControl.ps1" (
  echo ERROR: Falta Actualizar-ProControl.ps1 junto a este BAT.
  pause
  exit /b 20
)
if not exist "%~dp0MANIFEST.json" (
  echo ERROR: Falta MANIFEST.json. Extrae el ZIP completo antes de continuar.
  pause
  exit /b 21
)
if not exist "%~dp0ProControl\ProControl.exe" (
  echo ERROR: Falta ProControl\ProControl.exe. La entrega esta incompleta.
  pause
  exit /b 22
)

"%PS%" -NoLogo -NoProfile -NonInteractive -STA -ExecutionPolicy Bypass -File "%~dp0Actualizar-ProControl.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo La operacion no termino. No vuelvas a ejecutarla hasta revisar el error.
  pause
)
exit /b %RC%
