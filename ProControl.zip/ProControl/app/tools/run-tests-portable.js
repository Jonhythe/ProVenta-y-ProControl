'use strict';
// Arnés auxiliar para validar tests de licencia fuera de Windows.
// En Windows se debe ejecutar directamente: node tools/test-license.js
const cp = require('child_process');
const original = cp.execFileSync;
cp.execFileSync = function (file, args, options) {
  if (Array.isArray(args) && args.includes('MachineGuid')) {
    return '    MachineGuid    REG_SZ    E5A913DB-E606-4709-8605-531B320F5D5F\r\n';
  }
  return original.apply(this, arguments);
};
require('./test-license.js');
