#!/usr/bin/env node
'use strict';

/**
 * Validador NSIS conservador para ProControl.
 *
 * Importante:
 * - Reproduce la comprobacion CRC de exehead/NSIS (misma logica que electron-builder).
 * - Si el encabezado no es visible en bytes (por ejemplo, PE/UPX empaquetado),
 *   devuelve INDETERMINATE; NO afirma que el archivo este corrupto.
 * - No usa 7-Zip para decidir si un instalador NSIS es valido.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ALIGNMENT = 512;
const FIRST_HEADER_SIZE = 28;
const MAGIC = 0xDEADBEEF;
const SIGNATURE = Buffer.from('NullsoftInst', 'ascii');
const FLAG_UNINSTALL = 0x1;
const FLAG_NO_CRC = 0x4;
const FLAG_FORCE_CRC = 0x8;
const FLAG_MASK = 0x0F;

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let c = i;
    for (let j = 0; j < 8; j += 1) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buffer, start = 0, end = buffer.length) {
  if (!Buffer.isBuffer(buffer)) throw new TypeError('crc32 requiere un Buffer.');
  if (!Number.isInteger(start) || !Number.isInteger(end) || start < 0 || end < start || end > buffer.length) {
    throw new RangeError('Rango CRC-32 no valido.');
  }
  let crc = 0xFFFFFFFF;
  for (let i = start; i < end; i += 1) {
    crc = CRC_TABLE[(crc ^ buffer[i]) & 0xFF] ^ (crc >>> 8);
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function readPeInfo(buffer) {
  const result = { isPE: false, sectionNames: [], hasUpxSections: false };
  if (!Buffer.isBuffer(buffer) || buffer.length < 64 || buffer.toString('ascii', 0, 2) !== 'MZ') {
    return result;
  }
  const peOffset = buffer.readUInt32LE(0x3C);
  if (peOffset < 64 || peOffset + 24 > buffer.length || buffer.toString('binary', peOffset, peOffset + 4) !== 'PE\0\0') {
    return result;
  }
  const sectionCount = buffer.readUInt16LE(peOffset + 6);
  const optionalHeaderSize = buffer.readUInt16LE(peOffset + 20);
  const sectionTable = peOffset + 24 + optionalHeaderSize;
  if (sectionCount > 96 || sectionTable + sectionCount * 40 > buffer.length) return result;

  const sectionNames = [];
  for (let i = 0; i < sectionCount; i += 1) {
    const at = sectionTable + i * 40;
    const raw = buffer.subarray(at, at + 8);
    const name = raw.toString('ascii').replace(/\0.*$/, '');
    sectionNames.push(name);
  }
  result.isPE = true;
  result.sectionNames = sectionNames;
  result.hasUpxSections = sectionNames.some(name => /^UPX[0-9]$/i.test(name));
  return result;
}

function isFirstHeaderAt(buffer, offset) {
  if (offset < 0 || offset + FIRST_HEADER_SIZE > buffer.length) return false;
  const flags = buffer.readUInt32LE(offset);
  if ((flags & ~FLAG_MASK) !== 0) return false;
  return buffer.readUInt32LE(offset + 4) === MAGIC &&
    buffer.subarray(offset + 8, offset + 20).equals(SIGNATURE);
}

function findFirstHeader(buffer) {
  if (!Buffer.isBuffer(buffer)) throw new TypeError('findFirstHeader requiere un Buffer.');
  for (let offset = 0; offset + FIRST_HEADER_SIZE <= buffer.length; offset += ALIGNMENT) {
    if (isFirstHeaderAt(buffer, offset)) return offset;
  }
  return -1;
}

function inspectNsisBuffer(buffer, options = {}) {
  if (!Buffer.isBuffer(buffer)) throw new TypeError('inspectNsisBuffer requiere un Buffer.');
  const label = options.label || 'archivo';
  const expectedKind = options.expectedKind || null;
  const pe = readPeInfo(buffer);
  const offset = findFirstHeader(buffer);

  if (offset < 0) {
    return {
      status: 'INDETERMINATE',
      valid: null,
      reason: pe.hasUpxSections
        ? 'No se puede leer la primera cabecera NSIS en claro; el PE contiene secciones UPX. No se declara corrupto por una busqueda binaria.'
        : 'No se encontro una primera cabecera NSIS verificable en los limites de 512 bytes.',
      label,
      fileSize: buffer.length,
      sha256: crypto.createHash('sha256').update(buffer).digest('hex').toUpperCase(),
      pe,
    };
  }

  const flags = buffer.readUInt32LE(offset);
  const isUninstaller = (flags & FLAG_UNINSTALL) !== 0;
  const kind = isUninstaller ? 'uninstaller' : 'installer';
  if (expectedKind && expectedKind !== kind) {
    return {
      status: 'INVALID',
      valid: false,
      reason: `Tipo incorrecto: se esperaba ${expectedKind} y la cabecera indica ${kind}.`,
      label, offset, flags, kind, fileSize: buffer.length,
      sha256: crypto.createHash('sha256').update(buffer).digest('hex').toUpperCase(),
      pe,
    };
  }

  const lengthOfAllFollowingData = buffer.readUInt32LE(offset + 24);
  if (lengthOfAllFollowingData < FIRST_HEADER_SIZE + 4 ||
      lengthOfAllFollowingData > buffer.length - offset) {
    return {
      status: 'INVALID',
      valid: false,
      reason: 'La longitud NSIS es inconsistente o apunta fuera del ejecutable.',
      label, offset, flags, kind, lengthOfAllFollowingData,
      fileSize: buffer.length,
      sha256: crypto.createHash('sha256').update(buffer).digest('hex').toUpperCase(),
      pe,
    };
  }

  const noCrc = (flags & FLAG_NO_CRC) !== 0;
  const forceCrc = (flags & FLAG_FORCE_CRC) !== 0;
  if (noCrc && !forceCrc) {
    return {
      status: 'INVALID',
      valid: false,
      reason: 'El ejecutable NSIS desactiva CRC; ProControl exige CRC habilitado.',
      label, offset, flags, kind, lengthOfAllFollowingData,
      fileSize: buffer.length,
      sha256: crypto.createHash('sha256').update(buffer).digest('hex').toUpperCase(),
      pe,
    };
  }

  const crcOffset = offset + lengthOfAllFollowingData - 4;
  const crcStart = offset === 0 ? 0 : ALIGNMENT;
  if (crcOffset < crcStart || crcOffset + 4 > buffer.length) {
    return {
      status: 'INVALID',
      valid: false,
      reason: 'El rango del CRC NSIS queda fuera del archivo.',
      label, offset, flags, kind, lengthOfAllFollowingData, crcOffset,
      fileSize: buffer.length,
      sha256: crypto.createHash('sha256').update(buffer).digest('hex').toUpperCase(),
      pe,
    };
  }

  const storedCrc = buffer.readUInt32LE(crcOffset);
  const calculatedCrc = crc32(buffer, crcStart, crcOffset);
  const valid = storedCrc === calculatedCrc;
  return {
    status: valid ? 'VALID' : 'INVALID',
    valid,
    reason: valid ? null : 'El CRC-32 almacenado no coincide con la comprobacion de NSIS.',
    label,
    offset,
    flags,
    kind,
    lengthOfAllFollowingData,
    crcOffset,
    crcStart,
    crcStored: storedCrc.toString(16).toUpperCase().padStart(8, '0'),
    crcCalculated: calculatedCrc.toString(16).toUpperCase().padStart(8, '0'),
    crcEnabled: true,
    fileSize: buffer.length,
    sha256: crypto.createHash('sha256').update(buffer).digest('hex').toUpperCase(),
    pe,
  };
}

function inspectNsisFile(filePath, options = {}) {
  const resolved = path.resolve(filePath);
  const buffer = fs.readFileSync(resolved);
  return inspectNsisBuffer(buffer, { ...options, label: options.label || resolved });
}

module.exports = {
  crc32,
  findFirstHeader,
  readPeInfo,
  inspectNsisBuffer,
  inspectNsisFile,
};

if (require.main === module) {
  const filePath = process.argv[2];
  const expectedKind = process.argv.includes('--uninstaller') ? 'uninstaller' : 'installer';
  if (!filePath) {
    console.error('Uso: node tools/nsis-integrity.js "ruta\\Setup.exe" [--uninstaller]');
    process.exit(2);
  }
  try {
    const result = inspectNsisFile(filePath, { expectedKind });
    console.log(JSON.stringify(result, null, 2));
    if (result.status === 'VALID') {
      console.log('NSIS INTEGRITY: PASS');
      process.exit(0);
    }
    console.error(`NSIS INTEGRITY: ${result.status}`);
    console.error(result.reason || 'No se pudo validar el archivo.');
    process.exit(result.status === 'INDETERMINATE' ? 3 : 1);
  } catch (error) {
    console.error('NSIS INTEGRITY: ERROR');
    console.error(error.message);
    process.exit(1);
  }
}
