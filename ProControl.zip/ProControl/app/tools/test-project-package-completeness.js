#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const ROOT = path.resolve(__dirname, '..');
const readJson = file => JSON.parse(fs.readFileSync(path.join(ROOT, file), 'utf8'));

function main() {
  const rootPackagePath = path.join(ROOT, 'package.json');
  const lockPath = path.join(ROOT, 'package-lock.json');
  assert(fs.existsSync(rootPackagePath), 'Falta el package.json principal en la raíz del proyecto.');
  assert(fs.existsSync(lockPath), 'Falta package-lock.json en la raíz del proyecto.');

  const pkg = readJson('package.json');
  const lock = readJson('package-lock.json');

  assert.equal(pkg.name, 'procontrol-desktop', 'El package.json principal no corresponde a ProControl.');
  assert(pkg.version, 'El package.json principal no declara versión.');
  assert(pkg.scripts && typeof pkg.scripts['check-source'] === 'string', 'El package.json principal no declara check-source.');
  assert(pkg.scripts && typeof pkg.scripts['precheck-source'] === 'string', 'El package.json principal no declara precheck-source.');
  assert(pkg.scripts && typeof pkg.scripts.dist === 'string', 'El package.json principal no declara dist.');
  assert(pkg.build && typeof pkg.build === 'object', 'El package.json principal no contiene la configuración electron-builder.');
  assert(Array.isArray(pkg.build.files) && pkg.build.files.includes('!electron/**/*.bak'),
    'Los respaldos locales deben excluirse del runtime empaquetado.');
  assert.equal(lock.name, pkg.name, 'package-lock.json y package.json tienen nombres diferentes.');
  assert.equal(lock.version, pkg.version, 'package-lock.json y package.json tienen versiones diferentes.');
  assert.equal(lock.packages && lock.packages[''] && lock.packages[''].name, pkg.name,
    'La entrada raíz de package-lock.json no corresponde a ProControl.');

  assert.equal(pkg.main, 'electron/main.js', 'El proyecto no declara electron/main.js como entrypoint.');

  const references = ['precheck-source', 'check-source'].flatMap(script =>
    [...pkg.scripts[script].matchAll(/(?:^|&&)\s*node\s+([^\s&]+)/g)].map(match => match[1])
  );
  assert(references.length > 0, 'No se encontraron comandos Node en check-source.');
  const missing = references.filter(relative => !fs.existsSync(path.resolve(ROOT, relative)));
  assert.deepEqual(missing, [], `check-source referencia archivos ausentes:\n${missing.join('\n')}`);

  const required = [
    'tools/test-runtime-package-completeness.js',
    'tools/test-electron-navigation-policy.js',
    'tools/test-password-hardening.js',
    'tools/check-nsis-toolchain.js',
    'tools/build-clean-nsis.js',
    'build/installer.nsh',
    'assets/icono.ico',
    'electron/main.js',
    'electron/preload.js',
    'electron/license.js',
    'electron/license-core.js',
    'electron/license-config.js',
    'electron/mobile-bridge/store.js',
    'electron/mobile-bridge/control-plane.js',
    'electron/mobile-bridge/proventa-snapshot.js',
    'electron/mobile-bridge/fragments.js',
    'electron/mobile-bridge/sales-write-policy.js',
    'electron/record-archive-store.js',
    'electron/security/authorized-store-wipe.js',
    'electron/security/navigation-policy.js',
    'renderer/index.html',
    'renderer/security.js',
    'renderer/license.html',
    'renderer/splash.html',
  ];
  const absent = required.filter(relative => !fs.existsSync(path.join(ROOT, relative)));
  assert.deepEqual(absent, [], `Faltan archivos esenciales del proyecto/runtime:\n${absent.join('\n')}`);

  // Tres pruebas de licencias leen herramientas de ../licensor desde la raíz del repositorio.
  const repoRoot = path.resolve(ROOT, '..');
  const licensorRequired = [
    'licensor/emitir-licencia.js',
    'licensor/emitir-licencia-pos.js',
    'licensor/gen-license-keys.js',
    'licensor/Generador-Codigos-ProControl.template.html',
    'licensor/license_public.pem',
    'licensor/ROTACION-CLAVE-REQUERIDA.txt',
  ];
  const licensorAbsent = licensorRequired.filter(relative => !fs.existsSync(path.join(repoRoot, relative)));
  assert.deepEqual(licensorAbsent, [], `Faltan recursos de licenciamiento del repositorio:\n${licensorAbsent.join('\n')}`);

  console.log(`PROJECT_PACKAGE_OK: ${references.length} referencias node de check-source resueltas.`);
  console.log('Manifiesto principal y lockfile coherentes; runtime se prepara desde esta fuente única.');
  console.log(`Archivos esenciales presentes: ${required.length}.`);
}

try { main(); }
catch (error) {
  console.error('\nPROJECT_PACKAGE_ERROR');
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
}
