'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'renderer', 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'renderer', 'mobile-bridge-ui.js'), 'utf8');
const bridgeSource = fs.readFileSync(path.join(root, 'electron', 'mobile-bridge', 'store.js'), 'utf8');
const mainSource = fs.readFileSync(path.join(root, 'electron', 'main.js'), 'utf8');
let assertionCount = 0;
function expect(condition, message) { assertionCount++; assert.ok(condition, message); }

// Static wiring checks catch missing modal elements and route/load failures.
expect(html.includes("ProVentaAuthorizationUI.openForCurrentPOS('open')") &&
  html.includes("ProVentaAuthorizationUI.openForCurrentPOS('close')"), 'Las acciones actuales de apertura y cierre de ProVenta deben estar en el POS activo.');
expect(html.includes('Exportar abrir turno') && html.includes('Recibir cierre de ProVenta'), 'Las acciones de ProVenta deben conservar los rótulos actuales de la interfaz.');
expect(!html.includes('ProVentaAuthorizationUI.open()'), 'No debe existir una entrada global para vincular teléfonos ProVenta.');
expect(js.includes("Auth.requireRole(['Dueño', 'Administrador']"), 'La UI debe limitar el panel a Dueño/Administrador.');
expect(html.includes('<script src="app://mobile-bridge-ui.js"></script>'), 'Debe cargar el módulo móvil mediante el protocolo app://.');
for (const id of [
  'mobile-bridge-overlay', 'mobile-bridge-status', 'mobile-bridge-role', 'mobile-bridge-code',
  'mobile-bridge-code-expiry', 'mobile-bridge-devices', 'mobile-bridge-packages', 'mobile-bridge-package-detail'
]) expect(html.includes(`id="${id}"`), `Falta el elemento de interfaz ${id}.`);
for (const method of ['status','listDevices','setDeviceEnabled','listPendingPackages','getPackage','decidePackage']) {
  expect(js.includes(`'${method}'`) || js.includes(`.${method}(`), `La UI debe invocar la API ${method}.`);
}
expect(html.includes('no cambian stock hasta aceptar y conciliar explícitamente'), 'La interfaz debe advertir que importar no modifica existencias antes de conciliar.');
expect(html.includes('Importar paquete desde USB'), 'Debe existir el flujo de importación offline por archivo.');
expect(html.includes('Exportar catálogo y stock'), 'Debe existir la exportación de catálogo e inventario.');
expect(html.includes('Validar y conciliar'), 'Debe existir la conciliación explícita del paquete aceptado.');
expect(js.includes('closingReport') && js.includes('expectedSalesCupMinor') && js.includes('countedTotalCupMinor'), 'La aprobación de cierres debe mostrar ventas esperadas y dinero contado.');
expect(js.includes("call('createPackageAcknowledgement', { packageId, authToken })") && js.includes("showQrDocument('A', acknowledgement.acknowledgement, packageId)"), 'Al confirmar o rechazar un cierre debe generarse el acuse firmado para devolverlo al móvil.');
expect(js.includes('button.dataset.packageId') && js.includes('data-package-id='), 'Cada solicitud debe conservar el paquete exacto que originó el cierre.');
expect(js.includes('Ver IPV resumido') && js.includes('Ver informe completo y desglose de efectivo'), 'El dueño debe poder revisar el IPV y el desglose antes de confirmar.');
expect(js.includes('Confirmar solicitud') && js.includes('No altera automáticamente el efectivo'), 'La UI debe aclarar que aprobar no modifica automáticamente caja ni inventario.');
expect(mainSource.includes('LEGACY_POS_PAIRING_DISABLED'), 'El backend debe bloquear el emparejamiento antiguo por POS.');
expect(js.includes('LEGACY_POS_PAIRING_DISABLED'), 'La interfaz antigua debe dirigir al botón nuevo de ProVenta.');
expect(bridgeSource.includes("networkListener: false"), 'El puente debe mantener apagado el listener de red.');
expect(!/listen\s*\(/i.test(bridgeSource), 'El backend base no debe abrir listeners de red.');
expect(js.includes("!!posId && String(d.posId || '') === String(posId)") && !js.includes('installationAuthorized ||'), 'El selector de permisos solo debe ofrecer teléfonos fijados al POS elegido.');
expect(js.includes("id: String(item && item.id || '')"), 'El plano de control debe pasar el ID persistido del POS, sin prefijo pos:, al proceso principal.')
expect(js.includes('d.employeeName'), 'El selector identifica al trabajador asociado al teléfono autorizado.');
expect(js.includes('Teléfono autorizado exclusivamente para el POS'), 'La confirmación del permiso debe aclarar que el teléfono pertenece exclusivamente a ese POS y turno.');

// Lightweight DOM+bridge smoke test exercises the real UI controller without Electron.
// Override permitido solo en el proceso de pruebas Node; no se activa en Electron.
process.env.PROCONTROL_TEST_MOBILE_UI = '1';
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, { id, textContent: '', innerHTML: '', value: id === 'mobile-bridge-role' ? 'operator' : '', style: {}, dataset: {}, select() {}, setAttribute() {}, remove() {} });
  return elements.get(id);
}
global.document = {
  getElementById: element,
  createElement: () => ({ value: '', setAttribute() {}, select() {}, remove() {} }),
  body: { appendChild() {} },
  execCommand: () => true
};
let enabledChange = null;
let decided = null;
let codeCalls = 0;
let packageStatus = 'pending_review';
Object.defineProperty(global, 'navigator', { configurable: true, value: { clipboard: { writeText: async value => { global.__copiedCode = value; } } } });
let roleAllowed = false;
global.Auth = { requireRole: roles => { assert.deepEqual(roles, ['Dueño', 'Administrador']); return roleAllowed; } };
global.confirm = () => true;
global.prompt = () => 'prueba fase 7';
global.askInput = async () => ({ user: 'admin-prueba', password: 'clave-prueba' });
global.appState = { currentUser:'admin-prueba', currentUserRole:'Dueño', businessData:{name:'Tienda demo'}, dollarRate:24, inventory:[], productCatalog:[], pointsOfSale:[{id:'pos_test_0001',name:'POS de prueba',inventory:[],salesTrackingEnabled:true}], salesLedger:[], transfers:[], closingSessions:{}, auditLog:[] };
global.Inventory = { posReference: pos => pos.id, _productIdForItem: item => item && item.productId, productIdForName: () => null, unitsPerBoxForPOSItem: () => null };
global.DataStore = { save: () => true, transaction: (_label, keys, fn) => { const snapshot={}; keys.forEach(k=>snapshot[k]=JSON.parse(JSON.stringify(global.appState[k]))); try { return {ok:true,result:fn()}; } catch(e) { keys.forEach(k=>global.appState[k]=snapshot[k]); return {ok:false,error:e}; } } };
global.SalesLedgerOps = { validateTransaction: () => true };
global.ProductUnits = {};
global.window = {
  confirm: global.confirm,
  prompt: global.prompt,
  PCMobileBridge: {
    authorizeControl: async () => ({ ok: true, token: 'test-control-auth-token', expiresAt: Date.now() + 300000 }),
    status: async () => ({ ok: true, version: 1, transport: 'not-configured', networkListener: false, devices: 1, pendingPackages: 1, note: 'Solo almacenamiento local.' }),
    createPairingCode: async input => { codeCalls++; assert.equal(input.role, 'operator'); assert.equal(input.posId, 'pos_test_0001'); return { ok: true, code: '123456', expiresAt: Date.now() + 300000, assignedRole: 'operator', assignedPosId: 'pos_test_0001' }; },
    listDevices: async () => ({ ok: true, devices: [
      { deviceId: 'device_test_0001', label: 'Móvil de prueba', role: 'operator', enabled: 1, posId: 'pos_test_0001', installationId: 'pcinst_test_00000000000000000000000000000000', authorizationId: 'auth_test_0001', employeeName: 'Dependiente POS actual', pairedAt: Date.now(), lastSeenAt: null },
      { deviceId: 'device_other_0001', label: 'Móvil de otro POS', role: 'operator', enabled: 1, posId: 'pos_otro_0001', installationId: 'pcinst_test_00000000000000000000000000000000', authorizationId: 'auth_other_0001', employeeName: 'Dependiente de otra sucursal', pairedAt: Date.now(), lastSeenAt: null }
    ] }),
    setDeviceEnabled: async input => { enabledChange = input; return { ok: true }; },
    listPendingPackages: async () => ({ ok: true, packages: [{ packageId: 'package_test_001', deviceId: 'device_test_0001', type: 'sale_batch', status: packageStatus, receivedAt: Date.now() }] }),
    getPackage: async id => ({ ok: true, package: { packageId: id, deviceId:'device_test_0001', type:'sale_batch', status: packageStatus, payload: { items: [{ productId: 'p1', qty: 2 }] } } }),
    decidePackage: async input => { decided = input; packageStatus = input.decision; return { ok: true }; },
    exportPairingDescriptor: async () => ({ok:true,fileName:'pair.pcpair'}),
    exportDesktopPackage: async () => ({ok:true,fileName:'snapshot.pcpkg',bytes:123}),
    importFile: async () => ({ok:true,packageId:'package_test_001'}),
    markPackageApplied: async () => ({ok:true})
  }
};
require(path.join(root, 'renderer', 'mobile-bridge-ui.js'));
(async () => {
  await window.MobileBridgeUI.open();
  expect(element('mobile-bridge-overlay').style.display !== 'flex', 'Un usuario sin rol autorizado no debe abrir el panel.');
  roleAllowed = true;
  await window.MobileBridgeUI.open();
  expect(element('mobile-bridge-overlay').style.display === 'flex', 'Al abrir se debe mostrar el panel.');
  expect(element('mobile-bridge-status').textContent.includes('sin transporte activo'), 'Debe mostrar que no hay transporte activo.');
  expect(element('mobile-bridge-devices').innerHTML.includes('Móvil de prueba'), 'Debe renderizar dispositivos usando los datos del puente.');
  expect(element('mobile-bridge-packages').innerHTML.includes('package_test_001'), 'Debe renderizar paquetes pendientes.');
  const legacyCode = await window.MobileBridgeUI.createCode();
  expect(legacyCode && legacyCode.code === 'LEGACY_POS_PAIRING_DISABLED' && codeCalls === 0, 'El panel antiguo no debe emitir códigos vinculados a un POS.');
  expect(element('mobile-bridge-status').textContent.includes('Generar código ProVenta') || element('mobile-bridge-code-card').style.display === 'none', 'El flujo antiguo debe quedar oculto y dirigir a la nueva administración.');
  await window.MobileBridgeUI.toggleDevice('device_test_0001', false);
  expect(enabledChange && enabledChange.enabled === false, 'Debe enviar la revocación del dispositivo.');
  await window.MobileBridgeUI.viewPackage('package_test_001');
  expect(element('mobile-bridge-package-detail-wrap').style.display === 'block', 'Debe mostrar el detalle del paquete.');
  await window.MobileBridgeUI.decideSelected('accepted_for_reconciliation');
  expect(decided && decided.decision === 'accepted_for_reconciliation' && decided.note === 'prueba fase 7', 'Debe guardar la decisión y su nota.');
  expect(element('mobile-bridge-package-detail-wrap').style.display === 'block', 'Al aceptar para conciliación debe conservarse el detalle.');
  expect(element('mobile-bridge-apply-selected').style.display === 'inline-flex', 'Después de aceptar debe habilitarse la conciliación explícita.');
  window.MobileBridgeUI.close();
  expect(element('mobile-bridge-overlay').style.display === 'none', 'El panel debe cerrar correctamente.');
  console.log(`Mobile bridge UI: ${assertionCount} assertions passed.`);
})().catch(error => { console.error(error); process.exitCode = 1; });
