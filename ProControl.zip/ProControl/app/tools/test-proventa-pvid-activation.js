'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
global.ProControlQrEngine = require('../renderer/qrcode-engine');
const QR = require('../renderer/local-qr');
const {
  MobileBridgeStore,
  decodeProVentaActivationCode,
  stableJson
} = require('../electron/mobile-bridge/store');
const { writeProVentaAuthorizationFile } = require('../electron/mobile-bridge/proventa-code-file');
let assertions = 0;
function ok(value, message) { assertions++; assert.ok(value, message); }
function equal(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
function makeIdentity(label = 'Samsung SM-A266M') {
  const signing = crypto.generateKeyPairSync('ed25519');
  const encryption = crypto.generateKeyPairSync('rsa', { modulusLength: 3072, publicExponent: 0x10001 });
  const doc = {
    format: 'proventa.device-identity', version: 1,
    deviceId: 'device_' + crypto.randomBytes(16).toString('hex'),
    label,
    devicePublicKey: signing.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    deviceEncryptionPublicKey: encryption.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    createdAt: new Date().toISOString()
  };
  doc.signature = {
    algorithm: 'Ed25519',
    value: crypto.sign(null, Buffer.from(stableJson(doc), 'utf8'), signing.privateKey).toString('base64')
  };
  return {
    document: doc,
    token: 'PVID1:' + Buffer.from(JSON.stringify(doc), 'utf8').toString('base64url')
  };
}
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-proventa-pvid-'));
let store;
try {
  store = new MobileBridgeStore(root, { desktopId: 'desktop_pvid_test' });
  const identity = makeIdentity();
  const result = store.createDeviceAuthorizationFromIdentity(identity.token, {
    employeeName: 'José Dependiente', employeeData: 'Prueba de firma', posId: 'pos_pvid_demo_01', authorizedPosName: 'Almacén Central'
  }, 'Dueño');
  ok(result.ok === true, 'ProControl genera la autorización desde el archivo PVID1.');
  ok(result.activationCode.startsWith('PVLA2:'), 'El resultado es un código PVLA2 copiable.');
  ok(result.activationCode.length > 100 && result.activationCode.length <= 4000, 'El código completo está dentro del límite admitido por Android.');
  ok(!Object.prototype.hasOwnProperty.call(result, 'authorizationDescriptor'), 'ProControl no expone un descriptor JSON paralelo al código PVLA2.');
  const singleQr = QR.getInfo(result.activationCode, 6);
  const singleQrSvg = QR.toSvg(result.activationCode, 6);
  ok(singleQr.mode === 'alphanumeric' && singleQr.errorCorrection === 'M', 'La autorización PVLA2 se codifica en modo alfanumérico estándar y corrección M.');
  const savedCode = writeProVentaAuthorizationFile(result.activationCode, path.join(root, 'exported-code'));
  equal(fs.readFileSync(savedCode.filePath, 'utf8').trim(), result.activationCode,
    'El archivo exportado contiene exactamente el mismo PVLA2 que el QR único.');
  equal(savedCode.fileName, 'ProVenta Codigo.pvla2', 'El archivo conserva el nombre de autorización acordado.');
  ok(singleQr.version >= 1 && singleQr.version <= 25, 'El PVLA2 real cabe en un único QR estándar, sin fragmentos.');
  equal(singleQr.modules, singleQr.version * 4 + 17, 'La matriz única respeta el tamaño Model 2 estándar de su versión.');
  ok(singleQrSvg.includes('<svg') && !singleQrSvg.includes('PCQ1'), 'El QR único contiene directamente el texto PVLA2 y no una envoltura de fragmentos.');

  const decoded = decodeProVentaActivationCode(result.activationCode);
  const descriptor = decoded.descriptor;
  ok(typeof decoded.rawJson === 'string' && decoded.rawJson.length > 0, 'El mismo token PVLA2 contiene el descriptor Ed25519 que verificará ProVenta.');
  ok(Buffer.byteLength(decoded.rawJson, 'utf8') <= 8192, 'El descriptor firmado respeta el límite de autorización.');
  equal(descriptor.version, 4, 'El token contiene descriptor v4.');
  equal(descriptor.permanent, true, 'La autorización es permanente.');
  equal(descriptor.deviceId, identity.document.deviceId, 'La autorización queda ligada al ID del teléfono.');
  equal(descriptor.authorizedPosId, 'pos_pvid_demo_01', 'La autorización queda ligada al POS solicitado.');
  equal(descriptor.authorizedPosName, 'Almacén Central', 'La autorización firmada conserva el nombre exacto del POS para confirmarlo en ProVenta.');
  equal(descriptor.employeeName, 'José Dependiente', 'Se conserva el nombre del trabajador con caracteres UTF-8.');
  const desktopPublic = crypto.createPublicKey(store.getDesktopPublicKey());
  const unsigned = { ...descriptor };
  delete unsigned.signature;
  ok(crypto.verify(null, Buffer.from(stableJson(unsigned), 'utf8'), desktopPublic, Buffer.from(descriptor.signature.value, 'base64')),
    'La firma Ed25519 del código PVLA2 es válida.');

  const authorization = store.db.prepare(`SELECT status,installation_id,authorized_pos_id,device_id
    FROM device_authorizations WHERE authorization_id=?`).get(result.authorizationId);
  equal(authorization.status, 'active', 'La autorización queda registrada en la instalación.');
  equal(authorization.installation_id, store.getInstallationId(), 'El registro pertenece a la instalación actual.');
  equal(authorization.authorized_pos_id, 'pos_pvid_demo_01', 'El registro interno tiene el POS correcto.');
  equal(authorization.device_id, identity.document.deviceId, 'El registro interno tiene el ID del teléfono.');
  const device = store.db.prepare(`SELECT enabled,pos_id,installation_id,authorization_id,public_key,encryption_public_key
    FROM devices WHERE device_id=?`).get(identity.document.deviceId);
  ok(device && device.enabled === 1, 'El teléfono queda registrado como dispositivo activo.');
  equal(device.pos_id, 'pos_pvid_demo_01', 'El dispositivo queda fijado al POS.');
  equal(device.installation_id, store.getInstallationId(), 'El dispositivo queda fijado a la instalación.');
  ok(device.public_key && device.encryption_public_key, 'Se guardan ambas claves públicas verificadas del teléfono.');

  let badChecksumRejected = false;
  try {
    const last = result.activationCode.slice(-1);
    decodeProVentaActivationCode(result.activationCode.slice(0, -1) + (last === '0' ? '1' : '0'));
  } catch (_) { badChecksumRejected = true; }
  ok(badChecksumRejected, 'Un código modificado se rechaza por su checksum.');

  let tamperedPvidRejected = false;
  const altered = { ...identity.document, label: 'Teléfono alterado' };
  const alteredToken = 'PVID1:' + Buffer.from(JSON.stringify(altered), 'utf8').toString('base64url');
  try {
    store.createDeviceAuthorizationFromIdentity(alteredToken, { employeeName: 'José Dependiente', posId: 'pos_pvid_demo_01' }, 'Dueño');
  } catch (error) { tamperedPvidRejected = error.code === 'PVID1_SIGNATURE_INVALID'; }
  ok(tamperedPvidRejected, 'ProControl rechaza un .pvid modificado después de su firma.');

  let duplicateDeviceRejected = false;
  try {
    store.createDeviceAuthorizationFromIdentity(identity.token, { employeeName: 'José Dependiente', posId: 'pos_pvid_demo_01' }, 'Dueño');
  } catch (error) { duplicateDeviceRejected = error.code === 'DEVICE_ALREADY_REGISTERED'; }
  ok(duplicateDeviceRejected, 'Un mismo teléfono activo no puede registrarse dos veces.');

  let missingPosRejected = false;
  const other = makeIdentity('Otro teléfono');
  try { store.createDeviceAuthorizationFromIdentity(other.token, { employeeName: 'Trabajador POS', posId: '' }, 'Dueño'); }
  catch (error) { missingPosRejected = error.code === 'POS_SCOPE_REQUIRED'; }
  ok(missingPosRejected, 'La generación sin un POS definido se rechaza.');

  console.log(`ProVenta PVID1 → PVLA2 end-to-end: ${assertions} assertions passed.`);
} finally {
  try { if (store) store.close(); } catch (_) {}
  fs.rmSync(root, { recursive: true, force: true });
}
