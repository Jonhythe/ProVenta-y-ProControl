'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { MobileBridgeStore, decodeProVentaActivationCode, stableJson } = require('../electron/mobile-bridge/store');
const { MobileControlPlane } = require('../electron/mobile-bridge/control-plane');

let assertions = 0;
function check(value, message) { assertions++; assert.ok(value, message); }
function equal(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
function makeIdentity(label) {
  const signing = crypto.generateKeyPairSync('ed25519');
  const encryption = crypto.generateKeyPairSync('rsa', { modulusLength: 3072, publicExponent: 0x10001 });
  const doc = {
    format: 'proventa.device-identity', version: 1,
    deviceId: 'device_' + crypto.randomBytes(16).toString('hex'), label,
    devicePublicKey: signing.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    deviceEncryptionPublicKey: encryption.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    createdAt: new Date().toISOString()
  };
  doc.signature = { algorithm: 'Ed25519', value: crypto.sign(null, Buffer.from(stableJson(doc), 'utf8'), signing.privateKey).toString('base64') };
  return { token: 'PVID1:' + Buffer.from(JSON.stringify(doc), 'utf8').toString('base64url'), document: doc };
}

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-proventa-v6-'));
let store = null;
try {
  store = new MobileBridgeStore(temp, { desktopId: 'desktop_proventa_v6_test' });
  const firstIdentity = makeIdentity('Samsung Galaxy A26 · principal');
  const first = store.createDeviceAuthorizationFromIdentity(firstIdentity.token, {
    employeeName: 'Dependiente Global', employeeData: 'Contacto de prueba',
    phoneNumber: '+53 5 123 4567', installationWide: true
  }, 'Dueño');
  check(first && first.ok === true, 'ProControl crea una autorización V6 desde un PVID1 sin pedir POS.');
  equal(first.protocolVersion, 6, 'La nueva autorización usa protocolo V6.');
  equal(first.authorizationScope, 'installation', 'El alcance declarado es la instalación completa.');
  equal(first.authorizedPosId, null, 'La autorización global no guarda authorizedPosId.');
  equal(first.status, 'pending', 'El alta inicial queda pendiente hasta que el Dueño confirma ProVenta en el teléfono.');
  equal(first.renewalSequence, 1, 'El QR inicial tiene la secuencia de renovación 1.');
  check(first.qrExpiresAt > Date.now() && first.qrExpiresAt <= Date.now() + 5 * 60 * 1000, 'El QR inicial vence dentro de cinco minutos.');

  const decoded = decodeProVentaActivationCode(first.activationCode);
  const descriptor = decoded.descriptor;
  equal(descriptor.version, 6, 'El PVLA2 contiene descriptor V6.');
  equal(descriptor.renewalSequence, 1, 'El descriptor inicial incluye la secuencia antirrepetición.');
  equal(descriptor.authorizationScope, 'installation', 'El descriptor firmado declara alcance de instalación.');
  check(!Object.prototype.hasOwnProperty.call(descriptor, 'authorizedPosId'), 'El descriptor V6 no incluye un POS permanente.');
  equal(descriptor.deviceId, firstIdentity.document.deviceId, 'El descriptor V6 queda ligado al ID del teléfono.');
  const desktopPublic = crypto.createPublicKey(store.getDesktopPublicKey());
  const unsigned = { ...descriptor }; delete unsigned.signature;
  check(crypto.verify(null, Buffer.from(stableJson(unsigned), 'utf8'), desktopPublic, Buffer.from(descriptor.signature.value, 'base64')), 'La firma Ed25519 del descriptor global es válida.');

  let authRow = store.db.prepare(`SELECT status,installation_id AS installationId,authorized_pos_id AS authorizedPosId,
    device_id AS deviceId,protocol_version AS protocolVersion,renewal_sequence AS renewalSequence
    FROM device_authorizations WHERE authorization_id=?`).get(first.authorizationId);
  equal(authRow.status, 'pending', 'La autorización inicial permanece pendiente en el registro.');
  equal(authRow.installationId, store.getInstallationId(), 'La autorización está ligada a la instalación actual.');
  equal(authRow.authorizedPosId, null, 'SQLite conserva authorized_pos_id nulo para V6.');
  equal(authRow.protocolVersion, 6, 'SQLite conserva el protocolo V6.');
  equal(authRow.renewalSequence, 1, 'SQLite conserva la secuencia inicial.');
  const device = store.db.prepare('SELECT enabled,pos_id AS posId,installation_id AS installationId,authorization_id AS authorizationId FROM devices WHERE device_id=?').get(first.deviceId);
  equal(device.enabled, 0, 'El teléfono nuevo permanece deshabilitado hasta la confirmación del Dueño.');
  equal(device.posId, null, 'El registro del teléfono no queda fijado a ningún POS.');
  equal(device.installationId, store.getInstallationId(), 'El dispositivo pertenece a la instalación central.');
  equal(device.authorizationId, first.authorizationId, 'El dispositivo referencia su autorización vigente.');
  check(store.listDeviceAuthorizations().some(row => row.authorizationId === first.authorizationId), 'El registro general incluye el teléfono V5.');
  check(store.listDeviceAuthorizations('pos_uno').some(row => row.authorizationId === first.authorizationId), 'La vista de elegibles por POS puede ver teléfonos V5 globales.');

  const control = new MobileControlPlane(store, {
    deviceId: 'desktop_procontrol_v6_test',
    now: () => Date.now(),
    getInstallationLicense: () => ({ modules: ['mobile-integration'], allowedModes: ['CON_APP'] })
  });
  control.mobileAppReady = true; // Solo el banco de pruebas activa la emisión; producción permanece bloqueada.
  control.getPOSPolicy = posId => ({ ok: true, licenseValid: true, mode: 'CON_APP', posId });
  let deviceRow = store.db.prepare('SELECT * FROM devices WHERE device_id=?').get(first.deviceId);
  equal(control._deviceAuthorization(deviceRow).code, 'DEVICE_AUTHORIZATION_INACTIVE', 'El teléfono pendiente no puede acceder al plano de control.');
  const confirmed = store.confirmDeviceAuthorization(first.authorizationId, 'Dueño');
  check(confirmed.ok === true && confirmed.status === 'active', 'El Dueño confirma el alta del teléfono después de verificar ProVenta.');
  authRow = store.db.prepare('SELECT status,renewal_sequence AS renewalSequence FROM device_authorizations WHERE authorization_id=?').get(first.authorizationId);
  equal(authRow.status, 'active', 'La confirmación activa la autorización del teléfono.');
  equal(store.db.prepare('SELECT enabled FROM devices WHERE device_id=?').get(first.deviceId).enabled, 1, 'La confirmación habilita el teléfono.');
  const renewal = store.issueDeviceAuthorizationRenewal(first.authorizationId, 'Dueño');
  check(renewal.ok === true && renewal.protocolVersion === 6, 'ProControl puede emitir el QR de renovación para el teléfono registrado.');
  equal(renewal.renewalSequence, 2, 'Cada QR de renovación incrementa la secuencia.');
  check(renewal.qrExpiresAt > Date.now() && renewal.qrExpiresAt <= Date.now() + 5 * 60 * 1000, 'El QR de renovación vence dentro de cinco minutos.');
  const renewalDescriptor = decodeProVentaActivationCode(renewal.activationCode).descriptor;
  equal(renewalDescriptor.renewalSequence, 2, 'La secuencia se incluye en el descriptor firmado.');
  const renewalUnsigned = { ...renewalDescriptor }; delete renewalUnsigned.signature;
  check(crypto.verify(null, Buffer.from(stableJson(renewalUnsigned), 'utf8'), desktopPublic, Buffer.from(renewalDescriptor.signature.value, 'base64')), 'La firma del QR de renovación es válida.');
  equal(store.db.prepare('SELECT renewal_sequence FROM device_authorizations WHERE authorization_id=?').get(first.authorizationId).renewal_sequence, 2, 'La secuencia emitida se persiste de manera atómica.');
  deviceRow = store.db.prepare('SELECT * FROM devices WHERE device_id=?').get(first.deviceId);
  check(control._deviceAuthorization(deviceRow).ok === true, 'El plano de control acepta la autorización global sin POS fijo.');
  equal(control._deviceAuthorization({ ...deviceRow, pos_id: 'pos_forzado' }).code, 'DEVICE_AUTHORIZATION_SCOPE_INVALID', 'El plano de control rechaza si alguien intenta fijar un POS en el registro global.');
  const snapshotPosId = 'pos_snapshot_01';
  const snapshot = store.createDeviceBoundDataPackage({
    deviceId: first.deviceId, posId: snapshotPosId, requestId: 'request_v5_snapshot_01',
    type: 'inventory_snapshot',
    payload: { installationId: store.getInstallationId(), posId: snapshotPosId, items: [{ productId: 'prod_snapshot_01', quantity: 12 }] }
  }, 'Dueño');
  check(snapshot.ok === true, 'El teléfono V6 puede recibir una instantánea cifrada del POS seleccionado sin quedar ligado permanentemente a ese POS.');
  equal(JSON.parse(snapshot.envelopeJson).posId, snapshotPosId, 'La instantánea V6 queda limitada al POS que se seleccionó para exportarla.');
  store.db.prepare('UPDATE devices SET pos_id=? WHERE device_id=?').run('pos_forzado', first.deviceId);
  equal(store.createDeviceBoundDataPackage({
    deviceId: first.deviceId, posId: snapshotPosId, requestId: 'request_v5_snapshot_02',
    type: 'inventory_snapshot',
    payload: { installationId: store.getInstallationId(), posId: snapshotPosId, items: [{ productId: 'prod_snapshot_01', quantity: 12 }] }
  }, 'Dueño').code, 'DEVICE_AUTHORIZATION_SCOPE_INVALID', 'La exportación V6 rechaza si se fuerza un POS permanente en el dispositivo.');
  store.db.prepare('UPDATE devices SET pos_id=NULL WHERE device_id=?').run(first.deviceId);

  const now = Date.now();
  const permitOne = control.issueShiftPermit({
    posId: 'pos_centro_01', deviceId: first.deviceId, employee: 'Dependiente Global',
    startsAt: now - 1000, endsAt: now + 60 * 60 * 1000, sequence: 1
  }, { role: 'Dueño', user: 'Dueño' });
  check(permitOne.ok === true, 'El Dueño puede emitir un permiso de turno V2 con POS definido para el teléfono global.');
  equal(permitOne.permit.version, 2, 'El permiso firmado incluye el protocolo de instalación y dispositivo V2.');
  equal(permitOne.permit.posId, 'pos_centro_01', 'El permiso firmado define el POS operativo concreto.');
  equal(permitOne.permit.authorizedPosId, 'pos_centro_01', 'El campo POS del permiso firmado coincide con el POS operativo, no con la autorización global.');
  const verified = control.verifyShiftPermit(permitOne.permitId, { deviceId: first.deviceId, posId: 'pos_centro_01', sequence: 1 });
  check(verified.ok === true, 'El permiso V6 se verifica para el teléfono y POS exactos.');
  equal(control.verifyShiftPermit(permitOne.permitId, { deviceId: first.deviceId, posId: 'pos_otro_02' }).code, 'SHIFT_PERMIT_POS_MISMATCH', 'El permiso V6 no puede reutilizarse en otro POS.');

  const simultaneous = control.issueShiftPermit({
    posId: 'pos_otro_02', deviceId: first.deviceId, employee: 'Dependiente Global',
    startsAt: now - 1000, endsAt: now + 60 * 60 * 1000, sequence: 1
  }, { role: 'Dueño', user: 'Dueño' });
  equal(simultaneous.code, 'ACTIVE_DEVICE_SHIFT_PERMIT_EXISTS', 'Un teléfono no puede mantener dos turnos activos simultáneos en POS distintos.');
  store.db.prepare("UPDATE shift_permits SET status='closed' WHERE permit_id=?").run(permitOne.permitId);
  const permitTwo = control.issueShiftPermit({
    posId: 'pos_otro_02', deviceId: first.deviceId, employee: 'Dependiente Global',
    startsAt: now - 1000, endsAt: now + 60 * 60 * 1000, sequence: 1
  }, { role: 'Dueño', user: 'Dueño' });
  check(permitTwo.ok === true, 'El mismo teléfono puede recibir otro permiso para un POS distinto después de cerrar el turno anterior.');
  equal(permitTwo.permit.posId, 'pos_otro_02', 'El segundo permiso queda limitado al segundo POS.');

  const missingReason = store.revokeDeviceAuthorization(first.authorizationId, 'Dueño', null, '');
  equal(missingReason.code, 'REVOCATION_REASON_REQUIRED', 'La invalidación exige un motivo auditable.');
  const revoked = store.revokeDeviceAuthorization(first.authorizationId, 'Dueño', null, 'Teléfono perdido');
  check(revoked.ok === true, 'El Dueño puede invalidar una autorización global con motivo.');
  authRow = store.db.prepare('SELECT status FROM device_authorizations WHERE authorization_id=?').get(first.authorizationId);
  equal(authRow.status, 'invalidated', 'La autorización invalidada conserva su registro.');
  equal(store.db.prepare('SELECT enabled FROM devices WHERE device_id=?').get(first.deviceId).enabled, 0, 'La invalidación deshabilita el teléfono.');

  const replacementIdentity = makeIdentity('Samsung Galaxy A26 · sustituto');
  const replacement = store.createDeviceAuthorizationFromIdentity(replacementIdentity.token, {
    employeeName: 'Dependiente Global', employeeData: 'Contacto actualizado', phoneNumber: '+53 5 987 6543', installationWide: true,
    replacesAuthorizationId: first.authorizationId, replacementReason: 'Teléfono anterior perdido'
  }, 'Dueño');
  check(replacement.ok === true, 'Se puede autorizar un nuevo teléfono sustituyendo uno ya invalidado.');
  equal(replacement.protocolVersion, 6, 'La sustitución conserva el alcance V6 global.');
  const oldAfterReplacement = store.db.prepare(`SELECT status,replaced_by_authorization_id AS replacedBy FROM device_authorizations WHERE authorization_id=?`).get(first.authorizationId);
  equal(oldAfterReplacement.status, 'superseded', 'El registro anterior pasa a Sustituido, no se elimina.');
  equal(oldAfterReplacement.replacedBy, replacement.authorizationId, 'La autorización anterior referencia el nuevo registro.');
  equal(store.db.prepare('SELECT enabled FROM devices WHERE device_id=?').get(first.deviceId).enabled, 0, 'El dispositivo anterior permanece deshabilitado.');
  const newRow = store.db.prepare('SELECT authorized_pos_id AS posId,protocol_version AS protocolVersion,status FROM device_authorizations WHERE authorization_id=?').get(replacement.authorizationId);
  equal(newRow.posId, null, 'El nuevo teléfono sustituto tampoco queda fijado a un POS.');
  equal(newRow.protocolVersion, 6, 'El sustituto queda registrado como V6.');
  equal(newRow.status, 'pending', 'El sustituto debe confirmarse antes de habilitarlo.');
  equal(store.db.prepare('SELECT enabled FROM devices WHERE device_id=?').get(replacement.deviceId).enabled, 0, 'El dispositivo sustituto permanece deshabilitado hasta su confirmación.');

  const history = store.listDeviceAuthorizationHistory(100);
  check(history.some(event => event.action === 'device_authorization_revoked' && event.detail.reason === 'Teléfono perdido'), 'El historial conserva la invalidación y su motivo.');
  check(history.some(event => event.action === 'device_authorization_superseded' && event.detail.reason === 'Teléfono anterior perdido'), 'El historial conserva la sustitución y su motivo.');
  check(history.some(event => event.action === 'device_authorized_from_pvid' && event.detail.authorizationScope === 'installation'), 'El historial identifica las autorizaciones globales.');
  check(store.listDeviceAuthorizations().some(row => row.authorizationId === first.authorizationId && row.status === 'superseded') && store.listDeviceAuthorizations().some(row => row.authorizationId === replacement.authorizationId), 'El registro central conserva ambos teléfonos: el sustituido y el actual.');

  // Legacy v4 authorizations remain bound to their historic POS during migration.
  const legacyIdentity = makeIdentity('Teléfono legado V4');
  const legacy = store.createDeviceAuthorizationFromIdentity(legacyIdentity.token, {
    employeeName: 'Trabajador Legado', posId: 'pos:pos_legacy_01'
  }, 'Dueño');
  equal(legacy.protocolVersion, 4, 'Se conserva la creación legacy V4 para compatibilidad de datos antiguos.');
  equal(legacy.authorizedPosId, 'pos_legacy_01', 'La autorización legacy mantiene su POS histórico.');
  equal(store.db.prepare('SELECT pos_id FROM devices WHERE device_id=?').get(legacy.deviceId).pos_id, 'pos_legacy_01', 'El dispositivo legacy conserva su vínculo POS anterior.');

  console.log(`ProVenta V6 mensual + permisos POS + historial: ${assertions} assertions passed.`);
} finally {
  try { if (store) store.close(); } catch (_) {}
  fs.rmSync(temp, { recursive: true, force: true });
}
