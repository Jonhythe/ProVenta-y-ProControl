'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const { RecordArchiveStore } = require('../electron/record-archive-store');
const { wipeOperationalStoreData } = require('../electron/security/authorized-store-wipe');
const root = path.resolve(__dirname, '..');
const main = fs.readFileSync(path.join(root, 'electron', 'main.js'), 'utf8');
const preload = fs.readFileSync(path.join(root, 'electron', 'preload.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'renderer', 'index.html'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const assert = (condition, message) => { if (!condition) throw new Error(message); };

assert(main.includes("ipcMain.on('pc:store-wipe-owner'"), 'debe existir el IPC dedicado al borrado total');
assert(main.includes("auth.role !== 'Dueño'"), 'el proceso principal debe exigir el rol Dueño real');
assert(main.includes('authenticatePrivilegedUser(event, { user: requestedUser, password })'), 'debe reautenticar con contraseña persistida');
assert(main.includes('wipeOperationalStoreData({'), 'main debe delegar el borrado real al módulo probado');
assert(main.includes("require('./security/authorized-store-wipe')"), 'main debe cargar el módulo de borrado probado');
const archiveSource = fs.readFileSync(path.join(root, 'electron', 'record-archive-store.js'), 'utf8');
assert(/^\s{2}stageClearAll\s*\(/m.test(archiveSource), 'el almacén histórico debe implementar realmente stageClearAll, no solo mencionarlo en un comentario');
assert(preload.includes("ipcRenderer.sendSync('pc:store-wipe-owner'"), 'preload debe exponer la acción segura');
assert(html.includes("PCStore.wipeAll({ user: appState.currentUser, password: passwordForWipe })") && html.includes("verification.password = ''"), 'la UI debe pedir contraseña y limpiar la referencia temporal');
assert(html.includes('wipeResult.stage') && html.includes('wipeResult.detail'), 'la UI debe mostrar etapa y detalle del error para no ocultar fallos');
assert(pkg.scripts?.['check-source']?.includes('tools/test-authorized-store-wipe.js'), 'la batería debe ejecutar esta prueba');
assert(main.includes("auth.role !== 'Dueño'") && main.includes('license.isLicensed()'), 'solo Dueño autenticado con licencia puede ejecutar el reinicio');

function count(db, table) {
  return Number(db.prepare('SELECT COUNT(*) AS n FROM "' + table.replace(/"/g, '""') + '"').get().n || 0);
}
function createFixture(dir) {
  fs.mkdirSync(dir, { recursive: true });
  const mainDb = new DatabaseSync(path.join(dir, 'procontrol.db'));
  mainDb.exec('CREATE TABLE store (key TEXT PRIMARY KEY, value TEXT NOT NULL);');
  mainDb.prepare('INSERT INTO store(key,value) VALUES(?,?)').run('users', '[{"name":"Dueño"}]');
  mainDb.prepare('INSERT INTO store(key,value) VALUES(?,?)').run('inventory', '[{"name":"Producto"}]');
  mainDb.prepare('INSERT INTO store(key,value) VALUES(?,?)').run('elite_sales_ledger', '[{"id":"sale-1"}]');
  mainDb.close();

  const bridgeDb = new DatabaseSync(path.join(dir, 'mobile-bridge.db'));
  bridgeDb.exec(`PRAGMA foreign_keys=ON;
    CREATE TABLE bridge_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE devices (device_id TEXT PRIMARY KEY, label TEXT NOT NULL);
    CREATE TABLE incoming_packages (package_id TEXT PRIMARY KEY, device_id TEXT NOT NULL, FOREIGN KEY(device_id) REFERENCES devices(device_id));
    CREATE TABLE reconciliation_jobs (package_id TEXT PRIMARY KEY, status TEXT NOT NULL, FOREIGN KEY(package_id) REFERENCES incoming_packages(package_id));
    CREATE TABLE bridge_audit (id INTEGER PRIMARY KEY AUTOINCREMENT, detail TEXT NOT NULL);
    CREATE TABLE future_operational_table (id INTEGER PRIMARY KEY, device_id TEXT NOT NULL, FOREIGN KEY(device_id) REFERENCES devices(device_id));`);
  bridgeDb.prepare('INSERT INTO bridge_meta(key,value) VALUES(?,?)').run('installation_id', 'pcinst_test_stable_identity_001');
  bridgeDb.prepare('INSERT INTO devices(device_id,label) VALUES(?,?)').run('device-1', 'Teléfono de prueba');
  bridgeDb.prepare('INSERT INTO incoming_packages(package_id,device_id) VALUES(?,?)').run('package-1', 'device-1');
  bridgeDb.prepare('INSERT INTO reconciliation_jobs(package_id,status) VALUES(?,?)').run('package-1', 'pending');
  bridgeDb.prepare('INSERT INTO bridge_audit(detail) VALUES(?)').run('alta');
  bridgeDb.prepare('INSERT INTO future_operational_table(id,device_id) VALUES(?,?)').run(1, 'device-1');
  bridgeDb.close();

  fs.writeFileSync(path.join(dir, 'procontrol.json'), JSON.stringify({ inventory: '[{"old":true}]' }));
  const archiveDir = path.join(dir, 'registros-antiguos');
  fs.mkdirSync(archiveDir, { recursive: true });
  fs.writeFileSync(path.join(archiveDir, `v1_${crypto.randomUUID()}.pca`), 'ciphertext-fixture');
  fs.writeFileSync(path.join(archiveDir, `.tmp-${crypto.randomUUID()}.part`), 'partial-fixture');
}

// Prueba de éxito contra bases SQLite temporales con claves foráneas y una tabla
// operativa desconocida, para asegurar que el reset no depende de una lista fija.
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-wipe-ok-'));
try {
  createFixture(tempRoot);
  const archiveStore = new RecordArchiveStore(tempRoot);
  const result = wipeOperationalStoreData({ userDataDir: tempRoot, archiveStore });
  assert(result.ok === true, 'el reset de prueba debe completarse: ' + JSON.stringify(result));

  const mainDb = new DatabaseSync(path.join(tempRoot, 'procontrol.db'));
  assert(count(mainDb, 'store') === 0, 'el almacén principal debe quedar vacío');
  mainDb.close();

  const bridgeDb = new DatabaseSync(path.join(tempRoot, 'mobile-bridge.db'));
  assert(count(bridgeDb, 'bridge_meta') === 1, 'bridge_meta debe conservar la identidad estable');
  assert(bridgeDb.prepare("SELECT value FROM bridge_meta WHERE key='installation_id'").get().value === 'pcinst_test_stable_identity_001', 'la huella de instalación debe conservarse exactamente');
  for (const table of ['devices', 'incoming_packages', 'reconciliation_jobs', 'bridge_audit', 'future_operational_table']) {
    assert(count(bridgeDb, table) === 0, 'la tabla operativa ' + table + ' debe quedar vacía');
  }
  bridgeDb.close();
  assert(fs.readFileSync(path.join(tempRoot, 'procontrol.json'), 'utf8') === '{}', 'el JSON legado debe quedar vacío');
  assert(fs.readdirSync(path.join(tempRoot, 'registros-antiguos')).length === 0, 'los históricos activos deben quedar vacíos');
  console.log('PASS - borrado SQLite principal, JSON legado, todas las tablas móviles y archivos históricos');
  console.log('PASS - bridge_meta conserva la identidad de instalación sin alterar su valor');
} finally {
  try { fs.rmSync(tempRoot, { recursive: true, force: true }); } catch (_) {}
}

// Prueba de aborto: si no se pueden apartar los archivos históricos, las bases
// y el JSON deben permanecer intactos.
const rollbackRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-wipe-rollback-'));
try {
  createFixture(rollbackRoot);
  const failingArchiveStore = new RecordArchiveStore(rollbackRoot);
  failingArchiveStore.stageClearAll = () => { throw Object.assign(new Error('fixture archive locked'), { code: 'EPERM' }); };
  const result = wipeOperationalStoreData({ userDataDir: rollbackRoot, archiveStore: failingArchiveStore });
  assert(result.ok === false && result.code === 'EPERM' && result.stage === 'STAGE_ENCRYPTED_ARCHIVES', 'el fallo debe informar etapa y código: ' + JSON.stringify(result));

  const mainDb = new DatabaseSync(path.join(rollbackRoot, 'procontrol.db'));
  assert(count(mainDb, 'store') === 3, 'el borrado principal debe revertirse al fallar el staging');
  mainDb.close();
  const bridgeDb = new DatabaseSync(path.join(rollbackRoot, 'mobile-bridge.db'));
  assert(count(bridgeDb, 'devices') === 1, 'los dispositivos no deben borrarse si falla el staging');
  assert(count(bridgeDb, 'bridge_meta') === 1, 'la identidad debe mantenerse en el aborto');
  bridgeDb.close();
  assert(JSON.parse(fs.readFileSync(path.join(rollbackRoot, 'procontrol.json'), 'utf8')).inventory, 'el JSON legado debe conservarse en el aborto');
  console.log('PASS - un fallo previo al commit revierte el borrado y conserva todos los datos');
} finally {
  try { fs.rmSync(rollbackRoot, { recursive: true, force: true }); } catch (_) {}
}

console.log('Authorized store wipe runtime: 5 comprobaciones aprobadas.');
