"use strict";
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { parseArgs, encodeStoredValue, decodeStoredValue, readAllStoreRows, analyzeAndMaybeApply } = require('./check-product-identity-migration');
let assertions = 0;
function eq(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
function ok(value, message) { assertions++; assert.ok(value, message); }
function dbWithData(dir, values) {
  const file = path.join(dir, 'procontrol.db');
  const db = new DatabaseSync(file);
  db.exec('CREATE TABLE store (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
  const put = db.prepare('INSERT INTO store(key,value) VALUES(?,?)');
  for (const [key, value] of Object.entries(values)) put.run(key, encodeStoredValue(value));
  db.close();
  return file;
}
function snapshot(file) { const db = new DatabaseSync(file, { readOnly: true }); try { return readAllStoreRows(db); } finally { db.close(); } }
function stored(file, key) {
  const db = new DatabaseSync(file, { readOnly: true });
  try { const row = db.prepare('SELECT value FROM store WHERE key=?').get(key); return row ? decodeStoredValue(row.value) : null; }
  finally { db.close(); }
}
const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-product-id-apply-'));
try {
  assert.throws(() => parseArgs(['--apply']), /--db RUTA_EXPLÍCITA/); assertions++;
  assert.throws(() => parseArgs(['--db','x.db','--apply']), /--confirm-apply=YES/); assertions++;
  assert.throws(() => parseArgs(['--confirm-apply=YES']), /solo se admite/); assertions++;

  // Dry-run may analyze but cannot write or create a backup.
  {
    const dir = path.join(temporary, 'dry'); fs.mkdirSync(dir);
    const dbFile = dbWithData(dir, { elite_inventory: [{ name:'Arroz', unit:'u', family:'Granos', qty:4 }] });
    const before = snapshot(dbFile);
    const result = analyzeAndMaybeApply({ dbPath: dbFile, apply: false, confirmApply: false });
    eq(result.ok, true, 'Dry-run with an unambiguous row is ready');
    eq(result.status, 'dry-run-ready', 'Dry-run reports read-only status');
    eq(result.applied, false, 'Dry-run never applies data');
    eq(JSON.stringify(snapshot(dbFile)), JSON.stringify(before), 'Dry-run leaves SQLite store byte-values unchanged');
    eq(fs.readdirSync(dir).filter(n => n.includes('backup')).length, 0, 'Dry-run creates no backup file');
  }

  // Ambiguity stops before backup creation and before any write.
  {
    const dir = path.join(temporary, 'ambiguous'); fs.mkdirSync(dir);
    const dbFile = dbWithData(dir, { elite_inventory: [
      { name:'Leche', unit:'u', family:'Lácteos', qty:4 },
      { name:'Leche', unit:'u', family:'Lácteos', qty:2 }
    ] });
    const before = snapshot(dbFile);
    const result = analyzeAndMaybeApply({ dbPath: dbFile, apply: true, confirmApply: true });
    eq(result.ok, false, 'Ambiguous duplicate names prevent application');
    eq(result.status, 'requires-review', 'Ambiguity is explicitly reported for manual review');
    eq(result.backup, null, 'No backup/application is started for a known conflict');
    eq(JSON.stringify(snapshot(dbFile)), JSON.stringify(before), 'Ambiguous input keeps source store unchanged');
    eq(fs.readdirSync(dir).filter(n => n.includes('backup')).length, 0, 'Conflict creates no misleading backup');
  }

  // Successful apply requires explicit confirmation, creates a verified backup, and writes all identity collections atomically.
  {
    const dir = path.join(temporary, 'apply'); fs.mkdirSync(dir);
    const dbFile = dbWithData(dir, { elite_inventory: [{ name:'Arroz', unit:'u', family:'Granos', qty:4 }], unrelated_setting: { theme:'dark' } });
    const before = snapshot(dbFile);
    const result = analyzeAndMaybeApply({ dbPath: dbFile, apply: true, confirmApply: true });
    eq(result.ok, true, 'Confirmed migration is applied');
    eq(result.status, 'applied', 'Apply reports the applied status');
    ok(result.backup && result.backup.verified === true && fs.existsSync(result.backup.path), 'Backup is created and verified before changes');
    ok(/^[a-f0-9]{64}$/.test(result.backup.sha256), 'Backup has a SHA-256 integrity digest');
    const inventory = stored(dbFile, 'elite_inventory');
    ok(typeof inventory[0].productId === 'string' && inventory[0].productId.length > 0, 'Stable productId is persisted');
    eq(stored(dbFile, 'elite_product_catalog')[0].id, inventory[0].productId, 'Catalog and inventory share the persisted identity');
    eq(stored(dbFile, 'elite_transfers').length, 0, 'Transfer collection is preserved as an empty collection');
    eq(stored(dbFile, 'elite_sales_ledger').length, 0, 'Historical sales collection is preserved as an empty collection');
    eq(stored(dbFile, 'unrelated_setting').theme, 'dark', 'Unrelated application settings remain intact');
    eq(JSON.stringify(snapshot(result.backup.path)), JSON.stringify(before), 'Verified backup retains original store contents');
  }

  // A present but undecodable store value is a hard stop, not an empty-list fallback.
  {
    const dir = path.join(temporary, 'corrupt'); fs.mkdirSync(dir);
    const dbFile = path.join(dir, 'procontrol.db');
    const db = new DatabaseSync(dbFile); db.exec('CREATE TABLE store (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
    db.prepare('INSERT INTO store(key,value) VALUES(?,?)').run('elite_inventory','NOT_JSON'); db.close();
    const before = snapshot(dbFile);
    const result = analyzeAndMaybeApply({ dbPath: dbFile, apply: true, confirmApply: true });
    eq(result.ok, false, 'Unreadable store value stops migration');
    eq(result.applied, false, 'Unreadable data is never overwritten');
    eq(JSON.stringify(snapshot(dbFile)), JSON.stringify(before), 'Corrupt-value store remains unchanged');
  }
  console.log(`Product identity apply/recovery: ${assertions} assertions passed.`);
} finally { fs.rmSync(temporary, { recursive:true, force:true }); }
