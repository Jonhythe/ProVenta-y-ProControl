'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const tools = __dirname;
const root = path.resolve(tools, '..');
const builder = fs.readFileSync(path.join(tools, 'build-folder-distribution.js'), 'utf8');
const creatorBat = fs.readFileSync(path.join(tools, 'Crear-Distribucion-Carpeta.bat'), 'utf8');
const updater = fs.readFileSync(path.join(tools, 'Actualizar-ProControl.ps1'), 'utf8');
const updaterBat = fs.readFileSync(path.join(tools, 'Actualizar-ProControl.bat'), 'utf8');
const zipCreator = fs.readFileSync(path.join(tools, 'create-folder-zip.ps1'), 'utf8');
const zipVerifier = fs.readFileSync(path.join(tools, 'verify-folder-zip.ps1'), 'utf8');
const main = fs.readFileSync(path.join(root, 'electron', 'main.js'), 'utf8');

assert.match(builder, /target:\s*'dir'/, 'la compilación debe usar target dir');
assert.match(builder, /createTarget\(\['dir'\],\s*Arch\.x64\)/, 'la compilación debe ser Windows x64 dir');
assert.match(builder, /signAndEditExecutable:\s*true/, 'debe insertar los recursos del producto, incluido el icono');
assert.match(builder, /signExecutable:\s*false/, 'no debe intentar firmar el EXE');
assert.match(builder, /check-no-secrets\.js/, 'debe escanear secretos antes de publicar');
assert.match(builder, /compareSnapshots\(buildSnapshot, copiedSnapshot/, 'debe comparar build y copia antes del manifiesto');
assert.match(builder, /Manifest is generated from the FINAL copied payload/, 'manifiesto generado desde la entrega final');
assert.match(builder, /releaseFiles,/, 'el manifiesto debe registrar los archivos BAT/PS1 y el LEEME');
assert.match(builder, /verify-folder-zip\.ps1/, 'debe validar el contenido interno del ZIP');
assert.match(builder, /compareSnapshots\(manifestFiles, buildAfterZip/, 'debe revalidar build luego de crear el ZIP');
assert.match(builder, /compareSnapshots\(manifestFiles, payloadAfterZip/, 'debe revalidar entrega luego de crear el ZIP');
assert.match(builder, /zipPartial/, 'debe generar un ZIP temporal y publicarlo solo tras validar');
assert.match(builder, /REQUIRED_BUILDER_VERSION = '26\.18\.1'/, 'toolchain electron-builder debe quedar fijada');
assert.match(creatorBat, /build-folder-distribution\.js/, 'el BAT creador debe ejecutar el generador');
assert.match(creatorBat, /test-folder-distribution\.js|build-folder-distribution\.js/, 'el BAT debe ejecutar el flujo probado');
assert.match(updater, /schemaVersion -ne 2/, 'debe rechazar manifiestos antiguos/incompatibles');
assert.match(updater, /Test-ReleaseArtifacts/, 'debe comprobar los hashes de sus propios archivos de control');
assert.match(updater, /No se permite instalar ProControl directamente en la raíz/, 'debe bloquear la raíz de una unidad');
assert.match(updater, /SHA-256 distinto en el respaldo de datos/, 'debe verificar criptográficamente el respaldo de datos');
assert.match(updater, /Get-FileHash[\s\S]*SHA256/, 'debe verificar SHA-256');
const updaterHashCheck = updater.indexOf('if ($actualHash -ne $expectedHash)');
const updaterSizeCheck = updater.indexOf('if ($actualSize -ne $expectedSize)');
assert(updaterHashCheck >= 0 && updaterSizeCheck > updaterHashCheck,
  'SHA-256 debe decidir antes que el metadato de tamaño');
assert.match(updater, /tamaño registrado[\s\S]*SHA-256 coincide exactamente/i,
  'un tamaño discrepante solo se advierte después de verificar el mismo SHA-256');
assert.match(updater, /no mezcles archivos de distintas compilaciones/,
  'si cambia el contenido debe indicar que el paquete está mezclado o alterado');
assert.match(builder, /waitForStableFile\(appExe\)/,
  'el creador debe esperar a que el EXE termine de recibir recursos antes de crear el manifiesto');
assert.match(builder, /requiredStableRounds = .*: 3/,
  'el creador debe exigir tres lecturas estables del ejecutable');
assert.match(updater, /Stop-AllProControlInstances/, 'debe cerrar las instancias antes de respaldar datos');
assert.match(updater, /Backup-UserData/, 'debe respaldar datos antes de reemplazar programa');
assert.match(updater, /programBackup/, 'debe conservar versión anterior');
assert.match(updater, /failedRoot/, 'debe conservar paquete nuevo fallido para diagnóstico');
assert.match(updater, /Test-LegacyNsisInstall/, 'debe proteger instalaciones NSIS antiguas');
assert.doesNotMatch(updater, /Remove-Item\s+-LiteralPath\s+\$dataRoot/i, 'no debe borrar AppData ProControl');
assert.match(updaterBat, /ExecutionPolicy Bypass[\s\S]*Actualizar-ProControl\.ps1/, 'BAT actualizador debe ejecutar PS1 con bypass solo para ese proceso');
assert.match(zipCreator, /CreateFromDirectory/, 'debe crear ZIP con .NET');
assert.match(zipVerifier, /ProControl\/ProControl\.exe/, 'debe validar la ruta normalizada del EXE en el ZIP');
assert.match(zipVerifier, /Get-StreamHash/, 'debe hashear directamente el contenido extraído del ZIP');
assert.match(zipVerifier, /localReleaseStream[\s\S]*Get-StreamHash/, 'debe validar hashes locales con SHA-256 .NET sin depender de Get-FileHash');
assert.doesNotMatch(zipVerifier, /Get-FileHash/, 'el verificador del ZIP no debe depender del cmdlet Get-FileHash');
assert.match(zipVerifier, /SHA-256 dentro del ZIP no coincide[\s\S]*Metadato de tamaño distinto/i,
  'el verificador del ZIP debe validar contenido antes del tamaño informativo');
assert.match(zipVerifier, /releaseFile\.sha256/, 'debe validar el hash del BAT/PS1 incluido');
assert.match(zipVerifier, /releaseSeen\.ContainsKey/, 'debe rechazar archivos de control duplicados');
assert.match(zipVerifier, /MANIFEST\.json dentro del ZIP no es idéntico/, 'debe comprobar el manifiesto incluido en ZIP');
assert.match(main, /path\.join\(APP_DATA_DIR,\s*'ProControl'\)/, 'main.js debe mantener userData fuera del programa');
assert.match(main, /app\.setPath\('userData',\s*USER_DATA_DIR\)/, 'Electron debe fijar userData en AppData ProControl');

console.log('Folder distribution v2: 41 comprobaciones aprobadas.');
