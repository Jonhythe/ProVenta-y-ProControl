'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { MobileBridgeStore } = require('../electron/mobile-bridge/store');
const { MobileControlPlane } = require('../electron/mobile-bridge/control-plane');
const LocalQr = require('../renderer/local-qr');

function stableJson(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return '[' + value.map(stableJson).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + stableJson(value[key])).join(',') + '}';
  if (typeof value === 'number' && !Number.isFinite(value)) throw new Error('Non-finite number');
  return JSON.stringify(value);
}
function signedFields(value) { const copy = { ...value }; delete copy.signature; return Buffer.from(stableJson(copy), 'utf8'); }
function generateIdentity(deviceId, label) {
  const signing = crypto.generateKeyPairSync('ed25519');
  const encryption = crypto.generateKeyPairSync('rsa', { modulusLength: 3072, publicExponent: 0x10001 });
  const doc = {
    format: 'proventa.device-identity',
    version: 1,
    deviceId,
    label,
    devicePublicKey: signing.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    deviceEncryptionPublicKey: encryption.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    createdAt: new Date().toISOString()
  };
  doc.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(doc), signing.privateKey).toString('base64') };
  return {
    encoded: 'PVID1:' + Buffer.from(JSON.stringify(doc), 'utf8').toString('base64url'),
    signingPrivateKey: signing.privateKey,
    signingPublicKey: signing.publicKey,
    encryptionPrivateKey: encryption.privateKey,
    document: doc
  };
}
function decryptLink(envelopeText, encryptionPrivateKey, expectedPcPublicKey) {
  const envelope = JSON.parse(envelopeText);
  assert.equal(envelope.format, 'procontrol.device-link');
  assert.equal(envelope.version, 1);
  assert.equal(envelope.algorithm, 'RSA-OAEP-256+A256GCM');
  const pcPublic = crypto.createPublicKey(envelope.signerPublicKey);
  assert.equal(envelope.signerPublicKey.replace(/\r/g, '').trim(), expectedPcPublicKey.replace(/\r/g, '').trim());
  assert.equal(envelope.signature.algorithm, 'Ed25519');
  assert.equal(crypto.verify(null, signedFields(envelope), pcPublic, Buffer.from(envelope.signature.value, 'base64')), true);
  const key = crypto.privateDecrypt({ key: encryptionPrivateKey, padding: crypto.constants.RSA_PKCS1_OAEP_PADDING, oaepHash: 'sha256' }, Buffer.from(envelope.encryption.wrappedKey, 'base64'));
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(envelope.encryption.iv, 'base64'));
  const header = { ...envelope };
  delete header.encryption; delete header.ciphertext; delete header.signature;
  decipher.setAAD(Buffer.from(stableJson(header), 'utf8'));
  decipher.setAuthTag(Buffer.from(envelope.encryption.tag, 'base64'));
  const plaintext = Buffer.concat([decipher.update(Buffer.from(envelope.ciphertext, 'base64')), decipher.final()]);
  return { envelope, authorization: JSON.parse(plaintext.toString('utf8')) };
}

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-v4-link-'));
const otherTemp = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-v4-other-'));
let store;
let otherStore;
let assertions = 0;
const check = (condition, message) => { assert.ok(condition, message); assertions++; };
try {
  store = new MobileBridgeStore(temp);
  otherStore = new MobileBridgeStore(otherTemp);
  const installationCode = store.getInstallationCode();
  check(/^PC-[A-F0-9]{4}(?:-[A-F0-9]{4}){3}$/.test(installationCode), 'installation identity uses the PC-XXXX-XXXX-XXXX-XXXX format');
  check(installationCode !== otherStore.getInstallationCode(), 'independent ProControl installations have different visible identities');
  check(store.getInstallationCodePatternV4().patternId !== otherStore.getInstallationCodePatternV4().patternId, 'each installation receives its own v4 PIN pattern identity');
  check(store.getInstallationCodePatternV4().codeLength === 8, 'v4 profile declares eight-digit PINs');
  const first = generateIdentity('phone_proventa_00000001', 'Samsung Galaxy A26');
  const imported = store.importDeviceIdentity(first.encoded, 'owner');
  check(imported.ok && imported.deviceId === 'phone_proventa_00000001', 'PVID1 base64url identity is parsed and stored');
  check(imported.encryptionConfigured === true, 'PVID1 requires the phone RSA encryption key');
  check(/^[a-f0-9]{64}$/.test(imported.encryptionKeyHash), 'PVID1 stores a fingerprint of the encryption key too');
  const rawIdentity = generateIdentity('phone_proventa_00000003', 'Teléfono con PVID1 JSON');
  const rawImport = store.importDeviceIdentity('PVID1:' + JSON.stringify(rawIdentity.document), 'owner');
  check(rawImport.ok && rawImport.deviceId === 'phone_proventa_00000003', 'PVID1 raw JSON encoding is accepted too');
  const swappedEncryption = crypto.generateKeyPairSync('rsa', { modulusLength: 3072, publicExponent: 0x10001 });
  const swappedDocument = { ...first.document, deviceEncryptionPublicKey: swappedEncryption.publicKey.export({ type: 'spki', format: 'pem' }).toString() };
  swappedDocument.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(swappedDocument), first.signingPrivateKey).toString('base64') };
  const swapAttempt = store.importDeviceIdentity('PVID1:' + Buffer.from(JSON.stringify(swappedDocument), 'utf8').toString('base64url'), 'owner');
  check(swapAttempt.ok === false && swapAttempt.code === 'DEVICE_IDENTITY_CONFLICT', 'a signed identity cannot silently swap its RSA encryption key');

  const created = store.createDeviceAuthorization({
    employeeName: 'Dependiente Uno', employeeData: 'Turno de tarde', posId: 'pos:pos_norte_01',
    deviceId: imported.deviceId
  }, 'owner');
  check(created.ok === true, 'v4 authorization is created after importing the phone identity');
  check(/^\d{8}$/.test(created.code), 'activation PIN has eight digits');
  check(created.protocolVersion === 4, 'new identity-bound authorization uses protocol v4');
  check(created.installationCode === installationCode, 'authorization references the stable installation identity');
  check(store._codeMatchesInstallationPattern(created.code, created.codePattern), 'eight-digit PIN follows the installation-specific pattern and checksum');

  const link = store.createDeviceAuthorizationDescriptor(created, 'owner');
  const qrPieces = LocalQr.splitDocument('D', link, created.authorizationId);
  check(qrPieces.length <= 99, 'the encrypted .pvlink fits the ProVenta D-fragment QR assembler limit');
  check(qrPieces.every(piece => piece.payload.startsWith('PCQ1|D|')), 'authorization QR fragments use the PCQ1 D channel');
  const opened = decryptLink(link, first.encryptionPrivateKey, store.getDesktopPublicKey());
  const authorization = opened.authorization;
  check(authorization.format === 'procontrol.device-authorization' && authorization.version === 4, 'encrypted payload contains signed authorization v4');
  check(authorization.deviceId === imported.deviceId, 'authorization is bound to exact device ID');
  check(authorization.deviceSigningPublicKeyHash === imported.signingKeyHash, 'authorization contains the signing-key fingerprint');
  check(authorization.authorizedPosId === 'pos_norte_01', 'authorization is fixed to exactly one POS');
  check(authorization.installationCode === created.installationCode, 'authorization includes the installation code');
  check(authorization.permanent === true, 'authorization is marked permanent after activation');
  check(authorization.code === created.code && /^\d{8}$/.test(authorization.code), 'PIN is inside the encrypted signed payload');
  const pcPublic = crypto.createPublicKey(authorization.desktopPublicKey);
  check(crypto.verify(null, signedFields(authorization), pcPublic, Buffer.from(authorization.signature.value, 'base64')), 'inner authorization signature is valid');

  const devices = store.listDevices();
  check(devices.length === 1 && devices[0].deviceId === imported.deviceId && devices[0].enabled === 1, 'linked phone is registered as enabled');
  const controlPlane = new MobileControlPlane(store, { deviceId: 'desktop_procontrol_test_01' });
  const activeDeviceRow = store.db.prepare('SELECT * FROM devices WHERE device_id=?').get(imported.deviceId);
  check(controlPlane._deviceAuthorization(activeDeviceRow).ok === true, 'control plane accepts an active v4 authorization for its own installation and device');
  check(controlPlane._deviceAuthorization({ ...activeDeviceRow, pos_id: 'pos_otro_0001' }).code === 'DEVICE_POS_SCOPE_MISMATCH', 'control plane rejects the same v4 phone outside its sole POS');

  // A v4-linked phone receives a v2 signed shift permit; legacy authorizations keep v1.
  const shiftPlane = new MobileControlPlane(store, {
    deviceId: 'desktop_procontrol_test_01',
    now: () => Date.now(),
    getInstallationLicense: () => ({ modules: ['mobile-integration'], allowedModes: ['CON_APP'] })
  });
  shiftPlane.mobileAppReady = true; // Test-only override; production remains fail-closed.
  shiftPlane.getPOSPolicy = posId => ({ ok: true, licenseValid: true, mode: 'CON_APP', posId });
  const shiftNow = Date.now();
  const shiftPermit = shiftPlane.issueShiftPermit({ posId: 'pos_norte_01', deviceId: imported.deviceId,
    employee: 'Dependiente Uno', startsAt: shiftNow - 1000, endsAt: shiftNow + 600000, sequence: 1 }, { role: 'Dueño', user: 'owner' });
  check(shiftPermit.ok === true, 'v4 installation authorization can issue a shift permit in the isolated test harness');
  check(shiftPermit.permit.version === 2, 'v4 devices receive shift-permit protocol v2');
  check(shiftPermit.permit.installationId === store.getInstallationId() && shiftPermit.permit.installationCode === installationCode,
    'v2 shift permit binds the stable ProControl installation identity');
  check(shiftPermit.permit.authorizationId === created.authorizationId && shiftPermit.permit.deviceSigningPublicKeyHash === imported.signingKeyHash,
    'v2 shift permit binds the exact active authorization and phone signing key');
  check(shiftPermit.permit.authorizedPosId === 'pos_norte_01' && shiftPermit.permit.deviceId === imported.deviceId,
    'v2 shift permit binds the phone to its one authorized POS');
  check(shiftPlane.verifyShiftPermit(shiftPermit.permitId, { deviceId: imported.deviceId, posId: 'pos_norte_01', eventAt: shiftNow }).ok,
    'signed v2 shift permit verifies while its v4 authorization is active');
  check(shiftPlane.verifyShiftPermit(shiftPermit.permitId, { deviceId: imported.deviceId, posId: 'pos_otro_0001', eventAt: shiftNow }).code === 'SHIFT_PERMIT_POS_MISMATCH',
    'v2 shift permit cannot be replayed against a different POS');

  const history = store.listDeviceAuthorizations('pos_norte_01');
  check(history.length === 1 && history[0].status === 'active', 'history records activated authorization');
  check(history[0].protocolVersion === 4 && history[0].encryptionConfigured === 1, 'history shows v4 and encryption status');

  // A revocation must disable the device and invalidate its permanent authorization.
  const revoked = store.revokeDeviceAuthorization(created.authorizationId, 'owner', 'pos_norte_01');
  check(revoked.ok === true, 'authorization can be revoked');
  check(shiftPlane.verifyShiftPermit(shiftPermit.permitId, { deviceId: imported.deviceId, posId: 'pos_norte_01', eventAt: shiftNow }).ok === false,
    'revocation invalidates future ProControl acceptance of a previously issued v2 permit');
  check(store.listDevices()[0].enabled === 0, 'revocation disables the paired device');
  check(store.listDeviceAuthorizations('pos_norte_01')[0].status === 'invalidated', 'revocation changes the authorization history');
  const reimportRevokedIdentity = store.importDeviceIdentity(first.encoded, 'owner');
  check(reimportRevokedIdentity.ok === false && reimportRevokedIdentity.code === 'DEVICE_IDENTITY_REVOKED',
    'a revoked phone identity cannot be imported again as a new device');
  assert.throws(() => store.createDeviceAuthorization({
    employeeName: 'Dependiente Uno', employeeData: '', posId: 'pos:pos_norte_01',
    deviceId: imported.deviceId, replacesAuthorizationId: created.authorizationId
  }, 'owner'), error => error && error.code === 'REPLACEMENT_DEVICE_MUST_BE_DIFFERENT');
  assertions++;
  assert.throws(() => store.createDeviceAuthorization({
    employeeName: 'Dependiente Uno', employeeData: '', posId: 'pos:pos_norte_01',
    replacesAuthorizationId: created.authorizationId
  }, 'owner'), error => error && error.code === 'REPLACEMENT_DEVICE_IDENTITY_REQUIRED');
  assertions++;

  // Replacement: the old record is superseded and the new handset gets a different device identity.
  const second = generateIdentity('phone_proventa_00000002', 'Samsung Galaxy A26 nuevo');
  check(store.importDeviceIdentity(second.encoded, 'owner').ok === true, 'replacement phone identity imports');
  const replacement = store.createDeviceAuthorization({
    employeeName: 'Dependiente Uno', employeeData: '', posId: 'pos:pos_norte_01',
    deviceId: 'phone_proventa_00000002', replacesAuthorizationId: created.authorizationId
  }, 'owner');
  const replacementLink = store.createDeviceAuthorizationDescriptor(replacement, 'owner');
  const openedReplacement = decryptLink(replacementLink, second.encryptionPrivateKey, store.getDesktopPublicKey());
  check(openedReplacement.authorization.deviceId === 'phone_proventa_00000002', 'replacement link is encrypted to the new phone only');
  const replacementRows = store.listDeviceAuthorizations('pos_norte_01');
  check(replacementRows.find(row => row.authorizationId === created.authorizationId).status === 'superseded', 'previous authorization is marked superseded');
  check(replacementRows.find(row => row.authorizationId === replacement.authorizationId).status === 'active', 'replacement authorization becomes active');
  check(store.listDevices().find(device => device.deviceId === 'phone_proventa_00000002').enabled === 1, 'replacement phone is active');
  const replacementDeviceRow = store.db.prepare('SELECT * FROM devices WHERE device_id=?').get('phone_proventa_00000002');
  check(controlPlane._deviceAuthorization(replacementDeviceRow).ok === true, 'control plane accepts the replacement phone authorization');
  check(controlPlane._deviceAuthorization(activeDeviceRow).code === 'DEVICE_AUTHORIZATION_INACTIVE', 'control plane blocks the superseded phone immediately');

  // Historical authorizations are no longer truncated at 500 rows.
  const now = Date.now();
  const insert = store.db.prepare(`INSERT INTO device_authorizations(authorization_id,installation_id,employee_name,employee_data_json,code_hash,issued_at,expires_at,status,created_by,authorized_pos_id,updated_at,protocol_version)
    VALUES(?,?,?,?,?,?,?,'invalidated','test','pos_norte_01',?,2)`);
  for (let index = 0; index < 520; index++) {
    const issuedAt = now - 100000 - index;
    insert.run(`auth_history_${String(index).padStart(5, '0')}`, store.getInstallationId(), 'Histórico', '{}', crypto.createHash('sha256').update(`history-${index}`).digest('hex'), issuedAt, now - 1, issuedAt);
  }
  const allHistory = store.listDeviceAuthorizations('pos_norte_01');
  check(allHistory.length >= 522, 'history returns every record beyond 500');
  check(allHistory.some(row => row.authorizationId === 'auth_history_00519'), 'oldest historical authorization remains visible');
  const revokedReplacement = store.revokeDeviceAuthorization(replacement.authorizationId, 'owner', 'pos_norte_01');
  check(revokedReplacement.ok && controlPlane._deviceAuthorization(replacementDeviceRow).code === 'DEVICE_AUTHORIZATION_INACTIVE', 'revoking the current v4 phone blocks it in the control plane');

  // Corrupted or tampered device identities must never be imported.
  const tampered = JSON.parse(Buffer.from(first.encoded.slice('PVID1:'.length), 'base64url').toString('utf8'));
  tampered.label = 'Teléfono manipulado';
  const invalid = store.importDeviceIdentity('PVID1:' + Buffer.from(JSON.stringify(tampered)).toString('base64url'), 'owner');
  check(invalid.ok === false && invalid.code === 'DEVICE_IDENTITY_SIGNATURE_INVALID', 'tampered PVID1 identity is rejected');

  console.log(`ProControl ProVenta v4 device link: ${assertions} assertions passed.`);
} finally {
  if (store) { try { store.close(); } catch (_) {} }
  if (otherStore) { try { otherStore.close(); } catch (_) {} }
  fs.rmSync(temp, { recursive: true, force: true });
  fs.rmSync(otherTemp, { recursive: true, force: true });
}
