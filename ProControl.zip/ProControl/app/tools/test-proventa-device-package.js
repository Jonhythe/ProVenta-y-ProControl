'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {
  MobileBridgeStore, stableJson, signedFields, sha256,
  DEVICE_DATA_PACKAGE_FORMAT, DEVICE_DATA_PACKAGE_TTL_MS
} = require('../electron/mobile-bridge/store');
let assertions = 0;
function check(value, message) { assertions++; assert.ok(value, message); }
function equal(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
function keys() {
  const signing = crypto.generateKeyPairSync('ed25519');
  const encryption = crypto.generateKeyPairSync('rsa', { modulusLength: 3072, publicExponent: 0x10001 });
  return {
    signingPrivate: signing.privateKey,
    signingPublic: signing.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    encryptionPrivate: encryption.privateKey,
    encryptionPublic: encryption.publicKey.export({ type: 'spki', format: 'pem' }).toString()
  };
}
function decryptEnvelope(envelope, privateKey) {
  const header = {};
  for (const key of ['format','version','algorithm','packageId','installationId','authorizationId','deviceId','posId','type','createdAt','expiresAt','payloadHash','signerPublicKey']) header[key] = envelope[key];
  const contentKey = crypto.privateDecrypt({ key: privateKey, padding: crypto.constants.RSA_PKCS1_OAEP_PADDING, oaepHash: 'sha256' }, Buffer.from(envelope.encryption.wrappedKey, 'base64'));
  const decipher = crypto.createDecipheriv('aes-256-gcm', contentKey, Buffer.from(envelope.encryption.iv, 'base64'));
  decipher.setAAD(Buffer.from(stableJson(header), 'utf8'));
  decipher.setAuthTag(Buffer.from(envelope.encryption.tag, 'base64'));
  const plaintext = Buffer.concat([decipher.update(Buffer.from(envelope.ciphertext, 'base64')), decipher.final()]).toString('utf8');
  contentKey.fill(0);
  return plaintext;
}
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-proventa-device-package-'));
let store;
try {
  store = new MobileBridgeStore(root);
  const installationId = store.getInstallationId();
  const auth = store.createDeviceAuthorization({ employeeName: 'Dependiente cifrado', posId: 'pos_alpha_01' }, 'Dueño');
  const deviceKeys = keys();
  const enrollment = {
    format: 'procontrol.device-enrollment-request', version: 3,
    installationId, authorizationId: auth.authorizationId, authorizedPosId: 'pos_alpha_01', code: auth.code,
    deviceId: 'device_crypto_01', label: 'Android cifrado',
    devicePublicKey: deviceKeys.signingPublic,
    deviceEncryptionPublicKey: deviceKeys.encryptionPublic,
    createdAt: new Date().toISOString()
  };
  enrollment.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(enrollment), deviceKeys.signingPrivate).toString('base64') };
  const imported = store.importDeviceEnrollment(enrollment, 'Dueño');
  check(imported.ok, 'Importa el enrolamiento v2 con clave RSA de cifrado');
  equal(imported.encryptionConfigured, true, 'Registra la capacidad de cifrado del dispositivo');
  equal(store.listDeviceAuthorizations()[0].encryptionConfigured, 1, 'El registro administrativo indica clave de cifrado');

  const payload = {
    schema: 'proventa.inventory-snapshot', schemaVersion: 1, installationId,
    posId: 'pos_alpha_01', posName: 'Punto Alpha', generatedAt: new Date().toISOString(),
    exchangeRates: { USD_CUP: 410 }, catalog: [{ productId: 'prod_rice_01', name: 'Arroz' }],
    inventory: [{ productId: 'prod_rice_01', name: 'Arroz', unit: 'lb', qty: 12, sale: 100, saleTransf: 108, saleTransfMode: 'percentage', saleTransfPercent: 8, saleUSD: 1.5, saleCurrency: 'USD' }]
  };
  const requestId = 'request_crypto_01';
  const result = store.createDeviceBoundDataPackage({ deviceId: 'device_crypto_01', posId: 'pos_alpha_01', requestId, payload }, 'Dueño');
  check(result.ok, 'Crea un paquete cifrado para el dispositivo autorizado');
  equal(result.posId, 'pos_alpha_01', 'Vincula el paquete al POS solicitado');
  const envelope = JSON.parse(result.envelopeJson);
  equal(envelope.format, DEVICE_DATA_PACKAGE_FORMAT, 'Usa el formato de paquete de datos cifrado');
  equal(envelope.algorithm, 'RSA-OAEP-256+A256GCM', 'Declara RSA-OAEP-SHA256 y AES-256-GCM');
  equal(envelope.deviceId, 'device_crypto_01', 'Vincula el paquete al teléfono exacto');
  equal(envelope.installationId, installationId, 'Vincula el paquete a la instalación del dueño');
  equal(envelope.authorizationId, auth.authorizationId, 'Vincula el paquete a la autorización vigente');
  check(!result.envelopeJson.includes('Arroz'), 'El texto del producto no aparece en claro dentro del archivo');
  check(crypto.verify(null, signedFields(envelope), crypto.createPublicKey(envelope.signerPublicKey), Buffer.from(envelope.signature.value, 'base64')), 'La envoltura cifrada tiene firma Ed25519 de ProControl');
  const plaintext = decryptEnvelope(envelope, deviceKeys.encryptionPrivate);
  equal(sha256(plaintext), envelope.payloadHash, 'El hash del contenido se verifica tras descifrar');
  equal(JSON.parse(plaintext).inventory[0].name, 'Arroz', 'El dispositivo destinatario puede recuperar el inventario original');
  let wrongKeyFailed = false;
  try { decryptEnvelope(envelope, keys().encryptionPrivate); } catch (_) { wrongKeyFailed = true; }
  check(wrongKeyFailed, 'Otro teléfono no puede descifrar el paquete');

  const duplicate = store.createDeviceBoundDataPackage({ deviceId: 'device_crypto_01', posId: 'pos_alpha_01', requestId, payload }, 'Dueño');
  check(duplicate.ok && duplicate.duplicate, 'Repetir la misma solicitud devuelve el paquete original sin crear otro');
  equal(duplicate.packageId, result.packageId, 'La idempotencia conserva el packageId');
  const changedPayload = { ...payload, inventory: [{ ...payload.inventory[0], qty: 13 }] };
  equal(store.createDeviceBoundDataPackage({ deviceId: 'device_crypto_01', posId: 'pos_alpha_01', requestId, payload: changedPayload }, 'Dueño').code, 'DEVICE_DATA_REQUEST_ID_CONFLICT', 'Reutilizar requestId con contenido distinto se rechaza');
  equal(store.createDeviceBoundDataPackage({ deviceId: 'device_crypto_01', posId: 'pos_beta_02', requestId: 'request_scope_02', payload }, 'Dueño').code, 'DEVICE_DATA_PACKAGE_SCOPE_MISMATCH', 'El payload no puede declarar un POS distinto al destino');

  const tampered = { ...envelope, ciphertext: (envelope.ciphertext[0] === 'A' ? 'B' : 'A') + envelope.ciphertext.slice(1) };
  check(!crypto.verify(null, signedFields(tampered), crypto.createPublicKey(tampered.signerPublicKey), Buffer.from(tampered.signature.value, 'base64')), 'La firma deja de ser válida si se modifica el ciphertext');
  let gcmRejected = false;
  try { decryptEnvelope(tampered, deviceKeys.encryptionPrivate); } catch (_) { gcmRejected = true; }
  check(gcmRejected, 'AES-GCM detecta modificaciones del contenido cifrado');
  check(Number(envelope.expiresAt) - Date.parse(envelope.createdAt) === DEVICE_DATA_PACKAGE_TTL_MS, 'El paquete tiene vencimiento explícito de 24 horas');

  const weakAuth = store.createDeviceAuthorization({ employeeName: 'Clave RSA débil', posId: 'pos_alpha_01' }, 'Dueño');
  const weakSigning = crypto.generateKeyPairSync('ed25519');
  const weakEncryption = crypto.generateKeyPairSync('rsa', { modulusLength: 2048, publicExponent: 0x10001 });
  const weakEnrollment = {
    format: 'procontrol.device-enrollment-request', version: 3,
    installationId, authorizationId: weakAuth.authorizationId, authorizedPosId: 'pos_alpha_01', code: weakAuth.code,
    deviceId: 'device_rsa_weak_01', label: 'RSA débil',
    devicePublicKey: weakSigning.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    deviceEncryptionPublicKey: weakEncryption.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    createdAt: new Date().toISOString()
  };
  weakEnrollment.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(weakEnrollment), weakSigning.privateKey).toString('base64') };
  equal(store.importDeviceEnrollment(weakEnrollment, 'Dueño').code, 'INVALID_DEVICE_ENCRYPTION_PUBLIC_KEY', 'Rechaza claves RSA de menos de 3072 bits');

  const authNoEncryption = store.createDeviceAuthorization({ employeeName: 'Dispositivo antiguo', posId: 'pos_alpha_01' }, 'Dueño');
  const oldKeys = crypto.generateKeyPairSync('ed25519');
  const oldPair = store.pairDevice({ code: authNoEncryption.code, authorizationId: authNoEncryption.authorizationId, authorizedPosId: 'pos_alpha_01', installationId, deviceId: 'device_old_0001', label: 'Legacy sin cifrado', publicKey: oldKeys.publicKey.export({ type: 'spki', format: 'pem' }).toString() }, 'Dueño');
  check(oldPair.ok, 'Permite conservar dispositivos v1 para compatibilidad');
  equal(store.createDeviceBoundDataPackage({ deviceId: 'device_old_0001', posId: 'pos_alpha_01', requestId: 'request_old_0001', payload }, 'Dueño').code, 'DEVICE_ENCRYPTION_KEY_NOT_REGISTERED', 'No envía datos a un teléfono sin clave de cifrado');

  equal(store.revokeDeviceAuthorization(auth.authorizationId, 'Dueño').ok, true, 'La revocación invalida la autorización');
  equal(store.createDeviceBoundDataPackage({ deviceId: 'device_crypto_01', posId: 'pos_alpha_01', requestId: 'request_after_revoke', payload }, 'Dueño').code, 'DEVICE_NOT_AUTHORIZED', 'No se generan paquetes nuevos para un dispositivo revocado');
  equal(store.createDeviceBoundDataPackage({ deviceId: 'device_crypto_01', posId: 'pos_alpha_01', requestId, payload }, 'Dueño').code, 'DEVICE_NOT_AUTHORIZED', 'La idempotencia tampoco permite recuperar un paquete desde un dispositivo revocado');
} finally {
  try { if (store) store.close(); } catch (_) {}
  fs.rmSync(root, { recursive: true, force: true });
}
console.log(`ProVenta device-bound encryption: ${assertions} assertions passed.`);
