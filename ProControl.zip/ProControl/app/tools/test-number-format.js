'use strict';
const assert = require('node:assert/strict');
const NumberFormat = require('../renderer/number-format.js');

assert.equal(NumberFormat.maxDecimals, 2);
assert.equal(NumberFormat.formatNumber(1000, 0), '1,000');
assert.equal(NumberFormat.formatNumber(10000, 0), '10,000');
assert.equal(NumberFormat.formatNumber(100000, 0), '100,000');
assert.equal(NumberFormat.formatMoney(3666), '3,666.00');
assert.equal(NumberFormat.formatMoney(36000.9), '36,000.90');
assert.equal(NumberFormat.formatMoney(1234.567), '1,234.57');
assert.equal(NumberFormat.formatNumber(1.239, 2), '1.24');
assert.equal(NumberFormat.formatNumber(1.231, 2), '1.23');
assert.equal(NumberFormat.formatFixed(1234.56789, 4), '1,234.57');
assert.equal(NumberFormat.formatNumber(1234.56789, 8), '1,234.57');
assert.equal(NumberFormat.formatNumber(12.5, 0), '13');
assert.equal(NumberFormat.formatFixed(-36000.9, 2), '-36,000.90');
assert.equal(NumberFormat.formatMoney(null), '0.00');
assert.equal(NumberFormat.formatNumber('no es número'), '—');

const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const html = read('renderer/index.html');

assert.ok(html.includes('<script src="app://number-format.js"></script>'));
assert.ok(html.includes('ProControlNumberFormat.formatMoney(num)'));
assert.ok(html.includes('ProControlNumberFormat.formatNumber(num, maximumFractionDigits)'));
assert.ok(html.includes('ProControlNumberFormat.formatFixed(num, fractionDigits)'));
assert.ok(read('renderer/business-management.js').includes('root.ProControlNumberFormat.formatMoney(value)'));
assert.ok(read('renderer/product-units.js').includes('root.ProControlNumberFormat.formatNumber'));
assert.ok(read('renderer/mobile-bridge-ui.js').includes('fmtNumber(result.devices'));
assert.ok(read('renderer/proventa-authorization-ui.js').includes('fmtNumber(result.productCount'));

console.log('PASS - Formato global: miles, punto decimal, dos decimales máximos y redondeo visual.');
