'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const Reconcile = require('../renderer/mobile-reconcile');
const SalesLedgerOps = require('../renderer/sales-ledger');
let assertions = 0;
function ok(value, message) { assertions++; assert.ok(value, message); }
function eq(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
function makeState() {
  return {
    currentUser: 'Dueño prueba',
    inventory: [{ productId:'prod_b', name:'Arroz', unit:'u', qty:20, sale:3, saleTransf:3, saleUSD:1 }],
    productCatalog: [{ id:'prod_a', name:'Agua 500 ml', unit:'u', unitsPerBox:15 }, { id:'prod_b', name:'Arroz', unit:'u', unitsPerBox:null }],
    pointsOfSale: [
      { id:'pos_test_0001', name:'Punto A', salesTrackingEnabled:true, inventory:[{ productId:'prod_a', name:'Agua 500 ml', unit:'u', qty:50, sale:2, saleTransf:2, saleUSD:1 }, { productId:'prod_b', name:'Arroz', unit:'u', qty:10, sale:3, saleTransf:3, saleUSD:1 }] },
      { id:'pos_test_0002', name:'Punto B', salesTrackingEnabled:true, inventory:[] }
    ],
    transfers: [], salesLedger: [], closingSessions: {}, auditLog: [], businessData:{name:'Tienda prueba'}, dollarRate:24
  };
}
function dependencies(state) {
  const Inventory = {
    posReference: pos => pos && pos.id,
    _productIdForItem: item => item && item.productId,
    productIdForName: (name, s) => {
      const find = arr => (arr||[]).find(x => x && String(x.name).toLowerCase()===String(name).toLowerCase());
      const record = find(s.productCatalog) || find(s.inventory);
      return record && (record.id || record.productId) || null;
    },
    unitsPerBoxForPOSItem: item => { const p=state.productCatalog.find(x=>x.id===item.productId); return p ? p.unitsPerBox : null; }
  };
  const DataStore = {
    save: () => true,
    transaction: (_label, keys, fn) => {
      const snapshots = {};
      try { for (const key of keys) snapshots[key] = JSON.parse(JSON.stringify(state[key])); }
      catch (error) { return {ok:false,error}; }
      try { return {ok:true,result:fn()}; }
      catch (error) { for (const key of keys) state[key] = snapshots[key]; return {ok:false,error}; }
    }
  };
  return { appState:state, Inventory, DataStore, SalesLedgerOps, ProductUnits: require('../renderer/product-units') };
}
function makeSale(id, quantity, presentation='unit', posId='pos_test_0001') {
  return SalesLedgerOps.buildTransaction({
    id, posId, posName: posId==='pos_test_0001'?'Punto A':'Punto B', user:'Operador móvil', paymentMethod:'cash', source:'mobile',
    lines:[{ productId:'prod_a', name:'Agua 500 ml', baseUnit:'u', presentation, quantity, unitsPerBox:presentation==='box'?15:null, unitPrice:presentation==='box'?30:2 }]
  });
}
function pkg(type, payload, id='package_test_0001') { return { packageId:id, deviceId:'device_test_0001', type, status:'accepted_for_reconciliation', payloadHash:crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex'), payload }; }

// Multi-ticket batch must preflight all stock and then apply atomically.
{
  const state=makeState(), deps=dependencies(state);
  const sales=[makeSale('sale_test_0001',3), makeSale('sale_test_0002',2)];
  const record=pkg('sale_batch',{schemaVersion:1,transactions:sales});
  const preview=Reconcile.preview(record,deps); eq(preview.newOperations,2,'Preview cuenta ambos tickets');
  const applied=Reconcile.apply(record,deps); ok(applied.applied,'El lote se aplica');
  eq(state.pointsOfSale[0].inventory[0].qty,45,'El stock descuenta las cantidades de ambos tickets');
  eq(state.salesLedger.length,2,'Se guardan ambos tickets');
  Reconcile.apply(record,deps);
  eq(state.pointsOfSale[0].inventory[0].qty,45,'Reintentar el mismo paquete no vuelve a descontar stock');
  eq(state.salesLedger.length,2,'Reintentar el lote no duplica tickets');
}
// Boxes convert to the product's configured base-unit count.
{
  const state=makeState(), deps=dependencies(state);
  const record=pkg('sale_batch',{schemaVersion:1,transactions:[makeSale('sale_box_0001',2,'box')]},'package_box_0001');
  Reconcile.apply(record,deps);
  eq(state.pointsOfSale[0].inventory[0].qty,20,'Dos cajas de 15 descuentan 30 unidades base');
  eq(state.salesLedger[0].items[0].presentation,'box','El ticket conserva la presentación caja');
}
// Insufficient stock fails before any mutations.
{
  const state=makeState(), deps=dependencies(state);
  const record=pkg('sale_batch',{schemaVersion:1,transactions:[makeSale('sale_short_0001',60)]},'package_short_0001');
  const before=state.pointsOfSale[0].inventory[0].qty;
  assertions++; assert.throws(()=>Reconcile.apply(record,deps),/Stock insuficiente/);
  eq(state.pointsOfSale[0].inventory[0].qty,before,'El fallo de stock no altera existencias');
  eq(state.salesLedger.length,0,'El fallo no deja ticket parcial');
}
// Full return restores stock, creates a negative event and leaves original sale.
{
  const state=makeState(), deps=dependencies(state);
  const sale=makeSale('sale_return_0001',2);
  Reconcile.apply(pkg('sale_batch',{schemaVersion:1,transactions:[sale]},'package_sale_return_01'),deps);
  const returned=SalesLedgerOps.buildReturnTransaction({id:'return_test_0001',originalSale:state.salesLedger[0],user:'Supervisor móvil'});
  Reconcile.apply(pkg('return',{schemaVersion:1,transactions:[returned]},'package_return_0001'),deps);
  eq(state.pointsOfSale[0].inventory[0].qty,50,'Devolver el ticket restaura stock');
  eq(state.salesLedger.length,2,'Se conserva ticket original y se agrega evento de devolución');
  eq(state.salesLedger[0].kind,'sale','El ticket original permanece intacto');
  eq(state.salesLedger[1].kind,'return','La devolución queda como evento negativo');
}
// Transfers move base units and are idempotent by package id.
{
  const state=makeState(), deps=dependencies(state);
  const record=pkg('transfer',{schemaVersion:1,transfer:{id:'transfer_mobile_0001',source:'warehouse',destination:'pos_test_0002',items:[{productId:'prod_b',name:'Arroz',unit:'u',qty:5}]}},'package_transfer_0001');
  Reconcile.apply(record,deps);
  eq(state.inventory[0].qty,15,'La transferencia descuenta almacén');
  eq(state.pointsOfSale[1].inventory[0].qty,5,'La transferencia crea stock en destino');
  Reconcile.apply(record,deps);
  eq(state.inventory[0].qty,15,'Reintento de transferencia no vuelve a descontar');
  eq(state.pointsOfSale[1].inventory[0].qty,5,'Reintento de transferencia no duplica entrada');
}
// Shift events don't bypass physical desktop closing; snapshots are read-only.
{
  const state=makeState(), deps=dependencies(state);
  Reconcile.apply(pkg('shift_open',{schemaVersion:1,shift:{id:'shift_mobile_0001',posId:'pos_test_0001',startedAt:new Date().toISOString()}},'package_shift_open_1'),deps);
  ok(state.pointsOfSale[0].salesTrackingEnabled,'Inicio móvil habilita seguimiento de tickets');
  Reconcile.apply(pkg('shift_close',{schemaVersion:1,shift:{id:'shift_mobile_0001',posId:'pos_test_0001',endedAt:new Date().toISOString()}},'package_shift_close_1'),deps);
  ok(state.auditLog.some(x=>x.type==='mobile-shift-close-request'),'Cierre móvil crea solicitud auditada');
  ok(!state.closingSessions['0'],'El cierre móvil no inventa conteo físico');
  const before=state.inventory[0].qty;
  const snapshot=pkg('inventory_snapshot',{schemaVersion:1,inventory:[{productId:'prod_b',name:'Arroz',qty:99}]},'package_snapshot_001');
  const result=Reconcile.apply(snapshot,deps);
  eq(state.inventory[0].qty,before,'La instantánea nunca sobrescribe stock');
  eq(result.differences.length,1,'La instantánea reporta la diferencia');
}

// A mobile goods receipt records delivery evidence only; desktop stock was
// already updated by the original dispatch and must not be added a second time.
{
  const state=makeState(), deps=dependencies(state);
  const beforePos=state.pointsOfSale[0].inventory[1].qty;
  const beforeWarehouse=state.inventory[0].qty;
  const payload={
    schemaVersion:1,
    dispatchId:'dispatch_mobile_0001',
    posId:'pos_test_0001',
    shiftPermitId:'permit_mobile_0001',
    confirmationCode:'12345678',
    itemsHash:'a'.repeat(64),
    items:[{productId:'prod_b',name:'Arroz',unit:'u',quantity:5}]
  };
  const record=pkg('goods_receipt',payload,'package_goods_receipt_01');
  const preview=Reconcile.preview(record,deps);
  eq(preview.newOperations,1,'La vista previa reconoce una recepción pendiente');
  ok(preview.message.includes('NO se modificará'), 'La vista previa advierte que no se repetirá el movimiento de stock');
  const applied=Reconcile.apply(record,deps);
  ok(applied.applied && applied.changedStock===false,'La recepción se concilia sin cambiar inventario');
  eq(state.pointsOfSale[0].inventory[1].qty,beforePos,'La recepción no vuelve a sumar stock en el POS');
  eq(state.inventory[0].qty,beforeWarehouse,'La recepción tampoco cambia el almacén');
  eq(state.auditLog.filter(x=>x && x.id==='mobile-goods-receipt:dispatch_mobile_0001').length,1,
    'La recepción queda registrada una sola vez');
  const retry=Reconcile.apply(record,deps);
  ok(retry.recovered && retry.alreadyApplied,'El reintento recupera el recibo de recepción');
  eq(state.pointsOfSale[0].inventory[1].qty,beforePos,'El reintento no duplica existencias');
}
 
// Durable receipt closes the crash window between commercial save and bridge ACK.
{
  const state=makeState(), deps=dependencies(state);
  const record=pkg('sale_batch',{schemaVersion:1,transactions:[makeSale('sale_durable_0001',2)]},'package_durable_001');
  const first=Reconcile.apply(record,deps);
  ok(first.applied,'Primer intento guarda la operación y su recibo durable');
  eq(state.auditLog.filter(x=>x && x.id==='mobile-package-receipt:package_durable_001').length,1,'El recibo durable se guarda una sola vez');
  const stock=state.pointsOfSale[0].inventory[0].qty;
  const recovered=Reconcile.apply(record,deps);
  ok(recovered.recovered && recovered.alreadyApplied,'Reintento reconoce el recibo y entra en modo recuperación');
  eq(state.pointsOfSale[0].inventory[0].qty,stock,'La recuperación no vuelve a descontar stock');
  eq(state.salesLedger.length,1,'La recuperación no duplica el ticket');
  const conflicting={...record,payloadHash:'f'.repeat(64)};
  assertions++; assert.throws(()=>Reconcile.apply(conflicting,deps),/PACKAGE_ID_CONFLICT/,'La misma ID con otra huella no se acepta como repetición válida');
}

console.log(`Mobile reconciliation: ${assertions} assertions passed.`);
