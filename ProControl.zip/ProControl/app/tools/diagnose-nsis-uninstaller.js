#!/usr/bin/env node
'use strict';

/**
 * Diagnostico SOLO DE LECTURA. Ya no intercepta fs-extra.unlink ni captura
 * archivos temporales de electron-builder, porque esos temporales no son
 * necesariamente el desinstalador instalado en el equipo del cliente.
 *
 * Uso:
 *   node tools/diagnose-nsis-uninstaller.js "ruta\\Setup.exe"
 *   node tools/diagnose-nsis-uninstaller.js "ruta\\Uninstall ProControl.exe" --uninstaller
 */
const path = require('node:path');
const { inspectNsisFile } = require('./nsis-integrity');

const file = process.argv[2];
const expectedKind = process.argv.includes('--uninstaller') ? 'uninstaller' : 'installer';

if (!file || process.argv.includes('--recovery')) {
  console.error('Uso: node tools/diagnose-nsis-uninstaller.js "ruta\\archivo.exe" [--uninstaller]');
  console.error('Este script es de solo lectura; no compila, no captura temporales y no modifica archivos.');
  process.exit(2);
}

try {
  const result = inspectNsisFile(path.resolve(file), { expectedKind });
  console.log(JSON.stringify(result, null, 2));
  if (result.status === 'VALID') {
    console.log('NSIS FILE: VALID');
    process.exit(0);
  }
  console.error(`NSIS FILE: ${result.status}`);
  console.error(result.reason);
  process.exit(result.status === 'INDETERMINATE' ? 3 : 1);
} catch (error) {
  console.error('NSIS DIAGNOSTIC ERROR');
  console.error(error.stack || error.message || error);
  process.exit(1);
}
