param(
    [string]$UninstallerPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$appRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path

if (-not $UninstallerPath) {
    $registryPaths = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    $entry = Get-ItemProperty -Path $registryPaths -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -like 'ProControl 1.2.0*' } |
        Select-Object -First 1

    if (-not $entry -or -not $entry.UninstallString) {
        throw 'Windows no tiene un registro ProControl 1.2.0 con UninstallString.'
    }

    $command = [string]$entry.UninstallString
    if ($command -match '^\s*"([^"]+\.exe)"') {
        $UninstallerPath = $Matches[1]
    } elseif ($command -match '^\s*(.+?\.exe)(?:\s|$)') {
        $UninstallerPath = $Matches[1].Trim('"')
    } else {
        throw "No se pudo extraer la ruta de UninstallString: $command"
    }
}

if (-not (Test-Path -LiteralPath $UninstallerPath -PathType Leaf)) {
    throw "Windows apunta a un desinstalador que no existe: $UninstallerPath"
}

$file = Get-Item -LiteralPath $UninstallerPath
$hash1 = (Get-FileHash -LiteralPath $UninstallerPath -Algorithm SHA256).Hash.ToUpperInvariant()
Start-Sleep -Seconds 1
$hash2 = (Get-FileHash -LiteralPath $UninstallerPath -Algorithm SHA256).Hash.ToUpperInvariant()

Write-Host 'DESINSTALADOR REGISTRADO EN WINDOWS' -ForegroundColor Cyan
Write-Host "Ruta: $UninstallerPath"
Write-Host "Bytes: $($file.Length)"
Write-Host "SHA256: $hash2"
if ($hash1 -ne $hash2) { throw 'El archivo cambio durante la lectura; no debe ejecutarse.' }

& node.exe (Join-Path $appRoot 'tools\nsis-integrity.js') $UninstallerPath --uninstaller
$code = $LASTEXITCODE

if ($code -eq 0) {
    Write-Host 'La cabecera NSIS y el CRC del desinstalador son validos.' -ForegroundColor Green
} elseif ($code -eq 3) {
    Write-Warning 'La estructura NSIS no se puede leer en bruto (posible PE empaquetado). No se declara corrupto; hace falta la prueba real de desinstalacion.'
} else {
    throw "El desinstalador no supero la validacion NSIS (codigo $code)."
}
