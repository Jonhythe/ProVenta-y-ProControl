'use strict';

const assert = require('node:assert/strict');
const nodeCrypto = require('node:crypto');

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  Object.defineProperty(globalThis, 'crypto', { value: nodeCrypto.webcrypto, configurable: true });
}
globalThis.window = { crypto: globalThis.crypto };

const Security = require('../renderer/security');
const {
  findOwnerWithPin,
  findUserWithPasswordAndSecurityAnswer,
  findPrivilegedCredential,
  registerAccountInStore,
  decodeStoredValue
} = require('../electron/security/privileged-credentials');
const { DatabaseSync } = require('node:sqlite');

function storedCredential(value) {
  const salt = nodeCrypto.randomBytes(16);
  const hash = nodeCrypto.pbkdf2Sync(value, salt, 120000, 32, 'sha256');
  return `pbkdf2$120000$${salt.toString('hex')}$${hash.toString('hex')}`;
}

async function main() {
  assert.equal(Security.PBKDF2_ITERATIONS, 600000, 'Las contraseñas nuevas deben usar 600.000 iteraciones.');
  assert(Security.DUMMY_RECORD.startsWith('pbkdf2$600000$'), 'La verificación de usuarios inexistentes debe igualar el costo actual.');

  const password = 'ProControl-test-Password-1';
  const currentRecord = await Security.createPasswordRecord(password);
  assert.match(currentRecord, /^pbkdf2\$600000\$[a-f0-9]{32}\$[a-f0-9]{64}$/);
  assert.deepEqual(await Security.verifyPassword(password, currentRecord), { ok: true, needsUpgrade: false });
  assert.deepEqual(await Security.verifyPassword('incorrecta', currentRecord), { ok: false, needsUpgrade: false });

  const oldSalt = nodeCrypto.randomBytes(16);
  const oldDerived = await Security._derive(password, oldSalt, 120000);
  const oldRecord = `pbkdf2$120000$${oldSalt.toString('hex')}$${Security._toHex(oldDerived)}`;
  assert.deepEqual(await Security.verifyPassword(password, oldRecord), { ok: true, needsUpgrade: true });

  const legacyRecord = nodeCrypto.createHash('sha256').update(password, 'utf8').digest('hex');
  assert.deepEqual(await Security.verifyPassword(password, legacyRecord), { ok: true, needsUpgrade: true });

  for (const invalid of [
    'pbkdf2$120000x$00112233445566778899aabbccddeeff$' + '0'.repeat(64),
    'pbkdf2$1000001$00112233445566778899aabbccddeeff$' + '0'.repeat(64),
    'pbkdf2$120000$bad$' + '0'.repeat(64),
    'pbkdf2$120000$00112233445566778899aabbccddeeff$not-a-hash',
    'plaintext-password',
  ]) {
    assert.deepEqual(await Security.verifyPassword(password, invalid), { ok: false, needsUpgrade: false });
  }

  const ownerName = 'Dueño Prueba';
  const ownerPassword = 'Clave-dueño-segura';
  const ownerPin = '572941';
  const ownerRoles = { [ownerName]: 'Dueño' };
  const ownerPasswords = { [ownerName]: storedCredential(ownerPassword) };
  const ownerPins = { [ownerName]: storedCredential(ownerPin) };
  assert.deepEqual(
    findOwnerWithPin({ password: ownerPassword, pin: '1234', roles: ownerRoles, passwords: ownerPasswords, pins: ownerPins }),
    { ok: false, code: 'INVALID_CREDENTIALS' },
    'Un PIN de cuatro dígitos siempre se rechaza.'
  );
  assert.deepEqual(
    findOwnerWithPin({ password: ownerPassword, pin: '123456', roles: ownerRoles, passwords: ownerPasswords, pins: ownerPins }),
    { ok: false, code: 'AUTH_FAILED' },
    'Una contraseña válida no compensa un PIN incorrecto.'
  );
  assert.deepEqual(
    findOwnerWithPin({ password: 'contraseña equivocada', pin: ownerPin, roles: ownerRoles, passwords: ownerPasswords, pins: ownerPins }),
    { ok: false, code: 'AUTH_FAILED' },
    'Un PIN válido no compensa una contraseña incorrecta.'
  );
  assert.deepEqual(
    findOwnerWithPin({ password: ownerPassword, pin: '12345', roles: ownerRoles, passwords: ownerPasswords, pins: ownerPins }),
    { ok: false, code: 'INVALID_CREDENTIALS' },
    'También se rechazan PIN incompletos de cinco dígitos.'
  );
  assert.deepEqual(
    findOwnerWithPin({ password: ownerPassword, pin: ownerPin, roles: ownerRoles, passwords: ownerPasswords, pins: ownerPins }),
    { ok: true, user: ownerName, role: 'Dueño' },
    'Solo la combinación exacta de contraseña y PIN habilita al Dueño.'
  );
  assert.deepEqual(
    findOwnerWithPin({
      password: ownerPassword, pin: ownerPin,
      roles: { ...ownerRoles, 'Dueño duplicado': 'Dueño' },
      passwords: { ...ownerPasswords, 'Dueño duplicado': storedCredential(ownerPassword) },
      pins: { ...ownerPins, 'Dueño duplicado': storedCredential(ownerPin) }
    }),
    { ok: false, code: 'AUTH_FAILED' },
    'Una combinación que identifica más de un Dueño nunca crea una sesión.'
  );

  const question = '¿Cuál es el nombre de su primera mascota?';
  const recovery = findUserWithPasswordAndSecurityAnswer({
    password: ownerPassword, question, answer: '  Mi   Perro  ',
    roles: ownerRoles, passwords: ownerPasswords,
    questions: { [ownerName]: { question, answerHash: storedCredential('mi perro') } }
  });
  assert.deepEqual(recovery, { ok: true, user: ownerName, role: 'Dueño' }, 'Recupera el usuario sin pedirlo, solo con contraseña y respuesta correcta.');
  assert.equal(findUserWithPasswordAndSecurityAnswer({
    password: ownerPassword, question, answer: 'respuesta equivocada',
    roles: ownerRoles, passwords: ownerPasswords,
    questions: { [ownerName]: { question, answerHash: storedCredential('mi perro') } }
  }).code, 'AUTH_FAILED', 'La contraseña sola no permite recuperar el usuario.');
  assert.equal(findUserWithPasswordAndSecurityAnswer({
    password: ownerPassword, question, answer: 'mi perro',
    roles: { 'Cuenta pendiente': 'Pendiente' },
    passwords: { 'Cuenta pendiente': storedCredential(ownerPassword) },
    questions: { 'Cuenta pendiente': { question, answerHash: storedCredential('mi perro') } }
  }).code, 'AUTH_FAILED', 'La recuperación no habilita cuentas pendientes.');

  const db = new DatabaseSync(':memory:');
  try {
    const registration = await registerAccountInStore({
      db,
      username: 'Dueño Inicial',
      password: 'Clave-inicial-segura',
      phone: '55512345',
      countryCode: '+53',
      email: '',
      question,
      answer: 'Mi perro'
    });
    assert.deepEqual(registration, { ok: true, user: 'Dueño Inicial', role: 'Dueño' });
    const persisted = {};
    for (const key of ['elite_user_roles', 'elite_user_passwords', 'elite_owner_pass']) {
      const row = db.prepare('SELECT value FROM store WHERE key=?').get(key);
      persisted[key] = decodeStoredValue(row.value);
    }
    assert.equal(persisted.elite_user_roles['Dueño Inicial'], 'Dueño', 'El dueño inicial queda persistido antes de salir del asistente.');
    assert.equal(
      findPrivilegedCredential({
        user: 'Dueño Inicial',
        password: 'Clave-inicial-segura',
        roles: persisted.elite_user_roles,
        passwords: persisted.elite_user_passwords,
        requiredRole: 'Dueño'
      }).ok,
      true,
      'El propietario puede volver a iniciar sesión tras salir del asistente.'
    );
    assert.equal(
      await registerAccountInStore({
        db, username: 'dueño inicial', password: 'Otra-clave-segura',
        phone: '55512345', countryCode: '+53', email: '', question, answer: 'Mi perro'
      }).then(result => result.code),
      'USERNAME_EXISTS',
      'El nombre se reserva sin distinguir mayúsculas y no puede duplicarse con otra contraseña.'
    );
    assert.equal(
      await registerAccountInStore({
        db, username: 'Dueño Inicial', password: 'Clave-inicial-segura',
        phone: '55512345', countryCode: '+53', email: '', question, answer: 'Mi perro'
      }).then(result => result.code),
      'USERNAME_EXISTS',
      'Tampoco puede duplicarse la misma cuenta con igual usuario y contraseña.'
    );
    const concurrentRegistrations = await Promise.all([
      registerAccountInStore({
        db, username: 'Empleado Nuevo', password: 'Clave-empleado-segura',
        phone: '55512346', countryCode: '+53', email: '', question, answer: 'Otra respuesta'
      }),
      registerAccountInStore({
        db, username: ' empleado   nuevo ', password: 'Otra-clave-empleado',
        phone: '55512347', countryCode: '+53', email: '', question, answer: 'Respuesta distinta'
      })
    ]);
    assert.equal(concurrentRegistrations.filter(result => result.ok).length, 1, 'Dos altas simultáneas del mismo usuario no pueden confirmarse ambas.');
    assert.equal(concurrentRegistrations.filter(result => result.code === 'USERNAME_EXISTS').length, 1, 'La segunda alta concurrente se rechaza al revalidar dentro de la transacción.');
    const employeeRoles = decodeStoredValue(db.prepare("SELECT value FROM store WHERE key='elite_user_roles'").get().value);
    const employeeKeys = Object.keys(employeeRoles).filter(key => key.normalize('NFKC').trim().toLowerCase().replace(/\s+/g, ' ') === 'empleado nuevo');
    assert.equal(employeeKeys.length, 1, 'El usuario nuevo existe una sola vez aunque se intenten alias de escritura.');
    assert.equal(employeeRoles[employeeKeys[0]], 'Pendiente', 'El usuario nuevo sigue sujeto a aprobación del Dueño.');
  } finally {
    db.close();
  }

  console.log('Password hardening: PBKDF2, PIN, recuperación y registro único de cuentas verificados.');
}

main().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
