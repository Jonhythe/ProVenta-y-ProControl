'use strict';

/**
 * ProControl x64 folder release creator.
 * - Builds electron-builder target `dir` only (never NSIS/portable/zip).
 * - Copies the build into a new delivery directory.
 * - Compares source build and copied payload byte-for-byte by SHA-256.
 * - Creates MANIFEST.json from the final copied payload, not from an earlier tree.
 * - Creates ZIP and verifies every archived payload file against that manifest.
 * - Rechecks build and delivery folders after ZIP creation to detect late mutations.
 *
 * Run from app root:
 *   node tools/build-folder-distribution.js
 */

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');

const PROJECT_ROOT = path.resolve(__dirname, '..');
const DELIVERY_ROOT = path.resolve(PROJECT_ROOT, '..');
const REQUIRED_BUILDER_VERSION = '26.18.1';
const PRODUCT_EXE = 'ProControl.exe';

function stamp() {
  const d = new Date();
  const p = (v, n = 2) => String(v).padStart(n, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}${p(d.getMilliseconds(), 3)}`;
}

function quoteForError(value) {
  return String(value).replace(/[\r\n]/g, ' ');
}

async function sha256File(file) {
  const before = fs.statSync(file);
  if (!before.isFile()) throw new Error(`No es un archivo normal: ${file}`);
  const hash = crypto.createHash('sha256');
  await new Promise((resolve, reject) => {
    const input = fs.createReadStream(file);
    input.on('error', reject);
    input.on('data', chunk => hash.update(chunk));
    input.on('end', resolve);
  });
  const after = fs.statSync(file);
  if (before.size !== after.size || before.mtimeMs !== after.mtimeMs) {
    throw new Error(`El archivo cambió mientras se calculaba su SHA-256: ${file}`);
  }
  return { sizeBytes: after.size, sha256: hash.digest('hex').toUpperCase() };
}

function findPackageVersion(packageName) {
  let entry;
  try {
    entry = require.resolve(packageName);
  } catch (error) {
    throw new Error(`No se pudo resolver ${packageName}: ${error.message}`);
  }
  let dir = path.dirname(entry);
  while (true) {
    const candidate = path.join(dir, 'package.json');
    if (fs.existsSync(candidate)) {
      try {
        const metadata = JSON.parse(fs.readFileSync(candidate, 'utf8'));
        if (metadata.name === packageName) return metadata.version;
      } catch (_) {
        // Continue to parent package directory.
      }
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  throw new Error(`No se encontró package.json para ${packageName}.`);
}

function listFiles(root, current = root, result = []) {
  for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
    const full = path.join(current, entry.name);
    if (entry.isSymbolicLink()) {
      throw new Error(`Se rechazó un enlace simbólico dentro de la entrega: ${full}`);
    }
    if (entry.isDirectory()) listFiles(root, full, result);
    else if (entry.isFile()) result.push(full);
    else throw new Error(`Elemento no compatible en la entrega: ${full}`);
  }
  return result;
}

function relativeName(root, file) {
  return path.relative(root, file).split(path.sep).join('/');
}

async function waitForStableFile(file, options = {}) {
  const intervalMs = Number.isInteger(options.intervalMs) ? options.intervalMs : 1200;
  const requiredStableRounds = Number.isInteger(options.stableRounds) ? options.stableRounds : 3;
  const timeoutMs = Number.isInteger(options.timeoutMs) ? options.timeoutMs : 30000;
  const startedAt = Date.now();
  let previous = null;
  let stableRounds = 0;
  let lastError = null;

  while (Date.now() - startedAt <= timeoutMs) {
    try {
      const info = await sha256File(file);
      const stat = fs.statSync(file);
      const fingerprint = `${info.sizeBytes}:${info.sha256}:${stat.mtimeMs}`;
      if (fingerprint === previous) stableRounds += 1;
      else stableRounds = 1;
      previous = fingerprint;
      lastError = null;
      if (stableRounds >= requiredStableRounds) return info;
    } catch (error) {
      // The executable may still be receiving Windows PE resources (icon/version).
      // Retry only during this bounded stabilization window.
      lastError = error;
      previous = null;
      stableRounds = 0;
    }
    await new Promise(resolve => setTimeout(resolve, intervalMs));
  }

  const detail = lastError ? ` Último error: ${lastError.message}` : '';
  throw new Error(`ProControl.exe no alcanzó un estado estable tras ${timeoutMs} ms.${detail}`);
}

async function snapshotTree(root) {
  if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) {
    throw new Error(`No existe la carpeta que se debe verificar: ${root}`);
  }
  const files = listFiles(root).map(file => ({ file, path: relativeName(root, file) }));
  files.sort((a, b) => a.path.toLowerCase().localeCompare(b.path.toLowerCase()));
  const snapshot = [];
  for (const item of files) {
    const info = await sha256File(item.file);
    snapshot.push({ path: item.path, sizeBytes: info.sizeBytes, sha256: info.sha256 });
  }
  return snapshot;
}

function compareSnapshots(expected, actual, label) {
  if (expected.length !== actual.length) {
    throw new Error(`${label}: cantidad de archivos distinta (${expected.length} frente a ${actual.length}).`);
  }
  const actualByPath = new Map(actual.map(item => [item.path.toLowerCase(), item]));
  for (const item of expected) {
    const found = actualByPath.get(item.path.toLowerCase());
    if (!found) throw new Error(`${label}: falta ${item.path}.`);
    if (found.sizeBytes !== item.sizeBytes || found.sha256 !== item.sha256) {
      throw new Error(
        `${label}: cambió ${item.path}. ` +
        `Origen=${item.sizeBytes} bytes/${item.sha256}; ` +
        `copia=${found.sizeBytes} bytes/${found.sha256}.`
      );
    }
  }
}

function psExecutable() {
  const candidate = process.env.SystemRoot
    ? path.join(process.env.SystemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
    : 'powershell.exe';
  return candidate;
}

function invokePowerShell(scriptPath, args, label) {
  if (!fs.existsSync(scriptPath)) throw new Error(`Falta el auxiliar PowerShell: ${scriptPath}`);
  const result = spawnSync(psExecutable(), [
    '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
    '-File', scriptPath,
    ...args,
  ], {
    cwd: PROJECT_ROOT,
    encoding: 'utf8',
    windowsHide: true,
    maxBuffer: 20 * 1024 * 1024,
  });
  if (result.stdout) process.stdout.write(result.stdout);
  if (result.stderr) process.stderr.write(result.stderr);
  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error(`${label} falló (PowerShell exit ${result.status}). ${quoteForError(result.stderr || result.stdout || '')}`);
  }
}

function runStaticTests() {
  const staticTest = path.join(__dirname, 'test-folder-distribution.js');
  const result = spawnSync(process.execPath, [staticTest], {
    cwd: PROJECT_ROOT,
    encoding: 'utf8',
    windowsHide: true,
    maxBuffer: 10 * 1024 * 1024,
  });
  if (result.stdout) process.stdout.write(result.stdout);
  if (result.stderr) process.stderr.write(result.stderr);
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error('Las pruebas estáticas de distribución por carpeta fallaron.');
}

async function main() {
  if (process.platform !== 'win32') {
    throw new Error('Esta compilación debe ejecutarse en Windows x64.');
  }
  if (process.arch !== 'x64') {
    throw new Error(`Se requiere Node.js x64; arquitectura actual: ${process.arch}.`);
  }

  const packagePath = path.join(PROJECT_ROOT, 'package.json');
  const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
  if (pkg.name !== 'procontrol-desktop' || !/^\d+\.\d+\.\d+$/.test(String(pkg.version || ''))) {
    throw new Error('package.json no identifica una versión estable de ProControl Desktop.');
  }

  const declaredBuilder = pkg.devDependencies && pkg.devDependencies['electron-builder'];
  const actualBuilder = findPackageVersion('electron-builder');
  const actualAppBuilder = findPackageVersion('app-builder-lib');
  if (declaredBuilder !== REQUIRED_BUILDER_VERSION || actualBuilder !== REQUIRED_BUILDER_VERSION || actualAppBuilder !== REQUIRED_BUILDER_VERSION) {
    throw new Error(
      `Toolchain no aprobada. Se requiere electron-builder y app-builder-lib ${REQUIRED_BUILDER_VERSION}; ` +
      `package.json=${declaredBuilder || 'ausente'}, instalado electron-builder=${actualBuilder}, app-builder-lib=${actualAppBuilder}.`
    );
  }

  const requiredTools = [
    'check-no-secrets.js',
    'Crear-Distribucion-Carpeta.bat',
    'Actualizar-ProControl.ps1',
    'Actualizar-ProControl.bat',
    'create-folder-zip.ps1',
    'verify-folder-zip.ps1',
    'test-folder-distribution.js',
  ];
  for (const name of requiredTools) {
    if (!fs.existsSync(path.join(__dirname, name))) throw new Error(`Falta tools/${name}.`);
  }

  runStaticTests();

  const buildId = stamp();
  const buildDirName = `dist_folder_${buildId}`;
  const buildDir = path.join(PROJECT_ROOT, buildDirName);
  const deliveryName = `Entrega_Carpeta_ProControl_${pkg.version}_${buildId}`;
  const deliveryDir = path.join(DELIVERY_ROOT, deliveryName);
  const payloadDir = path.join(deliveryDir, 'ProControl');
  const zipPath = path.join(DELIVERY_ROOT, `${deliveryName}.zip`);
  const zipPartial = `${zipPath}.partial`;
  const zipHashPath = `${zipPath}.sha256`;

  for (const candidate of [buildDir, deliveryDir, zipPath, zipPartial, zipHashPath]) {
    if (fs.existsSync(candidate)) throw new Error(`La ruta ya existe; no se sobrescribirá: ${candidate}`);
  }

  const electronBuilder = require('electron-builder');
  const { build, Platform, Arch } = electronBuilder;
  if (typeof build !== 'function' || !Platform || !Arch) {
    throw new Error('No se pudo cargar la API de electron-builder.');
  }

  const originalBuild = pkg.build || {};
  const config = {
    ...originalBuild,
    directories: { ...(originalBuild.directories || {}), output: buildDirName },
    win: {
      ...(originalBuild.win || {}),
      target: [{ target: 'dir', arch: ['x64'] }],
      signExecutable: false,
      signAndEditExecutable: true,
    },
  };

  console.log('PROCONTROL — CREADOR DE DISTRIBUCIÓN POR CARPETA');
  console.log(`Versión: ${pkg.version}`);
  console.log(`electron-builder: ${actualBuilder}`);
  console.log(`app-builder-lib: ${actualAppBuilder}`);
  console.log('Objetivo: Windows x64 / dir. No se generará instalador NSIS.');
  console.log(`Carpeta de compilación: ${buildDir}`);

  await build({
    projectDir: PROJECT_ROOT,
    targets: Platform.WINDOWS.createTarget(['dir'], Arch.x64),
    config,
  });

  const appOutDir = path.join(buildDir, 'win-unpacked');
  const appExe = path.join(appOutDir, PRODUCT_EXE);
  const appAsar = path.join(appOutDir, 'resources', 'app.asar');
  if (!fs.existsSync(appExe) || !fs.existsSync(appAsar)) {
    throw new Error(`La compilación está incompleta: se requieren ${PRODUCT_EXE} y resources/app.asar en ${appOutDir}`);
  }

  // electron-builder edits the Windows PE resources to embed the product icon
  // and metadata. Wait until the final executable bytes stop changing before
  // capturing the manifest; otherwise a late resource edit could stale it.
  const stableExe = await waitForStableFile(appExe);
  console.log(`Ejecutable estable: ${stableExe.sizeBytes} bytes / ${stableExe.sha256}`);

  const scanner = path.join(__dirname, 'check-no-secrets.js');
  const scan = spawnSync(process.execPath, [scanner, '--require-build', '--build-dir', buildDir], {
    cwd: PROJECT_ROOT,
    encoding: 'utf8',
    windowsHide: true,
    maxBuffer: 20 * 1024 * 1024,
  });
  if (scan.stdout) process.stdout.write(scan.stdout);
  if (scan.stderr) process.stderr.write(scan.stderr);
  if (scan.error) throw scan.error;
  if (scan.status !== 0) throw new Error('El escáner de secretos no aprobó la compilación. No se creará la entrega.');

  // Capture a snapshot of the actual electron-builder output.
  const buildSnapshot = await snapshotTree(appOutDir);
  if (!buildSnapshot.some(item => item.path.toLowerCase() === PRODUCT_EXE.toLowerCase())) {
    throw new Error(`La compilación no contiene ${PRODUCT_EXE} en la raíz de win-unpacked.`);
  }
  if (!buildSnapshot.some(item => item.path.toLowerCase() === 'resources/app.asar')) {
    throw new Error('La compilación no contiene resources/app.asar.');
  }

  fs.mkdirSync(deliveryDir, { recursive: false });
  fs.cpSync(appOutDir, payloadDir, { recursive: true, errorOnExist: true, force: false });

  // Compare the copy with the build BEFORE producing the manifest.
  const copiedSnapshot = await snapshotTree(payloadDir);
  compareSnapshots(buildSnapshot, copiedSnapshot, 'Copia build -> entrega');

  fs.copyFileSync(path.join(__dirname, 'Actualizar-ProControl.ps1'), path.join(deliveryDir, 'Actualizar-ProControl.ps1'));
  fs.copyFileSync(path.join(__dirname, 'Actualizar-ProControl.bat'), path.join(deliveryDir, 'Actualizar-ProControl.bat'));
  fs.writeFileSync(path.join(deliveryDir, 'LEEME-ENTREGA.txt'), [
    'PROCONTROL — DISTRIBUCIÓN POR CARPETA',
    `Versión: ${pkg.version}`,
    'Arquitectura: Windows x64',
    '',
    'PRIMERA PRUEBA:',
    '1. Extrae el ZIP completo en una carpeta temporal.',
    '2. Ejecuta Actualizar-ProControl.bat.',
    '3. Selecciona una carpeta NUEVA y vacía, por ejemplo D:\\ProControl-Carpeta-Prueba.',
    '4. Abre ProControl.exe desde esa carpeta y comprueba el inicio y la licencia.',
    '',
    'ACTUALIZACIONES:',
    'Usa el BAT incluido en cada nueva entrega y selecciona la carpeta de esta distribución.',
    'El actualizador respalda %APPDATA%\\ProControl y conserva la versión anterior para poder volver atrás.',
    'No sustituye instalaciones antiguas de NSIS.',
    '',
    'DATOS:',
    'La base de datos, la licencia y la configuración del usuario permanecen en %APPDATA%\\ProControl.',
    'El paquete solo contiene archivos del programa.',
    '',
    'No copies licensor/private ni claves privadas dentro de esta entrega.',
    '',
  ].join('\r\n'), 'utf8');

  // Manifest is generated from the FINAL copied payload and its control files.
  const manifestFiles = await snapshotTree(payloadDir);
  compareSnapshots(buildSnapshot, manifestFiles, 'Verificación previa al manifiesto');
  const releaseFileNames = ['Actualizar-ProControl.ps1', 'Actualizar-ProControl.bat', 'LEEME-ENTREGA.txt'];
  const releaseFiles = [];
  for (const name of releaseFileNames) {
    const filePath = path.join(deliveryDir, name);
    const info = await sha256File(filePath);
    releaseFiles.push({ path: name, sizeBytes: info.sizeBytes, sha256: info.sha256 });
  }
  const manifest = {
    schemaVersion: 2,
    product: 'ProControl',
    version: String(pkg.version),
    architecture: 'x64',
    target: 'electron-builder-dir',
    createdAt: new Date().toISOString(),
    payloadFolder: 'ProControl',
    fileCount: manifestFiles.length,
    files: manifestFiles,
    releaseFiles,
    dataLocation: '%APPDATA%\\ProControl',
    integrity: 'SHA-256 por archivo; comprobación posterior del ZIP completo.',
    note: 'El manifiesto describe exactamente el contenido final de ProControl/. No incluye datos personales, licencias de clientes ni claves privadas del emisor.',
  };
  fs.writeFileSync(path.join(deliveryDir, 'MANIFEST.json'), `${JSON.stringify(manifest, null, 2)}\r\n`, 'utf8');

  const verifyFolder = path.join(__dirname, 'verify-folder-zip.ps1');
  const createZipScript = path.join(__dirname, 'create-folder-zip.ps1');
  invokePowerShell(createZipScript, ['-SourceDirectory', deliveryDir, '-ZipPath', zipPartial], 'Creación del ZIP');
  invokePowerShell(verifyFolder, ['-ZipPath', zipPartial, '-DeliveryRoot', deliveryDir], 'Verificación interna del ZIP');

  // Re-hash both the build and the final payload after the archive has been made.
  const buildAfterZip = await snapshotTree(appOutDir);
  const payloadAfterZip = await snapshotTree(payloadDir);
  compareSnapshots(manifestFiles, buildAfterZip, 'Compilación después de crear el ZIP');
  compareSnapshots(manifestFiles, payloadAfterZip, 'Carpeta de entrega después de crear el ZIP');

  // The temporary archive becomes the official ZIP only after every check passes.
  fs.renameSync(zipPartial, zipPath);
  const zipInfo = await sha256File(zipPath);
  fs.writeFileSync(zipHashPath, `${zipInfo.sha256}  ${path.basename(zipPath)}\r\n`, 'utf8');

  const exeRecord = manifestFiles.find(item => item.path.toLowerCase() === PRODUCT_EXE.toLowerCase());
  console.log('\nDISTRIBUCIÓN POR CARPETA CREADA Y VERIFICADA:');
  console.log(`Carpeta de entrega: ${deliveryDir}`);
  console.log(`ZIP: ${zipPath}`);
  console.log(`SHA-256 ZIP: ${zipInfo.sha256}`);
  console.log(`ProControl.exe: ${exeRecord.sizeBytes} bytes / ${exeRecord.sha256}`);
  console.log(`Archivos del programa verificados: ${manifestFiles.length}`);
  console.log('Build, copia, manifiesto y contenido del ZIP coinciden.');
  console.log('La instalación existente y %APPDATA%\\ProControl no fueron modificados.');
}

main().catch(error => {
  console.error('\nERROR EN EL CREADOR DE DISTRIBUCIÓN:');
  console.error(error && error.stack ? error.stack : error);
  console.error('No se modificó la instalación de ProControl ni su carpeta de datos.');
  process.exitCode = 1;
});
