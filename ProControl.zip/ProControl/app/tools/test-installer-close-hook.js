'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const script = fs.readFileSync(path.join(root, 'build', 'installer.nsh'), 'utf8');
const buildScript = fs.readFileSync(path.join(root, 'tools', 'build-clean-nsis.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

assert(script.includes('!macro customCheckAppRunning'), 'debe usar el hook de comprobacion de proceso reconocido por electron-builder');
assert(!/CRCCheck\s+off/i.test(script), 'no debe desactivar CRC de NSIS');
assert(script.includes('${nsProcess::FindProcess} "${APP_EXECUTABLE_FILENAME}"'), 'debe detectar el ejecutable exacto configurado por electron-builder');
assert(script.includes('/IM "${APP_EXECUTABLE_FILENAME}"'), 'taskkill debe apuntar solo al ejecutable de ProControl');
assert(script.includes('MB_OKCANCEL') && script.includes('MB_RETRYCANCEL'), 'debe pedir consentimiento y permitir reintentar');
assert(!/taskkill[^\r\n]*\*|taskkill[^\r\n]*node\.exe|taskkill[^\r\n]*Code\.exe|taskkill[^\r\n]*chrome\.exe/i.test(script), 'no debe cerrar procesos ajenos');
assert(!/!ifndef\s+BUILD_UNINSTALLER[\s\S]*?!macro\s+customCheckAppRunning/i.test(script), 'el hook debe estar disponible tambien al compilar el desinstalador');
assert(!/!macro\s+customUnInit/i.test(script), 'no debe matar procesos a ciegas desde customUnInit');
assert(pkg.build?.nsis?.include === 'build/installer.nsh', 'electron-builder debe incluir build/installer.nsh');
assert(buildScript.includes("process.argv.includes('--recovery')"), 'el generador debe rechazar explicitamente la ruta de recovery antigua');
assert(buildScript.includes('build/installer.nsh') && !buildScript.includes('installer-recovery.nsh'), 'el build oficial solo debe usar el include mantenido');
assert(!/nsisConfig\.include\s*=\s*\[/.test(buildScript), 'nsis.include nunca debe configurarse como arreglo');
assert.equal(fs.existsSync(path.join(root, 'build', 'installer-recovery.nsh')), false, 'el include de recuperación antiguo no debe formar parte del repositorio de compilación');
assert(pkg.scripts?.['check-source']?.includes('tools/test-installer-close-hook.js'), 'check-source debe ejecutar esta prueba');

console.log('PASS - el hook limita la deteccion y cierre al ejecutable de ProControl');
console.log('PASS - CRC de NSIS permanece activado');
console.log('PASS - pide consentimiento y permite reintentar');
console.log('PASS - no finaliza Chrome, Code ni node.exe');
console.log('PASS - compilacion oficial usa solo installer.nsh');
console.log('PASS - la ruta de recovery antigua queda deshabilitada');
console.log('Installer close hook: 13 comprobaciones aprobadas.');
