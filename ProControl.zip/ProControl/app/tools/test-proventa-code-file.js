
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { writeProVentaAuthorizationFile, writeProVentaAuthorizationFileAtPath } = require('../electron/mobile-bridge/proventa-code-file');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'proventa-code-file-'));
try {
  const code = 'PVLA2:' + 'A'.repeat(128);
  const first = writeProVentaAuthorizationFile(code, root);
  assert.equal(first.fileName, 'ProVenta Codigo.pvla2');
  assert.equal(fs.readFileSync(first.filePath, 'utf8').trim(), code);
  assert.equal(first.directory, root);

  const second = writeProVentaAuthorizationFile(code, root);
  assert.equal(second.fileName, 'ProVenta Codigo (2).pvla2');
  assert.notEqual(second.filePath, first.filePath);
  assert.equal(fs.readFileSync(second.filePath, 'utf8').trim(), code);

  assert.throws(() => writeProVentaAuthorizationFile('NO-ES-UNA-AUTORIZACION', root), { code: 'INVALID_ACTIVATION_CODE' });

  const chosenPath = path.join(root, 'USB', 'Autorizacion dependiente.pvla2');
  const exported = writeProVentaAuthorizationFileAtPath(code, chosenPath);
  assert.equal(exported.fileName, 'Autorizacion dependiente.pvla2');
  assert.equal(exported.filePath, chosenPath);
  assert.equal(fs.readFileSync(chosenPath, 'utf8').trim(), code);
  assert.throws(() => writeProVentaAuthorizationFileAtPath(code, 'relative.pvla2'), { code: 'EXPORT_DESTINATION_INVALID' });
  console.log('ProVenta authorization file export: 11 assertions passed.');
} finally {
  fs.rmSync(root, { recursive: true, force: true });
}
