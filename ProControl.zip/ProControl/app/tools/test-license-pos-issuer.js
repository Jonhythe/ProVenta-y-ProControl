'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const path = require('node:path');
const { signPointLicense, issuePointLicense } = require(path.resolve(__dirname, '..', '..', 'licensor', 'emitir-licencia-pos.js'));
const { verifyLicense } = require('../electron/license-core');
const keys = crypto.generateKeyPairSync('ed25519');
const deviceId = 'ABCDEF0123456789ABCDEF0123456789';
let count = 0;
function check(value, message) { count++; assert.ok(value, message); }
const issued = issuePointLicense({
  deviceId, posId: 'pos_tienda_01', posName: 'Tienda principal', customer: 'Cliente prueba',
  now: new Date('2026-01-01T00:00:00.000Z'), privateKey: keys.privateKey
});
const verified = verifyLicense(issued.token, { publicKey: keys.publicKey, deviceId, now: new Date('2026-02-01T00:00:00Z'), expectedType: 'point-of-sale' });
check(verified.ok, 'el emisor genera una licencia POS verificable por Ed25519');
check(verified.payload.posId === 'pos_tienda_01' && verified.payload.posName === 'Tienda principal' && verified.payload.installationMachineId === deviceId, 'la licencia registra ID/nombre del POS y el equipo de instalación');
check(!verifyLicense(issued.token, { publicKey: keys.publicKey, deviceId, expectedType: 'installation' }).ok, 'una licencia POS no se puede usar como licencia de instalación');
check(!verifyLicense(issued.token, { publicKey: keys.publicKey, deviceId: 'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF', expectedType: 'point-of-sale' }).ok, 'la licencia POS está ligada a la PC emisora indicada');
const trial = issuePointLicense({ deviceId, posId: 'pos_tienda_01', posName: 'Tienda principal', customer: 'Cliente prueba', days: 2, now: new Date('2026-01-01T00:00:00.000Z'), privateKey: keys.privateKey });
check(trial.payload.expiresAt === '2026-01-03T00:00:00.000Z', 'la licencia temporal tiene vencimiento exacto');
check(!verifyLicense(trial.token, { publicKey: keys.publicKey, deviceId, now: new Date('2026-01-04T00:00:00Z'), expectedType: 'point-of-sale' }).ok, 'una licencia POS temporal vencida se rechaza');
assert.throws(() => issuePointLicense({ deviceId, posId: 'mal id', posName: 'Nombre', customer: 'Cliente', privateKey: keys.privateKey }), /ID del punto/);
assert.throws(() => signPointLicense({ v: 1, app: 'procontrol', licenseType: 'installation', deviceId, plan: 'permanent' }, keys.privateKey), /INVALID_POS_LICENSE_PAYLOAD/);
console.log(`POS license issuer tests: ${count + 2} assertions passed.`);
