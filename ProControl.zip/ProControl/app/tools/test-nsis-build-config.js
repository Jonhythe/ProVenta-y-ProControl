#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const buildScript = fs.readFileSync(path.join(__dirname, 'build-clean-nsis.js'), 'utf8');
const nsisInclude = fs.readFileSync(path.join(root, 'build', 'installer.nsh'), 'utf8');
const main = fs.readFileSync(path.join(root, 'electron', 'main.js'), 'utf8');

assert(['26.15.3', '26.18.1'].includes(pkg.devDependencies['electron-builder']), 'package.json debe estar en la version original antes del upgrade o en 26.18.1 despues del upgrade.');
assert.equal(pkg.devDependencies.electron, '39.8.10');
assert.equal(pkg.build.win.signExecutable, false);
assert.equal(pkg.build.win.signAndEditExecutable, true);
assert.deepEqual(pkg.build.win.target, [{ target: 'nsis', arch: ['x64'] }]);
assert.equal(pkg.build.nsis.include, 'build/installer.nsh');
assert(pkg.build.files.includes('!electron/**/*.bak'), 'Los respaldos fuente no deben incluirse en app.asar.');
assert.equal(pkg.build.win.icon, 'assets/icono.ico');
assert.equal(pkg.build.nsis.installerIcon, 'assets/icono.ico');
assert.equal(pkg.build.nsis.uninstallerIcon, 'assets/icono.ico');
assert(fs.existsSync(path.join(root, 'assets', 'icono.ico')), 'El icono oficial ICO debe estar incluido en la aplicación.');
assert(fs.existsSync(path.join(root, 'assets', 'icono.png')), 'El icono PNG oficial debe permanecer disponible.');
assert(main.includes("const externalIcon = path.join(process.resourcesPath, 'app.asar.unpacked', 'assets', 'icono.ico')") &&
  main.includes('icon: appIconPath'),
  'La ventana de ProControl debe seleccionar el ICO físico externo oficial en Windows.');
assert.equal((main.match(/const WINDOWS_APP_ID\s*=/g) || []).length, 1,
  'La identidad AppUserModelID debe declararse una sola vez.');
assert.equal((main.match(/app\.setAppUserModelId\(WINDOWS_APP_ID\)/g) || []).length, 1,
  'Windows debe recibir un único AppUserModelID estable antes de crear ventanas.');
assert(main.includes('win.setIcon(appIconPath)'),
  'La ventana debe recibir explícitamente el ICO oficial mediante BrowserWindow.setIcon.');
assert.equal((main.match(/win\.setAppDetails\(\{/g) || []).length, 1,
  'El botón de la barra de tareas debe configurarse una sola vez.');
assert(main.includes('appIconPath,') && main.includes('appId: WINDOWS_APP_ID'),
  'El botón de la barra de tareas debe usar el ICO oficial y el AUMID del producto.');
assert(Array.isArray(pkg.build.asarUnpack) && pkg.build.asarUnpack.includes('assets/icono.ico'),
  'El ICO oficial debe extraerse físicamente a app.asar.unpacked sin una copia extraResources separada.');
assert(!Array.isArray(pkg.build.extraResources) || !pkg.build.extraResources.some(resource =>
  resource.from === 'assets/icono.ico' && resource.to === 'ProControl.ico'),
  'No debe copiarse el mismo ICO por separado mediante extraResources.');
assert.equal(pkg.build.nsis.differentialPackage, false);
assert.equal(pkg.scripts.dist, 'node tools/build-clean-nsis.js');

assert(buildScript.includes("REQUIRED_BUILDER = '26.18.1'"));
assert(buildScript.includes('signAndEditExecutable: true'));
assert(buildScript.includes("Platform.WINDOWS.createTarget(['nsis'], Arch.x64)"));
assert(buildScript.includes("expectedKind: 'installer'"));
assert(buildScript.includes('assertStable'));
assert(!buildScript.includes('installer-recovery.nsh'));
assert(!/CRCCheck\s+off/i.test(nsisInclude));
assert(nsisInclude.includes('customCheckAppRunning'));
assert(nsisInclude.includes('!macro customInstall'),
  'El instalador debe tener un post-install para corregir el icono del acceso directo.');
assert(nsisInclude.includes('CreateShortCut "$newDesktopLink" "$appExe"'),
  'El post-install debe actualizar el acceso directo del escritorio existente.');
assert(nsisInclude.includes('$INSTDIR\\resources\\app.asar.unpacked\\assets\\icono.ico'),
  'El acceso directo debe apuntar directamente al ICO físico de ProControl.');
assert(nsisInclude.includes('WinShell::SetLnkAUMI "$newDesktopLink" "${APP_ID}"'),
  'El acceso directo debe conservar la identidad AUMID de ProControl.');
assert(nsisInclude.includes('Shell32::SHChangeNotify'),
  'Windows debe recibir una notificación para actualizar el icono del acceso directo.');

console.log('NSIS build configuration: 35 comprobaciones aprobadas.');
