'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const htmlPath = path.join(__dirname, '..', 'renderer', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
let passed = 0;
function check(condition, message) {
  assert.ok(condition, message);
  passed++;
  console.log(`PASS - ${message}`);
}

check(html.includes('var PCModal = {') && html.includes("_enqueue(kind, opts)"), 'existe un sistema de modales con cola para que no se pisen los avisos');
check(html.includes('confirm(opts) { return this._enqueue(\'confirm\', opts); }'), 'las confirmaciones utilizan el modal premium reutilizable');
check(html.includes("alert(opts) { return this._enqueue('alert', opts); }"), 'los avisos informativos usan la misma estética');
check(html.includes('window.alert = function(message)'), 'alert() de la aplicación se redirige al modal de ProControl');
check(html.includes('white-space: pre-wrap; overflow-wrap: anywhere;'), 'las alertas conservan párrafos y textos largos sin desbordarse');
check(html.includes("title: 'Cerrar venta sin registrar'"), 'la confirmación de cerrar una venta usa el diseño premium');
check(html.includes("title: 'Confirmar cierre de caja'"), 'la confirmación de cierre de caja usa el diseño premium');
check(html.includes("title: 'Importar respaldo'"), 'la importación de respaldos conserva una confirmación visual explícita');
check(html.includes("title: 'Última confirmación'"), 'la operación destructiva conserva su segunda confirmación');

// Garantiza que no queden llamadas a confirm() nativo, sin confundir el método PCModal.confirm.
const codeWithoutComments = html
  .replace(/<!--[\s\S]*?-->/g, '')
  .replace(/\/\*[\s\S]*?\*\//g, '')
  .replace(/^\s*\/\/.*$/gm, '');
const nativeConfirmCalls = (codeWithoutComments.match(/(?<![\w$.])confirm\s*\(/g) || []);
check(nativeConfirmCalls.length === 1 && /confirm\(opts\)\s*\{\s*return this\._enqueue/.test(codeWithoutComments), 'no quedan confirm() nativos en los flujos de negocio');
const nativePromptCalls = codeWithoutComments.match(/(?<![\w$.])prompt\s*\(/g) || [];
check(nativePromptCalls.length === 0, 'los formularios que usaban prompt() también usan el diálogo propio de la aplicación');
console.log(`Custom modal UI: ${passed} comprobaciones aprobadas.`);
