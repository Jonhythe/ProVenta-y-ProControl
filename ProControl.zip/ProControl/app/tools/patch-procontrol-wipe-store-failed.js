#!/usr/bin/env node
'use strict';

// Corrige STORE_WIPE_FAILED sin reemplazar archivos completos de ProControl.
// Crea respaldo, aplica escrituras atómicas y ejecuta pruebas SQLite reales.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');

const mainFile = path.join(root, 'electron', 'main.js');
const htmlFile = path.join(root, 'renderer', 'index.html');
const testFile = path.join(root, 'tools', 'test-authorized-store-wipe.js');
const archiveFile = path.join(root, 'electron', 'record-archive-store.js');
const helperSource = path.join(__dirname, '..', 'electron', 'security', 'authorized-store-wipe.js');
const testSource = path.join(__dirname, 'test-authorized-store-wipe.js');
const helperTarget = path.join(root, 'electron', 'security', 'authorized-store-wipe.js');

const handler = `// Borrado total explícito, reservado al Dueño y reautenticado en el proceso principal.
// La operación real está aislada y probada en security/authorized-store-wipe.js.
ipcMain.on('pc:store-wipe-owner', (event, input) => {
  if (!isAppSender(event) || !license.isLicensed()) {
    event.returnValue = { ok: false, code: 'ORIGIN_DENIED', stage: 'AUTHORIZATION' };
    return;
  }

  const credentials = input && typeof input === 'object' ? input : {};
  const requestedUser = String(credentials.user || '').trim();
  const password = typeof credentials.password === 'string' ? credentials.password : '';
  if (!requestedUser || !password) {
    event.returnValue = { ok: false, code: 'INVALID_CREDENTIALS', stage: 'AUTHENTICATION' };
    return;
  }

  let auth;
  try {
    auth = authenticatePrivilegedUser(event, { user: requestedUser, password });
  } catch (error) {
    event.returnValue = { ok: false, code: error && error.code || 'AUTH_FAILED', stage: 'AUTHENTICATION' };
    return;
  }
  if (!auth || auth.ok !== true) {
    event.returnValue = { ok: false, code: auth && auth.code || 'AUTH_FAILED', stage: 'AUTHENTICATION' };
    return;
  }
  if (auth.role !== 'Dueño' || String(auth.user || '').toLowerCase() !== requestedUser.toLowerCase()) {
    if (auth.token) privilegedSessions.delete(auth.token);
    event.returnValue = { ok: false, code: 'OWNER_REQUIRED', stage: 'AUTHENTICATION' };
    return;
  }
  if (auth.token) privilegedSessions.delete(auth.token);

  let result;
  try {
    result = wipeOperationalStoreData({
      userDataDir: USER_DATA_DIR,
      bridgeDb: mobileBridgeStore && mobileBridgeStore.db ? mobileBridgeStore.db : null,
      archiveStore: getRecordArchiveStore()
    });
  } catch (error) {
    result = {
      ok: false,
      code: error && error.code || 'STORE_WIPE_FAILED',
      stage: 'MAIN_PROCESS',
      detail: String(error && error.message || error || 'Unknown error').replace(/[\\r\\n\\t]+/g, ' ').slice(0, 240)
    };
  }

  if (!result || result.ok !== true) {
    const safeLog = {
      at: new Date().toISOString(),
      user: requestedUser,
      code: result && result.code || 'STORE_WIPE_FAILED',
      stage: result && result.stage || 'UNKNOWN',
      detail: result && result.detail || '',
      partialReset: !!(result && result.partialReset),
      rollbackWarning: result && result.rollbackWarning || null
    };
    try {
      fs.appendFileSync(path.join(USER_DATA_DIR, 'store-wipe-errors.log'), JSON.stringify(safeLog) + '\\n', { encoding: 'utf8', mode: 0o600 });
    } catch (logError) {
      console.error('[ProControl] No se pudo escribir store-wipe-errors.log:', logError && logError.message);
    }
  }

  event.returnValue = result || { ok: false, code: 'STORE_WIPE_NO_RESULT', stage: 'MAIN_PROCESS' };
});`;

function replaceBetween(source, startMarker, endRegex, replacement, label) {
  const start = source.indexOf(startMarker);
  if (start < 0) throw new Error('No se encontró el marcador inicial de ' + label + '.');
  const match = endRegex.exec(source.slice(start + startMarker.length));
  if (!match) throw new Error('No se encontró el cierre de ' + label + '.');
  const end = start + startMarker.length + match.index + match[0].length;
  return source.slice(0, start) + replacement + source.slice(end);
}

function eolOf(text) { return text.includes('\r\n') ? '\r\n' : '\n'; }
function withEol(text, eol) { return text.replace(/\r?\n/g, eol); }
function atomicWrite(file, contents) {
  const temp = file + '.wipe-fix-' + process.pid + '-' + Math.random().toString(16).slice(2) + '.tmp';
  fs.writeFileSync(temp, contents, { encoding: 'utf8', flag: 'wx', mode: 0o600 });
  try { fs.renameSync(temp, file); }
  catch (error) {
    try { if (fs.existsSync(file)) fs.unlinkSync(file); } catch (_) {}
    try { fs.renameSync(temp, file); }
    catch (second) { try { fs.unlinkSync(temp); } catch (_) {} throw second || error; }
  }
}

if (!fs.existsSync(mainFile) || !fs.existsSync(htmlFile) || !fs.existsSync(archiveFile) || !fs.existsSync(helperSource) || !fs.existsSync(testSource)) {
  throw new Error('Faltan archivos del parche o la estructura de ProControl no es la esperada. No se modificó nada.');
}

const originals = new Map();
for (const file of [mainFile, htmlFile, archiveFile, testFile, helperTarget]) {
  originals.set(file, fs.existsSync(file) ? fs.readFileSync(file) : null);
}
let nextMain = originals.get(mainFile).toString('utf8');
let nextHtml = originals.get(htmlFile).toString('utf8');
let nextArchive = originals.get(archiveFile).toString('utf8');
const nextTest = fs.readFileSync(testSource, 'utf8');
const nextHelper = fs.readFileSync(helperSource, 'utf8');
const eol = eolOf(nextMain);

// Importar módulo sin tocar el resto de main.js.
// El parche anterior pudo omitir stageClearAll porque su comprobación textual
// también encontraba el nombre dentro de un comentario de cleanupPendingWipeStages.
// Verificamos una declaración real de método, no una coincidencia de texto.
const hasStageMethod = /^\s{2}stageClearAll\s*\(/m.test(nextArchive);
if (!hasStageMethod) {
  const archiveMarker = '  inspectFiles(indexedNames) {';
  if (!nextArchive.includes(archiveMarker)) throw new Error('No se reconoce RecordArchiveStore.inspectFiles(). No se escribió ningún archivo.');
  const archiveEol = eolOf(nextArchive);
  const stageMethod = `  stageClearAll() {
    this._ensureDir();
    const stageDir = path.join(this.root, '.wipe-stage-' + crypto.randomUUID());
    fs.mkdirSync(stageDir, { recursive: false, mode: 0o700 });
    const moved = [];
    try {
      for (const entry of fs.readdirSync(this.root, { withFileTypes: true })) {
        if (!entry.isFile()) continue;
        if (!FILE_RE.test(entry.name) && !/^\\.tmp-[0-9a-f-]{36}\\.part$/i.test(entry.name)) continue;
        const source = path.join(this.root, entry.name);
        const stat = fs.lstatSync(source);
        if (!stat.isFile() || stat.isSymbolicLink()) {
          const error = new Error('ARCHIVE_WIPE_FILE_INVALID'); error.code = error.message; throw error;
        }
        fs.renameSync(source, path.join(stageDir, entry.name));
        moved.push(entry.name);
      }
    } catch (error) {
      for (const name of moved.reverse()) {
        try { fs.renameSync(path.join(stageDir, name), path.join(this.root, name)); } catch (_) {}
      }
      try { fs.rmSync(stageDir, { recursive: true, force: true }); } catch (_) {}
      throw error;
    }
    let finished = false;
    return {
      count: moved.length,
      rollback: () => {
        if (finished) return;
        for (const name of moved) {
          const staged = path.join(stageDir, name);
          if (fs.existsSync(staged)) fs.renameSync(staged, path.join(this.root, name));
        }
        fs.rmSync(stageDir, { recursive: true, force: true });
        finished = true;
      },
      commit: () => {
        if (finished) return { ok: true, deletedFiles: moved.length };
        try {
          fs.rmSync(stageDir, { recursive: true, force: false });
          finished = true;
          try { const dirFd = fs.openSync(this.root, 'r'); fs.fsyncSync(dirFd); fs.closeSync(dirFd); } catch (_) {}
          return { ok: true, deletedFiles: moved.length };
        } catch (error) {
          // Un bloqueo antivirus no debe resucitar los históricos: quedan apartados
          // y cleanupPendingWipeStages los elimina al próximo inicio.
          return { ok: false, pending: true, code: error && error.code || 'ARCHIVE_CLEANUP_PENDING', deletedFiles: moved.length };
        }
      }
    };
  }
`;
  nextArchive = nextArchive.replace(archiveMarker, withEol(stageMethod, archiveEol) + archiveMarker);
}
if (!/^\s{2}stageClearAll\s*\(/m.test(nextArchive)) throw new Error('No se pudo instalar la declaración real de stageClearAll(). No se escribió ningún archivo.');

const requireLine = "const { RecordArchiveStore } = require('./record-archive-store');";
const helperRequire = "const { wipeOperationalStoreData } = require('./security/authorized-store-wipe');";
if (!nextMain.includes(helperRequire)) {
  if (!nextMain.includes(requireLine)) throw new Error('No se reconoce el bloque de imports de main.js. No se escribió ningún archivo.');
  nextMain = nextMain.replace(requireLine, requireLine + eol + helperRequire);
}

// Sustituir únicamente el handler IPC de borrado.
const startMarker = '// Borrado total explícito, reservado al Dueño y reautenticado en el proceso principal.';
const endMarker = /\/\/ API local-first para futura aplicaci[oó]n m[oó]vil\.[^\r\n]*/;
if (!nextMain.includes('wipeOperationalStoreData({')) {
  nextMain = replaceBetween(nextMain, startMarker, endMarker, withEol(handler, eol) + eol + eol, 'handler de borrado');
}

// Mostrar al Dueño etapa y detalle real del error, sin exponer contraseña.
const oldMessage = "'No se pudo completar el borrado autorizado. No se eliminó ningún dato. Código: ' + String(wipeResult && wipeResult.code || 'STORE_WIPE_FAILED');";
const newMessage = "(wipeResult && wipeResult.partialReset === true ? 'El borrado quedó parcialmente aplicado. No cierres ni sigas usando ProControl; conserva el log de diagnóstico y contacta con soporte.' : 'No se pudo completar el borrado. La operación se revirtió y no se confirmó la eliminación de datos.') + '\\nCódigo: ' + String(wipeResult && wipeResult.code || 'STORE_WIPE_FAILED') + (wipeResult && wipeResult.stage ? '\\nEtapa: ' + String(wipeResult.stage) : '') + (wipeResult && wipeResult.detail ? '\\nDetalle: ' + String(wipeResult.detail) : '') + (wipeResult && wipeResult.rollbackWarning ? '\\nAviso de reversión: ' + String(wipeResult.rollbackWarning) : '');"
if (nextHtml.includes(oldMessage)) nextHtml = nextHtml.replace(oldMessage, newMessage);
if (!nextHtml.includes('wipeResult.stage') || !nextHtml.includes('wipeResult.detail')) {
  throw new Error('No se pudo actualizar el mensaje de error de la interfaz. No se escribió ningún archivo.');
}

// Validar que no se haya perdido la protección de autenticación.
if (!nextMain.includes(helperRequire) || !nextMain.includes("auth.role !== 'Dueño'") || !nextMain.includes('authenticatePrivilegedUser(event, { user: requestedUser, password })') || !nextMain.includes('wipeOperationalStoreData({')) {
  throw new Error('La validación previa del IPC de borrado no pasó. No se escribió ningún archivo.');
}

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const backupRoot = path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'ProControl', 'patch-backups', 'wipe-v2-' + stamp);
fs.mkdirSync(backupRoot, { recursive: true });
for (const [file, bytes] of originals.entries()) {
  if (bytes !== null) fs.writeFileSync(path.join(backupRoot, path.basename(file) + '.before'), bytes);
}

const changes = [
  [helperTarget, nextHelper],
  [mainFile, nextMain],
  [htmlFile, nextHtml],
  [archiveFile, nextArchive],
  [testFile, nextTest]
];
const committed = [];
try {
  fs.mkdirSync(path.dirname(helperTarget), { recursive: true });
  for (const [file, text] of changes) {
    atomicWrite(file, text);
    committed.push(file);
  }
} catch (error) {
  for (const file of committed.reverse()) {
    const previous = originals.get(file);
    try {
      if (previous === null) fs.unlinkSync(file);
      else fs.writeFileSync(file, previous);
    } catch (_) {}
  }
  throw error;
}

console.log('Corrección STORE_WIPE_FAILED aplicada. Copias previas: ' + backupRoot);
function run(relativePath) {
  const child = spawnSync(process.execPath, [path.join(root, relativePath)], { cwd: root, stdio: 'inherit' });
  if (child.error) throw child.error;
  if (child.status !== 0) throw new Error('Falló ' + relativePath + ' (código ' + child.status + ').');
}
if (fs.existsSync(path.join(root, 'tools', 'check-source-syntax.js'))) run('tools/check-source-syntax.js');
run('tools/test-authorized-store-wipe.js');
