'use strict';
// Migración de identidad de producto: dry-run por defecto. Aplicar exige --apply,
// una ruta --db explícita y --confirm-apply=YES. No se fusiona por nombre ambiguo.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const { plan, analyze } = require('../renderer/product-identity-migration.js');

const STORE_KEY_MAP = Object.freeze({
  inventory: 'elite_inventory',
  pointsOfSale: 'elite_pos',
  productCatalog: 'elite_product_catalog',
  transfers: 'elite_transfers',
  salesLedger: 'elite_sales_ledger'
});
const STORE_KEYS = Object.values(STORE_KEY_MAP);

function parseArgs(argv) {
  const out = { db: null, json: null, backup: null, apply: false, confirmApply: false, help: false };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--db' && argv[i + 1]) out.db = argv[++i];
    else if (arg === '--out' && argv[i + 1]) out.json = argv[++i];
    else if (arg === '--backup' && argv[i + 1]) out.backup = argv[++i];
    else if (arg === '--apply') out.apply = true;
    else if (arg === '--confirm-apply=YES') out.confirmApply = true;
    else if (arg === '--help' || arg === '-h') out.help = true;
    else throw new Error(`Argumento desconocido o incompleto: ${arg}`);
  }
  if (out.apply && !out.help && (!out.db || !out.confirmApply)) {
    throw new Error('Para aplicar: especifica --db RUTA_EXPLÍCITA --apply --confirm-apply=YES.');
  }
  if (out.confirmApply && !out.apply) throw new Error('--confirm-apply=YES solo se admite junto con --apply.');
  return out;
}
function encodeStoredValue(value) {
  const json = JSON.stringify(value);
  const encoded = Buffer.from(json, 'utf8').toString('base64');
  return Buffer.from('PROCONTROL_SECRET_2026:' + encoded, 'utf8').toString('base64');
}
function decodeStoredValue(raw) {
  if (typeof raw !== 'string' || !raw) throw new Error('STORE_VALUE_EMPTY_OR_INVALID');
  try {
    const outer = Buffer.from(raw, 'base64').toString('utf8');
    const prefix = 'PROCONTROL_SECRET_2026:';
    if (outer.startsWith(prefix)) return JSON.parse(Buffer.from(outer.slice(prefix.length), 'base64').toString('utf8'));
  } catch (_) {}
  try { return JSON.parse(raw); } catch (_) { throw new Error('STORE_VALUE_CANNOT_BE_DECODED'); }
}
function stableSerialize(value) {
  if (Array.isArray(value)) return '[' + value.map(stableSerialize).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stableSerialize(value[k])).join(',') + '}';
  return JSON.stringify(value);
}
function readAllStoreRows(db) {
  const table = db.prepare("SELECT 1 AS ok FROM sqlite_master WHERE type='table' AND name='store'").get();
  if (!table) throw new Error('La base no contiene la tabla store esperada de ProControl.');
  return db.prepare('SELECT key, value FROM store ORDER BY key').all().map(row => [String(row.key), String(row.value)]);
}
function readRelevantValues(db) {
  const rows = readAllStoreRows(db);
  const rawMap = new Map(rows);
  const result = {};
  for (const [field, key] of Object.entries(STORE_KEY_MAP)) {
    if (!rawMap.has(key)) { result[field] = []; continue; }
    const value = decodeStoredValue(rawMap.get(key));
    if (!Array.isArray(value)) throw new Error(`La clave ${key} existe, pero no contiene una lista válida. No se tocará la base.`);
    result[field] = value;
  }
  return { values: result, rows };
}
function sha256File(filePath) {
  const hash = crypto.createHash('sha256');
  hash.update(fs.readFileSync(filePath));
  return hash.digest('hex');
}
function chooseBackupPath(dbPath, explicitPath) {
  const backup = explicitPath
    ? path.resolve(explicitPath)
    : `${path.resolve(dbPath)}.product-id-backup-${new Date().toISOString().replace(/[-:.TZ]/g, '')}-${crypto.randomBytes(4).toString('hex')}.db`;
  if (path.resolve(backup) === path.resolve(dbPath)) throw new Error('El respaldo no puede sobrescribir la base original.');
  if (fs.existsSync(backup)) throw new Error(`El archivo de respaldo ya existe; no se sobrescribirá: ${backup}`);
  fs.mkdirSync(path.dirname(backup), { recursive: true });
  return backup;
}
function createAndVerifyBackup(db, backupPath, expectedRows) {
  const escaped = backupPath.replace(/'/g, "''");
  db.exec(`VACUUM INTO '${escaped}'`);
  const check = new DatabaseSync(backupPath, { readOnly: true });
  try {
    const integrity = check.prepare('PRAGMA integrity_check').get();
    if (!integrity || integrity.integrity_check !== 'ok') throw new Error('El respaldo no superó PRAGMA integrity_check.');
    const rows = readAllStoreRows(check);
    if (stableSerialize(rows) !== stableSerialize(expectedRows)) throw new Error('El contenido de store del respaldo no coincide con la línea base.');
  } finally { check.close(); }
  return { path: backupPath, sha256: sha256File(backupPath), verified: true };
}
function dataForPlanner(values) {
  return {
    inventory: values.inventory,
    pointsOfSale: values.pointsOfSale,
    productCatalog: values.productCatalog,
    transfers: values.transfers,
    salesLedger: values.salesLedger
  };
}
function buildPlan(values) {
  return plan(dataForPlanner(values), () => `product_${crypto.randomUUID().replace(/-/g, '')}`);
}
function analyzeAndMaybeApply(options) {
  const dbPath = path.resolve(options.dbPath);
  if (!fs.existsSync(dbPath)) throw new Error(`No existe la base de datos: ${dbPath}`);
  if (options.apply && options.confirmApply !== true) throw new Error('La aplicación requiere confirmación explícita.');
  const db = new DatabaseSync(dbPath, options.apply ? {} : { readOnly: true });
  let backup = null;
  try {
    db.exec('PRAGMA busy_timeout=5000');
    const { values, rows: baselineRows } = readRelevantValues(db);
    let migration;
    try {
      migration = buildPlan(values);
    } catch (error) {
      return {
        ok: false, status: 'requires-review', code: error.code || 'PRODUCT_IDENTITY_REVIEW_REQUIRED',
        message: error.message, issues: error.issues || [], report: error.report || null,
        database: dbPath, readOnly: true, applied: false, backup: null
      };
    }
    if (!options.apply) {
      return { ok: true, ...migration.report, status: 'dry-run-ready', issues: [], database: dbPath, readOnly: true, applied: false, backup: null };
    }

    const backupPath = chooseBackupPath(dbPath, options.backupPath);
    backup = createAndVerifyBackup(db, backupPath, baselineRows);
    db.exec('BEGIN IMMEDIATE');
    try {
      const currentRows = readAllStoreRows(db);
      if (stableSerialize(currentRows) !== stableSerialize(baselineRows)) {
        throw new Error('La base cambió después del análisis; no se aplicó la migración. Conserva el respaldo y vuelve a ejecutar el dry-run.');
      }
      const upsert = db.prepare('INSERT INTO store(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
      const plannedValues = {
        inventory: migration.inventory,
        pointsOfSale: migration.pointsOfSale,
        productCatalog: migration.productCatalog,
        transfers: migration.transfers,
        salesLedger: migration.salesLedger
      };
      for (const [field, key] of Object.entries(STORE_KEY_MAP)) upsert.run(key, encodeStoredValue(plannedValues[field]));
      const verify = new Map(readAllStoreRows(db));
      for (const [field, key] of Object.entries(STORE_KEY_MAP)) {
        const saved = decodeStoredValue(verify.get(key));
        if (stableSerialize(saved) !== stableSerialize(plannedValues[field])) throw new Error(`La verificación posterior a escribir ${key} no coincide con el plan.`);
      }
      const integrity = db.prepare('PRAGMA integrity_check').get();
      if (!integrity || integrity.integrity_check !== 'ok') throw new Error('La base modificada no superó PRAGMA integrity_check.');
      db.exec('COMMIT');
    } catch (error) {
      try { db.exec('ROLLBACK'); } catch (_) {}
      throw error;
    }
    return { ok: true, ...migration.report, status: 'applied', issues: [], database: dbPath, readOnly: false, applied: true, backup };
  } catch (error) {
    return { ok: false, status: 'failed', code: error.code || 'PRODUCT_IDENTITY_APPLY_FAILED', message: error.message, issues: [], database: dbPath, readOnly: !options.apply, applied: false, backup };
  } finally { db.close(); }
}
function main(argv) {
  const args = parseArgs(argv);
  if (args.help) {
    console.log('Dry-run: node tools/check-product-identity-migration.js --db COPIA.db [--out informe.json]');
    console.log('Aplicar: node tools/check-product-identity-migration.js --db COPIA_CERRADA.db --apply --confirm-apply=YES [--backup RUTA.db] [--out informe.json]');
    console.log('Usar únicamente sobre copia verificada, con ProControl cerrado. La aplicación exige respaldo validado e informe sin conflictos.');
    return 0;
  }
  if (!args.db) {
    const roaming = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
    args.db = path.join(roaming, 'ProControl', 'procontrol.db');
  }
  const result = analyzeAndMaybeApply({ dbPath: args.db, apply: args.apply, confirmApply: args.confirmApply, backupPath: args.backup });
  result.tool = 'ProControl product-identity migration';
  result.generatedAt = new Date().toISOString();
  const text = JSON.stringify(result, null, 2) + '\n';
  if (args.json) fs.writeFileSync(path.resolve(args.json), text, { encoding: 'utf8', flag: 'wx' });
  else process.stdout.write(text);
  return result.ok ? 0 : 2;
}
if (require.main === module) {
  try { process.exitCode = main(process.argv.slice(2)); }
  catch (error) { console.error(`No se pudo analizar/aplicar la migración: ${error.message}`); process.exitCode = 1; }
}
module.exports = { parseArgs, encodeStoredValue, decodeStoredValue, stableSerialize, readAllStoreRows, readRelevantValues, chooseBackupPath, createAndVerifyBackup, analyzeAndMaybeApply, main };
