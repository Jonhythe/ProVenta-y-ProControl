#!/usr/bin/env node
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const SalesReportOps = require('../renderer/sales-report.js');
const tests = [];
function test(name, fn) {
  try { fn(); tests.push({ name, ok: true }); }
  catch (error) { tests.push({ name, ok: false, error: error.message }); }
}
const salesLedger = [
  { id: 'desk-1', kind: 'sale', ts: '2026-11-07T10:00:00.000Z', posId: 'pos-1', posName: 'Principal', source: 'desktop', items: [
    { productId: 'p-apple', name: 'Manzana', baseUnit: 'u', baseQty: 5, lineTotalCUP: 500 }
  ] },
  { id: 'mobile-1', kind: 'sale', ts: '2026-11-06T10:00:00.000Z', posId: 'pos-2', posName: 'Sucursal', source: 'mobile:device-1', items: [
    { productId: 'p-apple', name: 'Manzana', baseUnit: 'u', baseQty: 2, lineTotalCUP: 1000 }
  ] },
  { id: 'return-1', kind: 'return', ts: '2026-11-08T10:00:00.000Z', posId: 'pos-1', posName: 'Principal', source: 'desktop', items: [
    { productId: 'p-apple', name: 'Manzana', baseUnit: 'u', baseQty: -1, lineTotalCUP: -100 }
  ] },
  { id: 'desk-1', kind: 'sale', ts: '2026-11-07T10:00:00.000Z', posId: 'pos-1', posName: 'Principal', items: [
    { productId: 'p-apple', name: 'Manzana', baseUnit: 'u', baseQty: 5, lineTotalCUP: 500 }
  ] },
  { id: 'old-year', kind: 'sale', ts: '2025-12-31T23:00:00.000Z', posId: 'pos-1', posName: 'Principal', items: [
    { productId: 'p-pear', name: 'Pera', baseUnit: 'kg', baseQty: 1.5, lineTotalCUP: 150 }
  ] }
];
const closingHistory = [
  { id: 'close-ticketed', ts: '2026-11-07T22:00:00.000Z', posId: 'pos-1', posName: 'Principal', salesTrackingMode: true, rotationDataVersion: 2, salesLedgerIds: ['desk-1'], products: [
    { productId: 'p-apple', name: 'Manzana', baseUnit: 'u', sold: 5, subtotal: 500 }
  ] },
  { id: 'close-ipv', date: '05/11/2026', posId: 'pos-1', posName: 'Principal', salesTrackingMode: false, products: [
    { productId: 'p-bread', name: 'Pan', baseUnit: 'u', sold: 3, subtotal: 300 }
  ] },
  { id: 'close-old', date: '2026-11-04', posName: 'Principal', products: [
    { name: 'Leche', baseUnit: 'L', sold: 2, price: 70 }
  ] }
];

test('Combina tickets del escritorio, tickets de ProVenta y devoluciones', () => {
  const report = SalesReportOps.buildMonthlyReport({ salesLedger, closingHistory, year: 2026 });
  const november = report.months.find(month => month.monthKey === '2026-11');
  const apple = november.rows.find(row => row.productId === 'p-apple');
  assert.strictEqual(apple.quantity, 6);
  assert.strictEqual(apple.revenueCUP, 1400);
});
test('Incluye cierres IPV históricos y utiliza subtotal o precio por cantidad', () => {
  const report = SalesReportOps.buildMonthlyReport({ salesLedger, closingHistory, year: 2026, posFilter: { id: 'pos-1', name: 'Principal' } });
  const november = report.months.find(month => month.monthKey === '2026-11');
  assert.strictEqual(november.rows.find(row => row.name === 'Pan').revenueCUP, 300);
  assert.strictEqual(november.rows.find(row => row.name === 'Leche').revenueCUP, 140);
});
test('No duplica el resumen de los cierres que ya tienen tickets en el ledger', () => {
  const report = SalesReportOps.buildMonthlyReport({ salesLedger, closingHistory, year: 2026, posFilter: { id: 'pos-1', name: 'Principal' } });
  const apple = report.months[0].rows.find(row => row.productId === 'p-apple');
  assert.strictEqual(apple.quantity, 4);
  assert.strictEqual(apple.revenueCUP, 400);
});
test('El consolidado global incluye todos los POS y el filtro individual aísla uno', () => {
  const global = SalesReportOps.buildMonthlyReport({ salesLedger, closingHistory, year: 2026 });
  const pos1 = SalesReportOps.buildMonthlyReport({ salesLedger, closingHistory, year: 2026, posFilter: { id: 'pos-1', name: 'Principal' } });
  assert.strictEqual(global.months[0].rows.find(row => row.productId === 'p-apple').quantity, 6);
  assert.strictEqual(pos1.months[0].rows.find(row => row.productId === 'p-apple').quantity, 4);
});
test('El filtro de año separa correctamente los registros históricos', () => {
  const report = SalesReportOps.buildMonthlyReport({ salesLedger, closingHistory, year: 2025 });
  assert.deepStrictEqual(report.months.map(month => month.monthKey), ['2025-12']);
  assert.strictEqual(report.months[0].rows[0].name, 'Pera');
});
test('Ordena por importe de forma predeterminada y permite ordenar por cantidad', () => {
  const records = [
    { id: 'a', kind: 'sale', ts: '2026-11-01T10:00:00Z', posId: 'p', posName: 'POS', items: [
      { productId: 'one', name: 'Producto A', baseUnit: 'kg', baseQty: 100, lineTotalCUP: 100 }
    ] },
    { id: 'b', kind: 'sale', ts: '2026-11-02T10:00:00Z', posId: 'p', posName: 'POS', items: [
      { productId: 'two', name: 'Producto B', baseUnit: 'u', baseQty: 2, lineTotalCUP: 500 }
    ] }
  ];
  const byRevenue = SalesReportOps.buildMonthlyReport({ salesLedger: records, year: 2026 });
  const byQuantity = SalesReportOps.buildMonthlyReport({ salesLedger: records, year: 2026, sortBy: 'quantity' });
  assert.strictEqual(byRevenue.months[0].rows[0].name, 'Producto B');
  assert.strictEqual(byQuantity.months[0].rows[0].name, 'Producto A');
});
test('Omite fechas, importes, productos y transacciones inválidas', () => {
  const report = SalesReportOps.buildMonthlyReport({ salesLedger: [
    { id: 'bad-date', ts: 'fecha', posId: 'p', items: [{ name: 'X', baseUnit: 'u', baseQty: 2, lineTotalCUP: 20 }] },
    { id: 'bad-line', ts: '2026-11-01T10:00:00Z', posId: 'p', items: [{ name: 'Y', baseUnit: 'u', baseQty: 'n/a', lineTotalCUP: 10 }] }
  ], year: 2026 });
  assert.strictEqual(report.months.length, 0);
});
test('La pestaña nueva aparece debajo de Estudio de Mercado y carga su módulo', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');
  const market = html.indexOf('data-stats-module="market_study"');
  const sold = html.indexOf('data-stats-module="sold_products"');
  assert.ok(market >= 0 && sold > market, 'El menú debe mostrar Productos Vendidos debajo de Estudio de Mercado.');
  assert.ok(html.includes("module === 'sold_products'"));
  assert.ok(html.includes('window.SoldProductsUI.render(container, appState)'));
  assert.ok(html.includes('<script src="app://sales-report.js"></script>'));
  const bridge = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'mobile-bridge-ui.js'), 'utf8');
  assert.ok(bridge.includes('window.SoldProductsUI.refresh()'));
  assert.ok(bridge.includes("result.type === 'sale_batch' || result.type === 'return'"));
});
test('La interfaz expone filtros de año, POS y criterio de orden', () => {
  const ui = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'sales-report.js'), 'utf8');
  assert.ok(ui.includes('id="sold-products-year"'));
  assert.ok(ui.includes('id="sold-products-pos"'));
  assert.ok(ui.includes('id="sold-products-sort"'));
  assert.ok(ui.includes('Consolidado Global (Todos)'));
  assert.ok(ui.includes('Mayor importe vendido'));
  assert.ok(ui.includes('Mayor cantidad vendida'));
  assert.ok(ui.includes('no son comparables entre unidades distintas'));
});

for (const result of tests) {
  console.log((result.ok ? 'PASS' : 'FAIL') + ' - ' + result.name + (result.ok ? '' : ': ' + result.error));
}
console.log(tests.filter(result => result.ok).length + '/' + tests.length + ' pruebas correctas.');
if (tests.some(result => !result.ok)) process.exit(1);
