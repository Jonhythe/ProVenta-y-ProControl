#!/usr/bin/env node
'use strict';

const assert = require('node:assert/strict');
const {
  crc32,
  findFirstHeader,
  inspectNsisBuffer,
} = require('./nsis-integrity');

function makeFixture({ headerOffset = 1024, flags = 0, payload = 'PROCONTROL-NSIS-TEST' } = {}) {
  const body = Buffer.from(payload, 'ascii');
  const totalLength = 28 + body.length + 4;
  const buffer = Buffer.alloc(headerOffset + totalLength, 0);
  buffer.writeUInt32LE(flags, headerOffset);
  buffer.writeUInt32LE(0xDEADBEEF, headerOffset + 4);
  buffer.write('NullsoftInst', headerOffset + 8, 'ascii');
  buffer.writeUInt32LE(32, headerOffset + 20);
  buffer.writeUInt32LE(totalLength, headerOffset + 24);
  body.copy(buffer, headerOffset + 28);
  const crcOffset = headerOffset + totalLength - 4;
  const crcStart = headerOffset === 0 ? 0 : 512;
  buffer.writeUInt32LE(crc32(buffer, crcStart, crcOffset), crcOffset);
  return buffer;
}

function makePackedPeWithoutVisibleNsisHeader() {
  const buffer = Buffer.alloc(1024, 0);
  buffer.write('MZ', 0, 'ascii');
  const peOffset = 0x80;
  buffer.writeUInt32LE(peOffset, 0x3C);
  buffer.write('PE\0\0', peOffset, 'binary');
  buffer.writeUInt16LE(0x8664, peOffset + 4); // AMD64
  buffer.writeUInt16LE(2, peOffset + 6); // sections
  buffer.writeUInt16LE(0xF0, peOffset + 20); // optional header size
  const sectionTable = peOffset + 24 + 0xF0;
  buffer.write('UPX0', sectionTable, 'ascii');
  buffer.write('UPX1', sectionTable + 40, 'ascii');
  return buffer;
}

const installer = makeFixture();
assert.equal(findFirstHeader(installer), 1024);
const inspectedInstaller = inspectNsisBuffer(installer, { expectedKind: 'installer' });
assert.equal(inspectedInstaller.status, 'VALID');
assert.equal(inspectedInstaller.kind, 'installer');
assert.equal(inspectedInstaller.crcEnabled, true);

const zeroOffset = makeFixture({ headerOffset: 0 });
assert.equal(inspectNsisBuffer(zeroOffset, { expectedKind: 'installer' }).status, 'VALID');

const changedPayload = Buffer.from(installer);
changedPayload[1024 + 29] ^= 0x10;
assert.equal(inspectNsisBuffer(changedPayload, { expectedKind: 'installer' }).status, 'INVALID');

const noCrc = makeFixture({ flags: 0x4 });
assert.equal(inspectNsisBuffer(noCrc, { expectedKind: 'installer' }).status, 'INVALID');
assert.match(inspectNsisBuffer(noCrc).reason, /desactiva CRC/);

const forcedCrc = makeFixture({ flags: 0xC });
assert.equal(inspectNsisBuffer(forcedCrc, { expectedKind: 'installer' }).status, 'VALID');

const wrongKind = makeFixture({ flags: 0x1 });
assert.equal(inspectNsisBuffer(wrongKind, { expectedKind: 'installer' }).status, 'INVALID');

const badLength = Buffer.from(installer);
badLength.writeUInt32LE(0xFFFFFFFF, 1024 + 24);
assert.equal(inspectNsisBuffer(badLength, { expectedKind: 'installer' }).status, 'INVALID');

const packed = makePackedPeWithoutVisibleNsisHeader();
const packedResult = inspectNsisBuffer(packed, { expectedKind: 'installer' });
assert.equal(packedResult.status, 'INDETERMINATE');
assert.equal(packedResult.pe.hasUpxSections, true);
assert.match(packedResult.reason, /UPX/);

const nonNsis = Buffer.alloc(4096, 0x41);
assert.equal(inspectNsisBuffer(nonNsis).status, 'INDETERMINATE');

console.log('NSIS integrity: 9 pruebas aprobadas (CRC, flags, tipo, longitudes y PE/UPX indeterminado).');
