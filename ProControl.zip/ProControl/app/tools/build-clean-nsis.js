#!/usr/bin/env node
'use strict';

/**
 * Genera SOLO el Setup NSIS x64 en una carpeta nueva.
 * Requiere electron-builder/app-builder-lib 26.18.1 exactos.
 * No reutiliza dist_final, no usa el include de recuperacion y no desactiva CRC.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const os = require('node:os');
const { spawnSync } = require('node:child_process');

const ROOT = path.resolve(__dirname, '..');
const REQUIRED_BUILDER = '26.18.1';

function stamp() {
  const d = new Date();
  const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}${p(d.getMilliseconds(), 3)}`;
}

function readPackageVersion(name) {
  const entry = require.resolve(name, { paths: [ROOT] });
  let dir = path.dirname(entry);
  while (true) {
    const manifest = path.join(dir, 'package.json');
    if (fs.existsSync(manifest)) {
      const parsed = JSON.parse(fs.readFileSync(manifest, 'utf8'));
      if (parsed.name === name) return { version: parsed.version, path: manifest };
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  throw new Error(`No se pudo resolver package.json de ${name}.`);
}

function sha256File(filePath) {
  const hash = crypto.createHash('sha256');
  const stream = fs.createReadStream(filePath);
  return new Promise((resolve, reject) => {
    stream.on('error', reject);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex').toUpperCase()));
  });
}

async function assertPe(filePath) {
  const handle = await fs.promises.open(filePath, 'r');
  try {
    const dos = Buffer.alloc(64);
    const dosRead = await handle.read(dos, 0, dos.length, 0);
    if (dosRead.bytesRead !== 64 || dos.toString('ascii', 0, 2) !== 'MZ') {
      throw new Error('El Setup no tiene una cabecera MZ completa.');
    }
    const peOffset = dos.readUInt32LE(0x3C);
    if (peOffset < 64 || peOffset > 16 * 1024 * 1024) {
      throw new Error('Desplazamiento PE del Setup no valido.');
    }
    const pe = Buffer.alloc(4);
    const peRead = await handle.read(pe, 0, 4, peOffset);
    if (peRead.bytesRead !== 4 || pe.toString('binary') !== 'PE\0\0') {
      throw new Error('La firma PE del Setup no es valida.');
    }
  } finally {
    await handle.close();
  }
}

async function assertStable(filePath) {
  const firstStat = await fs.promises.stat(filePath);
  const firstHash = await sha256File(filePath);
  await new Promise(resolve => setTimeout(resolve, 1500));
  const secondStat = await fs.promises.stat(filePath);
  const secondHash = await sha256File(filePath);
  if (firstStat.size !== secondStat.size || firstHash !== secondHash) {
    throw new Error('El Setup cambio mientras se verificaba. No se crea manifiesto ni se autoriza distribuirlo.');
  }
  return { sizeBytes: secondStat.size, sha256: secondHash };
}

function assertToolchain(pkg) {
  if (process.platform !== 'win32') {
    throw new Error('La compilacion de ProControl debe ejecutarse en Windows, no mediante cross-build.');
  }
  if (process.arch !== 'x64') {
    throw new Error(`Se esperaba Node x64; arquitectura actual: ${process.arch}.`);
  }
  const declared = pkg.devDependencies && pkg.devDependencies['electron-builder'];
  const builder = readPackageVersion('electron-builder').version;
  const appBuilderLib = readPackageVersion('app-builder-lib').version;
  const builderUtil = readPackageVersion('builder-util').version;
  const runtime = readPackageVersion('builder-util-runtime').version;
  const dmgBuilder = readPackageVersion('dmg-builder').version;
  const expected = {
    'package.json electron-builder': declared,
    'electron-builder instalado': builder,
    'app-builder-lib': appBuilderLib,
    'builder-util': builderUtil,
    'builder-util-runtime': runtime,
    'dmg-builder': dmgBuilder,
  };
  const required = {
    'package.json electron-builder': REQUIRED_BUILDER,
    'electron-builder instalado': REQUIRED_BUILDER,
    'app-builder-lib': REQUIRED_BUILDER,
    'builder-util': REQUIRED_BUILDER,
    'builder-util-runtime': '9.7.1',
    'dmg-builder': REQUIRED_BUILDER,
  };
  for (const [name, version] of Object.entries(required)) {
    if (expected[name] !== version) {
      throw new Error(`Toolchain inconsistente: ${name}=${expected[name] || '(ausente)'}; se requiere ${version}. Ejecuta tools/upgrade-nsis-toolchain.ps1.`);
    }
  }
  return expected;
}


async function prepareAndCheckRuntimeApp(pkg) {
  const appDir = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'procontrol-runtime-'));
  const cleanup = () => {
    try { fs.rmSync(appDir, { recursive: true, force: true }); }
    catch (error) {
      console.error(`No se pudo limpiar el runtime temporal ${appDir}: ${error.message}`);
      process.exitCode = 1;
    }
  };
  process.once('exit', cleanup);
  try {
    for (const folder of ['electron', 'renderer', 'assets']) {
      const source = path.join(ROOT, folder);
      if (!fs.existsSync(source) || !fs.statSync(source).isDirectory()) {
        throw new Error(`Falta la carpeta fuente necesaria para preparar el runtime: ${source}`);
      }
      await fs.promises.cp(source, path.join(appDir, folder), {
        recursive: true,
        filter: sourcePath => !/\.bak$/i.test(sourcePath)
      });
    }

    const runtimePackage = { ...pkg };
    delete runtimePackage.build;
    delete runtimePackage.scripts;
    delete runtimePackage.devDependencies;
    delete runtimePackage.devEngines;
    await fs.promises.writeFile(
      path.join(appDir, 'package.json'),
      `${JSON.stringify(runtimePackage, null, 2)}\n`,
      'utf8'
    );

    const masterIcon = path.join(ROOT, 'assets', 'icono.ico');
    const runtimeIcon = path.join(appDir, 'assets', 'icono.ico');
    if (!fs.existsSync(masterIcon) || !fs.existsSync(runtimeIcon)) {
      throw new Error('Falta el icono ICO maestro o su copia en el runtime temporal.');
    }
    const masterHash = await sha256File(masterIcon);
    if (await sha256File(runtimeIcon) !== masterHash) {
      throw new Error('El icono ICO del runtime temporal no coincide con el icono maestro.');
    }

    const preflight = path.join(__dirname, 'test-runtime-package-completeness.js');
    if (!fs.existsSync(preflight)) throw new Error('Falta test-runtime-package-completeness.js; se cancela el empaquetado.');
    const result = spawnSync(process.execPath, [preflight, '--runtime-dir', appDir], { cwd: ROOT, stdio: 'inherit' });
    if (result.error) throw result.error;
    if (result.status !== 0) throw new Error(`La auditoría del runtime temporal falló (código ${result.status}). No se inicia electron-builder.`);
    return { appDir, masterIcon, masterHash };
  } catch (error) {
    process.removeListener('exit', cleanup);
    cleanup();
    throw error;
  }
}

async function verifyPackagedRuntime(outputDir, appDir, expectedMainHash, masterIconHash) {
  const asarPath = path.join(outputDir, 'win-unpacked', 'resources', 'app.asar');
  if (!fs.existsSync(asarPath)) throw new Error(`No se generó app.asar: ${asarPath}`);
  const asar = require('@electron/asar');
  const archiveEntries = await asar.listPackage(asarPath);
  const normalized = new Set(archiveEntries.map(entry => String(entry).replace(/\\/g, '/').replace(/^\/+/, '')));
  const packagedFiles = [];
  const walk = dir => {
    if (!fs.existsSync(dir)) throw new Error(`Falta una carpeta que debe empaquetarse: ${dir}`);
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.isFile()) {
        const rel = path.relative(appDir, full).split(path.sep).join('/');
        // El ICO canónico se extrae físicamente mediante asarUnpack y se valida abajo.
        if (rel !== 'assets/icono.ico') packagedFiles.push(rel);
      }
    }
  };
  for (const folder of ['electron', 'renderer', 'assets']) walk(path.join(appDir, folder));
  packagedFiles.push('package.json');
  for (const rel of packagedFiles) {
    if (!normalized.has(rel)) throw new Error(`El ASAR omitió un archivo incluido en la auditoría: ${rel}`);
  }
  if (typeof asar.extractFile !== 'function') throw new Error('@electron/asar no permite extraer archivos para la verificación final.');
  const packagedManifest = JSON.parse((await asar.extractFile(asarPath, 'package.json')).toString('utf8'));
  if (packagedManifest.build) throw new Error('El package.json dentro de app.asar contiene metadatos build no permitidos.');
  if (packagedManifest.main !== 'electron/main.js') throw new Error('El entrypoint dentro de app.asar no es electron/main.js.');
  const packagedMain = await asar.extractFile(asarPath, 'electron/main.js');
  const packagedMainHash = crypto.createHash('sha256').update(packagedMain).digest('hex').toUpperCase();
  if (packagedMainHash !== expectedMainHash) throw new Error('El main.js dentro de app.asar no coincide byte por byte con el main.js revisado.');

  const unpackedIcon = path.join(outputDir, 'win-unpacked', 'resources', 'app.asar.unpacked', 'assets', 'icono.ico');
  if (!fs.existsSync(unpackedIcon)) throw new Error(`No se extrajo el ICO físico esperado: ${unpackedIcon}`);
  if (await sha256File(unpackedIcon) !== masterIconHash) throw new Error('El ICO de app.asar.unpacked no coincide byte por byte con el icono maestro.');
  console.log(`ASAR_RUNTIME_OK: ${packagedFiles.length} archivos de Electron, Renderer, assets y manifiesto verificados; main.js e icono físico íntegros.`);
}

async function main() {
  const iconTestPath = path.join(__dirname, 'test-windows-icon-config.js');
  if (!fs.existsSync(iconTestPath)) throw new Error('Falta tools/test-windows-icon-config.js; no se compila sin la prueba de iconos.');
  const iconTest = spawnSync(process.execPath, [iconTestPath], { cwd: ROOT, stdio: 'inherit' });
  if (iconTest.error) throw iconTest.error;
  if (iconTest.status !== 0) throw new Error('La prueba de consistencia de iconos de Windows no pasó.');

  if (process.argv.includes('--recovery')) {
    throw new Error('El modo --recovery queda retirado. Primero ejecuta ProControl-Limpieza-Instalaciones-Prueba.ps1 -Apply y luego compila/instala de forma normal.');
  }

  const packagePath = path.join(ROOT, 'package.json');
  const pkg = JSON.parse(await fs.promises.readFile(packagePath, 'utf8'));
  if (pkg.name !== 'procontrol-desktop' || !pkg.version) {
    throw new Error('package.json no corresponde a procontrol-desktop.');
  }

  const runtime = await prepareAndCheckRuntimeApp(pkg);
  const expectedRuntimeMainHash = await sha256File(path.join(runtime.appDir, 'electron', 'main.js'));

  const toolchain = assertToolchain(pkg);
  const buildConfig = pkg.build || {};
  if (buildConfig.nsis && buildConfig.nsis.script) {
    throw new Error('No se permite nsis.script personalizado; se conserva el script NSIS mantenido por electron-builder.');
  }

  const include = buildConfig.nsis && buildConfig.nsis.include;
  if (include !== 'build/installer.nsh') {
    throw new Error(`El include NSIS debe ser build/installer.nsh; valor actual: ${include || '(vacio)'}. No se usa el include de recuperacion en publicaciones.`);
  }
  const includePath = path.join(ROOT, include);
  if (!fs.existsSync(includePath)) throw new Error(`No existe el include NSIS: ${includePath}`);
  const includeText = await fs.promises.readFile(includePath, 'utf8');
  if (/CRCCheck\s+off/i.test(includeText)) {
    throw new Error('Se detecto CRCCheck off en build/installer.nsh. La proteccion CRC debe permanecer activa.');
  }

  const asarUnpack = Array.isArray(buildConfig.asarUnpack) ? buildConfig.asarUnpack : [];
  if (!asarUnpack.includes('assets/icono.ico')) {
    throw new Error('build.asarUnpack debe extraer assets/icono.ico para que Windows pueda cargar el icono desde una ruta fisica.');
  }
  if (!Array.isArray(buildConfig.files) || !buildConfig.files.includes('!electron/**/*.bak')) {
    throw new Error('build.files debe excluir los respaldos *.bak de Electron antes de empaquetar.');
  }

  const win = buildConfig.win || {};
  if (win.signExecutable !== false || win.signAndEditExecutable !== true) {
    throw new Error('package.json debe conservar win.signExecutable=false y win.signAndEditExecutable=true para insertar el icono de ProControl.');
  }

  const nsis = buildConfig.nsis || {};
  const canonicalIcon = 'assets/icono.ico';
  if (win.icon !== canonicalIcon || nsis.installerIcon !== canonicalIcon || nsis.uninstallerIcon !== canonicalIcon) {
    throw new Error('La aplicación, el instalador y el desinstalador deben usar exactamente assets/icono.ico.');
  }
  for (const key of ['installerIcon', 'uninstallerIcon']) {
    const iconPath = path.resolve(ROOT, nsis[key]);
    if (!fs.existsSync(iconPath)) throw new Error(`No existe nsis.${key}: ${iconPath}`);
  }
  const iconPath = path.join(ROOT, canonicalIcon);
  const iconBytes = await fs.promises.readFile(iconPath);
  if (iconBytes.length < 6 || iconBytes.readUInt16LE(0) !== 0 || iconBytes.readUInt16LE(2) !== 1) {
    throw new Error('assets/icono.ico no es un ICO valido.');
  }
  const iconCount = iconBytes.readUInt16LE(4);
  const iconSizes = new Set();
  for (let i = 0; i < iconCount; i++) {
    const offset = 6 + i * 16;
    if (offset + 16 > iconBytes.length) throw new Error('Directorio ICO truncado.');
    const w = iconBytes[offset] || 256;
    const h = iconBytes[offset + 1] || 256;
    const bytes = iconBytes.readUInt32LE(offset + 8);
    const dataOffset = iconBytes.readUInt32LE(offset + 12);
    if (!bytes || dataOffset < 6 + iconCount * 16 || dataOffset + bytes > iconBytes.length) {
      throw new Error('Una resolución del ICO tiene datos fuera de rango.');
    }
    iconSizes.add(`${w}x${h}`);
  }
  for (const size of [16, 20, 24, 32, 40, 48, 64, 96, 128, 256]) {
    if (!iconSizes.has(`${size}x${size}`)) throw new Error(`El ICO carece de la resolución ${size}x${size}.`);
  }

  if (process.argv.includes('--preflight-only')) {
    console.log('\nPROCONTROL_PREFLIGHT_OK');
    console.log(`Runtime temporal validado: ${runtime.appDir}`);
    console.log(`Toolchain: ${JSON.stringify(toolchain)}`);
    return;
  }

  const outputName = `dist_setup_definitivo_${stamp()}`;
  const outputDir = path.join(ROOT, outputName);
  if (fs.existsSync(outputDir)) throw new Error(`La carpeta de salida ya existe: ${outputDir}`);

  const config = {
    ...buildConfig,
    directories: { ...(buildConfig.directories || {}), app: runtime.appDir, output: outputName },
    win: {
      ...win,
      icon: canonicalIcon,
      target: [{ target: 'nsis', arch: ['x64'] }],
      signExecutable: false,
      signAndEditExecutable: true,
    },
    nsis: {
      ...nsis,
      installerIcon: canonicalIcon,
      uninstallerIcon: canonicalIcon,
      installerHeaderIcon: canonicalIcon,
      createDesktopShortcut: 'always',
      createStartMenuShortcut: true,
      shortcutName: 'ProControl',
      include: 'build/installer.nsh',
      differentialPackage: false,
    },
  };

  console.log('PROCONTROL - COMPILACION LIMPIA NSIS DEFINITIVA');
  console.log(`Version de ProControl: ${pkg.version}`);
  console.log(`Toolchain: ${JSON.stringify(toolchain)}`);
  console.log(`Salida nueva: ${outputDir}`);
  console.log('Objetivo unico: NSIS x64');
  console.log('Host: Windows x64');
  console.log('CRC de NSIS: habilitado');
  console.log('signAndEditExecutable: true (icono oficial integrado en el EXE)');
  console.log('Icono único: assets/icono.ico (EXE, Setup, Uninstaller, ventana y accesos directos).');
  console.log('Acceso directo del Escritorio: recreate=always.');
  console.log('No se usa el include de recuperacion.');

  const { build, Platform, Arch } = require('electron-builder');
  await build({
    projectDir: ROOT,
    targets: Platform.WINDOWS.createTarget(['nsis'], Arch.x64),
    config,
  });

  const unpackedIcon = path.join(outputDir, 'win-unpacked', 'resources', 'app.asar.unpacked', 'assets', 'icono.ico');
  if (!fs.existsSync(unpackedIcon)) {
    throw new Error(`No se extrajo el ICO fisico esperado: ${unpackedIcon}`);
  }
  const iconHeader = await fs.promises.readFile(unpackedIcon);
  if (iconHeader.length < 6 || iconHeader.readUInt16LE(0) !== 0 || iconHeader.readUInt16LE(2) !== 1) {
    throw new Error('El ICO extraido no tiene una cabecera valida.');
  }
  const sourceIconHash = await sha256File(path.join(ROOT, 'assets', 'icono.ico'));
  const unpackedIconHash = await sha256File(unpackedIcon);
  if (sourceIconHash !== unpackedIconHash) {
    throw new Error('El ICO de app.asar.unpacked no coincide byte por byte con el icono oficial fuente.');
  }
  await verifyPackagedRuntime(outputDir, runtime.appDir, expectedRuntimeMainHash, sourceIconHash);

  const entries = await fs.promises.readdir(outputDir, { withFileTypes: true });
  const setupFiles = entries
    .filter(entry => entry.isFile() && /\.exe$/i.test(entry.name) && /setup/i.test(entry.name))
    .map(entry => path.join(outputDir, entry.name));
  if (setupFiles.length !== 1) {
    throw new Error(`Se esperaba un solo Setup.exe y se encontraron ${setupFiles.length}.`);
  }

  const setupPath = setupFiles[0];
  const stat = await fs.promises.stat(setupPath);
  if (stat.size < 10 * 1024 * 1024) {
    throw new Error(`El Setup tiene un tamaño anormal (${stat.size} bytes).`);
  }
  await assertPe(setupPath);

  const { inspectNsisFile } = require('./nsis-integrity');
  const nsisCheck = inspectNsisFile(setupPath, { expectedKind: 'installer' });
  if (nsisCheck.status !== 'VALID') {
    throw new Error(`No se pudo validar el Setup con la comprobacion NSIS: ${nsisCheck.status}. ${nsisCheck.reason || ''}`);
  }

  const stable = await assertStable(setupPath);
  const manifest = {
    schemaVersion: 2,
    product: 'ProControl',
    version: String(pkg.version),
    architecture: 'x64',
    target: 'nsis',
    icon: 'assets/icono.ico',
    iconSha256: sourceIconHash,
    desktopShortcut: 'always',
    startMenuShortcut: true,
    buildHost: `${process.platform}-${process.arch}`,
    outputDir,
    setupFile: path.basename(setupPath),
    setupPath,
    sizeBytes: stable.sizeBytes,
    sha256: stable.sha256,
    electron: pkg.devDependencies.electron,
    toolchain,
    nsisIntegrity: nsisCheck,
    signAndEditExecutable: true,
    differentialPackage: false,
    crcCheckDisabled: false,
    generatedAt: new Date().toISOString(),
    note: 'CRC NSIS verificado con la misma regla de exehead. La prueba final obligatoria sigue siendo instalar desde cero en Windows y ejecutar el desinstalador creado en esa instalacion.',
  };
  const manifestPath = path.join(outputDir, 'PROCONTROL_NSIS_BUILD.json');
  await fs.promises.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\r\n`, 'utf8');

  // Relee el artefacto despues de escribir el manifiesto para detectar cambios posteriores al build.
  const final = await assertStable(setupPath);
  if (final.sha256 !== manifest.sha256 || final.sizeBytes !== manifest.sizeBytes) {
    await fs.promises.rm(manifestPath, { force: true });
    throw new Error('El Setup cambio despues de la validacion. Se elimino el manifiesto; no distribuir.');
  }

  console.log('\nBUILD_NSIS_OK');
  console.log(`SETUP: ${setupPath}`);
  console.log(`BYTES: ${stable.sizeBytes}`);
  console.log(`SHA256: ${stable.sha256}`);
  console.log(`CRC NSIS: ${nsisCheck.crcCalculated}`);
  console.log(`MANIFIESTO: ${manifestPath}`);
  console.log('Siguiente paso: respaldar los datos de ProControl y probar una instalacion NUEVA en un entorno controlado. No borrar %APPDATA%\\ProControl.');
}

main().catch(error => {
  console.error('\nBUILD_NSIS_ERROR');
  console.error(error && error.stack ? error.stack : error.message || error);
  process.exit(1);
});
