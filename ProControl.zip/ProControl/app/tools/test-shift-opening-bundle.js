'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { stableJson, signedFields } = require('../electron/mobile-bridge/store');
const {
  MAX_SHIFT_OPENING_BUNDLE_BYTES,
  createShiftOpeningBundle,
  verifyShiftOpeningBundle
} = require('../electron/mobile-bridge/shift-opening-bundle');

const desktopKeys = crypto.generateKeyPairSync('ed25519');
const desktopPublicKey = desktopKeys.publicKey.export({ type: 'spki', format: 'pem' }).toString();
const installationId = 'pcinst_' + 'a'.repeat(32);
const authorizationId = 'auth_test_opening_0001';
const deviceId = 'device_test_opening_0001';
const posId = 'pos_test_opening_01';
const permit = {
  format: 'procontrol.shift-permit',
  version: 2,
  permitId: 'permit_test_opening_0001',
  desktopDeviceId: 'desktop_test_0001',
  posId,
  deviceId,
  employee: 'Operador de prueba',
  startsAt: 1793900000000,
  endsAt: 1793928800000,
  sequence: 1,
  emergency: { enabled: false, maxSales: 0, expiresAt: null, reason: null },
  issuedAt: 1793900000000,
  desktopPublicKey,
  installationId,
  installationCode: 'PCINST-AAAAAAAAAAAAAAAA',
  authorizationId,
  deviceSigningPublicKeyHash: 'b'.repeat(64),
  authorizedPosId: posId
};
permit.signature = crypto.sign(null, Buffer.from(stableJson(permit), 'utf8'), desktopKeys.privateKey).toString('base64');

function makeInventoryPackage(overrides = {}) {
  const document = {
    format: 'procontrol.device-data-package',
    version: 1,
    algorithm: 'RSA-OAEP-256+A256GCM',
    packageId: 'package_test_opening_0001',
    installationId,
    authorizationId,
    deviceId,
    posId,
    type: 'inventory_snapshot',
    createdAt: new Date(permit.issuedAt).toISOString(),
    expiresAt: permit.issuedAt + 86400000,
    payloadHash: 'c'.repeat(64),
    signerPublicKey: desktopPublicKey,
    encryption: {
      keyWrap: 'RSA-OAEP-SHA256',
      contentCipher: 'AES-256-GCM',
      wrappedKey: Buffer.alloc(384, 1).toString('base64'),
      iv: Buffer.alloc(12, 2).toString('base64'),
      tag: Buffer.alloc(16, 3).toString('base64')
    },
    ciphertext: Buffer.from('encrypted snapshot test bytes').toString('base64'),
    ...overrides
  };
  document.signature = {
    algorithm: 'Ed25519',
    value: crypto.sign(null, signedFields(document), desktopKeys.privateKey).toString('base64')
  };
  return document;
}

const inventoryPackage = makeInventoryPackage();
const created = createShiftOpeningBundle({
  permit,
  inventoryPackage,
  desktopPrivateKey: desktopKeys.privateKey,
  desktopPublicKey,
  bundleId: '12345678-1234-4234-8234-123456789abc',
  now: permit.issuedAt
});
const parsed = JSON.parse(created.json);
assert.equal(parsed.format, 'procontrol.shift-opening-bundle');
assert.equal(parsed.version, 1);
assert.equal(parsed.permit.permitId, permit.permitId);
assert.equal(parsed.inventoryPackage.packageId, inventoryPackage.packageId);
assert.equal(verifyShiftOpeningBundle(parsed, desktopPublicKey).ok, true);
assert.ok(created.bytes <= MAX_SHIFT_OPENING_BUNDLE_BYTES);

const tampered = JSON.parse(created.json);
tampered.posId = 'pos_other_0001';
assert.equal(verifyShiftOpeningBundle(tampered, desktopPublicKey).code, 'SHIFT_OPENING_BUNDLE_SCOPE_MISMATCH');

const changedPermit = JSON.parse(created.json);
changedPermit.permit.employee = 'Otro trabajador';
assert.equal(verifyShiftOpeningBundle(changedPermit, desktopPublicKey).code, 'SHIFT_OPENING_PERMIT_SIGNATURE_INVALID');

const changedOuterSignature = JSON.parse(created.json);
changedOuterSignature.bundleId = '22345678-1234-4234-8234-123456789abc';
assert.equal(verifyShiftOpeningBundle(changedOuterSignature, desktopPublicKey).code, 'SHIFT_OPENING_BUNDLE_SIGNATURE_INVALID');

const changedInventory = makeInventoryPackage({ posId: 'pos_other_0001' });
assert.throws(() => createShiftOpeningBundle({
  permit,
  inventoryPackage: changedInventory,
  desktopPrivateKey: desktopKeys.privateKey,
  desktopPublicKey
}), error => error && error.code === 'SHIFT_OPENING_BUNDLE_SCOPE_MISMATCH');

const oversizedInventory = makeInventoryPackage({ ciphertext: 'A'.repeat(100 * 1024) });
assert.throws(() => createShiftOpeningBundle({
  permit,
  inventoryPackage: oversizedInventory,
  desktopPrivateKey: desktopKeys.privateKey,
  desktopPublicKey
}), error => error && error.code === 'SHIFT_OPENING_BUNDLE_TOO_LARGE');

console.log('Shift opening bundle contract and signature tests passed.');
