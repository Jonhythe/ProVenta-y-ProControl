'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');

// La hoja de ruta nueva usa un solo campo para la cantidad en unidad base.
// Los campos boxQty/unitQty permanecen únicamente como compatibilidad de datos.
assert.match(html, /id="trans-qty"[^>]*step="1"[^>]*inputmode="numeric"/, 'La transferencia debe tener un campo único de cantidad que acepta enteros en unidades discretas.');
assert.doesNotMatch(html, /id="trans-box-qty"|id="trans-unit-qty"/, 'La transferencia no debe mostrar campos separados de cajas y unidades.');
assert.match(html, /ProductUnits\.validateDiscreteQuantity\(quantity, unit\)/, 'La transferencia debe validar la cantidad según la unidad base.');
assert.match(html, /const available = Math\.max\(0, Number\(item\.qty \|\| 0\) - alreadyAssigned\)/, 'El campo de transferencia debe limitarse al stock disponible.');
assert.match(html, /handleQtyEnter\(e\)[\s\S]*?this\.addToCart\(\)/, 'La cantidad se puede confirmar con Enter.');
assert.match(html, /id="trans-quantity-breakdown"/, 'La interfaz debe explicar la cantidad que se va a transferir.');
assert.match(html, /appState\.transferCart\.push\(\{ dest: destination\.key, name: productName, productId: item\.productId \|\| null, qty: quantity, boxQty: 0, unitQty: quantity, unitsPerBox: null, unit \}\)/, 'El carrito debe guardar la cantidad única y conservar campos de compatibilidad sin usarlos en la interfaz.');
assert.match(html, /line\.qty = quantity;[\s\S]*?line\.boxQty = 0;[\s\S]*?line\.unitQty = quantity/, 'Editar una línea de ruta debe actualizar la cantidad única.');
assert.match(html, /class="[^"]*route-qty-input[^"]*"[\s\S]*?Logistics\.updateCartQty\(/, 'La cantidad de cada destino se puede modificar en la hoja de ruta.');
assert.match(html, /route-qty-unit-note/, 'La hoja de ruta debe identificar la unidad base de cada cantidad.');
console.log('OK: transferencias con cantidad única, validación de stock y edición de ruta; sin campos visibles de cajas.');
