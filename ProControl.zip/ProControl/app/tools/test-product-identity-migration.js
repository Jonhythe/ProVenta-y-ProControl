'use strict';
const assert = require('node:assert/strict');
const { plan, analyze } = require('../renderer/product-identity-migration.js');
let assertions = 0;
function equal(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
function ok(value, message) { assertions++; assert.ok(value, message); }
function throwsCode(fn, expected, message) {
  assertions++;
  assert.throws(fn, error => error && error.code === expected, message);
}
let idCounter = 0;
const newId = () => `prod_${String(++idCounter).padStart(8, '0')}`;
const empty = overrides => ({ inventory: [], pointsOfSale: [], productCatalog: [], transfers: [], ...(overrides || {}) });

// A single unlinked product can be assigned an ID on a deep copy.
{
  const original = empty({ inventory: [{ name: 'Arroz', unit: 'u', family: 'Granos', qty: 0 }] });
  const result = plan(original, newId);
  ok(result.inventory[0].productId, 'A unambiguous product receives a stable ID');
  equal(result.inventory[0].stockEmpty, true, 'An exhausted product is preserved and marked exhausted');
  equal(original.inventory[0].productId, undefined, 'Planning must not mutate the input state');
  equal(result.report.generatedIds, 1, 'Report counts the generated ID');
}

// Same name in two locations without an existing ID or catalog match must not be merged.
{
  const original = empty({
    inventory: [{ name: 'Leche', unit: 'u', family: 'Lácteos', qty: 4 }],
    pointsOfSale: [{ id: 'pos_00000001', name: 'Caja 1', inventory: [{ name: 'Leche', unit: 'u', family: 'Lácteos', qty: 2 }] }]
  });
  const result = analyze(original);
  equal(result.ok, false, 'Dry-run flags duplicate name as ambiguous');
  ok(result.issues.some(issue => issue.code === 'AMBIGUOUS_DUPLICATE_NAME'), 'Report explains the ambiguous product identity');
  throwsCode(() => plan(original, newId), 'PRODUCT_IDENTITY_REVIEW_REQUIRED', 'Migration refuses to merge by name alone');
  equal(original.inventory[0].productId, undefined, 'Original remains untouched after rejection');
  equal(original.pointsOfSale[0].inventory[0].productId, undefined, 'POS inventory remains untouched after rejection');
}

// A name match in the catalog is not enough to merge several inventory rows; explicit same IDs are required.
{
  const ambiguous = empty({
    productCatalog: [{ id: 'product_rice_001', name: 'Arroz', aliases: ['Arroz largo'], unit: 'u', family: 'Granos' }],
    inventory: [{ name: 'Arroz', unit: 'u', family: 'Granos', qty: 5 }],
    pointsOfSale: [{ id: 'pos_00000001', name: 'Caja 1', inventory: [{ name: 'Arroz', unit: 'u', family: 'Granos', qty: 1 }] }]
  });
  equal(analyze(ambiguous).issues.some(issue => issue.code === 'AMBIGUOUS_DUPLICATE_NAME'), true, 'Catalog name alone cannot merge two inventory rows');
  const input = empty({
    productCatalog: [{ id: 'product_rice_001', name: 'Arroz', aliases: ['Arroz largo'], unit: 'u', family: 'Granos' }],
    inventory: [{ name: 'Arroz', productId: 'product_rice_001', unit: 'u', family: 'Granos', qty: 5 }],
    pointsOfSale: [{ id: 'pos_00000001', name: 'Caja 1', inventory: [{ name: 'Arroz', productId: 'product_rice_001', unit: 'u', family: 'Granos', qty: 1 }] }],
    transfers: [{ id: 'transfer_0001', product: 'Arroz', qty: 2 }]
  });
  const result = plan(input, newId);
  equal(result.inventory[0].productId, 'product_rice_001', 'Central stock preserves an explicit catalog ID');
  equal(result.pointsOfSale[0].inventory[0].productId, 'product_rice_001', 'POS stock preserves the same explicit ID');
  equal(result.transfers[0].productId, 'product_rice_001', 'Transfer history gets a unique catalog link');
  equal(input.transfers[0].productId, undefined, 'Transfer plan does not mutate original input');
}

// Same explicit ID on every inventory record is safe to preserve, even when the catalog row is missing.
{
  const input = empty({
    inventory: [{ name: 'Jabón', productId: 'soap_00000001', unit: 'u', qty: 0 }],
    pointsOfSale: [{ id: 'pos_00000001', name: 'Caja 1', inventory: [{ name: 'Jabón', productId: 'soap_00000001', unit: 'u', qty: 2 }] }]
  });
  const result = plan(input, newId);
  equal(result.pointsOfSale[0].inventory[0].productId, 'soap_00000001', 'Known explicit identity is preserved');
  equal(result.productCatalog[0].id, 'soap_00000001', 'Missing catalog record is reconstructed without changing its ID');
  equal(result.inventory[0].stockEmpty, true, 'Zero stock stays represented');
}

// Conflicting product IDs, catalog collisions, different units, and orphan transfer names stop the plan.
{
  const conflict = empty({ inventory: [{ name: 'Aceite', productId: 'oil_00000001', unit: 'u' }], pointsOfSale: [{ id: 'pos_00000001', inventory: [{ name: 'Aceite', productId: 'oil_00000002', unit: 'u' }] }] });
  throwsCode(() => plan(conflict, newId), 'PRODUCT_IDENTITY_REVIEW_REQUIRED', 'Conflicting IDs require manual resolution');
  const unitConflict = empty({ inventory: [{ name: 'Agua', unit: 'l', family: 'Bebidas' }, { name: 'Agua', unit: 'u', family: 'Bebidas' }] });
  throwsCode(() => plan(unitConflict, newId), 'PRODUCT_IDENTITY_REVIEW_REQUIRED', 'Different units cannot be merged');
  const catalogConflict = empty({ productCatalog: [{ id: 'cat_00000001', name: 'Cafe' }, { id: 'cat_00000002', name: 'Cafe' }] });
  ok(analyze(catalogConflict).issues.some(issue => issue.code === 'CATALOG_NAME_COLLISION'), 'Duplicate catalog name collision is reported');
  const orphan = empty({ transfers: [{ id: 'transfer_0002', product: 'Descontinuado', qty: 1 }] });
  throwsCode(() => plan(orphan, newId), 'PRODUCT_IDENTITY_REVIEW_REQUIRED', 'Orphan transfer stays untouched and requires review');
}


// Historical sales lines are part of the stable identity migration.
{
  const original = empty({
    productCatalog: [{ id: 'product_rice_001', name: 'Arroz', aliases: [], unit: 'u', family: 'Granos' }],
    inventory: [{ name: 'Arroz', productId: 'product_rice_001', unit: 'u', family: 'Granos', qty: 3 }],
    salesLedger: [{ id: 'sale_00000001', items: [{ name: 'Arroz', baseUnit: 'u', baseQty: 1, lineTotalCUP: 2 }] }]
  });
  const result = plan(original, newId);
  equal(result.salesLedger[0].items[0].productId, 'product_rice_001', 'A ticket line without an ID is linked only when the catalog identity is unique');
  equal(original.salesLedger[0].items[0].productId, undefined, 'The ticket identity plan does not mutate original history');
  equal(result.report.ticketLinks, 1, 'The report counts linked historical ticket lines');
}
{
  const orphanTicket = empty({ salesLedger: [{ id: 'sale_00000002', items: [{ name: 'Producto desconocido', baseUnit: 'u' }] }] });
  equal(analyze(orphanTicket).issues.some(issue => issue.code === 'TICKET_PRODUCT_ID_AMBIGUOUS'), true, 'A ticket line with no unique product mapping requires manual review');
  throwsCode(() => plan(orphanTicket, newId), 'PRODUCT_IDENTITY_REVIEW_REQUIRED', 'Migration refuses to guess an identity for a historical ticket');
}
{
  const conflictTicket = empty({
    productCatalog: [{ id: 'product_rice_001', name: 'Arroz', aliases: [], unit: 'u' }],
    inventory: [{ name: 'Arroz', productId: 'product_rice_001', unit: 'u', qty: 2 }],
    salesLedger: [{ id: 'sale_00000003', items: [{ name: 'Jabón', productId: 'product_rice_001', baseUnit: 'u', baseQty: 1, lineTotalCUP: 1 }] }]
  });
  equal(analyze(conflictTicket).issues.some(issue => issue.code === 'TICKET_PRODUCT_ID_NAME_CONFLICT'), true, 'An existing ticket ID cannot be silently reassigned to a different product name');
}

console.log(`Product identity migration: ${assertions} assertions passed.`);
