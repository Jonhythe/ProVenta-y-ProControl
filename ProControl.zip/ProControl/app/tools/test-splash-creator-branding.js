'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const appRoot = path.resolve(__dirname, '..');
const splashPath = path.join(appRoot, 'renderer', 'splash.html');
const authPath = path.join(appRoot, 'renderer', 'index.html');
const logoPath = path.join(appRoot, 'renderer', 'roninlab-logo.png');
const splash = fs.readFileSync(splashPath, 'utf8');
const auth = fs.readFileSync(authPath, 'utf8');
const logo = fs.readFileSync(logoPath);

assert.match(splash, /class="creator-signature"[^>]*aria-label="ProControl desarrollado por RoninLab"/,
  'La firma de RoninLab debe estar en la bienvenida de ProControl.');
assert.match(splash, /class="creator-caption">Desarrollado por<\/span>/,
  'La bienvenida debe identificar discretamente al creador.');
assert.match(splash, /src="app:\/\/roninlab-logo\.png" alt="RoninLab"/,
  'La imagen de RoninLab debe usar el recurso local de la aplicación.');
assert.match(splash, /\.creator-logo\s*\{[^}]*max-height:\s*112px/s,
  'El logo debe tener un tamaño contenido para seguir siendo secundario.');
assert.match(splash, /@media\s*\(max-height:\s*700px\)[\s\S]*?\.creator-logo\s*\{\s*width:\s*76px/s,
  'El logo debe reducirse en ventanas de poca altura.');
assert.match(splash, /@media\s*\(max-width:\s*700px\)[\s\S]*?\.creator-logo\s*\{\s*width:\s*88px/s,
  'El logo debe reducirse en pantallas estrechas.');
assert.doesNotMatch(auth, /creator-signature|roninlab-logo\.png/,
  'El branding de RoninLab no debe añadirse a la ventana de autenticación.');

// Check PNG signature and RGBA color type so the app receives a real transparent PNG.
assert.deepEqual([...logo.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10], 'El logo debe ser un PNG válido.');
assert.equal(logo[25], 6, 'El logo debe ser RGBA (canal alfa/transparencia).');
assert.ok(logo.length > 100_000, 'El recurso debe tener suficiente resolución para verse nítido.');

console.log('OK: logotipo secundario de RoninLab integrado únicamente en splash.html y con transparencia real.');
