﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ZipPath,
    [Parameter(Mandatory = $true)][string]$DeliveryRoot
)

$ErrorActionPreference = 'Stop'
$ZipPath = [System.IO.Path]::GetFullPath($ZipPath)
$DeliveryRoot = [System.IO.Path]::GetFullPath($DeliveryRoot)
if (-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)) { throw "No existe el ZIP: $ZipPath" }
if (-not (Test-Path -LiteralPath $DeliveryRoot -PathType Container)) { throw "No existe la carpeta de entrega: $DeliveryRoot" }

function Get-StreamHash([System.IO.Stream]$Stream) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([System.BitConverter]::ToString($sha.ComputeHash($Stream))).Replace('-', '')
    } finally { $sha.Dispose() }
}

function Get-ManifestObject([string]$Path) {
    return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json)
}

$localManifestPath = Join-Path $DeliveryRoot 'MANIFEST.json'
if (-not (Test-Path -LiteralPath $localManifestPath -PathType Leaf)) { throw 'La carpeta de entrega no contiene MANIFEST.json.' }
$localManifest = Get-ManifestObject $localManifestPath
if ([int]$localManifest.schemaVersion -ne 2 -or $localManifest.product -ne 'ProControl' -or $localManifest.target -ne 'electron-builder-dir') {
    throw 'El manifiesto local no corresponde al esquema de distribución por carpeta v2.'
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
try {
    $entriesByName = @{}
    foreach ($entry in $archive.Entries) {
        $normalized = $entry.FullName.Replace('\', '/').TrimStart('/')
        if (-not $normalized) { continue }
        if ($entriesByName.ContainsKey($normalized)) { throw "El ZIP contiene una ruta duplicada: $normalized" }
        $entriesByName.Add($normalized, $entry)
    }

    foreach ($required in @('MANIFEST.json', 'Actualizar-ProControl.ps1', 'Actualizar-ProControl.bat', 'LEEME-ENTREGA.txt', 'ProControl/ProControl.exe', 'ProControl/resources/app.asar')) {
        if (-not $entriesByName.ContainsKey($required)) { throw "El ZIP no contiene la ruta obligatoria: $required" }
    }

    # El manifiesto comprimido debe ser idéntico al manifiesto de la carpeta entregada.
    $zipManifestEntry = $entriesByName['MANIFEST.json']
    $zipManifestStream = $zipManifestEntry.Open()
    $zipManifestMemory = New-Object System.IO.MemoryStream
    try {
        $zipManifestStream.CopyTo($zipManifestMemory)
        $zipManifestText = [System.Text.Encoding]::UTF8.GetString($zipManifestMemory.ToArray()).TrimStart([char]0xFEFF)
    } finally {
        $zipManifestMemory.Dispose()
        $zipManifestStream.Dispose()
    }
    $localManifestBytes = [System.IO.File]::ReadAllBytes($localManifestPath)
    $localManifestText = [System.Text.Encoding]::UTF8.GetString($localManifestBytes).TrimStart([char]0xFEFF)
    if ($zipManifestText -ne $localManifestText) { throw 'MANIFEST.json dentro del ZIP no es idéntico al manifiesto de la carpeta.' }

    $declared = @($localManifest.files)
    if ($declared.Count -ne [int]$localManifest.fileCount) { throw 'El número de archivos del manifiesto no coincide con fileCount.' }

    $declaredRelease = @($localManifest.releaseFiles)
    $requiredRelease = @('Actualizar-ProControl.ps1', 'Actualizar-ProControl.bat', 'LEEME-ENTREGA.txt')
    if ($declaredRelease.Count -ne $requiredRelease.Count) { throw 'El manifiesto no registra los tres archivos de control de la entrega.' }
    $releaseSeen = @{}
    foreach ($releaseFile in $declaredRelease) {
        $releaseName = [string]$releaseFile.path
        if ($requiredRelease -notcontains $releaseName) { throw "Archivo de control no permitido en el manifiesto: $releaseName" }
        if ($releaseSeen.ContainsKey($releaseName)) { throw "Archivo de control duplicado: $releaseName" }
        $releaseSeen[$releaseName] = $true
        $localReleasePath = Join-Path $DeliveryRoot $releaseName
        if (-not (Test-Path -LiteralPath $localReleasePath -PathType Leaf)) { throw "Falta el archivo de control local: $releaseName" }
        $localReleaseItem = Get-Item -LiteralPath $localReleasePath
        $localReleaseStream = [System.IO.File]::OpenRead($localReleasePath)
        try { $localReleaseHash = Get-StreamHash -Stream $localReleaseStream } finally { $localReleaseStream.Dispose() }
        if ($localReleaseHash -ne ([string]$releaseFile.sha256).ToUpperInvariant()) { throw "SHA-256 local incorrecto para $releaseName." }
        if ([long]$localReleaseItem.Length -ne [long]$releaseFile.sizeBytes) {
            Write-Warning "Metadato de tamaño distinto para $releaseName; SHA-256 local coincide exactamente."
        }
        if (-not $entriesByName.ContainsKey($releaseName)) { throw "Falta en el ZIP el archivo de control: $releaseName" }
        $releaseEntry = $entriesByName[$releaseName]
        $releaseStream = $releaseEntry.Open()
        try { $releaseHash = Get-StreamHash -Stream $releaseStream } finally { $releaseStream.Dispose() }
        if ($releaseHash -ne ([string]$releaseFile.sha256).ToUpperInvariant()) { throw "SHA-256 incorrecto dentro del ZIP para $releaseName." }
        if ([long]$releaseEntry.Length -ne [long]$releaseFile.sizeBytes) {
            Write-Warning "Metadato de tamaño distinto dentro del ZIP para $releaseName; SHA-256 coincide exactamente."
        }
    }
    foreach ($releaseName in $requiredRelease) { if (-not $releaseSeen.ContainsKey($releaseName)) { throw "Falta en el manifiesto el archivo de control $releaseName." } }

    $listed = @{}
    foreach ($file in $declared) {
        $relative = ([string]$file.path).Replace('\', '/')
        if (-not $relative -or $relative.StartsWith('/') -or $relative -match '(^|/)\.\.?(/|$)') { throw "Ruta insegura en el manifiesto: $relative" }
        if ($listed.ContainsKey($relative)) { throw "Ruta duplicada en el manifiesto: $relative" }
        $listed[$relative] = $true
        $zipName = 'ProControl/' + $relative
        if (-not $entriesByName.ContainsKey($zipName)) { throw "Falta en el ZIP: $zipName" }
        $zipEntry = $entriesByName[$zipName]
        $stream = $zipEntry.Open()
        try { $hash = Get-StreamHash -Stream $stream } finally { $stream.Dispose() }
        if ($hash -ne ([string]$file.sha256).ToUpperInvariant()) {
            throw "SHA-256 dentro del ZIP no coincide para $relative. Esperado=$($file.sha256); ZIP=$hash."
        }
        if ([long]$zipEntry.Length -ne [long]$file.sizeBytes) {
            Write-Warning "Metadato de tamaño distinto para $relative dentro del ZIP; SHA-256 coincide exactamente."
        }
    }

    $zipPayloadFiles = @($entriesByName.Keys | Where-Object { $_.StartsWith('ProControl/', [System.StringComparison]::OrdinalIgnoreCase) -and -not $_.EndsWith('/') })
    if ($zipPayloadFiles.Count -ne $declared.Count) {
        throw "El ZIP contiene $($zipPayloadFiles.Count) archivos bajo ProControl/, pero el manifiesto declara $($declared.Count)."
    }
    $allowedRootEntries = @('MANIFEST.json') + @($declaredRelease | ForEach-Object { [string]$_.path })
    foreach ($name in $entriesByName.Keys) {
        if ($name.StartsWith('ProControl/', [System.StringComparison]::OrdinalIgnoreCase) -or $name.EndsWith('/')) { continue }
        if ($allowedRootEntries -notcontains $name) { throw "Archivo raíz no esperado en el ZIP: $name" }
    }

    Write-Host "ZIP verificado: $($declared.Count) archivos de programa; estructura y SHA-256 coinciden." -ForegroundColor Green
} finally {
    $archive.Dispose()
}
