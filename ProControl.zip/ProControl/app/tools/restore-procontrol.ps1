param(
  [Parameter(Mandatory=$true)][string]$BackupPath
)
$ErrorActionPreference = 'Stop'
$AppRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$DataRoot = Join-Path $env:APPDATA 'ProControl'
$ElectronExe = Join-Path $AppRoot 'node_modules\electron\dist\electron.exe'
$running = @()
try { $running += Get-Process -Name 'ProControl' -ErrorAction SilentlyContinue } catch {}
if (Test-Path $ElectronExe) {
  try { $running += Get-Process -Name 'electron' -ErrorAction SilentlyContinue | Where-Object { $_.Path -and ([IO.Path]::GetFullPath($_.Path) -eq [IO.Path]::GetFullPath($ElectronExe)) } } catch {}
}
if ($running.Count -gt 0) { throw 'Cierra ProControl por completo antes de restaurar una copia.' }
$BackupPath = (Resolve-Path $BackupPath).Path
$manifestPath = Join-Path $BackupPath 'manifest.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'La carpeta elegida no contiene manifest.json.' }
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.format -ne 'ProControl.Backup' -or $manifest.version -ne 1 -or -not ($manifest.files -is [System.Array] -or $manifest.files)) { throw 'El formato de copia no es compatible.' }
$allowed = @('procontrol.db','procontrol.db-wal','procontrol.db-shm','procontrol.json','mobile-bridge.db','mobile-bridge.db-wal','mobile-bridge.db-shm','mobile-bridge-desktop-public.pem','mobile-bridge-desktop-private.dpapi','mobile-bridge-desktop-private.dpapi.bak','mobile-bridge-desktop-private.pem.dpapi')
foreach ($entry in $manifest.files) {
  if ($entry.name -notin $allowed) { throw "Nombre de archivo no permitido en el manifiesto: $($entry.name)" }
  $src = Join-Path $BackupPath $entry.name
  if (-not (Test-Path -LiteralPath $src -PathType Leaf)) { throw "Falta el archivo $($entry.name). No se restauró nada." }
  $hash = (Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($hash -ne $entry.sha256.ToLowerInvariant()) { throw "La comprobación SHA-256 falló para $($entry.name). No se restauró nada." }
}
# Validar todo antes de mover cualquier dato. La copia actual se conserva primero.
New-Item -ItemType Directory -Path $DataRoot -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$SafetyDir = Join-Path (Split-Path $BackupPath -Parent) "ProControl-PreRestore-$stamp"
New-Item -ItemType Directory -Path $SafetyDir -Force | Out-Null
foreach ($name in $allowed) {
  $current = Join-Path $DataRoot $name
  if (Test-Path -LiteralPath $current -PathType Leaf) { Copy-Item -LiteralPath $current -Destination (Join-Path $SafetyDir $name) }
}
try {
  foreach ($entry in $manifest.files) {
    $targetName = if ($entry.name -eq 'mobile-bridge-desktop-private.pem.dpapi') { 'mobile-bridge-desktop-private.pem' } else { $entry.name }
    $src = Join-Path $BackupPath $entry.name
    $dst = Join-Path $DataRoot $targetName
    if ($entry.name -eq 'mobile-bridge-desktop-private.pem.dpapi') {
      Add-Type -AssemblyName System.Security
      $entropy = [Text.Encoding]::UTF8.GetBytes('ProControl-MobileBridge-Backup-v1')
      $protected = [IO.File]::ReadAllBytes($src)
      $plain = [Security.Cryptography.ProtectedData]::Unprotect($protected, $entropy, [Security.Cryptography.DataProtectionScope]::CurrentUser)
      [IO.File]::WriteAllBytes($dst, $plain)
    } else {
      Copy-Item -LiteralPath $src -Destination $dst -Force
    }
  }
} catch {
  Write-Warning "La restauración falló: $($_.Exception.Message). La copia previa se guardó en $SafetyDir. Restaura manualmente desde esa carpeta si es necesario."
  throw
}
Write-Host "Copia restaurada. Se conservó un respaldo previo en: $SafetyDir" -ForegroundColor Green
Write-Host 'Abre ProControl y comprueba el inventario, las ventas, los cierres y el panel móvil antes de operar.'
