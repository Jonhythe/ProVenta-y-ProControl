'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const engine = require('../renderer/qrcode-engine');
global.ProControlQrEngine = engine;
const QR = require('../renderer/local-qr');
const { encodeProVentaActivationCode, signedFields, sha256 } = require('../electron/mobile-bridge/store');

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { MobileBridgeStore, stableJson, decodeProVentaActivationCode } = require('../electron/mobile-bridge/store');

function createSignedPhoneIdentity(label = 'Samsung SM-A266M de prueba') {
  const signingKeys = crypto.generateKeyPairSync('ed25519');
  const encryptionKeys = crypto.generateKeyPairSync('rsa', { modulusLength: 3072, publicExponent: 0x10001 });
  const document = {
    format: 'proventa.device-identity',
    version: 1,
    deviceId: 'device_' + crypto.randomBytes(16).toString('hex'),
    label,
    devicePublicKey: signingKeys.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    deviceEncryptionPublicKey: encryptionKeys.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    createdAt: new Date().toISOString()
  };
  document.signature = {
    algorithm: 'Ed25519',
    value: crypto.sign(null, Buffer.from(stableJson(document), 'utf8'), signingKeys.privateKey).toString('base64')
  };
  return {
    document,
    token: 'PVID1:' + Buffer.from(JSON.stringify(document), 'utf8').toString('base64url')
  };
}

const temporaryRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-single-qr-'));
let store;
try {
  store = new MobileBridgeStore(temporaryRoot, { desktopId: 'desktop_single_qr_test' });
  const identity = createSignedPhoneIdentity();
  const authorization = store.createDeviceAuthorizationFromIdentity(identity.token, {
    employeeName: 'Trabajador de prueba',
    employeeData: 'Fixture de interoperabilidad QR estándar',
    posId: 'pos_test_01',
    authorizedPosName: 'Punto de venta de prueba'
  }, 'Dueño de prueba');
  assert.equal(authorization.ok, true);
  assert.ok(authorization.activationCode.startsWith('PVLA2:'));

  const activationCode = authorization.activationCode;
  const decoded = decodeProVentaActivationCode(activationCode);
  const rawDescriptor = decoded.rawJson;
  assert.equal(encodeProVentaActivationCode(rawDescriptor), activationCode, 'El código leído del archivo y el QR debe ser el mismo PVLA2 íntegro.');
  assert.equal(decoded.descriptor.deviceId, identity.document.deviceId);
  assert.equal(decoded.descriptor.authorizedPosId, 'pos_test_01');

  const info = QR.getInfo(activationCode, 6);
  assert.ok(info.version >= 1 && info.version <= 40, 'PVLA2 fits one standard QR Model 2 symbol');
  assert.equal(info.errorCorrection, 'M');
  assert.equal(info.modules, 17 + 4 * info.version);
  assert.equal(info.payloadBytes, Buffer.byteLength(activationCode, 'utf8'));
  assert.ok(info.payloadBytes <= 1200, 'The real signed PVID1 → PVLA2 payload remains practical for a conventional QR scanner.');

  const matrix = QR.encodeMatrix(activationCode);
  assert.equal(matrix.length, info.modules);
  assert.ok(matrix.every(row => row.length === info.modules));
  const dataUrl = QR.toDataUrl(activationCode, 6);
  assert.ok(dataUrl.startsWith('data:image/svg+xml;charset=utf-8,'));
  assert.ok(decodeURIComponent(dataUrl.split(',')[1]).includes('<svg'));

  // The authorization QR path is intentionally single-symbol only.
  assert.throws(() => QR.splitDocument('D', rawDescriptor, decoded.descriptor.authorizationId), /QR_KIND_INVALID/);
  assert.throws(() => QR.toSvg('PVLA2:incomplete'), error => error && error.code === 'PVLA2_FORMAT_INVALID');
  assert.throws(() => QR.toSvg('x'.repeat(3000)), error => error && error.code === 'QR_SINGLE_CAPACITY_EXCEEDED');
  assert.throws(() => QR.toSvg('PVLA2:' + 'A'.repeat(4001)), error => error && error.code === 'PVLA2_FORMAT_INVALID');

  // Existing goods-dispatch transport remains independently multi-symbol.
  const dispatch = JSON.stringify({
    format: 'procontrol.goods-dispatch', version: 1, dispatchId: 'dispatch_test_12345678',
    confirmationCode: '01234567', posId: 'pos_test_01',
    items: [{ productId: 'rice_01', name: 'Arroz', unit: 'lb', quantity: 12.5, sale: 100, saleTransf: 108 }]
  });
  const pieces = QR.splitDocument('T', dispatch, 'dispatch_test_12345678');
  assert.ok(pieces.length > 1);
  assert.ok(pieces.every(piece => Buffer.byteLength(piece.payload, 'utf8') <= QR.MAX_INPUT_BYTES));
  assert.ok(pieces.every(piece => piece.dataUrl.startsWith('data:image/svg+xml;charset=utf-8,')));

  const openingText = JSON.stringify({
    format: 'procontrol.shift-opening-bundle',
    version: 1,
    bundleId: '12345678-1234-4234-8234-123456789abc',
    payload: 'x'.repeat(2500)
  });
  const openingPieces = QR.splitOpeningBundle(openingText);
  assert.equal(openingPieces.length, 3);
  assert.ok(openingPieces.every(piece => piece.payload.startsWith(`PCO2|B|12345678123442348234123456789ABC|`)));
  assert.ok(openingPieces.every(piece => Buffer.byteLength(piece.payload, 'utf8') <= 1500));
  assert.ok(openingPieces.every(piece => piece.dataUrl.startsWith('data:image/svg+xml;charset=utf-8,')));
  const openingBytes = Buffer.concat(openingPieces.map(piece =>
    Buffer.from(piece.payload.split('|')[4].replace(/-/g, '+').replace(/_/g, '/'), 'base64')
  ));
  assert.equal(openingBytes.toString('utf8'), openingText, 'PCO2 preserves the exact opening bundle bytes across ordered frames.');
  assert.throws(() => QR.splitOpeningBundle(JSON.stringify({
    format: 'procontrol.shift-opening-bundle',
    version: 1,
    bundleId: '12345678-1234-4234-8234-123456789abc',
    payload: 'x'.repeat(QR.MAX_OPENING_QR_BYTES)
  })), error => error && error.code === 'OPENING_QR_SIZE_EXCEEDED');

  const fixture = {
    format: 'procontrol.single-pvla2-qr-test-fixture',
    version: info.version,
    modules: info.modules,
    errorCorrection: info.errorCorrection,
    activationCode,
    rawDescriptor,
    deviceId: identity.document.deviceId,
    deviceSigningPublicKeyHash: decoded.descriptor.deviceSigningPublicKeyHash,
    matrix: matrix.map(row => row.map(dark => dark ? '1' : '0').join(''))
  };
  // Never depend on the model/container-only /mnt/data path. Windows users run
  // this script from PowerShell, so default to the OS temp directory and create
  // parent directories for both the default and caller-supplied output paths.
  const defaultOutputPath = path.join(
    os.tmpdir(),
    'ProControl',
    'test-artifacts',
    'pvla2-qr-integration-fixture.json'
  );
  const outputPath = path.resolve(process.env.PROVENTA_SINGLE_QR_FIXTURE_OUTPUT || defaultOutputPath);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, JSON.stringify(fixture) + '\n', { encoding: 'utf8' });
  console.log(`Single PVLA2 QR tests passed: ${Buffer.byteLength(activationCode)} bytes, QR v${info.version} M (${info.modules} modules); dispatch multi-QR retained.`);
  console.log(`Interoperability fixture written to: ${outputPath}`);
} finally {
  try { store && store.close(); } catch (_) {}
  fs.rmSync(temporaryRoot, { recursive: true, force: true });
}
