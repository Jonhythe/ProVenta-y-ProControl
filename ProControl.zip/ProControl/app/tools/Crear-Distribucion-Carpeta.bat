@echo off
setlocal EnableExtensions

for %%I in ("%~dp0..") do set "APP_ROOT=%%~fI"
cd /d "%APP_ROOT%"

where node.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: No se encontro Node.js en PATH.
  echo Instala Node.js x64 o abre la consola configurada para el proyecto.
  pause
  exit /b 10
)

if not exist "package.json" (
  echo ERROR: No se encontro package.json en "%APP_ROOT%".
  pause
  exit /b 11
)
if not exist "tools\build-folder-distribution.js" (
  echo ERROR: Falta tools\build-folder-distribution.js.
  pause
  exit /b 12
)

echo.
echo ================================================================
echo       PROCONTROL - CREADOR DE DISTRIBUCION POR CARPETA
echo ================================================================
echo.
echo Este proceso crea una carpeta limpia y un ZIP verificado.
echo No ejecuta NSIS y no modifica la instalacion ni AppData.
echo.

node "tools\build-folder-distribution.js"
set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" (
  echo ERROR: La creacion no termino correctamente. Codigo: %RC%
  echo Conserva el mensaje anterior para diagnosticarlo.
  pause
  exit /b %RC%
)

echo DISTRIBUCION CREADA Y VERIFICADA.
echo Revisa la ruta de la carpeta y del ZIP indicada arriba.
pause
exit /b 0
