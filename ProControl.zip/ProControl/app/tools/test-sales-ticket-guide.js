'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');

assert.match(html, /id="sale-guide-heading"[^>]*>¿Debes registrar aquí cada venta del dependiente\?/,
  'La pantalla explica que los tickets individuales no son el flujo habitual del dependiente.');
assert.match(html, /el dependiente trabaja con su IPV impreso/i,
  'La pantalla explica el flujo real basado en IPV impreso.');
assert.match(html, /Cierre diario por IPV/, 'El cierre por IPV queda como ruta principal.');
assert.match(html, /Tickets individuales \(opcional\)/, 'El registro individual se identifica como opcional en el menú.');
assert.match(html, /class="sales-ticket-steps"[\s\S]*?El dependiente entrega el IPV[\s\S]*?Revisan el conteo juntos[\s\S]*?ProControl calcula una estimación/,
  'El flujo principal muestra los tres pasos basados en IPV.');
assert.match(html, /id="sale-draft-status"/,
  'Existe un estado visible y accesible del borrador.');
assert.match(html, /id="sale-register-button"[^>]*>Confirmar venta y descontar stock/,
  'La acción final explica que confirma la venta y descuenta existencias.');
assert.match(html, /¿Confirmas que las cantidades y el importe son correctos\?/,
  'Antes de guardar aparece una confirmación con el resumen de la operación.');
assert.match(html, /no está guardado y no se ha descontado stock/i,
  'El estado del borrador deja explícito que aún no modifica inventario.');
assert.match(html, /todos los productos de este ticket usan la misma forma de pago/i,
  'La regla de una única forma de pago se explica junto al campo.');
assert.match(html, /si el dependiente trabaja con IPV impreso y las ventas se calculan en el cierre/i,
  'La confirmación de activación distingue el modo individual del flujo IPV.');
assert.match(html, /registrará el stock|se descontará el stock|se descontarán las existencias/i,
  'El texto explica el efecto sobre inventario.');
assert.match(html, /pendiente de incluirse en el próximo cierre/i,
  'El texto explica la relación con el cierre sin confundirlo con el cierre mismo.');
assert.match(html, /[Ll]os cierres sin tickets aportan una estimación por diferencia de inventario/,
  'La guía distingue el dato exacto por ticket de la estimación por IPV.');
assert.match(html, /sales-ticket-help-details/,
  'Los detalles de ayuda ampliada se pueden consultar sin saturar el formulario.');
assert.match(html, /draftStatus\.innerHTML = this\._cart\.length[\s\S]*?Borrador preparado[\s\S]*?Borrador vacío/,
  'El estado visual cambia entre borrador vacío y preparado.');
assert.match(html, /Añadido al borrador|Añadido al ticket:/,
  'Se informa al usuario al preparar una línea.');
console.log('Sales ticket guide: 15 assertions passed.');
