'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
require('../renderer/number-format.js');
require('../renderer/product-units.js');
const U = globalThis.ProductUnits;

assert.equal(U.normalizeUnitsPerBox(null), null);
assert.equal(U.normalizeUnitsPerBox('12'), 12);
assert.throws(() => U.normalizeUnitsPerBox(0), /entero mayor que cero/);
assert.throws(() => U.normalizeUnitsPerBox(2.5), /entero mayor que cero/);
assert.equal(U.toIndividualUnits(10, 'cajas', 12), 120);
assert.equal(U.toIndividualUnits(2, 'caja', 15), 30);
assert.deepEqual(U.normalizeBoxPurchase(2, 150, 15), {
  stockQuantity: 30,
  costPerIndividualUnit: 10,
  unitsPerBox: 15
});
assert.equal(U.purchaseStockQuantity(2, 'caja', 15), 30);
assert.equal(U.purchaseStockQuantity(1, 'caja', 15) - U.purchaseStockQuantity(2, 'caja', 15), -15, 'corregir 2 cajas a 1 caja debe retirar 15 unidades físicas');
assert.equal(U.purchaseStockQuantity(30, 'u', null), 30);
assert.equal(U.purchaseStockQuantity(2.5, 'kg', null), 2.5);
assert.equal(U.stockUnitForPurchase('caja'), 'u');
assert.equal(U.stockUnitForPurchase('kg'), 'kg');
assert.throws(() => U.purchaseStockQuantity(2, 'caja', null), /no tiene configurado/);
assert.throws(() => U.purchaseStockQuantity(1.5, 'caja', 15), /número entero/);
assert.throws(() => U.purchaseStockQuantity(1.5, 'u', null), /número entero/);
assert.throws(() => U.normalizeBoxPurchase(1.5, 150, 15), /cantidad de cajas debe ser un número entero/);
assert.throws(() => U.normalizeBoxPurchase(2, 150, null), /no tiene configurado/);
assert.equal(U.toIndividualUnits(3, 'u', 12), 3);
assert.throws(() => U.toIndividualUnits(1, 'caja', null), /no tiene configurado/);
assert.throws(() => U.toIndividualUnits(1.5, 'cajas', 12), /número entero/);
assert.throws(() => U.toIndividualUnits(1.5, 'u', 12), /número entero/);
assert.deepEqual(U.combineBoxAndUnitQuantity(3, 0, 10), { boxes: 3, individualUnits: 0, unitsPerBox: 10, totalUnits: 30 });
assert.deepEqual(U.combineBoxAndUnitQuantity(3, 2, 10), { boxes: 3, individualUnits: 2, unitsPerBox: 10, totalUnits: 32 });
assert.deepEqual(U.splitIndividualUnits(32, 10), { boxes: 3, individualUnits: 2, totalUnits: 32, unitsPerBox: 10 });
assert.equal(U.formatBoxBreakdown(3, 0, 10).text, '3 cj × 10 u = 30 u');
assert.equal(U.formatBoxBreakdown(3, 2, 10).totalUnits, 32);
assert.equal(U.formatBoxBreakdown(1234, 0, 10).text, '1,234 cj × 10 u = 12,340 u');
assert.equal(U.formatBoxBreakdown(0, 1234.567, null, { allowFractionalUnits: true }).text, '1,234.57 u · Total: 1,234.57 u');
assert.throws(() => U.combineBoxAndUnitQuantity(1, 0, null), /Configure cuántas unidades contiene una caja/);
assert.throws(() => U.combineBoxAndUnitQuantity(1, 1.5, 10), /unidades sueltas deben ser un número entero/);
assert.equal(U.combineBoxAndUnitQuantity(0, 1.5, null, { allowFractionalUnits: true }).totalUnits, 1.5);
assert.deepEqual(U.subtractSale(120, 10, 'cajas', 12), {
  soldIndividualUnits: 120,
  remainingIndividualUnits: 0
});
assert.deepEqual(U.subtractSale(120, 1, 'caja', 12), {
  soldIndividualUnits: 12,
  remainingIndividualUnits: 108
});
assert.deepEqual(U.subtractSale(120, 3, 'u', 12), {
  soldIndividualUnits: 3,
  remainingIndividualUnits: 117
});
assert.throws(() => U.subtractSale(10, 1, 'caja', 12), /existencias suficientes/);
assert.equal(U.validateDiscreteQuantity(2.5, 'kg'), true);
assert.equal(U.validateDiscreteQuantity(2.5, 'u'), false);
assert.equal(U.validateDiscreteQuantity(2, 'caja'), true);
assert.equal(U.validateDiscreteQuantity(1.5, 'pqt'), false);
assert.equal(U.validateDiscreteQuantity(2, 'pqt'), true);
assert.equal(U.isSupportedUnit('caja'), false, 'Caja ya no debe ofrecerse como unidad nueva; sus convertidores históricos se conservan');
assert.equal(U.isSupportedUnit('u'), true);
assert.equal(U.isSupportedUnit('desconocida'), false);
assert.deepEqual(U.unitOptions().map(option => option.value), ['u', 'pqt', 'lb', 'kg', 'lt']);

// Electron usa app://<nombre-de-archivo>; una ruta relativa ./product-units.js
// acabaría resolviéndose como app://index.html/product-units.js y no cargaría el módulo.
const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');
assert.match(html, /<script\s+src=["']app:\/\/product-units\.js["']><\/script>/i, 'index.html debe cargar el módulo de unidades mediante la ruta app:// correcta');
assert.doesNotMatch(html, /<script\s+src=["']\.\/product-units\.js["']/i, 'no usar una ruta relativa para product-units.js');
assert.match(html, /!ProductUnits\.validateDiscreteQuantity\(qty, unit\)/, 'las compras deben validar cantidades enteras para unidades discretas');
assert.match(html, /!ProductUnits\.validateDiscreteQuantity\(finalQty, item\.unit\)/, 'el cierre debe validar cantidades enteras para unidades discretas');
assert.match(html, /target\.classList\.contains\('p-name'\) && e\.key === 'Enter'/, 'Enter en nombre debe abrir el selector de unidades');
assert.match(html, /ArrowDown|ArrowUp/, 'el selector debe incluir navegación por flechas');
assert.match(html, /position:\s*fixed;[\s\S]*?\.purchase-table \.p-unit-menu/, 'el menú no debe ocupar espacio en el flujo vertical');
assert.doesNotMatch(html, /class=\"p-box-qty\"/, 'las compras nuevas no deben mostrar el campo unidades por caja');
assert.doesNotMatch(html, /classList\.toggle\('has-boxes', hasBoxes\)/, 'la tabla de compras no debe volver a ampliarse al elegir Caja');
assert.doesNotMatch(html, /row\.querySelector\('\.p-box-qty'\)\.value/, 'la cantidad por caja no debe formar parte de altas nuevas');
// Las equivalencias antiguas se validan en las pruebas de migración de historial, no en el formulario de compra nuevo.


assert.match(html, /displayUnit\(item, state = appState\)/, 'inventario y POS deben indicar cuántas unidades contiene la caja configurada');
assert.match(html, /purchaseStockQuantity\(quantity, purchaseUnit, item\.unitsPerBox\)/, 'las correcciones de compras deben convertir cantidades de caja a stock base');
assert.match(html, /formatQuantityCompact\(item, availableQuantity\)/, 'las transferencias deben indicar cajas/unidades en una línea compacta al mostrar stock');
assert.match(html, /const transferFactor = Number\(transfer\.unitsPerBox \|\| 0\)/, 'el historial usa la equivalencia almacenada al realizar la transferencia');
console.log('OK: altas sin opción Caja, cantidades discretas, unidad de stock y compatibilidad de cantidades de transferencia históricas.');
