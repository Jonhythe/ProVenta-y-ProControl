#!/usr/bin/env node
'use strict';

// Parche mínimo e idempotente: conserva el main.js local completo y solo elimina
// la segunda carga qrDescriptor/authorizationDescriptor del IPC de autorización.
const fs = require('node:fs');
const path = require('node:path');

const mainPath = path.resolve(process.cwd(), 'electron', 'main.js');
if (!fs.existsSync(mainPath)) {
  throw new Error('Ejecute este script desde la raíz app de ProControl; falta electron/main.js.');
}

const original = fs.readFileSync(mainPath, 'utf8');
const eol = original.includes('\r\n') ? '\r\n' : '\n';
const source = original.replace(/\r\n/g, '\n');

const legacyBlock = [
  "    if (typeof result.authorizationDescriptor !== 'string' ||",
  "        Buffer.byteLength(result.authorizationDescriptor, 'utf8') > 8192) {",
  "      throw Object.assign(new Error('PROVENTA_AUTHORIZATION_QR_DESCRIPTOR_INVALID'), {",
  "        code: 'PROVENTA_AUTHORIZATION_QR_DESCRIPTOR_INVALID'",
  "      });",
  "    }",
  "    // El QR reconstruye exactamente la ficha firmada que ya está dentro del PVLA2.",
  "    // La importación por archivo y por QR son dos transportes alternativos de la misma autorización.",
  "    result.qrDescriptor = result.authorizationDescriptor;",
  "    delete result.authorizationDescriptor;"
].join('\n');

const replacement = [
  "    // Solo se transporta el PVLA2 canónico; el descriptor queda dentro del token firmado.",
  "    if (typeof result.activationCode !== 'string' ||",
  "        !result.activationCode.startsWith('PVLA2:') ||",
  "        Buffer.byteLength(result.activationCode, 'utf8') > 4000) {",
  "      throw Object.assign(new Error('PROVENTA_ACTIVATION_CODE_INVALID'), {",
  "        code: 'PROVENTA_ACTIVATION_CODE_INVALID'",
  "      });",
  "    }"
].join('\n');

const occurrences = source.split(legacyBlock).length - 1;
if (occurrences === 0) {
  const alreadyPatched = source.includes("result.activationCode.startsWith('PVLA2:')") &&
    !source.includes('result.qrDescriptor') && !source.includes('result.authorizationDescriptor');
  if (alreadyPatched) {
    process.stdout.write('OK: main.js ya devuelve únicamente PVLA2; no se modificó nada.\n');
    process.exit(0);
  }
  throw new Error('No se encontró el bloque QR antiguo exacto. No se modificó main.js para evitar una sustitución incorrecta.');
}
if (occurrences !== 1) {
  throw new Error(`Se esperaba una única ruta antigua de descriptor QR y se encontraron ${occurrences}. No se modificó main.js.`);
}

const backupPath = mainPath + '.pre-single-qr.bak';
try {
  fs.copyFileSync(mainPath, backupPath, fs.constants.COPYFILE_EXCL);
} catch (error) {
  if (error.code !== 'EEXIST') throw error;
}
const updated = source.replace(legacyBlock, replacement).replace(/\n/g, eol);
fs.writeFileSync(mainPath, updated, 'utf8');

const check = fs.readFileSync(mainPath, 'utf8');
if (check.includes('result.qrDescriptor') || check.includes('result.authorizationDescriptor')) {
  fs.copyFileSync(backupPath, mainPath);
  throw new Error('La comprobación posterior detectó campos paralelos. Se restauró el respaldo original.');
}
process.stdout.write('OK: main.js actualizado; ahora la IPC entrega solo activationCode PVLA2.\n');
process.stdout.write(`Respaldo conservado en: ${path.basename(backupPath)}\n`);
