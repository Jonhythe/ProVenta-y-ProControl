"use strict";
const assert = require('node:assert/strict');
require('../renderer/product-units.js');
const Sales = require('../renderer/sales-ledger.js');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log(`✓ ${name}`); }
const base = { productId:'product-1', name:'Agua 500 ml', baseUnit:'u', presentation:'unit', quantity:3, unitPrice:2, currency:'CUP' };
test('unidades individuales mantienen cantidad base', () => {
  const line=Sales.makeLine(base); assert.equal(line.baseQty,3); assert.equal(line.lineTotal,6); assert.equal(line.lineTotalCUP,6);
});
test('dos cajas de 15 conservan presentación y convierten a 30 unidades base', () => {
  const line=Sales.makeLine({...base,presentation:'box',quantity:2,unitsPerBox:15,unitPrice:27});
  assert.equal(line.presentationQty,2); assert.equal(line.baseQty,30); assert.equal(line.lineTotal,54); assert.equal(line.presentation,'box');
});
test('venta mixta registra 3 cajas de 10 + 2 unidades sueltas como 32 unidades base', () => {
  const tx=Sales.buildTransaction({id:'mixed-box-unit',posId:'pos:mixed',posName:'POS mixto',user:'cajero',paymentMethod:'cash',lines:[
    {...base,presentation:'box',quantity:3,unitsPerBox:10,unitsPerBoxAtSale:10,unitPrice:100},
    {...base,presentation:'unit',quantity:2,unitsPerBoxAtSale:10,unitPrice:10}
  ]});
  assert.equal(tx.items.length,2);
  assert.equal(tx.items[0].baseQty,30);
  assert.equal(tx.items[0].unitsPerBoxAtSale,10);
  assert.equal(tx.items[1].baseQty,2);
  assert.equal(tx.items[1].unitsPerBoxAtSale,10);
  assert.equal(tx.items.reduce((sum,line)=>sum+line.baseQty,0),32);
  assert.equal(tx.totalNative,320);
  assert.equal(tx.totalCUP,320);
  assert.equal(Sales.validateTransaction(tx),true);
});
test('venta en USD conserva tipo de cambio e importe contable', () => {
  const tx=Sales.buildTransaction({id:'sale-1',posId:'pos:123',posName:'POS 1',user:'cajero',paymentMethod:'usd',exchangeRate:400,line:{...base,unitPrice:0.5}});
  assert.equal(tx.currency,'USD'); assert.equal(tx.totalNative,1.5); assert.equal(tx.totalCUP,600); assert.equal(Sales.validateTransaction(tx),true);
});
test('caja requiere equivalencia de unidades', () => {
  assert.throws(()=>Sales.makeLine({...base,presentation:'box',quantity:1,unitsPerBox:null}),/unidades por caja/);
});
test('no permite fracciones de caja', () => {
  assert.throws(()=>Sales.makeLine({...base,presentation:'box',quantity:1.5,unitsPerBox:12}),/entero/);
});
test('no permite vender cajas de productos medidos en kg', () => {
  assert.throws(()=>Sales.makeLine({...base,baseUnit:'kg',presentation:'box',quantity:1,unitsPerBox:12}),/unidad base/);
});
test('impide vender más stock del disponible', () => {
  assert.throws(()=>Sales.validateAvailableStock(12,15),/Stock insuficiente/);
  assert.equal(Sales.validateAvailableStock(12,2),10);
});
test('cierre calcula ventas pendientes por presentación y por ID de producto', () => {
  const records=[
    {id:'s1',posId:'pos:a',status:'pending-close',closingId:null,items:[{productId:'p1',name:'Agua',baseQty:30,lineTotalCUP:54,presentation:'box',presentationQty:2,baseUnit:'u'}]},
    {id:'s2',posId:'pos:a',status:'pending-close',closingId:null,items:[{productId:'p1',name:'Agua',baseQty:3,lineTotalCUP:6,presentation:'unit',presentationQty:3,baseUnit:'u'}]},
    {id:'s3',posId:'pos:b',status:'pending-close',closingId:null,items:[{productId:'p1',name:'Agua',baseQty:2,lineTotalCUP:4,presentation:'unit',presentationQty:2,baseUnit:'u'}]}
  ];
  const summary=Sales.summarizeProduct(records,'pos:a','p1','Agua');
  assert.equal(summary.baseQty,33); assert.equal(summary.revenueCUP,60); assert.equal(summary.boxes,2); assert.equal(summary.units,3); assert.equal(summary.transactionCount,2); assert.deepEqual(summary.transactionIds,['s1','s2']);
});
test('cierre solo ve tickets pendientes y excluye los ya reconciliados', () => {
  const records=[{id:'s1',posId:'pos:a',status:'reconciled',closingId:'c1',items:[{productId:'p1',name:'Agua',baseQty:3,lineTotalCUP:6,presentation:'unit',presentationQty:3,baseUnit:'u'}]}];
  assert.equal(Sales.pendingForPOS(records,'pos:a').length,0);
});
test('valida unicidad de idempotencia del ticket', () => {
  const tx=Sales.buildTransaction({id:'sale-2',posId:'pos:1',posName:'POS 1',user:'cajero',paymentMethod:'cash',line:base});
  assert.equal(Sales.validateTransaction(tx),true);
  assert.equal(Sales.validateTransaction({...tx,idempotencyKey:'another-id'}),false);
});
test('rechaza una tasa USD inexistente', () => {
  assert.throws(()=>Sales.buildTransaction({id:'sale-3',posId:'pos:1',posName:'POS 1',user:'cajero',paymentMethod:'usd',exchangeRate:0,line:base}),/tasa de cambio/);
});
test('diferencia física admite faltante y sobrante con signo correcto', () => {
  assert.equal(Sales.stockDifference(10,8),2);
  assert.equal(Sales.stockDifference(8,10),-2);
  assert.equal(Sales.stockDifference(10,10),0);
  assert.throws(()=>Sales.stockDifference(-1,2),/no negativos/);
});
test('detecta producto eliminado con tickets pendientes y no bloquea por tickets cerrados', () => {
  const records=[
    {id:'open',posId:'pos:x',status:'pending-close',closingId:null,items:[{productId:'gone',name:'Producto ausente'}]},
    {id:'closed',posId:'pos:x',status:'reconciled',closingId:'c1',items:[{productId:'gone2',name:'Producto histórico'}]}
  ];
  const missing=Sales.findMissingPendingProducts(records,'pos:x',[{productId:'ok',name:'Otro'}],item=>item.productId);
  assert.equal(missing.length,1); assert.equal(missing[0].name,'Producto ausente');
  assert.equal(Sales.findMissingPendingProducts(records,'pos:x',[{productId:'gone',name:'Producto ausente'}],item=>item.productId).length,0);
});

test('un ticket admite varios productos y suma correctamente los importes', () => {
  const tx=Sales.buildTransaction({id:'multi-1',posId:'pos:1',posName:'POS 1',user:'cajero',paymentMethod:'cash',lines:[
    {...base,quantity:2,unitPrice:2},
    {...base,productId:'product-2',name:'Lápiz',quantity:3,unitPrice:1.5}
  ]});
  assert.equal(tx.items.length,2); assert.equal(tx.totalNative,8.5); assert.equal(tx.totalCUP,8.5); assert.equal(Sales.validateTransaction(tx),true);
});
test('un ticket con una sola línea mantiene compatibilidad con la fase anterior', () => {
  const tx=Sales.buildTransaction({id:'single-v5',posId:'pos:1',posName:'POS 1',user:'cajero',paymentMethod:'cash',line:base});
  assert.equal(tx.items.length,1); assert.equal(tx.kind,'sale'); assert.equal(Sales.validateTransaction(tx),true);
});
test('devolución completa conserva referencia e importe negativo sin mutar el original', () => {
  const original=Sales.buildTransaction({id:'original-1',posId:'pos:1',posName:'POS 1',user:'cajero',paymentMethod:'cash',lines:[
    {...base,quantity:2,unitPrice:2}, {...base,productId:'product-2',name:'Lápiz',quantity:3,unitPrice:1}
  ]});
  const before=JSON.stringify(original);
  const ret=Sales.buildReturnTransaction({id:'return-1',originalSale:original,user:'admin'});
  assert.equal(ret.kind,'return'); assert.equal(ret.returnOf,'original-1'); assert.equal(ret.items.length,2);
  assert.equal(ret.totalNative,-7); assert.equal(ret.totalCUP,-7); assert.equal(ret.items[0].baseQty,-2); assert.equal(Sales.validateTransaction(ret),true);
  assert.equal(JSON.stringify(original),before);
});
test('impide devolver dos veces el mismo ticket', () => {
  const original=Sales.buildTransaction({id:'original-dup',posId:'pos:1',posName:'POS 1',user:'cajero',paymentMethod:'cash',line:base});
  const ret=Sales.buildReturnTransaction({id:'return-dup',originalSale:original,user:'admin'});
  assert.equal(Sales.canReturnSale([original],original),true);
  assert.equal(Sales.canReturnSale([original,ret],original),false);
  assert.equal(Sales.canReturnSale([original],ret),false);
});
test('devoluciones reducen el importe y unidades netas pendientes del cierre', () => {
  const original=Sales.buildTransaction({id:'net-sale',posId:'pos:net',posName:'POS net',user:'cajero',paymentMethod:'cash',line:{...base,quantity:4,unitPrice:2}});
  const ret=Sales.buildReturnTransaction({id:'net-return',originalSale:original,user:'admin'});
  const summary=Sales.summarizeProduct([original,ret],'pos:net','product-1','Agua 500 ml');
  // Ambos eventos están pendientes en el mismo periodo: la venta queda totalmente compensada.
  assert.equal(summary.baseQty,0); assert.equal(summary.revenueCUP,0); assert.equal(summary.units,0);
});
test('una devolución posterior al cierre queda negativa en el siguiente periodo', () => {
  const original=Sales.buildTransaction({id:'closed-sale',posId:'pos:closed',posName:'POS',user:'cajero',paymentMethod:'cash',line:{...base,quantity:4,unitPrice:2}});
  original.status='reconciled'; original.closingId='close-old'; original.reconciledAt='2026-01-01T00:00:00.000Z';
  const ret=Sales.buildReturnTransaction({id:'later-return',originalSale:original,user:'admin'});
  const summary=Sales.summarizeProduct([original,ret],'pos:closed','product-1','Agua 500 ml');
  assert.equal(summary.baseQty,-4); assert.equal(summary.revenueCUP,-8); assert.match(summary.presentationLabel,/4 u devueltas/);
});
test('rechaza un ticket con totales que no coinciden con sus líneas', () => {
  const tx=Sales.buildTransaction({id:'bad-total',posId:'pos:1',posName:'POS 1',user:'cajero',paymentMethod:'cash',line:base});
  assert.equal(Sales.validateTransaction({...tx,totalNative:999}),false);
});

console.log(`\n${passed} pruebas de registro de ventas aprobadas.`);
