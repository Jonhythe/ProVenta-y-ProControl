'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { MobileBridgeStore, stableJson, sha256, signedFields } = require('../electron/mobile-bridge/store');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-mobile-bridge-final-'));
let store; let assertions = 0;
function equal(a,b,m) { assertions++; assert.equal(a,b,m); }
function ok(v,m) { assertions++; assert.ok(v,m); }
function signedDevicePackage({ privateKey, publicKey, packageId, deviceId, type, payload }) {
  const doc = { format: 'procontrol.offline-package', version: 1, packageId, deviceId, type, createdAt: new Date().toISOString(), payload, payloadHash: sha256(stableJson(payload)), signerPublicKey: publicKey };
  doc.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(doc), privateKey).toString('base64') };
  return doc;
}
try {
  store = new MobileBridgeStore(dir);
  equal(store.status().networkListener, false, 'No se debe activar un listener de red');
  equal(store.status().transport, 'offline-file', 'Debe anunciar transporte por archivo');
  const keyPair = crypto.generateKeyPairSync('ed25519');
  const publicKey = keyPair.publicKey.export({ type: 'spki', format: 'pem' }).toString();
  const privateKey = keyPair.privateKey;
  const code = store.createPairingCode('desktop-local', 'operator', 'pos_test_0001');
  ok(/^\d{6}$/.test(code.code), 'Código temporal de seis dígitos');
  equal(code.assignedPosId, 'pos_test_0001', 'El código queda limitado a un POS');
  const paired = store.pairDevice({ code: code.code, deviceId: 'device_test_0001', label: 'Móvil de prueba', publicKey, role: 'admin', posId: 'otro-pos' });
  equal(paired.ok, true, 'El móvil debe emparejarse con el código');
  equal(paired.role, 'operator', 'El móvil no puede elevar el rol enviado por cliente');
  equal(paired.posId, 'pos_test_0001', 'El móvil no puede alterar el POS asignado');
  equal(paired.signingConfigured, true, 'Debe registrar clave pública Ed25519');
  equal(store.pairDevice({ code: code.code, deviceId: 'device_test_0002', label: 'Segundo móvil', publicKey }).code, 'PAIRING_CODE_INVALID_OR_EXPIRED', 'El código es de un solo uso');
  try { store.createPairingCode('desktop-local', 'admin', 'pos_test_0001'); throw new Error('El rol admin no debió permitirse.'); } catch (e) { if (e.code !== 'ADMIN_ROLE_REQUIRES_AUTHORIZATION') throw e; assertions++; }
} catch (e) {
  if (e && e.code === 'ADMIN_ROLE_REQUIRES_AUTHORIZATION') { assertions++; }
  else throw e;
} finally {
  try { if (store) store.close(); } catch (_) {}
}
// Reopen a clean DB and cover the signed package lifecycle and recovery edge cases.
let store2;
try {
  store2 = new MobileBridgeStore(dir);
  const kp = crypto.generateKeyPairSync('ed25519');
  const publicPem = kp.publicKey.export({ type: 'spki', format: 'pem' }).toString();
  const code = store2.createPairingCode('desktop-local','operator','pos_test_0001');
  equal(store2.pairDevice({ code: code.code, deviceId: 'device_test_0002', label: 'Móvil firmado', publicKey: publicPem }).ok, true, 'Debe emparejar clave para las pruebas firmadas');
  const payload = { schemaVersion: 1, transactions: [{ id: 'sale_test_0001', posId: 'pos_test_0001', items: [{ productId: 'product_test_0001', name: 'Arroz' }] }] };
  const bundle = signedDevicePackage({ privateKey: kp.privateKey, publicKey: publicPem, packageId: 'package_test_0001', deviceId: 'device_test_0002', type: 'sale_batch', payload });
  const imported = store2.importOfflineBundle(JSON.stringify(bundle));
  equal(imported.ok, true, 'Debe importar paquete con firma Ed25519 válida');
  equal(imported.status, 'pending_review', 'Un paquete firmado queda pendiente de revisión');
  equal(store2.importOfflineBundle(JSON.stringify(bundle)).duplicate, true, 'El mismo paquete debe ser idempotente');
  const conflict = signedDevicePackage({ privateKey: kp.privateKey, publicKey: publicPem, packageId: 'package_test_0001', deviceId: 'device_test_0002', type: 'sale_batch', payload: { schemaVersion: 1, transactions: [{ id: 'altered', posId: 'pos_test_0001', items: [{ productId: 'product_test_0001', name: 'Arroz' }] }] } });
  equal(store2.importOfflineBundle(JSON.stringify(conflict)).code, 'PACKAGE_ID_CONFLICT', 'Un ID repetido con otro contenido debe bloquearse');
  const mutated = JSON.parse(JSON.stringify(bundle)); mutated.payload.transactions[0].id = 'tampered';
  equal(store2.importOfflineBundle(JSON.stringify(mutated)).code, 'HASH_MISMATCH', 'Un paquete alterado debe detectarse');
  const otherPos = signedDevicePackage({ privateKey: kp.privateKey, publicKey: publicPem, packageId: 'package_test_0002', deviceId: 'device_test_0002', type: 'sale_batch', payload: { schemaVersion: 1, transactions: [{ id: 'sale_test_0002', posId: 'other_pos_0001', items: [{ productId: 'product_test_0001', name: 'Arroz' }] }] } });
  equal(store2.importOfflineBundle(JSON.stringify(otherPos)).code, 'DEVICE_POS_SCOPE_MISMATCH', 'No se permiten paquetes de otro POS');
  const forbiddenReturn = signedDevicePackage({ privateKey: kp.privateKey, publicKey: publicPem, packageId: 'package_test_0003', deviceId: 'device_test_0002', type: 'return', payload: { schemaVersion: 1, transactions: [{ id:'return_test_01', posId: 'pos_test_0001', items: [{ productId: 'product_test_0001', name: 'Arroz' }] }] } });
  equal(store2.importOfflineBundle(JSON.stringify(forbiddenReturn)).code, 'ROLE_NOT_ALLOWED', 'Operador no puede importar devoluciones');
  equal(store2.markPackage('package_test_0001','accepted_for_reconciliation').ok, true, 'Debe aceptar para conciliación');
  equal(store2.markPackageApplied('package_test_0001','desktop-local',{}).code, 'RECONCILIATION_JOB_NOT_APPLYING', 'No permite cerrar el diario sin iniciar el intento de aplicación');
  const initialJob = store2.getReconciliationJob('package_test_0001');
  equal(initialJob.status, 'accepted_for_reconciliation', 'El diario duradero refleja la aprobación del paquete');
  const firstBegin = store2.beginPackageApply('package_test_0001', 'desktop-local');
  equal(firstBegin.ok, true, 'El diario inicia el intento de aplicación');
  equal(firstBegin.attempt, 1, 'El primer intento queda numerado');
  equal(store2.failPackageApply('package_test_0001', 'desktop-local', 'SIMULATED_CRASH').ok, true, 'Una interrupción vuelve el trabajo a estado reintentable');
  const retryBegin = store2.beginPackageApply('package_test_0001', 'desktop-local');
  equal(retryBegin.attempt, 2, 'El reintento aumenta el contador sin duplicar el paquete');
  equal(store2.markPackageApplied('package_test_0001','desktop-local',{newOperations:1}).ok, true, 'Debe marcar paquete aplicado después de guardar negocio');
  equal(store2.getReconciliationJob('package_test_0001').status, 'applied', 'El diario y el paquete terminan conciliados');
  equal(store2.markPackageApplied('package_test_0001','desktop-local',{}).duplicate, true, 'El ACK tras interrupción debe ser idempotente');
  equal(store2.markPackage('package_test_0001','rejected').code, 'INVALID_STATUS_TRANSITION', 'No permite sobrescribir paquete conciliado');

  const missingProductId = signedDevicePackage({ privateKey: kp.privateKey, publicKey: publicPem, packageId: 'package_test_0005', deviceId: 'device_test_0002', type: 'sale_batch', payload: { schemaVersion: 1, transactions: [{ id: 'sale_missing_product_id', posId: 'pos_test_0001', items: [{ name: 'Arroz' }] }] } });
  equal(store2.importOfflineBundle(JSON.stringify(missingProductId)).code, 'PACKAGE_PRODUCT_ID_REQUIRED', 'Un paquete comercial sin identidad estable de producto se rechaza antes de guardarlo');
  try { store2.createDesktopBundle('transfer', { source: 'pos_test_0001', destination: 'pos_test_0001', product: 'Arroz' }); throw new Error('Debió rechazar transferencia sin productId.'); } catch (e) { if (e.code !== 'PACKAGE_PRODUCT_ID_REQUIRED') throw e; assertions++; }

  const desktopBundle = JSON.parse(store2.createDesktopBundle('inventory_snapshot',{schemaVersion:1,inventory:[]}));
  equal(desktopBundle.format, 'procontrol.offline-package', 'La exportación usa el formato de paquete documentado');
  ok(crypto.verify(null, signedFields(desktopBundle), crypto.createPublicKey(desktopBundle.signerPublicKey), Buffer.from(desktopBundle.signature.value,'base64')), 'El paquete del escritorio debe llevar firma válida');
  const descriptor = JSON.parse(store2.createPairingDescriptor({ code:'123456', role:'operator', posId:'pos_test_0001', expiresAt:Date.now()+120000 }));
  ok(crypto.verify(null, signedFields(descriptor), crypto.createPublicKey(descriptor.desktopPublicKey), Buffer.from(descriptor.signature.value,'base64')), 'La ficha de vinculación debe estar firmada');
  equal(store2.setDeviceEnabled('device_test_0002', false).ok, true, 'Debe revocar el dispositivo');
  const afterRevocation = signedDevicePackage({ privateKey: kp.privateKey, publicKey: publicPem, packageId: 'package_test_0004', deviceId: 'device_test_0002', type: 'heartbeat', payload: { sentAt: new Date().toISOString() } });
  equal(store2.importOfflineBundle(JSON.stringify(afterRevocation)).code, 'DEVICE_NOT_AUTHORIZED', 'Un dispositivo revocado no puede importar');
  ok(store2.status().networkListener === false, 'El modo de red debe seguir apagado');
  console.log(`Mobile bridge final: ${assertions} assertions passed.`);
} finally {
  try { if (store2) store2.close(); } catch (_) {}
  fs.rmSync(dir, { recursive: true, force: true });
}
