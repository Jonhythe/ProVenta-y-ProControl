'use strict';

const assert = require('node:assert/strict');
const { isTrustedAppNavigation, isPrintPopupUrl } = require('../electron/security/navigation-policy');

for (const page of ['license.html', 'splash.html', 'index.html']) {
  assert.equal(isTrustedAppNavigation(`app://${page}`), true, `${page} debe ser una navegación interna permitida.`);
}

for (const url of [
  'https://example.com/',
  'file:///C:/Windows/win.ini',
  'app://attacker.html/',
  'app://index.html/renderer/index.html',
  'app://user@index.html/',
  'app://index.html:1234/',
  'javascript:alert(1)',
  'not a URL',
  `app://${'a'.repeat(2049)}.html/`,
]) {
  assert.equal(isTrustedAppNavigation(url), false, `${url.slice(0, 80)} debe bloquearse como navegación principal.`);
}

assert.equal(isPrintPopupUrl('about:blank'), true, 'La impresión usa una ventana about:blank controlada.');
assert.equal(isPrintPopupUrl('https://example.com/'), false, 'Las ventanas emergentes externas deben bloquearse.');
assert.equal(isPrintPopupUrl('app://index.html'), false, 'Una ventana emergente no debe abrir la aplicación.');

console.log('Electron navigation policy: 15 comprobaciones aprobadas.');
