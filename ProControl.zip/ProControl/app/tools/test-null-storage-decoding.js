#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'renderer', 'index.html'), 'utf8');
const Security = require('../renderer/security');

const encodedNull = Security.obfuscate(null);
const decodedNull = Security.tryDeobfuscate(encodedNull);
assert.deepEqual(decodedNull, { ok: true, value: null }, 'null guardado debe reconocerse como dato válido');
assert.equal(Security.deobfuscate(encodedNull), null, 'la API compatible conserva el valor null');

const sample = { version: 1, passwordWrap: 'p', recoveryWrap: 'r' };
const decodedObject = Security.tryDeobfuscate(Security.obfuscate(sample));
assert.equal(decodedObject.ok, true);
assert.deepEqual(decodedObject.value, sample, 'los objetos existentes deben seguir decodificándose');
assert.equal(Security.tryDeobfuscate(btoa('OTRO_PREFIJO:bnVsbA==')).ok, false, 'los datos no válidos deben seguir detectándose');

const loadSecureStart = html.indexOf('const loadSecure = (key, defaultValue) =>');
const loadSecureEnd = html.indexOf('// Validadores:', loadSecureStart);
assert.ok(loadSecureStart >= 0 && loadSecureEnd > loadSecureStart, 'debe existir loadSecure');
const loadSecure = html.slice(loadSecureStart, loadSecureEnd);
assert.match(loadSecure, /const decoded = Security\.tryDeobfuscate\(raw\);/);
assert.match(loadSecure, /if \(decoded\.ok\) return decoded\.value;/);
assert.match(loadSecure, /JSON\.parse\(raw\)/, 'debe conservar compatibilidad con datos planos antiguos');

console.log('PASS - null ofuscado se recupera como null válido, sin marcar corrupción.');
console.log('PASS - objetos válidos, compatibilidad con datos planos y detección de datos inválidos.');
