'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const nodeCrypto = require('node:crypto');
const { RecordArchiveStore, FILE_RE } = require('../electron/record-archive-store');

let passed = 0;
function check(name, fn) {
  try { fn(); passed++; console.log(`PASS - ${name}`); }
  catch (error) { console.error(`FAIL - ${name}\n`, error); process.exitCode = 1; }
}
async function asyncCheck(name, fn) {
  try { await fn(); passed++; console.log(`PASS - ${name}`); }
  catch (error) { console.error(`FAIL - ${name}\n`, error); process.exitCode = 1; }
}
function loadCryptoModule() {
  const filename = path.join(__dirname, '../renderer/record-archive-crypto.js');
  const source = fs.readFileSync(filename, 'utf8');
  const btoaPoly = global.btoa || (s => Buffer.from(s, 'binary').toString('base64'));
  const atobPoly = global.atob || (s => Buffer.from(s, 'base64').toString('binary'));
  const window = {};
  vm.runInNewContext(source, {
    window,
    crypto: nodeCrypto.webcrypto,
    btoa: btoaPoly,
    atob: atobPoly,
    TextEncoder,
    TextDecoder,
    Uint8Array,
    Date,
    JSON,
    String,
    Number,
    Array,
    Object,
    Error,
    RegExp,
    Math,
    Promise,
    console
  }, { filename });
  return window.PCRecordArchiveCrypto;
}

(async () => {
  const crypto = loadCryptoModule();
  let initialized; let envelope; let payload;
  const records = [
    { recordKey: 'entries:101', record: { id: 101, supplier: 'Proveedor demostración', totalAmount: 240 } },
    { recordKey: 'entries:102', record: { id: 102, supplier: 'Proveedor prueba', totalAmount: 120 } }
  ];

  await asyncCheck('activa una bóveda cifrada y entrega recuperación solo en memoria', async () => {
    initialized = await crypto.initialize('Owner-password-987');
    assert.equal(initialized.config.version, 1);
    assert.equal(initialized.config.algorithm, 'AES-256-GCM');
    assert.match(initialized.recoveryCode, /^[0-9A-F]{4}(?:-[0-9A-F]{4}){7}$/);
    const configText = JSON.stringify(initialized.config);
    assert.equal(configText.includes('Owner-password-987'), false);
    assert.equal(configText.includes(initialized.recoveryCode), false);
    assert.ok(initialized.config.passwordWrap.ciphertext);
    assert.ok(initialized.config.recoveryWrap.ciphertext);
  });
  await asyncCheck('contraseña correcta abre y contraseña incorrecta no abre', async () => {
    const key = await crypto.unlockWithPassword('Owner-password-987', initialized.config);
    assert.ok(key);
    await assert.rejects(() => crypto.unlockWithPassword('wrong-password-123', initialized.config), /desbloquear|contraseña|código/i);
  });
  await asyncCheck('código de recuperación abre el mismo archivo cifrado', async () => {
    const key = await crypto.unlockWithRecovery(initialized.recoveryCode, initialized.config);
    assert.ok(key);
  });
  await asyncCheck('cifra y recupera los registros con la sección y día autenticados', async () => {
    envelope = await crypto.encryptArchive(initialized.key, 'entries', '2026-10-27', records);
    payload = await crypto.decryptArchive(initialized.key, envelope);
    assert.equal(payload.section, 'entries');
    assert.equal(payload.date, '2026-10-27');
    assert.deepEqual(JSON.parse(JSON.stringify(payload.records)), records);
  });
  await asyncCheck('detecta alteración de ciphertext', async () => {
    const doc = JSON.parse(envelope);
    const chars = doc.ciphertext.split('');
    chars[Math.floor(chars.length / 2)] = chars[Math.floor(chars.length / 2)] === 'A' ? 'B' : 'A';
    doc.ciphertext = chars.join('');
    await assert.rejects(() => crypto.decryptArchive(initialized.key, JSON.stringify(doc)), /alterado|no coincide|criptográfica/i);
  });
  await asyncCheck('no permite intercambiar sección o fecha sin romper la autenticación', async () => {
    const doc = JSON.parse(envelope); doc.section = 'transfers';
    await assert.rejects(() => crypto.decryptArchive(initialized.key, JSON.stringify(doc)), /alterado|no coincide|criptográfica/i);
    const docDate = JSON.parse(envelope); docDate.date = '2026-10-28';
    await assert.rejects(() => crypto.decryptArchive(initialized.key, JSON.stringify(docDate)), /alterado|no coincide|criptográfica/i);
  });
  await asyncCheck('cambio de contraseña conserva la misma clave maestra y permite recuperación', async () => {
    const oldConfig = initialized.config;
    const next = await crypto.rewrapPassword(initialized.key, 'New-owner-password-987', oldConfig);
    const unlocked = await crypto.unlockWithPassword('New-owner-password-987', next);
    const reloaded = await crypto.decryptArchive(unlocked, envelope);
    assert.equal(reloaded.records.length, 2);
    assert.equal(next.recoveryWrap.ciphertext, oldConfig.recoveryWrap.ciphertext);
  });
  await asyncCheck('rotar recuperación invalida el código anterior y conserva archivos', async () => {
    const changed = await crypto.rewrapRecovery(initialized.key, initialized.config);
    await assert.rejects(() => crypto.unlockWithRecovery(initialized.recoveryCode, changed.config));
    const recovered = await crypto.unlockWithRecovery(changed.recoveryCode, changed.config);
    assert.equal((await crypto.decryptArchive(recovered, envelope)).records.length, 2);
  });

  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-record-archive-'));
  try {
    const store = new RecordArchiveStore(temp);
    const fileName = 'v1_entries_2026-10-27_123e4567-e89b-12d3-a456-426614174000.pca';
    const sha256 = await crypto.sha256Hex(envelope);
    await asyncCheck('store escribe atómicamente solo un sobre cifrado íntegro', async () => {
      const result = store.writeEncrypted({ fileName, contents: envelope, sha256 });
      assert.equal(result.ok, true);
      assert.equal(result.sha256, sha256);
      assert.equal(fs.existsSync(path.join(temp, 'registros-antiguos', fileName)), true);
      assert.equal(fs.readdirSync(path.join(temp, 'registros-antiguos')).some(n => n.endsWith('.part')), false);
    });
    check('store aplica permisos restrictivos a la carpeta y al archivo (en sistemas POSIX)', () => {
      if (process.platform !== 'win32') {
        assert.equal(fs.statSync(path.join(temp, 'registros-antiguos')).mode & 0o077, 0);
        assert.equal(fs.statSync(path.join(temp, 'registros-antiguos', fileName)).mode & 0o077, 0);
      }
    });
    await asyncCheck('store verifica huella al indexar y devuelve el contenido cifrado', async () => {
      const result = store.readEncrypted(fileName);
      assert.equal(result.sha256, sha256);
      assert.equal((await crypto.decryptArchive(initialized.key, result.contents)).records.length, 2);
      const inspect = store.inspectFiles([fileName, 'v1_sessions_2026-10-26_123e4567-e89b-12d3-a456-426614174000.pca']);
      assert.equal(inspect.files.find(f => f.fileName === fileName).indexed, true);
      assert.equal(inspect.missing.length, 1);
    });
    await asyncCheck('rechaza escritura con hash incorrecto y nunca sustituye un archivo existente', async () => {
      assert.throws(() => store.writeEncrypted({ fileName: 'v1_entries_2026-10-27_123e4567-e89b-12d3-a456-426614174001.pca', contents: envelope, sha256: '0'.repeat(64) }), /HASH_MISMATCH/);
      assert.throws(() => store.writeEncrypted({ fileName, contents: envelope, sha256 }), /ALREADY_EXISTS/);
      assert.equal(store.readEncrypted(fileName).sha256, sha256);
    });
    check('rechaza rutas y nombres que intentan escapar de la carpeta', () => {
      assert.throws(() => store.readEncrypted('../procontrol.db'), /NAME_INVALID/);
      assert.throws(() => store.writeEncrypted({ fileName: 'v1_entries_2026-10-27_123e4567-e89b-12d3-a456-426614174000.pca/../x', contents: envelope, sha256 }), /NAME_INVALID/);
      assert.equal(FILE_RE.test(fileName), true);
      assert.equal(FILE_RE.test('v1_123e4567-e89b-12d3-a456-426614174099.pca'), true);
      assert.equal(FILE_RE.test('v1_entries_2026-10-27_123e4567-e89b-12d3-a456-426614174099.pca'), true);
      assert.equal(FILE_RE.test('v1_entries_2026-10-27_no-es-id.pca'), false);
    });
    check('no crea archivos para sobres con formato incorrecto', () => {
      assert.throws(() => store.writeEncrypted({ fileName: 'v1_entries_2026-10-27_123e4567-e89b-12d3-a456-426614174002.pca', contents: '{"hello":"world"}', sha256: '0'.repeat(64) }), /ENVELOPE_INVALID|HASH_MISMATCH/);
      assert.equal(fs.readdirSync(path.join(temp, 'registros-antiguos')).filter(n => n.endsWith('.pca')).length, 1);
    });
    await asyncCheck('la compactación elimina solo un archivo cifrado con huella exacta', async () => {
      const oldName = 'v1_entries_2026-10-26_123e4567-e89b-12d3-a456-426614174003.pca';
      store.writeEncrypted({ fileName: oldName, contents: envelope, sha256 });
      assert.throws(() => store.deleteEncrypted(oldName, '0'.repeat(64)), /ARCHIVE_HASH_MISMATCH/);
      assert.equal(store.readEncrypted(oldName).sha256, sha256);
      const deleted = store.deleteEncrypted(oldName, sha256);
      assert.equal(deleted.ok, true);
      assert.equal(fs.existsSync(path.join(temp, 'registros-antiguos', oldName)), false);
    });
  } finally { fs.rmSync(temp, { recursive: true, force: true }); }

  const indexHtml = fs.readFileSync(path.join(__dirname, '../renderer/index.html'), 'utf8');
  const mainJs = fs.readFileSync(path.join(__dirname, '../electron/main.js'), 'utf8');
  const preloadJs = fs.readFileSync(path.join(__dirname, '../electron/preload.js'), 'utf8');
  check('la UI define el archivado por secciones y conserva el umbral de 50', () => {
    assert.match(indexHtml, /const RecordArchiveUI/);
    assert.match(indexHtml, /LIMIT: 50/);
    assert.match(indexHtml, /record-archive-overlay/);
    assert.match(indexHtml, /const fileName = `v1_\$\{createStableId\(\)\}\.pca`/);
    assert.match(indexHtml, /payload\.records\.some\(\(record, i\) => !record \|\| !Array\.isArray\(meta\.recordKeys\)/);
    assert.match(indexHtml, /const payload = await PCRecordArchiveCrypto\.decryptArchive\(this\.masterKey, full\.contents\)/);
    assert.match(indexHtml, /solo el Dueño|Acceso exclusivo del Dueño/i);
  });
  check('UI prohíbe archivar sesiones abiertas y transferencias no terminales', () => {
    assert.match(indexHtml, /if \(section === 'sessions'\) return !!\(record\.logout/);
    assert.match(indexHtml, /'returned', 'cancelled', 'canceled', 'received', 'completed', 'closed', 'reconciled'/);
    assert.match(indexHtml, /record\.confirmed === false \|\| record\.pendingConfirmation === true \|\| record\.mobilePending === true/);
  });
  check('los archivos se escriben y verifican antes de actualizar los registros activos', () => {
    const writePos = indexHtml.indexOf("writeRecordArchiveFile({ authToken: this.authToken");
    const verifyPos = indexHtml.indexOf('const verified = await PCRecordArchiveCrypto.decryptArchive', writePos);
    const removePos = indexHtml.indexOf('source.splice(0, source.length, ...replacement)', verifyPos);
    assert.ok(writePos > 0 && verifyPos > writePos && removePos > verifyPos);
  });
  check('la bóveda se bloquea al cerrar la sesión del Dueño', () => assert.match(indexHtml, /RecordArchiveUI\.lock\(\);\s*this\.clearAuthFields\(\)/));
  check('la bóveda se bloquea y borra la vista al cerrar o expirar el permiso', () => {
    assert.match(indexHtml, /_lockTimer:\s*null/);
    assert.match(indexHtml, /_scheduleLockExpiry\(\)[\s\S]*this\.lock\(\)[\s\S]*La autorización del Dueño expiró por seguridad/);
    assert.match(indexHtml, /async authenticateOwner\(password\)[\s\S]*this\._scheduleLockExpiry\(\)/);
    assert.match(indexHtml, /close\(\) \{[\s\S]*this\.lock\(\)[\s\S]*record-archive-overlay/);
    assert.match(indexHtml, /record-archive-recovery-code/);
    assert.match(indexHtml, /shownRecoveryCode\.textContent = ''/);
    assert.match(indexHtml, /record-archive-record-json/);
  });
  check('la clave privada, los datos comerciales y la contraseña no entran en el archivo', () => {
    assert.doesNotMatch(fs.readFileSync(path.join(__dirname, '../electron/record-archive-store.js'), 'utf8'), /license_private\.pem|license\.dat/);
    assert.match(indexHtml, /passwordWrap/);
    assert.match(indexHtml, /recoveryWrap/);
  });
  check('los IPC de archivos exigen rol Dueño y licencia válida', () => {
    assert.match(mainJs, /function requireArchiveOwner[\s\S]*actor\.role !== 'Dueño'[\s\S]*!license\.isLicensed\(\)/);
    assert.match(mainJs, /record-archive:read-file/);
    assert.match(mainJs, /record-archive:write-file/);
    assert.match(preloadJs, /readRecordArchiveFile/);
    assert.match(preloadJs, /writeRecordArchiveFile/);
    assert.match(mainJs, /record-archive:delete-superseded/);
    const deleteHandler = mainJs.slice(mainJs.indexOf("ipcMain.handle('record-archive:delete-superseded'"), mainJs.indexOf("ipcMain.handle('license:status'"));
    assert.match(deleteHandler, /meta\.superseded !== true/);
    assert.match(deleteHandler, /ARCHIVE_STILL_REFERENCED/);
    assert.match(deleteHandler, /ARCHIVE_COMPACTION_BLOCKED/);
    assert.match(deleteHandler, /hasOrphans/);
    assert.match(deleteHandler, /deleteEncrypted\(fileName, meta\.sha256\)/);
    assert.match(preloadJs, /deleteSupersededRecordArchiveFile/);
  });
  check('la comprobación de inicio es de solo lectura y detecta huellas faltantes o distintas', () => {
    assert.match(mainJs, /record-archive:startup-check/);
    const startupHandler = mainJs.slice(mainJs.indexOf("ipcMain.handle('record-archive:startup-check'"), mainJs.indexOf("ipcMain.handle('record-archive:list-files'"));
    assert.match(startupHandler, /inspectFiles\(allNames\)/);
    assert.match(startupHandler, /problemCount/);
    assert.doesNotMatch(startupHandler, /unlinkSync|rmSync|writeEncrypted/);
    assert.match(preloadJs, /checkRecordArchiveStartup/);
  });
  check('el respaldo incluye todos los archivos cifrados y verifica antes de restaurar el índice principal', () => {
    assert.match(indexHtml, /const recordArchives = await RecordArchiveUI\.createBackupBundle\(\)/);
    assert.match(indexHtml, /async createBackupBundle\(\)/);
    assert.match(indexHtml, /async validateBackupBundle\(backup\)/);
    assert.match(indexHtml, /async restoreBackupBundle\(bundle, backup\)/);
    const importStart = indexHtml.indexOf('async importFromInput(input)');
    const validatePos = indexHtml.indexOf('await RecordArchiveUI.validateBackupBundle(backup)', importStart);
    const restorePos = indexHtml.indexOf('await RecordArchiveUI.restoreBackupBundle(archiveBundle, backup)', importStart);
    const replacePos = indexHtml.indexOf('const replacements = entries.map', importStart);
    assert.ok(importStart >= 0 && validatePos > importStart && restorePos > validatePos && replacePos > restorePos);
    assert.match(indexHtml, /respaldo contiene referencias a registros antiguos pero no incluye sus archivos cifrados/);
    assert.match(indexHtml, /los respaldos previos podían incluir revisiones superseded/i);
    assert.match(indexHtml, /await this\.cleanupSuperseded\(\)/);
    assert.match(indexHtml, /if \(activeInvalid \|\| hasOrphans\)/);
  });
  check('la vista de archivos presenta un resumen entendible y conserva el detalle técnico', () => {
    assert.match(indexHtml, /_recordSummary\(section, record\)/);
    assert.match(indexHtml, /record-archive-record-summary/);
    assert.match(indexHtml, /Ver detalle completo del registro \(avanzado\)/);
    assert.match(indexHtml, /record-archive-record-summary'\); if \(summary\) summary\.textContent = ''/);
  });
  check('el bloqueo limpia credenciales temporales y evita archivado automático concurrente', () => {
    assert.match(indexHtml, /this\._pendingTransferCredentials = null/);
    assert.match(indexHtml, /if \(!this\.isUnlocked\(\) \|\| this\._autoBusy \|\| this\._busy \|\| this\._autoTimer\) return/);
  });
  console.log(`\nRecord archive: ${passed} comprobaciones aprobadas.`);
  if (process.exitCode) process.exit(process.exitCode);
})().catch(error => { console.error(error); process.exit(1); });
