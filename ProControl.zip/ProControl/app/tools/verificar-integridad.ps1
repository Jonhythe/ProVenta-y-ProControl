param(
    [string]$BuildDirectory
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$appRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not $BuildDirectory) {
    $candidate = Get-ChildItem -LiteralPath $appRoot -Directory -Filter 'dist_setup_definitivo_*' |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if (-not $candidate) { throw 'No hay ninguna carpeta dist_setup_definitivo_* para verificar.' }
    $BuildDirectory = $candidate.FullName
}

$BuildDirectory = (Resolve-Path -LiteralPath $BuildDirectory).Path
$manifestPath = Join-Path $BuildDirectory 'PROCONTROL_NSIS_BUILD.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw "Falta el manifiesto: $manifestPath" }
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ([int]$manifest.schemaVersion -ne 2) { throw 'Esquema de manifiesto no reconocido. Este script solo verifica; no reconstruye.' }

$setupPath = [string]$manifest.setupPath
if (-not (Test-Path -LiteralPath $setupPath -PathType Leaf)) {
    $setupPath = Join-Path $BuildDirectory ([string]$manifest.setupFile)
}
if (-not (Test-Path -LiteralPath $setupPath -PathType Leaf)) { throw "No existe el Setup esperado: $setupPath" }

$expectedHash = ([string]$manifest.sha256).ToUpperInvariant()
$expectedSize = [int64]$manifest.sizeBytes
$hash1 = (Get-FileHash -LiteralPath $setupPath -Algorithm SHA256).Hash.ToUpperInvariant()
$size1 = (Get-Item -LiteralPath $setupPath).Length
Start-Sleep -Seconds 2
$hash2 = (Get-FileHash -LiteralPath $setupPath -Algorithm SHA256).Hash.ToUpperInvariant()
$size2 = (Get-Item -LiteralPath $setupPath).Length

if ($hash1 -ne $expectedHash -or $hash2 -ne $expectedHash -or $size1 -ne $expectedSize -or $size2 -ne $expectedSize) {
    throw "INTEGRIDAD FALLIDA. Esperado SHA256=$expectedHash / bytes=$expectedSize; actual SHA256=$hash2 / bytes=$size2. No se reconstruyo ni modifico ningun archivo."
}

& node.exe (Join-Path $appRoot 'tools\nsis-integrity.js') $setupPath
$code = $LASTEXITCODE
if ($code -ne 0) { throw "La comprobacion estructural/CRC NSIS devolvio codigo $code." }

Write-Host "`nINTEGRIDAD APROBADA (solo lectura)." -ForegroundColor Green
Write-Host "Archivo: $setupPath"
Write-Host "Bytes: $size2"
Write-Host "SHA256: $hash2"
Write-Host 'No se compilo, no se sobrescribio y no se modifico ningun manifiesto.'
