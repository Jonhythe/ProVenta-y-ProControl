#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$SourceDirectory,
    [Parameter(Mandatory = $true)][string]$ZipPath
)
$ErrorActionPreference = 'Stop'
$source = [System.IO.Path]::GetFullPath($SourceDirectory)
$zip = [System.IO.Path]::GetFullPath($ZipPath)
if (-not (Test-Path -LiteralPath $source -PathType Container)) { throw "No existe la carpeta de entrega: $source" }
if (Test-Path -LiteralPath $zip) { throw "El ZIP ya existe; no se sobrescribirá: $zip" }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory(
    $source,
    $zip,
    [System.IO.Compression.CompressionLevel]::Optimal,
    $false
)
if (-not (Test-Path -LiteralPath $zip -PathType Leaf)) { throw 'No se creó el ZIP.' }
Write-Host "ZIP creado temporalmente: $zip"
