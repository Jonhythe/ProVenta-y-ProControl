"use strict";
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Core = require('../renderer/business-management.js');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log(`OK ${passed}: ${name}`); }

test('carga los datos reales del producto: precio de venta, coste, unidad y existencia', () => {
  const rice = Core.priceSimulatorProductDefaults({ id: 'rice-01', name: 'Arroz', sale: 200, cost: 145, unit: 'lb', qty: 32 });
  assert.deepEqual(rice, { productId: 'rice-01', name: 'Arroz', unit: 'lb', currentPrice: 200, unitCost: 145, stock: 32 });
});

test('acepta coste unitario cero, existencia cero y unidad base predeterminada', () => {
  const product = Core.priceSimulatorProductDefaults({ id: 'p2', name: 'Producto', sale: 50, cost: 0, qty: 0 });
  assert.equal(product.unitCost, 0);
  assert.equal(product.stock, 0);
  assert.equal(product.unit, 'u');
});

test('respeta la existencia cero del campo principal y no utiliza una cantidad secundaria antigua', () => {
  const product = Core.priceSimulatorProductDefaults({ id: 'p-zero', name: 'Agotado', sale: 20, cost: 12, qty: 0, quantity: 9 });
  assert.equal(product.stock, 0);
});

test('no inventa precio, coste ni existencia si el producto no contiene esos datos', () => {
  const product = Core.priceSimulatorProductDefaults({ id: 'p3', name: 'Sin datos' });
  assert.equal(product.currentPrice, null);
  assert.equal(product.unitCost, null);
  assert.equal(product.stock, null);
});

test('un precio propuesto de 220 CUP puede compararse contra arroz a 200 CUP y coste de 145 CUP', () => {
  const product = Core.priceSimulatorProductDefaults({ id: 'rice-01', name: 'Arroz', sale: 200, cost: 145, unit: 'lb', qty: 10 });
  const result = Core.simulatePrice(product.stock, product.currentPrice, 220, product.unitCost);
  assert.equal(result.currentRevenue, 2000);
  assert.equal(result.newRevenue, 2200);
  assert.equal(result.currentGrossProfit, 550);
  assert.equal(result.newGrossProfit, 750);
});

test('la vista permite elegir un producto de prueba y aclara que la simulación no modifica inventario ni precios', () => {
  const source = fs.readFileSync(path.join(__dirname, '../renderer/business-management.js'), 'utf8');
  assert.match(source, /id="pcbm-price-product"/);
  assert.match(source, /Producto de prueba/);
  assert.match(source, /Core\.priceSimulatorProductDefaults\(product\)/);
  assert.match(source, /priceSimulatorProductDefaults,simulateStock/);
  assert.match(source, /no modifica inventario, compras ni precios guardados/i);
  assert.match(source, /proposed\.value=''/);
});

console.log(`Resultado: ${passed} pruebas aprobadas, 0 fallidas.`);
