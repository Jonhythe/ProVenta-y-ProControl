'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');

// El cierre actual registra la cantidad final en la unidad base; se mantienen
// los datos históricos de cajas, pero ya no se muestran controles separados.
assert.match(html, /data-count-kind="single"/, 'El cierre debe tener un campo único de cantidad final.');
assert.doesNotMatch(html, /data-count-kind="box"|data-count-kind="unit"/, 'El cierre no debe mostrar entradas separadas de cajas y unidades sueltas.');
assert.match(html, /session\.counts\[key\] = Number\(raw\)/, 'El cierre debe guardar la cantidad introducida en la unidad base.');
assert.match(html, /session\.countErrors\[key\] = `Introduzca una cantidad válida en/, 'Un conteo inválido debe quedar marcado y no aprobar el cierre.');
assert.match(html, /_formatClosingCount\(item, quantity\)/, 'El conteo debe mostrar una explicación de la cantidad registrada.');
assert.match(html, /closing-count-breakdown/, 'La tabla de cierre debe mostrar la cantidad en tiempo real.');
assert.match(html, /this\.formatQuantity\(item, row\.stock\)/, 'El stock inicial debe mostrarse con la unidad del producto.');
assert.match(html, /const formatClosingHistoryQty =/, 'El detalle histórico debe formatear cantidades en unidad base.');
assert.match(html, /formatClosingHistoryQty\(p, p\.sold\)/, 'El historial de cierre debe presentar las cantidades vendidas con su unidad.');
assert.match(html, /formatQuantityCompact\(item, qty\)/, 'Los inventarios compactos deben usar el formato unificado de cantidades.');
console.log('OK: cierre con cantidad única en unidad base, validación de errores y sin scroll horizontal forzado.');
