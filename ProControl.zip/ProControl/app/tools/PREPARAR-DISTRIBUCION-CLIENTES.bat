@echo off
setlocal
set "SCRIPT=%~dp0preparar-distribucion-clientes.ps1"
if not exist "%SCRIPT%" (
  echo No se encontro preparar-distribucion-clientes.ps1.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
  echo.
  echo ERROR: no se completo la preparacion. La carpeta anterior de clientes se ha conservado.
  pause
  exit /b %RESULT%
)
echo.
echo ProControl esta preparado: solo el instalador Setup se encuentra en la carpeta ProControl.
pause
endlocal
