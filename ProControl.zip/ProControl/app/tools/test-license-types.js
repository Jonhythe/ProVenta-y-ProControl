'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const core = require('../electron/license-core');
const { parseArgs: parseInstallationLicenseArgs, ROTATION_LOCK_PATH: installationRotationLock } = require(require('node:path').resolve(__dirname, '..', '..', 'licensor', 'emitir-licencia.js'));
const { ROTATION_LOCK_PATH: posRotationLock } = require(require('node:path').resolve(__dirname, '..', '..', 'licensor', 'emitir-licencia-pos.js'));
const fs = require('node:fs');
const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
const deviceId = 'A'.repeat(32);
function sign(payload) {
  const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const signed = Buffer.from('PCL1.' + payloadB64, 'ascii');
  const signature = crypto.sign(null, signed, privateKey).toString('base64url');
  return `PCL1.${payloadB64}.${signature}`;
}
const base = { v:1, app:'procontrol', plan:'permanent', deviceId, licenseId:'TEST-1' };
const oldInstallation = sign({ ...base, customer:'legacy' });
const install = core.verifyLicense(oldInstallation,{publicKey,deviceId,expectedType:'installation'});
assert.equal(install.ok,true,'PCL1 legado sin tipo sigue siendo licencia de instalación');
assert.deepEqual(install.payload.allowedModes, ['SIN_APP'], 'las licencias antiguas solo autorizan SIN_APP por defecto');
assert.ok(install.payload.modules.includes('pos'), 'las licencias antiguas conservan compatibilidad con POS');
const pointToken = sign({ ...base, licenseType:'point-of-sale', installationMachineId:deviceId, posId:'pos_01', posName:'Caja Principal' });
assert.equal(core.verifyLicense(pointToken,{publicKey,deviceId,expectedType:'installation'}).ok,false,'token POS no se acepta como licencia de instalación');
const pos = core.verifyLicense(pointToken,{publicKey,deviceId,expectedType:'point-of-sale'});
assert.equal(pos.ok,true,'token POS válido se acepta como licencia POS');
assert.equal(pos.payload.posId,'pos_01');
assert.equal(core.verifyLicense(sign({ ...base, licenseType:'point-of-sale', installationMachineId:deviceId, posName:'Caja Principal' }),{publicKey,deviceId,expectedType:'point-of-sale'}).ok,false,'token POS sin posId se rechaza');
assert.equal(core.verifyLicense(sign({ ...base, licenseType:'point-of-sale', posId:'pos_01', posName:'Caja Principal' }),{publicKey,deviceId,expectedType:'point-of-sale'}).ok,false,'token POS sin installationMachineId se rechaza');
assert.equal(core.verifyLicense(sign({ ...base, licenseType:'point-of-sale', installationMachineId:'F'.repeat(32), posId:'pos_01', posName:'Caja Principal' }),{publicKey,deviceId,expectedType:'point-of-sale'}).code,'OTRA_PC','installationMachineId tiene que coincidir con deviceId');
assert.equal(core.verifyLicense(sign({ ...base, licenseType:'installation', posId:'pos_01', posName:'Caja Principal' }),{publicKey,deviceId,expectedType:'installation'}).ok,false,'token de instalación no puede incluir campos POS');
assert.equal(core.verifyLicense(sign({ ...base, licenseType:'unknown' }),{publicKey,deviceId,expectedType:'installation'}).ok,false,'tipo desconocido se rechaza');
assert.throws(() => parseInstallationLicenseArgs([deviceId, 'Prueba', '--modo-con-app']), /CON APP permanece bloqueado/,'el emisor no permite autorizar CON_APP antes de la app móvil');
if (fs.existsSync(installationRotationLock) || fs.existsSync(posRotationLock)) {
  assert.equal(fs.existsSync(installationRotationLock) && fs.existsSync(posRotationLock), true, 'el bloqueo de rotación cubre ambos emisores');
}
const mobileInstall = core.verifyLicense(sign({ ...base, licenseType:'installation', modules:['core','pos','mobile-integration'], allowedModes:['SIN_APP','CON_APP'] }),{publicKey,deviceId,expectedType:'installation'});
assert.equal(mobileInstall.ok,true,'instalación autorizada puede declarar módulo y modo móvil');
assert.equal(core.verifyLicense(sign({ ...base, licenseType:'installation', modules:['core','pos'], allowedModes:['SIN_APP','CON_APP'] }),{publicKey,deviceId,expectedType:'installation'}).ok,false,'CON_APP requiere el módulo mobile-integration');
assert.equal(core.verifyLicense(sign({ ...base, licenseType:'installation', modules:['core','inventado'], allowedModes:['SIN_APP'] }),{publicKey,deviceId,expectedType:'installation'}).ok,false,'módulos desconocidos se rechazan');
assert.equal(core.verifyLicense(sign({ ...base, licenseType:'point-of-sale', posId:'pos_01', posName:'Caja', modules:['pos'] }),{publicKey,deviceId,expectedType:'point-of-sale'}).ok,false,'la licencia POS no puede transportar permisos de instalación');
console.log('License type/module tests passed.');
