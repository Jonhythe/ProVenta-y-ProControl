#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const ROOT = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));

function installedVersion(packageName) {
  let entry;
  try {
    entry = require.resolve(packageName, { paths: [ROOT] });
  } catch (error) {
    throw new Error(`No se puede resolver ${packageName}: ${error.message}`);
  }
  let dir = path.dirname(entry);
  while (true) {
    const manifest = path.join(dir, 'package.json');
    if (fs.existsSync(manifest)) {
      const candidate = JSON.parse(fs.readFileSync(manifest, 'utf8'));
      if (candidate.name === packageName) return candidate.version;
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  throw new Error(`No se encontro package.json de ${packageName}.`);
}

const expected = {
  'electron-builder': '26.18.1',
  'app-builder-lib': '26.18.1',
  'builder-util': '26.18.1',
  'dmg-builder': '26.18.1',
  'builder-util-runtime': '9.7.1',
};
const results = {};
for (const [name, wanted] of Object.entries(expected)) {
  const actual = installedVersion(name);
  results[name] = actual;
  assert.equal(actual, wanted, `${name}: se esperaba ${wanted}, se encontro ${actual}`);
}
assert.equal(pkg.devDependencies && pkg.devDependencies['electron-builder'], '26.18.1',
  'package.json debe fijar electron-builder 26.18.1.');
assert.equal(pkg.devDependencies && pkg.devDependencies.electron, '39.8.10',
  'La version de Electron debe seguir fijada en 39.8.10.');

console.log('NSIS TOOLCHAIN: PASS');
console.log(JSON.stringify(results, null, 2));
