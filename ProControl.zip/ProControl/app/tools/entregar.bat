@echo off
setlocal
rem ============================================================
rem PROCONTROL - ENTREGA NSIS UNICA (flujo antiguo redirigido)
rem No copia Uninstall-ProControl.exe: es un desinstalador C# separado
rem y NO es el desinstalador NSIS registrado por electron-builder.
rem ============================================================

set "SCRIPT=%~dp0preparar-distribucion-clientes.ps1"
if not exist "%SCRIPT%" (
  echo ERROR: no se encontro %SCRIPT%
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
if errorlevel 1 (
  echo ERROR: no se pudo preparar la distribucion ProControl.
  exit /b 1
)

echo.
echo Entrega NSIS preparada correctamente.
exit /b 0
