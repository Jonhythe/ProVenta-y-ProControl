'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');
const checks = [
  ['el panel calcula las alertas manualmente a partir del inventario', /const stockAlertResults = appState\.inventory\.map\(\(item, index\) =>/.test(html)],
  ['el límite individual puede venir de la configuración del producto', /cfg\.alertStock \?\? cfg\.manualMinimum \?\? item\.minimumStock/.test(html)],
  ['el estado crítico depende de llegar al límite configurado', /qty <= threshold \? 'critical'/.test(html)],
  ['el aviso preventivo cubre hasta diez unidades por encima', /const warningThreshold = threshold \+ 10/.test(html) && /qty <= warningThreshold \? 'reorder'/.test(html)],
  ['el KPI de stock crítico usa los mismos resultados que la lista', /const criticalItems = stockAlertResults\.filter\(result => result\.status === 'critical'\)/.test(html)],
  ['la lista muestra todos los productos críticos o en aviso', /stockAlertResults\.filter\(result => result\.status !== 'ok'\)/.test(html)],
  ['hay acceso a configurar cada producto', /StockAlertSettings\.open\(\$\{Number\(alert\.index\)\}\)/.test(html)],
  ['existe la ventana de configuración manual', /id="stock-alert-settings-overlay"/.test(html)],
  ['la configuración permite elegir producto y stock de alerta', /id="stock-alert-product"/.test(html) && /id="stock-alert-quantity"/.test(html)],
  ['se guarda la configuración manual y se revierte si falla el guardado', /alertStock,\s*manualMinimum: alertStock/.test(html) && /if \(!DataStore\.save\(\)\)/.test(html)],
  ['el valor predeterminado sin configuración es diez', /item\.minQty \?\? 10/.test(html)],
  ['la vista deja claro que no necesita tickets ni cierres', /No se necesitan tickets de venta para calcular estas alertas\./.test(html) && /No necesitas tickets de venta ni cierres de caja para usar esta función\./.test(html)],
  ['la interfaz principal no sustituye los límites manuales por el motor basado en ventas', !/window\.InventoryStockAlerts\.evaluate\(appState\.inventory/.test(html) && /const stockAlertResults = appState\.inventory\.map/.test(html)],
  ['no queda un umbral universal fijo sustituyendo la configuración por producto', !/const STOCK_ALERT_THRESHOLD = 10/.test(html)]
];
let passed = 0;
for (const [name, ok] of checks) {
  try { assert.ok(ok, name); passed++; console.log(`PASS - ${name}`); }
  catch { console.error(`FAIL - ${name}`); }
}
if (passed !== checks.length) process.exit(1);
console.log(`\n${passed}/${checks.length} comprobaciones de integración de alertas manuales aprobadas.`);
