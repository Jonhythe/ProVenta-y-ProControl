'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { writeFragmentSet, readFragmentSet } = require('../electron/mobile-bridge/fragments');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-fragments-'));
let assertions = 0;
function check(value, message) { assertions++; assert.ok(value, message); }
try {
  const source = Buffer.alloc(700000);
  for (let i=0;i<source.length;i++) source[i] = (i * 31 + 17) & 255;
  const manifestPath = path.join(root, 'test-export.pcmanifest');
  const written = writeFragmentSet(source, manifestPath, { chunkSize: 128 * 1024 });
  check(written.manifest.totalChunks === 6, 'exports a multi-part manifest');
  check(written.fragmentPaths.every(f => fs.existsSync(f)), 'all fragment files are created');
  const loaded = readFragmentSet(manifestPath);
  check(loaded.contents.equals(source), 'reassembles byte-exact source');
  check(loaded.manifest.totalSha256 === written.manifest.totalSha256, 'total SHA-256 is preserved');
  assert.throws(() => writeFragmentSet(source, manifestPath, { chunkSize: 128 * 1024 }), e => e && e.code === 'MANIFEST_ALREADY_EXISTS');
  assertions++;
  const first = written.fragmentPaths[0];
  const original = fs.readFileSync(first);
  const changed = Buffer.from(original); changed[0] ^= 0xff; fs.writeFileSync(first, changed);
  assert.throws(() => readFragmentSet(manifestPath), e => e && e.code === 'FRAGMENT_HASH_MISMATCH');
  assertions++;
  fs.writeFileSync(first, original);
  fs.unlinkSync(written.fragmentPaths[1]);
  assert.throws(() => readFragmentSet(manifestPath), e => e && e.code === 'FRAGMENT_MISSING');
  assertions++;
  const parsed = JSON.parse(fs.readFileSync(manifestPath,'utf8'));
  parsed.fragments[0].name = '../../evil.pcfrag';
  const badPath = path.join(root, 'bad.pcmanifest'); fs.writeFileSync(badPath, JSON.stringify(parsed));
  assert.throws(() => readFragmentSet(badPath), e => e && e.code === 'FRAGMENT_MANIFEST_ENTRY_INVALID');
  assertions++;
  console.log(`Offline fragments tests: ${assertions} assertions passed.`);
} finally { fs.rmSync(root, { recursive:true, force:true }); }
