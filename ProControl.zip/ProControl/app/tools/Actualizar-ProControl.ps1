﻿#requires -Version 5.1
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Section([string]$Text) {
    Write-Host ''
    Write-Host ('=' * 68) -ForegroundColor DarkCyan
    Write-Host $Text -ForegroundColor Cyan
    Write-Host ('=' * 68) -ForegroundColor DarkCyan
}

function Get-NormalizedPath([string]$Path) {
    $full = [System.IO.Path]::GetFullPath($Path)
    $root = [System.IO.Path]::GetPathRoot($full)
    if ($full -ieq $root) { return $full }
    return $full.TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
}

function Test-SameOrChildPath([string]$Candidate, [string]$Parent) {
    $candidateFull = Get-NormalizedPath $Candidate
    $parentFull = Get-NormalizedPath $Parent
    if ($candidateFull -ieq $parentFull) { return $true }
    $prefix = $parentFull
    if (-not $prefix.EndsWith([System.IO.Path]::DirectorySeparatorChar)) {
        $prefix += [System.IO.Path]::DirectorySeparatorChar
    }
    return $candidateFull.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)
}

function Get-RelativeFiles([string]$Root) {
    $rootFull = Get-NormalizedPath $Root
    $prefix = $rootFull
    if (-not $prefix.EndsWith([System.IO.Path]::DirectorySeparatorChar)) {
        $prefix += [System.IO.Path]::DirectorySeparatorChar
    }
    $result = @()
    foreach ($file in (Get-ChildItem -LiteralPath $rootFull -File -Recurse -Force)) {
        $relative = $file.FullName.Substring($prefix.Length).Replace('\', '/')
        $result += [pscustomobject]@{ RelativePath = $relative; FullName = $file.FullName; Length = [long]$file.Length }
    }
    return $result
}

function Test-PayloadManifest([string]$Root, $Manifest) {
    $rootFull = Get-NormalizedPath $Root
    if ([int]$Manifest.schemaVersion -ne 2 -or $Manifest.product -ne 'ProControl' -or
        $Manifest.architecture -ne 'x64' -or $Manifest.target -ne 'electron-builder-dir') {
        throw 'El manifiesto no corresponde al esquema v2 de ProControl para Windows x64.'
    }
    if ([string]::IsNullOrWhiteSpace([string]$Manifest.version) -or -not $Manifest.files) {
        throw 'El manifiesto está incompleto o no contiene archivos.'
    }

    $expected = @{}
    foreach ($entry in $Manifest.files) {
        $relative = ([string]$entry.path).Replace('\', '/')
        if ([string]::IsNullOrWhiteSpace($relative) -or $relative.StartsWith('/') -or
            $relative -match '(^|/)\.\.?(/|$)' -or $relative.Contains(':')) {
            throw "Ruta no permitida en el manifiesto: $relative"
        }
        $key = $relative.ToLowerInvariant()
        if ($expected.ContainsKey($key)) { throw "El manifiesto repite una ruta: $relative" }
        $expected[$key] = $entry

        $nativeRelative = $relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar)
        $candidate = [System.IO.Path]::GetFullPath((Join-Path $rootFull $nativeRelative))
        if (-not (Test-SameOrChildPath -Candidate $candidate -Parent $rootFull) -or $candidate -ieq $rootFull) {
            throw "La ruta del manifiesto intenta salir de ProControl: $relative"
        }
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { throw "Falta un archivo del paquete: $relative" }

        $expectedSize = 0L
        if (-not [long]::TryParse([string]$entry.sizeBytes, [ref]$expectedSize) -or $expectedSize -lt 0) {
            throw "Tamaño inválido en el manifiesto para $relative."
        }
        $expectedHash = ([string]$entry.sha256).ToUpperInvariant()
        if ($expectedHash -notmatch '^[A-F0-9]{64}$') { throw "SHA-256 inválido en el manifiesto para $relative." }

        # SHA-256 es la comprobación decisiva del contenido. El tamaño es un
        # metadato auxiliar y se evalúa después del hash para no rechazar una
        # entrada cuyo contenido sí coincide exactamente con el manifiesto.
        $before = Get-Item -LiteralPath $candidate
        $actualHash = (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToUpperInvariant()
        $after = Get-Item -LiteralPath $candidate
        $actualSize = [long]$after.Length
        if ($actualHash -ne $expectedHash) {
            $hashError = (
                "SHA-256 incorrecto en {0}. El archivo no pertenece a este paquete o fue alterado. " +
                "Tamaño esperado: {1} bytes; actual: {2} bytes. SHA-256 esperado: {3}; actual: {4}. " +
                "Vuelve a extraer el ZIP completo o genera una entrega nueva; no mezcles archivos de distintas compilaciones."
            ) -f $relative, $expectedSize, $actualSize, $expectedHash, $actualHash
            throw $hashError
        }
        if ($before.Length -ne $after.Length -or $before.LastWriteTimeUtc -ne $after.LastWriteTimeUtc) {
            throw "El archivo cambió mientras se verificaba: $relative. No se instalará un paquete inestable."
        }
        if ($actualSize -ne $expectedSize) {
            Write-Warning ("El tamaño registrado para {0} no coincide ({1} frente a {2}), pero SHA-256 coincide exactamente. Se acepta el archivo verificado por contenido." -f $relative, $expectedSize, $actualSize)
        }
    }

    if ($expected.Count -ne [int]$Manifest.fileCount) {
        throw "El manifiesto declara $($Manifest.fileCount) archivos, pero contiene $($expected.Count) entradas distintas."
    }

    $actualFiles = @(Get-RelativeFiles -Root $rootFull)
    if ($actualFiles.Count -ne [int]$Manifest.fileCount) {
        throw "La carpeta tiene $($actualFiles.Count) archivos, pero el manifiesto declara $($Manifest.fileCount)."
    }
    foreach ($actual in $actualFiles) {
        if (-not $expected.ContainsKey($actual.RelativePath.ToLowerInvariant())) {
            throw "Hay un archivo no declarado en el manifiesto: $($actual.RelativePath)"
        }
    }

    if (-not (Test-Path -LiteralPath (Join-Path $rootFull 'ProControl.exe') -PathType Leaf) -or
        -not (Test-Path -LiteralPath (Join-Path $rootFull 'resources\app.asar') -PathType Leaf)) {
        throw 'La carpeta no contiene ProControl.exe y resources\app.asar.'
    }
    return $true
}

function Test-ReleaseArtifacts([string]$PackageRoot, $Manifest) {
    $required = @('Actualizar-ProControl.ps1', 'Actualizar-ProControl.bat', 'LEEME-ENTREGA.txt')
    $releaseFiles = @($Manifest.releaseFiles)
    if ($releaseFiles.Count -ne $required.Count) { throw 'El manifiesto no registra los archivos de control de la entrega.' }
    $seen = @{}
    foreach ($entry in $releaseFiles) {
        $name = [string]$entry.path
        if ($required -notcontains $name) { throw "Archivo de control no permitido: $name" }
        if ($seen.ContainsKey($name)) { throw "Archivo de control repetido en el manifiesto: $name" }
        $seen[$name] = $true
        $filePath = Join-Path $PackageRoot $name
        if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) { throw "Falta el archivo de control: $name" }
        $item = Get-Item -LiteralPath $filePath
        if ([long]$item.Length -ne [long]$entry.sizeBytes) { throw "Tamaño incorrecto en el archivo de control $name." }
        $actualHash = (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actualHash -ne ([string]$entry.sha256).ToUpperInvariant()) { throw "SHA-256 incorrecto en el archivo de control $name." }
    }
    foreach ($name in $required) { if (-not $seen.ContainsKey($name)) { throw "Falta en el manifiesto el archivo de control $name." } }
}

function Backup-UserData([string]$DataPath, [string]$BackupRoot) {
    if (-not (Test-Path -LiteralPath $DataPath -PathType Container)) { return $null }

    $destination = Join-Path $BackupRoot 'AppData-ProControl'
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    foreach ($item in (Get-ChildItem -LiteralPath $DataPath -Force)) {
        Copy-Item -LiteralPath $item.FullName -Destination $destination -Recurse -Force
    }

    $sourceFiles = @(Get-RelativeFiles -Root $DataPath)
    $copyFiles = @(Get-RelativeFiles -Root $destination)
    if ($sourceFiles.Count -ne $copyFiles.Count) {
        throw 'El respaldo de %APPDATA%\ProControl no tiene la misma cantidad de archivos. No se reemplazó el programa.'
    }
    $copyMap = @{}
    foreach ($file in $copyFiles) { $copyMap[$file.RelativePath.ToLowerInvariant()] = $file }
    foreach ($source in $sourceFiles) {
        $key = $source.RelativePath.ToLowerInvariant()
        if (-not $copyMap.ContainsKey($key)) { throw "Falta en el respaldo de datos: $($source.RelativePath)" }
        $copy = $copyMap[$key]
        if ($source.Length -ne $copy.Length) { throw "Tamaño distinto en el respaldo de datos: $($source.RelativePath)" }
        $sourceHash = (Get-FileHash -LiteralPath $source.FullName -Algorithm SHA256).Hash
        $copyHash = (Get-FileHash -LiteralPath $copy.FullName -Algorithm SHA256).Hash
        if ($sourceHash -ne $copyHash) { throw "SHA-256 distinto en el respaldo de datos: $($source.RelativePath)" }
    }
    return $destination
}

function Stop-AllProControlInstances {
    $processes = @(Get-CimInstance Win32_Process -Filter "Name='ProControl.exe'" -ErrorAction Stop)
    if ($processes.Count -eq 0) { return }
    Write-Host "Se encontraron $($processes.Count) instancia(s) de ProControl. Solicitando cierre normal..." -ForegroundColor Yellow
    foreach ($entry in $processes) {
        try {
            $process = Get-Process -Id ([int]$entry.ProcessId) -ErrorAction Stop
            [void]$process.CloseMainWindow()
        } catch {
            # We do not force-kill ProControl. The check below aborts if it remains open.
        }
    }
    $deadline = (Get-Date).AddSeconds(25)
    do {
        Start-Sleep -Milliseconds 500
        $stillRunning = @(Get-CimInstance Win32_Process -Filter "Name='ProControl.exe'" -ErrorAction Stop)
    } while ($stillRunning.Count -gt 0 -and (Get-Date) -lt $deadline)
    if ($stillRunning.Count -gt 0) {
        throw 'ProControl sigue abierto. Ciérralo manualmente y vuelve a ejecutar el BAT. No se reemplazó ningún archivo.'
    }
}

function Test-LegacyNsisInstall([string]$TargetRoot) {
    if (Test-Path -LiteralPath (Join-Path $TargetRoot 'Uninstall ProControl.exe')) { return $true }
    $registryRoots = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
    )
    foreach ($root in $registryRoots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($key in (Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
            try {
                $entry = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction Stop
                if ($entry.DisplayName -like 'ProControl*' -and $entry.UninstallString -and
                    $entry.UninstallString.IndexOf($TargetRoot, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                    return $true
                }
            } catch { }
        }
    }
    return $false
}

function New-DesktopShortcut([string]$ExePath, [string]$WorkingDirectory) {
    try {
        $desktop = [Environment]::GetFolderPath('DesktopDirectory')
        if (-not $desktop) { return }
        $shortcutPath = Join-Path $desktop 'ProControl.lnk'
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $ExePath
        $shortcut.WorkingDirectory = $WorkingDirectory
        $shortcut.Description = 'ProControl — Gestión Premium'
        $shortcut.IconLocation = "$ExePath,0"
        $shortcut.Save()
    } catch {
        Write-Warning "ProControl quedó copiado, pero no se pudo crear el acceso directo: $($_.Exception.Message)"
    }
}

try {
    Write-Section 'ACTUALIZADOR PROCONTROL — PAQUETE VERIFICADO V2'
    $packageRoot = Get-NormalizedPath $PSScriptRoot
    $payloadRoot = Join-Path $packageRoot 'ProControl'
    $manifestPath = Join-Path $packageRoot 'MANIFEST.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf) -or -not (Test-Path -LiteralPath $payloadRoot -PathType Container)) {
        throw 'No se encontraron MANIFEST.json y la carpeta ProControl. Extrae el ZIP completo antes de ejecutar el BAT.'
    }

    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Test-ReleaseArtifacts -PackageRoot $packageRoot -Manifest $manifest
    [void](Test-PayloadManifest -Root $payloadRoot -Manifest $manifest)
    Write-Host "Paquete verificado: ProControl $($manifest.version) x64; $($manifest.fileCount) archivos coinciden en tamaño y SHA-256." -ForegroundColor Green

    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.Application]::EnableVisualStyles()
    [void][System.Windows.Forms.MessageBox]::Show(
        "Selecciona la carpeta destino de ProControl.`r`n`r`nPara la primera prueba, selecciona una carpeta NUEVA y vacía.`r`nPara actualizar una instalación creada con este sistema, selecciona la carpeta que contiene ProControl.exe.`r`n`r`nNo selecciones una instalación antigua de NSIS.",
        'ProControl — Actualización segura',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    )

    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Selecciona la carpeta destino de ProControl.'
    $dialog.ShowNewFolderButton = $true
    $dialog.SelectedPath = [Environment]::GetFolderPath('LocalApplicationData')
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Write-Host 'Operación cancelada. No se modificó nada.' -ForegroundColor Yellow
        exit 0
    }

    $targetRoot = Get-NormalizedPath $dialog.SelectedPath
    if (-not (Test-Path -LiteralPath $targetRoot -PathType Container)) { throw 'La carpeta destino seleccionada no existe.' }
    if ($targetRoot -ieq (Get-NormalizedPath ([System.IO.Path]::GetPathRoot($targetRoot)))) { throw 'No se permite instalar ProControl directamente en la raíz de una unidad.' }
    if ((Test-SameOrChildPath -Candidate $targetRoot -Parent $packageRoot) -or
        (Test-SameOrChildPath -Candidate $packageRoot -Parent $targetRoot)) {
        throw 'La carpeta destino y la carpeta del paquete no pueden contenerse entre sí. Extrae el ZIP aparte y selecciona otra ruta.'
    }

    $targetExe = Join-Path $targetRoot 'ProControl.exe'
    $isUpdate = Test-Path -LiteralPath $targetExe -PathType Leaf
    if ($isUpdate -and (Test-LegacyNsisInstall -TargetRoot $targetRoot)) {
        throw 'La carpeta destino pertenece a una instalación NSIS antigua. No se modificó. Selecciona una carpeta nueva para esta primera prueba.'
    }
    if (-not $isUpdate) {
        $existingItems = @(Get-ChildItem -LiteralPath $targetRoot -Force)
        if ($existingItems.Count -gt 0) {
            throw 'La carpeta destino no está vacía y no contiene ProControl.exe. Elige una carpeta nueva y vacía.'
        }
    }

    # Close the old/current app before taking a consistent copy of SQLite/WAL files.
    Stop-AllProControlInstances

    $operationId = (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + ([Guid]::NewGuid().ToString('N').Substring(0, 6))
    $parent = Split-Path -Parent $targetRoot
    $leaf = Split-Path -Leaf $targetRoot
    $stageRoot = Join-Path $parent ('.' + $leaf + '.nuevo_' + $operationId)
    $programBackup = Join-Path $parent ($leaf + '_respaldo_' + $operationId)
    $failedRoot = Join-Path $parent ($leaf + '_fallido_' + $operationId)
    $dataRoot = Join-Path $env:APPDATA 'ProControl'
    $dataBackupRoot = Join-Path (Join-Path $env:USERPROFILE 'Documents\Respaldos-ProControl') $operationId

    foreach ($candidate in @($stageRoot, $programBackup, $failedRoot, $dataBackupRoot)) {
        if (Test-Path -LiteralPath $candidate) { throw "Ya existe una ruta de trabajo: $candidate" }
    }

    New-Item -ItemType Directory -Path $stageRoot -Force | Out-Null
    foreach ($item in (Get-ChildItem -LiteralPath $payloadRoot -Force)) {
        Copy-Item -LiteralPath $item.FullName -Destination $stageRoot -Recurse -Force
    }
    [void](Test-PayloadManifest -Root $stageRoot -Manifest $manifest)
    Write-Host 'La copia temporal pasó nuevamente todos los hashes.' -ForegroundColor Green

    $dataBackup = $null
    if (Test-Path -LiteralPath $dataRoot -PathType Container) {
        New-Item -ItemType Directory -Path $dataBackupRoot -Force | Out-Null
        $dataBackup = Backup-UserData -DataPath $dataRoot -BackupRoot $dataBackupRoot
        Write-Host "Respaldo de datos y licencia verificado: $dataBackup" -ForegroundColor Green
    } else {
        Write-Host 'No existe %APPDATA%\ProControl todavía; no hay datos previos que respaldar.' -ForegroundColor Yellow
    }

    $oldMoved = $false
    $newPlaced = $false
    try {
        if (Test-Path -LiteralPath $targetRoot -PathType Container) {
            Move-Item -LiteralPath $targetRoot -Destination $programBackup
            $oldMoved = $true
        }
        Move-Item -LiteralPath $stageRoot -Destination $targetRoot
        $newPlaced = $true
        [void](Test-PayloadManifest -Root $targetRoot -Manifest $manifest)
    } catch {
        if ($newPlaced -and (Test-Path -LiteralPath $targetRoot -PathType Container)) {
            Move-Item -LiteralPath $targetRoot -Destination $failedRoot
        }
        if ($oldMoved -and (Test-Path -LiteralPath $programBackup -PathType Container) -and -not (Test-Path -LiteralPath $targetRoot)) {
            Move-Item -LiteralPath $programBackup -Destination $targetRoot
        }
        throw
    }

    if (-not $isUpdate) { New-DesktopShortcut -ExePath (Join-Path $targetRoot 'ProControl.exe') -WorkingDirectory $targetRoot }

    Write-Section 'OPERACIÓN COMPLETADA'
    if ($isUpdate) {
        Write-Host "ProControl $($manifest.version) se actualizó correctamente." -ForegroundColor Green
        Write-Host "Versión anterior conservada en: $programBackup"
    } else {
        Write-Host "ProControl $($manifest.version) quedó en: $targetRoot" -ForegroundColor Green
        Write-Host 'Se creó un acceso directo en el Escritorio cuando Windows lo permitió.'
        if ($oldMoved) { Write-Host "Carpeta vacía anterior conservada en: $programBackup" }
    }
    if ($dataBackup) { Write-Host "Respaldo adicional de datos/licencia: $dataBackup" }
    Write-Host 'La carpeta %APPDATA%\ProControl no se reemplazó ni se borró.' -ForegroundColor Green
    Write-Host 'Abre ProControl.exe y comprueba el inicio y la licencia.'
} catch {
    Write-Host ''
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'No se ha solicitado borrar la carpeta de datos ni la licencia.' -ForegroundColor Yellow
    exit 1
}
