'use strict';
const assert = require('node:assert/strict');
const { normalizePOSId, resolveDesktopSalesGate, authorizeSalesLedgerDelta, validateUniqueStoreKeys } = require('../electron/mobile-bridge/sales-write-policy');
let assertions = 0;
function equal(a,b,m) { assertions++; assert.equal(a,b,m); }
function ok(a,m) { assertions++; assert.ok(a,m); }
function policyState({strictLicensing=false, mode='SIN_APP'}={}) { return { ok:true, strictLicensing, modes:new Map([['pos_00000001',mode]]) }; }
const current = [{ id:'sale_existing_0001', kind:'sale', posId:'pos:pos_00000001' }];
const allowed = [];
{
  const result = authorizeSalesLedgerDelta(current, [...current,{id:'sale_new_0001',kind:'sale',posId:'pos:pos_00000001'}], posId => { allowed.push(posId); return {ok:true}; });
  equal(result.ok,true,'New sale authorized when the main-process POS policy accepts it');
  equal(allowed[0],'pos_00000001','Renderer POS reference is normalized to the stored POS ID');
  equal(normalizePOSId('pos:pos_00000001'),'pos_00000001','Prefix normalization is stable');
}
{
  const result = authorizeSalesLedgerDelta(current,[...current,{id:'sale_new_0002',kind:'sale',posId:'pos_00000001'}],() => ({ok:false,code:'POS_LICENSE_REQUIRED'}));
  equal(result.ok,false,'Main-process policy denial blocks persistence');
  equal(result.code,'POS_LICENSE_REQUIRED','The gate error code is preserved');
}
{
  const result = authorizeSalesLedgerDelta(current,[...current,{id:'return_new_0001',kind:'return',posId:'pos_00000001'}],() => ({ok:true}));
  equal(result.authorizedTransactions,1,'Returns are also checked at the persistence boundary');
}
{
  const duplicate = { id:'sale_duplicate_0001', kind:'sale', posId:'pos_00000001' };
  equal(authorizeSalesLedgerDelta([], [duplicate,duplicate], () => ({ok:true})).code,'SALES_TRANSACTION_ID_DUPLICATE','Duplicate IDs within one write are rejected');
  equal(authorizeSalesLedgerDelta([], [{kind:'sale',posId:'pos_00000001'}], () => ({ok:true})).code,'SALES_TRANSACTION_ID_REQUIRED','A new transaction without an ID is rejected');
  equal(authorizeSalesLedgerDelta([], [{id:'sale_bad_pos_0001',kind:'sale',posId:'bad pos'}], () => ({ok:true})).code,'SALES_POS_ID_INVALID','Malformed POS scope is rejected');
  equal(authorizeSalesLedgerDelta([], [{id:'sale_new_0001',kind:'sale',posId:'pos_00000001'}], () => ({ok:true}),{maxTransactions:0}).ok,true,'Non-positive test limits fall back to the safe default');
}

{
  let called = false;
  const gate = resolveDesktopSalesGate('pos:pos_00000001', policyState({strictLicensing:false}), () => { called = true; return {ok:false}; });
  equal(gate.ok,true,'Legacy desktop POS remains compatible while strict POS licensing is disabled');
  equal(called,false,'Legacy sales do not initialize the mobile bridge or migrate its key');
}
{
  const gate = resolveDesktopSalesGate('pos_00000001', policyState({mode:'CON_APP'}), () => ({ok:true}));
  equal(gate.code,'MOBILE_APP_NOT_AVAILABLE','A persisted CON_APP state cannot authorize desktop sales without a real mobile app');
}
{
  const gate = resolveDesktopSalesGate('pos_00000001', policyState({strictLicensing:true}), () => ({ok:false,code:'POS_LICENSE_REQUIRED'}));
  equal(gate.code,'POS_LICENSE_REQUIRED','Strict mode delegates to the signed POS license policy');
}
{
  const tx = { id:'sale_immutable_0001', kind:'sale', posId:'pos_00000001', totalCUP:100, items:[{productId:'rice_1',baseQty:2}], status:'pending-close', closingId:null, reconciledAt:null };
  const statusOnly = { ...tx, status:'closed', closingId:'close_1', reconciledAt:'2026-10-27T00:00:00Z' };
  equal(authorizeSalesLedgerDelta([tx],[statusOnly],() => ({ok:true})).ok,true,'Closing metadata can change without changing the sale itself');
  equal(authorizeSalesLedgerDelta([tx],[],() => ({ok:true})).code,'SALES_HISTORY_DELETE_BLOCKED','Historical sales cannot be removed from the ledger');
  equal(authorizeSalesLedgerDelta([tx],[{...tx,totalCUP:1}],() => ({ok:true})).code,'SALES_HISTORY_MUTATION_BLOCKED','Historical money values cannot be rewritten');
  equal(authorizeSalesLedgerDelta([tx],[{...tx,items:[{productId:'rice_2',baseQty:2}]}],() => ({ok:true})).code,'SALES_HISTORY_MUTATION_BLOCKED','Historical product identity cannot be rewritten');
  const legacy = {...tx,items:[{baseQty:2}]};
  equal(authorizeSalesLedgerDelta([legacy],[{...legacy,items:[{baseQty:2,productId:'rice_1'}]}],() => ({ok:true})).code,'SALES_HISTORY_MUTATION_BLOCKED','A renderer write cannot invent a historical product ID; only the validated migration may backfill it');
  equal(validateUniqueStoreKeys([['a','1'],['b','2']]).ok,true,'Unique bulk store keys are accepted');
  equal(validateUniqueStoreKeys([['elite_sales_ledger','[]'],['elite_sales_ledger','[{"id":"forged"}]']]).code,'STORE_KEY_DUPLICATE','Duplicate keys cannot bypass the persistence gate in bulk writes');
  equal(validateUniqueStoreKeys([['a','1'],['a','2']]).ok,false,'Any repeated key in a bulk write is rejected');
}
console.log(`Sales write policy: ${assertions} assertions passed.`);
