'use strict';
const assert = require('node:assert/strict');
const { buildProVentaInventorySnapshot } = require('../electron/mobile-bridge/proventa-snapshot');
let assertions = 0;
function check(value, message) { assertions++; assert.ok(value, message); }
function equal(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
const installationId = 'pcinst_' + 'a'.repeat(32);
const pointsOfSale = [
  { id: 'pos_alpha_01', name: 'Punto Alpha', inventory: [
    { productId: 'prod_rice_01', name: 'Arroz', unit: 'lb', family: 'Granos', qty: 12, sale: 100, saleTransf: 108, saleTransfMode: 'percentage', saleTransfPercent: 8, saleUSD: 1.5, saleCurrency: 'USD', cost: 55, unitsPerBox: 20 },
    { productId: 'prod_beans_01', name: 'Frijoles', unit: 'lb', qty: 4, sale: 120, saleTransf: 120, saleTransfMode: 'manual', saleUSD: 2, saleCurrency: 'EUR' }
  ] },
  { id: 'pos_beta_02', name: 'Punto Beta', inventory: [{ productId: 'prod_other_01', name: 'Agua', unit: 'u', qty: 99, sale: 5 }] }
];
const snapshot = buildProVentaInventorySnapshot({
  installationId, pointsOfSale, posId: 'pos_alpha_01',
  productCatalog: [
    { id: 'prod_rice_01', name: 'Arroz', aliases: ['Arroz largo'], family: 'Granos', unit: 'lb' },
    { id: 'prod_other_01', name: 'Agua', aliases: ['Agua botella'] }
  ],
  dollarRate: 410,
  exchangeRates: { USD_CUP: 410, EUR_CUP: 455, MLC_CUP: 390, INVALID_CUP: -1, CUSTOM_CUP: 500 },
  now: 1793900000000
});
equal(snapshot.schema, 'proventa.inventory-snapshot', 'Incluye el esquema del snapshot');
equal(snapshot.posId, 'pos_alpha_01', 'El paquete identifica el POS seleccionado');
equal(snapshot.posName, 'Punto Alpha', 'Conserva el nombre real del POS');
equal(snapshot.inventory.length, 2, 'Solo contiene inventario del POS seleccionado');
equal(snapshot.inventory[0].productId, 'prod_rice_01', 'Conserva el productId estable');
equal(snapshot.inventory[0].qty, 12, 'Conserva existencias del POS');
equal(snapshot.inventory[0].saleTransfPercent, 8, 'Conserva el modo porcentual y el porcentaje de transferencia');
equal(snapshot.inventory[1].saleCurrency, 'EUR', 'Conserva la moneda real del precio en divisas');
equal(snapshot.catalog.length, 1, 'Filtra el catálogo a productos presentes en el POS');
equal(snapshot.exchangeRates.USD_CUP, 410, 'Envía la tasa USD/CUP real cuando está configurada');
equal(snapshot.exchangeRates.EUR_CUP, 455, 'Envía la tasa EUR/CUP vigente');
equal(snapshot.exchangeRates.MLC_CUP, 390, 'Envía la tasa MLC/CUP vigente');
check(!Object.prototype.hasOwnProperty.call(snapshot.exchangeRates, 'INVALID_CUP'), 'No exporta tasas negativas');
check(!Object.prototype.hasOwnProperty.call(snapshot.exchangeRates, 'CUSTOM_CUP'), 'No exporta monedas no admitidas por el contrato móvil');
check(!Object.prototype.hasOwnProperty.call(snapshot.inventory[0], 'cost'), 'No expone costes de adquisición al dependiente');
check(!Object.prototype.hasOwnProperty.call(snapshot.inventory[0], 'unitsPerBox'), 'No reintroduce campos de caja ni conversiones');
check(!JSON.stringify(snapshot).includes('prod_other_01'), 'No incluye productos de otro POS');
let error;
try { buildProVentaInventorySnapshot({ installationId, pointsOfSale: [{ id: 'pos_alpha_01', name: 'Punto', inventory: [{ name: 'Sin ID', unit: 'u', qty: 1 }] }], posId: 'pos_alpha_01' }); } catch (e) { error = e; }
equal(error && error.code, 'PRODUCT_ID_REQUIRED', 'Rechaza productos sin identidad estable');
error = null;
try { buildProVentaInventorySnapshot({ installationId, pointsOfSale: [{ id: 'pos_alpha_01', name: 'Punto', inventory: [{ productId: 'prod_x_01', name: 'A', unit: 'u', qty: 1 }, { productId: 'prod_x_01', name: 'B', unit: 'u', qty: 1 }] }], posId: 'pos_alpha_01' }); } catch (e) { error = e; }
equal(error && error.code, 'DUPLICATE_PRODUCT_ID', 'Rechaza productId duplicados sin fusionarlos');
error = null;
try { buildProVentaInventorySnapshot({ installationId, pointsOfSale, posId: 'pos_missing_01' }); } catch (e) { error = e; }
equal(error && error.code, 'POS_NOT_FOUND', 'Rechaza POS inexistente');
console.log(`ProVenta snapshot projection: ${assertions} assertions passed.`);
