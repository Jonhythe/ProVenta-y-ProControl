'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const costing = require('../renderer/purchase-costing.js');
const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');
let passed = 0;
function test(name, fn) {
  fn();
  passed += 1;
  console.log(`OK ${passed}: ${name}`);
}

test('el Extra se distribuye por el valor de cada línea, no por producto físico', () => {
  const result = costing.allocateExtra([
    { name: 'Galletas', cost: 30, qty: 3, unit: 'u' },
    { name: 'Carne de res', cost: 800, qty: 100, unit: 'kg' }
  ], 1000);
  assert.equal(result.ok, true);
  assert.equal(result.goodsAmount, 80090);
  assert.equal(result.extraAmount, 1000);
  assert.equal(result.totalAmount, 81090);
  const biscuits = result.items.find(item => item.name === 'Galletas');
  const beef = result.items.find(item => item.name === 'Carne de res');
  assert.equal(biscuits.extraAllocated, 1.12);
  assert.equal(beef.extraAllocated, 998.88);
  assert.ok(Math.abs(biscuits.cost - (30 + 1.12 / 3)) < 1e-10);
  assert.ok(Math.abs(beef.cost - (800 + 998.88 / 100)) < 1e-10);
  assert.equal(result.items.reduce((sum, item) => sum + item.extraAllocated, 0), 1000);
});

test('el coste ajustado queda expresado en la unidad de compra (incluida caja)', () => {
  const result = costing.allocateExtra([
    { name: 'Producto en cajas', cost: 100, qty: 2, unit: 'caja', unitsPerBox: 10 },
    { name: 'Producto suelto', cost: 100, qty: 2, unit: 'u' }
  ], 40);
  assert.equal(result.ok, true);
  const boxes = result.items.find(item => item.name === 'Producto en cajas');
  assert.equal(boxes.extraAllocated, 20);
  assert.equal(boxes.cost, 110);
  assert.equal(boxes.cost / boxes.unitsPerBox, 11);
});

test('cero de Extra no altera el precio de compra ni los subtotales', () => {
  const result = costing.allocateExtra([{ name: 'Arroz', cost: 50, qty: 4 }], 0);
  assert.equal(result.ok, true);
  assert.equal(result.items[0].baseCost, 50);
  assert.equal(result.items[0].cost, 50);
  assert.equal(result.items[0].extraAllocated, 0);
  assert.equal(result.totalAmount, 200);
});

test('un Extra negativo o no numérico es rechazado', () => {
  assert.equal(costing.allocateExtra([{ name: 'Arroz', cost: 50, qty: 2 }], -1).ok, false);
  assert.equal(costing.allocateExtra([{ name: 'Arroz', cost: 50, qty: 2 }], 'abc').ok, false);
});

test('una línea con precio o cantidad inválidos se rechaza', () => {
  assert.equal(costing.allocateExtra([{ name: 'Arroz', cost: 0, qty: 2 }], 10).ok, false);
  assert.equal(costing.allocateExtra([{ name: 'Arroz', cost: 50, qty: 0 }], 10).ok, false);
});

test('el reparto en céntimos suma exactamente el Extra global', () => {
  const result = costing.allocateExtra([
    { name: 'C', cost: 1, qty: 1 },
    { name: 'A', cost: 1, qty: 1 },
    { name: 'B', cost: 1, qty: 1 }
  ], 0.01);
  assert.equal(result.ok, true);
  assert.equal(result.items.reduce((sum, item) => Math.round((sum + item.extraAllocated) * 100) / 100, 0), 0.01);
  assert.equal(result.items.find(item => item.name === 'A').extraAllocated, 0.01);
});

test('el reparto no modifica el array original', () => {
  const items = [{ name: 'Azúcar', cost: 12, qty: 3 }];
  const before = structuredClone(items);
  costing.allocateExtra(items, 1.50);
  assert.deepEqual(items, before);
});

test('la compra guarda valor base, Extra asignado, método y coste de adquisición total', () => {
  assert.match(html, /id="purchase-extra-amount"/);
  assert.match(html, /PurchaseOps\.planPurchase\(rawRows, supplier,[\s\S]{0,120}purchase-extra-amount/);
  assert.match(html, /baseCost/);
  assert.match(html, /extraAllocated/);
  assert.match(html, /extraAllocationMethod/);
  assert.match(html, /applyPurchaseItems\(items, state\)/);
});

test('el Extra se muestra debajo del proveedor y la previsualización se actualiza', () => {
  const supplierAt = html.indexOf('id="purchase-supplier"');
  const extraAt = html.indexOf('id="purchase-extra-amount"');
  const itemsAt = html.indexOf('id="purchase-items-container"');
  assert.ok(supplierAt >= 0 && extraAt > supplierAt && itemsAt > extraAt);
  assert.match(html, /oninput="Purchases\.updateExtraPreview\(\)"/);
  assert.match(html, /Coste total de adquisición/);
});



test('Nueva compra elimina instrucciones largas del Extra y mantiene resumen compacto', () => {
  assert.doesNotMatch(html, /id="purchase-extra-help"/);
  assert.doesNotMatch(html, /Se distribuye proporcionalmente al valor original de cada línea, no por cantidad física/);
  assert.match(html, /id="purchase-extra-summary" class="purchase-extra-summary"/);
  assert.match(html, /Extra que se repartirá/);
  assert.match(html, /<details id="purchase-extra-breakdown" class="purchase-extra-breakdown">[\s\S]*?Ver distribución por producto[\s\S]*?id="purchase-extra-preview"/);
});

test('Nueva compra da prioridad de espacio al listado de productos', () => {
  assert.match(html, /#purchase-modal-overlay \.purchase-modal[\s\S]{0,250}height:min\(95vh,1100px\)/);
  assert.match(html, /#purchase-modal-overlay #purchase-items-container[\s\S]{0,250}flex:1 1 0 !important/);
  assert.match(html, /#purchase-modal-overlay #purchase-items-container[\s\S]{0,250}min-height:0 !important/);
  assert.match(html, /#purchase-modal-overlay \.purchase-modal-footer[\s\S]{0,220}padding-top:7px/);
});

test('el acceso de compra usa rutas app:// coherentes con el protocolo Electron', () => {
  assert.match(html, /<script src="app:\/\/purchase-costing\.js"><\/script>/);
  assert.match(html, /<script src="app:\/\/business-management\.js"><\/script>/);
});



test('PurchaseOps.planPurchase conecta la entrada real de Nueva compra con el reparto proporcional', () => {
  const start = html.indexOf('const PurchaseOps = ');
  const end = html.indexOf('\n};\nconst Logistics =', start);
  assert.ok(start >= 0 && end > start, 'No se encontró el objeto PurchaseOps en el HTML principal');
  const source = html.slice(start + 'const PurchaseOps = '.length, end + 2).trim();
  const units = {
    normalizeUnitsPerBox(value) { const n = Number(value); return Number.isSafeInteger(n) && n > 0 ? n : null; },
    isSupportedUnit(unit) { return ['u', 'pqt', 'lb', 'kg', 'lt'].includes(String(unit || '').trim()); },
    validateDiscreteQuantity(qty, unit) { return ['kg', 'lb', 'lt'].includes(unit) || Number.isSafeInteger(Number(qty)); }
  };
  const ops = new Function('PurchaseCosting', 'ProductUnits', `return (${source});`)(costing, units);
  const plan = ops.planPurchase([
    { rowNum: 1, name: 'Galletas', cost: '30', transf: '', usd: '', qty: '3', unit: 'u', unitsPerBox: '' },
    { rowNum: 2, name: 'Carne de res', cost: '800', transf: '', usd: '', qty: '100', unit: 'kg', unitsPerBox: '' }
  ], 'Proveedor de prueba', { validateUnits: () => null }, '1000');
  assert.equal(plan.ok, true, plan.message);
  assert.equal(plan.goodsTotal, 80090);
  assert.equal(plan.extraAmount, 1000);
  assert.equal(plan.total, 81090);
  assert.equal(plan.items.find(item => item.name === 'Galletas').extraAllocated, 1.12);
  assert.equal(plan.items.find(item => item.name === 'Carne de res').extraAllocated, 998.88);
});

test('PurchaseOps.applyPurchase persiste la distribución y pasa costes ajustados al inventario', () => {
  const start = html.indexOf('const PurchaseOps = ');
  const end = html.indexOf('\n};\nconst Logistics =', start);
  const source = html.slice(start + 'const PurchaseOps = '.length, end + 2).trim();
  const units = {
    normalizeUnitsPerBox(value) { const n = Number(value); return Number.isSafeInteger(n) && n > 0 ? n : null; },
    isSupportedUnit(unit) { return ['u', 'pqt', 'lb', 'kg', 'lt'].includes(String(unit || '').trim()); },
    validateDiscreteQuantity(qty, unit) { return ['kg', 'lb', 'lt'].includes(unit) || Number.isSafeInteger(Number(qty)); }
  };
  const ops = new Function('PurchaseCosting', 'ProductUnits', `return (${source});`)(costing, units);
  const plan = ops.planPurchase([
    { rowNum: 1, name: 'Galletas', cost: '30', transf: '', usd: '', qty: '3', unit: 'u', unitsPerBox: '' },
    { rowNum: 2, name: 'Carne de res', cost: '800', transf: '', usd: '', qty: '100', unit: 'kg', unitsPerBox: '' }
  ], 'Proveedor de prueba', { validateUnits: () => null }, 1000);
  assert.equal(plan.ok, true, plan.message);
  const state = { purchases: [], inventory: [], pointsOfSale: [], productCatalog: [], auditLog: [] };
  let receivedByInventory = null;
  const result = ops.applyPurchase(state, plan.items, 'Proveedor de prueba', plan.total, {
    applyPurchaseItems(items) {
      receivedByInventory = items.map(item => ({ name: item.name, cost: item.cost, baseCost: item.baseCost, extraAllocated: item.extraAllocated }));
    }
  }, { goodsAmount: plan.goodsTotal, extraAmount: plan.extraAmount, extraAllocationMethod: plan.extraAllocationMethod, supplierPhone: '555-1234' });
  assert.equal(state.purchases.length, 1);
  assert.equal(state.purchases[0].goodsAmount, 80090);
  assert.equal(state.purchases[0].extraAmount, 1000);
  assert.equal(state.purchases[0].totalAmount, 81090);
  assert.equal(state.purchases[0].extraCurrency, 'CUP');
  assert.equal(state.purchases[0].extraAllocationMethod, 'proportional-value');
  assert.equal(state.purchases[0].supplierPhone, '555-1234');
  assert.equal(result.purchase, state.purchases[0]);
  assert.deepEqual(receivedByInventory, plan.items.map(item => ({ name: item.name, cost: item.cost, baseCost: item.baseCost, extraAllocated: item.extraAllocated })));
});


test('proveedor y teléfono opcional se incorporan al formulario real de compra',()=>{
 assert.match(html,/id="purchase-supplier"[\s\S]*?datalist id="purchase-supplier-options"/);
 assert.match(html,/id="purchase-supplier-phone"/);
 assert.match(html,/Purchases\.suggestSupplierPhone\(\)/);
 assert.match(html,/supplierPhone: String\(extraDetails\.supplierPhone/);
});


test('PurchaseOps rechaza Caja en compras nuevas y mantiene las conversiones solo para históricos', () => {
  const start = html.indexOf('const PurchaseOps = ');
  const end = html.indexOf('\n};\nconst Logistics =', start);
  assert.ok(start >= 0 && end > start, 'No se encontró PurchaseOps');
  const source = html.slice(start + 'const PurchaseOps = '.length, end + 2).trim();
  const units = {
    normalizeUnitsPerBox(value) { const n = Number(value); return Number.isSafeInteger(n) && n > 0 ? n : null; },
    isSupportedUnit(unit) { return ['u', 'pqt', 'lb', 'kg', 'lt'].includes(String(unit || '').trim()); },
    validateDiscreteQuantity(qty, unit) { return ['kg', 'lb', 'lt'].includes(unit) || Number.isSafeInteger(Number(qty)); }
  };
  const ops = new Function('PurchaseCosting', 'ProductUnits', `return (${source});`)(costing, units);
  const plan = ops.planPurchase([
    { rowNum: 1, name: 'Arroz', cost: '100', transf: '', usd: '', qty: '2', unit: 'caja', unitsPerBox: '12' }
  ], 'Proveedor de prueba', { validateUnits: () => null }, 0);
  assert.equal(plan.ok, false);
  assert.match(plan.message, /la unidad indicada ya no está disponible para nuevas compras/i);
  assert.match(html, /const isRetiredUnit = \['caja', 'cajas', 'box', 'boxes'\]\.includes\(purchaseUnit\)/);
  assert.match(html, /const isLegacyPackage = isRetiredUnit && Number\.isSafeInteger\(factor\) && factor > 0/);
  assert.match(html, /const displayUnit = isRetiredUnit \? 'u'/);
});

console.log(`Resultado: ${passed} pruebas de Extra de compra aprobadas, 0 fallidas.`);
