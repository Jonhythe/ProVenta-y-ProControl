﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)][string]$File,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$Description
    )
    Write-Host "`n== $Description ==" -ForegroundColor Cyan
    & $File @Arguments
    $code = $LASTEXITCODE
    if ($code -ne 0) { throw "$Description termino con codigo $code." }
}

if ($env:OS -ne 'Windows_NT') { throw 'Este preparador requiere Windows.' }
if (-not [Environment]::Is64BitOperatingSystem) { throw 'ProControl se distribuye para Windows x64.' }

$appRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$workspaceRoot = Split-Path -Parent $appRoot
Set-Location -LiteralPath $appRoot

$package = Get-Content -LiteralPath (Join-Path $appRoot 'package.json') -Raw | ConvertFrom-Json
if ($package.name -ne 'procontrol-desktop') { throw 'El proyecto no parece ser ProControl Desktop.' }

$running = @(Get-Process -Name 'ProControl' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) { throw 'Cierra ProControl antes de compilar.' }

Write-Host 'PREPARACION DE DISTRIBUCION PROCONTROL' -ForegroundColor Yellow
Write-Host "Version: $($package.version)"
Write-Host 'Objetivo: un unico Setup NSIS x64.'
Write-Host 'No se usara 7-Zip como verificador NSIS.'

Invoke-Checked -File 'node.exe' -Arguments @('tools/check-nsis-toolchain.js') -Description 'Verificacion del toolchain electron-builder'
Invoke-Checked -File 'npm.cmd' -Arguments @('run', 'check-source') -Description 'Pruebas completas del codigo fuente'
Invoke-Checked -File 'node.exe' -Arguments @('tools/build-clean-nsis.js') -Description 'Compilacion NSIS limpia'

$latest = Get-ChildItem -LiteralPath $appRoot -Directory -Filter 'dist_setup_definitivo_*' |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1
if (-not $latest) { throw 'No se encontro una carpeta dist_setup_definitivo_*.' }

$manifestPath = Join-Path $latest.FullName 'PROCONTROL_NSIS_BUILD.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'Falta PROCONTROL_NSIS_BUILD.json.' }
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ([int]$manifest.schemaVersion -ne 2 -or $manifest.target -ne 'nsis' -or $manifest.architecture -ne 'x64') {
    throw 'El manifiesto no corresponde a un build NSIS x64 del esquema 2.'
}
if ($manifest.toolchain.'electron-builder instalado' -ne '26.18.1') {
    throw 'El manifiesto no confirma electron-builder 26.18.1.'
}

$setupPath = [string]$manifest.setupPath
if (-not (Test-Path -LiteralPath $setupPath -PathType Leaf)) { throw "No existe el Setup: $setupPath" }
$integrityOutput = & node.exe 'tools/nsis-integrity.js' $setupPath
$integrityCode = $LASTEXITCODE
$integrityOutput | ForEach-Object { Write-Host $_ }
if ($integrityCode -ne 0) { throw "El verificador NSIS devolvio codigo $integrityCode; no se distribuira el Setup." }

$asarPath = Join-Path ([string]$manifest.outputDir) 'win-unpacked\resources\app.asar'
if (-not (Test-Path -LiteralPath $asarPath -PathType Leaf)) { throw "Falta app.asar: $asarPath" }
Invoke-Checked -File 'node.exe' -Arguments @('tools/check-no-secrets.js', '--require-build', '--build-dir', [string]$manifest.outputDir) -Description 'Escaneo de secretos y app.asar'

$hash1 = (Get-FileHash -LiteralPath $setupPath -Algorithm SHA256).Hash.ToUpperInvariant()
$size1 = (Get-Item -LiteralPath $setupPath).Length
Start-Sleep -Seconds 2
$hash2 = (Get-FileHash -LiteralPath $setupPath -Algorithm SHA256).Hash.ToUpperInvariant()
$size2 = (Get-Item -LiteralPath $setupPath).Length
if ($hash1 -ne $hash2 -or $size1 -ne $size2 -or $hash1 -ne ([string]$manifest.sha256).ToUpperInvariant() -or $size1 -ne [int64]$manifest.sizeBytes) {
    throw 'El Setup cambio o no coincide con su manifiesto. No se copiara a distribucion.'
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$deliveryDir = Join-Path $workspaceRoot ("ProControl_Entrega_{0}_{1}" -f $package.version, $stamp)
$stageDir = Join-Path $workspaceRoot ("ProControl_preparando_" + $stamp)
if (Test-Path -LiteralPath $stageDir) { throw "Ya existe la carpeta temporal: $stageDir" }
New-Item -ItemType Directory -Path $stageDir | Out-Null

$finalName = "Setup-ProControl-$($package.version)-x64.exe"
$stagedSetup = Join-Path $stageDir $finalName
Copy-Item -LiteralPath $setupPath -Destination $stagedSetup

$copyHash1 = (Get-FileHash -LiteralPath $stagedSetup -Algorithm SHA256).Hash.ToUpperInvariant()
$copySize1 = (Get-Item -LiteralPath $stagedSetup).Length
Start-Sleep -Seconds 1
$copyHash2 = (Get-FileHash -LiteralPath $stagedSetup -Algorithm SHA256).Hash.ToUpperInvariant()
$copySize2 = (Get-Item -LiteralPath $stagedSetup).Length
if ($copyHash1 -ne $hash1 -or $copyHash2 -ne $hash1 -or $copySize1 -ne $size1 -or $copySize2 -ne $size1) {
    Remove-Item -LiteralPath $stageDir -Recurse -Force
    throw 'La copia del Setup no coincide o cambio durante la comprobacion. La entrega anterior se conserva.'
}

# Publicacion inmutable: no mover ni renombrar la entrega anterior, que puede estar bloqueada.
if (Test-Path -LiteralPath $deliveryDir) {
    throw "La carpeta de entrega unica ya existe; no se sobrescribira: $deliveryDir"
}
New-Item -ItemType Directory -Path $deliveryDir | Out-Null
$publishedSetup = Join-Path $deliveryDir $finalName
try {
    Copy-Item -LiteralPath $stagedSetup -Destination $publishedSetup -ErrorAction Stop
    $publishedHash1 = (Get-FileHash -LiteralPath $publishedSetup -Algorithm SHA256).Hash.ToUpperInvariant()
    $publishedSize1 = (Get-Item -LiteralPath $publishedSetup).Length
    Start-Sleep -Seconds 2
    $publishedHash2 = (Get-FileHash -LiteralPath $publishedSetup -Algorithm SHA256).Hash.ToUpperInvariant()
    $publishedSize2 = (Get-Item -LiteralPath $publishedSetup).Length
    if ($publishedHash1 -ne $hash1 -or $publishedHash2 -ne $hash1 -or $publishedSize1 -ne $size1 -or $publishedSize2 -ne $size1) {
        throw 'La copia publicada no coincide de forma estable con el Setup validado.'
    }
    $publishedIntegrity = & node.exe 'tools/nsis-integrity.js' $publishedSetup
    $publishedIntegrityCode = $LASTEXITCODE
    $publishedIntegrity | ForEach-Object { Write-Host $_ }
    if ($publishedIntegrityCode -ne 0) {
        throw "La validacion NSIS de la copia publicada fallo con codigo $publishedIntegrityCode."
    }
    $sourceHashFinal = (Get-FileHash -LiteralPath $setupPath -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($sourceHashFinal -ne $hash1) { throw 'El Setup de origen cambio despues de la publicacion.' }
} catch {
    Write-Host "La nueva entrega no se publico correctamente. Se conserva el archivo temporal en: $stageDir" -ForegroundColor Yellow
    throw
}

$report = @(
    'PROCONTROL - MANIFIESTO DE DISTRIBUCION',
    "Archivo: $finalName",
    "Version: $($package.version)",
    "Tamano: $size1 bytes",
    "SHA256: $hash1",
    "electron-builder: 26.18.1",
    'NSIS CRC: validado antes y despues de publicar por tools/nsis-integrity.js',
    "Carpeta de entrega: $deliveryDir",
    '',
    "Verificar en PowerShell: Get-FileHash -LiteralPath '.\$finalName' -Algorithm SHA256"
)
$reportPath = Join-Path $workspaceRoot ("ProControl-SETUP-SHA256-{0}-{1}.txt" -f $package.version, $stamp)
Set-Content -LiteralPath $reportPath -Value $report -Encoding UTF8

# Eliminar el staging solo despues de validar la publicacion; el Setup final queda en la carpeta versionada.
Remove-Item -LiteralPath $stageDir -Recurse -Force

Write-Host "`nDISTRIBUCION LISTA" -ForegroundColor Green
Write-Host "Carpeta: $deliveryDir" -ForegroundColor Green
Write-Host "Archivo: $finalName" -ForegroundColor Green
Write-Host "Bytes: $size1"
Write-Host "SHA256: $hash1"
Write-Host "Reporte: $reportPath"
Write-Host 'La entrega anterior se conserva intacta; la nueva entrega usa una carpeta exclusiva.'
Write-Host 'Antes de publicar, instalar en un equipo limpio y verificar tambien la desinstalacion real.' -ForegroundColor Yellow
