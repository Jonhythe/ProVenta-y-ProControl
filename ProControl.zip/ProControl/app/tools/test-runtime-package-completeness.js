#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const assert = require('node:assert/strict');
const vm = require('node:vm');

const ROOT = path.resolve(__dirname, '..');
const runtimeDirIndex = process.argv.indexOf('--runtime-dir');
if (runtimeDirIndex >= 0 && !process.argv[runtimeDirIndex + 1]) {
  throw new Error('--runtime-dir requiere la ruta del runtime que debe auditarse.');
}
const APP = runtimeDirIndex >= 0
  ? path.resolve(process.argv[runtimeDirIndex + 1] || '')
  : ROOT;
const ELECTRON = path.join(APP, 'electron');
const RENDERER = path.join(APP, 'renderer');

function hash(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}
function resolveLocal(base) {
  const candidates = [base, ...['.js', '.cjs', '.mjs', '.json', '.node'].map(ext => base + ext)];
  for (const candidate of candidates) {
    try { if (fs.statSync(candidate).isFile()) return candidate; } catch {}
  }
  try {
    if (fs.statSync(base).isDirectory()) {
      const packageFile = path.join(base, 'package.json');
      if (fs.existsSync(packageFile)) {
        const manifest = JSON.parse(fs.readFileSync(packageFile, 'utf8'));
        if (manifest.main) {
          const main = resolveLocal(path.resolve(base, manifest.main));
          if (main) return main;
        }
      }
      for (const index of ['index.js', 'index.cjs', 'index.mjs', 'index.json']) {
        const candidate = path.join(base, index);
        if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
      }
    }
  } catch {}
  return null;
}
function walk(dir) {
  let out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out = out.concat(walk(full));
    else if (entry.isFile()) out.push(full);
  }
  return out;
}
function localUrl(value) {
  return value && !/^(?:[a-z]+:|\/\/|#|data:|javascript:)/i.test(value);
}

function main() {
  assert(fs.existsSync(path.join(APP, 'package.json')), 'Falta package.json del runtime.');
  const runtimePackage = JSON.parse(fs.readFileSync(path.join(APP, 'package.json'), 'utf8'));
  assert.equal(runtimePackage.name, 'procontrol-desktop', 'El manifiesto de runtime no corresponde a ProControl.');
  assert(runtimePackage.version, 'El manifiesto de runtime no tiene versión.');
  if (runtimeDirIndex >= 0) {
    assert(!Object.prototype.hasOwnProperty.call(runtimePackage, 'build'), 'El manifiesto runtime generado no debe contener configuración electron-builder.');
    assert(!runtimePackage.scripts, 'El manifiesto runtime no debe incluir scripts de desarrollo o empaquetado.');
  }
  assert(runtimePackage.main, 'El manifiesto runtime no declara main.');
  assert(fs.existsSync(resolveLocal(path.resolve(APP, runtimePackage.main))), 'El entrypoint declarado por el manifiesto runtime no existe.');
  assert(fs.existsSync(ELECTRON) && fs.statSync(ELECTRON).isDirectory(), 'Falta electron/ en el runtime.');
  for (const page of ['index.html', 'license.html', 'splash.html']) {
    assert(fs.existsSync(path.join(RENDERER, page)), `Falta app/renderer/${page}.`);
  }

  const required = [
    'electron/main.js',
    'electron/preload.js',
    'electron/license.js',
    'electron/license-core.js',
    'electron/license-config.js',
    'electron/mobile-bridge/store.js',
    'electron/mobile-bridge/control-plane.js',
    'electron/mobile-bridge/proventa-snapshot.js',
    'electron/mobile-bridge/fragments.js',
    'electron/mobile-bridge/sales-write-policy.js',
    'electron/record-archive-store.js',
    'electron/security/authorized-store-wipe.js',
  ];
  for (const rel of required) assert(fs.existsSync(path.join(APP, rel)), `Falta dependencia crítica del runtime: app/${rel}`);

  const missing = [];
  const jsFiles = walk(ELECTRON).filter(file => /\.(?:js|cjs|mjs)$/i.test(file));
  const requirePattern = /\brequire\s*\(\s*(['"])([^'"]+)\1\s*\)/g;
  const importPattern = /\b(?:from\s*|import\s*\()(['"])(\.[^'"]+)\1/g;
  for (const file of jsFiles) {
    const source = fs.readFileSync(file, 'utf8');
    for (const match of source.matchAll(requirePattern)) {
      const request = match[2];
      if (!request.startsWith('.')) continue;
      const resolved = resolveLocal(path.resolve(path.dirname(file), request));
      if (!resolved) missing.push(`${path.relative(APP, file)} -> ${request}`);
    }
    for (const match of source.matchAll(importPattern)) {
      const request = match[2];
      if (!request.startsWith('.')) continue;
      const resolved = resolveLocal(path.resolve(path.dirname(file), request));
      if (!resolved) missing.push(`${path.relative(APP, file)} -> ${request}`);
    }
  }
  assert.deepEqual(missing, [], `Hay importaciones relativas sin resolver:\n${missing.join('\n')}`);

  const htmlFiles = walk(RENDERER).filter(file => /\.html?$/i.test(file));
  const assetRefs = [];
  for (const htmlFile of htmlFiles) {
    const html = fs.readFileSync(htmlFile, 'utf8');
    for (const match of html.matchAll(/<(?:script|link|img|audio|source)\b[^>]*?\b(?:src|href)\s*=\s*(['"])(.*?)\1/gi)) {
      const value = match[2].trim();
      if (!localUrl(value) || value.includes('${') || value.includes('{{')) continue;
      const clean = value.split(/[?#]/, 1)[0];
      if (!clean) continue;
      let decoded;
      try { decoded = decodeURIComponent(clean); } catch { assetRefs.push(`${path.relative(RENDERER, htmlFile)} -> ${value} (URL inválida)`); continue; }
      const resolved = path.resolve(path.dirname(htmlFile), decoded);
      if (!resolved.startsWith(APP + path.sep) && resolved !== APP) continue;
      if (!fs.existsSync(resolved)) assetRefs.push(`${path.relative(RENDERER, htmlFile)} -> ${value}`);
    }
  }
  assert.deepEqual(assetRefs, [], `Las páginas HTML de runtime referencian archivos ausentes: ${assetRefs.join(', ')}`);

  let inlineScripts = 0;
  for (const htmlFile of htmlFiles) {
    const html = fs.readFileSync(htmlFile, 'utf8');
    for (const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)) {
      if (/\bsrc\s*=/i.test(match[1])) continue;
      const type = (match[1].match(/\btype\s*=\s*['"]([^'"]+)/i) || [])[1] || 'text/javascript';
      if (!/javascript|module/i.test(type)) continue;
      inlineScripts += 1;
      try {
        new vm.Script(match[2], { filename: `${path.relative(RENDERER, htmlFile)}#inline-${inlineScripts}` });
      } catch (error) {
        throw new Error(`Error de sintaxis en script inline de ${path.relative(RENDERER, htmlFile)}: ${error.message}`);
      }
    }
  }

  const rootIcon = path.join(ROOT, 'assets', 'icono.ico');
  const runtimeIcon = path.join(APP, 'assets', 'icono.ico');
  assert(fs.existsSync(rootIcon), 'Falta el icono ICO maestro en assets/icono.ico.');
  assert(fs.existsSync(runtimeIcon), 'Falta el icono ICO en assets/icono.ico del runtime.');
  const icon = fs.readFileSync(runtimeIcon);
  assert(icon.length >= 6 && icon.readUInt16LE(0) === 0 && icon.readUInt16LE(2) === 1, 'El icono de runtime no tiene cabecera ICO válida.');
  assert.equal(hash(rootIcon), hash(runtimeIcon), 'El icono de runtime no coincide byte por byte con el ICO maestro.');

  const syntaxFiles = walk(ELECTRON).concat(walk(RENDERER))
    .filter(file => /\.(?:js|cjs|mjs)$/i.test(file));
  if (runtimeDirIndex >= 0) {
    const backupFiles = walk(ELECTRON).filter(file => /\.bak$/i.test(file));
    assert.deepEqual(backupFiles, [], `El runtime no debe incluir respaldos de código: ${backupFiles.join(', ')}`);
  }
  for (const file of syntaxFiles) {
    const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
    if (result.status !== 0) {
      throw new Error(`Error de sintaxis en ${path.relative(APP, file)}:\n${result.stderr || result.stdout}`);
    }
  }

  console.log(`RUNTIME_PACKAGE_OK: ${syntaxFiles.length} archivos JavaScript de Electron y Renderer revisados.`);
  console.log(`Dependencias relativas resueltas: ${jsFiles.length} archivos Electron inspeccionados.`);
  console.log(`Módulos críticos presentes: ${required.length}.`);
  console.log(runtimeDirIndex >= 0
    ? 'Manifiesto runtime separado de electron-builder: OK.'
    : 'Fuente activa única revisada; el runtime se genera durante el empaquetado.');
  console.log(`Páginas HTML y recursos locales verificados: ${htmlFiles.length}; scripts inline: ${inlineScripts}.`);
  console.log('ICO runtime idéntico al ICO maestro: OK.');
}

try { main(); }
catch (error) {
  console.error('\nRUNTIME_PACKAGE_ERROR');
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
}
