'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const {
  decodeStoredValue,
  verifyStoredPassword,
  findPrivilegedCredential,
  readAppStoreKeysFromDisk
} = require('../electron/security/privileged-credentials');
const { createNativeFileDialogs } = require('../electron/native-file-dialogs');

module.exports = async function runProVentaSecurityDialogHardeningTests() {
  let assertions = 0;
  const check = (condition, message) => { assertions++; assert.ok(condition, message); };
  const equal = (actual, expected, message) => { assertions++; assert.equal(actual, expected, message); };

  function encodeStored(value) {
    const json = Buffer.from(JSON.stringify(value), 'utf8').toString('base64');
    return Buffer.from(`PROCONTROL_SECRET_2026:${json}`, 'utf8').toString('base64');
  }

  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-auth-hardening-'));
  try {
    const dbFile = path.join(root, 'procontrol.db');
    const legacyFile = path.join(root, 'procontrol.json');
    const db = new DatabaseSync(dbFile);
    db.exec('CREATE TABLE store (key TEXT PRIMARY KEY, value TEXT NOT NULL)');

    const ownerName = 'Dueño Prueba';
    const ownerPassword = 'Clave-fuerte-de-prueba-2026';
    const ownerSalt = crypto.randomBytes(16).toString('hex');
    const ownerHash = crypto.pbkdf2Sync(ownerPassword, Buffer.from(ownerSalt, 'hex'), 120000, 32, 'sha256').toString('hex');
    const adminName = 'Administrador Prueba';
    const adminPassword = 'Clave-admin-de-prueba-2026';
    const adminSalt = crypto.randomBytes(16).toString('hex');
    const adminHash = crypto.pbkdf2Sync(adminPassword, Buffer.from(adminSalt, 'hex'), 120000, 32, 'sha256').toString('hex');

    const roles = { [ownerName]: 'Dueño', [adminName]: 'Administrador' };
    const passwords = {
      [ownerName]: `pbkdf2$120000$${ownerSalt}$${ownerHash}`,
      [adminName]: `pbkdf2$120000$${adminSalt}$${adminHash}`
    };

    db.prepare('INSERT INTO store(key,value) VALUES(?,?)').run('elite_user_roles', encodeStored(roles));
    db.prepare('INSERT INTO store(key,value) VALUES(?,?)').run('elite_user_passwords', encodeStored(passwords));
    db.close();
    fs.writeFileSync(legacyFile, JSON.stringify({ elite_user_roles: encodeStored({ [ownerName]: 'Administrador' }), elite_user_passwords: encodeStored({ [ownerName]: 'stale-password' }) }), 'utf8');

    const stored = readAppStoreKeysFromDisk({ dbFile, legacyFile, keys: ['elite_user_roles', 'elite_user_passwords'] });
    check(stored.elite_user_roles && stored.elite_user_roles[ownerName] === 'Dueño', 'Lee los roles reales desde SQLite y descodifica el formato persistido de ProControl.');
    check(stored.elite_user_passwords && stored.elite_user_passwords[ownerName].startsWith('pbkdf2$'), 'Lee la contraseña vigente desde SQLite, nunca desde JSON obsoleto.');
    const missingInSqlite = readAppStoreKeysFromDisk({ dbFile, legacyFile, keys: ['elite_not_present'] });
    check(!Object.prototype.hasOwnProperty.call(missingInSqlite, 'elite_not_present'), 'No recupera desde JSON credenciales ausentes en SQLite, evitando reactivar contraseñas antiguas.');
    check(decodeStoredValue(encodeStored(roles))[ownerName] === 'Dueño', 'Decodifica el sobre seguro exacto usado por Security.obfuscate().');
    const jsonOnlyFile = path.join(root, 'json-only.json');
    fs.writeFileSync(jsonOnlyFile, JSON.stringify({ elite_user_roles: encodeStored(roles), elite_user_passwords: encodeStored(passwords) }), 'utf8');
    const jsonOnly = readAppStoreKeysFromDisk({ dbFile: path.join(root, 'missing.db'), legacyFile: jsonOnlyFile, keys: ['elite_user_roles', 'elite_user_passwords'] });
    check(jsonOnly.elite_user_roles && jsonOnly.elite_user_roles[ownerName] === 'Dueño', 'Usa el respaldo JSON solo cuando no existe una base SQLite.');
    check(verifyStoredPassword(ownerPassword, stored.elite_user_passwords[ownerName]), 'La contraseña PBKDF2 correcta debe validarse.');
    check(!verifyStoredPassword('contraseña-incorrecta', stored.elite_user_passwords[ownerName]), 'Una contraseña equivocada debe fallar.');
    check(!verifyStoredPassword(ownerPassword, 'plaintext-password'), 'Nunca acepta contraseñas en texto plano.');
    check(!verifyStoredPassword(ownerPassword, 'pbkdf2$not-a-number$bad$bad'), 'Rechaza registros PBKDF2 malformados.');

    const goodOwner = findPrivilegedCredential({ user: ownerName.toLowerCase(), password: ownerPassword, roles: stored.elite_user_roles, passwords: stored.elite_user_passwords, requiredRole: 'Dueño' });
    check(goodOwner.ok && goodOwner.role === 'Dueño' && goodOwner.user === ownerName, 'Autoriza únicamente al Dueño auténtico, sin distinguir mayúsculas del nombre.');
    equal(findPrivilegedCredential({ user: 'Dueño inexistente', password: ownerPassword, roles: stored.elite_user_roles, passwords: stored.elite_user_passwords, requiredRole: 'Dueño' }).code, 'AUTH_FAILED', 'Un nombre de usuario inexistente se rechaza.');
    equal(findPrivilegedCredential({ user: ownerName, password: 'incorrecta', roles: stored.elite_user_roles, passwords: stored.elite_user_passwords, requiredRole: 'Dueño' }).code, 'AUTH_FAILED', 'Una contraseña incorrecta no genera sesión.');
    equal(findPrivilegedCredential({ user: adminName, password: adminPassword, roles: stored.elite_user_roles, passwords: stored.elite_user_passwords, requiredRole: 'Dueño' }).code, 'OWNER_REQUIRED', 'Una cuenta Administrador válida no puede entrar en la vinculación reservada al Dueño.');
    check(!findPrivilegedCredential({ user: ownerName, password: ownerPassword, roles: {}, passwords: stored.elite_user_passwords, requiredRole: 'Dueño' }).ok, 'Si el almacén de roles no está disponible, la autenticación falla cerrada.');

    // Native picker tests: temporarily leave fullscreen so Windows cannot hide
    // the dialog behind the fullscreen parent, then restore the exact state.
    const parent = {
      id: 77,
      fullScreen: true,
      maximized: false,
      minimized: false,
      visible: true,
      focusCount: 0,
      isDestroyed: () => false,
      isFullScreen() { return this.fullScreen; },
      isMaximized() { return this.maximized; },
      isMinimized() { return this.minimized; },
      isVisible() { return this.visible; },
      setFullScreen(value) { this.fullScreen = value; },
      show() { this.visible = true; },
      focus() { this.focusCount++; },
      restore() { this.minimized = false; this.visible = true; },
      maximize() { this.maximized = true; },
      minimize() { this.minimized = true; this.visible = false; }
    };
    const sender = { id: 91 };
    const event = { sender };
    let openCalled = 0;
    let saveCalled = 0;
    let messageCalled = 0;
    const nativeDialog = {
      async showOpenDialog(actualParent, options) {
        openCalled++;
        equal(actualParent, parent, 'El selector de archivos se asocia a la ventana que originó la acción.');
        check(parent.fullScreen === false, 'La ventana sale temporalmente de pantalla completa para mostrar el selector.');
        equal(options.title, 'Elegir archivo de identidad', 'Conserva las opciones del selector .pvid.');
        return { canceled: false, filePaths: ['C:/Users/Test/Downloads/ProVenta ID.pvid'] };
      },
      async showSaveDialog(actualParent, options) {
        saveCalled++;
        equal(actualParent, parent, 'El diálogo Guardar también usa la ventana que originó la acción.');
        check(parent.fullScreen === false, 'El diálogo Guardar se muestra fuera de pantalla completa.');
        equal(options.defaultPath, 'C:/Desktop/ProVenta Codigo.pvla2', 'Conserva la ubicación de destino.');
        return { canceled: false, filePath: options.defaultPath };
      },
      async showMessageBox(actualParent, options) {
        messageCalled++;
        equal(actualParent, parent, 'Las alertas nativas usan la ventana de origen.');
        check(parent.fullScreen === false, 'Las alertas no quedan detrás de la ventana de pantalla completa.');
        equal(options.title, 'Archivo ProVenta importado', 'La alerta conserva su título.');
        return { response: 0, checkboxChecked: false };
      }
    };
    const manager = createNativeFileDialogs({ dialog: nativeDialog, BrowserWindow: { fromWebContents: source => source === sender ? parent : null }, wait: async () => {} });
    const openResult = await manager.showOpenDialog(event, { title: 'Elegir archivo de identidad' });
    equal(openResult.filePaths[0], 'C:/Users/Test/Downloads/ProVenta ID.pvid', 'Devuelve el archivo seleccionado sin bloquear el renderer.');
    check(parent.fullScreen === true, 'Restaura pantalla completa después de cerrar el selector Abrir.');
    const saveResult = await manager.showSaveDialog(event, { defaultPath: 'C:/Desktop/ProVenta Codigo.pvla2' });
    equal(saveResult.filePath, 'C:/Desktop/ProVenta Codigo.pvla2', 'Devuelve la ruta seleccionada en Guardar.');
    check(parent.fullScreen === true, 'Restaura pantalla completa después de cerrar el selector Guardar.');
    equal(openCalled, 1, 'Abre exactamente un selector de archivos.');
    equal(saveCalled, 1, 'Abre exactamente un selector Guardar.');
    check(parent.focusCount >= 4, 'Devuelve el foco a ProControl después de los diálogos.');

    // Errors and cancellation also restore fullscreen in the finally path.
    let finishPendingDialog;
    const pendingManager = createNativeFileDialogs({
      dialog: { showOpenDialog: () => new Promise(resolve => { finishPendingDialog = resolve; }) },
      BrowserWindow: { fromWebContents: () => parent },
      wait: async () => {}
    });
    const firstPending = pendingManager.showOpenDialog(event, { title: 'Diálogo en curso' });
    await Promise.resolve();
    await assert.rejects(() => pendingManager.showOpenDialog(event, { title: 'Segundo diálogo' }), error => error && error.code === 'DIALOG_ALREADY_OPEN');
    assertions++;
    finishPendingDialog({ canceled: true, filePaths: [] });
    await firstPending;

    const errorManager = createNativeFileDialogs({
      dialog: { showOpenDialog: async () => { throw Object.assign(new Error('native picker failed'), { code: 'DIALOG_FAILED' }); } },
      BrowserWindow: { fromWebContents: () => parent },
      wait: async () => {}
    });
    await assert.rejects(() => errorManager.showOpenDialog(event, {}), /native picker failed/);
    assertions++;
    check(parent.fullScreen === true, 'Si Windows devuelve un error al abrir el selector, ProControl vuelve a pantalla completa.');

    // With no surviving BrowserWindow parent, the picker falls back to the
    // documented parentless Electron API rather than using a stale global win.
    let parentlessCalled = false;
    const parentless = createNativeFileDialogs({
      dialog: { showOpenDialog: async options => { parentlessCalled = options.title === 'Selector independiente'; return { canceled: true, filePaths: [] }; } },
      BrowserWindow: { fromWebContents: () => null },
      wait: async () => {}
    });
    const canceled = await parentless.showOpenDialog(event, { title: 'Selector independiente' });
    check(parentlessCalled && canceled.canceled === true, 'Si el padre fue destruido, el selector independiente no se queda colgado.');
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }

  return assertions;
};
