#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const builder = fs.readFileSync(path.join(__dirname, 'build-clean-nsis.js'), 'utf8');
const preparer = fs.readFileSync(path.join(__dirname, 'preparar-distribucion-clientes.ps1'), 'utf8');
const verifier = fs.readFileSync(path.join(__dirname, 'verificar-integridad.ps1'), 'utf8');
const windowsValidator = fs.readFileSync(path.join(__dirname, 'validate-windows-release.ps1'), 'utf8');
const entregaBat = fs.readFileSync(path.join(__dirname, 'entregar.bat'), 'utf8');
const publisher = fs.readFileSync(path.join(__dirname, 'publicar-setup-temporal.ps1'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

assert.equal(pkg.scripts.dist, 'node tools/build-clean-nsis.js');
assert(['26.15.3', '26.18.1'].includes(pkg.devDependencies['electron-builder']));
assert.equal(pkg.build.win.signAndEditExecutable, true);
assert(builder.includes("Platform.WINDOWS.createTarget(['nsis'], Arch.x64)"));
assert(builder.includes("REQUIRED_BUILDER = '26.18.1'"));
assert(builder.includes('inspectNsisFile'));
assert(builder.includes('assertStable'));
assert(builder.includes('differentialPackage: false'));
assert(builder.includes("include: 'build/installer.nsh'"));
assert(builder.includes('CRCCheck\\s+off'));
assert(!builder.includes('installer-recovery.nsh'));
assert(preparer.includes("tools/build-clean-nsis.js"));
assert(preparer.includes('PROCONTROL_NSIS_BUILD.json'));
assert(preparer.includes('Get-FileHash'));
assert(preparer.includes('ProControl_Entrega_{0}_{1}'), 'Cada compilacion debe publicarse en una carpeta nueva e inmutable.');
assert(!/Move-Item\s+-LiteralPath\s+\$deliveryDir/i.test(preparer), 'No mover la entrega anterior: puede estar bloqueada por Windows.');
assert(preparer.includes('$publishedHash2') && preparer.includes('$publishedIntegrityCode'), 'Debe verificar hash y CRC despues de publicar.');
assert(!/7z\.exe|&\s*\$sevenZip|Cannot open the file as archive/i.test(preparer),
  'No usar 7-Zip para verificar un ejecutable NSIS.');
assert(!/Out-File[^\r\n]*-Append|Add-Content/i.test(verifier),
  'El verificador no debe anexar hashes.');
assert(!/npm\.cmd[^\r\n]*run[^\r\n]*dist/i.test(verifier),
  'El verificador no debe reconstruir.');
assert(verifier.includes('Get-FileHash'));
assert(windowsValidator.includes('tools/build-clean-nsis.js'));
assert(!/npm\.cmd[^\r\n]*run[^\r\n]*dist/i.test(windowsValidator));

assert(publisher.includes("$reportPath = Join-Path $deliveryDir 'PROCONTROL-SETUP-SHA256.txt'"),
  'El publicador debe inicializar el reporte dentro de la carpeta de entrega nueva.');
const reportPathAssignment = publisher.indexOf("$reportPath = Join-Path $deliveryDir 'PROCONTROL-SETUP-SHA256.txt'");
const reportPathOutput = publisher.lastIndexOf('Write-Host "REPORTE: $reportPath"');
assert(reportPathAssignment >= 0 && reportPathOutput > reportPathAssignment,
  'El publicador no debe leer reportPath antes de inicializarlo.');
assert(!/Write-Host "REPORTE: \$reportPath"/.test(publisher.slice(0, publisher.indexOf('$reportPath = Join-Path $deliveryDir'))),
  'No debe imprimir reportPath antes de inicializarlo.');

assert(entregaBat.includes('preparar-distribucion-clientes.ps1'));
assert(!/Uninstall-ProControl\.exe.*copy|copy.*Uninstall-ProControl\.exe/i.test(entregaBat),
  'No copiar el desinstalador C# independiente en la entrega NSIS.');

console.log('PASS - el publicador inicializa reportPath antes de utilizarla');
console.log('Installer distribution: 30 comprobaciones aprobadas.');
