'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');

// La aplicación trabaja con una cantidad única en la unidad base. Estas
// comprobaciones evitan que vuelva a aparecer la antigua interfaz de cajas.
assert.match(html, /id="sale-unit-quantity"/, 'La venta debe tener un campo para la cantidad en unidad base.');
assert.match(html, /id="sale-unit-price"/, 'El precio por unidad base debe permanecer identificado.');
assert.match(html, /id="sale-quantity-breakdown"/, 'La venta debe explicar en tiempo real qué cantidad se descontará.');
assert.match(html, /id="sale-unit-quantity"[^>]*value="0"/, 'La venta debe comenzar en cero para evitar añadir cantidades involuntarias.');
assert.doesNotMatch(html, /id="sale-box-quantity"|id="sale-box-price"|id="sale-presentation"/, 'La venta nueva no debe exigir cajas ni presentaciones separadas.');
assert.match(html, /const rawQty = \$\('sale-unit-quantity'\)/, 'La validación debe leer la cantidad única.');
assert.match(html, /ProductUnits\.validateDiscreteQuantity\(quantity, unit\)/, 'La cantidad debe respetar las unidades discretas del producto.');
assert.match(html, /SalesLedgerOps\.validateAvailableStock\(Number\(item\.qty\) \|\| 0, priorQty \+ line\.baseQty\)/, 'La venta debe impedir superar las existencias disponibles.');
assert.match(html, /presentation: 'unit', quantity, unitsPerBox: null/, 'Las líneas nuevas se deben guardar como cantidad en unidad base sin caja.');
assert.match(html, /\$\('sale-unit-quantity'\)\.value = '0';/, 'Al añadir una línea, el campo de cantidad debe reiniciarse a cero.');
assert.match(html, /−\$\{this\._format\(line\.baseQty\)\} \$\{baseUnit\}/, 'El borrador debe indicar la cantidad base que descontará.');
console.log('OK: venta con cantidad única en unidad base, stock validado y sin campos de cajas.');
