#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const htmlPath = path.join(__dirname, '..', 'renderer', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const tests = [];
function test(name, fn) { try { fn(); tests.push({name, ok:true}); } catch (e) { tests.push({name, ok:false, error:e.message}); } }
function rule(selector) {
  const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(escaped + '\\s*\\{([^}]*)\\}', 's');
  const matches = [...html.matchAll(new RegExp(re.source, 'g'))];
  return matches.length ? matches[matches.length - 1][1] : '';
}
test('Existe la optimización específica del dashboard', () => assert(html.includes('pc-dashboard-compact-no-global-scroll')));
test('La página global conserva overflow oculto (sin scroll general)', () => assert(/html,\s*body\s*\{[^}]*overflow:\s*hidden/s.test(html)));
test('El layout del dashboard usa la altura disponible', () => assert(/#page-dashboard\s+\.app-layout\s*\{[^}]*height:\s*calc\(100vh\s*-\s*80px\)[^}]*overflow:\s*hidden/s.test(html)));
test('El contenido principal del dashboard no crea scroll de página', () => assert(/#page-dashboard\s+\.main-content\s*\{[^}]*overflow:\s*hidden/s.test(html)));
test('Las dos tarjetas de indicadores comparten el espacio disponible', () => assert(/#page-dashboard\s+\.dashboard-insights\s*\{[^}]*flex:\s*1\s+1\s+auto[^}]*min-height:\s*0/s.test(html)));
test('La lista de Atención Inmediata desplaza el contenido dentro de su tarjeta', () => assert(/#page-dashboard\s+\.critical-list\s*\{[^}]*overflow-y:\s*auto/s.test(html)));
test('La distribución de familias desplaza el contenido dentro de su tarjeta', () => assert(/#page-dashboard\s+\.family-chart-container\s*\{[^}]*overflow-y:\s*auto/s.test(html)));
test('Se compactaron títulos, padding y gaps de las tarjetas', () => {
  assert(/#page-dashboard\s+\.dashboard-insights\s+\.insight-box\s+h3\s*\{[^}]*font-size:\s*\.93rem/s.test(html));
  assert(/#page-dashboard\s+\.dashboard-insights\s+\.insight-box\s*\{[^}]*padding:\s*\.65rem\s+\.75rem/s.test(html));
});
test('Conserva el arreglo anterior del campo de cantidad de transferencias', () => assert(/\.cart-qty-input\s*\{[^}]*width:\s*96px\s*!important/s.test(html)));
test('Conserva cargadores de ventas y conciliación móvil', () => {
  assert(html.includes('app://sales-ledger.js'));
  assert(html.includes('app://mobile-reconcile.js'));
  assert(html.includes('app://mobile-bridge-ui.js'));
});
test('La barra de navegación compacta los botones sin cortar las etiquetas', () => {
  assert(html.includes('id=\"procontrol-navbar-fit-fix\"'));
  assert(/\.top-navbar \.nav-left > \.navbar-btn\s*\{[^}]*flex:\s*0 0 auto\s*!important/s.test(html));
  assert(/\.top-navbar \.navbar-btn \.navbar-label\s*\{[^}]*white-space:\s*nowrap\s*!important/s.test(html));
  assert(html.includes('class=\"navbar-label\">Cambiar sesión</span>'));
});
test('El botón Gestión económica ahora se llama Análisis y aparece después de Registros', () => {
  const start = html.indexOf("const dropdowns = c.minimal ? '' : `");
  const end = html.indexOf('return `', start);
  assert(start >= 0 && end > start, 'No se localizó la plantilla de navegación');
  const nav = html.slice(start, end);
  assert(nav.includes('class=\"navbar-label\">Análisis</span>'));
  assert(!nav.includes('class=\"navbar-label\">Gestión económica</span>'));
  assert(nav.indexOf('id=\"menu-logistica\"') < nav.indexOf('id=\"menu-auditoria\"'));
  assert(nav.indexOf('id=\"menu-auditoria\"') < nav.indexOf('id=\"menu-pcbm-gestion-economica\"'));
});

test('El tamaño intermedio de los botones evita tanto el recorte como los extremos anteriores', () => {
  assert.match(html, /\.top-navbar \.navbar-btn \.navbar-icon\s*\{[^}]*width:\s*36px/s);
  assert.match(html, /\.top-navbar \.navbar-btn \.navbar-label\s*\{[^}]*font-size:\s*\.64rem/s);
  assert.match(html, /@media \(min-width:\s*769px\) and \(max-width:\s*1150px\)[\s\S]*?\.navbar-icon \{ width:\s*31px/s);
});
test('Todas las ventanas principales tienen margen inferior y pueden desplazarse si desbordan', () => {
  assert.match(html, /id="procontrol-global-bottom-gap-and-overflow"/);
  assert.match(html, /body > section\[id\^="page-"\]\s*\{[^}]*padding-bottom:\s*8px/s);
  assert.match(html, /body > section\[id\^="page-"\]:not\(#page-dashboard\)\s*\{[^}]*overflow-y:\s*auto/s);
  assert.match(html, /\.table-scroll-container,[\s\S]*?padding-bottom:\s*6px/);
  assert.match(html, /\.modal-overlay \.modal-content,[\s\S]*?max-height:\s*calc\(100vh - 24px\)[\s\S]*?overflow-y:\s*auto/);
});
test('El botón de auditoría se etiqueta como Historial en todas las ventanas', () => {
  const navStart = html.indexOf('NAV_CFG: {');
  const navEnd = html.indexOf('\n},', navStart);
  assert.ok(navStart >= 0 && navEnd > navStart);
  const navCfg = html.slice(navStart, navEnd);
  assert.doesNotMatch(navCfg, /auditLabel:\s*'Registros'/);
  assert.equal((navCfg.match(/auditLabel:\s*'Historial'/g) || []).length, 8);
});
test('Estadísticas deja Estudio de Mercado como único módulo y pantalla inicial', () => {
  assert.doesNotMatch(html, /Rotación de Productos/);
  assert.match(html, /📈 Estudio de Mercado/);
  assert.match(html, /if\(pageId === 'page-stats'\) Stats\.showModule\('market_study'\)/);
  assert.match(html, /this\.selectedPOSIndex = null;[\s\S]*?selector\.value = 'all';[\s\S]*?this\.renderMarketAnalysis\(\)/);
  assert.match(html, /#page-stats #stats-dynamic-container[\s\S]*?overflow-y:\s*auto/);
});
test('Los formateadores globales delegan en la política numérica única de ProControl', () => {
  assert.match(html, /<script src="app:\/\/number-format\.js"><\/script>/);
  assert.match(html, /const formatMoney = \(num\) => ProControlNumberFormat\.formatMoney\(num\)/);
  assert.match(html, /ProControlNumberFormat\.formatNumber\(num, maximumFractionDigits\)/);
  assert.match(html, /ProControlNumberFormat\.formatFixed\(num, fractionDigits\)/);
  assert.match(html, /formatGroupedNumber\(qty, 4\)/);
  assert.match(html, /formatGroupedFixed\(cost, 4\)/);
});
test('La distribución de compras muestra Extra total y Extra por unidad base', () => {
  assert.match(html, /Extra asignado \(total\)/);
  assert.match(html, /Extra asignado por unidad/);
  assert.match(html, /money\(extraPerUnit\)\} \/ \$\{esc\(unit\)\}/);
});


test('El botón de salida de usuario se identifica correctamente como Cambiar sesión', () => {
  assert.match(html, /title="Cambiar sesión \(logout\)"/);
  assert.match(html, /title: 'Cambiar sesión'/);
  assert.match(html, /ok: 'Sí, cerrar sesión'/);
});
test('La configuración inicial no solicita ni modifica empleados', () => {
  const setupStart = html.indexOf('<section id="page-setup"');
  const setupEnd = html.indexOf('<!-- DASHBOARD -->', setupStart);
  assert.ok(setupStart >= 0 && setupEnd > setupStart);
  const setup = html.slice(setupStart, setupEnd);
  assert.doesNotMatch(setup, /workers-container|worker-entry|Añadir otro miembro|>Personal</);
  const bizStart = html.indexOf('saveSetup() {');
  const bizEnd = html.indexOf('\nenableEdit(field)', bizStart);
  assert.ok(bizStart >= 0 && bizEnd > bizStart);
  const saveSetup = html.slice(bizStart, bizEnd);
  assert.doesNotMatch(saveSetup, /workers-container|appState\.workers\s*=|workers\.push/);
});
test('Compras y cierres permiten adjuntar fotos y guardarlas en sus registros', () => {
  assert.match(html, /id="purchase-attachment"[^>]*accept="image\/\*"/);
  assert.match(html, /id="closing-attachment"[^>]*accept="image\/\*"/);
  assert.match(html, /attachment: extraDetails\.attachment/);
  assert.match(html, /attachment: session\.attachment/);
  assert.match(html, /RecordPhoto\.render\('det-closing-attachment', c\.attachment/);
  assert.match(html, /RecordPhoto\.render\('purchase-attachment-display', this\.attachment/);
  assert.match(html, /canvas\.toDataURL\('image\/jpeg', 0\.78\)/);
});

test('Las fotografías limitan resolución, protegen la selección más reciente y restauran el adjunto si falla el guardado', () => {
  assert.ok(html.includes('width * height > 32000000'));
  assert.ok(html.includes('_attachmentRequest'));
  assert.ok(html.includes('this.attachment = previousAttachment'));
  assert.ok(html.includes('_closingAttachmentRequests'));
  assert.ok(html.includes('session.attachment = previousAttachment'));
  assert.ok(html.includes("RecordPhoto.render('closing-attachment-display', previousAttachment"));
});

for (const t of tests) console.log(`${t.ok ? 'PASS' : 'FAIL'} - ${t.name}${t.ok ? '' : ': ' + t.error}`);
console.log(`\n${tests.filter(t=>t.ok).length}/${tests.length} pruebas correctas.`);
if (tests.some(t=>!t.ok)) process.exit(1);
