'use strict';
// Integrated regression tests for phases 4–6. The mobileAppReady=true override is
// used only by this isolated synthetic fixture; production remains fail-closed.
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { MobileBridgeStore, stableJson, sha256, signedFields } = require('../electron/mobile-bridge/store');
const { MobileControlPlane } = require('../electron/mobile-bridge/control-plane');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-phase4-6-'));
const desktopId = 'A'.repeat(32);
const posId = 'pos_test_0042';
const deviceId = 'device_test_0042';
const owner = { user: 'Dueño de prueba', role: 'Dueño' };
let assertions = 0;
function check(value, message) { assertions++; assert.ok(value, message); }
function equal(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
function signedDevicePackage({ privateKey, publicKey, packageId, type, payload, deviceId: signerId = deviceId }) {
  const doc = { format: 'procontrol.offline-package', version: 1, packageId, deviceId: signerId, type,
    createdAt: new Date().toISOString(), payload, payloadHash: sha256(stableJson(payload)), signerPublicKey: publicKey };
  doc.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(doc), privateKey).toString('base64') };
  return doc;
}
let store;
try {
  let now = Date.now();
  store = new MobileBridgeStore(temp, { desktopId });
  const keys = crypto.generateKeyPairSync('ed25519');
  const publicPem = keys.publicKey.export({ type: 'spki', format: 'pem' }).toString();
  const privateKey = keys.privateKey;
  store.db.prepare(`INSERT INTO devices(device_id,label,role,enabled,paired_at,public_key,pos_id)
    VALUES(?,?,?,1,?,?,?)`).run(deviceId, 'Dispositivo de pruebas', 'supervisor', now, publicPem, posId);
  const verifier = (token, expectedPosId, expectedPosName) => token === 'POS_TEST_TOKEN_PHASE4_6_000000000000'
    ? { ok: true, payload: { licenseType: 'point-of-sale', deviceId: desktopId, installationMachineId: desktopId,
      posId: expectedPosId, posName: expectedPosName, licenseId: 'LIC-POS-SYNTHETIC' } }
    : { ok: false, code: 'POS_LICENSE_INVALID' };
  const installation = { modules: ['core','inventory','purchases','pos','closings','reports','mobile-integration'], allowedModes: ['SIN_APP','CON_APP'] };
  const plane = new MobileControlPlane(store, { deviceId: desktopId, verifyPointLicense: verifier,
    getInstallationLicense: () => installation, now: () => now });
  // Only this temporary test instance overrides the hard-coded production gate.
  plane.mobileAppReady = true;
  store.controlPlane = plane;

  check(plane.installPointLicense({ posId, posName: 'POS prueba', token: 'POS_TEST_TOKEN_PHASE4_6_000000000000' }, owner).ok,
    'instala licencia POS sintética');
  check(plane.enablePointLicenseEnforcement([{ id: posId, name: 'POS prueba' }], owner).ok,
    'activa control POS solo en la base temporal');
  check(plane.setPOSMode({ posId, mode: 'CON_APP', cutInfo: { backupVerified: true, backupSha256: 'a'.repeat(64), cutAt: now,
    inventorySnapshot: [{ productId: 'prod_test_0042', qty: 10, unit: 'u' }] } }, owner).ok,
    'el fixture puede preparar CON_APP solo para probar validadores');

  const nonOwner = plane.issueShiftPermit({ posId, deviceId, employee: 'Operador no autorizado', startsAt: now - 1000,
    endsAt: now + 60 * 60 * 1000, sequence: 2,
    emergency: { enabled: true, maxSales: 2, expiresAt: now + 20 * 60 * 1000, reason: 'Prueba de autorización' } },
    { user: 'Administrador de prueba', role: 'Administrador' });
  check(!nonOwner.ok && nonOwner.code === 'EMERGENCY_REQUIRES_OWNER', 'solo Dueño puede autorizar emergencia');

  const permit = plane.issueShiftPermit({ posId, deviceId, employee: 'Operador sintético', startsAt: now - 1000,
    endsAt: now + 2 * 60 * 60 * 1000, sequence: 1,
    emergency: { enabled: true, maxSales: 2, expiresAt: now + 30 * 60 * 1000, reason: 'Sin conexión temporal' } }, owner);
  check(permit.ok, 'emite permiso sintético de emergencia con cuota y expiración');
  const verifiedPermit = plane.verifyShiftPermit(permit.permitId, { posId, deviceId, eventAt: now });
  check(verifiedPermit.ok && verifiedPermit.permit.emergency.maxSales === 2, 'la firma del permiso conserva los límites de emergencia');
  const openAt = new Date(now).toISOString();
  const openPackage = signedDevicePackage({ privateKey, publicKey: publicPem, packageId: 'pkg_phase6_shift_open_01', type: 'shift_open',
    payload: { schemaVersion: 1, shiftPermitId: permit.permitId, sequence: 1,
      shift: { id: 'shift_phase6_0001', posId, startedAt: openAt, sequence: 1 } } });
  const openImport = store.importOfflineBundle(JSON.stringify(openPackage));
  check(openImport.ok && openImport.status === 'pending_review', 'recibe inicio de turno firmado como pendiente');
  check(store.markPackage(openPackage.packageId, 'accepted_for_reconciliation', 'desktop-local').ok, 'autoriza explícitamente el inicio de turno');
  equal(plane.verifyShiftPermit(permit.permitId, { posId, deviceId, eventAt: now }).status, 'opened', 'el permiso solo se abre después de aprobar el paquete');

  function salePackage(packageId, saleIds) {
    const at = new Date(Math.min(now, permit.permit.emergency.expiresAt - 1000)).toISOString();
    const transactions = saleIds.map(id => ({ id, posId, shiftPermitId: permit.permitId, ts: at,
      items: [{ productId: 'prod_test_0042', name: 'Producto de prueba', baseQty: 1 }] }));
    return signedDevicePackage({ privateKey, publicKey: publicPem, packageId, type: 'sale_batch',
      payload: { schemaVersion: 1, shiftPermitId: permit.permitId, transactions } });
  }
  const sales2 = salePackage('pkg_phase6_sales_two_01', ['sale_phase6_0001','sale_phase6_0002']);
  const salesImport = store.importOfflineBundle(JSON.stringify(sales2));
  check(salesImport.ok, 'recibe lote de dos ventas dentro de la cuota firmada');
  check(store.importOfflineBundle(JSON.stringify(sales2)).duplicate, 'reintento idéntico no vuelve a consumir cuota');
  equal(Number(store.db.prepare('SELECT sales_count AS n FROM shift_emergency_usage WHERE permit_id=?').get(permit.permitId).n), 2,
    'la cuota se contabiliza una sola vez en el diario persistente');
  const overQuota = salePackage('pkg_phase6_sales_extra_01', ['sale_phase6_0003']);
  const overQuotaResult = store.importOfflineBundle(JSON.stringify(overQuota));
  check(!overQuotaResult.ok && overQuotaResult.code === 'EMERGENCY_SALE_LIMIT_REACHED', 'un paquete posterior no puede superar la cuota');
  const returnPackage = signedDevicePackage({ privateKey, publicKey: publicPem, packageId: 'pkg_phase6_emergency_return_01', type: 'return',
    payload: { schemaVersion: 1, shiftPermitId: permit.permitId, transactions: [{ id: 'ret_phase6_0001', posId, shiftPermitId: permit.permitId,
      ts: new Date(now).toISOString(), items: [{ productId: 'prod_test_0042', baseQty: 1 }] }] } });
  const returnResult = store.importOfflineBundle(JSON.stringify(returnPackage));
  check(!returnResult.ok && returnResult.code === 'EMERGENCY_RETURNS_NOT_ALLOWED', 'emergencia no permite devoluciones');

  const mismatchClose = signedDevicePackage({ privateKey, publicKey: publicPem, packageId: 'pkg_phase6_shift_close_wrong_01', type: 'shift_close',
    payload: { schemaVersion: 1, shiftPermitId: permit.permitId,
      shift: { id: 'shift_phase6_WRONG', posId, closedAt: new Date(now).toISOString() } } });
  const mismatchResult = store.importOfflineBundle(JSON.stringify(mismatchClose));
  check(!mismatchResult.ok && mismatchResult.code === 'SHIFT_CLOSE_SCOPE_INVALID', 'no permite cerrar un turno con otro ID');
  const closePackage = signedDevicePackage({ privateKey, publicKey: publicPem, packageId: 'pkg_phase6_shift_close_01', type: 'shift_close',
    payload: { schemaVersion: 1, shiftPermitId: permit.permitId,
      shift: { id: 'shift_phase6_0001', posId, closedAt: new Date(now).toISOString() } } });
  check(store.importOfflineBundle(JSON.stringify(closePackage)).ok, 'recibe solicitud de cierre');
  equal(plane.listPendingClosures(posId).length, 0, 'el cierre no aparece para aprobación antes de aceptar su paquete');
  check(store.markPackage(closePackage.packageId, 'accepted_for_reconciliation', 'desktop-local').ok, 'acepta paquete de cierre para conciliación autorizada');
  const closeApply = store.beginPackageApply(closePackage.packageId, 'desktop-local');
  check(closeApply.ok, 'inicia la conciliación del paquete de cierre');
  const closeApplied = store.markPackageApplied(closePackage.packageId, 'desktop-local', {
    reconciledBy: 'desktop-local', shiftId: 'shift_phase6_0001'
  });
  check(closeApplied.ok, 'termina la conciliación del paquete de cierre antes de solicitar aprobación');
  const pending = plane.listPendingClosures(posId);
  equal(pending.length, 1, 'el cierre pasa a la bandeja de aprobación después de aceptar paquete');
  const decision = plane.decidePendingClosure({ closureId: pending[0].closureId, decision: 'confirmed', posId }, owner);
  check(decision.ok && decision.status === 'confirmed', 'Dueño confirma la solicitud de cierre');
  check(plane.decidePendingClosure({ closureId: pending[0].closureId, decision: 'confirmed', posId }, owner).duplicate,
    'repetir la misma aprobación es idempotente');
  equal(plane.verifyShiftPermit(permit.permitId, { posId, deviceId, eventAt: now }).status, 'closed', 'permiso queda cerrado después de la decisión');

  const secondPermit = plane.issueShiftPermit({ posId, deviceId, employee: 'Operador normal', startsAt: now - 1000,
    endsAt: now + 60 * 60 * 1000, sequence: 2 }, owner);
  check(secondPermit.ok, 'se puede emitir un nuevo permiso después de cerrar el anterior');
  equal(secondPermit.permit.emergency.enabled, false, 'emergencia desactivada por defecto en permisos nuevos');
  const blockedActive = plane.issueShiftPermit({ posId, deviceId, employee: 'Turno simultáneo', startsAt: now - 1000,
    endsAt: now + 60 * 60 * 1000, sequence: 3 }, owner);
  check(!blockedActive.ok && blockedActive.code === 'ACTIVE_SHIFT_PERMIT_EXISTS', 'no permite permisos simultáneos para el mismo POS/dispositivo');

  const productionPlane = new MobileControlPlane(store, { deviceId: desktopId, verifyPointLicense: verifier,
    getInstallationLicense: () => installation, now: () => now });
  const blockedPermit = productionPlane.issueShiftPermit({ posId, deviceId, employee: 'Bloqueado en producción',
    startsAt: now - 1000, endsAt: now + 60 * 60 * 1000, sequence: 3 }, owner);
  check(!blockedPermit.ok && blockedPermit.code === 'MOBILE_APP_NOT_AVAILABLE', 'la instancia normal de producción sigue bloqueando permisos móviles');
  const blockedMode = productionPlane.setPOSMode({ posId, mode: 'CON_APP', cutInfo: { backupVerified: true, backupSha256: 'b'.repeat(64), cutAt: now,
    inventorySnapshot: [{ productId: 'prod_test_0042', qty: 10, unit: 'u' }] } }, owner);
  check(!blockedMode.ok && blockedMode.code === 'MOBILE_APP_NOT_AVAILABLE', 'la instancia normal de producción sigue bloqueando CON_APP');
  const transferPackage = signedDevicePackage({ privateKey, publicKey: publicPem, packageId: 'pkg_phase4_transfer_01', type: 'transfer',
    payload: { schemaVersion: 1, transfer: { id: 'transfer_phase4_0001', source: posId, destination: 'pos_test_0043',
      items: [{ productId: 'prod_test_0042', name: 'Producto de prueba', qty: 1, unit: 'u' }] } } });
  check(store.importOfflineBundle(JSON.stringify(transferPackage)).ok, 'registra recepción de transferencia firmada en el diario compartido');
  check(store.markPackage(transferPackage.packageId, 'accepted_for_reconciliation', 'desktop-local').ok, 'autoriza la transferencia para conciliación');
  check(store.beginPackageApply(transferPackage.packageId, 'desktop-local').ok, 'inicia aplicación idempotente de transferencia');
  check(store.markPackageApplied(transferPackage.packageId, 'desktop-local', { newOperations: 1 }).ok, 'finaliza paquete y evento de transferencia juntos');
  const transferHistory = plane.listTransferHistory('transfer_phase4_0001');
  check(transferHistory.some(event => event.status === 'received') && transferHistory.some(event => event.status === 'reconciled'),
    'el historial deja constancia de recepción y conciliación');
  check(store.markPackageApplied(transferPackage.packageId, 'desktop-local', {}).duplicate, 'el ACK final de una transferencia es idempotente');
  store.db.prepare(`UPDATE pos_modes SET mode='SIN_APP' WHERE pos_id=?`).run(posId);
  const transferInDesktopMode = signedDevicePackage({ privateKey, publicKey: publicPem, packageId: 'pkg_phase4_transfer_blocked_01', type: 'transfer',
    payload: { schemaVersion: 1, transfer: { id: 'transfer_phase4_blocked_01', source: posId, destination: 'pos_test_0043',
      items: [{ productId: 'prod_test_0042', qty: 1, unit: 'u' }] } } });
  const transferBlocked = store.importOfflineBundle(JSON.stringify(transferInDesktopMode));
  check(!transferBlocked.ok && transferBlocked.code === 'MOBILE_MODE_NOT_ENABLED', 'no se importan transferencias móviles comerciales cuando el POS está en SIN_APP');
  equal(store.status().networkListener, false, 'la sincronización sigue sin listener de red');
  console.log(`Phase 4–6 hardening: ${assertions} assertions passed.`);
} finally {
  try { if (store) store.close(); } catch (_) {}
  fs.rmSync(temp, { recursive: true, force: true });
}
