'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const sourceRoot = path.resolve(__dirname, '..', '..');
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-key-rotation-'));
const licensorDir = path.join(tempRoot, 'licensor');
const privateDir = path.join(licensorDir, 'private');
const appElectronDir = path.join(tempRoot, 'app', 'electron');
const generatorSource = path.join(licensorDir, 'gen-license-keys.js');
const oldPrivatePath = path.join(privateDir, 'license_private.pem');
const packagePath = path.join(privateDir, 'ProControl-Emisor.pckey');
const publicPath = path.join(licensorDir, 'license_public.pem');
const configPath = path.join(appElectronDir, 'license-config.js');
const sentinelPath = path.join(licensorDir, 'ROTACION-CLAVE-REQUERIDA.txt');
const htmlTemplate = path.join(licensorDir, 'Generador-Codigos-ProControl.template.html');
const htmlOutput = path.join(licensorDir, 'Generador-Codigos-ProControl.html');
const testPassword = 'Test-Only-ProControl-Key-2026!';

function configText(publicPem) {
  const lines = publicPem.trim().split(/\r?\n/).map(line => `    '${line}'`);
  return ['module.exports = {', "  APP_ID: 'procontrol',", "  LICENSE_PREFIX: 'PCL1',", '  LICENSE_PUBLIC_KEY_PEM: [', lines.join(',\n'), "  ].join('\\n')", '};', ''].join('\n');
}
function sign(payload, privateKey) {
  const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const signed = Buffer.from(`PCL1.${payloadB64}`, 'ascii');
  return `PCL1.${payloadB64}.${crypto.sign(null, signed, privateKey).toString('base64url')}`;
}
function copyFile(from, to) { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(from, to); }

try {
  fs.mkdirSync(privateDir, { recursive: true });
  fs.mkdirSync(appElectronDir, { recursive: true });
  const oldPair = crypto.generateKeyPairSync('ed25519');
  const oldPrivatePem = oldPair.privateKey.export({ type: 'pkcs8', format: 'pem' });
  const oldPublicPem = oldPair.publicKey.export({ type: 'spki', format: 'pem' });
  fs.writeFileSync(oldPrivatePath, oldPrivatePem, { encoding: 'utf8', mode: 0o600 });
  fs.writeFileSync(publicPath, oldPublicPem, 'utf8');
  fs.writeFileSync(configPath, configText(oldPublicPem), 'utf8');
  fs.writeFileSync(sentinelPath, 'rotation locked\n', 'utf8');

  for (const rel of [
    'licensor/gen-license-keys.js',
    'licensor/Generador-Codigos-ProControl.template.html',
    'licensor/emitir-licencia.js',
    'licensor/emitir-licencia-pos.js',
    'app/electron/license-core.js'
  ]) {
    const dest = rel.startsWith('app/') ? path.join(tempRoot, rel) : path.join(tempRoot, rel);
    copyFile(path.join(sourceRoot, rel), dest);
  }

  const rotation = spawnSync(process.execPath, [generatorSource, '--force'], {
    cwd: tempRoot,
    encoding: 'utf8',
    env: { ...process.env, GITHUB_ACTIONS: 'true', PROCONTROL_KEY_PASSWORD: testPassword }
  });
  assert.equal(rotation.status, 0, `la rotación aislada debe terminar correctamente: ${rotation.stderr}`);
  assert.match(rotation.stdout, /ROTACIÓN COMPLETADA/i);
  assert.match(rotation.stdout, /paquete cifrado/i);
  assert.ok(fs.existsSync(sentinelPath), 'el bloqueo debe permanecer activo');
  assert.ok(!fs.existsSync(oldPrivatePath), 'la clave privada antigua en PEM debe retirarse');

  const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
  assert.equal(pkg.format, 'PCKEY1');
  assert.equal(pkg.cipher, 'AES-256-GCM');
  assert.ok(pkg.iterations >= 300000);
  const salt = Buffer.from(pkg.salt, 'base64');
  const iv = Buffer.from(pkg.iv, 'base64');
  const tag = Buffer.from(pkg.tag, 'base64');
  const ciphertext = Buffer.from(pkg.ciphertext, 'base64');
  const key = crypto.pbkdf2Sync(testPassword, salt, pkg.iterations, 32, 'sha256');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  const newPrivatePem = Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
  const newPrivate = crypto.createPrivateKey(newPrivatePem);
  const newPublicPem = fs.readFileSync(publicPath, 'utf8');
  const newPublic = crypto.createPublicKey(newPublicPem);
  const derived = crypto.createPublicKey(newPrivate).export({ type: 'spki', format: 'der' });
  assert.ok(derived.equals(newPublic.export({ type: 'spki', format: 'der' })), 'el paquete cifrado debe contener la nueva clave privada correspondiente');
  assert.equal(pkg.publicFingerprint, crypto.createHash('sha256').update(newPublic.export({ type: 'spki', format: 'der' })).digest('hex'));

  delete require.cache[require.resolve(configPath)];
  const config = require(configPath);
  assert.equal(config.LICENSE_PUBLIC_KEY_PEM.trim(), newPublicPem.trim(), 'la pública de ProControl coincide con la clave nueva');
  assert.notEqual(newPublicPem.trim(), oldPublicPem.trim(), 'la nueva clave pública es distinta de la anterior');
  assert.ok(fs.existsSync(htmlOutput), 'se debe crear el HTML final del generador');
  const html = fs.readFileSync(htmlOutput, 'utf8');
  assert.match(html, /const EMBEDDED_PACKAGE = \{/);
  assert.ok(html.includes(pkg.publicFingerprint), 'el HTML debe incluir el mismo paquete cifrado');
  assert.ok(!html.includes('BEGIN PRIVATE KEY'), 'el HTML no debe contener la clave privada en texto claro');
  assert.ok(!fs.readFileSync(packagePath, 'utf8').includes('BEGIN PRIVATE KEY'), 'el archivo .pckey no debe contener la clave privada en texto claro');

  const histories = fs.readdirSync(path.join(licensorDir, 'rotation-history'));
  assert.equal(histories.length, 1, 'se respalda una sola copia de configuración pública previa');
  const backupDir = path.join(licensorDir, 'rotation-history', histories[0]);
  assert.equal(fs.readFileSync(path.join(backupDir, 'license_public.pem'), 'utf8').trim(), oldPublicPem.trim());
  assert.ok(!fs.readdirSync(backupDir).some(name => /private|license_private/i.test(name)), 'el respaldo no debe contener clave privada');

  const deviceId = 'A'.repeat(32);
  const payload = { v: 1, app: 'procontrol', plan: 'permanent', deviceId, licenseId: 'ROTATION-SMOKE-TEST', issuedAt: '2026-10-27T00:00:00.000Z' };
  const core = require(path.join(tempRoot, 'app', 'electron', 'license-core.js'));
  const newToken = sign(payload, newPrivate);
  assert.equal(core.verifyLicense(newToken, { publicKey: config.LICENSE_PUBLIC_KEY_PEM, deviceId, now: new Date('2026-10-27T01:00:00.000Z') }).ok, true,
    'la licencia firmada con el nuevo par debe verificarse');
  const oldToken = sign(payload, oldPair.privateKey);
  assert.equal(core.verifyLicense(oldToken, { publicKey: config.LICENSE_PUBLIC_KEY_PEM, deviceId, now: new Date('2026-10-27T01:00:00.000Z') }).ok, false,
    'la clave pública nueva debe rechazar la clave antigua');

  const installationAttempt = spawnSync(process.execPath, [path.join(licensorDir, 'emitir-licencia.js'), deviceId, 'Prueba local'], { cwd: tempRoot, encoding: 'utf8' });
  assert.notEqual(installationAttempt.status, 0, 'el emisor antiguo debe bloquearse durante la rotación');
  assert.match(installationAttempt.stderr, /Emisión bloqueada/i);
  const posAttempt = spawnSync(process.execPath, [path.join(licensorDir, 'emitir-licencia-pos.js'), deviceId, 'pos_prueba', 'Caja prueba', 'Prueba local'], { cwd: tempRoot, encoding: 'utf8' });
  assert.notEqual(posAttempt.status, 0, 'el emisor POS de consola debe bloquearse');
  assert.match(posAttempt.stderr, /Emisión bloqueada/i);
  assert.ok(!fs.existsSync(path.join(licensorDir, 'emitidas')), 'no se deben crear licencias por emisores bloqueados');

  const repeatAttempt = spawnSync(process.execPath, [generatorSource, '--force'], {
    cwd: tempRoot, encoding: 'utf8',
    env: { ...process.env, GITHUB_ACTIONS: 'true', PROCONTROL_KEY_PASSWORD: testPassword }
  });
  assert.notEqual(repeatAttempt.status, 0, 'el configurador no debe rotar accidentalmente una clave ya creada');
  assert.match(repeatAttempt.stderr, /Ya existe ProControl-Emisor\.pckey/i);

  console.log('License key rotation: passed (encrypted vault + HTML issuer; isolated temp copy).');
} finally {
  fs.rmSync(tempRoot, { recursive: true, force: true });
}
