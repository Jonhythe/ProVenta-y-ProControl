'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const path = require('node:path');

const htmlPath = process.argv[2];
assert.ok(htmlPath, 'Debe indicarse la ruta del HTML generado.');
const html = fs.readFileSync(htmlPath, 'utf8');
const configPath = path.resolve(__dirname, '..', 'electron', 'license-config.js');
const config = require(configPath);

assert.match(html, /const EMBEDDED_PACKAGE = \{/, 'El generador debe llevar el paquete cifrado incorporado.');
const match = html.match(/const EMBEDDED_PACKAGE = (\{[\s\S]*?\});/);
assert.ok(match, 'Debe poder leerse el paquete cifrado integrado.');
const pkg = JSON.parse(match[1]);

assert.equal(pkg.format, 'PCKEY1');
assert.equal(pkg.kdf, 'PBKDF2-SHA256');
assert.equal(pkg.cipher, 'AES-256-GCM');
assert.ok(Number(pkg.iterations) >= 300000);
assert.ok(!html.includes('BEGIN PRIVATE KEY'), 'No debe existir clave privada en texto claro.');

const key = crypto.createPublicKey(pkg.publicKeyPem);
assert.equal(key.asymmetricKeyType, 'ed25519');
const fingerprint = crypto.createHash('sha256').update(key.export({ type: 'spki', format: 'der' })).digest('hex');
assert.equal(pkg.publicFingerprint, fingerprint);
assert.equal(config.LICENSE_PUBLIC_KEY_PEM.trim(), pkg.publicKeyPem.trim(),
  'La clave pública del generador debe coincidir con la clave pública de la aplicación.');

assert.match(html, /id="deviceId"/, 'Debe pedir el ID del equipo.');
assert.match(html, /id="keyPassword"/, 'Debe proteger el emisor con la contraseña del dueño.');
assert.doesNotMatch(html, /id="customer"|id="plan"/, 'No debe pedir cliente ni permitir escoger el plan.');
assert.doesNotMatch(html, /Prueba de 1 hora|Prueba de 1 semana|expiresAt/, 'No debe contener licencias temporales.');
assert.match(html, /plan:'permanent'/, 'Toda licencia generada debe ser permanente.');
assert.match(html, /crypto\.subtle\.sign/, 'Debe firmar con Ed25519.');
assert.match(html, /crypto\.subtle\.verify/, 'Debe verificar la firma antes de mostrar el código.');
assert.match(html, /COPIAR CÓDIGO/, 'Debe permitir copiar el código.');
assert.match(html, /Guardar archivo \.lic/, 'Debe permitir guardar el archivo de licencia.');

console.log('Permanent owner generator: all checks passed.');
