#!/usr/bin/env node
// ============================================================
// PROCONTROL - GUARDA ANTI-REGRESION DE SECRETOS
// ============================================================
// Ejecutar:  node app/tools/check-no-secrets.js [--require-build] [--build-dir <carpeta>]
//
// --build-dir <carpeta>: usa SOLO el app.asar de esa carpeta de
//   build (ej. D:\ProControl\app\dist_final). Sin este
//   argumento, busca en dist_final, PROCONTROL_BUILD_ROOT y raíces
//   conocidas C:\ProControl / D:\ProControl, usando el build más reciente.
//
// 1. Escanea app/electron, app/renderer, app/build y package.json.
// 2. Extrae el app.asar del build indicado (con @electron/asar,
//    offline) y escanea su contenido. Esta es la UNICA parte que
//    cuenta para el resultado LIMPIO / FALLO, junto con el codigo
//    fuente.
// 3. Escanea en binario el Setup.exe y el portable, SOLO de forma
//    INFORMATIVA: los instaladores van comprimidos, asi que NO
//    encontrar nada ahi NO demuestra ausencia de secretos. Esta
//    seccion nunca hace fallar el resultado.
//
// Sale con codigo 0 si el codigo fuente y el asar extraido estan
// limpios; distinto de 0 si encuentra cualquier secreto, si no
// hay ningun asar que escanear, o si no se pudo extraer.
// ============================================================
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');

const APP_DIR = path.resolve(__dirname, '..');
const SOURCE_DIRS = [
  path.join(APP_DIR, 'electron'),
  path.join(APP_DIR, 'renderer'),
  path.join(APP_DIR, 'build')
];
const PACKAGE_JSON = path.join(APP_DIR, 'package.json');

const NEEDLES = [
  'Y3YbL7GzGbDJxyaxst8i4tYa1lMeBg/y',
  '268ef8d96147b1bc411e6efcc02ca244eab9ee4fd62d134f56b53d9b6ac16ef9',
  'TOTP_SECRET',
  'LICENSE_HMAC',
  'PC_SECRET',
  'pc-install-code',
  'PRIVATE KEY'
];

const PRIVATE_KEY_PEM_RE = /-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----/i;

const REQUIRE_BUILD = process.argv.includes('--require-build');
const buildDirIdx = process.argv.indexOf('--build-dir');
const BUILD_DIR = buildDirIdx !== -1 ? process.argv[buildDirIdx + 1] : null;
if (buildDirIdx !== -1 && !BUILD_DIR) {
  console.error('--build-dir necesita una carpeta: --build-dir C:\\ProControl\\EB-build-...');
  process.exit(1);
}

const findings = [];
const infoOnly = [];
let scannedFiles = 0;

function record(where, needle) {
  findings.push(where + ' -> "' + needle + '"');
}

function recordInfo(where, needle) {
  infoOnly.push(where + ' -> "' + needle + '"');
}

function scanTextFile(file, wherePrefix) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (_) {
    return;
  }
  scannedFiles++;
  for (const needle of NEEDLES) {
    if (text.indexOf(needle) !== -1) record(wherePrefix + path.relative(APP_DIR, file), needle);
  }
  if (PRIVATE_KEY_PEM_RE.test(text)) record(wherePrefix + path.relative(APP_DIR, file), 'PRIVATE KEY PEM (patron)');
}

function walk(dir, wherePrefix) {
  if (!fs.existsSync(dir)) return;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walk(full, wherePrefix);
    } else if (entry.isFile()) {
      scanTextFile(full, wherePrefix);
    }
  }
}

function scanBufferInfo(buf, where) {
  if (PRIVATE_KEY_PEM_RE.test(buf.toString('latin1'))) recordInfo(where, 'PRIVATE KEY PEM (patron)');
  for (const needle of NEEDLES) {
    if (buf.includes(Buffer.from(needle, 'ascii'))) recordInfo(where, needle);
    if (buf.includes(Buffer.from(needle, 'utf16le'))) recordInfo(where, needle + ' (UTF-16LE)');
  }
}

// ------------------------------------------------------------
// 1. Codigo fuente
// ------------------------------------------------------------
console.log('== 1. Codigo fuente ==');
for (const dir of SOURCE_DIRS) {
  console.log('  Escaneando ' + dir);
  walk(dir, '');
}
if (fs.existsSync(PACKAGE_JSON)) {
  scanTextFile(PACKAGE_JSON, '');
  console.log('  Escaneando ' + PACKAGE_JSON);
}

// ------------------------------------------------------------
// 2. app.asar del build (UNICA fuente binaria que cuenta)
// ------------------------------------------------------------
console.log('');
console.log('== 2. app.asar del build ==');

function discoverBuildRoots() {
  const roots = new Set();
  const add = value => {
    if (!value) return;
    const resolved = path.resolve(value);
    if (fs.existsSync(resolved)) roots.add(resolved);
  };
  for (const value of String(process.env.PROCONTROL_BUILD_ROOT || '').split(path.delimiter)) add(value.trim());
  add(path.join(APP_DIR, 'dist_final'));
  add(path.join(APP_DIR, 'dist'));
  add(path.join(APP_DIR, 'build-output'));
  add(path.dirname(APP_DIR));
  add('C:\\ProControl');
  add('D:\\ProControl');
  return [...roots];
}

function findAsarCandidates() {
  if (BUILD_DIR) {
    const candidate = path.join(BUILD_DIR, 'win-unpacked', 'resources', 'app.asar');
    return fs.existsSync(candidate) ? [candidate] : [];
  }
  const found = [];
  for (const root of discoverBuildRoots()) {
    const directCandidates = [
      path.join(root, 'win-unpacked', 'resources', 'app.asar'),
      path.join(root, 'dist_final', 'win-unpacked', 'resources', 'app.asar'),
      path.join(root, 'dist', 'win-unpacked', 'resources', 'app.asar')
    ];
    for (const candidate of directCandidates) if (fs.existsSync(candidate)) found.push(candidate);
    try {
      for (const name of fs.readdirSync(root)) {
        if (!/^(?:EB-build|dist_final|build-output)/i.test(name)) continue;
        const candidate = path.join(root, name, 'win-unpacked', 'resources', 'app.asar');
        if (fs.existsSync(candidate)) found.push(candidate);
      }
    } catch (_) { /* raíz no legible */ }
  }
  const unique = [...new Set(found.map(p => path.resolve(p)))];
  unique.sort((a, b) => {
    try { return fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs; } catch (_) { return 0; }
  });
  return unique;
}

function findDeliveryArtifacts() {
  const dirs = [];
  if (BUILD_DIR) {
    dirs.push(path.resolve(BUILD_DIR));
  } else {
    for (const root of discoverBuildRoots()) {
      try {
        for (const name of fs.readdirSync(root)) {
          const fullPath = path.join(root, name);
          if (!fs.statSync(fullPath).isDirectory()) continue;
          if (/^(?:EntregaFinal_1\.1|EB-build|dist_final|build-output)/i.test(name)) dirs.push(fullPath);
          if (/^dist_final$/i.test(name) && fs.existsSync(path.join(fullPath, 'win-unpacked'))) dirs.push(fullPath);
        }
      } catch (_) { /* raíz no legible */ }
      if (fs.existsSync(path.join(root, 'win-unpacked'))) dirs.push(root);
    }
  }
  const setup = [];
  const portable = [];
  for (const dir of [...new Set(dirs)]) {
    if (!fs.existsSync(dir)) continue;
    try {
      for (const name of fs.readdirSync(dir)) {
        if (!/\.exe$/i.test(name)) continue;
        if (/setup/i.test(name)) setup.push(path.join(dir, name));
        else if (/portable/i.test(name)) portable.push(path.join(dir, name));
      }
    } catch (_) { /* carpeta no legible */ }
  }
  return { setup: [...new Set(setup)], portable: [...new Set(portable)] };
}

let asarChecked = false;
const asarCandidates = findAsarCandidates();
if (asarCandidates.length === 0) {
  console.log('  AVISO: no se encontro app.asar de un build' + (BUILD_DIR ? ' en ' + BUILD_DIR : '') + '.');
  findings.push('No se encontro app.asar para escanear (obligatorio: sin esto el resultado no es valido)');
} else {
  const asarPath = asarCandidates[0];
  console.log('  Usando ' + asarPath);

  let asarLib = null;
  try {
    asarLib = require(path.join(APP_DIR, 'node_modules', '@electron', 'asar'));
  } catch (_) {
    try { asarLib = require('@electron/asar'); } catch (_) { /* sin libreria */ }
  }

  if (!asarLib) {
    findings.push('No se pudo cargar @electron/asar para extraer el paquete');
  } else {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-asar-'));
    try {
      asarLib.extractAll(asarPath, tmp);
      const before = findings.length;
      walk(tmp, 'app.asar/');
      asarChecked = true;
      console.log('  Extraido y escaneado en ' + tmp);
      if (findings.length === before) console.log('  Sin secretos en el contenido extraido.');
    } catch (err) {
      findings.push('No se pudo extraer app.asar: ' + err.message);
    } finally {
      try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (_) { /* temporal */ }
    }
  }
}

// ------------------------------------------------------------
// 3. Instalador y portable (binario) - SOLO INFORMATIVO
// ------------------------------------------------------------
console.log('');
console.log('== 3. Instalador y portable (solo informativo) ==');
console.log('  Los instaladores van comprimidos: esto NO demuestra ausencia de secretos.');
const artifacts = findDeliveryArtifacts();
const binaries = artifacts.setup.concat(artifacts.portable);
if (binaries.length === 0) {
  console.log('  AVISO: no se encontraron Setup.exe / portable en las carpetas de entrega 1.1.x.');
} else {
  for (const bin of binaries) {
    console.log('  Escaneando (informativo) ' + bin);
    scanBufferInfo(fs.readFileSync(bin), path.basename(bin));
  }
}
if (infoOnly.length > 0) {
  console.log('  Coincidencias informativas (no afectan el resultado):');
  for (const f of infoOnly) console.log('    - ' + f);
}

// ------------------------------------------------------------
// Resultado
// ------------------------------------------------------------
console.log('');
console.log('Archivos de texto escaneados: ' + scannedFiles);
if (findings.length > 0) {
  console.error('SECRETOS O PROBLEMAS ENCONTRADOS:');
  for (const f of findings) console.error('  - ' + f);
  console.error('CHECK-NO-SECRETS: FALLO');
  process.exit(1);
}
if (!asarChecked) {
  console.error('CHECK-NO-SECRETS: FALLO (no se extrajo ni escaneo ningun app.asar)');
  process.exit(1);
}
console.log('CHECK-NO-SECRETS: LIMPIO (codigo fuente + asar verificado)');
process.exit(0);
