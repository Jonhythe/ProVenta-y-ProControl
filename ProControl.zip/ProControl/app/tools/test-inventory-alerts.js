'use strict';
const assert = require('node:assert/strict');
const Alerts = require('../renderer/inventory-alerts.js');
let passed = 0;
function test(name, fn) { fn(); passed += 1; console.log(`OK ${passed}: ${name}`); }

test('usa un límite manual por defecto de 10 unidades sin historial de ventas', () => {
  const results = Alerts.evaluate([
    { id: 'critical', name: 'Crítico', qty: 10, unit: 'u' },
    { id: 'warning', name: 'Aviso', qty: 11, unit: 'u' },
    { id: 'normal', name: 'Normal', qty: 21, unit: 'u' }
  ]);
  const byId = Object.fromEntries(results.map(row => [row.item.id, row]));
  assert.equal(byId.critical.status, 'critical');
  assert.equal(byId.critical.alertStock, 10);
  assert.equal(byId.warning.status, 'reorder');
  assert.equal(byId.warning.warningThreshold, 20);
  assert.equal(byId.normal.status, 'ok');
  assert.equal(byId.critical.hasRecentDemand, false);
});

test('el límite y la banda de aviso respetan exactamente los extremos', () => {
  const result = Alerts.evaluate([
    { id: 'below', name: 'Por debajo', qty: 4, stockAlertSettings: { alertStock: 5 } },
    { id: 'at', name: 'En el límite', qty: 5, stockAlertSettings: { alertStock: 5 } },
    { id: 'one-above', name: 'Uno por encima', qty: 6, stockAlertSettings: { alertStock: 5 } },
    { id: 'edge-warning', name: 'Límite de aviso', qty: 15, stockAlertSettings: { alertStock: 5 } },
    { id: 'over-warning', name: 'Fuera del aviso', qty: 16, stockAlertSettings: { alertStock: 5 } }
  ]);
  const byId = Object.fromEntries(result.map(row => [row.item.id, row]));
  assert.equal(byId.below.status, 'critical');
  assert.equal(byId.at.status, 'critical');
  assert.equal(byId['one-above'].status, 'reorder');
  assert.equal(byId['edge-warning'].status, 'reorder');
  assert.equal(byId['over-warning'].status, 'ok');
});

test('no depende de tickets ni cierres aunque se pasen como argumentos', () => {
  const product = { id: 'water', name: 'Agua', qty: 18, stockAlertSettings: { alertStock: 10 } };
  const sales = [{ kind: 'sale', ts: '2026-10-29T00:00:00.000Z', items: [{ productId: 'water', baseQty: 10000 }] }];
  const closingHistory = [{ salesTrackingMode: false, products: [{ productId: 'water', sold: 10000 }] }];
  const alert = Alerts.evaluate([product], sales, { closingHistory, asOf: new Date('2026-10-29T00:00:00.000Z') })[0];
  assert.equal(alert.status, 'reorder');
  assert.equal(alert.alertStock, 10);
  assert.equal(alert.warningThreshold, 20);
  assert.equal(alert.averageDailySales, 0);
  assert.equal(alert.demandSource, 'manual');
});

test('mantiene compatibilidad con configuraciones previas que guardaban manualMinimum', () => {
  const alert = Alerts.evaluate([{ id: 'legacy', name: 'Antiguo', qty: 24, stockAlertSettings: { manualMinimum: 15, leadTimeDays: 4, safetyStockUnits: 3 } }])[0];
  assert.equal(alert.alertStock, 15);
  assert.equal(alert.status, 'reorder');
  assert.equal(alert.warningThreshold, 25);
});

test('alertStock nuevo prevalece sobre el mínimo antiguo guardado', () => {
  const alert = Alerts.evaluate([{ id: 'migrated', name: 'Actualizado', qty: 16, stockAlertSettings: { alertStock: 5, manualMinimum: 15 } }])[0];
  assert.equal(alert.alertStock, 5);
  assert.equal(alert.status, 'ok');
});

test('usa mínimo de inventario heredado cuando no hay configuración específica', () => {
  assert.equal(Alerts.evaluate([{ name: 'Producto A', qty: 8, minimumStock: 8 }])[0].status, 'critical');
  assert.equal(Alerts.evaluate([{ name: 'Producto B', qty: 15, minStock: 8 }])[0].status, 'reorder');
  assert.equal(Alerts.evaluate([{ name: 'Producto C', qty: 19, minQty: 8 }])[0].status, 'ok');
});

test('stock agotado siempre es crítico', () => {
  const alert = Alerts.evaluate([{ name: 'Agotado', qty: 0, stockAlertSettings: { alertStock: 0 } }])[0];
  assert.equal(alert.status, 'critical');
  assert.equal(alert.message, 'Agotado');
});

test('configuración inválida del límite usa el valor predeterminado seguro', () => {
  const alert = Alerts.evaluate([{ name: 'Inválido', qty: 10, stockAlertSettings: { alertStock: -3 } }])[0];
  assert.equal(alert.alertStock, 10);
  assert.equal(alert.status, 'critical');
});

test('ordenación pone críticos primero, luego avisos y al final stock normal', () => {
  const result = Alerts.evaluate([
    { id: 'normal', name: 'Normal', qty: 100, stockAlertSettings: { alertStock: 10 } },
    { id: 'warning', name: 'Aviso', qty: 15, stockAlertSettings: { alertStock: 10 } },
    { id: 'critical', name: 'Crítico', qty: 8, stockAlertSettings: { alertStock: 10 } }
  ]);
  assert.deepEqual(result.map(row => row.item.id), ['critical', 'warning', 'normal']);
});

test('maneja entradas inválidas sin lanzar errores', () => {
  assert.deepEqual(Alerts.evaluate(null), []);
  const result = Alerts.evaluate([{ name: 'Stock inválido', qty: 'no-es-numero', stockAlertSettings: { alertStock: 4 } }])[0];
  assert.equal(result.status, 'critical');
});

console.log(`\n${passed}/${passed} pruebas del módulo de alertas manuales aprobadas.`);
