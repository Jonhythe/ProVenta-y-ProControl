'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = relative => fs.readFileSync(path.join(root, relative), 'utf8');
const html = read('renderer/index.html');
const ui = read('renderer/proventa-authorization-ui.js');
const main = read('electron/main.js');
const control = read('electron/mobile-bridge/control-plane.js');
const store = read('electron/mobile-bridge/store.js');
const preload = read('electron/preload.js');
let checks = 0;
function has(condition, message) { checks++; assert.ok(condition, message); }

has(html.includes('Exportar abrir turno'), 'El espacio de trabajo del POS ofrece exportar el permiso de apertura.');
has(html.includes('Recibir cierre de ProVenta') && ui.includes('importShiftClose'), 'El POS ofrece la acción actual para recibir e importar el cierre de ProVenta.');
const retryStart = ui.indexOf('async function retryShiftPermitExport()');
const retryEnd = ui.indexOf('async function exportExistingShiftPermit(', retryStart);
const retryFlow = retryStart >= 0 && retryEnd > retryStart ? ui.slice(retryStart, retryEnd) : '';
has(ui.includes('issueShiftPermit') && ui.includes('api().exportShiftOpeningBundle') &&
  retryFlow.includes('exportPermit(pendingShiftPermit.permitId, posId, pendingShiftPermit.deviceId, authToken)') &&
  !retryFlow.includes('issueShiftPermit('), 'La UI emite y exporta la apertura completa sin recrear el permiso al reintentar.');
has(ui.includes('pendingShiftPermit') && ui.includes('Reintentar exportación'), 'La cancelación del selector conserva el permiso para reintentar la exportación.');
has(ui.includes('listShiftPermits({ posId, authToken })'), 'La lista de permisos se consulta por POS.');
has(ui.includes('authorizedPosId || \'\') === posId'), 'Solo el dispositivo autorizado para el POS actual puede abrir un turno.');
has(ui.includes('function validateCloseReport') && ui.includes('finalQuantityMicros'), 'El cierre valida cantidades finales en microunidades.');
has(ui.includes('new Map()') && ui.includes('missing.length'), 'El informe debe contener exactamente los productos del POS, sin duplicados ni faltantes.');
has(ui.includes('DataStore.transaction(\'proventa-shift-close-reconcile\''), 'La conciliación del cierre ocurre en una transacción de datos.');
has(ui.indexOf('DataStore.transaction(\'proventa-shift-close-reconcile\'') < ui.indexOf('api().markPackageApplied({'), 'ProControl persiste primero el inventario; solo después marca el paquete como conciliado.');
has(ui.includes("failPackageApply({ packageId, authToken, errorCode: 'SHIFT_CLOSE_LOCAL_INVENTORY_SAVE_FAILED' })"), 'Un fallo al guardar inventario restablece la conciliación para poder reintentar.');
has(ui.includes('targetPos.inventory') && ui.includes('posId') && ui.includes('liveIds.length !== updatesById.size') && ui.includes('new Set(liveIds).size !== liveIds.length'), 'La transacción revalida que el inventario del POS siga siendo exactamente el mismo antes de aplicar el cierre.');
has(ui.includes('proventaClosureReceipts') && ui.includes('payloadHash'), 'La repetición del mismo cierre es idempotente y un hash distinto se bloquea.');
has(ui.includes('createPackageAcknowledgement') && ui.includes('savePackageAcknowledgement'), 'Tras confirmar el cierre, ProControl genera el acuse firmado.');
has(main.includes('writeExportFileVerified') && main.includes('EXPORT_FINAL_READBACK_MISMATCH'), 'La exportación vuelve a leer y comparar los bytes del archivo publicado.');
has(main.includes('PERMIT_EXPORT_SIGNATURE_RECHECK_FAILED'), 'La exportación de permiso vuelve a verificar la firma persistida.');
has(control.includes('getShiftPermitForExport') && control.includes('expected.forExport !== true'), 'Se puede exportar un permiso futuro sin tratarlo como turno ya iniciado.');
has(control.includes('WHERE c.status=\'pending_confirmation\'') && control.includes('AND c.pos_id=?'), 'Los cierres pendientes se filtran por el POS solicitado.');
has(control.includes('CLOSURE_POS_SCOPE_MISMATCH'), 'La confirmación de cierre comprueba nuevamente el POS.');
has(store.includes('protocol_version INTEGER NOT NULL DEFAULT 0') && store.includes('device_signing_key_hash'), 'La base migra los campos de autorización de forma compatible.');
has(preload.includes('mobile-control:export-shift-permit'), 'Preload publica el IPC de exportación del permiso.');

has(control.includes('CLOSURE_POS_SCOPE_MISMATCH') && control.includes('CLOSURE_POS_SCOPE_REQUIRED') && control.includes("if (typeof posId !== 'string' || !isPosId(posId)) return []"), 'La bandeja y la confirmación de cierre exigen el POS y fallan cerradas sin él.');
has(control.includes("code: 'SHIFT_PERMIT_EXPIRED'"), 'El exportador distingue y rechaza permisos cuyo horario autorizado ya terminó.');
console.log(`ProVenta shift workflow: ${checks} static assertions passed.`);
