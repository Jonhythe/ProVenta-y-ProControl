#!/usr/bin/env node
// ============================================================
// PROCONTROL - PRUEBAS DEL NUCLEO DE LICENCIAS
// ============================================================
// Ejecutar:  node app/tools/test-license.js
// Sale con codigo 0 si TODO pasa; distinto de 0 si algo falla.
//
// Usa un par de claves Ed25519 TEMPORAL (no toca la clave real
// ni ningun archivo del cliente).
// ============================================================
'use strict';

const crypto = require('crypto');
const path = require('path');
const core = require(path.join(__dirname, '..', 'electron', 'license-core.js'));

const TEST_DEVICE = 'E5A913DBE60647098605531B320F5D5F';
const OTHER_DEVICE = '0123456789ABCDEF0123456789ABCDEF';
const NOW = Date.parse('2026-10-21T12:00:00.000Z');

const keyPair = crypto.generateKeyPairSync('ed25519');
const publicKey = keyPair.publicKey.export({ type: 'spki', format: 'pem' });
const privateKey = keyPair.privateKey;
const otherPair = crypto.generateKeyPairSync('ed25519');

let passed = 0;
let failed = 0;

function check(name, condition, detail) {
  if (condition) {
    passed++;
    console.log('  OK   ' + name);
  } else {
    failed++;
    console.log('  FALLA ' + name + (detail ? ' -> ' + detail : ''));
  }
}

function basePayload(overrides) {
  const payload = {
    v: 1,
    app: 'procontrol',
    deviceId: TEST_DEVICE,
    plan: 'permanent',
    issuedAt: '2026-10-01T10:00:00.000Z',
    licenseId: '0123456789abcdef',
    customer: 'Cliente de Prueba'
  };
  const extra = overrides || {};
  Object.keys(extra).forEach(function (k) { payload[k] = extra[k]; });
  return payload;
}

function signWith(payload, key) {
  const json = JSON.stringify(payload);
  const payloadB64 = Buffer.from(json, 'utf8').toString('base64url');
  const signed = Buffer.from('PCL1.' + payloadB64, 'ascii');
  const signature = crypto.sign(null, signed, key || privateKey);
  return 'PCL1.' + payloadB64 + '.' + signature.toString('base64url');
}

function verify(text, device) {
  return core.verifyLicense(text, {
    publicKey: publicKey,
    deviceId: device || TEST_DEVICE,
    now: NOW
  });
}

console.log('== Pruebas de license-core.js ==');

// 1. Licencia valida permanente.
let r = verify(signWith(basePayload()));
check('licencia valida permanente', r.ok === true, JSON.stringify(r));
check('devuelve el payload correcto', r.ok && r.payload.customer === 'Cliente de Prueba');

// 2. Licencia trial vigente.
r = verify(signWith(basePayload({ plan: 'trial', expiresAt: '2026-11-01T00:00:00.000Z' })));
check('licencia trial vigente', r.ok === true, JSON.stringify(r));

// Un trial firmado sin vencimiento nunca debe ser valido.
r = verify(signWith(basePayload({ plan: 'trial' })));
check('trial sin expiresAt rechazado', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 3. Licencia vencida.
r = verify(signWith(basePayload({ plan: 'trial', expiresAt: '2026-10-01T00:00:00.000Z' })));
check('licencia vencida rechazada', !r.ok && r.code === 'EXPIRADA', JSON.stringify(r));

// 4. expiresAt invalido.
r = verify(signWith(basePayload({ expiresAt: 'no-es-fecha' })));
check('expiresAt invalido rechazado', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 5. Payload alterado despues de firmar.
const valid = signWith(basePayload());
const parts = valid.split('.');
const alteredPayload = parts[1].slice(0, -1) + (parts[1].slice(-1) === 'A' ? 'B' : 'A');
r = verify('PCL1.' + alteredPayload + '.' + parts[2]);
check('payload alterado rechazado por FIRMA', !r.ok && r.code === 'FIRMA', JSON.stringify(r));

// 6. Firma de otra clave.
r = verify(signWith(basePayload(), otherPair.privateKey));
check('firma de otra clave rechazada', !r.ok && r.code === 'FIRMA', JSON.stringify(r));

// 7. Licencia de otra PC.
r = verify(signWith(basePayload()), OTHER_DEVICE);
check('licencia de otra PC rechazada', !r.ok && r.code === 'OTRA_PC', JSON.stringify(r));

// 8. Basura.
r = verify('esto no es una licencia');
check('texto basura rechazado', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 9. Vacio.
r = verify('');
check('texto vacio rechazado', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 10. Solo espacios.
r = verify('   \r\n\t  ');
check('solo espacios rechazado', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 11. Mas de 2048 caracteres.
r = verify('PCL1.' + 'A'.repeat(2100) + '.' + 'B'.repeat(86));
check('mas de 2048 caracteres rechazado', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 12. Espacios y saltos de linea pegados se toleran.
const padded = '  ' + valid.slice(0, 10) + ' \r\n ' + valid.slice(10, 40) + '\n\t' + valid.slice(40) + '  ';
r = verify(padded);
check('espacios y saltos de linea tolerados', r.ok === true, JSON.stringify(r));

// 13. JSON con campos de mas.
r = verify(signWith(basePayload({ campoExtra: 'ignorado', otroMas: 123 })));
check('campos de mas tolerados', r.ok === true, JSON.stringify(r));

// 14. JSON sin el campo opcional customer.
const sinCustomer = basePayload();
delete sinCustomer.customer;
r = verify(signWith(sinCustomer));
check('campo opcional customer ausente tolerado', r.ok === true, JSON.stringify(r));

// 15. JSON sin deviceId (campo obligatorio).
const sinDevice = basePayload();
delete sinDevice.deviceId;
r = verify(signWith(sinDevice));
check('campo obligatorio deviceId ausente rechazado', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 16. JSON invalido pero con firma valida -> ID_ILEGIBLE (no crashea).
const badJsonB64 = Buffer.from('{esto no es json', 'utf8').toString('base64url');
const badJsonSig = crypto.sign(null, Buffer.from('PCL1.' + badJsonB64, 'ascii'), privateKey).toString('base64url');
r = verify('PCL1.' + badJsonB64 + '.' + badJsonSig);
check('JSON ilegible con firma valida -> ID_ILEGIBLE', !r.ok && r.code === 'ID_ILEGIBLE', JSON.stringify(r));

// 17. Firma de longitud incorrecta.
r = verify('PCL1.' + parts[1] + '.' + parts[2].slice(0, 20));
check('firma de longitud incorrecta rechazada', !r.ok && r.code === 'FIRMA', JSON.stringify(r));

// 18. Version distinta.
r = verify(signWith(basePayload({ v: 2 })));
check('version distinta rechazada', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 19. App distinta.
r = verify(signWith(basePayload({ app: 'otra-app' })));
check('app distinta rechazada', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 20. Plan invalido.
r = verify(signWith(basePayload({ plan: 'pirata' })));
check('plan invalido rechazado', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 21. Prefijo distinto.
r = verify('PCL2.' + parts[1] + '.' + parts[2]);
check('prefijo PCL2 rechazado', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 22. deviceId de la licencia con guiones/minusculas se normaliza.
r = verify(signWith(basePayload({ deviceId: 'e5a913db-e606-4709-8605-531b320f5d5f' })));
check('deviceId con guiones/minusculas normalizado', r.ok === true, JSON.stringify(r));

// 23. deviceId de esta PC ilegible.
r = core.verifyLicense(signWith(basePayload()), { publicKey: publicKey, deviceId: null, now: NOW });
check('ID de PC ilegible -> ID_ILEGIBLE', !r.ok && r.code === 'ID_ILEGIBLE', JSON.stringify(r));

// 24. Entrada que no es string.
r = verify(null);
check('entrada null rechazada', !r.ok && r.code === 'FORMATO', JSON.stringify(r));

// 25. La regex de formato termina en $ y no acepta basura al final.
check('regex de formato termina en $', core.FORMAT_RE.source.slice(-1) === '$');


console.log('Resultado core: ' + passed + ' OK, ' + failed + ' FALLAS');
if (failed) process.exit(1);
