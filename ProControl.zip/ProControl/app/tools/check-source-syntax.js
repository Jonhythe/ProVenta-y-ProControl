#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const appRoot = path.resolve(__dirname, '..');
const checked = [];
function walk(dir) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name !== 'node_modules' && entry.name !== 'dist_final' && entry.name !== 'dist') walk(full);
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      const result = spawnSync(process.execPath, ['--check', full], { encoding: 'utf8' });
      if (result.status !== 0) {
        process.stderr.write(`ERROR de sintaxis en ${path.relative(appRoot, full)}\n${result.stderr || result.stdout}`);
        process.exit(1);
      }
      checked.push(path.relative(appRoot, full));
    }
  }
}
for (const dir of ['electron', 'renderer', 'tools']) walk(path.join(appRoot, dir));
const htmlPath = path.join(appRoot, 'renderer', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const blocks = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)];
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'procontrol-inline-check-'));
let inlineCount = 0;
try {
  for (let i = 0; i < blocks.length; i++) {
    const attrs = blocks[i][1] || '';
    const body = blocks[i][2] || '';
    if (/\bsrc\s*=/i.test(attrs) || !body.trim()) continue;
    const typeMatch = attrs.match(/\btype\s*=\s*["']?([^\s"'>]+)/i);
    if (typeMatch && !['text/javascript', 'application/javascript', 'module'].includes(typeMatch[1].toLowerCase())) continue;
    const tempFile = path.join(tempRoot, `inline-${i + 1}.js`);
    fs.writeFileSync(tempFile, body, 'utf8');
    const result = spawnSync(process.execPath, ['--check', tempFile], { encoding: 'utf8' });
    if (result.status !== 0) {
      process.stderr.write(`ERROR de sintaxis en script inline #${i + 1} de renderer/index.html\n${result.stderr || result.stdout}`);
      process.exitCode = 1;
      break;
    }
    inlineCount++;
  }
} finally {
  fs.rmSync(tempRoot, { recursive: true, force: true });
}
if (process.exitCode === 1) process.exit(1);
console.log(`Sintaxis correcta: ${checked.length} archivos JavaScript y ${inlineCount} scripts inline de renderer/index.html.`);
