'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { MobileBridgeStore } = require('../electron/mobile-bridge/store');
let assertions = 0;
function ok(value, message) { assertions++; assert.ok(value, message); }
function equal(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
function fakeSafeStorage(overrides = {}) {
  return {
    isEncryptionAvailable: () => true,
    encryptString: text => Buffer.from(String(text), 'utf8'),
    decryptString: buffer => Buffer.from(buffer).toString('utf8'),
    ...overrides
  };
}
function tempDir() { return fs.mkdtempSync(path.join(os.tmpdir(), 'pc-key-migration-')); }
function paths(dir) {
  return {
    privatePem: path.join(dir, 'mobile-bridge-desktop-private.pem'),
    encrypted: path.join(dir, 'mobile-bridge-desktop-private.dpapi'),
    recovery: path.join(dir, 'mobile-bridge-desktop-private.dpapi.bak'),
    publicPem: path.join(dir, 'mobile-bridge-desktop-public.pem')
  };
}
function makeLegacyPair(dir) {
  const pair = crypto.generateKeyPairSync('ed25519');
  const files = paths(dir);
  fs.writeFileSync(files.privatePem, pair.privateKey.export({ type: 'pkcs8', format: 'pem' }));
  fs.writeFileSync(files.publicPem, pair.publicKey.export({ type: 'spki', format: 'pem' }));
  return { pair, files };
}

// New identity: encrypted primary and a readable/verified recovery copy are created.
{
  const dir = tempDir(); let store;
  try {
    store = new MobileBridgeStore(dir, { safeStorage: fakeSafeStorage(), desktopId: 'desktop_test_0001' });
    const f = paths(dir);
    ok(fs.existsSync(f.encrypted), 'New private key is stored encrypted');
    ok(fs.existsSync(f.recovery), 'A recovery copy of the encrypted key exists');
    ok(fs.existsSync(f.publicPem), 'Public key is persisted');
    equal(fs.existsSync(f.privatePem), false, 'No plaintext private key is left after verified key creation');
    const challenge = Buffer.from('test challenge');
    const signature = crypto.sign(null, challenge, store.desktopPrivateKey);
    ok(crypto.verify(null, challenge, crypto.createPublicKey(store.getDesktopPublicKey()), signature), 'Persisted identity signs and verifies');
  } finally { try { if (store) store.close(); } catch (_) {} fs.rmSync(dir, { recursive: true, force: true }); }
}

// Legacy key migration preserves exact key bytes and keeps backup available before removing PEM.
{
  const dir = tempDir(); let store;
  try {
    const legacy = makeLegacyPair(dir);
    const expectedPublic = fs.readFileSync(legacy.files.publicPem, 'utf8').trim();
    store = new MobileBridgeStore(dir, { safeStorage: fakeSafeStorage(), desktopId: 'desktop_test_0001' });
    equal(store.getDesktopPublicKey().trim(), expectedPublic, 'Migration preserves the original public identity');
    ok(fs.existsSync(legacy.files.encrypted), 'Migrated encrypted key exists');
    ok(fs.existsSync(legacy.files.recovery), 'Recovery copy is present before the original PEM is removed');
    equal(fs.existsSync(legacy.files.privatePem), false, 'Plaintext key is removed only after verified migration');
  } finally { try { if (store) store.close(); } catch (_) {} fs.rmSync(dir, { recursive: true, force: true }); }
}

// Corrupt primary can recover from the encrypted backup without creating a new identity.
{
  const dir = tempDir(); let first; let second;
  try {
    first = new MobileBridgeStore(dir, { safeStorage: fakeSafeStorage(), desktopId: 'desktop_test_0001' });
    const f = paths(dir); const expectedPublic = first.getDesktopPublicKey().trim(); first.close(); first = null;
    fs.writeFileSync(f.encrypted, 'corrupted encrypted bytes');
    second = new MobileBridgeStore(dir, { safeStorage: fakeSafeStorage(), desktopId: 'desktop_test_0001' });
    equal(second.getDesktopPublicKey().trim(), expectedPublic, 'Recovery keeps the previous key identity');
    const restored = fakeSafeStorage().decryptString(fs.readFileSync(f.encrypted));
    equal(crypto.createPublicKey(crypto.createPrivateKey(restored)).export({ type: 'spki', format: 'pem' }).toString().trim(), expectedPublic, 'The primary key file is restored from the verified backup');
  } finally { try { if (first) first.close(); } catch (_) {} try { if (second) second.close(); } catch (_) {} fs.rmSync(dir, { recursive: true, force: true }); }
}

// If encryption was interrupted and the primary is corrupted before the DPAPI backup exists,
// recover from the still-preserved PEM rather than generate a new identity.
{
  const dir = tempDir(); let store;
  try {
    const legacy = makeLegacyPair(dir);
    fs.writeFileSync(legacy.files.encrypted, 'interrupted migration artifact');
    const expectedPublic = fs.readFileSync(legacy.files.publicPem, 'utf8').trim();
    store = new MobileBridgeStore(dir, { safeStorage: fakeSafeStorage(), desktopId: 'desktop_test_0001' });
    equal(store.getDesktopPublicKey().trim(), expectedPublic, 'Recovery from PEM preserves the original identity');
    ok(fs.existsSync(legacy.files.recovery), 'Recovery completes an encrypted DPAPI backup');
    equal(fs.existsSync(legacy.files.privatePem), false, 'PEM is removed only after successful recovery and verification');
  } finally { try { if (store) store.close(); } catch (_) {} fs.rmSync(dir, { recursive: true, force: true }); }
}

// A failed encryption operation never deletes the only valid plaintext key.
{
  const dir = tempDir(); let store;
  try {
    const legacy = makeLegacyPair(dir);
    const broken = fakeSafeStorage({ encryptString: () => { throw new Error('simulated encryption failure'); } });
    assertions++;
    assert.throws(() => { store = new MobileBridgeStore(dir, { safeStorage: broken, desktopId: 'desktop_test_0001' }); }, /simulated encryption failure/);
    ok(fs.existsSync(legacy.files.privatePem), 'Original PEM is preserved after failed migration');
    equal(fs.existsSync(legacy.files.encrypted), false, 'Incomplete encrypted artifact is cleaned up');
  } finally { try { if (store) store.close(); } catch (_) {} fs.rmSync(dir, { recursive: true, force: true }); }
}

console.log(`Bridge key migration: ${assertions} assertions passed.`);
