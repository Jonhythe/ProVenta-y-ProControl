'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { MobileBridgeStore, stableJson, sha256, signedFields } = require('../electron/mobile-bridge/store');
const { MobileControlPlane } = require('../electron/mobile-bridge/control-plane');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-control-plane-'));
let now = Date.now();
const desktopId = 'D'.repeat(32);
const posId = 'pos_test_01';
const posName = 'Punto de prueba';
const phoneId = 'device_12345678';
const store = new MobileBridgeStore(temp);
const verifier = (token, expectedPosId, expectedPosName) => {
  if (token !== 'TOKEN_POS_VALIDO_TEST_12345678901234567890') return { ok:false, code:'POS_LICENSE_INVALID' };
  return { ok:true, payload:{ licenseType:'point-of-sale', deviceId:desktopId, installationMachineId:desktopId, posId:expectedPosId, posName, licenseId:'LIC-POS-TEST' } };
};
const plane = new MobileControlPlane(store, { deviceId:desktopId, verifyPointLicense:verifier, getInstallationLicense:()=>({ modules:['core','inventory','purchases','pos','closings','reports','mobile-integration'], allowedModes:['SIN_APP','CON_APP'] }), now:()=>now });
store.controlPlane = plane;
const owner = { user:'Dueño prueba', role:'Dueño' };
let count=0;
function check(value, message) { count++; assert.ok(value, message); }
try {
  const historicalPermitInsert = store.db.prepare(`INSERT INTO shift_permits(permit_id,pos_id,device_id,employee,sequence,starts_at,ends_at,permit_json,signature,status,created_by,created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`);
  for (let index = 0; index < 520; index++) {
    const createdAt = now - 200000 - index;
    historicalPermitInsert.run(`permit_history_${String(index).padStart(5, '0')}`, posId, 'device_history_0001', 'Histórico', index + 1,
      now - 1000, now + 600000, '{}', 'test-signature', 'expired', 'test', createdAt);
  }
  check(plane.listShiftPermits().length >= 520, 'the general permit history is no longer truncated at 500 records');
  check(plane.listShiftPermits(posId).length >= 520, 'the POS-specific permit history includes records older than the former 500-row cap');
  const lic = plane.installPointLicense({posId,posName,token:'TOKEN_POS_VALIDO_TEST_12345678901234567890'},owner);
  check(lic.ok,'instala licencia POS válida');
  store.db.prepare('INSERT INTO devices(device_id,label,role,enabled,paired_at,public_key,pos_id) VALUES(?,?,?,?,?,?,?)')
    .run(phoneId,'Móvil de prueba','operator',1,now,store.desktopPublicKey,posId);
  check(plane.enablePointLicenseEnforcement([{id:posId,name:posName}],owner).ok,'activa control estricto después de licenciar todos los POS');
  check(plane.canDesktopSell(posId).ok,'POS con licencia válida puede vender en SIN_APP');
  store.db.prepare('UPDATE pos_licenses SET pos_name=? WHERE pos_id=?').run('Caja Principal Renombrada', posId);
  check(plane.canDesktopSell(posId).ok,'renombrar el nombre visible no invalida una licencia ligada al ID estable del POS');
  store.db.prepare('UPDATE pos_licenses SET pos_name=? WHERE pos_id=?').run(posName, posId);
  check(plane.canDesktopSell('pos:' + posId).ok,'la referencia pos: del renderer se normaliza al ID de licencia del POS');
  const restrictedPlane = new MobileControlPlane(store, { deviceId:desktopId, verifyPointLicense:verifier, getInstallationLicense:()=>({ modules:['core','inventory','purchases','closings','reports'], allowedModes:['SIN_APP'] }), now:()=>now });
  check(!restrictedPlane.canDesktopSell(posId).ok,'un módulo de punto de venta ausente bloquea ventas');
  check(!restrictedPlane.issueShiftPermit({posId,deviceId:phoneId,employee:'Operador',startsAt:now-1000,endsAt:now+600000,sequence:99},owner).ok,'no se emiten permisos móviles sin módulo y modo autorizados');
  check(!plane.canDesktopSell('pos_sin_licencia').ok,'POS no licenciado queda bloqueado en modo estricto');
  const permit = plane.issueShiftPermit({posId,deviceId:phoneId,employee:'Operador prueba',startsAt:now-1000,endsAt:now+600000,sequence:1},owner);
  check(!permit.ok && permit.code==='MOBILE_APP_NOT_AVAILABLE','no emite permisos de turno hasta que exista la app móvil real');
  const noLicense = plane.installPointLicense({posId:'pos_bad',posName:'Otro POS',token:'INVALID'},owner);
  check(!noLicense.ok,'rechaza token de licencia inválido');
  const mode = plane.setPOSMode({posId,mode:'CON_APP',cutInfo:{backupVerified:true,backupSha256:'a'.repeat(64),cutAt:now,inventorySnapshot:[{productId:'prod_01',qty:10,unit:'u'}]}},owner);
  check(!mode.ok && mode.code==='MOBILE_APP_NOT_AVAILABLE','bloquea CON_APP incluso con licencia y corte hasta completar integración móvil real');
  check(plane.canDesktopSell(posId).ok,'mantiene habilitada la venta de escritorio en SIN_APP durante esta entrega');
  check(!plane.setPOSMode({posId,mode:'CON_APP'},owner).ok,'no permite activar CON_APP sin los prerrequisitos y la app móvil');

  // Nueva autorización por instalación: el mismo teléfono puede recibir permisos
  // independientes para distintos POS, sin guardar un pos_id fijo en devices.
  const authorization = store.createDeviceAuthorization({ employeeName:'Operador autorizado', employeeData:'Prueba de alcance por instalación', posId }, owner.user);
  const phoneKeys = crypto.generateKeyPairSync('ed25519');
  const phonePublicKey = phoneKeys.publicKey.export({ type:'spki', format:'pem' }).toString();
  const installationDeviceId = 'device_87654321';
  const pairedInstallationDevice = store.pairDevice({
    code:authorization.code, authorizationId:authorization.authorizationId, authorizedPosId:posId,
    installationId:authorization.installationId, deviceId:installationDeviceId,
    label:'Teléfono autorizado', publicKey:phonePublicKey
  }, owner.user);
  check(pairedInstallationDevice.ok && pairedInstallationDevice.posId === posId,'autoriza el teléfono a la instalación y lo fija al único POS elegido');
  const installationDevice = store.db.prepare('SELECT * FROM devices WHERE device_id=?').get(installationDeviceId);
  check(installationDevice && installationDevice.pos_id === posId,'el registro del dispositivo conserva el POS fijo de la autorización');
  check(store._checkDeviceScope(installationDevice,'sale_batch',{transactions:[{posId,shiftPermitId:'permit_test_01',items:[{productId:'prod_01'}]}]}) === null,'la validación acepta el único POS asignado al teléfono');
  check(store._checkDeviceScope(installationDevice,'sale_batch',{transactions:[{posId:'pos_test_02',shiftPermitId:'permit_test_02',items:[]}]}) === 'DEVICE_POS_SCOPE_MISMATCH','la validación bloquea un segundo POS aunque el teléfono pertenezca a la misma instalación');
  check(store._checkDeviceScope(installationDevice,'sale_batch',{transactions:[{posId,items:[]},{posId:'pos_test_02',items:[]}]}) === 'PACKAGE_MULTIPLE_POS_NOT_ALLOWED','rechaza un paquete de ventas mezclando puntos de venta');

  const secondPosId = 'pos_test_02';
  const secondLicense = plane.installPointLicense({posId:secondPosId,posName:'Punto alternativo',token:'TOKEN_POS_VALIDO_TEST_12345678901234567890'},owner);
  check(secondLicense.ok,'instala una segunda licencia POS para probar separación entre dispositivos');
  const secondAuthorization = store.createDeviceAuthorization({ employeeName:'Operador alternativo', posId:secondPosId }, owner.user);
  const secondPhoneKeys = crypto.generateKeyPairSync('ed25519');
  const secondPhonePublicKey = secondPhoneKeys.publicKey.export({ type:'spki', format:'pem' }).toString();
  const secondInstallationDeviceId = 'device_87654322';
  const pairedSecondDevice = store.pairDevice({ code:secondAuthorization.code, authorizationId:secondAuthorization.authorizationId,
    authorizedPosId:secondPosId, installationId:secondAuthorization.installationId, deviceId:secondInstallationDeviceId,
    label:'Segundo POS', publicKey:secondPhonePublicKey }, owner.user);
  check(pairedSecondDevice.ok && pairedSecondDevice.posId===secondPosId,'el segundo POS requiere otra autorización y otro dispositivo');
  // Solo el harness de prueba levanta este indicador; el runtime real sigue
  // usando MOBILE_APP_READY=false hasta completar Android y el transporte.
  plane.mobileAppReady = true;
  const permitFirstPOS = plane.issueShiftPermit({posId,deviceId:installationDeviceId,employee:'Operador autorizado',startsAt:now-1000,endsAt:now+600000,sequence:1},owner);
  check(permitFirstPOS.ok,'emite permiso de turno únicamente para el POS asignado al teléfono');
  const permitSecondOnFirstDevice = plane.issueShiftPermit({posId:secondPosId,deviceId:installationDeviceId,employee:'Operador autorizado',startsAt:now-1000,endsAt:now+600000,sequence:1},owner);
  check(!permitSecondOnFirstDevice.ok && permitSecondOnFirstDevice.code==='DEVICE_POS_SCOPE_MISMATCH','rechaza solicitar otro POS con el teléfono de la primera autorización');
  const permitSecondPOS = plane.issueShiftPermit({posId:secondPosId,deviceId:secondInstallationDeviceId,employee:'Operador alternativo',startsAt:now-1000,endsAt:now+600000,sequence:1},owner);
  check(permitSecondPOS.ok,'el segundo teléfono obtiene permiso solo para su POS asignado');
  const wrongEmployeePermit = plane.issueShiftPermit({posId,deviceId:installationDeviceId,employee:'Otra persona',startsAt:now-1000,endsAt:now+600000,sequence:2},owner);
  check(!wrongEmployeePermit.ok && wrongEmployeePermit.code==='EMPLOYEE_DEVICE_MISMATCH','el permiso debe corresponder al trabajador autorizado para el teléfono');
  const verifiedSecondPermit = plane.verifyShiftPermit(permitSecondPOS.permitId,{deviceId:secondInstallationDeviceId,posId:secondPosId,eventAt:now});
  check(verifiedSecondPermit.ok,'el segundo permiso firmado conserva la identidad del POS independiente');
  const savedClock = now;
  now = Number(permitFirstPOS.permit.startsAt) - 1;
  const scheduledCheck = plane.verifyShiftPermit(permitFirstPOS.permitId, { deviceId:installationDeviceId, posId });
  check(!scheduledCheck.ok && scheduledCheck.code === 'SHIFT_PERMIT_EXPIRED_OR_NOT_STARTED', 'un permiso futuro no se usa para abrir un turno antes de su hora');
  const scheduledExport = plane.getShiftPermitForExport(permitFirstPOS.permitId, { deviceId:installationDeviceId, posId });
  check(scheduledExport.ok && scheduledExport.permit.signature === permitFirstPOS.permit.signature, 'el PC puede exportar de forma verificada un permiso programado antes de que comience');
  check(!plane.getShiftPermitForExport(permitFirstPOS.permitId, { deviceId:installationDeviceId, posId:'pos_test_02' }).ok, 'la exportación del permiso vuelve a validar el POS solicitado');
  check(plane.getShiftPermitForExport(permitFirstPOS.permitId, { deviceId:installationDeviceId }).code === 'SHIFT_PERMIT_EXPORT_SCOPE_REQUIRED', 'la exportación rechaza solicitudes sin el alcance completo de dispositivo y POS');
  now = Number(permitFirstPOS.permit.endsAt) + 1;
  const expiredExport = plane.getShiftPermitForExport(permitFirstPOS.permitId, { deviceId:installationDeviceId, posId });
  check(!expiredExport.ok && expiredExport.code === 'SHIFT_PERMIT_EXPIRED', 'el PC no permite exportar como nuevo un permiso cuyo horario ya terminó');
  now = savedClock;

  for (const targetPosId of [posId, secondPosId]) {
    const modeResult = plane.setPOSMode({posId:targetPosId,mode:'CON_APP',cutInfo:{backupVerified:true,backupSha256:'c'.repeat(64),cutAt:now,inventorySnapshot:[{productId:'prod_01',qty:10,unit:'u'}]}},owner);
    check(modeResult.ok,`prepara ${targetPosId} en CON_APP dentro de la base de prueba aislada`);
  }
  function signedInstallationPackage(packageId, type, payload, targetPhoneId = installationDeviceId, targetPhonePublicKey = phonePublicKey, targetPrivateKey = phoneKeys.privateKey) {
    const doc = { format:'procontrol.offline-package', version:1, packageId, deviceId:targetPhoneId,
      type, createdAt:new Date(now).toISOString(), payload, payloadHash:sha256(stableJson(payload)), signerPublicKey:targetPhonePublicKey };
    doc.signature = { algorithm:'Ed25519', value:crypto.sign(null,signedFields(doc),targetPrivateKey).toString('base64') };
    return doc;
  }
  for (const [targetPosId, permitForPOS, suffix, targetPhoneId, targetPublicKey, targetPrivateKey] of [[posId,permitFirstPOS,'one',installationDeviceId,phonePublicKey,phoneKeys.privateKey],[secondPosId,permitSecondPOS,'two',secondInstallationDeviceId,secondPhonePublicKey,secondPhoneKeys.privateKey]]) {
    const shiftId = `shift_install_${suffix}_01`;
    const openDoc = signedInstallationPackage(`pkg_install_open_${suffix}01`,'shift_open',{
      shiftPermitId:permitForPOS.permitId,sequence:1,
      shift:{id:shiftId,posId:targetPosId,startedAt:new Date(now).toISOString(),sequence:1}
    },targetPhoneId,targetPublicKey,targetPrivateKey);
    const opened = store.importOfflineBundle(JSON.stringify(openDoc));
    check(opened.ok,`el teléfono sin POS fijo puede abrir turno autorizado en ${targetPosId}`);
    check(store.markPackage(openDoc.packageId,'accepted_for_reconciliation',owner.user).ok,`ProControl acepta la apertura revisada en ${targetPosId}`);
    const saleDoc = signedInstallationPackage(`pkg_install_sale_${suffix}01`,'sale_batch',{
      shiftPermitId:permitForPOS.permitId,
      transactions:[{id:`sale_install_${suffix}_01`,posId:targetPosId,shiftPermitId:permitForPOS.permitId,
        ts:new Date(now).toISOString(),items:[{productId:'prod_01',baseQty:1}]}]
    },targetPhoneId,targetPublicKey,targetPrivateKey);
    const saleImport = store.importOfflineBundle(JSON.stringify(saleDoc));
    check(saleImport.ok,`el mismo teléfono envía una venta firmada y limitada a ${targetPosId}`);
  }

  const crossPOSPackage = signedInstallationPackage('pkg_install_crosspos_001','sale_batch',{transactions:[{posId:'pos_test_02',items:[]}]});
  check(store.importOfflineBundle(JSON.stringify(crossPOSPackage)).code === 'DEVICE_POS_SCOPE_MISMATCH','ProControl rechaza operaciones del teléfono enviadas desde otro POS de la misma instalación');

  const legacyDevice = store.db.prepare('SELECT * FROM devices WHERE device_id=?').get(phoneId);
  check(store._checkDeviceScope(legacyDevice,'sale_batch',{transactions:[{posId:secondPosId,shiftPermitId:'permit_test_02',items:[]}]})==='DEVICE_POS_SCOPE_MISMATCH','los dispositivos heredados conservan su restricción al POS antiguo');

  const sent = plane.recordTransferStatus({transferId:'transfer_hist_001',status:'sent',operationId:'op_transfer_sent_001',payload:{manifestHash:'a'.repeat(64)}},owner);
  check(sent.ok && sent.status==='sent','registra envío con clave de idempotencia');
  const sentRetry = plane.recordTransferStatus({transferId:'transfer_hist_001',status:'sent',operationId:'op_transfer_sent_001',payload:{manifestHash:'a'.repeat(64)}},owner);
  check(sentRetry.ok && sentRetry.duplicate,'reintentar un evento de transferencia devuelve el mismo resultado');
  const idempotencyConflict = plane.recordTransferStatus({transferId:'transfer_hist_001',status:'cancelled',operationId:'op_transfer_sent_001',payload:{manifestHash:'a'.repeat(64)}},owner);
  check(!idempotencyConflict.ok && idempotencyConflict.code==='IDEMPOTENCY_KEY_CONFLICT','la misma clave no se reutiliza para otra transición');
  const received = plane.recordTransferStatus({transferId:'transfer_hist_001',status:'received',operationId:'op_transfer_recv_001',payload:{manifestHash:'a'.repeat(64)}},owner);
  check(received.ok && received.previous==='sent','la transición sent a received está permitida');
  const illegal = plane.recordTransferStatus({transferId:'transfer_hist_001',status:'cancelled',operationId:'op_transfer_cancel_01',payload:{}},owner);
  check(!illegal.ok && illegal.code==='INVALID_TRANSFER_TRANSITION','no permite cancelar destructivamente después de recibir');
  check(plane.listTransferHistory('transfer_hist_001').length===2,'el historial conserva los dos eventos');

  // QR de despacho firmado: el PC no puede confirmar un código distinto y
  // la recepción móvil se concilia como evidencia sin volver a mover stock.
  const dispatchItems = [{
    productId:'prod_dispatch_01', name:'Arroz', family:'granos', unit:'lb',
    quantity:12.5, sale:100, saleTransf:108, saleTransfMode:'percentage',
    saleTransfPercent:8, saleUSD:1.5, saleCurrency:'USD', saleCustomCurrency:'', aliases:['arroz']
  }];
  const dispatch = plane.createGoodsDispatchManifest({
    dispatchId:'dispatch_test_0001', posId, posName,
    items:dispatchItems
  }, owner);
  check(dispatch.ok && dispatch.status==='issued','genera manifiesto firmado persistente para despacho');
  const unsignedManifest = { ...dispatch.manifest }; delete unsignedManifest.signature;
  check(crypto.verify(null, Buffer.from(stableJson(unsignedManifest),'utf8'),
    crypto.createPublicKey(store.desktopPublicKey),
    Buffer.from(dispatch.manifest.signature.value,'base64')),
    'el manifiesto de despacho lleva una firma Ed25519 válida');
  check(!Object.prototype.hasOwnProperty.call(dispatch.manifest,'confirmationCode') &&
    dispatch.manifest.confirmationCodeHash===sha256(dispatch.confirmationCode),
    'el QR solo incluye el hash del código; el valor se entrega aparte para entrada manual');
  const dispatchRetry = plane.createGoodsDispatchManifest({
    dispatchId:'dispatch_test_0001', posId, posName, items:dispatchItems
  }, owner);
  check(dispatchRetry.ok && dispatchRetry.duplicate &&
    dispatchRetry.confirmationCode===dispatch.confirmationCode,
    'repetir la creación devuelve el mismo manifiesto y el mismo código');
  const wrongCode = plane.confirmGoodsDispatch({
    dispatchId:'dispatch_test_0001',
    confirmationCode:dispatch.confirmationCode==='00000000'?'00000001':'00000000'
  },owner);
  check(!wrongCode.ok && wrongCode.code==='GOODS_DISPATCH_CONFIRMATION_MISMATCH',
    'el PC rechaza un código de confirmación incorrecto');
  const statusAfterWrong = store.db.prepare('SELECT status FROM goods_dispatch_manifests WHERE dispatch_id=?').get('dispatch_test_0001');
  check(statusAfterWrong.status==='issued','un código incorrecto no cambia el estado del despacho');
  const confirmedDispatch = plane.confirmGoodsDispatch({
    dispatchId:'dispatch_test_0001', confirmationCode:dispatch.confirmationCode
  },owner);
  check(confirmedDispatch.ok && confirmedDispatch.status==='desktop_confirmed',
    'el código correcto confirma la entrada en el PC');
  const confirmedRetry = plane.confirmGoodsDispatch({
    dispatchId:'dispatch_test_0001', confirmationCode:dispatch.confirmationCode
  },owner);
  check(confirmedRetry.ok && confirmedRetry.duplicate,'la confirmación repetida es idempotente');

  const receiptPayload = {
    schemaVersion:1,
    dispatchId:'dispatch_test_0001',
    posId,
    shiftPermitId:permitFirstPOS.permitId,
    confirmationCode:dispatch.confirmationCode,
    itemsHash:dispatch.itemsHash,
    items:dispatch.manifest.items,
    receivedAt:new Date(now).toISOString()
  };
  const receiptDoc = signedInstallationPackage('pkg_goods_receipt_0001','goods_receipt',receiptPayload);
  const receiptImport = store.importOfflineBundle(JSON.stringify(receiptDoc));
  check(receiptImport.ok && receiptImport.status==='pending_review',
    'acepta paquete de recepción ligado a manifiesto, POS, permiso y código correctos');
  check(store.markPackage(receiptDoc.packageId,'accepted_for_reconciliation',owner.user).ok,
    'permite enviar la evidencia de recepción a conciliación');
  check(store.beginPackageApply(receiptDoc.packageId,owner.user).ok,
    'inicia conciliación idempotente de la evidencia de recepción');
  const receiptApplied = store.markPackageApplied(receiptDoc.packageId,owner.user,{
    type:'goods_receipt',payloadHash:receiptDoc.payloadHash,newOperations:1,changedStock:false
  });
  check(receiptApplied.ok,'conciliar recepción no aplica un segundo movimiento de inventario');
  const finalDispatch = store.db.prepare('SELECT status FROM goods_dispatch_manifests WHERE dispatch_id=?').get('dispatch_test_0001');
  check(finalDispatch.status==='reconciled','el manifiesto queda reconciliado después de procesar la recepción móvil');
  const duplicateReceiptImport = store.importOfflineBundle(JSON.stringify(receiptDoc));
  check(duplicateReceiptImport.duplicate && duplicateReceiptImport.packageId === receiptDoc.packageId && duplicateReceiptImport.type === 'goods_receipt',
    'reintentar el mismo paquete devuelve su identidad exacta para completar un paso pendiente sin duplicar datos');
  const duplicateReceiptDoc = signedInstallationPackage('pkg_goods_receipt_0002','goods_receipt',receiptPayload);
  const duplicateReceipt = store.importOfflineBundle(JSON.stringify(duplicateReceiptDoc));
  check(!duplicateReceipt.ok && duplicateReceipt.code==='GOODS_DISPATCH_NOT_CONFIRMED_ON_DESKTOP',
    'un segundo paquete distinto no puede volver a recibir el mismo despacho ya conciliado');
  const closeFixtures = [
    { targetPosId:posId, permit:permitFirstPOS, shiftId:'shift_install_one_01', deviceId:installationDeviceId, publicKey:phonePublicKey, privateKey:phoneKeys.privateKey, suffix:'one' },
    { targetPosId:secondPosId, permit:permitSecondPOS, shiftId:'shift_install_two_01', deviceId:secondInstallationDeviceId, publicKey:secondPhonePublicKey, privateKey:secondPhoneKeys.privateKey, suffix:'two' }
  ];
  for (const fixture of closeFixtures) {
    const closeDoc = signedInstallationPackage(`pkg_install_close_${fixture.suffix}01`,'shift_close',{
      shiftPermitId:fixture.permit.permitId,
      shift:{id:fixture.shiftId,posId:fixture.targetPosId,closedAt:new Date(now).toISOString()},
      closingReport:{schemaVersion:1,posId:fixture.targetPosId,permitId:fixture.permit.permitId,shiftId:fixture.shiftId,products:[]}
    },fixture.deviceId,fixture.publicKey,fixture.privateKey);
    const closeImport = store.importOfflineBundle(JSON.stringify(closeDoc));
    check(closeImport.ok && closeImport.status==='pending_review',`ProControl recibe cierre firmado solo para ${fixture.targetPosId}`);
    check(store.markPackage(closeDoc.packageId,'accepted_for_reconciliation',owner.user).ok,`el cierre de ${fixture.targetPosId} puede pasar a conciliación`);
    const filteredClosures = plane.listPendingClosures(fixture.targetPosId);
    check(filteredClosures.some(row=>row.packageId===closeDoc.packageId) && filteredClosures.every(row=>row.posId===fixture.targetPosId),`la bandeja de cierres de ${fixture.targetPosId} no mezcla otros POS`);
    check(plane.listPendingClosures('').length === 0, 'una consulta sin POS no devuelve cierres de todos los puntos de venta');
    const missingScopeDecision = plane.decidePendingClosure({closureId:`close_${closeDoc.packageId}`,decision:'confirmed'},owner);
    check(!missingScopeDecision.ok && missingScopeDecision.code==='CLOSURE_POS_SCOPE_REQUIRED', 'ProControl exige el POS explícito para tomar decisiones de cierre');
    if (fixture.targetPosId === posId) {
      const wrongPosDecision = plane.decidePendingClosure({closureId:`close_${closeDoc.packageId}`,decision:'confirmed',posId:secondPosId},owner);
      check(!wrongPosDecision.ok && wrongPosDecision.code==='CLOSURE_POS_SCOPE_MISMATCH','ProControl vuelve a comprobar el POS antes de confirmar un cierre');
    }
  }
  const revokedInstallationDevice = store.revokeDeviceAuthorization(authorization.authorizationId,owner.user);
  check(revokedInstallationDevice.ok,'permite revocar la autorización de instalación');
  const revokedDeviceRow = store.db.prepare('SELECT * FROM devices WHERE device_id=?').get(installationDeviceId);
  check(store._checkDeviceScope(revokedDeviceRow,'goods_receipt',{posId,items:[{productId:'prod_dispatch_01'}]})==='DEVICE_AUTHORIZATION_INACTIVE',
    'un dispositivo revocado tampoco puede registrar recepciones móviles');
  console.log(`Mobile control plane tests: ${count} assertions passed.`);
} finally {
  try { store.db.close(); } catch (_) {}
  fs.rmSync(temp,{recursive:true,force:true});
}
