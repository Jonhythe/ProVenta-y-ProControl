"use strict";
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const Core=require('../renderer/business-management.js');
let passed=0;
function test(name,fn){fn();passed++;console.log(`OK ${passed}: ${name}`);}
const state={version:1,accounts:[{id:'cash',name:'Caja CUP',currency:'CUP',opening:100,active:true},{id:'usd',name:'Caja USD',currency:'USD',opening:10,active:true}],transactions:[{id:'1',type:'income',amount:50,currency:'CUP',accountId:'cash',date:'2026-10-01'},{id:'2',type:'expense',amount:20,currency:'CUP',accountId:'cash',date:'2026-10-02'},{id:'3',type:'settlement',debtKind:'payables',amount:5,currency:'CUP',accountId:'cash',date:'2026-10-03'}],receivables:[{id:'r',name:'Cliente',amount:100,paid:25,currency:'CUP'}],payables:[{id:'p',name:'Proveedor',amount:80,paid:30,currency:'CUP'}],suppliers:[],rates:[{date:'2026-10-01',currency:'USD',rate:400}],audit:[],settings:{}};
test('calcula saldo de caja incluyendo entradas, gastos y liquidación de cuenta por pagar',()=>assert.equal(Core.balanceForAccount(state,'cash'),125));
test('mantiene cuentas multimoneda separadas',()=>assert.equal(Core.balanceForAccount(state,'usd'),10));
test('calcula deuda pendiente por cobrar',()=>assert.equal(Core.openDebts(state,'receivables'),75));
test('calcula deuda pendiente por pagar',()=>assert.equal(Core.openDebts(state,'payables'),50));
test('clasifica productos ABC por participación acumulada',()=>{const a=Core.abcAnalysis([{name:'A',revenue:80},{name:'B',revenue:15},{name:'C',revenue:5}]);assert.equal(a[0].category,'A');assert.equal(a[1].category,'B');assert.equal(a[2].category,'C');});
test('ABC siempre muestra unidades vendidas aunque el ingreso no sea comparable',()=>{const rows=Core.aggregateProductSales([{id:'p1',name:'Arroz'}],[{kind:'sale',currency:'USD',items:[{productId:'p1',name:'Arroz',quantity:7,lineTotal:15,currency:'USD'}]}]);assert.equal(rows[0].sold,7);assert.equal(rows[0].revenue,0);const abc=Core.abcAnalysis([{id:'p1',name:'Arroz',sold:rows[0].sold,revenue:rows[0].revenue}]);assert.equal(abc[0].sold,7);assert.equal(abc[0].qty,7);});
test('margen usa el coste unitario de adquisición con Extra y precios CUP por modalidad',()=>{const rows=Core.buildMarginAnalysis([{id:'p1',name:'Producto con Extra',cost:105,baseCost:100,extraPerUnit:5,sale:150,saleTransf:130}]);assert.equal(rows.length,1);assert.equal(rows[0].cost,105);assert.equal(rows[0].cashPrice,150);assert.equal(rows[0].transferPrice,130);assert.ok(Math.abs(rows[0].cashMargin-30)<1e-9);assert.ok(Math.abs(rows[0].transferMargin-((130-105)/130*100))<1e-9);});
test('el semáforo puede evaluar operaciones sin usar caja, bancos ni movimientos económicos',()=>{const a=Core.healthAssessment({hasTransactions:false,hasInventory:true,liquidityKnown:false,cashAvailable:NaN,includeLiquidity:false,includePendingOperations:false,overdue:0,pending:0,stockAlerts:0,requireMainOperationalEvidence:true,hasSalesEvidence:true,hasClosingEvidence:true});assert.equal(a.enoughData,true);assert.ok(!a.checks.some(c=>c.label==='Dinero disponible'||c.label==='Operaciones por revisar'));});

test('no inventa puntuación de salud cuando no hay datos',()=>assert.equal(Core.healthScore({hasTransactions:false,hasInventory:false,cashAvailable:0,overdue:0,pending:0,stockAlerts:0}).score,null));
test('detecta señales que reducen el indicador de salud',()=>assert.ok(Core.healthScore({hasTransactions:true,cashAvailable:-20,overdue:2,pending:1,stockAlerts:3}).score<100));
test('sugiere reposición cuando el stock es menor al mínimo',()=>{const r=Core.suggestReplenishment([{name:'Agua',quantity:2,minStock:10}],[],14);assert.equal(r[0].suggested,8);});
test('sugiere compra por demanda fechada ponderando 30 y 90 días y la cobertura objetivo',()=>{const sales=Array.from({length:30},(_,i)=>({ts:new Date(Date.UTC(2026,9,1+i,12)).toISOString(),items:[{name:'Arroz',quantity:2}]}));const r=Core.suggestReplenishment([{name:'Arroz',quantity:10,minStock:0}],sales,14,new Date('2026-10-30T12:00:00Z'));assert.equal(r[0].suggested,32);assert.equal(r[0].source,'sales-history');assert.ok(r[0].daily>1.4&&r[0].daily<1.5);});
test('rechaza un estado sin versión reconocida',()=>assert.throws(()=>Core.validateState({version:2}),/formato/));
test('rechaza cuentas con moneda inválida',()=>assert.throws(()=>Core.validateState({...state,accounts:[{id:'x',name:'x',currency:'XYZ',opening:0}]}),/cuenta inválida/));
test('rechaza movimientos con importe no positivo',()=>assert.throws(()=>Core.validateState({...state,transactions:[{id:'bad',type:'expense',amount:0,currency:'CUP',date:'2026-10-01'}]}),/movimiento inválido/));
test('rechaza respaldos que exceden límites de volumen',()=>assert.throws(()=>Core.validateState({...state,transactions:Array(200001).fill(state.transactions[0])}),/límites/));
test('acepta un estado válido de módulo',()=>assert.equal(Core.validateState(state),state));

test('usa cantidad base y resta devoluciones en ventas fechadas',()=>{const r=Core.suggestReplenishment([{name:'Agua',quantity:0,minStock:0}], [{kind:'sale',ts:'2026-10-20T10:00:00Z',items:[{name:'Agua',baseQty:20}]},{kind:'return',ts:'2026-10-21T10:00:00Z',items:[{name:'Agua',baseQty:-5}]}],14,new Date('2026-10-30T12:00:00Z'));assert.equal(r[0].suggested,11);assert.equal(r[0].sold30,15);});
test('respeta plazo de abastecimiento específico del producto con demanda fechada',()=>{const r=Core.suggestReplenishment([{name:'Aceite',quantity:0,minStock:0,stockAlertSettings:{leadTimeDays:20}}],[{ts:'2026-10-20T10:00:00Z',items:[{name:'Aceite',baseQty:30}]}],14,new Date('2026-10-30T12:00:00Z'));assert.equal(r[0].suggested,31);assert.equal(r[0].leadDays,20);});

test('aplica transferencias simétricas a cuentas de la misma moneda',()=>{const transferState={...state,transactions:[{id:'tr',type:'transfer',amount:40,currency:'CUP',accountId:'cash',toAccountId:'cash2',date:'2026-10-04'}],accounts:[...state.accounts,{id:'cash2',name:'Caja secundaria',currency:'CUP',opening:5}]};assert.equal(Core.balanceForAccount(transferState,'cash'),60);assert.equal(Core.balanceForAccount(transferState,'cash2'),45);});
test('rechaza movimientos que apuntan a una cuenta inexistente',()=>assert.throws(()=>Core.validateState({...state,transactions:[{id:'bad-ref',type:'income',amount:1,currency:'CUP',accountId:'missing',date:'2026-10-01'}]}),/cuenta inexistente/));

test('rechaza una configuración ausente en un respaldo',()=>{const bad={...state};delete bad.settings;assert.throws(()=>Core.validateState(bad),/configuración/);});
test('procesa un catálogo de 10000 productos sin cargarlo en la interfaz completa',()=>{const products=Array.from({length:10000},(_,i)=>({name:'Producto '+i,quantity:i%12,minStock:5,sold:i%20,revenue:i%1000}));const result=Core.suggestReplenishment(products,[],14);assert.ok(result.length>0);assert.ok(result.length<=10000);});

test('el módulo empresarial se carga por el protocolo app:// del Electron principal',()=>{const html=fs.readFileSync(path.join(__dirname,'../renderer/index.html'),'utf8');const main=fs.readFileSync(path.join(__dirname,'../electron/main.js'),'utf8');assert.match(html,/<script src="app:\/\/business-management\.js"><\/script>/);assert.match(html,/window\.PCBusinessContext/);assert.match(main,/protocol\.handle\('app'/);});
test('el respaldo principal exporta y valida la clave del módulo empresarial',()=>{const html=fs.readFileSync(path.join(__dirname,'../renderer/index.html'),'utf8');assert.match(html,/data\.pc_business_management_v1 = businessData/);assert.match(html,/core\.validateState\(backup\.data\.pc_business_management_v1\)/);assert.match(html,/replacements\.push\(\['pc_business_management_v1'/);});

test('exige un segundo usuario para aprobar una transferencia pendiente',()=>{const t={type:'transfer',status:'pending-approval',createdBy:'operador'};assert.equal(Core.canApproveTransfer(t,'operador'),false);assert.equal(Core.canApproveTransfer(t,'administrador'),true);assert.equal(Core.canApproveTransfer({...t,status:'posted'},'administrador'),false);});

test('simula cambio de precio mostrando porcentaje, margen monetario y diferencia',()=>{const r=Core.simulatePrice(10,5,6,3);assert.equal(r.currentRevenue,50);assert.equal(r.newRevenue,60);assert.equal(r.currentGrossProfit,20);assert.equal(r.newGrossProfit,30);assert.equal(r.currentMargin,40);assert.equal(r.newMargin,50);assert.equal(r.grossProfitDelta,10);assert.equal(r.marginDelta,10);assert.match(r.assumption,/cantidad vendida/);});
test('simula compra adicional e informa sobrante o faltante de manera separada',()=>{const surplus=Core.simulateStock(5,40,2,7);assert.equal(surplus.stockAfterPurchase,45);assert.equal(surplus.estimatedDemandDuringLead,14);assert.equal(surplus.shortageAtLead,0);assert.equal(surplus.surplusAtLead,31);const shortage=Core.simulateStock(5,0,2,7);assert.equal(shortage.shortageAtLead,9);assert.equal(shortage.surplusAtLead,0);assert.equal(shortage.stockAfterLead,0);});
test('rechaza valores negativos en simuladores',()=>{assert.throws(()=>Core.simulatePrice(10,5,-1,3),/no negativos/);assert.throws(()=>Core.simulateStock(5,-2,1,7),/no negativos/);});

test('no compara márgenes si solo una moneda está identificada o las monedas difieren',()=>{assert.equal(Core.canCompareUnitCurrencies('USD','CUP'),false);assert.equal(Core.canCompareUnitCurrencies('USD',''),false);assert.equal(Core.canCompareUnitCurrencies('CUP','CUP'),true);assert.equal(Core.canCompareUnitCurrencies('',''),true);});
test('detecta posibles duplicados en una pasada y separa cuentas distintas',()=>{const base={date:'2026-10-20',amount:250,type:'expense',name:'Transporte',currency:'CUP',accountId:'cash'};const rows=[{...base,id:'a'},{...base,id:'b'},{...base,id:'c',accountId:'bank'},{...base,id:'d',name:'Compra'}];assert.deepEqual(Core.findPotentialDuplicateTransactions(rows).map(x=>x.id).sort(),['a','b']);});
test('resume sucursales en una pasada y mantiene separadas las monedas',()=>{const branches=[{id:'b1',name:'Centro'},{id:'b2',name:'Playa'}];const accounts=[{id:'c1',currency:'CUP',branchId:'b1'},{id:'c2',currency:'USD',branchId:'b1'}];const transactions=[{type:'income',amount:100,currency:'CUP',accountId:'c1'},{type:'settlement',debtKind:'receivables',amount:20,currency:'CUP',accountId:'c1'},{type:'expense',amount:5,currency:'USD',accountId:'c2'}];const result=Core.summarizeBranches(branches,accounts,transactions);assert.equal(result[0].transactions,3);assert.deepEqual(result[0].byCurrency.map(x=>[x.currency,x.income,x.expenses]),[['CUP',120,0],['USD',0,5]]);assert.equal(result[1].transactions,0);});
test('el detector de duplicados escala sin recorrer cada movimiento contra todo el historial',()=>{const rows=Array.from({length:15000},(_,i)=>({id:String(i),date:'2026-10-01',amount:i+1,type:'expense',name:'Gasto '+i,currency:'CUP',accountId:'cash'}));assert.equal(Core.findPotentialDuplicateTransactions(rows).length,0);});
test('los productos sin valor de ventas positivo no reciben una clase ABC artificial',()=>{const a=Core.abcAnalysis([{name:'Vendió',revenue:100},{name:'Sin datos',revenue:0}]);assert.equal(a.find(x=>x.name==='Vendió').category,'A');assert.equal(a.find(x=>x.name==='Sin datos').category,'Sin datos');});
test('ABC no agrega valores nativos de moneda desconocida como si fueran CUP',()=>{const a=Core.aggregateProductSales([{name:'Producto',price:500}], [{kind:'sale',currency:'USD',items:[{name:'Producto',baseQty:2,lineTotal:500,currency:'USD'}]}])[0];assert.equal(a.revenue,0);assert.equal(a.source,'none');});
test('semáforo económico no declara estabilidad sin datos suficientes',()=>{const a=Core.healthAssessment({hasTransactions:false,hasInventory:false,liquidityKnown:false,cashAvailable:NaN,overdue:0,pending:0,stockAlerts:0});assert.equal(a.status,'unknown');assert.match(a.label,/Datos insuficientes/);});
test('semáforo muestra riesgo cuando la liquidez estimada es negativa',()=>{const a=Core.healthAssessment({hasTransactions:true,hasInventory:true,liquidityKnown:true,cashAvailable:-10,overdue:0,pending:0,stockAlerts:0});assert.equal(a.status,'risk');assert.ok(a.checks.some(c=>c.state==='risk'));});
test('semáforo muestra atención por vencimientos o autorizaciones pendientes',()=>{const a=Core.healthAssessment({hasTransactions:true,hasInventory:true,liquidityKnown:true,cashAvailable:100,overdue:1,pending:1,stockAlerts:0});assert.equal(a.status,'attention');assert.ok(a.checks.some(c=>c.label==='Cuentas vencidas'&&c.state==='attention'));});
test('semáforo solo indica sin alertas principales si las categorías necesarias tienen datos',()=>{const a=Core.healthAssessment({hasTransactions:true,hasInventory:true,liquidityKnown:true,cashAvailable:100,overdue:0,pending:0,stockAlerts:0});assert.equal(a.status,'stable');assert.equal(a.enoughData,true);});
test('analítica ABC usa los importes de venta registrados y descuenta devoluciones',()=>{const p=[{name:'Arroz',quantity:12,price:999}];const sales=[{kind:'sale',ts:'2026-10-10T10:00:00Z',items:[{name:'Arroz',baseQty:10,lineTotalCUP:500}]},{kind:'return',ts:'2026-10-12T10:00:00Z',items:[{name:'Arroz',baseQty:-2,lineTotalCUP:-100}]}];const a=Core.aggregateProductSales(p,sales)[0];assert.equal(a.sold,8);assert.equal(a.revenue,400);assert.equal(a.lastSaleDate,'2026-10-10');});
test('analítica no inventa ingresos multiplicando unidades por precio actual',()=>{const a=Core.aggregateProductSales([{name:'Producto',sold:10,price:500}],[])[0];assert.equal(a.revenue,0);assert.equal(a.source,'none');});
test('análisis de movimiento diferencia falta de historial de ausencia de ventas registrada',()=>{const a=Core.inventoryMovementAnalysis([{name:'Sin historial',quantity:5},{name:'Vendió antes',quantity:2}],[], '2026-10-28');assert.equal(a.find(x=>x.name==='Sin historial').movement,'Sin historial de ventas disponible');assert.equal(a.find(x=>x.name==='Sin historial').needsReview,true);});
test('análisis de movimiento identifica ventas antiguas con fechas disponibles',()=>{const products=[{name:'Lento',quantity:4},{name:'Reciente',quantity:7}];const sales=[{kind:'sale',ts:'2026-08-01T12:00:00Z',items:[{name:'Lento',baseQty:1,lineTotalCUP:10}]},{kind:'sale',ts:'2026-10-25T12:00:00Z',items:[{name:'Reciente',baseQty:1,lineTotalCUP:10}]}];const a=Core.inventoryMovementAnalysis(products,sales,'2026-10-28',30);assert.match(a.find(x=>x.name==='Lento').movement,/Sin venta registrada en/);assert.equal(a.find(x=>x.name==='Lento').needsReview,true);assert.equal(a.find(x=>x.name==='Reciente').movement,'Movimiento reciente');});
test('las 12 funciones conservadas tienen ruta de renderizado propia y se elimina Alertas y anomalías',()=>{const src=fs.readFileSync(path.join(__dirname,'../renderer/business-management.js'),'utf8');const routes={overview:'overview()',receivables:"debtView('receivables')",payables:"debtView('payables')",suppliers:'suppliersView()',rates:'ratesView()',replenishment:'replenishmentView()',abc:'abcView()',movement:'movementView()',margins:'marginsView()',simPrice:'priceSimulatorView()',simStock:'stockSimulatorView()',branches:'branchesView()'};for(const [key,call] of Object.entries(routes)){assert.ok(src.includes("['"+key+"'"),`falta definición de pestaña: ${key}`);assert.ok(src.includes("case'"+key+"':return "+call),`ruta incorrecta para ${key}; se esperaba ${call}`);}const tabBlock=(src.match(/const tabs=\[([\s\S]*?)\n\];/)||[])[1]||'';for(const removed of ['transactions','accounts','simLiquidity','audit','backup','alerts'])assert.ok(!tabBlock.includes("['"+removed+"'"),`no debe quedar la pestaña retirada: ${removed}`);assert.match(src,/function renderView\(\)/);assert.match(src,/function barChart\(/);assert.match(src,/function donutChart\(/);assert.match(src,/option value=\"bar\"/);assert.match(src,/option value=\"line\"/);assert.match(src,/option value=\"pie\"/);assert.match(src,/option value=\"area\"/);assert.doesNotMatch(src,/function auditView\(/);assert.doesNotMatch(src,/function backupView\(/);assert.doesNotMatch(src,/function alertsView\(/);assert.match(src,/id="pcbm-window-switch"/);});
test('Análisis aparece después de Histórico con menú desplegable',()=>{const html=fs.readFileSync(path.join(__dirname,'../renderer/index.html'),'utf8');const history=html.indexOf('id="menu-auditoria"');const button=html.indexOf('data-pcbm-open="1"');assert.ok(history>=0&&button>history,'el acceso a Análisis debe estar después del menú de Historial/Registros');assert.match(html,/aria-haspopup="true"/);assert.match(html,/class="arrow-down" aria-hidden="true">▾<\/span>/);assert.match(html,/id="menu-pcbm-gestion-economica" class="nav-dropdown-content hidden pcbm-business-menu"/);});
test('el menú ofrece 12 pestañas, una acción separada de calculadora y excluye Alertas y anomalías',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../renderer/index.html'),'utf8');
 const keys=['overview','receivables','payables','suppliers','rates','replenishment','abc','movement','margins','simPrice','simStock','branches'];
 for(const key of keys)assert.match(html,new RegExp('data-pcbm-tab=\"'+key+'\"'),`falta acceso en menú: ${key}`);
 for(const key of ['transactions','accounts','simLiquidity','audit','backup','alerts'])assert.doesNotMatch(html,new RegExp('data-pcbm-tab=\"'+key+'\"'),`no debe quedar acceso a ${key}`);
 assert.equal((html.match(/class=\"dropdown-item pcbm-menu-action\"(?=[^>]*data-pcbm-tab=)/g)||[]).length,12,'deben existir exactamente 12 pestañas');
 assert.equal((html.match(/class=\"dropdown-item pcbm-menu-action\"/g)||[]).length,13,'las 12 pestañas más la acción independiente de calculadora');
 assert.match(html,/onclick=\"Corrections\.openTransferSalePriceCalculator\(\); UI\.toggleNavMenu/,'falta el acceso funcional a la calculadora de precio en transferencia');
 assert.match(html,/id=\"transfer-sale-price-overlay\"/,'falta la ventana de la calculadora');
 assert.match(html,/Resumen y salud económica/);assert.match(html,/Inventario ABC/);assert.doesNotMatch(html,/data-pcbm-tab=\"simLiquidity\"/);assert.match(html,/class=\"pcbm-menu-heading\"/);assert.match(html,/dropdown\.classList\.toggle\('hidden', !isOwner\)/);
});

test('la calculadora de transferencia conserva sus controles, validaciones y persistencia para Almacén y POS',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../renderer/index.html'),'utf8');
 for(const id of ['transfer-sale-price-product','transfer-sale-price-base','transfer-sale-price-mode-percent','transfer-sale-price-mode-manual','transfer-sale-price-percent','transfer-sale-price-preview','transfer-sale-price-manual','transfer-sale-price-error'])assert.ok(html.includes('id=\"'+id+'\"'),'falta control '+id);
 for(const method of ['openTransferSalePriceCalculator','closeTransferSalePriceCalculator','loadTransferSalePriceProduct','setTransferSalePriceMode','updateTransferSalePricePreview','saveTransferSalePriceConfiguration'])assert.match(html,new RegExp('\\b'+method+'\\s*\\('),'falta método '+method);
 assert.match(html,/calculateSaleTransferPrice\(baseCashPrice, percent\)/);
 assert.match(html,/saleTransfMode = mode/);assert.match(html,/saleTransfPercent = mode === 'percentage' \? percent : null/);
 assert.match(html,/DataStore\.transaction\('configurar-precio-venta-transferencia'/);
 assert.match(html,/posTargets\.forEach\(posItem =>/);
 assert.match(html,/Solo el Dueño puede guardar los precios por transferencia/);
});
test('abrir Gestión económica permite seleccionar una pestaña concreta',()=>{const src=fs.readFileSync(path.join(__dirname,'../renderer/business-management.js'),'utf8');assert.match(src,/function open\(requestedTab='overview'\)/);assert.match(src,/activeTab=allowedTabs\.has\(requestedTab\)\?requestedTab:'overview'/);assert.match(src,/function handleNavbarMenuAction\(event\)/);assert.match(src,/doc\.addEventListener\('click',handleNavbarMenuAction\)/);});
test('Análisis requiere rol Dueño y las tasas aceptan nombre para OTRA moneda',()=>{const src=fs.readFileSync(path.join(__dirname,'../renderer/business-management.js'),'utf8');const html=fs.readFileSync(path.join(__dirname,'../renderer/index.html'),'utf8');assert.match(src,/function open\(requestedTab='overview'\)\{if\(!canOwner\(\)\)/);assert.match(src,/id="pcbm-rate-custom"/);assert.match(src,/Nombre de la moneda/);assert.match(html,/nav-dropdown\.pcbm-nav-dropdown/);});


test('las vistas analíticas incluyen gráficos; Monedas y tasas mantiene una interfaz de edición directa',()=>{const src=fs.readFileSync(path.join(__dirname,'../renderer/business-management.js'),'utf8');const functions=['overview','debtView','suppliersView','replenishmentView','abcView','movementView','marginsView','branchesView'];for(const name of functions){const start=src.indexOf('function '+name+'(');assert.ok(start>=0,'falta vista '+name);const next=src.indexOf('\nfunction ',start+10);const body=src.slice(start,next<0?src.length:next);assert.ok(/barChart\(|donutChart\(|chartGrid\(/.test(body),'la vista '+name+' no ofrece recurso gráfico');}const ratesStart=src.indexOf('function ratesView(');const ratesEnd=src.indexOf('\nfunction ',ratesStart+10);const ratesBody=src.slice(ratesStart,ratesEnd<0?src.length:ratesEnd);assert.match(ratesBody,/Monedas y tasas/);assert.match(ratesBody,/pcbm-rate-custom/);});
test('las dos simulaciones conservadas tienen formulario, salida y gráfica propios',()=>{const src=fs.readFileSync(path.join(__dirname,'../renderer/business-management.js'),'utf8');for(const [form,result,chart] of [['pcbm-price-sim-form','pcbm-price-sim-result','pcbm-price-sim-chart'],['pcbm-stock-sim-form','pcbm-stock-sim-result','pcbm-stock-sim-chart']]){assert.ok(src.includes('id=\"'+form+'\"'),`falta formulario ${form}`);assert.ok(src.includes('id=\"'+result+'\"'),`falta salida ${result}`);assert.ok(src.includes('id=\"'+chart+'\"'),`falta gráfica ${chart}`);}assert.doesNotMatch(src,/id=\"pcbm-sim-form\"|id=\"pcbm-sim-liquidity-chart\"/);});
test('cambiar de función reinicia el desplazamiento al inicio de la vista',()=>{const src=fs.readFileSync(path.join(__dirname,'../renderer/business-management.js'),'utf8');assert.match(src,/content\.innerHTML=renderView\(\);content\.scrollTop=0/);});

test('proveedor se deriva de las compras reales y conserva el teléfono más reciente conocido',()=>{
 const r=Core.summarizeSupplierPurchases([
  {id:1,date:'01/10/2026',supplier:'Carnes La Habana',supplierPhone:'7000-1111',items:[{cost:100,qty:1}]},
  {id:2,date:'03/10/2026',supplier:'CARNES La Habana',supplierPhone:'7000-2222',items:[{cost:200,qty:2}],extraAmount:50,totalAmount:450}
 ]);
 assert.equal(r.length,1);assert.equal(r[0].name,'CARNES La Habana');assert.equal(r[0].phone,'7000-2222');assert.equal(r[0].purchaseCount,2);assert.equal(r[0].totalAcquisition,550);
});
test('proveedores antiguos se conservan sin fingir compras asociadas',()=>{
 const r=Core.summarizeSupplierPurchases([],[{id:'old',name:'Proveedor antiguo',phone:'555'}]);
 assert.equal(r.length,1);assert.equal(r[0].purchaseCount,0);assert.equal(r[0].source,'Proveedor antiguo sin compra asociada');
});
test('la comparación por puntos de venta usa ventas, devoluciones y cierres reales',()=>{
 const r=Core.summarizeSalesByPOS([
  {id:'s1',kind:'sale',ts:'2026-10-04T10:00:00Z',posId:'p1',posName:'Centro',totalCUP:500,status:'reconciled',closingId:'c1'},
  {id:'r1',kind:'return',ts:'2026-10-05T10:00:00Z',posId:'p1',posName:'Centro',totalCUP:100,status:'reconciled',closingId:'c1'}
 ],[{id:'c1',ts:'2026-10-05T11:00:00Z',posId:'p1',posName:'Centro',difference:5}],[{id:'p1',name:'Centro'}]);
 assert.equal(r.length,1);assert.equal(r[0].netSalesCUP,400);assert.equal(r[0].saleCount,1);assert.equal(r[0].returnCount,1);assert.equal(r[0].closings,1);assert.equal(r[0].closingDifferences[0],5);
});
test('resumen real cuenta compras, ventas, cierres y transferencias sin crear deudas',()=>{
 const r=Core.summarizeRealOperations([{id:1,date:'10/2026',ts:'2026-10-05T10:00:00Z',supplier:'Proveedor',totalAmount:100,items:[]}],[{id:'s1',ts:'2026-10-06T10:00:00Z',kind:'sale',totalCUP:120,posName:'Centro',items:[],status:'pending-close'}],[{id:'c1',ts:'2026-10-06T11:00:00Z',posId:'p1',posName:'Centro',difference:1}],[{id:'t1',ts:'2026-10-07T10:00:00Z',product:'Arroz',qtyPerDest:2,source:'Almacén',destinations:['Centro']}],[{id:'p1',name:'Centro'}],new Date('2026-10-20T12:00:00Z'));
 assert.equal(r.purchaseCount,1);assert.equal(r.purchaseTotalCUP,100);assert.equal(r.salesCount,1);assert.equal(r.netSalesCUP,120);assert.equal(r.closingsCount,1);assert.equal(r.transfersCount,1);
});
test('los períodos reales distinguen el mes actual y el anterior sin sumar monedas',()=>{
 const r=Core.summarizeRealPeriods([
  {date:'2026-10-05',totalAmount:100,items:[]},{date:'2026-09-03',totalAmount:50,items:[]}
 ],[
  {date:'2026-10-06',kind:'sale',totalCUP:150,items:[]},{date:'2026-09-04',kind:'return',totalCUP:20,items:[]}
 ],[],[],new Date('2026-10-20T12:00:00Z'));
 assert.equal(r[0].month,'2026-10');assert.equal(r[0].purchaseTotalCUP,100);assert.equal(r[0].netSalesCUP,150);assert.equal(r[1].month,'2026-09');assert.equal(r[1].purchaseTotalCUP,50);assert.equal(r[1].netSalesCUP,-20);
});
test('productos con nombres iguales se distinguen por ID interno cuando el ticket lo contiene',()=>{
 const rows=Core.aggregateProductSales([{id:'1',name:'Aceite',quantity:5},{id:'2',name:'Aceite',quantity:8}],[{kind:'sale',items:[{productId:'1',name:'Aceite',baseQty:2,lineTotalCUP:30}]}]);
 assert.equal(rows.find(x=>x.productId==='1').sold,2);assert.equal(rows.find(x=>x.productId==='2').sold,0);
});
test('el directorio automático, los registros reales y sus limitaciones están presentes en las vistas',()=>{
 const src=fs.readFileSync(path.join(__dirname,'../renderer/business-management.js'),'utf8');
 assert.match(src,/function suppliersView\([\s\S]*?summarizeSupplierPurchases\(getPurchases\(\),state\.suppliers\)/);
 assert.match(src,/function getPurchases\(\)\{ return readMainArray\('elite_purchases'\); \}/);assert.match(src,/function getClosingHistory\(\)\{ return readMainArray\('elite_closing_history'\); \}/);assert.match(src,/function getTransfers\(\)\{ return readMainArray\('elite_transfers'\)/);
 assert.match(src,/function actualActivityBody\(/);assert.match(src,/actualPurchasePayablesReference\(8\)/);assert.match(src,/function branchesView\([\s\S]*?summarizeSalesByPOS\(sales,closings,pos\)/);
 assert.match(src,/no se convierten automáticamente en cuentas por pagar/i);assert.match(src,/Compras → Nueva compra/);
});
test('Compra conserva Extra de compra y teléfono opcional enlazado con Proveedores',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../renderer/index.html'),'utf8');const costing=fs.readFileSync(path.join(__dirname,'../renderer/purchase-costing.js'),'utf8');
 assert.match(html,/id="purchase-supplier-phone"/);assert.match(html,/id="purchase-extra-amount"/);assert.match(html,/supplierPhone,\s*priceCurrency:/);assert.match(html,/getKnownSuppliers/);assert.match(costing,/allocateExtra/);
});


test('lee las listas almacenadas con el formato de Security.obfuscate de ProControl',()=>{
 const encode=value=>{const encoded=Buffer.from(unescape(encodeURIComponent(JSON.stringify(value))),'binary').toString('base64');return Buffer.from('PROCONTROL_SECRET_2026:'+encoded).toString('base64');};
 const stored={elite_purchases:[{id:1,supplier:'Proveedor A'}],elite_inventory:[{id:'p1',name:'Arroz'}],elite_pos:['Centro',{id:'p2',name:'Playa',inventory:[]}],elite_closing_history:[{id:'c1',difference:10}]};
 const mock={getItem:key=>Object.prototype.hasOwnProperty.call(stored,key)?encode(stored[key]):null};
 assert.deepEqual(Core.readProControlStoredArray(mock,'elite_purchases'),stored.elite_purchases);
 assert.deepEqual(Core.readProControlStoredArray(mock,'elite_inventory'),stored.elite_inventory);
 assert.deepEqual(Core.readProControlStoredArray(mock,'elite_pos'),stored.elite_pos);
 assert.deepEqual(Core.readProControlStoredArray(mock,'elite_closing_history'),stored.elite_closing_history);
});
test('lector de datos reales devuelve una lista vacía segura ante claves ausentes o malformadas',()=>{
 assert.deepEqual(Core.readProControlStoredArray({getItem:()=>null},'elite_purchases'),[]);
 assert.deepEqual(Core.readProControlStoredArray({getItem:()=>'{not json'},'elite_inventory'),[]);
 assert.deepEqual(Core.readProControlStoredArray(null,'elite_sales_ledger'),[]);
});
test('venta no se marca pendiente de cierre solo porque falta closingId',()=>{
 assert.equal(Core.isSalePendingClose({id:'s1',status:'completed'}),false);
 assert.equal(Core.isSalePendingClose({id:'s2',status:'pending-close'}),true);
 assert.equal(Core.isSalePendingClose({id:'s3',pendingReview:true}),true);
});

test('cierres IPV antiguos crean ventas estimadas a partir de campos guardados y sin inventar precio actual',()=>{
 const close={id:'ipv-1',ts:'2026-10-20T10:00:00Z',posId:'p1',posName:'Centro',salesTrackingMode:false,rotationDataVersion:1,salesLedgerIds:[],totalRevenue:250,products:[{productId:'g1',name:'Galleta',sold:5,subtotal:100},{productId:'c1',name:'Carne',sold:2,subtotal:150}]};
 const rows=Core.buildLegacyClosingSales([close],[]);assert.equal(rows.length,1);assert.equal(rows[0].estimatedFromClosing,true);assert.equal(rows[0].items.length,2);assert.equal(rows[0].items[0].lineTotalCUP,100);assert.equal(rows[0].totalCUP,250);
 const product=Core.aggregateProductSales([{id:'g1',name:'Galleta',qty:10,sale:999}],rows)[0];assert.equal(product.revenue,100);assert.equal(product.sold,5);
});
test('cierres con tickets asociados no se duplican en la estimación IPV',()=>{
 const close={id:'tracked-1',ts:'2026-10-20T10:00:00Z',salesTrackingMode:true,rotationDataVersion:2,salesLedgerIds:['s1'],totalRevenue:300,products:[{productId:'a',name:'Arroz',sold:3,subtotal:300}]};
 assert.equal(Core.isLegacyEstimatedClosing(close,[]),false);assert.deepEqual(Core.buildLegacyClosingSales([close],[]),[]);
 assert.equal(Core.buildLegacyClosingSales([{...close,id:'old',salesTrackingMode:false,rotationDataVersion:1,salesLedgerIds:[]}],[{id:'s2',closingId:'old',items:[]}]).length,0);
});
test('resumen mensual utiliza ingresos de cierres IPV antiguos cuando no hay tickets',()=>{
 const closings=[{id:'ipv-m',ts:'2026-10-20T10:00:00Z',date:'20/10/2026',salesTrackingMode:false,rotationDataVersion:1,salesLedgerIds:[],totalRevenue:250,products:[{name:'Galleta',sold:5,subtotal:250}]}];
 const summary=Core.summarizeRealOperations([],[],closings,[],[{id:'p1',name:'Centro'}],new Date('2026-10-28T12:00:00Z'));
 assert.equal(summary.netSalesCUP,250);assert.equal(summary.salesCount,0);assert.equal(summary.estimatedClosingsCount,1);assert.match(summary.salesSource,/IPV/);
});
test('comparación por punto de venta incluye IPV estimado, no duplica tickets y devuelve importes no disponibles si faltan valores',()=>{
 const closings=[{id:'ipv-p',ts:'2026-10-20T10:00:00Z',posId:'p1',posName:'Centro',salesTrackingMode:false,rotationDataVersion:1,salesLedgerIds:[],totalRevenue:250,products:[{name:'Galleta',sold:5,subtotal:250}]},{id:'tracked-p',ts:'2026-10-21T10:00:00Z',posId:'p2',posName:'Playa',salesTrackingMode:true,rotationDataVersion:2,salesLedgerIds:['s2'],totalRevenue:500,products:[{name:'Arroz',sold:5,subtotal:500}]}];
 const rows=Core.summarizeSalesByPOS([{id:'s2',closingId:'tracked-p',posId:'p2',posName:'Playa',kind:'sale',totalCUP:500,items:[]}],closings,[{id:'p1',name:'Centro'},{id:'p2',name:'Playa'}]);
 assert.equal(rows.find(r=>r.name==='Centro').netSalesCUP,250);assert.equal(rows.find(r=>r.name==='Centro').estimatedClosingCount,1);assert.equal(rows.find(r=>r.name==='Playa').netSalesCUP,500);assert.equal(rows.find(r=>r.name==='Playa').estimatedClosingCount,0);
});
test('reposición reconoce el campo qty y el mínimo manual real de ProControl',()=>{
 const rows=Core.suggestReplenishment([{id:'p1',name:'Arroz',qty:4,cost:10,sale:15,stockAlertSettings:{manualMinimum:8,leadTimeDays:3}}],[],14,new Date('2026-10-28T12:00:00Z'));
 assert.equal(rows.length,1);assert.equal(rows[0].stock,4);assert.equal(rows[0].min,8);assert.equal(rows[0].suggested,4);
});
test('movimiento de inventario lee qty de la estructura principal de ProControl',()=>{
 const rows=Core.inventoryMovementAnalysis([{id:'p1',name:'Arroz',qty:12}],[],'2026-10-28',30);assert.equal(rows.length,1);assert.equal(rows[0].stock,12);
});
test('semáforo acepta exigir evidencias operativas reales sin declarar estable si no hay ventas ni cierres',()=>{
 const a=Core.healthAssessment({hasTransactions:true,hasInventory:true,liquidityKnown:true,cashAvailable:500,overdue:0,pending:0,stockAlerts:0,requireMainOperationalEvidence:true,hasSalesEvidence:false,hasClosingEvidence:false});
 assert.equal(a.status,'unknown');assert.equal(a.enoughData,false);assert.ok(a.checks.some(c=>c.label==='Ventas y demanda'&&c.state==='unknown'));assert.ok(a.checks.some(c=>c.label==='Cierres de caja'&&c.state==='unknown'));
});
test('semáforo alerta ante diferencias de cierres y márgenes negativos basados en la fuente principal',()=>{
 const a=Core.healthAssessment({hasTransactions:true,hasInventory:true,liquidityKnown:true,cashAvailable:500,overdue:0,pending:0,stockAlerts:0,requireMainOperationalEvidence:true,hasSalesEvidence:true,hasClosingEvidence:true,closingDifferences:2,pendingSales:1,movementReviewCount:3,negativeMargins:1});
 assert.equal(a.status,'attention');assert.ok(a.checks.some(c=>c.label==='Diferencias de cierre'&&c.state==='attention'));assert.ok(a.checks.some(c=>c.label==='Ventas por cerrar'&&c.state==='attention'));assert.ok(a.checks.some(c=>c.label==='Productos con margen bruto negativo'&&c.state==='attention'));
});


test('las compras inteligentes cruzan demanda fechada, devoluciones, POS, plazo, ciclo de compra y coste',()=>{
 const products=[{id:'p1',name:'Arroz',qty:3,cost:12,unit:'u',supplier:'Proveedor A',stockAlertSettings:{manualMinimum:5,leadTimeDays:4}}];
 const sales=Array.from({length:30},(_,i)=>({id:'s'+i,ts:new Date(Date.UTC(2026,9,1+i,12)).toISOString(),kind:'sale',items:[{productId:'p1',name:'Arroz',baseQty:2}]}));
 sales.push({id:'ret',ts:'2026-10-29T12:00:00Z',kind:'return',items:[{productId:'p1',name:'Arroz',baseQty:1}]});
 const pos=[{id:'pos1',name:'Centro',inventory:[{id:'p1',name:'Arroz',qty:4}]}];
 const purchases=['2026-09-01','2026-09-16','2026-10-01'].map((date,i)=>({id:'buy'+i,date, supplier:'Proveedor A',items:[{productId:'p1',name:'Arroz',qty:10,cost:12}]}));
 const suppliers=[{name:'Proveedor A',leadDays:5}];
 const rows=Core.suggestReplenishment(products,sales,14,new Date('2026-10-30T12:00:00Z'),{pointsOfSale:pos,supplierDirectory:suppliers,purchases});
 assert.equal(rows.length,1);assert.equal(rows[0].stock,3);assert.equal(rows[0].posStock,4);assert.equal(rows[0].totalNetworkStock,7);assert.equal(rows[0].leadDays,4);assert.equal(rows[0].purchaseHistoryCount,3);assert.equal(rows[0].purchaseCycleDays,15);assert.ok(rows[0].suggested>0);assert.ok(rows[0].estimatedPurchaseValue>0);
});
test('las ventas sin fecha no se convierten en demanda diaria inventada',()=>{const rows=Core.suggestReplenishment([{id:'p1',name:'Producto',qty:0,minStock:5}],[{kind:'sale',items:[{productId:'p1',name:'Producto',baseQty:100}]}],14,new Date('2026-10-30T12:00:00Z'));assert.equal(rows.length,1);assert.equal(rows[0].daily,0);assert.equal(rows[0].suggested,5);assert.equal(rows[0].source,'manual-minimum');assert.match(rows[0].reason,/sin fecha verificable/);});
test('el resumen y las funciones analíticas ofrecen tipos de gráfico barras, líneas, pastel y área',()=>{const src=fs.readFileSync(path.join(__dirname,'../renderer/business-management.js'),'utf8');assert.match(src,/option value="bar"/);assert.match(src,/option value="line"/);assert.match(src,/option value="pie"/);assert.match(src,/option value="area"/);assert.match(src,/chartVisual\(config\.rows,mode,config\.options\)/);assert.match(src,/chartSlug=String\(title/);assert.doesNotMatch(src,/Alertas de negocio|function alertsView/);});
test('Puntos de venta muestra Precio Venta Divisas y mantiene el código de moneda',()=>{const html=fs.readFileSync(path.join(__dirname,'../renderer/index.html'),'utf8');assert.match(html,/<th>Precio<br>Venta divisas<\/th>/);assert.match(html,/class="pos-divisa-price"[\s\S]*?item\.saleUSD[\s\S]*?otherPriceCurrencyLabel/);assert.doesNotMatch(html,/data-pcbm-tab="alerts"/);});
test('comparación por POS calcula top cinco con devoluciones y mantiene monedas no comparables separadas',()=>{const rows=Core.summarizeProductSalesByPOS([{posId:'p1',posName:'Centro',kind:'sale',items:[{name:'A',baseQty:8,lineTotalCUP:80,currency:'CUP'},{name:'B',baseQty:5,lineTotalCUP:50,currency:'CUP'},{name:'C',baseQty:4,lineTotalCUP:40,currency:'CUP'},{name:'D',baseQty:3,lineTotalCUP:30,currency:'CUP'},{name:'E',baseQty:2,lineTotalCUP:20,currency:'CUP'},{name:'F',baseQty:1,lineTotalCUP:10,currency:'CUP'}]},{posId:'p1',posName:'Centro',kind:'return',items:[{name:'A',baseQty:2,lineTotalCUP:20,currency:'CUP'}]}],[{id:'p1',name:'Centro'}]);assert.equal(rows[0].topProducts.length,5);assert.equal(rows[0].topProducts[0].name,'A');assert.equal(rows[0].topProducts[0].units,6);assert.equal(rows[0].distinctProducts,6);});


test('coste estimado de compra usa el coste final de las compras cuando el inventario no lo tiene',()=>{const sales=[{ts:'2026-10-28T12:00:00Z',items:[{productId:'p1',name:'Café',baseQty:10}]}];const purchases=[{date:'2026-10-20',items:[{productId:'p1',name:'Café',qty:5,cost:115,baseCost:100,extraPerUnit:15}]}];const rows=Core.suggestReplenishment([{id:'p1',name:'Café',qty:0,minStock:0}],sales,14,new Date('2026-10-30T12:00:00Z'),{purchases});assert.equal(rows.length,1);assert.equal(rows[0].unitCost,115);assert.equal(rows[0].unitCostSource,'compras históricas');assert.equal(rows[0].estimatedPurchaseValue,rows[0].suggested*115);});



// Presentación: gráficas legibles y comparación de POS seleccionada manualmente.
const businessSource=fs.readFileSync(path.join(__dirname,'../renderer/business-management.js'),'utf8');
const indexSource=fs.readFileSync(path.join(__dirname,'../renderer/index.html'),'utf8');
test('los gráficos adaptan el margen del eje lateral a cifras grandes sin deformar la cuadrícula',()=>{assert.match(businessSource,/axisLabels=Array\.from\(\{length:5\}/);assert.match(businessSource,/longestAxisLabel/);assert.match(businessSource,/estimatedAxisLabelWidth/);assert.match(businessSource,/const left=Math\.max\(104,Math\.ceil\(estimatedAxisLabelWidth\+30\)\)/);assert.match(businessSource,/plotW=Math\.max\(260,width-left-right\)/);assert.match(businessSource,/100\.010\.000|formatChartValue\(maxValue/);assert.match(businessSource,/font-size="\$\{axisFontSize\}" font-weight="700" fill="#c5d0dc"/);assert.match(businessSource,/pcbm-chart-legend li\{font-size:13px\}/);});
test('la comparación de puntos de venta empieza vacía y permite añadir hasta cuatro puntos',()=>{assert.match(businessSource,/let selectedBranchIds=\[\]/);assert.match(businessSource,/selectedBranchIds\.length>=4/);assert.match(businessSource,/Añadir un punto de venta/);assert.match(businessSource,/data-branch-add/);assert.match(businessSource,/data-branch-remove/);});
test('la comparación agrupa las métricas, el top 5 y el inventario dentro de cada ficha de punto',()=>{assert.match(businessSource,/pcbm-pos-compare-card/);assert.match(businessSource,/5 productos más vendidos/);assert.match(businessSource,/Inventario local/);assert.match(businessSource,/Cómo aprovechar este punto/);});
test('las columnas POS conservan precios, cantidad y encabezados de precio en dos líneas',()=>{assert.match(indexSource,/<th>Precio<br>Venta<\/th>/);assert.match(indexSource,/<th>Precio<br>Venta transf\.<\/th>/);assert.match(indexSource,/<th>Precio<br>Venta divisas<\/th>/);assert.match(indexSource,/<th>Cantidad<\/th>/);assert.match(indexSource,/stock-quantity-value/);assert.match(indexSource,/stock-quantity-cell/);});

test('el Almacén Central permite seleccionar y guardar la moneda de Precio Venta Divisas por separado de la compra',()=>{assert.match(indexSource,/id="page-warehouse"[\s\S]*?<th>Precio<br>Venta divisas<\/th>/);assert.match(indexSource,/warehouse-divisa-price-input[\s\S]*?Inventory\.updateSalePriceUSD/);assert.match(indexSource,/renderSaleCurrencyPicker\(item, originalIndex\)/);assert.match(indexSource,/Elegir moneda/);assert.match(indexSource,/warehouse-sale-currency-select/);assert.match(indexSource,/Inventory\.updateSaleCurrency/);assert.match(indexSource,/item\.saleCurrency = selectedCurrency/);assert.match(indexSource,/posItem\.saleCurrency = selectedCurrency/);assert.match(indexSource,/item\.saleCustomCurrency/);assert.match(indexSource,/otherPriceCurrencyLabel/);assert.doesNotMatch(indexSource,/item\.saleCurrency = selectedCurrency;[\s\S]{0,120}item\.priceCurrency = selectedCurrency/);});
test('el stock en sistema del cierre diario se presenta en azul y las cantidades conservan su clase visual',()=>{assert.match(indexSource,/class="closing-stock-system stock-quantity-cell"/);assert.match(indexSource,/closing-stock-system-value/);assert.match(indexSource,/#pos-closing-overlay .closing-stock-system[\s\S]*?color:#1769c8/);});
test('todos los símbolos de dólar visibles se envuelven en una marca verde sin alterar importes',()=>{assert.match(indexSource,/\.pc-money-symbol \{ color:#20ad62/);assert.match(indexSource,/procontrol-green-dollar-symbols/);assert.match(indexSource,/document\.createTreeWalker\(node, NodeFilter\.SHOW_TEXT\)/);assert.match(indexSource,/new MutationObserver\(records/);});

test('almacén central y POS usan una presentación compacta para aumentar los productos visibles',()=>{assert.match(indexSource,/class="inventory-page-title-row warehouse-title-row"/);assert.match(indexSource,/class="inventory-page-toolbar warehouse-toolbar"/);assert.match(indexSource,/class="inventory-page-title pos-title"/);assert.match(indexSource,/class="inventory-page-toolbar pos-toolbar"/);const density=indexSource.slice(indexSource.lastIndexOf('<style id="procontrol-inventory-compact-density">'));assert.match(density,/#page-pos-workspace:not\(\.hidden\)[\s\S]*?height: 100vh/);assert.match(density,/\.warehouse-sale-currency-picker\s*\{[\s\S]*?display: flex !important/);assert.match(density,/\.warehouse-sale-currency-caption\s*\{[\s\S]*?white-space: nowrap !important/);assert.match(density,/\.warehouse-sale-currency-select\s*\{[\s\S]*?height: 18px !important/);assert.match(density,/\.inventory-table td\s*\{[\s\S]*?padding: 3px 3px !important/);assert.match(density,/\.family-header td\s*\{[\s\S]*?padding: 3px 7px !important/);assert.match(density,/\.warehouse-title-divider[\s\S]*?margin: \.12rem 0 \.38rem/);assert.match(density,/\.warehouse-toolbar[\s\S]*?margin: 0 0 \.34rem/);});


test('los recibos de compra incluyen firmas de Entrega y Recibe',()=>{assert.match(indexSource,/class="signature-grid"[\s\S]*?class="signature-line"[\s\S]*?>Entrega<\/span>[\s\S]*?class="signature-line"[\s\S]*?>Recibe<\/span>/);assert.match(indexSource,/\.signature-grid\{[\s\S]*?page-break-inside:avoid/);});
test('la impresión del inventario consolidado incluye un espacio de firma',()=>{const start=indexSource.indexOf('printFullInventory() {');const end=indexSource.indexOf('printIPV() {',start);const output=indexSource.slice(start,end);assert.ok(start>=0&&end>start);assert.match(output,/print-signature/);assert.match(output,/Firma:/);assert.match(output,/print-signature-line/);});
test('la hoja IPV impresa incluye espacio para la firma del dependiente',()=>{const start=indexSource.indexOf('printIPV() {');const end=indexSource.indexOf('async addNewPOS()',start);const output=indexSource.slice(start,end);assert.ok(start>=0&&end>start);assert.match(output,/Firma del dependiente:/);assert.match(output,/ipv-signature-line/);});
test('el reporte de cierre de venta imprime nombre y firma del dependiente',()=>{const start=indexSource.indexOf('printClosingReport() {');const end=indexSource.indexOf('setupInfiniteScroll()',start);const output=indexSource.slice(start,end);assert.ok(start>=0&&end>start);assert.match(output,/Nombre del dependiente:/);assert.match(output,/Firma del dependiente:/);assert.match(output,/print-signature-block/);});


test('Almacén Central aumenta más la legibilidad y permite un leve aumento de altura de filas',()=>{
 const start=indexSource.lastIndexOf('<style id="procontrol-inventory-legibility-with-controlled-density">');
 const style=indexSource.slice(start,indexSource.indexOf('</style>',start));
 assert.ok(start>=0);assert.match(style,/#page-warehouse \.inventory-table tbody tr:not\(\.family-header\) td:first-child[\s\S]*?font-size: \.94rem !important/);
 assert.match(style,/#page-warehouse \.inventory-table \.edit-input[\s\S]*?height: 24px !important[\s\S]*?font-size: \.82rem !important/);
 assert.match(style,/#page-warehouse \.warehouse-divisa-price-input[\s\S]*?height: 23px !important[\s\S]*?font-size: \.82rem !important/);
 assert.match(style,/#page-warehouse \.inventory-table tbody tr:not\(\.family-header\) td[\s\S]*?padding: 3px 3px !important/);
});
test('Puntos de venta aumentan nombres y números y solo elevan ligeramente cada fila',()=>{
 const start=indexSource.lastIndexOf('<style id="procontrol-inventory-legibility-with-controlled-density">');
 const style=indexSource.slice(start,indexSource.indexOf('</style>',start));
 assert.match(style,/#page-pos-workspace \.inventory-table tbody tr:not\(\.family-header\) td:first-child[\s\S]*?font-size: \.98rem !important/);
 assert.match(style,/#page-pos-workspace \.inventory-table tbody tr:not\(\.family-header\) td:nth-child\(3\)[\s\S]*?font-size: \.86rem !important/);
 assert.match(style,/#page-pos-workspace \.inventory-table tbody tr:not\(\.family-header\) td \{[\s\S]*?padding: 4px 3px !important[\s\S]*?line-height: 1\.17 !important/);
});

console.log(`Resultado: ${passed} pruebas aprobadas, 0 fallidas.`);
