'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'renderer', 'index.html'), 'utf8');

assert.match(html, /id="cash-cup-breakdown-panel"[\s\S]*?Desglose de Efectivo \(CUP\)/, 'El desglose de efectivo CUP es el único que aparece por defecto.');
assert.match(html, /onclick="Inventory\.toggleAddCurrencyBreakdown\(\)">＋ Añadir desglose/, 'Hay un botón para añadir un desglose de moneda.');
assert.match(html, /getDashboardRates\(\)/, 'Las monedas disponibles se obtienen de Monedas y tasas.');
assert.match(html, /session\.currencyBreakdowns\[key\]/, 'Cada moneda añadida se persiste en la sesión del cierre.');
assert.match(html, /data-currency-key=/, 'Los campos de denominación están asociados a la moneda correcta.');
assert.match(html, /currencyBreakdowns: currencyBreakdowns/, 'El historial guarda el desglose y la tasa utilizada en cada moneda.');
assert.doesNotMatch(html, /id="usd-grid-container"/, 'USD no se muestra por defecto como segundo desglose fijo.');

// Ejecuta el método real de cálculo, aislado de la UI, para verificar conversiones y suma.
const start = html.indexOf('_cashTotals(session) {');
const end = html.indexOf('\n},\nopenClosingModal()', start);
assert.ok(start >= 0 && end > start, 'Se localiza el método _cashTotals real.');
const method = html.slice(start, end + 2);
const inventory = Function('appState', `return ({${method}\n})`)({ dollarRate: 850, businessData: {} });
inventory._availableClosingCurrencies = () => [
  { key: 'EUR', currency: 'EUR', label: 'EUR', rate: 900 },
  { key: 'USD', currency: 'USD', label: 'USD', rate: 850 }
];
inventory._round = (value, digits = 2) => Number(Number(value).toFixed(digits));
const result = inventory._cashTotals({
  cash: { 100: 0 },
  usd: {},
  transfer: 0,
  currencyBreakdowns: {
    EUR: { key: 'EUR', currency: 'EUR', label: 'EUR', rate: 900, denominations: { 100: 1 } },
    USD: { key: 'USD', currency: 'USD', label: 'USD', rate: 850, denominations: { 10: 1 } }
  }
});
assert.equal(result.currencyTotals.find(item => item.currency === 'EUR').cupTotal, 90000, '100 EUR × 900 = 90.000 CUP.');
assert.equal(result.currencyTotals.find(item => item.currency === 'USD').cupTotal, 8500, '10 USD × 850 = 8.500 CUP.');
assert.equal(result.general, 98500, 'El total suma las monedas convertidas a CUP.');
assert.deepEqual(result.missingRates, [], 'No marca tasas vigentes como faltantes.');

const withoutRate = inventory._cashTotals({
  cash: {}, usd: {}, transfer: 0,
  currencyBreakdowns: { MLC: { key: 'MLC', currency: 'MLC', label: 'MLC', rate: 0, denominations: { 100: 1 } } }
});
assert.deepEqual(withoutRate.missingRates, ['MLC'], 'Bloquea moneda extranjera con importe si no tiene una tasa válida.');

console.log('Multicurrency closing: 100 EUR × 900 = 90.000 CUP; 10 USD × 850 = 8.500 CUP; total 98.500 CUP. Todas las comprobaciones aprobaron.');
