#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'renderer', 'index.html'), 'utf8');
const alerts = fs.readFileSync(path.join(root, 'renderer', 'inventory-alerts.js'), 'utf8');
const checks = [
  ['el cierre diario por IPV aparece como flujo principal', /Cierre diario por IPV/.test(html)],
  ['los tickets individuales están etiquetados como opcionales', /Tickets individuales \(opcional\)/.test(html) && /Registro individual de ventas \(opcional\)/.test(html)],
  ['la guía no exige al dependiente registrar ventas en la PC', /El dependiente trabaja con su IPV impreso/.test(html) && /no necesitas llenar este borrador si trabajas con el IPV impreso/.test(html)],
  ['el cierre describe la estimación por stock inicial y conteo final', /comparando el stock inicial con el conteo final/.test(html) && /Modo IPV \(flujo recomendado\)/.test(html)],
  ['las alertas de atención inmediata no requieren datos de ventas', /No requiere tickets ni cierres de venta/.test(alerts) && /No necesitas tickets de venta ni cierres de caja para usar esta función/.test(html)],
  ['el tablero usa un límite manual y un margen fijo de aviso', /WARNING_BAND_UNITS = 10/.test(alerts) && /Stock de alerta/.test(html) && /AVISO preventivo/.test(html)],
  ['el flujo IPV y sus opciones de ticket siguen documentados aparte de las alertas', /Tickets individuales \(opcional\)/.test(html) && /El dependiente trabaja con su IPV impreso/.test(html)]
];
let failed=0;
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} - ${name}`);
  if (!ok) failed++;
}
if (failed) process.exit(1);
console.log(`\n${checks.length}/${checks.length} comprobaciones del flujo IPV aprobadas.`);
