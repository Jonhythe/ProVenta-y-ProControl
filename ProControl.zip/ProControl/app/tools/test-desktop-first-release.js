#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const uiPath = path.join(root, 'renderer', 'mobile-bridge-ui.js');
const ui = fs.readFileSync(uiPath, 'utf8');
const html = fs.readFileSync(path.join(root, 'renderer', 'index.html'), 'utf8');
const control = fs.readFileSync(path.join(root, 'electron', 'mobile-bridge', 'control-plane.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const checks = [
  ['perfil de publicación PC-first activo', /const\s+DESKTOP_ONLY_RELEASE\s*=\s*true\s*;/.test(ui)],
  ['el panel móvil muestra un aviso de próxima actualización', /Aplicación móvil — próxima actualización/.test(ui)],
  ['el aviso explica que PC funciona de forma independiente', /funciona de forma independiente en modo SIN APP/.test(ui)],
  ['las acciones ProVenta se abren desde las herramientas del POS activo', /ProVentaAuthorizationUI\.openForCurrentPOS\('open'\)/.test(html) && /ProVentaAuthorizationUI\.openForCurrentPOS\('close'\)/.test(html) && !/ProVentaAuthorizationUI\.open\(\)/.test(html)],
  ['el proceso principal mantiene MOBILE_APP_READY desactivado', /const\s+MOBILE_APP_READY\s*=\s*false\s*;/.test(control)],
  ['el proceso principal rechaza CON_APP mientras no haya app móvil', /mode\s*===\s*'CON_APP'\s*&&\s*!this\.mobileAppReady/.test(control)],
  ['el control de publicación forma parte de check-source', pkg.scripts['check-source'].includes('test-desktop-first-release.js')]
];
let failed = 0;
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} - ${name}`);
  if (!ok) failed++;
}

// Smoke test of the default production branch with a minimal DOM mock.
(async () => {
  delete process.env.PROCONTROL_TEST_MOBILE_UI;
  const elements = new Map();
  const close = { id: 'close-button', classList: { contains: () => true }, style: {} };
  const title = { id: 'old-title', classList: { contains: () => false }, style: {} };
  const oldContent = { id: 'old-content', classList: { contains: () => false }, style: {} };
  const panel = {
    children: [close, title, oldContent],
    appendChild(node) { this.children.push(node); if (node.id) elements.set(node.id, node); }
  };
  const overlay = { id: 'mobile-bridge-overlay', style: { display: 'none' }, querySelector: selector => selector === 'section' ? panel : null };
  elements.set('mobile-bridge-overlay', overlay);
  global.document = {
    getElementById: id => elements.get(id) || null,
    createElement: tag => ({ tagName: tag.toUpperCase(), id: '', style: {}, innerHTML: '', classList: { contains: () => false } })
  };
  global.Auth = { requireRole: () => true };
  global.window = { PCMobileBridge: {} };
  try {
    delete require.cache[require.resolve(uiPath)];
    require(uiPath);
    await global.window.MobileBridgeUI.open();
    const notice = elements.get('mobile-bridge-desktop-notice');
    const runtimeOk = overlay.style.display === 'flex' && notice && notice.style.display === 'block' &&
      title.style.display === 'none' && oldContent.style.display === 'none' &&
      notice.innerHTML.includes('próxima actualización') && notice.innerHTML.includes('SIN APP');
    checks.push(['la rama PC-first muestra el aviso y oculta los controles operativos (prueba de ejecución)', !!runtimeOk]);
    console.log(`${runtimeOk ? 'PASS' : 'FAIL'} - la rama PC-first muestra el aviso y oculta los controles operativos (prueba de ejecución)`);
    if (!runtimeOk) failed++;
  } catch (error) {
    console.error('FAIL - prueba de ejecución del perfil PC-first:', error && error.stack || error);
    failed++;
  }
  if (failed) process.exitCode = 1;
  else console.log(`Desktop-first release guard: ${checks.length} assertions passed.`);
})().catch(error => { console.error(error); process.exitCode = 1; });
