'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { MobileBridgeStore, signedFields } = require('../electron/mobile-bridge/store');
let assertions = 0;
function ok(value, message) { assertions++; assert.ok(value, message); }
function equal(actual, expected, message) { assertions++; assert.equal(actual, expected, message); }
function deviceKeys() {
  const pair = crypto.generateKeyPairSync('ed25519');
  return { privateKey: pair.privateKey, publicKey: pair.publicKey.export({ type: 'spki', format: 'pem' }).toString() };
}
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-proventa-auth-'));
let store;
let secondStore;
try {
  const ownerDir = path.join(root, 'owner');
  const otherOwnerDir = path.join(root, 'other-owner');
  store = new MobileBridgeStore(ownerDir);
  const installationId = store.getInstallationId();
  const authorizedPosId = 'pos_demo_0001';
  ok(/^pcinst_[a-f0-9]{32}$/.test(installationId), 'La identidad de instalación se deriva de la clave pública Ed25519');
  const installationPattern = store.getInstallationCodePattern();
  ok(/^P1-[a-f0-9]{16}$/.test(installationPattern.patternId), 'Cada instalación obtiene una identidad de patrón propia y versionada');
  store.close(); store = null;
  store = new MobileBridgeStore(ownerDir);
  equal(store.getInstallationId(), installationId, 'La identidad de instalación permanece estable después de reiniciar');
  equal(store.getInstallationCodePattern().patternId, installationPattern.patternId, 'El patrón permanece estable después de reiniciar ProControl');

  const legacyAuth = store.createDeviceAuthorization({ employeeName: 'Autorización anterior', posId: authorizedPosId }, 'Dueño');
  let legacyCode = '';
  for (let attempt = 0; attempt < 100; attempt++) {
    const candidate = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    const duplicate = store.db.prepare('SELECT 1 FROM device_authorizations WHERE code_hash=?').get(require('../electron/mobile-bridge/store').sha256(candidate));
    if (!duplicate && !store._codeMatchesInstallationPattern(candidate)) { legacyCode = candidate; break; }
  }
  ok(/^\d{6}$/.test(legacyCode), 'La prueba prepara un código pendiente de formato anterior');
  const legacyHash = require('../electron/mobile-bridge/store').sha256(legacyCode);
  store.db.prepare('UPDATE device_authorizations SET code_hash=? WHERE authorization_id=?').run(legacyHash, legacyAuth.authorizationId);
  store.db.prepare('UPDATE pairing_codes SET code_hash=? WHERE authorization_id=?').run(legacyHash, legacyAuth.authorizationId);
  const legacyDescriptor = JSON.parse(store.createDeviceAuthorizationDescriptor({ ...legacyAuth, code: legacyCode }, 'Dueño'));
  equal(Object.prototype.hasOwnProperty.call(legacyDescriptor, 'codePattern'), false, 'Una autorización pendiente anterior conserva compatibilidad como ficha legacy firmada');

  const auth = store.createDeviceAuthorization({ employeeName: 'Dependiente Demo', employeeData: 'Contacto: 555-0100', posId: authorizedPosId }, 'Dueño');
  ok(auth.ok && /^\d{6}$/.test(auth.code), 'Se emite un código temporal de un solo uso');
  const codeDigits = [...auth.code].map(Number);
  equal(auth.code[5], store._installationCodeCheckDigit(auth.code.slice(0, 5)), 'El último dígito se calcula con la identidad propia de la instalación');
  if (installationPattern.mode === 'starts_with') equal(codeDigits[0], installationPattern.firstDigit, 'El código respeta el prefijo propio de esta instalación');
  else equal(codeDigits.filter(digit => digit % 2 === 1).length, installationPattern.oddDigitCount, 'El código respeta la cantidad exacta de cifras impares de esta instalación');
  equal(auth.codePattern.patternId, installationPattern.patternId, 'El código emitido informa el perfil de su instalación');
  for (let sample = 0; sample < 8; sample++) {
    const next = store.createDeviceAuthorization({ employeeName: `Prueba de patrón ${sample}`, posId: authorizedPosId }, 'Dueño');
    const digits = [...next.code].map(Number);
    equal(next.codePattern.patternId, installationPattern.patternId, `El código ${sample + 2} conserva el patrón del mismo ProControl`);
    equal(next.code[5], store._installationCodeCheckDigit(next.code.slice(0, 5)), `El código ${sample + 2} conserva el dígito comprobador propio de la instalación`);
    if (installationPattern.mode === 'starts_with') equal(digits[0], installationPattern.firstDigit, `El código ${sample + 2} conserva el prefijo del negocio`);
    else equal(digits.filter(digit => digit % 2 === 1).length, installationPattern.oddDigitCount, `El código ${sample + 2} conserva la cantidad de cifras impares del negocio`);
    store.db.prepare('DELETE FROM pairing_codes WHERE authorization_id=?').run(next.authorizationId);
    store.db.prepare('DELETE FROM device_authorizations WHERE authorization_id=?').run(next.authorizationId);
  }
  equal(auth.installationId, installationId, 'La autorización está vinculada a la instalación actual');
  equal(auth.replacesAuthorizationId, null, 'Primera autorización no sustituye otra');
  const descriptor = JSON.parse(store.createDeviceAuthorizationDescriptor(auth, 'Dueño'));
  equal(descriptor.format, 'procontrol.device-authorization', 'Se genera formato propio para autorización de dispositivo');
  equal(descriptor.installationId, installationId, 'La ficha firmada contiene la identidad de instalación');
  equal(descriptor.version, 2, 'La ficha usa la versión que exige POS fijo');
  equal(descriptor.authorizedPosId, authorizedPosId, 'La ficha firmada liga el teléfono a un POS concreto');
  equal(descriptor.codePattern.patternId, installationPattern.patternId, 'La ficha firmada lleva la identidad verificable del patrón');
  equal(descriptor.codePattern.checksumAlgorithm, 'sha256-installation-scoped-v1', 'La ficha firma el algoritmo de comprobación vinculado a la instalación');
  ok(crypto.verify(null, signedFields(descriptor), crypto.createPublicKey(descriptor.desktopPublicKey), Buffer.from(descriptor.signature.value, 'base64')), 'La ficha de autorización tiene firma Ed25519 válida');

  secondStore = new MobileBridgeStore(otherOwnerDir);
  equal(secondStore.getInstallationId() === installationId, false, 'Otra instalación tiene una identidad criptográfica distinta');
  ok(/^P1-[a-f0-9]{16}$/.test(secondStore.getInstallationCodePattern().patternId), 'Otra instalación deriva una identidad de patrón desde su propia clave');
  equal(secondStore.getInstallationCodePattern().patternId === installationPattern.patternId, false, 'Dos identidades criptográficas independientes reciben perfiles propios distintos');
  const foreignAttempt = secondStore.pairDevice({ code: auth.code, deviceId: 'device_foreign_01', label: 'Teléfono ajeno', publicKey: deviceKeys().publicKey, installationId }, 'Dueño');
  equal(foreignAttempt.code, 'PAIRING_CODE_INVALID_OR_EXPIRED', 'El código de una empresa no existe en la instalación de otro dueño');
  secondStore.close(); secondStore = null;

  const firstKeys = deviceKeys();
  const firstPairing = store.pairDevice({ code: auth.code, authorizationId: auth.authorizationId, authorizedPosId, deviceId: 'device_worker_01', label: 'Teléfono trabajador', publicKey: firstKeys.publicKey, installationId }, 'Dueño');
  equal(firstPairing.ok, true, 'Se vincula teléfono con la autorización correcta');
  equal(firstPairing.posId, authorizedPosId, 'La autorización del teléfono queda limitada al POS indicado');
  equal(firstPairing.installationId, installationId, 'El dispositivo queda ligado a la instalación');
  equal(store.listDeviceAuthorizations()[0].status, 'active', 'El registro pasa a activo al vincular el teléfono');
  equal(store.listDeviceAuthorizations()[0].deviceId, 'device_worker_01', 'El registro conserva el identificador del dispositivo');
  try {
    store.createDeviceAuthorization({ employeeName: 'Dependiente Demo', posId: 'pos_otro_0001', replacesAuthorizationId: auth.authorizationId }, 'Dueño');
    throw new Error('No debe permitir mover una autorización al sustituirla desde otro POS');
  } catch (error) { equal(error.code, 'REPLACEMENT_POS_SCOPE_MISMATCH', 'La sustitución no puede trasladar el teléfono a otro POS'); }
  const otherPosAuth = store.createDeviceAuthorization({ employeeName: 'Otro POS', posId: 'pos_otro_0001' }, 'Dueño');
  equal(store.listDeviceAuthorizations(authorizedPosId).some(row => row.authorizationId === otherPosAuth.authorizationId), false, 'El listado de un POS no expone autorizaciones de otro POS');
  equal(store.listDeviceAuthorizations('pos_otro_0001').some(row => row.authorizationId === otherPosAuth.authorizationId), true, 'El otro POS solo ve su propia autorización');
  equal(store.revokeDeviceAuthorization(otherPosAuth.authorizationId, 'Dueño', authorizedPosId).code, 'AUTHORIZATION_POS_SCOPE_MISMATCH', 'La revocación desde otro POS queda bloqueada');
  equal(store.pairDevice({ code: auth.code, deviceId: 'device_worker_02', label: 'Segundo teléfono', publicKey: deviceKeys().publicKey, installationId }, 'Dueño').code, 'PAIRING_CODE_INVALID_OR_EXPIRED', 'El código no puede reutilizarse');

  const replacement = store.createDeviceAuthorization({ employeeName: 'Dependiente Demo', employeeData: 'Contacto actualizado', posId: authorizedPosId, replacesAuthorizationId: auth.authorizationId }, 'Dueño');
  const replacementKeys = deviceKeys();
  const replacementResult = store.pairDevice({ code: replacement.code, authorizationId: replacement.authorizationId, authorizedPosId, deviceId: 'device_worker_02', label: 'Teléfono sustituto', publicKey: replacementKeys.publicKey, installationId }, 'Dueño');
  equal(replacementResult.ok, true, 'La nueva autorización permite vincular el teléfono sustituto');
  const rowsAfterReplacement = store.listDeviceAuthorizations();
  const oldRow = rowsAfterReplacement.find(row => row.authorizationId === auth.authorizationId);
  const newRow = rowsAfterReplacement.find(row => row.authorizationId === replacement.authorizationId);
  equal(oldRow.status, 'superseded', 'El teléfono anterior queda como sustituido');
  equal(newRow.status, 'active', 'La autorización nueva queda activa');
  equal(oldRow.deviceId, 'device_worker_01', 'Se conserva el identificador del teléfono anterior');
  equal(store.db.prepare('SELECT enabled FROM devices WHERE device_id=?').get('device_worker_01').enabled, 0, 'El teléfono sustituido queda deshabilitado');

  const revokeResult = store.revokeDeviceAuthorization(replacement.authorizationId, 'Dueño');
  equal(revokeResult.ok, true, 'El Dueño puede invalidar la autorización actual');
  equal(store.listDeviceAuthorizations().find(row => row.authorizationId === replacement.authorizationId).status, 'invalidated', 'El registro queda invalidado');
  equal(store.db.prepare('SELECT enabled FROM devices WHERE device_id=?').get('device_worker_02').enabled, 0, 'El teléfono revocado queda deshabilitado');
  const reenable = store.setDeviceEnabled('device_worker_02', true, 'Dueño');
  equal(reenable.code, 'DEVICE_AUTHORIZATION_NOT_REACTIVATABLE', 'Una autorización invalidada no se reactiva silenciosamente');

  // Solicitud de vinculación firmada desde el teléfono y devuelta por USB.
  const usbAuth = store.createDeviceAuthorization({ employeeName: 'Operador USB', posId: authorizedPosId }, 'Dueño');
  const usbKeys = deviceKeys();
  const enrollment = {
    format: 'procontrol.device-enrollment-request', version: 1,
    installationId, authorizationId: usbAuth.authorizationId, authorizedPosId, code: usbAuth.code,
    deviceId: 'device_usb_0001', label: 'Android USB', devicePublicKey: usbKeys.publicKey,
    createdAt: new Date().toISOString()
  };
  enrollment.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(enrollment), usbKeys.privateKey).toString('base64') };
  const imported = store.importDeviceEnrollment(JSON.stringify(enrollment), 'Dueño');
  equal(imported.ok, true, 'ProControl importa una solicitud de teléfono firmada desde USB');
  equal(imported.deviceId, enrollment.deviceId, 'La solicitud registra el ID real del teléfono');
  equal(store.listDeviceAuthorizations().find(row => row.authorizationId === usbAuth.authorizationId).status, 'active', 'La importación activa la autorización');
  const reusedEnrollment = store.importDeviceEnrollment(JSON.stringify(enrollment), 'Dueño');
  equal(reusedEnrollment.code, 'PAIRING_CODE_INVALID_OR_EXPIRED', 'Una solicitud ya usada no puede volver a vincular otro teléfono');
  const tamperedEnrollment = { ...enrollment, deviceId: 'device_tampered_01' };
  const tamperedResult = store.importDeviceEnrollment(JSON.stringify(tamperedEnrollment), 'Dueño');
  equal(tamperedResult.code, 'ENROLLMENT_SIGNATURE_INVALID', 'No acepta una solicitud alterada tras su firma');

  const lostAuth = store.createDeviceAuthorization({ employeeName: 'Trabajador teléfono perdido', posId: authorizedPosId }, 'Dueño');
  const lostKeys = deviceKeys();
  const lostPairing = store.pairDevice({ code: lostAuth.code, authorizationId: lostAuth.authorizationId, authorizedPosId, deviceId: 'device_lost_0001', label: 'Teléfono perdido', publicKey: lostKeys.publicKey, installationId }, 'Dueño');
  equal(lostPairing.ok, true, 'Se vincula el teléfono original que después se pierde');
  equal(store.revokeDeviceAuthorization(lostAuth.authorizationId, 'Dueño').ok, true, 'El Dueño puede bloquear de inmediato el teléfono perdido');
  const recoveryAuth = store.createDeviceAuthorization({ employeeName: 'Trabajador teléfono perdido', posId: authorizedPosId, replacesAuthorizationId: lostAuth.authorizationId }, 'Dueño');
  const recoveryKeys = deviceKeys();
  const recovered = store.pairDevice({ code: recoveryAuth.code, authorizationId: recoveryAuth.authorizationId, authorizedPosId, deviceId: 'device_lost_0002', label: 'Teléfono nuevo', publicKey: recoveryKeys.publicKey, installationId }, 'Dueño');
  equal(recovered.ok, true, 'Puede sustituirse también una autorización previamente invalidada');
  equal(store.listDeviceAuthorizations().find(row => row.authorizationId === lostAuth.authorizationId).status, 'superseded', 'El registro del equipo perdido queda sustituido tras vincular el nuevo');

  const third = store.createDeviceAuthorization({ employeeName: 'Otro Trabajador', posId: authorizedPosId }, 'Dueño');
  const wrongInstallation = store.pairDevice({ code: third.code, deviceId: 'device_wrong_install', label: 'Teléfono prueba', publicKey: deviceKeys().publicKey, authorizedPosId, installationId: 'pcinst_' + '0'.repeat(32) }, 'Dueño');
  equal(wrongInstallation.code, 'INSTALLATION_MISMATCH', 'La vinculación exige la identidad exacta de instalación');
  try { store.createDeviceAuthorization({ employeeName: 'X', posId: authorizedPosId }, 'Dueño'); throw new Error('Debe rechazar nombre de trabajador demasiado corto'); }
  catch (error) { equal(error.code, 'INVALID_EMPLOYEE_DATA', 'Valida los datos del trabajador'); }
  try { store.createDeviceAuthorization({ employeeName: 'Sin POS' }, 'Dueño'); throw new Error('Debe rechazar autorización sin POS'); }
  catch (error) { equal(error.code, 'POS_SCOPE_REQUIRED', 'No permite emitir códigos sin POS fijo'); }

  console.log(`ProVenta installation authorization: ${assertions} assertions passed.`);
} finally {
  try { if (store) store.close(); } catch (_) {}
  try { if (secondStore) secondStore.close(); } catch (_) {}
  fs.rmSync(root, { recursive: true, force: true });
}
