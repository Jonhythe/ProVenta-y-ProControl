'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'renderer', 'index.html'), 'utf8');
const ui = fs.readFileSync(path.join(root, 'renderer', 'proventa-authorization-ui.js'), 'utf8');
const main = fs.readFileSync(path.join(root, 'electron', 'main.js'), 'utf8');
const preload = fs.readFileSync(path.join(root, 'electron', 'preload.js'), 'utf8');
const store = fs.readFileSync(path.join(root, 'electron', 'mobile-bridge', 'store.js'), 'utf8');
const credentialHelper = fs.readFileSync(path.join(root, 'electron', 'security', 'privileged-credentials.js'), 'utf8');
let assertions = 0;
function expect(condition, message) { assertions++; assert.ok(condition, message); }
expect(html.includes('ProVentaAuthorizationUI.openAdmin()'), 'La administración de ProVenta debe abrirse desde el menú Administración de la ventana de inicio.');
expect(html.includes('id="page-proventa-admin"') && html.includes('Administración de ProVenta'), 'La administración tiene una página central independiente.');
expect(!html.includes('Vincular ProVenta a este POS') && !html.includes('ProVentaAuthorizationUI.openForCurrentPOS()'), 'No debe existir una acción para vincular el teléfono desde la ficha o lista de POS.');
expect(html.includes("ProVentaAuthorizationUI.openForCurrentPOS('open')") && html.includes("ProVentaAuthorizationUI.openForCurrentPOS('close')"), 'Las acciones específicas de apertura y cierre permanecen dentro del POS activo.');
expect(html.includes('Dispositivos vinculados') && html.includes('Historial de autorizaciones'), 'La página central contiene el registro de dispositivos y el historial de autorizaciones.');
expect(html.includes('proventa-admin-search') && html.includes('proventa-admin-status-filter'), 'La lista ofrece búsqueda y filtros de estado.');
expect(html.includes('proventa-admin-detail') && html.includes('proventa-auth-history'), 'La interfaz tiene ficha individual e historial auditable.');
expect(html.includes('Importar identidad .pvid y generar QR'), 'ProControl debe recibir la identidad PVID1 exportada desde ProVenta.');
expect(html.includes('Código PVLA2 generado') && html.includes('Mostrar código QR para escanear') && !html.includes('Exportar código .pvla2'), 'La interfaz entrega la autorización únicamente por QR.');
expect(!html.includes('Copiar código completo') && !ui.includes('copyCode') && !preload.includes('copyProVentaActivationCode') && !main.includes('proventa:copy-activation-code'), 'La transferencia por portapapeles fue eliminada del flujo de autorización.');
expect(html.includes('proventa-auth-qr-wrap') && ui.includes('qr.toDataUrl(code, 7)'), 'La UI genera y muestra un QR único convencional con el mismo PVLA2.');
expect(html.includes('qrcode-engine.js') && html.includes('local-qr.js') && preload.includes('proventa:issue-device-renewal-code'), 'La interfaz carga el motor QR local y expone la renovación firmada.');
expect(!html.includes('Guardar ficha .pcpair (USB)'), 'No vuelve a introducirse la ficha antigua .pcpair.');
expect(html.includes('el .pvid para registrar las claves del teléfono') && html.includes('PVLA2'), 'La ayuda explica que el .pvid solo se importa en el alta inicial.');
expect(ui.includes('proventaGenerateActivationCodeFromPvid'), 'La interfaz usa el IPC que valida PVID1 y genera PVLA2.');
expect(ui.includes('api().listShiftPermits({ posId, authToken })') && ui.includes("row.status === 'issued'"), 'La UI recupera los permisos de turno guardados para el POS activo.');
expect(ui.includes('exportExistingShiftPermit') && ui.includes('retry-permit-export') && html.includes('proventa-shift-permit-recovery'), 'Un permiso guardado se puede reexportar desde su POS correcto.');
expect(preload.includes("proventa:generate-activation-code-from-pvid") && preload.includes("proventa:list-device-authorization-history"), 'Preload expone generación e historial de autorizaciones.');
expect(main.includes("'proventa:generate-activation-code-from-pvid'") && main.includes("'proventa:list-device-authorizations'") && main.includes("'proventa:list-device-authorization-history'"), 'El proceso principal implementa las operaciones centrales de autorización.');
expect(store.includes('decodeProVentaDeviceIdentity') && store.includes('PVID1_SIGNATURE_INVALID'), 'La identidad .pvid se valida criptográficamente antes de crear autorización.');
expect(store.includes("authorizationScope: 'installation'") && store.includes('protocolVersion = installationWide ? 6 : 4'), 'Las autorizaciones nuevas son V6 mensuales y las antiguas V4 conservan compatibilidad.');
expect(ui.includes("Auth.requireRole(['Dueño']"), 'La interfaz solo admite al Dueño.');
expect(main.includes('function getOwnerPrivilegedActor') && main.includes("actor.role === 'Dueño'"), 'El proceso principal valida el rol Dueño.');
expect(html.includes('setup-owner-pin') && html.includes('setup-owner-pin-confirm') && html.includes('Guardar y Entrar al Sistema') && html.includes('no compartas este PIN con nadie'), 'La primera configuración del negocio obliga a crear y proteger el PIN del Dueño.');
expect(html.includes('account-pin-new') && html.includes('Auth.setOwnerPin()') && html.includes('elite_user_pins'), 'El PIN puede cambiarse posteriormente desde Mi Cuenta.');
expect(ui.includes("id: 'pin'") && ui.includes("maxlength: 6") && ui.includes("!/^\\d{6}$/.test(pin)") && ui.includes('authorizeOwnerControl({ password, pin })') && !ui.includes("id: 'user'"), 'La autenticación de ProVenta rechaza un PIN incompleto antes de llamar al proceso principal y no pide usuario.');
expect(main.includes('function authenticateOwnerWithPin') && main.includes('findOwnerWithPin({ password, pin, roles, passwords, pins })') && credentialHelper.includes('!/^\\d{6}$/.test(pin)'), 'El proceso principal exige seis dígitos y valida contraseña y PIN almacenados.');
expect(main.includes("authMethod: 'owner-pin'") && main.includes("actor.authMethod === 'owner-pin'"), 'Los IPC de ProVenta solo aceptan sesiones verificadas específicamente con PIN del Dueño.');
expect(html.includes('form-username-recovery') && html.includes('username-recovery-question') && html.includes('username-recovery-password') && html.includes('Auth.recoverUsernameLogin()'), 'La pantalla de acceso permite iniciar sesión sin escribir el usuario usando contraseña y pregunta.');
expect(html.includes('Auth.changeUsername()') && html.includes("DataStore.transaction('cambiar-nombre-de-usuario'") && html.includes('userQuestions') && html.includes('userPins'), 'Mi Cuenta permite cambiar el usuario con contraseña y mueve de forma transaccional sus credenciales asociadas.');
expect(main.includes("'auth:recover-username'") && preload.includes("'auth:recover-username'") && credentialHelper.includes('findUserWithPasswordAndSecurityAnswer'), 'La recuperación del usuario se verifica en el proceso principal sin exponer nombres antes de autenticar.');
const signupStart = html.indexOf('async handleSignup() {');
const signupEnd = html.indexOf('backFromSetup() {', signupStart);
const signupHandler = signupStart >= 0 && signupEnd > signupStart ? html.slice(signupStart, signupEnd) : '';
expect(
  signupHandler.includes('bridge.registerAccount') &&
  !signupHandler.includes('DataStore.save()') &&
  main.includes("'auth:register-account'") &&
  preload.includes("'auth:register-account'") &&
  credentialHelper.includes('BEGIN IMMEDIATE') &&
  credentialHelper.includes('USERNAME_EXISTS'),
  'El registro se guarda desde el proceso principal con transacción y unicidad autoritativa.'
);
const forgotStart = html.indexOf('async forgotLookup() {');
const forgotEnd = html.indexOf('openSecurityQuestion() {', forgotStart);
const forgotFlow = forgotStart >= 0 && forgotEnd > forgotStart ? html.slice(forgotStart, forgotEnd) : '';
expect(
  !html.includes('id="forgot-new-pass"') &&
  html.includes('id="forgot-lookup-button"') &&
  html.includes('onclick="Auth.forgotReset()">Verificar</button>') &&
  forgotFlow.includes("$('forgot-lookup-button').classList.add('hidden')") &&
  forgotFlow.indexOf('await Security.verifyPassword(answer, stored)') >= 0 &&
  forgotFlow.indexOf("await askInput('Crear nueva contraseña'") > forgotFlow.indexOf('await Security.verifyPassword(answer, stored)') &&
  forgotFlow.includes('DataStore.save()'),
  'El restablecimiento oculta Continuar tras confirmar usuario y solo pide la nueva contraseña en un modal tras validar la respuesta.'
);
expect(main.includes("'proventa:confirm-device-authorization'") && store.includes('confirmDeviceAuthorization'), 'El teléfono queda pendiente hasta que el Dueño confirma su alta.');
const generationHandler = main.slice(main.indexOf("ipcMain.handle('proventa:generate-activation-code-from-pvid'"), main.indexOf("ipcMain.handle('proventa:list-device-authorizations'"));
expect(generationHandler.includes('installationWide: true') && !generationHandler.includes('data.posId') && !generationHandler.includes('resolveProVentaPosContext'), 'La generación nueva no solicita ni persiste un POS permanente.');
expect(ui.includes('data-proventa-admin-action="replace"') && ui.includes('data-proventa-admin-action="revoke"'), 'El registro central permite invalidar y sustituir dispositivos.');
expect(ui.includes('proventaRevokeDeviceAuthorization({ authorizationId, reason, authToken })'), 'Invalidación y sustitución guardan un motivo obligatorio y no requieren POS.');
expect(ui.includes('proventaExportInventorySnapshot({ deviceId, posId, authToken })'), 'La exportación de inventario sigue ligada al POS operativo y no al código global.');
expect(html.includes('Exportar apertura completa (.pcopen + QR)') && html.includes('proventa-opening-qr-wrap') &&
  ui.includes('exportShiftOpeningBundle') && preload.includes('mobile-control:export-shift-opening-bundle') &&
  main.includes("'mobile-control:export-shift-opening-bundle'"),
  'La apertura ofrece un único paquete combinado y una secuencia QR, manteniendo el permiso e inventario vinculados.');
expect(main.includes('listDeviceAuthorizations()') && main.includes('listDeviceAuthorizationHistory(limit)') && main.includes('revokeDeviceAuthorization(authorizationId, actor.user, null, reason)'), 'Los IPC consultan historial global y revocan dentro de la instalación, con motivo.');
expect(html.includes('proventa-auth-overlay') && html.includes('proventa-authorization-ui.js'), 'Se conserva el panel de operaciones por turno y se carga el controlador.');


process.env.PROCONTROL_TEST_PROVENTA_AUTH_UI = '1';
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    id, value: '', textContent: '', innerHTML: '', style: {}, dataset: {},
    classList: { contains: () => false }, focus() {}, scrollIntoView() {}, select() {}
  });
  return elements.get(id);
}
let clickHandler = null;
global.document = { getElementById: element, addEventListener: (_name, callback) => { clickHandler = callback; } };
const activationCode = 'PVLA2:' + 'A'.repeat(128);
const recoverablePermit = {
  permitId: 'permit_saved_pos_demo_0001', posId: 'pos_demo_0001', deviceId: 'device_demo_0001',
  employee: 'Trabajador Persistido', status: 'issued', endsAt: Date.now() + 60 * 60 * 1000
};
let exportedOpeningCalls = [];
let activeClosePackage = null;
let beginApplyCalls = 0;
let failApplyCalls = 0;
let markAppliedCalls = 0;
let closureDecisionCalls = 0;
let closureConfirmed = false;
let failMarkAppliedOnce = false;
function makeClosePackage(packageId, overrides = {}) {
  const payload = {
    shiftPermitId: 'permit-close-demo-0001',
    shift: { permitId: 'permit-close-demo-0001', posId: 'pos_demo_0001', id: 'shift-demo-0001' },
    closingReport: {
      posId: 'pos_demo_0001', permitId: 'permit-close-demo-0001', shiftId: 'shift-demo-0001',
      products: [
        { productId: 'product-1', name: 'Uno', unit: 'ud', finalQuantityMicros: 1_500_000 },
        { productId: 'product-2', name: 'Dos', unit: 'kg', finalQuantityMicros: 0 }
      ]
    },
    ...overrides
  };
  return { packageId, type: 'shift_close', status: 'pending_review', payloadHash: 'a'.repeat(64), payload };
}
activeClosePackage = makeClosePackage('package_close_demo_0001');
let importChangesSelectedPos = false;
global.window = {
  confirm: () => true,
  ProControlLocalQR: {
    toDataUrl: value => { global.__qrAuthorizationCode = value; return 'data:image/svg+xml,test-qr'; },
    splitOpeningBundle: value => {
      global.__openingBundleForQr = value;
      return [{ index: 1, total: 1, dataUrl: 'data:image/svg+xml,opening-qr' }];
    }
  },
  PCMobileBridge: {
    authorizeOwnerControl: async input => {
      global.__ownerCredentials = input;
      return { ok: true, role: 'Dueño', token: 'owner-token', expiresAt: Date.now() + 300000 };
    },
    proventaListDeviceAuthorizations: async () => ({ ok: true, installationId: 'pcinst_0123456789abcdef0123456789abcdef', authorizations: [
      { authorizationId: 'auth_global_demo_000000000001', employeeName: 'Trabajador Global', deviceId: 'device_global_0001', deviceLabel: 'Samsung Global', protocolVersion: 6, renewalSequence: 1, authorizedPosId: null, status: 'active', issuedAt: Date.now(), createdBy: 'Dueño', employeeData: {} },
      { authorizationId: 'auth_legacy_other_0000000001', employeeName: 'Trabajador Antiguo', deviceId: 'device_legacy_0001', protocolVersion: 4, authorizedPosId: 'other_pos_0001', status: 'active', issuedAt: Date.now(), createdBy: 'Dueño', employeeData: {} }
    ] }),
    proventaListDeviceAuthorizationHistory: async () => ({ ok: true, history: [{ id: 1, at: Date.now(), action: 'device_authorized_from_pvid', actor: 'Dueño', detail: { employeeName: 'Trabajador Global', deviceId: 'device_global_0001' } }] }),
    listShiftPermits: async ({ posId }) => ({ ok: true, permits: posId === recoverablePermit.posId ? [
      recoverablePermit,
      { ...recoverablePermit, permitId: 'other-pos-permit', posId: 'other_pos_0001' },
      { ...recoverablePermit, permitId: 'expired-permit', endsAt: Date.now() - 1000 },
      { ...recoverablePermit, permitId: 'already-opened-permit', status: 'opened' }
    ] : [] }),
    exportShiftOpeningBundle: async input => {
      exportedOpeningCalls.push(input);
      return {
        ok: true,
        fileName: 'turno.pcopen',
        bytes: 4096,
        productCount: 3,
        bundleJson: JSON.stringify({
          format: 'procontrol.shift-opening-bundle',
          version: 1,
          bundleId: '12345678-1234-4234-8234-123456789abc'
        })
      };
    },
    proventaGenerateActivationCodeFromPvid: async input => {
      global.__generatedFromPvid = input;
      return {
        ok: true, authorizationId: 'auth_demo-authorization-id-0001', activationCode,
        employeeName: input.employeeName, deviceId: 'device_0123456789abcdef0123456789abcdef',
        authorizedPosId: null, authorizationScope: 'installation', protocolVersion: 6,
        installationId: 'pcinst_0123456789abcdef0123456789abcdef', fileName: 'phone.pvid',
        status: 'pending', renewalSequence: 1, qrExpiresAt: Date.now() + 300000
      };
    },
    proventaIssueDeviceRenewalCode: async input => ({
      ok: true, authorizationId: input.authorizationId, activationCode, employeeName: 'Trabajador Global',
      deviceId: 'device_global_0001', protocolVersion: 6, renewalSequence: 2,
      qrExpiresAt: Date.now() + 300000, status: 'active'
    }),
    proventaConfirmDeviceAuthorization: async input => { global.__confirmedEnrollment = input; return { ok: true, status: 'active' }; },
    proventaRevokeDeviceAuthorization: async input => { global.__revokedAuthorization = input; return { ok: true }; },
    proventaExportInventorySnapshot: async () => ({ ok: true, fileName: 'snapshot.pcinv', packageId: 'package_demo_0001', posName: 'Punto Demo', productCount: 3, expiresAt: Date.now() + 86400000 }),
    importFile: async () => { if (importChangesSelectedPos) global.appState.selectedPOSIndex = 1; return { ok: true, packageId: activeClosePackage.packageId }; },
    getPackage: async () => ({ ok: true, package: activeClosePackage }),
    decidePackage: async () => { activeClosePackage.status = 'accepted_for_reconciliation'; return { ok: true }; },
    beginPackageApply: async () => { beginApplyCalls++; return { ok: true }; },
    failPackageApply: async () => { failApplyCalls++; return { ok: true, retryable: true }; },
    markPackageApplied: async () => {
      markAppliedCalls++;
      if (failMarkAppliedOnce) { failMarkAppliedOnce = false; return { ok: false, code: 'SIMULATED_MARK_FAILURE' }; }
      activeClosePackage.status = 'reconciled';
      return { ok: true };
    },
    listPendingClosures: async () => ({ ok: true, closures: closureConfirmed ? [] : [{ packageId: activeClosePackage.packageId, closureId: 'close_demo_00000001', posId: 'pos_demo_0001' }] }),
    decidePendingClosure: async input => { closureDecisionCalls++; if (input.posId !== 'pos_demo_0001') return { ok: false, code: 'CLOSURE_POS_SCOPE_MISMATCH' }; closureConfirmed = true; return { ok: true }; },
    createPackageAcknowledgement: async () => ({ ok: true, acknowledgement: { packageId: activeClosePackage.packageId, signature: 'signed-test-ack' } }),
    savePackageAcknowledgement: async () => ({ ok: true, fileName: 'close-demo.pcack' })
  }
};
Object.defineProperty(global, 'navigator', { configurable: true, value: { clipboard: { writeText: async value => { global.__copiedAuthorizationCode = value; } } } });
let requiredRoles = null;
global.Auth = { requireRole: roles => { requiredRoles = roles; return true; } };
global.UI = { lastPage: null, showPage(page) { this.lastPage = page; } };
global.appState = { selectedPOSIndex: 0, pointsOfSale: [
  { id: 'pos_demo_0001', name: 'Punto Demo', inventory: [] },
  { id: 'other_pos_0001', name: 'Otro POS', inventory: [{ productId: 'other-product', unit: 'ud', qty: 77 }] }
] };
global.Inventory = { posReference: pos => `pos:${pos.id}`, refreshVisibleViews() {} };
global.History = { logEvent: () => true };
let failNextDataStoreTransaction = false;
global.DataStore = {
  transaction(_name, _keys, callback) {
    const before = JSON.stringify(global.appState.pointsOfSale);
    try {
      callback();
      if (failNextDataStoreTransaction) {
        failNextDataStoreTransaction = false;
        global.appState.pointsOfSale = JSON.parse(before);
        return { ok: false, error: { message: 'SIMULATED_DISK_WRITE_FAILURE' } };
      }
      return { ok: true };
    } catch (error) {
      global.appState.pointsOfSale = JSON.parse(before);
      return { ok: false, error: { message: error.message } };
    }
  }
};
const inputs = [
  { password: 'secret', pin: '123456' },
  { password: 'secret', pin: '123456' },
  { password: 'secret', pin: '123456' },
  { password: 'secret', pin: '123456' },
  { reason: 'Teléfono perdido, sustitución autorizada' }
];
const authRequests = [];
global.askInput = async (_title, fields) => { authRequests.push(fields); return inputs.shift(); };
require(path.join(root, 'renderer', 'proventa-authorization-ui.js'));
(async () => {
  await window.ProVentaAuthorizationUI.openForCurrentPOS();
  expect(requiredRoles.length === 1 && requiredRoles[0] === 'Dueño', 'Al abrir, debe solicitar rol Dueño.');
  expect(element('proventa-auth-overlay').style.display === 'flex', 'El panel debe abrirse.');
  expect(element('proventa-shift-device').innerHTML.includes('device_global_0001'), 'Un teléfono autorizado globalmente puede seleccionarse para emitir un permiso del POS activo.');
  expect(!element('proventa-shift-device').innerHTML.includes('device_legacy_0001'), 'Las autorizaciones antiguas siguen restringidas al POS que tenían asignado.');
  expect(element('proventa-shift-permit-recovery').innerHTML.includes(recoverablePermit.permitId), 'Al abrir el panel, recupera permisos emitidos que ya estaban guardados antes del reinicio.');
  expect(!element('proventa-shift-permit-recovery').innerHTML.includes('other-pos-permit'), 'Nunca muestra en el panel de recuperación un permiso de otro POS.');
  expect(!element('proventa-shift-permit-recovery').innerHTML.includes('expired-permit') && !element('proventa-shift-permit-recovery').innerHTML.includes('already-opened-permit'), 'No presenta para reexportación permisos caducados o que ya dejaron de estar emitidos.');
  global.appState.selectedPOSIndex = 1;
  const exportsBeforeWrongPOS = exportedOpeningCalls.length;
  await window.ProVentaAuthorizationUI.exportExistingShiftPermit(recoverablePermit.permitId, recoverablePermit.deviceId);
  expect(exportedOpeningCalls.length === exportsBeforeWrongPOS, 'Bloquea la reexportación si el usuario cambia a otro POS con el panel abierto.');
  global.appState.selectedPOSIndex = 0;
  const retryButton = { dataset: { proventaAction: 'retry-permit-export', permitId: recoverablePermit.permitId, deviceId: recoverablePermit.deviceId } };
  clickHandler({ target: { closest: selector => selector === '[data-proventa-action]' ? retryButton : null } });
  await new Promise(resolve => setTimeout(resolve, 0));
  expect(exportedOpeningCalls.length === 1, 'El botón reexporta la apertura completa del permiso persistido después de reiniciar.');
  expect(exportedOpeningCalls[0].permitId === recoverablePermit.permitId && exportedOpeningCalls[0].posId === 'pos_demo_0001' && exportedOpeningCalls[0].deviceId === recoverablePermit.deviceId, 'La reexportación conserva el permiso, teléfono y POS exactos.');
  expect(global.__openingBundleForQr && element('proventa-opening-qr-wrap').style.display === 'block', 'La exportación muestra la secuencia QR de la misma apertura completa guardada.');

  const localPos = global.appState.pointsOfSale[0];
  localPos.inventory = [
    { productId: 'product-1', unit: 'ud', qty: 90 },
    { productId: 'product-2', unit: 'kg', qty: 12 }
  ];
  failMarkAppliedOnce = true;
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(localPos.inventory[0].qty === 1.5 && localPos.inventory[1].qty === 0, 'El cierre aplica cantidades finales absolutas (incluidos los productos que terminan en cero).');
  expect(localPos.proventaClosureReceipts.length === 1 && markAppliedCalls === 1 && failApplyCalls === 1, 'Si falla el marcado posterior, mantiene el inventario guardado y registra un reintento seguro.');
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(localPos.inventory[0].qty === 1.5 && localPos.inventory[1].qty === 0 && localPos.proventaClosureReceipts.length === 1, 'Al reintentar el mismo cierre no duplica movimientos ni recibos.');
  expect(markAppliedCalls === 2 && closureDecisionCalls === 1 && closureConfirmed, 'El reintento completa conciliación, confirmación del cierre y acuse una sola vez.');
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(localPos.proventaClosureReceipts.length === 1 && closureDecisionCalls === 1, 'Reimportar un cierre ya confirmado es idempotente.');

  const stockAfterSuccess = JSON.stringify(localPos.inventory);
  const receiptsAfterSuccess = JSON.stringify(localPos.proventaClosureReceipts);
  const beginCallsBeforeInvalid = beginApplyCalls;
  activeClosePackage = makeClosePackage('package_wrong_pos_demo_0001');
  activeClosePackage.payload.closingReport.posId = 'other_pos_0001';
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(JSON.stringify(localPos.inventory) === stockAfterSuccess && beginApplyCalls === beginCallsBeforeInvalid, 'Rechaza un cierre de otro POS antes de empezar a conciliar.');

  activeClosePackage = makeClosePackage('package_missing_item_demo_0001');
  activeClosePackage.payload.closingReport.products.pop();
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(JSON.stringify(localPos.inventory) === stockAfterSuccess && beginApplyCalls === beginCallsBeforeInvalid, 'Rechaza cierres con productos faltantes antes de tocar el inventario.');

  activeClosePackage = makeClosePackage('package_duplicate_item_demo_001');
  activeClosePackage.payload.closingReport.products.push({ ...activeClosePackage.payload.closingReport.products[0] });
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(JSON.stringify(localPos.inventory) === stockAfterSuccess && beginApplyCalls === beginCallsBeforeInvalid, 'Rechaza IDs de producto duplicados antes de tocar el inventario.');

  activeClosePackage = makeClosePackage('package_bad_quantity_demo_0001');
  activeClosePackage.payload.closingReport.products[0].finalQuantityMicros = Number.MAX_SAFE_INTEGER + 1;
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(JSON.stringify(localPos.inventory) === stockAfterSuccess && beginApplyCalls === beginCallsBeforeInvalid, 'Rechaza cantidades fuera del rango entero seguro antes de tocar el inventario.');

  activeClosePackage = makeClosePackage('package_wrong_unit_demo_0001');
  activeClosePackage.payload.closingReport.products[0].unit = 'caja';
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(JSON.stringify(localPos.inventory) === stockAfterSuccess && beginApplyCalls === beginCallsBeforeInvalid, 'Rechaza unidades distintas a las del POS antes de tocar el inventario.');

  activeClosePackage = makeClosePackage('package_transaction_fail_demo_0001');
  failNextDataStoreTransaction = true;
  const failCountBefore = failApplyCalls;
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(JSON.stringify(global.appState.pointsOfSale[0].inventory) === stockAfterSuccess && JSON.stringify(global.appState.pointsOfSale[0].proventaClosureReceipts) === receiptsAfterSuccess, 'Si falla el guardado local, la transacción restaura el inventario y el registro de cierre.');
  expect(failApplyCalls === failCountBefore + 1, 'Un fallo de persistencia devuelve el paquete a un estado reintentable.');

  activeClosePackage = makeClosePackage('package_pos_switch_demo_0001');
  importChangesSelectedPos = true;
  const markCallsBeforePosSwitch = markAppliedCalls;
  await window.ProVentaAuthorizationUI.importShiftClose();
  expect(markAppliedCalls === markCallsBeforePosSwitch && global.appState.pointsOfSale[1].inventory[0].qty === 77, 'Rechaza el cambio de POS mientras se abre el selector de importación y no modifica el otro POS.');
  importChangesSelectedPos = false;
  global.appState.selectedPOSIndex = 0;

  await window.ProVentaAuthorizationUI.openAdmin();
  expect(UI.lastPage === 'page-proventa-admin', 'Administración de ProVenta abre su propia página desde el menú central.');
  expect(element('proventa-auth-installation').textContent.startsWith('pcinst_'), 'La página muestra la identidad de la instalación.');
  expect(authRequests[1].map(field => field.id).join(',') === 'password,pin', 'El diálogo de autorización no solicita username.');
  expect(element('proventa-auth-list').innerHTML.includes('Trabajador Global'), 'La tabla carga el registro global del teléfono.');
  expect(element('proventa-auth-history').innerHTML.includes('Identidad de teléfono registrada'), 'El historial muestra los eventos de autorización.');
  expect(element('proventa-admin-stat-active').textContent === '2', 'Los indicadores resumen solo el estado activo actual.');
  element('proventa-auth-employee').value = 'Trabajador Demo';
  element('proventa-auth-phone').value = '+53 5 123 4567';
  await window.ProVentaAuthorizationUI.generate();
  expect(global.__generatedFromPvid.employeeName === 'Trabajador Demo', 'Debe enviar el nombre del trabajador.');
  expect(global.__generatedFromPvid.phoneNumber === '+53 5 123 4567', 'Debe guardar el teléfono de contacto requerido.');
  expect(global.__generatedFromPvid.authToken === 'owner-token', 'Debe pasar la sesión verificada del Dueño.');
  expect(global.__ownerCredentials.password === 'secret' && global.__ownerCredentials.pin === '123456', 'La credencial de alta valida contraseña y PIN por IPC.');
  expect(!Object.prototype.hasOwnProperty.call(global.__generatedFromPvid, 'user'), 'La generación no solicita ni envía usuario.');
  expect(!Object.prototype.hasOwnProperty.call(global.__generatedFromPvid, 'posId'), 'La autorización global no debe enviar un POS al proceso principal.');
  expect(global.__generatedFromPvid.replacementReason === '', 'La primera autorización no debe incluir motivo de sustitución.');
  expect(global.__generatedFromPvid.replacesAuthorizationId === null, 'El primer código no debe inventar una sustitución.');
  expect(element('proventa-auth-code-details').textContent.includes('Renovación #1'), 'La tarjeta muestra la secuencia del QR mensual.');
  expect(element('proventa-auth-code-card').style.display === 'block', 'Debe mostrar la tarjeta con el código.');
  await window.ProVentaAuthorizationUI.showQr();
  expect(global.__qrAuthorizationCode === activationCode && element('proventa-auth-qr-image').src === 'data:image/svg+xml,test-qr', 'El QR muestra exactamente la autorización PVLA2 generada.');
  expect(element('proventa-auth-qr-wrap').style.display === 'block', 'El QR queda visible para escanearlo desde ProVenta.');
  expect(!window.ProVentaAuthorizationUI.exportCodeFile && !preload.includes('export-activation-code-file'), 'No existe un método alternativo de exportación del QR.');
  await window.ProVentaAuthorizationUI.confirmEnrollment();
  expect(global.__confirmedEnrollment.authorizationId === 'auth_demo-authorization-id-0001', 'El Dueño confirma explícitamente el registro después de verificar ProVenta.');
  await window.ProVentaAuthorizationUI.revoke('auth_global_demo_000000000001');
  expect(global.__revokedAuthorization.authorizationId === 'auth_global_demo_000000000001', 'La invalidación opera sobre la autorización seleccionada.');
  expect(global.__revokedAuthorization.reason === 'Teléfono perdido, sustitución autorizada', 'La invalidación exige y envía el motivo al proceso principal.');
  expect(!Object.prototype.hasOwnProperty.call(global.__revokedAuthorization, 'expectedPosId'), 'La invalidación no está ligada a un POS.');
  expect(typeof clickHandler === 'function', 'Debe instalar el manejador de acciones del registro.');
  window.ProVentaAuthorizationUI.close();
  expect(element('proventa-auth-overlay').style.display === 'none', 'Debe poder cerrar el panel.');
  console.log(`ProVenta authorization UI: ${assertions} assertions passed.`);
})().catch(error => { console.error(error); process.exitCode = 1; });
