'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const R = require('../renderer/product-catalog-rules.js');

// Clasificación del maíz: el vegetal no debe confundirse con harinas.
assert.equal(R.detectFamily('Maíz'), 'Viandas-Frutas-Vegetales');
assert.equal(R.detectFamily('Mazorca de maíz'), 'Viandas-Frutas-Vegetales');
assert.equal(R.detectFamily('Maíz tierno'), 'Viandas-Frutas-Vegetales');
assert.equal(R.detectFamily('Maíz dulce'), 'Viandas-Frutas-Vegetales');
assert.equal(R.detectFamily('Mazorca de maíz'), 'Viandas-Frutas-Vegetales');
assert.equal(R.detectFamily('Harina de maíz'), 'Harinas');
assert.equal(R.detectFamily('Maicena'), 'Harinas');
assert.equal(R.detectFamily('Maíz molido'), 'Harinas');
assert.equal(R.detectFamily('Maíz seco'), 'Granos');
assert.equal(R.detectFamily('Maíz desgranado'), 'Granos');
assert.equal(R.detectFamily('Maíz en lata'), 'Laterios');

// Las bolsas/paquetes se clasifican por el producto que contienen; una jaba de nailon es desechable.
for (const name of ['Bolsa de arroz', 'Bolsa arroz', 'Bolsa de Arroz 1 kg', 'Arroz en bolsa']) {
  assert.equal(R.detectFamily(name), 'Granos', `${name}: el contenido prevalece sobre bolsa`);
  assert.equal(R.purchaseUnitProfile(name).defaultUnit, 'pqt', `${name}: presentación en paquete`);
  assert.deepEqual(R.purchaseUnitProfile(name).allowedUnits, ['lb', 'pqt']);
}
for (const name of ['Jaba', 'Jaba de nailon', 'Jaba de nylon', 'Jaba de nilon', 'Jabas plásticas']) {
  assert.equal(R.detectFamily(name), 'Desechables', `${name}: familia de desechables`);
}
assert.equal(R.detectFamily('Bolsa de basura'), 'Desechables');
assert.equal(R.detectFamily('Bolsa plástica'), 'Desechables');

// Frases específicas ganan a coincidencias genéricas de ingredientes.
assert.equal(R.detectFamily('Salsa de tomate'), 'Salsas y Aderezos');
assert.equal(R.detectFamily('Puré de tomate'), 'Salsas y Aderezos');
assert.equal(R.detectFamily('Jugo de mango'), 'Bebidas');
assert.equal(R.detectFamily('Arroz con leche'), 'Elaborados');
assert.equal(R.detectFamily('Dulce de guayaba'), 'Confiteria');
assert.equal(R.detectFamily('Morcilla'), 'Embutidos');
assert.equal(R.detectFamily('Molleja'), 'Carnicos');

// Correcciones automáticas limitadas a errores conocidos y de alta certeza.
assert.equal(R.knownFamilyCorrection('Maíz', 'Harinas'), 'Viandas-Frutas-Vegetales');
assert.equal(R.knownFamilyCorrection('Maíz seco', 'Harinas'), 'Granos');
assert.equal(R.knownFamilyCorrection('Maíz en lata', 'Harinas'), 'Laterios');
assert.equal(R.knownFamilyCorrection('Maíz dulce', 'Confiteria'), 'Viandas-Frutas-Vegetales');
assert.equal(R.knownFamilyCorrection('Maíz molido', 'Viandas-Frutas-Vegetales'), 'Harinas');
assert.equal(R.knownFamilyCorrection('Harina de maíz', 'Harinas'), null);
assert.equal(R.knownFamilyCorrection('Tomate', 'Viandas-Frutas-Vegetales'), null);
assert.equal(R.knownFamilyCorrection('Salsa de tomate', 'Viandas-Frutas-Vegetales'), 'Salsas y Aderezos');
assert.equal(R.knownFamilyCorrection('Bolsa de arroz', 'Desechables'), 'Granos');
assert.equal(R.knownFamilyCorrection('Bolsa de arroz', 'Granos'), null);
assert.equal(R.knownFamilyCorrection('Jaba de nailon', 'Miscelaneas'), 'Desechables');
assert.equal(R.knownFamilyCorrection('Jaba de nailon', 'Desechables'), null);

// Arroz, frijoles y chícharos: libra por defecto; libra/paquete permitidos.
for (const name of ['Arroz', 'Frijoles negros', 'Chícharos', 'Habichuela seca']) {
  const profile = R.purchaseUnitProfile(name);
  assert.equal(profile.family, 'Granos', `${name}: familia de granos`);
  assert.equal(profile.defaultUnit, 'lb', `${name}: lb predeterminada`);
  assert.deepEqual(profile.allowedUnits, ['lb', 'pqt'], `${name}: solo lb o pqt`);
}
assert.equal(R.purchaseUnitProfile('Paquete de Arroz').defaultUnit, 'pqt');
assert.equal(R.purchaseUnitProfile('Arroz pqt').defaultUnit, 'pqt');

// Carnes y embutidos: paquete predeterminado, con lb/kg también disponibles.
for (const name of ['Carne de res', 'Carne de cerdo', 'Morcilla', 'Molleja']) {
  const profile = R.purchaseUnitProfile(name);
  assert.equal(profile.defaultUnit, 'pqt', `${name}: pqt predeterminada`);
  assert.deepEqual(profile.allowedUnits, ['pqt', 'lb', 'kg'], `${name}: pqt/lb/kg`);
}

// Productos de peso generales comienzan en lb sin perder el resto de opciones actuales.
assert.equal(R.purchaseUnitProfile('Tomate').defaultUnit, 'lb');
assert.equal(R.purchaseUnitProfile('Pargo').defaultUnit, 'lb');
assert.equal(R.purchaseUnitProfile('Harina de trigo').defaultUnit, 'lb');
assert.deepEqual(R.purchaseUnitProfile('Tomate').allowedUnits, ['u', 'pqt', 'lb', 'kg', 'lt']);

// La misma identidad no se puede guardar con otra unidad; se informa cómo separarla.
assert.equal(R.findUnitConflict([{ name: 'Arroz', unit: 'lb' }], 'pqt').storedUnit, 'lb');
assert.equal(R.findUnitConflict([{ name: 'Arroz', unit: 'lb' }], 'lb'), null);
const warning = R.unitConflictMessage('Arroz', 'pqt', 'lb', 'Almacén Central');
assert.match(warning, /ya existe/);
assert.match(warning, /Paquete de Arroz/);
assert.match(warning, /No se modificó el inventario/);

// Verifica que la UI integra el catálogo, restringe unidades y bloquea unidades
// distintas para el mismo nombre antes de tocar existencias.
const html = fs.readFileSync(path.join(__dirname, '..', 'renderer', 'index.html'), 'utf8');
assert.match(html, /app:\/\/product-catalog-rules\.js/);
assert.match(html, /ProductCatalogRules\.purchaseUnitProfile/);
assert.match(html, /ProductCatalogRules\.findUnitConflict\(matches, product\.unit\)/);
assert.match(html, /ProductCatalogRules\.unitConflictMessage/);
assert.match(html, /existingUnit && existingUnit !== option\.value/);
assert.match(html, /updateRowUnitSuggestion\(e\.target\.closest\('tr'\)\)/);
assert.match(html, /Inventory\.applyKnownFamilyCorrections\(\)/);

console.log('OK: familias, maíz vegetal, reglas de unidad predeterminada y bloqueo de presentaciones incompatibles.');
