'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'renderer', 'index.html'), 'utf8');
const packageJson = require(path.join(root, 'package.json'));

function ok(message) { console.log('OK:', message); }

// The price calculator belongs in Análisis, not in Auditoría or as another editable inventory column.
const auditMenuStart = html.indexOf('id="corrections-menu-overlay"');
const calculatorOverlayComment = html.indexOf('<!-- CALCULADORA DE PRECIO DE VENTA', auditMenuStart);
assert.ok(auditMenuStart >= 0 && calculatorOverlayComment > auditMenuStart, 'No se pudo delimitar el menú de Auditoría.');
const auditMenuSource = html.slice(auditMenuStart, calculatorOverlayComment);
assert.doesNotMatch(auditMenuSource, /Calcular precio en transferencia|openTransferSalePriceCalculator/);
assert.match(html, /onclick="Corrections\.openTransferSalePriceCalculator\(\); UI\.toggleNavMenu\('menu-pcbm-gestion-economica', this\)"/);
assert.match(html, /id="menu-pcbm-gestion-economica"[\s\S]*?Calcular precio en transferencia/);
const closeMethodStart = html.indexOf('closeTransferSalePriceCalculator() {');
const closeMethodEnd = html.indexOf('\n_transferSalePriceSelectedItem()', closeMethodStart);
assert.ok(closeMethodStart >= 0 && closeMethodEnd > closeMethodStart, 'No se encontró el cierre de la calculadora.');
assert.doesNotMatch(html.slice(closeMethodStart, closeMethodEnd), /corrections-menu-overlay/);
assert.match(html, /id="transfer-sale-price-overlay"/);
assert.match(html, /id="transfer-sale-price-product"/);
assert.match(html, /id="transfer-sale-price-mode-percent"/);
assert.match(html, /id="transfer-sale-price-mode-manual"/);
assert.match(html, /id="transfer-sale-price-preview"/);
assert.match(html, /id="transfer-sale-price-manual"/);
assert.doesNotMatch(html, /onchange="Inventory\.updateSalePriceTransf\(/);
ok('La calculadora está ubicada en Análisis, fue retirada de Auditoría y no agrega campos editables a las tablas de inventario.');

// Price values shown in inventory/POS tables are actionable entry points to the calculator.
const renderPriceStart = html.indexOf('renderSaleTransferPrice(item) {');
const renderPriceEnd = html.indexOf('\n},\nformatAlternativePrices(item)', renderPriceStart);
assert.ok(renderPriceStart >= 0 && renderPriceEnd > renderPriceStart, 'No se encontró renderSaleTransferPrice.');
const renderPriceSource = html.slice(renderPriceStart, renderPriceEnd);
assert.match(renderPriceSource, /sale-transfer-price-trigger/);
assert.match(renderPriceSource, /openTransferSalePriceCalculatorFromCell\(this\)/);
const openCalculatorStart = html.indexOf('openTransferSalePriceCalculator(productReference = null) {');
const openCalculatorEnd = html.indexOf('\nopenTransferSalePriceCalculatorFromCell(trigger)', openCalculatorStart);
assert.ok(openCalculatorStart >= 0 && openCalculatorEnd > openCalculatorStart, 'No se encontró la apertura contextual de la calculadora.');
const openCalculatorSource = html.slice(openCalculatorStart, openCalculatorEnd);
assert.match(openCalculatorSource, /candidate\.productId[\s\S]*?=== reference/);
assert.match(openCalculatorSource, /Inventory\._key\(candidate\.name\)[\s\S]*?referenceKey/);
assert.match(openCalculatorSource, /select\.value = String\(selectedIndex >= 0 \? selectedIndex : products\[0\]\.index\)/);
const saveCalculatorStart = html.indexOf('saveTransferSalePriceConfiguration() {');
const saveCalculatorEnd = html.indexOf('\ncloseModal(id)', saveCalculatorStart);
assert.ok(saveCalculatorStart >= 0 && saveCalculatorEnd > saveCalculatorStart, 'No se encontró el guardado de la calculadora.');
const saveCalculatorSource = html.slice(saveCalculatorStart, saveCalculatorEnd);
assert.doesNotMatch(saveCalculatorSource, /transfer-sale-price-overlay[\s\S]*?classList\.add\('hidden'\)/);
assert.match(saveCalculatorSource, /this\.loadTransferSalePriceProduct\(\)/);
ok('El precio en transferencia de cada fila abre la calculadora con el producto correspondiente seleccionado; el selector permite cambiar a otros productos y guardar varios sin cerrar la ventana.');

// Execute the same pure calculation method used by the UI and persistence layer.
const methodStart = html.indexOf('calculateSaleTransferPrice(baseCashPrice, percent) {');
const methodEnd = html.indexOf('\n},\nrenderSaleTransferPrice(item)', methodStart);
assert.ok(methodStart >= 0 && methodEnd > methodStart, 'No se encontró el cálculo centralizado del precio por transferencia.');
const methodSource = html.slice(methodStart, methodEnd + 2);
const calculator = new Function(`return ({${methodSource}}).calculateSaleTransferPrice;`)();
assert.equal(calculator(100, 10), 110);
assert.equal(calculator(500, 8), 540);
assert.equal(calculator(250, 5), 262.5);
assert.equal(calculator(80, 0), 80);
assert.equal(calculator(-1, 10), null);
assert.equal(calculator(100, -1), null);
ok('Cálculo comprobado: 100 + 10% = 110; 500 + 8% = 540; valida valores no negativos.');

// Verify exclusive modes, persistence and replication to points of sale.
assert.match(html, /item\.saleTransfMode = mode;/);
assert.match(html, /item\.saleTransfPercent = mode === 'percentage' \? percent : null;/);
assert.match(html, /posItem\.saleTransf = transferPrice;/);
assert.match(html, /posItem\.saleTransfMode = mode;/);
assert.match(html, /DataStore\.transaction\('configurar-precio-venta-transferencia'/);
assert.match(html, /action: 'sale-transfer-price-configuration'/);
ok('El guardado registra modo, porcentaje o precio manual, propaga el precio a los POS y deja auditoría.');

// When the cash base is changed, percentage-based products recalculate; manual prices stay fixed.
const updateStart = html.indexOf('updateSalePrice(index, newValue) {');
const updateEnd = html.indexOf('\nupdateSalePriceTransf(index, newValue) {', updateStart);
assert.ok(updateStart >= 0 && updateEnd > updateStart);
const updateSalePriceSource = html.slice(updateStart, updateEnd);
assert.match(updateSalePriceSource, /item\.saleTransfMode[\s\S]*?=== 'percentage'/);
assert.match(updateSalePriceSource, /this\.calculateSaleTransferPrice\(price, percent\)/);
assert.match(updateSalePriceSource, /if \(percentMode\) \{[\s\S]*?posItem\.saleTransf = nextTransferPrice;/);
assert.match(html, /sale-transfer-price-display[\s\S]*?<small>\$\{esc\(percentText\)\}<\/small>/);
ok('El modo porcentaje se recalcula al cambiar el precio en efectivo; el manual conserva su importe y la tabla muestra el porcentaje en pequeño.');

const checks = packageJson.scripts && packageJson.scripts['check-source'];
assert.ok(typeof checks === 'string' && checks.includes('test-sale-transfer-price-calculator.js'), 'El test nuevo debe formar parte de check-source.');
ok('El test queda incorporado al comando check-source.');
console.log('Resultado: calculadora de precio de venta por transferencia validada.');
