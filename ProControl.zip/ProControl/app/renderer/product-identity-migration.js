'use strict';

(function attachProductIdentityMigration(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ProductIdentityMigration = api;
})(typeof window !== 'undefined' ? window : globalThis, function createProductIdentityMigration() {
  const ID_RE = /^[A-Za-z0-9:_-]{1,160}$/;

  function normalizeName(value) {
    return String(value || '').trim().normalize('NFKC').toLowerCase().replace(/\s+/g, ' ');
  }
  function cloneJson(value, label) {
    try { return JSON.parse(JSON.stringify(value)); }
    catch (_) { throw Object.assign(new Error('No se pudo preparar una copia temporal de ' + label + '.'), { code: 'PRODUCT_IDENTITY_INVALID_DATA' }); }
  }
  function makeIssue(code, message, details) { return { code, message, ...(details || {}) }; }

  function plan(input, createStableId) {
    const source = input && typeof input === 'object' ? input : {};
    const inventory = cloneJson(Array.isArray(source.inventory) ? source.inventory : source.inventory, 'inventario');
    const pointsOfSale = cloneJson(Array.isArray(source.pointsOfSale) ? source.pointsOfSale : source.pointsOfSale, 'puntos de venta');
    const productCatalog = cloneJson(Array.isArray(source.productCatalog) ? source.productCatalog : source.productCatalog, 'catálogo');
    const transfers = cloneJson(Array.isArray(source.transfers) ? source.transfers : source.transfers, 'transferencias');
    const salesLedger = cloneJson(source.salesLedger === undefined ? [] : source.salesLedger, 'registro de ventas');

    const issues = [];
    const warnings = [];
    const nameToIds = new Map();
    const catalogById = new Map();
    const records = [];
    let generatedIds = 0;
    let transferLinks = 0;
    let ticketLinks = 0;
    let ticketLines = 0;
    let depletedProducts = 0;

    if (!Array.isArray(inventory) || !Array.isArray(pointsOfSale) || !Array.isArray(productCatalog) || !Array.isArray(transfers) || !Array.isArray(salesLedger)) {
      const error = Object.assign(new Error('La migración requiere inventario, puntos de venta, catálogo, transferencias y registro de ventas con estructura de lista válida.'), {
        code: 'PRODUCT_IDENTITY_INVALID_DATA',
        issues: [makeIssue('INVALID_TOP_LEVEL_STRUCTURE', 'Una o varias colecciones comerciales no son listas válidas.')]
      });
      throw error;
    }
    if (typeof createStableId !== 'function') throw new TypeError('La migración necesita un generador de ID estable.');

    const registerName = (name, id, sourceName) => {
      const key = normalizeName(name);
      if (!key) return;
      if (!nameToIds.has(key)) nameToIds.set(key, new Set());
      nameToIds.get(key).add(id);
      if (nameToIds.get(key).size > 1) {
        issues.push(makeIssue('CATALOG_NAME_COLLISION', `El nombre o alias “${key}” está vinculado a más de un ID de catálogo.`, { name: key, source: sourceName || 'catalog' }));
      }
    };

    for (let i = 0; i < productCatalog.length; i++) {
      const record = productCatalog[i];
      if (!record || typeof record !== 'object' || Array.isArray(record) || !ID_RE.test(String(record.id || '').trim()) || !String(record.name || '').trim()) {
        issues.push(makeIssue('INVALID_CATALOG_RECORD', `Ficha de catálogo inválida en la posición ${i + 1}.`, { index: i }));
        continue;
      }
      const id = String(record.id).trim();
      if (catalogById.has(id)) {
        issues.push(makeIssue('DUPLICATE_CATALOG_ID', `El ID ${id} está repetido en el catálogo.`, { id, index: i }));
        continue;
      }
      catalogById.set(id, record);
      registerName(record.name, id, 'catalog');
      if (Array.isArray(record.aliases)) record.aliases.forEach(alias => registerName(alias, id, 'alias'));
      else if (record.aliases != null) issues.push(makeIssue('INVALID_ALIASES', `Los alias de “${record.name}” no tienen una estructura válida.`, { id }));
    }

    const addItems = (items, location) => {
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (!item || typeof item !== 'object' || Array.isArray(item)) {
          issues.push(makeIssue('INVALID_INVENTORY_RECORD', `Registro inválido en ${location}, posición ${i + 1}.`, { location, index: i }));
          continue;
        }
        const name = String(item.name || '').trim();
        if (!name) {
          issues.push(makeIssue('MISSING_PRODUCT_NAME', `Hay un producto sin nombre en ${location}, posición ${i + 1}.`, { location, index: i }));
          continue;
        }
        records.push({ item, name, location, index: i });
      }
    };
    addItems(inventory, 'Almacén Central');
    for (let i = 0; i < pointsOfSale.length; i++) {
      const pos = pointsOfSale[i];
      if (!pos || typeof pos !== 'object' || Array.isArray(pos) || (pos.inventory !== undefined && !Array.isArray(pos.inventory))) {
        issues.push(makeIssue('INVALID_POS_INVENTORY', `El punto de venta en la posición ${i + 1} tiene un inventario inválido.`, { index: i }));
        continue;
      }
      if (!Array.isArray(pos.inventory)) pos.inventory = [];
      addItems(pos.inventory, `Punto de venta ${String(pos.name || pos.id || i + 1)}`);
    }

    const groups = new Map();
    for (const entry of records) {
      const key = normalizeName(entry.name);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(entry);
    }

    for (const [key, group] of groups) {
      const explicitIds = new Set();
      for (const row of group) {
        const ownId = String(row.item.productId || '').trim();
        if (ownId && !ID_RE.test(ownId)) issues.push(makeIssue('INVALID_PRODUCT_ID', `El producto “${row.name}” tiene un productId con formato incorrecto.`, { name: row.name, location: row.location, productId: ownId }));
        if (ownId) explicitIds.add(ownId);
      }
      const catalogMatches = new Set(nameToIds.get(key) || []);
      const candidateIds = new Set([...catalogMatches, ...explicitIds]);
      if (candidateIds.size > 1) {
        issues.push(makeIssue('PRODUCT_ID_CONFLICT', `“${group[0].name}” tiene varias identidades posibles entre catálogo y existencias.`, { name: group[0].name, locations: group.map(row => row.location), candidateIds: [...candidateIds] }));
        continue;
      }
      const id = [...candidateIds][0] || '';
      const everyRowHasSameExplicitId = !!id && group.every(row => String(row.item.productId || '').trim() === id);
      if (group.length > 1 && !everyRowHasSameExplicitId) {
        issues.push(makeIssue('AMBIGUOUS_DUPLICATE_NAME', `“${group[0].name}” aparece en varias filas/ubicaciones y no todas traen el mismo productId explícito. Aunque el catálogo tenga un nombre coincidente, no se fusionará por nombre; resuelve estas filas antes de migrar.`, {
          name: group[0].name,
          locations: group.map(row => row.location),
          explicitProductIds: group.map(row => String(row.item.productId || '').trim() || null),
          catalogCandidateIds: [...catalogMatches]
        }));
        continue;
      }
      const first = group[0].item;
      const unitKey = value => String(value || 'u').trim().toLowerCase();
      const familyKey = value => normalizeName(value || 'Miscelaneas');
      if (group.some(row => unitKey(row.item.unit) !== unitKey(first.unit) || familyKey(row.item.family) !== familyKey(first.family))) {
        issues.push(makeIssue('PRODUCT_UNIT_OR_FAMILY_CONFLICT', `“${group[0].name}” aparece con unidades o familias diferentes.`, { name: group[0].name, locations: group.map(row => row.location) }));
        continue;
      }

      let productId = id;
      if (productId) {
        let catalogRecord = catalogById.get(productId);
        if (catalogRecord) {
          const matches = new Set([catalogRecord.name, ...(Array.isArray(catalogRecord.aliases) ? catalogRecord.aliases : [])].map(normalizeName).filter(Boolean));
          if (!matches.has(key)) {
            issues.push(makeIssue('PRODUCT_ID_POINTS_TO_OTHER_NAME', `El ID ${productId} de “${group[0].name}” apunta a otra ficha de catálogo.`, { name: group[0].name, productId }));
            continue;
          }
        } else {
          catalogRecord = { id: productId, name: group[0].name, aliases: [], unit: String(first.unit || 'u'), family: String(first.family || 'Miscelaneas'), unitsPerBox: null };
          productCatalog.push(catalogRecord);
          catalogById.set(productId, catalogRecord);
          registerName(catalogRecord.name, productId, 'reconstructed-catalog');
        }
      } else {
        // Solo se crea automáticamente una identidad nueva cuando hay una única fila sin
        // historial de ID; los duplicados de nombre entre ubicaciones exigen resolución manual.
        productId = String(createStableId() || '').trim();
        if (!ID_RE.test(productId) || catalogById.has(productId)) {
          issues.push(makeIssue('GENERATED_ID_INVALID', `No se pudo crear un ID estable único para “${group[0].name}”.`, { name: group[0].name }));
          continue;
        }
        generatedIds++;
        const catalogRecord = { id: productId, name: group[0].name, aliases: [], unit: String(first.unit || 'u'), family: String(first.family || 'Miscelaneas'), unitsPerBox: null };
        productCatalog.push(catalogRecord);
        catalogById.set(productId, catalogRecord);
        registerName(catalogRecord.name, productId, 'new-catalog');
      }

      for (const row of group) {
        const ownId = String(row.item.productId || '').trim();
        if (ownId && ownId !== productId) {
          issues.push(makeIssue('PRODUCT_ID_CHANGE_REFUSED', `La fila “${row.name}” contiene un ID distinto (${ownId}); no se reasignó.`, { name: row.name, currentProductId: ownId, expectedProductId: productId, location: row.location }));
          continue;
        }
        row.item.productId = productId;
        if (Number(row.item.qty) <= 0) {
          row.item.stockEmpty = true;
          if (!row.item.stockEmptySince) row.item.stockEmptySince = Date.now();
          depletedProducts++;
        } else if (row.item.stockEmpty === true) {
          row.item.stockEmpty = false;
          row.item.stockRecoveredAt = Date.now();
        }
      }
    }

    // Rebuild the index after creating catalog entries above.
    const transferNameToIds = new Map();
    for (const record of productCatalog) {
      if (!record || !ID_RE.test(String(record.id || '').trim())) continue;
      const id = String(record.id).trim();
      for (const name of [record.name, ...(Array.isArray(record.aliases) ? record.aliases : [])]) {
        const key = normalizeName(name);
        if (!key) continue;
        if (!transferNameToIds.has(key)) transferNameToIds.set(key, new Set());
        transferNameToIds.get(key).add(id);
      }
    }
    for (const transfer of transfers) {
      if (!transfer || typeof transfer !== 'object' || Array.isArray(transfer)) {
        issues.push(makeIssue('INVALID_TRANSFER_RECORD', 'Existe una transferencia histórica con estructura inválida.'));
        continue;
      }
      const existingId = String(transfer.productId || '').trim();
      if (existingId) {
        if (!ID_RE.test(existingId)) issues.push(makeIssue('INVALID_TRANSFER_PRODUCT_ID', `La transferencia ${String(transfer.id || '(sin ID)')} tiene un productId inválido.`, { transferId: transfer.id }));
        continue;
      }
      const name = String(transfer.product || transfer.productName || transfer.name || '').trim();
      const candidates = new Set(transferNameToIds.get(normalizeName(name)) || []);
      if (candidates.size === 1) {
        transfer.productId = [...candidates][0];
        transferLinks++;
      } else {
        issues.push(makeIssue('TRANSFER_ID_AMBIGUOUS', `La transferencia histórica ${String(transfer.id || '(sin ID)')} (“${name || 'sin nombre'}”) no puede vincularse a una ficha única.`, { transferId: transfer.id || null, name, candidateIds: [...candidates] }));
      }
    }

    // Los tickets también deben conservar un productId estable por línea. Los IDs existentes
    // nunca se sustituyen; solo se completa un ID ausente con una correspondencia única.
    // Un ticket que no pueda vincularse sin adivinar detiene toda la migración antes de guardar.
    for (let ti = 0; ti < salesLedger.length; ti++) {
      const transaction = salesLedger[ti];
      if (!transaction || typeof transaction !== 'object' || Array.isArray(transaction) || !Array.isArray(transaction.items)) {
        issues.push(makeIssue('INVALID_SALES_RECORD', `El ticket histórico en la posición ${ti + 1} no tiene una lista items válida.`, { index: ti, transactionId: transaction && transaction.id || null }));
        continue;
      }
      for (let li = 0; li < transaction.items.length; li++) {
        const line = transaction.items[li];
        ticketLines++;
        if (!line || typeof line !== 'object' || Array.isArray(line)) {
          issues.push(makeIssue('INVALID_SALES_LINE', `El ticket ${String(transaction.id || ti + 1)} contiene una línea inválida en la posición ${li + 1}.`, { transactionId: transaction.id || null, lineIndex: li }));
          continue;
        }
        const name = String(line.name || '').trim();
        const existingId = String(line.productId || '').trim();
        if (!name) {
          issues.push(makeIssue('TICKET_PRODUCT_NAME_MISSING', `La línea ${li + 1} del ticket ${String(transaction.id || ti + 1)} no tiene nombre de producto.`, { transactionId: transaction.id || null, lineIndex: li }));
          continue;
        }
        if (existingId) {
          if (!ID_RE.test(existingId)) {
            issues.push(makeIssue('TICKET_PRODUCT_ID_INVALID', `La línea ${li + 1} del ticket ${String(transaction.id || ti + 1)} tiene productId inválido.`, { transactionId: transaction.id || null, lineIndex: li, productId: existingId }));
            continue;
          }
          const catalogRecord = catalogById.get(existingId);
          if (catalogRecord) {
            const names = new Set([catalogRecord.name, ...(Array.isArray(catalogRecord.aliases) ? catalogRecord.aliases : [])].map(normalizeName).filter(Boolean));
            if (!names.has(normalizeName(name))) {
              issues.push(makeIssue('TICKET_PRODUCT_ID_NAME_CONFLICT', `El ID ${existingId} de la línea del ticket ${String(transaction.id || ti + 1)} no corresponde al nombre “${name}” según el catálogo.`, { transactionId: transaction.id || null, lineIndex: li, productId: existingId, name }));
            }
          } else {
            warnings.push({ code: 'HISTORICAL_TICKET_PRODUCT_NOT_IN_CATALOG', message: `El ticket ${String(transaction.id || ti + 1)} conserva el ID ${existingId}, pero no hay ficha de catálogo con ese ID. No se reasignó.`, transactionId: transaction.id || null, productId: existingId });
          }
          continue;
        }
        const candidates = new Set(transferNameToIds.get(normalizeName(name)) || []);
        if (candidates.size === 1) {
          line.productId = [...candidates][0];
          ticketLinks++;
        } else {
          issues.push(makeIssue('TICKET_PRODUCT_ID_AMBIGUOUS', `La línea ${li + 1} del ticket ${String(transaction.id || ti + 1)} (“${name}”) no puede vincularse a una identidad de producto única.`, { transactionId: transaction.id || null, lineIndex: li, name, candidateIds: [...candidates] }));
        }
      }
    }

    if (issues.length) {
      const error = Object.assign(new Error(`Migración de identidad cancelada: ${issues.length} conflicto(s) requieren revisión. No se aplicó ningún cambio a los datos originales.`), {
        code: 'PRODUCT_IDENTITY_REVIEW_REQUIRED',
        issues,
        report: {
          status: 'requires-review',
          scannedInventoryRows: records.length,
          salesLedgerTransactions: salesLedger.length,
          salesLedgerLines: ticketLines,
          productGroups: groups.size,
          existingCatalogRows: Array.isArray(source.productCatalog) ? source.productCatalog.length : 0,
          conflicts: issues.length,
          warnings
        }
      });
      throw error;
    }

    return {
      inventory,
      pointsOfSale,
      productCatalog,
      transfers,
      salesLedger,
      report: {
        status: 'ready',
        scannedInventoryRows: records.length,
        salesLedgerTransactions: salesLedger.length,
        salesLedgerLines: ticketLines,
        productGroups: groups.size,
        catalogRowsBefore: Array.isArray(source.productCatalog) ? source.productCatalog.length : 0,
        catalogRowsAfter: productCatalog.length,
        generatedIds,
        transferLinks,
        ticketLinks,
        warnings
      }
    };
  }

  function analyze(input) {
    let counter = 0;
    try {
      const result = plan(input, () => `DRYRUN_${String(++counter).padStart(8, '0')}`);
      return { ok: true, ...result.report, issues: [] };
    } catch (error) {
      return {
        ok: false,
        status: 'requires-review',
        code: error && error.code || 'PRODUCT_IDENTITY_REVIEW_REQUIRED',
        message: error && error.message || 'No se pudo analizar la migración.',
        issues: Array.isArray(error && error.issues) ? error.issues : [makeIssue('ANALYSIS_FAILED', String(error && error.message || 'Error desconocido'))],
        report: error && error.report || null
      };
    }
  }

  return { normalizeName, plan, analyze };
});
