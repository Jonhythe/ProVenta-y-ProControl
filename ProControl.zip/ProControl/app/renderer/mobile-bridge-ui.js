'use strict';
// Fase única final: intercambio offline, vinculación con alcance POS y conciliación explícita.
(function () {
  const $ = id => document.getElementById(id);
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
  // Perfil PC-first: la interfaz de administración móvil queda como aviso hasta validar una app móvil real.
  // No activar en una actualización futura sin pruebas completas de extremo a extremo.
  const DESKTOP_ONLY_RELEASE = true;
  // Solo las pruebas automatizadas Node pueden ejercitar los controles del panel; Electron no define este override.
  const TEST_MOBILE_UI = typeof module !== 'undefined' && module.exports && process.env.PROCONTROL_TEST_MOBILE_UI === '1';
  const bridge = () => window.PCMobileBridge;
  let latestCode = '';
  let latestCodeMeta = null;
  let selectedPackageId = '';
  let packagesCache = [];
  let devicesCache = [];
  let controlAuth = null;
  let currentAcknowledgement = null;
  function message(text, kind) {
    const el = $('mobile-bridge-status');
    if (!el) return;
    el.textContent = String(text || '');
    el.style.borderColor = kind === 'error' ? '#d9534f' : 'var(--color-accent)';
    el.style.background = kind === 'error' ? 'rgba(217,83,79,.10)' : 'rgba(197,160,89,.08)';
  }
  function fmtNumber(value, digits = 0) {
    return window.ProControlNumberFormat
      ? window.ProControlNumberFormat.formatNumber(value, digits)
      : new Intl.NumberFormat('en-US', { useGrouping:true, maximumFractionDigits:Math.min(2, digits) }).format(Number(value) || 0);
  }
  function fmtDate(value) {
    if (!value) return 'Nunca';
    const d = new Date(Number(value));
    return Number.isFinite(d.getTime()) ? d.toLocaleString() : '—';
  }
  function showError(error) {
    const code = error && error.code ? error.code : '';
    message('La operación no pudo completarse' + (code ? ': ' + code : error && error.message ? ': ' + error.message : '') + '.', 'error');
  }
  async function call(method, input) {
    const api = bridge();
    if (!api || typeof api[method] !== 'function') throw new Error('PCMobileBridge no está disponible. Comprueba que main.js y preload.js pertenecen a la misma versión.');
    const result = await api[method](...(input === undefined ? [] : [input]));
    if (!result || result.ok !== true) {
      const err = new Error(result && (result.code || result.error) || 'BRIDGE_REQUEST_FAILED');
      err.code = result && result.code || 'BRIDGE_REQUEST_FAILED';
      if (result && result.canceled) err.canceled = true;
      throw err;
    }
    return result;
  }
  function posOptions() {
    const select = $('mobile-bridge-pos');
    if (!select) return [];
    const previous = select.value;
    const state = typeof appState !== 'undefined' ? appState : null;
    const pos = state && Array.isArray(state.pointsOfSale) ? state.pointsOfSale : [];
    // El plano de control trabaja con el ID persistido del POS (sin el prefijo visual pos:).
    const rows = pos.map(item => ({ item, id: String(item && item.id || '') })).filter(x => x.item && /^[A-Za-z0-9_-]{8,120}$/.test(x.id));
    select.innerHTML = rows.length ? rows.map(x => `<option value="${esc(x.id)}">${esc(x.item.name)} · ${esc(x.id)}</option>`).join('') : '<option value="">No hay puntos de venta configurados</option>';
    if (previous && rows.some(x => String(x.id) === previous)) select.value = previous;
    else if (rows.length) select.value = String(rows[0].id);
    select.disabled = rows.length === 0;
    return rows;
  }
  function setPackageActions(status) {
    const accepted = status === 'accepted_for_reconciliation';
    const canDecide = status === 'pending_review' || status === 'conflict';
    if ($('mobile-bridge-apply-selected')) $('mobile-bridge-apply-selected').style.display = accepted ? 'inline-flex' : 'none';
    for (const id of ['mobile-bridge-accept-selected','mobile-bridge-conflict-selected','mobile-bridge-reject-selected']) {
      if ($(id)) $(id).style.display = canDecide ? 'inline-flex' : 'none';
    }
  }
  async function refreshStatus() {
    const result = await call('status');
    const local = result.networkListener === false && ['offline-file','not-configured','local-only'].includes(result.transport);
    message(`Puente local, ${local ? 'sin transporte activo por red' : 'estado de transporte no confirmado'} · intercambio por archivo/USB · ${fmtNumber(result.devices||0)} dispositivo(s) habilitado(s) · ${fmtNumber(result.pendingPackages||0)} paquete(s) por revisar. ${result.note || ''}`);
  }
  async function refreshDevices() {
    try {
      const result = await call('listDevices');
      const rows = Array.isArray(result.devices) ? result.devices : [];
      devicesCache = rows;
      syncControlDeviceOptions();
      $('mobile-bridge-devices').innerHTML = rows.length ? rows.map(d => {
        const enabled = d.enabled === true || d.enabled === 1;
        const action = enabled ? 'Revocar' : 'Habilitar';
        const next = enabled ? 'false' : 'true';
        const signing = d.signingConfigured === true || d.signingConfigured === 1;
        return `<tr><td>${esc(d.label)}<div style="font-size:.7rem;color:var(--color-text-muted);word-break:break-all;">${esc(d.deviceId)}</div></td><td>${esc(d.role)}<div style="font-size:.7rem;color:var(--color-text-muted);">POS: ${esc(d.posId || 'sin asignar')}</div></td><td>${enabled ? 'Habilitado' : 'Revocado'}<div style="font-size:.7rem;color:var(--color-text-muted);">Firma: ${signing ? 'configurada' : 'pendiente'}</div></td><td>${esc(fmtDate(d.lastSeenAt))}</td><td><button type="button" class="btn btn-outline" data-device-id="${esc(d.deviceId)}" data-enable="${next}" onclick="MobileBridgeUI.toggleDevice(this.dataset.deviceId,this.dataset.enable==='true')">${action}</button></td></tr>`;
      }).join('') : '<tr><td colspan="5" style="text-align:center;padding:1rem;">No hay dispositivos emparejados todavía.</td></tr>';
    } catch (e) { $('mobile-bridge-devices').innerHTML = `<tr><td colspan="5" style="text-align:center;padding:1rem;">${esc(e.message || 'No se pudieron leer los dispositivos.')}</td></tr>`; showError(e); }
  }
  async function refreshPackages() {
    try {
      const result = await call('listPendingPackages');
      packagesCache = Array.isArray(result.packages) ? result.packages : [];
      $('mobile-bridge-packages').innerHTML = packagesCache.length ? packagesCache.map(p => `<tr><td>${esc(fmtDate(p.receivedAt))}</td><td>${esc(p.type)}</td><td>${esc(p.deviceId)}</td><td style="word-break:break-all;">${esc(p.packageId)}</td><td>${esc(p.status)}</td><td><button type="button" class="btn btn-outline" data-package-id="${esc(p.packageId)}" onclick="MobileBridgeUI.viewPackage(this.dataset.packageId)">Revisar</button></td></tr>`).join('') : '<tr><td colspan="6" style="text-align:center;padding:1rem;">No hay paquetes pendientes de revisión.</td></tr>';
      if (selectedPackageId && !packagesCache.some(p => p.packageId === selectedPackageId)) {
        selectedPackageId = '';
        $('mobile-bridge-package-detail-wrap').style.display = 'none';
      }
      await refreshStatus();
    } catch (e) { $('mobile-bridge-packages').innerHTML = `<tr><td colspan="6" style="text-align:center;padding:1rem;">${esc(e.message || 'No se pudieron leer los paquetes.')}</td></tr>`; showError(e); }
  }
  function ensureControlSection() {
    if ($('mobile-control-plane-section')) return;
    const section = document.createElement('section');
    section.id = 'mobile-control-plane-section';
    section.style.cssText = 'margin:1rem 0;padding:1rem;border:1px solid var(--color-accent);border-radius:10px;background:rgba(0,0,0,.12);';
    section.innerHTML = `
      <h3 style="color:var(--color-accent);margin:.2rem 0 .8rem;">4. Seguridad por punto de venta y turnos</h3>
      <p style="font-size:.82rem;color:var(--color-text-muted);">Estas acciones vuelven a autenticar al Dueño o Administrador usando las cuentas actuales de ProControl. La licencia PCL1 de instalación no se sustituye. No actives CON APP ni emitas permisos operativos hasta completar la integración móvil real y las pruebas de extremo a extremo.</p>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1rem;align-items:start;">
        <div style="border:1px solid var(--color-border);border-radius:8px;padding:.8rem;">
          <h4 style="color:var(--color-accent);margin-top:0;">Licencia de punto de venta</h4>
          <label for="mobile-control-pos">Punto de venta</label>
          <select id="mobile-control-pos" style="width:100%;margin:.35rem 0 .6rem;"></select>
          <label for="mobile-control-license-token">Token PCL1 del punto</label>
          <input id="mobile-control-license-token" type="text" maxlength="4096" autocomplete="off" placeholder="PCL1.…" style="width:100%;margin:.35rem 0 .6rem;">
          <button id="mobile-control-install-license" class="btn btn-outline" type="button" style="width:100%;margin-bottom:.5rem;">Instalar / renovar licencia</button>
          <button id="mobile-control-enable-strict" class="btn btn-primary" type="button" style="width:100%;">Activar control de licencias por POS</button>
          <div id="mobile-control-policy-list" style="margin-top:.8rem;font-size:.8rem;color:var(--color-text-muted);">Pulsa «Actualizar políticas» para consultar licencias y modos.</div>
          <button id="mobile-control-refresh-policy" class="btn btn-outline" type="button" style="width:100%;margin-top:.6rem;">Actualizar políticas</button>
        </div>
        <div style="border:1px solid var(--color-border);border-radius:8px;padding:.8rem;">
          <h4 style="color:var(--color-accent);margin-top:0;">Permiso de turno firmado</h4>
          <label for="mobile-control-device">Dispositivo emparejado</label>
          <select id="mobile-control-device" style="width:100%;margin:.35rem 0 .6rem;"></select>
          <button id="mobile-control-issue-permit" class="btn btn-primary" type="button" style="width:100%;">Autorizar turno y exportar permiso</button>
          <p style="font-size:.78rem;color:var(--color-text-muted);margin:.6rem 0 0;">El permiso lleva firma y alcance por POS/dispositivo. La emisión real, CON APP y cualquier emergencia siguen bloqueados hasta que exista una app móvil probada; la emergencia queda desactivada por defecto y limitada por permiso firmado.</p>
          <div id="mobile-control-permit-list" style="max-height:150px;overflow:auto;margin-top:.7rem;font-size:.78rem;color:var(--color-text-muted);"></div>
        </div>
      </div>
      <div style="border:1px solid var(--color-border);border-radius:8px;padding:.8rem;margin-top:1rem;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:.5rem;flex-wrap:wrap;">
          <h4 style="color:var(--color-accent);margin:.2rem 0;">Cierres móviles pendientes de confirmación</h4>
          <button id="mobile-control-refresh-closures" class="btn btn-outline" type="button">Actualizar cierres</button>
        </div>
        <div id="mobile-control-closure-list" style="max-height:220px;overflow:auto;font-size:.82rem;color:var(--color-text-muted);">No se han consultado cierres pendientes.</div>
      </div>
      <div style="border:1px solid var(--color-border);border-radius:8px;padding:.8rem;margin-top:1rem;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:.5rem;flex-wrap:wrap;">
          <h4 style="color:var(--color-accent);margin:.2rem 0;">Acuses firmados guardados</h4>
          <button id="mobile-control-refresh-acks" class="btn btn-outline" type="button">Actualizar acuses</button>
        </div>
        <div id="mobile-control-ack-history" style="max-height:220px;overflow:auto;font-size:.82rem;color:var(--color-text-muted);">Los acuses se guardan en el almacén local para poder volver a exportarlos.</div>
      </div>`;
    const status = $('mobile-bridge-status');
    if (status && status.parentNode) status.parentNode.insertBefore(section, status.nextSibling);
    const clonePOS = () => {
      const source = $('mobile-bridge-pos'); const target = $('mobile-control-pos');
      if (!source || !target) return;
      const old = target.value;
      const activeValue = source.value || old;
      target.innerHTML = source.innerHTML;
      if (activeValue) target.value = activeValue;
      syncControlDeviceOptions();
    };
    clonePOS();
    if ($('mobile-bridge-pos')) $('mobile-bridge-pos').addEventListener('change', clonePOS);
    $('mobile-control-refresh-policy').addEventListener('click', () => refreshPOSPolicies().catch(showError));
    $('mobile-control-install-license').addEventListener('click', () => installPOSLicense().catch(showError));
    $('mobile-control-enable-strict').addEventListener('click', () => enablePOSLicensing().catch(showError));
    $('mobile-control-issue-permit').addEventListener('click', () => issueShiftPermit().catch(showError));
    $('mobile-control-refresh-closures').addEventListener('click', () => refreshPendingClosures().catch(showError));
    $('mobile-control-refresh-acks').addEventListener('click', () => refreshPackageAcknowledgements().catch(showError));
    $('mobile-control-ack-history').addEventListener('click', event => {
      const button = event.target && event.target.closest ? event.target.closest('button[data-package-ack-id]') : null;
      if (button) api.showAcknowledgement(button.dataset.packageAckId).catch(showError);
    });
    $('mobile-control-closure-list').addEventListener('click', event => {
      const button = event.target && event.target.closest ? event.target.closest('button[data-closure-id]') : null;
      if (button) decideClosure(button.dataset.closureId, button.dataset.decision, button.dataset.packageId).catch(showError);
    });
  }
  function syncControlDeviceOptions() {
    const select = $('mobile-control-device');
    const posSelect = $('mobile-control-pos');
    if (!select || !posSelect) return;
    const posId = posSelect.value;
    const old = select.value;
    const rows = devicesCache.filter(d => {
      if (!(d.enabled === true || d.enabled === 1)) return false;
      // Los dispositivos ProVenta ya están fijados a un único POS al vincularse.
      // Nunca ofrecer un teléfono de otro POS solo porque comparta instalación.
      return !!posId && String(d.posId || '') === String(posId);
    });
    select.innerHTML = rows.length ? rows.map(d => {
      const worker = d.employeeName ? `${esc(d.employeeName)} · ` : '';
      const scope = d.installationId ? ' · Fijado a este POS' : '';
      return `<option value="${esc(d.deviceId)}">${worker}${esc(d.label || d.deviceId)} · ${esc(d.deviceId)}${scope}</option>`;
    }).join('') : '<option value="">No hay dispositivos autorizados disponibles</option>';
    if (old && rows.some(d => String(d.deviceId) === old)) select.value = old;
    select.disabled = rows.length === 0;
  }
  async function getControlAuth() {
    if (controlAuth && controlAuth.expiresAt > Date.now() + 5000) return controlAuth.token;
    if (typeof askInput !== 'function') throw new Error('No está disponible el formulario seguro de reautenticación de ProControl.');
    const answers = await askInput('Confirmar identidad de administrador', [
      { id: 'user', label: 'Usuario (Dueño o Administrador)', type: 'text', placeholder: 'Nombre de usuario' },
      { id: 'password', label: 'Contraseña actual', type: 'password', placeholder: 'Contraseña' }
    ], 'Verificar');
    if (!answers) throw Object.assign(new Error('Operación cancelada.'), { canceled: true });
    const password = String(answers.password || '');
    answers.password = '';
    const api = bridge();
    if (!api || typeof api.authorizeControl !== 'function') throw new Error('La versión de preload no incluye reautenticación segura; actualiza los archivos de la Parte 1 juntos.');
    const result = await api.authorizeControl({ user: String(answers.user || ''), password });
    if (!result || result.ok !== true || !result.token) throw new Error(result && result.code || 'No se pudo verificar la cuenta de administrador.');
    controlAuth = { token: result.token, expiresAt: Number(result.expiresAt) || Date.now() };
    return controlAuth.token;
  }
  async function refreshPOSPolicies() {
    const authToken = await getControlAuth();
    const result = await call('listPOSPolicy', { authToken });
    const rows = Array.isArray(result.policies) ? result.policies : [];
    const target = $('mobile-control-policy-list');
    target.innerHTML = rows.length ? `<div style="font-weight:800;color:var(--color-accent);margin-bottom:.35rem;">Políticas por punto</div>` + rows.map(p => `<div style="padding:.45rem 0;border-bottom:1px solid var(--color-border);"><strong>${esc(p.requestedName || p.posName || p.posId)}</strong> · <span>${esc(p.mode)}</span> · ${p.licenseValid ? '<span style="color:#22c55e;">Licencia válida</span>' : '<span style="color:#ef4444;">Sin licencia POS</span>'}<div style="word-break:break-all;font-size:.72rem;">${esc(p.posId)}${p.licenseCode ? ' · ' + esc(p.licenseCode) : ''}</div><div style="font-size:.75rem;color:var(--color-text-muted);margin-top:.2rem;">${p.mode === 'CON_APP' ? 'Escritorio en solo lectura para este POS.' : 'La operación de escritorio se conserva según los permisos actuales.'} CON APP permanece bloqueado hasta validar la app móvil real.</div>${p.mode !== 'SIN_APP' ? `<button type="button" class="btn btn-outline" style="margin-top:.35rem;" onclick="MobileBridgeUI.setPOSMode('${esc(p.posId)}','SIN_APP')">Restablecer SIN APP</button>` : ''}</div>`).join('') : 'No hay puntos de venta para mostrar.';
    syncControlDeviceOptions();
    return rows;
  }
  async function installPOSLicense() {
    const posId = $('mobile-control-pos').value;
    const token = String($('mobile-control-license-token').value || '').trim();
    if (!posId) throw new Error('Selecciona un punto de venta.');
    if (!token) throw new Error('Pega el token PCL1 de este punto de venta.');
    const authToken = await getControlAuth();
    const result = await call('installPOSLicense', { posId, token, authToken });
    $('mobile-control-license-token').value = '';
    message(`Licencia instalada para el punto ${posId}. ${result.licenseId ? 'ID de licencia: ' + result.licenseId : ''}`);
    await refreshPOSPolicies();
  }
  async function enablePOSLicensing() {
    if (!window.confirm('Esta acción exige una licencia válida para cada punto de venta actual. Si falta alguna, no activará el control estricto. ¿Continuar?')) return;
    const authToken = await getControlAuth();
    const result = await call('enablePOSLicensing', { authToken });
    message(`Control de licencias activado: ${fmtNumber(result.licensedPOSCount)} punto(s) validados.`);
    await refreshPOSPolicies();
  }
  function localDateTimeValue(date) {
    const d = date instanceof Date ? date : new Date(date);
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 16);
  }
  async function issueShiftPermit() {
    const posId = $('mobile-control-pos').value;
    const deviceId = $('mobile-control-device').value;
    const selectedDevice = devicesCache.find(d => String(d.deviceId) === String(deviceId || ''));
    if (!posId || !deviceId) throw new Error('Selecciona un POS licenciado y un teléfono autorizado para la instalación.');
    const authToken = await getControlAuth();
    const permitList = await call('listShiftPermits', { posId, authToken });
    const sequence = Math.max(0, ...(permitList.permits || []).filter(p => p.deviceId === deviceId).map(p => Number(p.sequence) || 0)) + 1;
    const now = new Date();
    const defaults = { start: localDateTimeValue(now), end: localDateTimeValue(new Date(now.getTime() + 8 * 60 * 60 * 1000)) };
    const values = await askInput('Autorizar turno móvil', [
      { id: 'employee', label: 'Nombre del dependiente', placeholder: 'Nombre del dependiente', value: selectedDevice && selectedDevice.employeeName ? selectedDevice.employeeName : '' },
      { id: 'startsAt', label: 'Inicio del turno (hora local)', type: 'text', value: defaults.start },
      { id: 'endsAt', label: 'Fin del turno (hora local)', type: 'text', value: defaults.end }
    ], 'Firmar permiso');
    if (!values) return;
    const startsAt = Date.parse(String(values.startsAt || ''));
    const endsAt = Date.parse(String(values.endsAt || ''));
    const result = await call('issueShiftPermit', { posId, deviceId, employee: values.employee, startsAt, endsAt, sequence, authToken });
    const exported = await call('exportShiftPermit', { permit: result.permit, authToken });
    message(`Permiso de turno firmado y exportado (${exported.fileName}). Teléfono autorizado exclusivamente para el POS ${posId} y este turno. Secuencia ${sequence}; emergencia desactivada.`);
    showQrDocument('P', result.permit, result.permit.permitId);
    await refreshPermits();
  }
  async function refreshPermits() {
    const posId = $('mobile-control-pos').value;
    if (!posId) return;
    const authToken = await getControlAuth();
    const result = await call('listShiftPermits', { posId, authToken });
    const target = $('mobile-control-permit-list');
    target.innerHTML = (result.permits || []).length ? (result.permits || []).slice(0, 15).map(p => `<div style="padding:.25rem 0;border-bottom:1px solid var(--color-border);">${esc(p.employee)} · ${esc(p.status)} · secuencia ${esc(p.sequence)}<div style="font-size:.72rem;word-break:break-all;">${esc(p.permitId)} · ${esc(fmtDate(p.startsAt))} – ${esc(fmtDate(p.endsAt))}</div></div>`).join('') : 'No hay permisos emitidos para este POS.';
  }
  async function refreshPendingClosures() {
    const authToken = await getControlAuth();
    const result = await call('listPendingClosures', { authToken });
    const target = $('mobile-control-closure-list');
    const rows = Array.isArray(result.closures) ? result.closures : [];
    const moneyMinor = value => new Intl.NumberFormat('es-CU', {
      minimumFractionDigits: 2, maximumFractionDigits: 2
    }).format((Number(value) || 0) / 100);
    target.innerHTML = rows.length ? rows.map(c => {
      const payload = c && c.payload && typeof c.payload === 'object' ? c.payload : {};
      const report = payload.closingReport && typeof payload.closingReport === 'object' ? payload.closingReport : {};
      const cash = report.cash && typeof report.cash === 'object' ? report.cash : {};
      const products = Array.isArray(report.products) ? report.products : [];
      const employee = String(report.employee || payload.employee || 'Dependiente');
      const expected = Number(cash.expectedSalesCupMinor) || 0;
      const counted = Number(cash.countedTotalCupMinor) || 0;
      const difference = Number(cash.differenceCupMinor) || 0;
      const differenceLabel = difference > 0 ? 'Sobrante' : difference < 0 ? 'Faltante' : 'Cuadrado';
      const differenceColor = difference === 0 ? 'var(--color-success, #2f9d68)' : difference > 0 ? 'var(--color-accent)' : 'var(--color-danger, #d9534f)';
      const productRows = products.slice(0, 12).map(item => {
        const opening = item.openingQuantityMicros == null ? '—' : Number(item.openingQuantityMicros) / 1000000;
        const received = Number(item.receivedQuantityMicros) / 1000000 || 0;
        const final = item.finalQuantityMicros == null ? '—' : Number(item.finalQuantityMicros) / 1000000;
        const ipv = item.ipvQuantityMicros == null ? '—' : Number(item.ipvQuantityMicros) / 1000000;
        return '<div style="display:grid;grid-template-columns:minmax(0,1fr) auto;gap:.4rem;padding:.35rem 0;border-bottom:1px solid var(--color-border);">' +
          '<span><strong>' + esc(item.name || item.productId || 'Producto') + '</strong><small style="display:block;color:var(--color-text-muted);">Al abrir: ' + esc(opening) + ' · Entradas: ' + esc(received) + ' · Físico: ' + esc(final) + ' ' + esc(item.unit || '') + '</small></span>' +
          '<strong style="white-space:nowrap;">IPV: ' + esc(ipv) + '</strong></div>';
      }).join('');
      const moreProducts = products.length > 12 ? '<p style="font-size:.72rem;color:var(--color-text-muted);">Y ' + (products.length - 12) + ' producto(s) más en el informe completo.</p>' : '';
      const reportJson = esc(JSON.stringify(report, null, 2));
      return `<article style="border:1px solid var(--color-border);border-radius:12px;padding:.8rem;margin:.65rem 0;background:var(--color-card,transparent);">
        <div style="display:flex;justify-content:space-between;gap:.6rem;flex-wrap:wrap;">
          <div><strong style="color:var(--color-accent);">${esc(c.posId || 'Punto de venta')}</strong><div style="font-size:.78rem;color:var(--color-text-muted);">${esc(employee)} · Turno ${esc(c.shiftId || '')}</div><div style="font-size:.72rem;color:var(--color-text-muted);">Recibido: ${esc(fmtDate(c.submittedAt))}</div></div>
          <strong style="color:${differenceColor};">${esc(differenceLabel)}: ${moneyMinor(Math.abs(difference))} CUP</strong>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(125px,1fr));gap:.5rem;margin:.75rem 0;">
          <div><small style="color:var(--color-text-muted);">Ventas esperadas</small><strong style="display:block;">${moneyMinor(expected)} CUP</strong></div>
          <div><small style="color:var(--color-text-muted);">Dinero contado</small><strong style="display:block;">${moneyMinor(counted)} CUP</strong></div>
          <div><small style="color:var(--color-text-muted);">Productos</small><strong style="display:block;">${products.length}</strong></div>
        </div>
        ${productRows ? `<details style="margin:.5rem 0;"><summary style="cursor:pointer;font-weight:700;">Ver IPV resumido</summary><div style="margin-top:.45rem;">${productRows}${moreProducts}</div></details>` : '<p style="font-size:.78rem;color:var(--color-text-muted);">El informe no contiene líneas de inventario.</p>'}
        <details style="margin:.5rem 0;"><summary style="cursor:pointer;font-weight:700;">Ver informe completo y desglose de efectivo</summary><pre style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:320px;overflow:auto;padding:.6rem;border-radius:8px;background:var(--color-panel,rgba(0,0,0,.08));font-size:.7rem;">${reportJson}</pre></details>
        <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.7rem;">
          <button type="button" class="btn btn-outline" data-closure-id="${esc(c.closureId)}" data-package-id="${esc(c.packageId)}" data-decision="confirmed">Confirmar solicitud</button>
          <button type="button" class="btn btn-outline" data-closure-id="${esc(c.closureId)}" data-package-id="${esc(c.packageId)}" data-decision="rejected">Rechazar solicitud</button>
        </div>
      </article>`;
    }).join('') + '<p style="font-size:.76rem;">Confirmar aprueba la solicitud del móvil y completa el permiso del turno. No altera automáticamente el efectivo, el inventario ni el cierre contable del escritorio: esa conciliación sigue siendo una operación independiente.</p>' : 'No hay cierres móviles pendientes de confirmación.';
  }
  async function refreshPackageAcknowledgements() {
    const authToken = await getControlAuth();
    const result = await call('listPackageAcknowledgements', { limit: 50, authToken });
    const target = $('mobile-control-ack-history');
    const rows = Array.isArray(result.acknowledgements) ? result.acknowledgements : [];
    target.innerHTML = rows.length ? rows.map(row => `<div style="display:flex;gap:.6rem;align-items:center;justify-content:space-between;flex-wrap:wrap;padding:.4rem 0;border-bottom:1px solid var(--color-border);"><span><strong>${esc(row.result)}</strong> · ${esc(fmtDate(row.createdAt))}<div style="font-size:.72rem;word-break:break-all;">${esc(row.packageId)}</div></span><button type="button" class="btn btn-outline" data-package-ack-id="${esc(row.packageId)}">Mostrar QR / exportar</button></div>`).join('') : 'Todavía no hay acuses firmados guardados.';
  }
  async function decideClosure(closureId, decision, packageId) {
    if (!['confirmed', 'rejected'].includes(decision)) throw new Error('Decisión de cierre no válida.');
    if (!/^[A-Za-z0-9_-]{8,100}$/.test(String(packageId || ''))) throw new Error('No se pudo identificar el paquete móvil para devolver el acuse.');
    const verb = decision === 'confirmed' ? 'confirmar' : 'rechazar';
    if (!window.confirm(`¿Deseas ${verb} esta solicitud de cierre? Esta decisión queda en la auditoría y no cambia el efectivo ni el conteo del escritorio.`)) return;
    const authToken = await getControlAuth();
    await call('decidePendingClosure', { closureId, decision, note: '', authToken });
    const acknowledgement = await call('createPackageAcknowledgement', { packageId, authToken });
    if (!acknowledgement || !acknowledgement.acknowledgement) {
      throw new Error('La decisión quedó registrada, pero ProControl no pudo generar el acuse firmado. Usa el historial de acuses para reintentarlo.');
    }
    showQrDocument('A', acknowledgement.acknowledgement, packageId);
    message(`Solicitud ${decision === 'confirmed' ? 'confirmada' : 'rechazada'}. Acuse firmado generado: guárdalo como .pcack y entrégalo al móvil. La caja e inventario del escritorio no se alteraron.`);
    await refreshPendingClosures();
    if ($('mobile-control-ack-history')) await refreshPackageAcknowledgements().catch(showError);
  }

  function buildDesktopSnapshot() {
    if (typeof appState === 'undefined' || typeof Inventory === 'undefined') throw new Error('El estado de ProControl todavía no está disponible.');
    const safeItem = item => {
      const productId = Inventory._productIdForItem(item, appState) || Inventory.productIdForName(item && item.name, appState) || item && item.productId;
      if (!productId || !item || !item.name) return null;
      let unitsPerBox = null;
      try { unitsPerBox = Inventory.unitsPerBoxForPOSItem(item, appState); } catch (_) {}
      return { productId: String(productId), name: String(item.name), unit: String(item.unit || 'u'), qty: Math.max(0, Number(item.qty) || 0), unitsPerBox: Number.isSafeInteger(Number(unitsPerBox)) && Number(unitsPerBox) > 0 ? Number(unitsPerBox) : null, sale: Math.max(0, Number(item.sale) || 0), saleTransf: Math.max(0, Number(item.saleTransf) || 0), saleUSD: Math.max(0, Number(item.saleUSD) || 0), family: String(item.family || '') };
    };
    const warehouse = (Array.isArray(appState.inventory) ? appState.inventory : []).map(safeItem).filter(Boolean);
    const pointStores = (Array.isArray(appState.pointsOfSale) ? appState.pointsOfSale : []).map(pos => ({
      posId: Inventory.posReference(pos), name: String(pos.name || ''), salesTrackingEnabled: !!pos.salesTrackingEnabled,
      inventory: (Array.isArray(pos.inventory) ? pos.inventory : []).map(safeItem).filter(Boolean)
    })).filter(pos => pos.posId);
    const products = (Array.isArray(appState.productCatalog) ? appState.productCatalog : []).map(p => p && p.id ? ({ id: String(p.id), name: String(p.name || ''), unit: String(p.unit || 'u'), unitsPerBox: p.unitsPerBox == null ? null : Number(p.unitsPerBox), family: String(p.family || '') }) : null).filter(Boolean);
    return { schemaVersion: 1, generatedAt: new Date().toISOString(), application: 'ProControl', businessName: String(appState.businessData && appState.businessData.name || ''), dollarRate: Math.max(0, Number(appState.dollarRate) || 0), inventory: warehouse, productCatalog: products, pointsOfSale: pointStores };
  }
  function showQrDocument(kind, documentObject, reference) {
    const wrap = $('mobile-bridge-qr-wrap');
    if (!wrap) throw new Error('QR_PANEL_NOT_AVAILABLE');
    const qr = window.ProControlLocalQR;
    if (!qr || typeof qr.splitDocument !== 'function') throw new Error('QR_LOCAL_ENCODER_UNAVAILABLE');
    const text = JSON.stringify(documentObject);
    const pieces = qr.splitDocument(kind, text, reference);
    currentAcknowledgement = kind === 'A' ? documentObject : null;
    const title = kind === 'A' ? 'Acuse firmado de recepción' : 'Permiso de turno firmado';
    wrap.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;gap:.7rem;flex-wrap:wrap;margin-bottom:.5rem;"><strong style="color:var(--color-accent);">${title}</strong><button type="button" class="btn btn-outline" onclick="MobileBridgeUI.closeQr()">Cerrar QR</button></div><p style="font-size:.78rem;color:var(--color-text-muted);">${pieces.length} fragmento(s) QR. Escanéalos todos en orden; el receptor debe reconstruir el documento completo y verificar la firma Ed25519 antes de aceptar el acuse o permiso. No borres datos del móvil solo por leer un QR.</p><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:.65rem;max-height:390px;overflow:auto;padding:.4rem;border:1px solid var(--color-border);border-radius:8px;">${pieces.map(piece => `<figure style="margin:0;padding:.45rem;text-align:center;background:#fff;color:#111;border-radius:6px;"><img src="${esc(piece.dataUrl)}" alt="QR ${piece.index} de ${piece.total}" width="135" height="135" style="width:135px;height:135px;max-width:100%;image-rendering:pixelated;"><figcaption style="font-size:.72rem;font-weight:800;margin-top:.25rem;">${piece.index} / ${piece.total}</figcaption></figure>`).join('')}</div>${kind === 'A' ? '<div style="display:flex;justify-content:flex-end;gap:.5rem;margin-top:.7rem;"><button type="button" class="btn btn-primary" onclick="MobileBridgeUI.saveCurrentAcknowledgement()">Guardar acuse .pcack</button></div>' : ''}`;
    wrap.style.display = 'block';
    wrap.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
  const api = {
    async open() {
      if (typeof Auth === 'undefined' || !Auth.requireRole(['Dueño', 'Administrador'], 'Solo el Dueño o un Administrador puede gestionar la integración móvil.')) return;
      const overlay = $('mobile-bridge-overlay');
      if (!overlay) return;
      if (DESKTOP_ONLY_RELEASE && !TEST_MOBILE_UI) {
        const panel = overlay.querySelector('section');
        if (!panel) return;
        for (const child of Array.from(panel.children)) {
          if (!child.classList.contains('modal-close') && child.id !== 'mobile-bridge-desktop-notice') child.style.display = 'none';
        }
        let notice = $('mobile-bridge-desktop-notice');
        if (!notice) {
          notice = document.createElement('div');
          notice.id = 'mobile-bridge-desktop-notice';
          notice.style.cssText = 'text-align:center;padding:clamp(1.5rem,4vw,3rem) .8rem;color:var(--color-text-surface,#eee);';
          notice.innerHTML = '<div style="font-size:2.4rem;margin-bottom:.7rem;">📱</div><h2 style="color:var(--color-accent);margin:.2rem 0 1rem;">Aplicación móvil — próxima actualización</h2><p style="max-width:680px;margin:0 auto 1rem;line-height:1.7;">ProControl para PC funciona de forma independiente en modo SIN APP. La aplicación móvil se entregará en una actualización posterior, después de completar y probar el intercambio de datos, los permisos y la recuperación.</p><p style="max-width:680px;margin:0 auto 1.5rem;color:var(--color-text-muted);line-height:1.7;">Por seguridad, el emparejamiento, los permisos operativos y el modo CON APP permanecen desactivados. Esto no afecta al uso normal de ProControl en esta computadora.</p><button type="button" class="btn btn-outline" onclick="MobileBridgeUI.close()">Volver a ProControl</button>';
          panel.appendChild(notice);
        }
        notice.style.display = 'block';
        overlay.style.display = 'flex';
        return;
      }
      posOptions();
      ensureControlSection();
      overlay.style.display = 'flex'; latestCode = ''; latestCodeMeta = null;
      $('mobile-bridge-code-card').style.display = 'none'; selectedPackageId = '';
      $('mobile-bridge-package-detail-wrap').style.display = 'none'; setPackageActions('');
      message('Consultando estado local…');
      await Promise.allSettled([refreshStatus(), refreshDevices(), refreshPackages()]);
    },
    close() { const overlay = $('mobile-bridge-overlay'); if (overlay) overlay.style.display = 'none'; controlAuth = null; currentAcknowledgement = null; const qr = $('mobile-bridge-qr-wrap'); if (qr) { qr.style.display = 'none'; qr.innerHTML = ''; } },
    closeQr() { const qr = $('mobile-bridge-qr-wrap'); if (qr) { qr.style.display = 'none'; qr.innerHTML = ''; } currentAcknowledgement = null; },
    async showAcknowledgement(packageId) {
      const authToken = await getControlAuth();
      const result = await call('createPackageAcknowledgement', { packageId, authToken });
      showQrDocument('A', result.acknowledgement, packageId);
      if ($('mobile-control-ack-history')) await refreshPackageAcknowledgements();
      return result;
    },
    async createGoodsDispatchManifest(input) {
      const authToken = await getControlAuth();
      return await call('createGoodsDispatchManifest', { ...(input || {}), authToken });
    },
    async confirmGoodsDispatch(input) {
      const authToken = await getControlAuth();
      return await call('confirmGoodsDispatch', { ...(input || {}), authToken });
    },
    async cancelGoodsDispatchManifest(input) {
      const authToken = await getControlAuth();
      return await call('cancelGoodsDispatchManifest', { ...(input || {}), authToken });
    },
    async saveCurrentAcknowledgement() {
      if (!currentAcknowledgement) throw new Error('ACK_NOT_AVAILABLE');
      try { const authToken = await getControlAuth(); const saved = await call('savePackageAcknowledgement', { acknowledgement: currentAcknowledgement, authToken }); message(`Acuse firmado guardado como ${saved.fileName}. Conserva también los datos originales hasta que el móvil verifique firma, paquete y resultado.`); }
      catch (e) { if (!e.canceled) showError(e); }
    },
    async setPOSMode(posId, mode) {
      if (mode !== 'SIN_APP') throw new Error('CON_APP sigue bloqueado hasta que exista la app móvil real y pasen las pruebas de extremo a extremo.');
      if (!window.confirm(`¿Registrar que el punto ${posId} permanece en modo SIN APP? No se borrarán sus históricos.`)) return;
      const authToken = await getControlAuth(); const result = await call('setPOSMode', { posId, mode, authToken });
      message(`Modo SIN APP registrado para ${posId}.`); await refreshPOSPolicies();
      return result;
    },
    async createCode() {
      latestCode = ''; latestCodeMeta = null;
      const card = $('mobile-bridge-code-card');
      if (card) card.style.display = 'none';
      message('La vinculación antigua por POS está deshabilitada. Utiliza «Generar código ProVenta» en la barra izquierda de Punto de Venta; solo el Dueño puede emitir autorizaciones por instalación.', 'error');
      return { ok: false, code: 'LEGACY_POS_PAIRING_DISABLED' };
    },
    async copyCode() {
      if (!latestCode) return;
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(latestCode);
        else { const input = document.createElement('textarea'); input.value = latestCode; input.setAttribute('readonly', ''); input.style.position = 'fixed'; input.style.opacity = '0'; document.body.appendChild(input); input.select(); const ok = document.execCommand('copy'); input.remove(); if (!ok) throw new Error('COPY_FAILED'); }
        message('Código copiado al portapapeles. Trátalo como credencial temporal.');
      } catch (e) { message('No se pudo copiar automáticamente. Selecciona el código y cópialo manualmente.', 'error'); }
    },
    async exportPairingDescriptor() {
      try {
        if (!latestCode || !latestCodeMeta) throw new Error('Primero genera un código temporal.');
        const authToken = await getControlAuth();
        const result = await call('exportPairingDescriptor', { code: latestCode, role: latestCodeMeta.role, posId: latestCodeMeta.posId, expiresAt: latestCodeMeta.expiresAt, authToken });
        message(`Ficha de vinculación guardada como ${result.fileName}. Contiene el código temporal: no la compartas por canales públicos.`);
      } catch (e) { if (!e.canceled) showError(e); }
    },
    async exportDesktopSnapshot() {
      try {
        const payload = buildDesktopSnapshot();
        const authToken = await getControlAuth();
        const result = await call('exportDesktopPackage', { type: 'inventory_snapshot', payload, authToken });
        message(`Paquete de catálogo y existencias guardado (${result.fileName}, ${fmtNumber(result.bytes)} bytes). Cópialo a la memoria USB para transferirlo al celular cuando exista la app.`);
      } catch (e) { if (!e.canceled) showError(e); }
    },
    async exportDesktopFragments() {
      try {
        const payload = buildDesktopSnapshot();
        const authToken = await getControlAuth();
        const result = await call('exportDesktopFragments', { type: 'inventory_snapshot', payload, authToken });
        message(`Manifiesto ${result.fileName} guardado con ${fmtNumber(result.fragmentCount)} fragmento(s). Copia el manifiesto y todos los .pcfrag juntos a la misma carpeta de la memoria USB.`);
      } catch (e) { if (!e.canceled) showError(e); }
    },
    async importPackageFile() {
      try {
        const authToken = await getControlAuth();
        const result = await call('importFile', { authToken });
        message(`Paquete ${result.packageId || '(sin ID)'} importado y verificado${result.fragmentCount ? ` desde ${fmtNumber(result.fragmentCount)} fragmentos` : ''}. Sigue pendiente de revisión; aún no se ha cambiado inventario ni cierre.`);
        await refreshPackages();
      } catch (e) { if (!e.canceled) showError(e); }
    },
    async refreshDevices() { posOptions(); await refreshDevices(); await refreshStatus().catch(showError); },
    async toggleDevice(deviceId, enabled) {
      if (!window.confirm(`${enabled ? '¿Habilitar' : 'Revocar'} el acceso del dispositivo ${deviceId}?`)) return;
      try { const authToken = await getControlAuth(); await call('setDeviceEnabled', { deviceId, enabled, authToken }); message(`Acceso del dispositivo ${enabled ? 'habilitado' : 'revocado'}.`); await refreshDevices(); await refreshStatus(); }
      catch (e) { showError(e); }
    },
    async refreshPackages() { await refreshPackages(); },
    async viewPackage(packageId) {
      try {
        const result = await call('getPackage', packageId);
        if (!result.package) throw new Error('PACKAGE_NOT_FOUND');
        selectedPackageId = packageId;
        let detail = JSON.stringify(result.package, null, 2);
        if (result.package.status === 'accepted_for_reconciliation' && window.MobileReconcile) {
          try {
            const preview = window.MobileReconcile.preview(result.package, { appState, DataStore, Inventory, SalesLedgerOps, ProductUnits });
            detail += `\n\nPREVISUALIZACIÓN DE CONCILIACIÓN\n${JSON.stringify(preview, null, 2)}`;
          } catch (e) { detail += `\n\nVALIDACIÓN FALLIDA\n${e && e.message || 'Paquete incompatible'}`; }
        }
        $('mobile-bridge-package-detail').textContent = detail;
        $('mobile-bridge-package-detail-wrap').style.display = 'block';
        setPackageActions(result.package.status);
      } catch (e) { showError(e); }
    },
    async decideSelected(decision) {
      if (!selectedPackageId) { message('Selecciona un paquete antes de decidir.', 'error'); return; }
      const explanations = {
        accepted_for_reconciliation: 'Aceptar solo autoriza pasar a la vista de conciliación; todavía no aplica el paquete. ¿Confirmas?',
        conflict: '¿Marcar este paquete como conflicto pendiente de resolver?',
        rejected: '¿Rechazar definitivamente este paquete? Esta decisión no se podrá sobrescribir.'
      };
      if (!window.confirm(explanations[decision] || '¿Confirmar decisión?')) return;
      const packageId = selectedPackageId;
      const note = window.prompt('Nota de auditoría (opcional):', '') || '';
      try {
        const authToken = await getControlAuth();
        await call('decidePackage', { packageId, decision, note, authToken });
        if (decision === 'rejected') {
          const ack = await call('createPackageAcknowledgement', { packageId, authToken });
          message('Paquete rechazado de forma auditada. Generando acuse firmado para devolverlo por USB o QR.');
          showQrDocument('A', ack.acknowledgement, packageId);
          await refreshPackageAcknowledgements().catch(() => {});
        } else {
          message(decision === 'accepted_for_reconciliation' ? 'Paquete aceptado para validación. Aún no se ha aplicado.' : 'Decisión guardada; el conflicto no es un acuse de aplicación.');
        }
        await refreshPackages();
        if (decision === 'accepted_for_reconciliation') await api.viewPackage(packageId);
      } catch (e) { showError(e); }
    },
    async applySelected() {
      if (typeof Auth === 'undefined' || !Auth.requireRole(['Dueño', 'Administrador'], 'Solo el Dueño o un Administrador puede conciliar paquetes móviles.')) return;
      if (!selectedPackageId) { message('Selecciona un paquete antes de conciliar.', 'error'); return; }
      const packageId = selectedPackageId;
      let applyStarted = false;
      let authToken = null;
      try {
        const loaded = await call('getPackage', packageId);
        if (!loaded.package || loaded.package.status !== 'accepted_for_reconciliation') throw new Error('PACKAGE_NOT_ACCEPTED');
        if (!window.MobileReconcile) throw new Error('No se ha cargado el reconciliador de paquetes.');
        authToken = await getControlAuth();
        const begun = await call('beginPackageApply', { packageId, authToken });
        if (!begun || begun.ok !== true) throw new Error(begun && begun.code || 'PACKAGE_APPLY_BEGIN_FAILED');
        applyStarted = !begun.duplicate;
        // El recibo comercial se guarda junto con los movimientos del almacén comercial.
        // Si el proceso cae antes del ACK SQLite, el siguiente intento lee el recibo y no duplica stock.
        const result = window.MobileReconcile.apply(loaded.package, { appState, DataStore, Inventory, SalesLedgerOps, ProductUnits });
        const marked = await call('markPackageApplied', { packageId, result: { type: result.type, payloadHash: loaded.package.payloadHash, newOperations: result.newOperations, changedStock: result.changedStock, message: result.message }, authToken });
        if (!marked || marked.ok !== true) throw new Error(marked && marked.code || 'PACKAGE_APPLY_FINALIZE_FAILED');
        // Actualiza el informe si está abierto; al navegar a Estadísticas también se leerá el ledger actualizado.
        if ((result.type === 'sale_batch' || result.type === 'return') &&
            window.SoldProductsUI && typeof window.SoldProductsUI.refresh === 'function') {
          window.SoldProductsUI.refresh();
        }
        selectedPackageId = '';
        $('mobile-bridge-package-detail-wrap').style.display = 'none';
        message(`Conciliación completada: ${result.message || result.type}. El paquete quedó marcado como conciliado${marked.duplicate || result.recovered ? ' (recuperación idempotente)' : ''}.`);
        try {
          const ack = await call('createPackageAcknowledgement', { packageId, authToken });
          showQrDocument('A', ack.acknowledgement, packageId);
          await refreshPackageAcknowledgements().catch(() => {});
        } catch (ackError) {
          message(`El paquete ya está conciliado, pero no se pudo generar su acuse: ${ackError && ackError.code || ackError.message || 'ACK_CREATE_FAILED'}. No repitas la conciliación; consulta el historial local.`, 'error');
        }
        await refreshPackages();
      } catch (e) {
        if (applyStarted && authToken) {
          try { await call('failPackageApply', { packageId, errorCode: e && e.code || 'RECONCILIATION_FAILED', authToken }); } catch (_) { /* Permanece en estado recuperable para el siguiente intento. */ }
        }
        showError(e);
        message(`No se confirmó la conciliación: ${e && e.message || 'error de conciliación'}. El reintento verifica el recibo durable antes de volver a mover stock.`, 'error');
      }
    }
  };
  window.MobileBridgeUI = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = { esc, fmtDate, buildDesktopSnapshot };
})();
