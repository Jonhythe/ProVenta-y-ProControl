'use strict';

(function (global) {
const cryptoApi = global.crypto;

const Security = {
  PBKDF2_ITERATIONS: 600000,
  DUMMY_RECORD: 'pbkdf2$600000$00112233445566778899aabbccddeeff$' + '0'.repeat(64),

  isAvailable() {
    if (window.crypto && window.crypto.subtle) return true;
    alert('La aplicación no dispone de criptografía segura en este entorno.');
    return false;
  },

  _toHex(bytes) {
    return Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
  },

  _fromHex(hex) {
    if (typeof hex !== 'string' || hex.length === 0 || hex.length % 2 !== 0 || !/^[0-9a-f]+$/i.test(hex)) return null;
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
    return bytes;
  },

  _safeEqual(actual, expected) {
    if (typeof actual !== 'string' || typeof expected !== 'string' || actual.length !== expected.length) return false;
    let difference = 0;
    for (let i = 0; i < actual.length; i++) difference |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
    return difference === 0;
  },

  async _derive(password, salt, iterations) {
    const keyMaterial = await cryptoApi.subtle.importKey(
      'raw',
      new TextEncoder().encode(password),
      'PBKDF2',
      false,
      ['deriveBits']
    );
    const bits = await cryptoApi.subtle.deriveBits(
      { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
      keyMaterial,
      256
    );
    return new Uint8Array(bits);
  },

  async hashPassword(password) {
    const digest = await cryptoApi.subtle.digest('SHA-256', new TextEncoder().encode(password));
    return this._toHex(new Uint8Array(digest));
  },

  async createPasswordRecord(password) {
    const salt = cryptoApi.getRandomValues(new Uint8Array(16));
    const derived = await this._derive(password, salt, this.PBKDF2_ITERATIONS);
    return `pbkdf2$${this.PBKDF2_ITERATIONS}$${this._toHex(salt)}$${this._toHex(derived)}`;
  },

  async verifyPassword(password, stored) {
    const fail = { ok: false, needsUpgrade: false };
    if (typeof password !== 'string' || typeof stored !== 'string' || !stored || stored.length > 128) return fail;

    try {
      if (stored.startsWith('pbkdf2$')) {
        const parts = stored.split('$');
        if (parts.length !== 4 || !/^\d+$/.test(parts[1])) return fail;
        const iterations = Number(parts[1]);
        const salt = this._fromHex(parts[2]);
        if (!Number.isSafeInteger(iterations) || iterations < 1 || iterations > 1000000 ||
            !salt || salt.length !== 16 || !/^[0-9a-f]{64}$/i.test(parts[3])) return fail;
        const derived = this._toHex(await this._derive(password, salt, iterations));
        const ok = this._safeEqual(derived, parts[3].toLowerCase());
        return { ok, needsUpgrade: ok && iterations < this.PBKDF2_ITERATIONS };
      }

      if (!/^[0-9a-f]{64}$/i.test(stored)) return fail;
      const legacy = await this.hashPassword(password);
      const ok = this._safeEqual(legacy, stored.toLowerCase());
      return { ok, needsUpgrade: ok };
    } catch {
      return fail;
    }
  },

  obfuscate(data) {
    const salt = 'PROCONTROL_SECRET_2026';
    const jsonString = JSON.stringify(data);
    const encoded = btoa(unescape(encodeURIComponent(jsonString)));
    return btoa(`${salt}:${encoded}`);
  },

  tryDeobfuscate(cipherText) {
    try {
      if (typeof cipherText !== 'string' || !cipherText) return { ok: false, value: null };
      const decoded = atob(cipherText);
      const separator = decoded.indexOf(':');
      if (separator < 0 || decoded.slice(0, separator) !== 'PROCONTROL_SECRET_2026') {
        return { ok: false, value: null };
      }
      const encoded = decoded.slice(separator + 1);
      if (!encoded) return { ok: false, value: null };
      return { ok: true, value: JSON.parse(decodeURIComponent(escape(atob(encoded)))) };
    } catch (error) {
      console.error('Error al descifrar datos:', error);
      return { ok: false, value: null };
    }
  },

  deobfuscate(cipherText) {
    const result = this.tryDeobfuscate(cipherText);
    return result.ok ? result.value : null;
  }
};

if (global.window) global.window.ProControlSecurity = Security;
if (typeof module !== 'undefined' && module.exports) module.exports = Security;
})(globalThis);
