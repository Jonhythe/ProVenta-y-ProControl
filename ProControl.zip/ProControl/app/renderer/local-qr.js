'use strict';
// QR Model 2 local generator. ProVenta authorization uses a single PVLA2 symbol;
// inventory/dispatch may continue using their separate multi-symbol transport.
(function (root) {
  const PREFIX = 'PVLA2:';
  const MAX_AUTH_TOKEN_LENGTH = 4006;
  const MAX_FRAGMENT_BYTES = 78;
  const CHUNK_BYTES = 40;
  const OPENING_CHUNK_BYTES = 1024;
  const MAX_OPENING_QR_BYTES = 96 * 1024;
  const MAX_OPENING_FRAMES = 96;
  const MAX_OPENING_FRAME_BYTES = 1500;
  const UTF8 = value => new TextEncoder().encode(String(value));
  const ALPHANUMERIC = /^[0-9A-Z $%*+\-./:]+$/;

  function engine() {
    const value = root.ProControlQrEngine;
    if (!value || typeof value.QRCode !== 'function' || !value.ErrorCorrectionLevel) {
      throw Object.assign(new Error('No se cargó el motor local de códigos QR.'), { code: 'QR_ENGINE_UNAVAILABLE' });
    }
    return value;
  }

  function validateActivationCode(value) {
    const token = String(value == null ? '' : value).trim().toUpperCase();
    if (!token.startsWith(PREFIX)) {
      throw Object.assign(new Error('El QR solo puede generarse con la autorización PVLA2 completa.'), { code: 'PVLA2_REQUIRED' });
    }
    const payload = token.slice(PREFIX.length);
    if (payload.length < 40 || token.length > MAX_AUTH_TOKEN_LENGTH || !/^[0-9ABCDEFGHJKMNPQRSTVWXYZ]+$/.test(payload)) {
      throw Object.assign(new Error('La autorización PVLA2 está incompleta o contiene caracteres no permitidos.'), { code: 'PVLA2_FORMAT_INVALID' });
    }
    return token;
  }

  function makeMatrix(value, level, forceAlpha) {
    const text = String(value);
    const { QRCode, ErrorCorrectionLevel } = engine();
    const qr = new QRCode(0, level || ErrorCorrectionLevel.M);
    const alphanumeric = forceAlpha === true || (forceAlpha !== false && ALPHANUMERIC.test(text));
    qr.addData(text, alphanumeric ? 'Alphanumeric' : undefined);
    qr.make();
    const size = qr.getModuleCount();
    return Array.from({ length: size }, (_, row) =>
      Array.from({ length: size }, (_, col) => qr.isDark(row, col))
    );
  }

  function matrixToSvg(matrix, moduleScale) {
    const quietZone = 4;
    const modules = matrix.length;
    const side = modules + quietZone * 2;
    const paths = [];
    for (let y = 0; y < modules; y++) {
      for (let x = 0; x < modules; x++) {
        if (matrix[y][x]) paths.push(`M${x + quietZone} ${y + quietZone}h1v1h-1z`);
      }
    }
    const scale = Math.max(3, Math.min(8, Number(moduleScale) || 5));
    const pixels = side * scale;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${pixels}" height="${pixels}" viewBox="0 0 ${side} ${side}" shape-rendering="crispEdges"><rect width="${side}" height="${side}" fill="#fff"/><path d="${paths.join('')}" fill="#000"/></svg>`;
    return { svg, modules, pixels };
  }

  function toSvg(value, moduleScale) {
    const text = String(value == null ? '' : value).trim();
    if (text.startsWith(PREFIX)) validateActivationCode(text);
    const maximum = text.startsWith(PREFIX) ? MAX_AUTH_TOKEN_LENGTH : 2800;
    if (!text || UTF8(text).length > maximum) {
      throw Object.assign(new Error('El contenido supera la capacidad de un único QR estándar.'), { code: 'QR_SINGLE_CAPACITY_EXCEEDED' });
    }
    return matrixToSvg(makeMatrix(text, engine().ErrorCorrectionLevel.M, text.startsWith(PREFIX)), moduleScale).svg;
  }

  function toDataUrl(value, moduleScale) {
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(toSvg(value, moduleScale));
  }

  function getInfo(value, moduleScale) {
    const token = validateActivationCode(value);
    const matrix = makeMatrix(token, engine().ErrorCorrectionLevel.M, true);
    const rendered = matrixToSvg(matrix, moduleScale);
    return {
      svg: rendered.svg,
      version: (rendered.modules - 17) / 4,
      modules: rendered.modules,
      pixels: rendered.pixels,
      mode: 'alphanumeric',
      errorCorrection: 'M',
      payloadBytes: UTF8(token).length
    };
  }

  function base64Url(bytes) {
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    const encoded = typeof btoa === 'function' ? btoa(binary) : Buffer.from(bytes).toString('base64');
    return encoded.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
  }

  function splitDocument(kind, documentText, reference) {
    if (!['P', 'A', 'T'].includes(String(kind))) throw new Error('QR_KIND_INVALID');
    const bytes = UTF8(documentText);
    if (!bytes.length || bytes.length > 8192) throw Object.assign(new Error('QR_DOCUMENT_SIZE_INVALID'), { code: 'QR_DOCUMENT_SIZE_INVALID' });
    const token = String(reference || '').replace(/[^A-Za-z0-9]/g, '').slice(0, 8).padEnd(8, '0');
    const count = Math.ceil(bytes.length / CHUNK_BYTES);
    if (count > 99) throw Object.assign(new Error('QR_TOO_MANY_SEGMENTS'), { code: 'QR_TOO_MANY_SEGMENTS' });
    const pieces = [];
    for (let i = 0; i < count; i++) {
      const encoded = base64Url(bytes.slice(i * CHUNK_BYTES, Math.min(bytes.length, (i + 1) * CHUNK_BYTES)));
      const index = String(i + 1).padStart(2, '0');
      const total = String(count).padStart(2, '0');
      const payload = `PCQ1|${kind}|${token}|${index}/${total}|${encoded}`;
      if (UTF8(payload).length > MAX_FRAGMENT_BYTES) throw new Error('QR_INTERNAL_FRAGMENT_TOO_LARGE');
      const matrix = makeMatrix(payload, engine().ErrorCorrectionLevel.M, false);
      const rendered = matrixToSvg(matrix, 5);
      pieces.push({ index: i + 1, total: count, payload, svg: rendered.svg,
        dataUrl: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(rendered.svg) });
    }
    return pieces;
  }

  function splitOpeningBundle(documentText) {
    let document;
    try { document = JSON.parse(String(documentText)); } catch (_) {
      throw Object.assign(new Error('El paquete de apertura no es JSON válido.'), { code: 'OPENING_BUNDLE_JSON_INVALID' });
    }
    if (!document || document.format !== 'procontrol.shift-opening-bundle' || document.version !== 1 ||
        typeof document.bundleId !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(document.bundleId)) {
      throw Object.assign(new Error('El documento no es un paquete de apertura compatible.'), { code: 'OPENING_BUNDLE_FORMAT_INVALID' });
    }
    const bytes = UTF8(documentText);
    if (!bytes.length || bytes.length > MAX_OPENING_QR_BYTES) {
      throw Object.assign(new Error('El paquete de apertura supera el límite de QR de 96 KiB; no se truncó el documento.'), { code: 'OPENING_QR_SIZE_EXCEEDED' });
    }
    const bundleId = document.bundleId.replace(/-/g, '').toUpperCase();
    const count = Math.ceil(bytes.length / OPENING_CHUNK_BYTES);
    if (count > MAX_OPENING_FRAMES) {
      throw Object.assign(new Error('El paquete requiere más de 96 cuadros QR.'), { code: 'OPENING_QR_FRAME_LIMIT_EXCEEDED' });
    }
    const pieces = [];
    for (let i = 0; i < count; i++) {
      const encoded = base64Url(bytes.slice(i * OPENING_CHUNK_BYTES, Math.min(bytes.length, (i + 1) * OPENING_CHUNK_BYTES)));
      const index = String(i + 1).padStart(3, '0');
      const total = String(count).padStart(3, '0');
      const payload = `PCO2|B|${bundleId}|${index}/${total}|${encoded}`;
      if (UTF8(payload).length > MAX_OPENING_FRAME_BYTES) {
        throw Object.assign(new Error('Un cuadro QR supera el límite seguro del transporte de apertura.'), { code: 'OPENING_QR_FRAME_SIZE_INVALID' });
      }
      const matrix = makeMatrix(payload, engine().ErrorCorrectionLevel.M, false);
      const rendered = matrixToSvg(matrix, 5);
      pieces.push({
        index: i + 1,
        total: count,
        payload,
        svg: rendered.svg,
        dataUrl: 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(rendered.svg)
      });
    }
    return pieces;
  }

  root.ProControlLocalQR = {
    validateActivationCode,
    encodeMatrix: value => makeMatrix(value, engine().ErrorCorrectionLevel.M, String(value).startsWith(PREFIX)),
    toSvg,
    toDataUrl,
    getInfo,
    // Conserva el transporte QR múltiple de inventario/despachos; la autorización PVLA2 nunca usa esta ruta.
    splitDocument,
    splitOpeningBundle,
    MAX_OPENING_QR_BYTES,
    MAX_OPENING_FRAMES,
    MAX_INPUT_BYTES: MAX_FRAGMENT_BYTES
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.ProControlLocalQR;
})(typeof window !== 'undefined' ? window : globalThis);
