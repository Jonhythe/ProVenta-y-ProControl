'use strict';

/*
 * ProControl - reglas puras para unidades individuales y cajas.
 * No cambia existencias ni precios por sí solo: el llamador debe validar
 * la operación y guardar todo dentro de la transacción de negocio.
 */
(function exposeProductUnits(root) {
  const isPositiveInteger = value =>
    Number.isSafeInteger(Number(value)) && Number(value) > 0;

  function normalizeUnitsPerBox(value) {
    if (value === null || value === undefined || value === '') return null;
    const number = Number(value);
    if (!Number.isSafeInteger(number) || number <= 0) {
      throw new Error('El contenido de una caja debe ser un entero mayor que cero.');
    }
    return number;
  }

  function toIndividualUnits(quantity, unit, unitsPerBox = null) {
    const qty = Number(quantity);
    if (!Number.isFinite(qty) || qty <= 0) {
      throw new Error('La cantidad debe ser un número mayor que cero.');
    }

    if (unit === 'caja' || unit === 'cajas' || unit === 'box' || unit === 'boxes') {
      const factor = normalizeUnitsPerBox(unitsPerBox);
      if (!factor) throw new Error('Este producto no tiene configurado cuántas unidades contiene una caja.');
      if (!Number.isSafeInteger(qty)) throw new Error('La cantidad de cajas debe ser un número entero.');
      const result = qty * factor;
      if (!Number.isSafeInteger(result)) throw new Error('La cantidad convertida excede el límite seguro.');
      return result;
    }

    if (unit === 'u' || unit === 'unidad' || unit === 'unidades') {
      if (!Number.isSafeInteger(qty)) throw new Error('La cantidad de unidades debe ser un número entero.');
      return qty;
    }

    throw new Error('La conversión automática solo está permitida entre cajas y unidades individuales.');
  }


  // Quantity stored in stock for a purchase line. A box is converted into its
  // individual units; other supported units remain in their own base unit.
  // This is used by purchase corrections as well as new purchase validation.
  function purchaseStockQuantity(quantity, unit, unitsPerBox = null) {
    const normalizedUnit = String(unit || '').trim().toLowerCase();
    const qty = Number(quantity);
    if (!Number.isFinite(qty) || qty <= 0) {
      throw new Error('La cantidad de compra debe ser un número mayor que cero.');
    }
    if (!validateDiscreteQuantity(qty, normalizedUnit)) {
      throw new Error(`La cantidad debe ser un número entero para la unidad ${normalizedUnit}.`);
    }
    if (['caja', 'cajas', 'box', 'boxes'].includes(normalizedUnit)) {
      return toIndividualUnits(qty, 'caja', unitsPerBox);
    }
    return qty;
  }

  function stockUnitForPurchase(unit) {
    const normalizedUnit = String(unit || '').trim().toLowerCase();
    return ['caja', 'cajas', 'box', 'boxes'].includes(normalizedUnit)
      ? 'u'
      : normalizedUnit;
  }

  // Convierte una compra introducida en cajas al stock base contado en unidades.
  // El coste recibido es por caja; el coste del inventario es por unidad individual.
  function normalizeBoxPurchase(boxQuantity, costPerBox, unitsPerBox) {
    const quantity = Number(boxQuantity);
    const cost = Number(costPerBox);
    const factor = normalizeUnitsPerBox(unitsPerBox);
    if (!Number.isSafeInteger(quantity) || quantity <= 0) {
      throw new Error('La cantidad de cajas debe ser un número entero positivo.');
    }
    if (!Number.isFinite(cost) || cost <= 0) {
      throw new Error('El precio por caja debe ser mayor que cero.');
    }
    return Object.freeze({
      stockQuantity: toIndividualUnits(quantity, 'caja', factor),
      costPerIndividualUnit: cost / factor,
      unitsPerBox: factor
    });
  }

  // Convierte dos cantidades de presentación (cajas completas + unidades sueltas)
  // a la única cantidad que almacena el inventario: unidades base individuales.
  // Las unidades pueden ser fraccionarias solo cuando el producto no usa caja y
  // su unidad base admite fracciones (kg, lb, lt, etc.).
  function combineBoxAndUnitQuantity(boxQuantity, individualQuantity, unitsPerBox = null, options = {}) {
    const boxes = Number(boxQuantity == null || boxQuantity === '' ? 0 : boxQuantity);
    const individuals = Number(individualQuantity == null || individualQuantity === '' ? 0 : individualQuantity);
    const factor = normalizeUnitsPerBox(unitsPerBox);
    const allowFractionalUnits = options && options.allowFractionalUnits === true;

    if (!Number.isFinite(boxes) || boxes < 0 || !Number.isSafeInteger(boxes)) {
      throw new Error('La cantidad de cajas debe ser un entero no negativo.');
    }
    if (!Number.isFinite(individuals) || individuals < 0) {
      throw new Error('La cantidad de unidades debe ser un número no negativo.');
    }
    if (boxes > 0 && !factor) {
      throw new Error('Configure cuántas unidades contiene una caja antes de transferirla o venderla.');
    }
    if (factor && !Number.isSafeInteger(individuals)) {
      throw new Error('Las unidades sueltas deben ser un número entero cuando el producto se cuenta por unidades.');
    }
    if (!allowFractionalUnits && !Number.isSafeInteger(individuals)) {
      throw new Error('La cantidad de unidades debe ser un número entero.');
    }
    const total = boxes * (factor || 0) + individuals;
    if (!Number.isFinite(total) || !Number.isSafeInteger(total) && !allowFractionalUnits) {
      throw new Error('La cantidad total convertida supera el límite seguro.');
    }
    if (Number.isSafeInteger(boxes * (factor || 0)) && Number.isFinite(total)) {
      return { boxes, individualUnits: individuals, unitsPerBox: factor, totalUnits: total };
    }
    throw new Error('La cantidad convertida no es válida.');
  }

  function splitIndividualUnits(totalQuantity, unitsPerBox = null) {
    const total = Number(totalQuantity);
    if (!Number.isFinite(total) || total < 0) throw new Error('La cantidad total debe ser un número no negativo.');
    const factor = normalizeUnitsPerBox(unitsPerBox);
    if (!factor) return { boxes: 0, individualUnits: total, totalUnits: total, unitsPerBox: null };
    if (!Number.isSafeInteger(total)) throw new Error('El stock individual debe ser un número entero para dividirlo en cajas.');
    return {
      boxes: Math.floor(total / factor),
      individualUnits: total % factor,
      totalUnits: total,
      unitsPerBox: factor
    };
  }

  function formatBoxBreakdown(boxQuantity, individualQuantity, unitsPerBox = null, options = {}) {
    const unitLabel = String(options.unitLabel || 'u');
    const boxLabel = String(options.boxLabel || 'cj');
    const combined = combineBoxAndUnitQuantity(boxQuantity, individualQuantity, unitsPerBox, {
      allowFractionalUnits: options.allowFractionalUnits === true
    });
    const format = (value, digits = 2) => root.ProControlNumberFormat
      ? root.ProControlNumberFormat.formatNumber(value, digits)
      : new Intl.NumberFormat('en-US', { useGrouping: true, maximumFractionDigits: Math.min(2, digits) }).format(Number(value) || 0);
    const parts = [];
    const individual = format(combined.individualUnits, 2);
    if (combined.boxes > 0 && combined.individualUnits > 0) {
      parts.push(`${format(combined.boxes,0)} ${boxLabel} × ${format(combined.unitsPerBox,0)} ${unitLabel} = ${format(combined.boxes*combined.unitsPerBox,0)} ${unitLabel}`);
      parts.push(`${individual} ${unitLabel} sueltas`);
      parts.push(`Total: ${format(combined.totalUnits,2)} ${unitLabel}`);
    } else if (combined.boxes > 0) {
      parts.push(`${format(combined.boxes,0)} ${boxLabel} × ${format(combined.unitsPerBox,0)} ${unitLabel} = ${format(combined.totalUnits,2)} ${unitLabel}`);
    } else {
      parts.push(`${individual} ${unitLabel}${combined.unitsPerBox ? ' sueltas' : ''}`);
      parts.push(`Total: ${format(combined.totalUnits,2)} ${unitLabel}`);
    }
    return { ...combined, text: parts.join(' · ') };
  }

  function subtractSale(currentIndividualUnits, quantity, saleUnit, unitsPerBox = null) {
    const current = Number(currentIndividualUnits);
    if (!Number.isSafeInteger(current) || current < 0) {
      throw new Error('El stock individual debe ser un entero no negativo.');
    }
    const sold = toIndividualUnits(quantity, saleUnit, unitsPerBox);
    if (sold > current) throw new Error('No hay existencias suficientes para esta venta.');
    return { soldIndividualUnits: sold, remainingIndividualUnits: current - sold };
  }

  const UNIT_OPTIONS = Object.freeze([
    Object.freeze({ value: 'u', label: 'Unidad (u)', shortLabel: 'u' }),
    Object.freeze({ value: 'pqt', label: 'Paquete (pqt)', shortLabel: 'pqt' }),
    Object.freeze({ value: 'lb', label: 'Libra (lb)', shortLabel: 'lb' }),
    Object.freeze({ value: 'kg', label: 'Kilogramo (kg)', shortLabel: 'kg' }),
    Object.freeze({ value: 'lt', label: 'Litro (lt)', shortLabel: 'lt' })
  ]);

  function unitOptions() {
    return UNIT_OPTIONS.map(option => ({ ...option }));
  }

  function isSupportedUnit(unit) {
    return UNIT_OPTIONS.some(option => option.value === String(unit || '').trim());
  }

  function validateDiscreteQuantity(quantity, unit) {
    if (['u', 'unidad', 'unidades', 'pqt', 'paquete', 'paquetes', 'caja', 'cajas', 'box', 'boxes'].includes(String(unit || '').toLowerCase())) {
      return Number.isSafeInteger(Number(quantity)) && Number(quantity) >= 0;
    }
    // kg, lb, lt y otras unidades fraccionables mantienen su precisión actual.
    return Number.isFinite(Number(quantity)) && Number(quantity) >= 0;
  }

  root.ProductUnits = Object.freeze({
    normalizeUnitsPerBox,
    toIndividualUnits,
    normalizeBoxPurchase,
    combineBoxAndUnitQuantity,
    splitIndividualUnits,
    formatBoxBreakdown,
    purchaseStockQuantity,
    stockUnitForPurchase,
    subtractSale,
    validateDiscreteQuantity,
    isPositiveInteger,
    unitOptions,
    isSupportedUnit
  });
})(typeof window !== 'undefined' ? window : globalThis);
