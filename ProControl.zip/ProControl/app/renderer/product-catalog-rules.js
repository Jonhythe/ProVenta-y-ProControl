'use strict';

/*
 * ProControl - clasificación de productos y sugerencias de unidad de compra.
 * Este módulo contiene reglas puras: no modifica inventario ni almacenamiento.
 */
(function exposeProductCatalogRules(root) {
  const PRODUCT_FAMILIES = Object.freeze({
    Carnicos: Object.freeze([
      'carne', 'cerdo', 'puerco', 'res$', 'carner', 'cordero', 'terner', 'chivo', 'conejo', 'pato',
      'chulet', 'pollo', 'pavo', 'picadill', 'bistec', 'costilla', 'pierna', 'lomo', 'masa de cerdo',
      'chicharron', 'huevo', 'molleja', 'menudencia', 'higado', 'viscera', 'carne molida', 'pechuga',
      'muslo de pollo', 'ala de pollo'
    ]),
    Pescados: Object.freeze(['pargo', 'bonit', 'salmon', 'trucha', 'bacalao', 'pescado', 'tilapia', 'merluz']),
    Mariscos: Object.freeze(['calamar', 'langost', 'camaron', 'pulpo', 'ostra', 'almeja', 'mejillon', 'cangrejo', 'marisc']),
    Granos: Object.freeze([
      'arroz', 'frijol', 'chicharo', 'garbanz', 'lentej', 'espagueti', 'spaghetti', 'macarron', 'fideo',
      'pasta alimenticia', 'pasta italiana', 'lasan', 'maiz en grano', 'maiz seco', 'maiz desgranado',
      'habichuela seca'
    ]),
    Harinas: Object.freeze(['harin', 'harina de maiz', 'maiz molido', 'maicena', 'maizena', 'trigo']),
    Grasas: Object.freeze(['aceite', 'mantec', 'margarina']),
    Embutidos: Object.freeze([
      'jamon', 'perro caliente', 'perrito caliente', 'mortadel', 'choriz', 'salami', 'salchic',
      'longaniza', 'morcill', 'butifarra', 'salchichon'
    ]),
    Lacteos: Object.freeze(['queso', 'leche', 'mantequill', 'yogur', 'helad', 'crema']),
    Laterios: Object.freeze(['lata$', 'atun', 'pure', 'conserva', 'sardin', 'maiz en lata', 'maiz enlatado', 'elote enlatado']),
    Condimentos: Object.freeze(['azucar', 'sal$', 'sason', 'comin', 'pimienta', 'pimenton', 'especia', 'condiment', 'oregano', 'laurel', 'curry', 'adobo', 'vainilla', 'canela', 'ajo en polvo']),
    'Salsas y Aderezos': Object.freeze([
      'mayon', 'mostaz', 'ketchup', 'salsa', 'vinagr', 'aderezo', 'aceituna', 'salsa de tomate',
      'pure de tomate', 'pasta de tomate', 'tomate triturado', 'concentrado de tomate', 'extracto de tomate'
    ]),
    Bebidas: Object.freeze([
      'refresc', 'malta', 'jugo', 'jugo de naranja', 'jugo de mango', 'jugo de guayaba', 'jugo de pina',
      'agua$', 'te$', 'energizante', 'cafe$', 'cola$', 'pepsi', 'sprite', 'fanta', 'batido', 'bebida',
      'nectar', 'limonada', 'gaseosa', 'soda$'
    ]),
    Cervezas: Object.freeze(['cervez', 'estella', 'corona$', 'heineken', 'cristal$', 'bucanero', 'mayabe', 'budweiser']),
    Licores: Object.freeze(['ron$', 'vino', 'whisk', 'vodka', 'licor', 'tequil', 'ginebra', 'brandy', 'aguardiente', 'champan', 'cognac', 'crema de whisky', 'crema de licor']),
    Aseo: Object.freeze([
      'jabon', 'deterg', 'cloro', 'papel', 'desinfec', 'limpiad', 'pasta dental', 'pasta de dientes',
      'crema dental', 'dental', 'dentifric', 'cepillo', 'enjuague', 'toallitas humedas', 'toallit',
      'toalla sanitaria', 'shampoo', 'champu', 'acondicionador', 'suavizante', 'desodorante', 'panal',
      'esponja', 'trapeador', 'fregona', 'escoba', 'insecticida', 'ambientador', 'lavavajilla', 'lejia',
      'rastrillo', 'afeitar', 'perfume', 'colonia', 'talco', 'algodon', 'agua oxigenada', 'gel de bano',
      'gel de ducha', 'crema hidratante', 'crema corporal'
    ]),
    Confiteria: Object.freeze([
      'gallet', 'caramel', 'chocol', 'snack', 'chuche', 'dulce', 'palomit', 'papas fritas', 'papitas',
      'chiclet', 'turron', 'bombon', 'mermelada', 'dulce de leche', 'dulce de guayaba', 'pasta de guayaba'
    ]),
    'Panaderia-Dulceria': Object.freeze(['pan$', 'cake', 'pancake', 'panque', 'marquesit', 'masa de pan', 'masa de empanada', 'masa de pizza', 'bizcoch', 'pastel', 'tarta', 'croissant', 'empanada']),
    Elaborados: Object.freeze(['sandwich', 'preparad', 'comida', 'servid', 'elaborad', 'pizza', 'hamburguesa', 'emparedado', 'plato del dia', 'arroz con leche']),
    Desechables: Object.freeze([
      'vaso$', 'plato$', 'envase', 'servillet', 'cubiert', 'desechabl', 'plastic', 'bolsa$',
      'jaba', 'jaba de nylon', 'jaba de nailon', 'jaba de nilon', 'jaba plastica'
    ]),
    Miscelaneas: Object.freeze(['pila$', 'bombill', 'articul', 'varios', 'vaso de cristal']),
    'Viandas-Frutas-Vegetales': Object.freeze([
      'yuca', 'malang', 'guayab', 'pina$', 'manzan', 'col$', 'lechu', 'tomate', 'cebol', 'papa$', 'papay',
      'frut', 'vegetal', 'platan', 'boniat', 'calabaz', 'zanahor', 'pepino', 'pimiento', 'aguacat', 'limon',
      'naranja', 'mango$', 'banan', 'ajo$', 'berenjena', 'remolacha', 'quimbombo', 'habichuela', 'coliflor',
      'brocoli', 'acelga', 'espinaca', 'rabano', 'apio', 'puerro', 'maiz tierno', 'maiz dulce',
      'maiz en mazorca', 'mazorca de maiz', 'maiz', 'mazorca', 'elote'
    ])
  });

  const FAMILY_BASE_INGREDIENTS = new Set([
    'Carnicos', 'Pescados', 'Mariscos', 'Granos', 'Harinas', 'Grasas', 'Condimentos', 'Viandas-Frutas-Vegetales'
  ]);

  const FAMILY_EMOJIS = Object.freeze({
    Carnicos: '🥩', Pescados: '🐟', Mariscos: '🦐', Granos: '🌾', Harinas: '🥖', Grasas: '🧈',
    Embutidos: '🌭', Lacteos: '🥛', Laterios: '🥫', Condimentos: '🧂', 'Salsas y Aderezos': '🍯',
    Bebidas: '🥤', Cervezas: '🍺', Licores: '🥃', Aseo: '🧼', Confiteria: '🍬',
    'Panaderia-Dulceria': '🥐', Elaborados: '🍱', Desechables: '🥤', Miscelaneas: '📦',
    'Viandas-Frutas-Vegetales': '🥦'
  });

  const normalize = value => String(value || '').toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  const tokens = value => normalize(value).split(/[^a-z0-9]+/).filter(Boolean);

  function tokenMatches(nameToken, keywordToken) {
    if (keywordToken.endsWith('$')) {
      const exact = keywordToken.slice(0, -1);
      return nameToken === exact || nameToken === `${exact}s` || nameToken === `${exact}es`;
    }
    return nameToken.startsWith(keywordToken);
  }

  function detectFamily(productName) {
    if (!String(productName || '').trim()) return 'Miscelaneas';
    const nameTokens = tokens(productName);
    if (!nameTokens.length) return 'Miscelaneas';

    let bestFamily = 'Miscelaneas';
    let bestLength = 0;
    let bestTokenCount = 0;
    let bestTier = 0;

    for (const [family, keywords] of Object.entries(PRODUCT_FAMILIES)) {
      const tier = FAMILY_BASE_INGREDIENTS.has(family) ? 1 : 2;
      for (const keyword of keywords) {
        const keywordTokens = tokens(keyword.replace(/\$$/, ''));
        if (!keywordTokens.length || keywordTokens.length > nameTokens.length) continue;
        let matched = false;
        for (let i = 0; i <= nameTokens.length - keywordTokens.length; i++) {
          let valid = true;
          for (let j = 0; j < keywordTokens.length; j++) {
            const sourceKeyword = keyword.split(' ')[j] || '';
            if (!tokenMatches(nameTokens[i + j], sourceKeyword.replace(/\$$/, '') + (sourceKeyword.endsWith('$') ? '$' : ''))) {
              valid = false;
              break;
            }
          }
          if (valid) { matched = true; break; }
        }
        if (!matched) continue;
        // "bolsa" es un descriptor genérico del envase, no debe imponerse
        // sobre el producto que contiene (por ejemplo, bolsa de arroz).
        // Si no hay otro producto identificable, seguirá clasificando como Desechables.
        const genericBagDescriptor = family === 'Desechables' && keyword === 'bolsa$';
        const length = genericBagDescriptor
          ? 0
          : normalize(keyword).replace(/\$/g, '').replace(/\s+/g, '').length;
        if (
          length > bestLength ||
          (length === bestLength && keywordTokens.length > bestTokenCount) ||
          (length === bestLength && keywordTokens.length === bestTokenCount && tier > bestTier)
        ) {
          bestFamily = family;
          bestLength = length;
          bestTokenCount = keywordTokens.length;
          bestTier = tier;
        }
      }
    }
    return bestFamily;
  }

  const ALL_UNITS = Object.freeze(['u', 'pqt', 'lb', 'kg', 'lt']);
  const MEAT_UNITS = Object.freeze(['pqt', 'lb', 'kg']);
  const GRAIN_UNITS = Object.freeze(['lb', 'pqt']);
  const WEIGHT_DEFAULT_FAMILIES = new Set(['Pescados', 'Mariscos', 'Harinas', 'Viandas-Frutas-Vegetales']);

  function hasPackagePresentation(productName) {
    return tokens(productName).some(token => ['paquete', 'paquetes', 'pqt', 'pack'].includes(token));
  }

  function hasBagPresentation(productName) {
    return tokens(productName).some(token => ['bolsa', 'bolsas'].includes(token));
  }

  function purchaseUnitProfile(productName, existingUnit = '') {
    const family = detectFamily(productName);
    let allowedUnits = [...ALL_UNITS];
    let defaultUnit = 'u';

    if (family === 'Granos') {
      allowedUnits = [...GRAIN_UNITS];
      defaultUnit = 'lb';
    } else if (family === 'Carnicos' || family === 'Embutidos') {
      allowedUnits = [...MEAT_UNITS];
      defaultUnit = 'pqt';
    } else if (WEIGHT_DEFAULT_FAMILIES.has(family)) {
      defaultUnit = 'lb';
    }

    if (
      (hasPackagePresentation(productName) || (family === 'Granos' && hasBagPresentation(productName))) &&
      allowedUnits.includes('pqt')
    ) defaultUnit = 'pqt';

    const current = String(existingUnit || '').trim().toLowerCase();
    if (current && ALL_UNITS.includes(current) && !allowedUnits.includes(current)) allowedUnits.push(current);

    return Object.freeze({ family, defaultUnit, allowedUnits: Object.freeze(allowedUnits) });
  }

  function knownFamilyCorrection(productName, currentFamily) {
    const name = normalize(productName);
    const family = String(currentFamily || '').trim();
    const detected = detectFamily(productName);
    if (!name || !family || family === detected) return null;

    const cornAsVegetable = /(^|\s)(maiz|mazorca|elote)(\s|$)/.test(name) &&
      !/(harina|maicena|maizena|maiz en grano|maiz seco|maiz desgranado|maiz en lata)/.test(name);
    if (['Harinas', 'Granos', 'Miscelaneas', 'Confiteria'].includes(family) && detected === 'Viandas-Frutas-Vegetales' && cornAsVegetable) return 'Viandas-Frutas-Vegetales';
    if (['Harinas', 'Viandas-Frutas-Vegetales', 'Miscelaneas'].includes(family) && detected === 'Granos' && /(maiz en grano|maiz seco|maiz desgranado|habichuela seca)/.test(name)) return 'Granos';
    if (family === 'Viandas-Frutas-Vegetales' && detected === 'Harinas' && /maiz molido/.test(name)) return 'Harinas';
    if (['Harinas', 'Viandas-Frutas-Vegetales', 'Miscelaneas'].includes(family) && detected === 'Laterios' && /maiz en lata/.test(name)) return 'Laterios';

    // Corrección de registros creados cuando el término genérico "bolsa"
    // desplazaba al alimento contenido hacia la familia Desechables.
    if (family === 'Desechables' && /(^|\s)bolsas?(\s|$)/.test(name) && detected !== 'Desechables' && detected !== 'Miscelaneas') {
      return detected;
    }
    // Las jabas de nailon para cargar productos pertenecen a Desechables.
    if (family === 'Miscelaneas' && detected === 'Desechables' && /(^|\s)jabas?(\s|$)/.test(name)) {
      return 'Desechables';
    }

    const tomatoSaucePhrases = [
      'salsa de tomate', 'pure de tomate', 'pasta de tomate', 'tomate triturado',
      'concentrado de tomate', 'extracto de tomate'
    ];
    if (family === 'Viandas-Frutas-Vegetales' && detected === 'Salsas y Aderezos' && tomatoSaucePhrases.some(phrase => name.includes(phrase))) {
      return 'Salsas y Aderezos';
    }

    if (family === 'Viandas-Frutas-Vegetales' && detected === 'Bebidas' && /^jugo de /.test(name)) return 'Bebidas';
    if (family === 'Granos' && detected === 'Elaborados' && name.includes('arroz con leche')) return 'Elaborados';
    if (family === 'Viandas-Frutas-Vegetales' && detected === 'Confiteria' && /(dulce de guayaba|pasta de guayaba|papas fritas|papitas)/.test(name)) return 'Confiteria';

    if (['Carnicos', 'Miscelaneas'].includes(family) && detected === 'Embutidos' && /(morcill|mortadel|choriz|salami|salchic|longaniza|butifarra)/.test(name)) {
      return 'Embutidos';
    }
    if (family === 'Miscelaneas' && detected === 'Carnicos' && /(molleja|menudencia|higado|viscera)/.test(name)) return 'Carnicos';
    if (family === 'Miscelaneas' && detected === 'Viandas-Frutas-Vegetales' && /(mazorca|elote)/.test(name)) return 'Viandas-Frutas-Vegetales';

    if (family === 'Viandas-Frutas-Vegetales' && detected === 'Granos' && /(habichuela seca|maiz en grano|maiz seco|maiz desgranado)/.test(name)) {
      return 'Granos';
    }

    return null;
  }


  function findUnitConflict(existingItems, requestedUnit) {
    const requested = String(requestedUnit || '').trim().toLowerCase();
    for (const item of Array.isArray(existingItems) ? existingItems : []) {
      if (!item || !item.unit) continue;
      const stored = String(item.unit).trim().toLowerCase();
      if (stored && stored !== requested) return Object.freeze({ item, storedUnit: stored });
    }
    return null;
  }

  function unitConflictMessage(productName, requestedUnit, storedUnit, locationName = 'el inventario') {
    const name = String(productName || '').trim() || 'Producto';
    const requested = String(requestedUnit || '').trim().toLowerCase();
    const stored = String(storedUnit || '').trim().toLowerCase();
    const suggestion = requested === 'pqt'
      ? (hasPackagePresentation(name) ? name : `Paquete de ${name}`)
      : `${name} (${requested})`;
    return `No se puede registrar "${name}" en ${requested} porque ese mismo producto ya existe en ${locationName} con unidad ${stored}.\n\nPara sumar la mercancía al inventario existente, cambie la unidad de esta compra a ${stored}.\n\nSi se trata de una presentación diferente, cambie el nombre del producto, por ejemplo: "${suggestion}". Así tendrá un inventario independiente y no se mezclarán libras, paquetes, kilogramos ni unidades.\n\nNo se modificó el inventario.`;
  }

  const api = Object.freeze({
    PRODUCT_FAMILIES,
    FAMILY_BASE_INGREDIENTS,
    FAMILY_EMOJIS,
    detectFamily,
    normalizeProductName: normalize,
    hasPackagePresentation,
    hasBagPresentation,
    purchaseUnitProfile,
    knownFamilyCorrection,
    findUnitConflict,
    unitConflictMessage
  });

  root.ProductCatalogRules = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
