'use strict';
// Administración de ProVenta: identidad inicial y renovaciones mensuales por QR firmado.
(function () {
  const $ = id => document.getElementById(id);
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
  const fmtNumber = (value, digits = 0) => window.ProControlNumberFormat
    ? window.ProControlNumberFormat.formatNumber(value, digits)
    : new Intl.NumberFormat('en-US', { useGrouping:true, maximumFractionDigits:Math.min(2, digits) }).format(Number(value) || 0);
  const api = () => window.PCMobileBridge;
  let ownerSession = null;
  let latestAuthorization = null;
  let replacingAuthorizationId = null;
  let currentPosId = null;
  let currentPosName = null;
  let authorizationRows = [];
  let pendingShiftPermit = null;
  let shiftPermitRows = [];
  let openingQrPieces = [];
  let openingQrIndex = 0;
  let openingQrTimer = null;

  function requireCurrentPos() {
    const state = typeof appState !== 'undefined' ? appState : null;
    const inventory = typeof Inventory !== 'undefined' ? Inventory : null;
    const index = state ? Number(state.selectedPOSIndex) : -1;
    const pos = state && Array.isArray(state.pointsOfSale) && Number.isInteger(index) ? state.pointsOfSale[index] : null;
    if (!pos || !pos.id || !inventory || typeof inventory.posReference !== 'function') {
      throw Object.assign(new Error('Abre primero el punto de venta para preparar su permiso de turno.'), { code: 'POS_WORKSPACE_REQUIRED' });
    }
    const reference = inventory.posReference(pos);
    if (typeof reference !== 'string' || !reference.startsWith('pos:')) {
      throw Object.assign(new Error('El punto de venta no tiene una identidad estable.'), { code: 'POS_IDENTITY_UNAVAILABLE' });
    }
    currentPosId = String(pos.id);
    currentPosName = String(pos.name || 'Punto de venta');
    const page = $('page-pos-workspace');
    if (page && page.classList && page.classList.contains('hidden')) {
      throw Object.assign(new Error('Las operaciones de turno solo se gestionan desde el punto de venta abierto.'), { code: 'POS_WORKSPACE_REQUIRED' });
    }
    return currentPosId;
  }

  function setMessage(text, error = false) {
    const target = $('proventa-auth-message');
    if (!target) return;
    target.textContent = String(text || '');
    target.style.borderColor = error ? '#d9534f' : 'var(--color-accent)';
    target.style.background = error ? 'rgba(217,83,79,.10)' : 'rgba(197,160,89,.08)';
  }
  function showError(error) {
    if (error && error.canceled) return;
    setMessage((error && (error.message || error.code)) || 'No se pudo completar la operación.', true);
  }

  async function requireOwnerSession(force = false) {
    if (force) ownerSession = null;
    if (ownerSession && ownerSession.expiresAt > Date.now() + 5000) return ownerSession.token;
    if (typeof askInput !== 'function') throw new Error('No está disponible el diálogo seguro para confirmar la contraseña del Dueño.');
    const credentials = await askInput('Confirmar identidad del Dueño', [
      { id: 'password', label: 'Contraseña del Dueño', type: 'password', placeholder: 'Contraseña' },
      { id: 'pin', label: 'PIN del Dueño (6 dígitos)', type: 'password', inputmode: 'numeric', maxlength: 6, autocomplete: 'off', placeholder: 'PIN de 6 dígitos' }
    ], 'Verificar y continuar');
    if (!credentials) throw Object.assign(new Error('Operación cancelada.'), { canceled: true });
    const password = String(credentials.password || '');
    const pin = String(credentials.pin || '');
    credentials.password = '';
    credentials.pin = '';
    if (!/^\d{6}$/.test(pin)) throw new Error('El PIN debe contener exactamente 6 dígitos. No se aceptará un PIN incompleto.');
    const bridge = api();
    if (!bridge || typeof bridge.authorizeOwnerControl !== 'function') throw new Error('Actualiza juntos main.js y preload.js de ProControl.');
    const result = await bridge.authorizeOwnerControl({ password, pin });
    if (!result || result.ok !== true || !result.token) {
      if (result && result.code === 'OWNER_PIN_NOT_CONFIGURED') {
        throw new Error('Primero configura el PIN de 6 dígitos desde Mi Cuenta. Se requiere contraseña actual.');
      }
      throw new Error(result && result.code || 'AUTH_FAILED');
    }
    ownerSession = { token: result.token, expiresAt: Number(result.expiresAt) || Date.now() };
    return ownerSession.token;
  }

  function statusLabel(status) {
    return ({ pending: 'Pendiente', active: 'Activo', invalidated: 'Invalidado', superseded: 'Sustituido', expired: 'Caducado' })[status] || status;
  }
  function statusColor(status) {
    return status === 'active' ? '#22a06b' : (status === 'invalidated' || status === 'superseded' || status === 'expired') ? '#d97706' : 'var(--color-text-muted)';
  }
  function formatDate(value) {
    const number = Number(value);
    return Number.isFinite(number) && number > 0 ? new Date(number).toLocaleString() : '—';
  }
  function scopeLabel(row) {
    const version = Number(row && row.protocolVersion || 0);
    if (version >= 5 || !row.authorizedPosId) return 'Instalación completa';
    return `Compatibilidad anterior · POS ${String(row.authorizedPosId)}`;
  }
  function getAuthorization(authorizationId) {
    return authorizationRows.find(row => String(row.authorizationId) === String(authorizationId)) || null;
  }
  function renderAdminDevices() {
    const target = $('proventa-auth-list');
    if (!target) return;
    const query = String(($('proventa-admin-search') || {}).value || '').trim().toLocaleLowerCase();
    const selectedStatus = String(($('proventa-admin-status-filter') || {}).value || 'all');
    const filtered = authorizationRows.filter(row => {
      if (selectedStatus !== 'all' && row.status !== selectedStatus) return false;
      const employeeData = row.employeeData && (row.employeeData.phoneNumber || row.employeeData.note || row.employeeData.contact || '') || '';
      const haystack = [row.employeeName, employeeData, row.deviceLabel, row.deviceId, row.authorizationId, row.createdBy]
        .map(value => String(value || '').toLocaleLowerCase()).join(' ');
      return !query || haystack.includes(query);
    });
    target.innerHTML = filtered.length ? filtered.map(row => {
      const contact = row.employeeData && (row.employeeData.phoneNumber || row.employeeData.note || row.employeeData.contact || '');
      const canRevoke = ['active', 'pending', 'expired'].includes(row.status);
      const canReplace = Boolean(row.deviceId) && ['active', 'invalidated'].includes(row.status);
      const canRenew = Boolean(row.deviceId) && ['active', 'pending', 'expired'].includes(row.status);
      const needsConfirmation = row.recordStatus === 'pending';
      return `<tr>
        <td><span class="proventa-admin-worker">${esc(row.employeeName || 'Trabajador sin nombre')}</span>${contact ? `<span class="proventa-admin-sub">Tel. ${esc(contact)}</span>` : ''}</td>
        <td><strong>${esc(row.deviceLabel || 'Teléfono Android')}</strong><span class="proventa-admin-sub">ID: ${esc(row.deviceId || 'No disponible')}</span></td>
        <td>${esc(scopeLabel(row))}<span class="proventa-admin-sub">Protocolo V${esc(row.protocolVersion || 'legacy')}</span></td>
        <td>${esc(formatDate(row.issuedAt))}</td>
        <td><span class="proventa-admin-status" style="color:${statusColor(row.status)}">${esc(statusLabel(row.status))}</span></td>
        <td><div class="proventa-admin-row-actions">
          <button type="button" class="btn btn-outline" data-proventa-admin-action="detail" data-auth-id="${esc(row.authorizationId)}">Ficha</button>
          ${canRenew ? `<button type="button" class="btn btn-outline" data-proventa-admin-action="renew" data-auth-id="${esc(row.authorizationId)}">QR ${needsConfirmation ? 'alta' : 'renovación'}</button>` : ''}
          ${needsConfirmation ? `<button type="button" class="btn btn-primary" data-proventa-admin-action="confirm" data-auth-id="${esc(row.authorizationId)}">Confirmar alta</button>` : ''}
          ${canRevoke ? `<button type="button" class="btn btn-outline" data-proventa-admin-action="revoke" data-auth-id="${esc(row.authorizationId)}">Invalidar</button>` : ''}
          ${canReplace ? `<button type="button" class="btn btn-outline" data-proventa-admin-action="replace" data-auth-id="${esc(row.authorizationId)}">Sustituir</button>` : ''}
        </div></td>
      </tr>`;
    }).join('') : '<tr><td colspan="6" class="proventa-admin-empty">No hay dispositivos que coincidan con estos filtros.</td></tr>';
    const count = $('proventa-admin-result-count');
    if (count) count.textContent = `${filtered.length} de ${authorizationRows.length} registros`;
    const active = $('proventa-admin-stat-active');
    const invalidated = $('proventa-admin-stat-invalidated');
    const superseded = $('proventa-admin-stat-superseded');
    if (active) active.textContent = String(authorizationRows.filter(row => row.status === 'active').length);
    if (invalidated) invalidated.textContent = String(authorizationRows.filter(row => row.status === 'invalidated').length);
    if (superseded) superseded.textContent = String(authorizationRows.filter(row => row.status === 'superseded').length);
  }
  function renderDeviceDetail(authorizationId) {
    const target = $('proventa-admin-detail');
    if (!target) return;
    const row = getAuthorization(authorizationId);
    if (!row) { target.className = 'proventa-admin-detail-empty'; target.textContent = 'Selecciona un dispositivo de la tabla para consultar su ficha y las acciones disponibles.'; return; }
    const contact = row.employeeData && (row.employeeData.phoneNumber || row.employeeData.note || row.employeeData.contact || '') || 'No proporcionado';
    const fields = [
      ['Trabajador', row.employeeName || '—'], ['Teléfono', contact],
      ['ID de dispositivo', row.deviceId || '—'], ['Nombre del teléfono', row.deviceLabel || '—'],
      ['Alcance', scopeLabel(row)], ['Protocolo', `V${row.protocolVersion || 'legacy'}`],
      ['Renovación mensual #', String(row.renewalSequence || 0)],
      ['Autorización emitida', formatDate(row.issuedAt)], ['Última actividad', formatDate(row.lastSeenAt)],
      ['Estado', statusLabel(row.status)], ['Creada por', row.createdBy || '—'],
      ['Autorización sustituida por', row.replacedByAuthorizationId || '—'], ['Sustituye a', row.replacesAuthorizationId || '—']
    ];
    target.className = '';
    target.innerHTML = `<div class="proventa-admin-detail-grid">${fields.map(([label,value]) => `<div class="proventa-admin-detail-item"><label>${esc(label)}</label><strong>${esc(value)}</strong></div>`).join('')}</div>
      <div class="proventa-admin-detail-actions">
        ${['active','pending','expired'].includes(row.status) && row.deviceId ? `<button type="button" class="btn btn-outline" data-proventa-admin-action="renew" data-auth-id="${esc(row.authorizationId)}">Generar QR</button>` : ''}
        ${row.recordStatus === 'pending' ? `<button type="button" class="btn btn-primary" data-proventa-admin-action="confirm" data-auth-id="${esc(row.authorizationId)}">Confirmar alta</button>` : ''}
        ${['active','pending','expired'].includes(row.status) ? `<button type="button" class="btn btn-outline" data-proventa-admin-action="revoke" data-auth-id="${esc(row.authorizationId)}">Invalidar autorización</button>` : ''}
        ${row.deviceId && ['active','invalidated'].includes(row.status) ? `<button type="button" class="btn btn-primary" data-proventa-admin-action="replace" data-auth-id="${esc(row.authorizationId)}">Sustituir teléfono</button>` : ''}
      </div>`;
  }
  function historyActionLabel(action) {
    return ({ device_authorized_from_pvid:'Identidad de teléfono registrada', device_authorization_issued:'Autorización emitida', device_authorization_renewal_issued:'QR de renovación emitido', device_authorization_confirmed:'Alta de teléfono confirmada', device_authorization_revoked:'Autorización invalidada', device_authorization_superseded:'Teléfono sustituido', device_authorization_descriptor_exported:'Ficha de autorización exportada', device_enabled:'Dispositivo habilitado', device_revoked:'Dispositivo revocado', device_enrollment_request_imported:'Solicitud de dispositivo importada', device_identity_imported:'Identidad de dispositivo importada' })[action] || String(action || 'Evento de autorización').replace(/_/g, ' ');
  }
  function renderAuthorizationHistory(history) {
    const target = $('proventa-auth-history');
    if (!target) return;
    const rows = Array.isArray(history) ? history : [];
    target.innerHTML = rows.length ? rows.map(event => {
      const detail = event.detail && typeof event.detail === 'object' ? event.detail : {};
      const employee = detail.employeeName || detail.employee || '';
      const device = detail.deviceId || detail.replacementDeviceId || '';
      const reason = detail.reason || detail.note || '';
      const sub = [employee, device ? `ID ${device}` : '', reason ? `Motivo: ${reason}` : ''].filter(Boolean).join(' · ');
      return `<article class="proventa-admin-history-item"><div class="proventa-admin-history-icon">${event.action === 'device_authorization_revoked' ? '×' : event.action === 'device_authorization_superseded' ? '↗' : '✓'}</div><div><div class="proventa-admin-history-title">${esc(historyActionLabel(event.action))}</div><div class="proventa-admin-sub">${esc(formatDate(event.at))} · Responsable: ${esc(event.actor || 'Sistema')}</div>${sub ? `<div class="proventa-admin-sub">${esc(sub)}</div>` : ''}${detail.authorizationId ? `<div class="proventa-admin-sub">Autorización: ${esc(detail.authorizationId)}</div>` : ''}</div></article>`;
    }).join('') : '<div class="proventa-admin-empty">Todavía no hay eventos de autorización registrados.</div>';
  }
  async function refreshAdmin() {
    const authToken = await requireOwnerSession();
    const bridge = api();
    if (!bridge || typeof bridge.proventaListDeviceAuthorizations !== 'function' || typeof bridge.proventaListDeviceAuthorizationHistory !== 'function') throw new Error('Actualiza juntos main.js y preload.js para habilitar el registro de dispositivos e historial.');
    const [result, historyResult] = await Promise.all([
      bridge.proventaListDeviceAuthorizations({ authToken }), bridge.proventaListDeviceAuthorizationHistory({ authToken, limit: 300 })
    ]);
    if (!result || result.ok !== true) throw new Error(result && result.code || 'AUTHORIZATION_LIST_FAILED');
    if (!historyResult || historyResult.ok !== true) throw new Error(historyResult && historyResult.code || 'AUTHORIZATION_HISTORY_FAILED');
    authorizationRows = Array.isArray(result.authorizations) ? result.authorizations : [];
    const installation = $('proventa-auth-installation');
    if (installation) installation.textContent = result.installationId || '—';
    renderAdminDevices();
    renderAuthorizationHistory(historyResult.history);
    return authorizationRows;
  }
  async function openAdmin() {
    try {
      if (typeof Auth === 'undefined' || !Auth.requireRole(['Dueño'], 'Solo el Dueño puede administrar los teléfonos de ProVenta.')) return;
      ownerSession = null; latestAuthorization = null; replacingAuthorizationId = null; replacementReason = '';
      if ($('proventa-auth-code-card')) $('proventa-auth-code-card').style.display = 'none';
      hideQr();
      if (typeof UI !== 'undefined' && typeof UI.showPage === 'function') UI.showPage('page-proventa-admin');
      setMessage('Verificando al Dueño y cargando los registros de esta instalación…');
      await refreshAdmin();
      setMessage('Administración de ProVenta lista. Las nuevas autorizaciones se vinculan a esta instalación completa.');
    } catch (error) { showError(error); }
  }
  async function askReason(title, confirmLabel) {
    if (typeof askInput !== 'function') throw new Error('No está disponible el diálogo seguro para registrar el motivo.');
    const values = await askInput(title, [{ id:'reason', label:'Motivo (obligatorio)', type:'text', placeholder:'Ej. Teléfono perdido, roto o cambio de trabajador' }], confirmLabel || 'Continuar');
    if (!values) throw Object.assign(new Error('Operación cancelada.'), { canceled:true });
    const reason = String(values.reason || '').trim();
    if (reason.length < 3 || reason.length > 240) throw new Error('El motivo debe tener entre 3 y 240 caracteres.');
    return reason;
  }
  async function generate() {
    try {
      if (typeof Auth === 'undefined' || !Auth.requireRole(['Dueño'], 'Solo el Dueño puede autorizar teléfonos ProVenta.')) return;
      const authToken = await requireOwnerSession(true);
      const employeeName = String(($('proventa-auth-employee') || {}).value || '').trim();
      const phoneNumber = String(($('proventa-auth-phone') || {}).value || '').trim();
      if (employeeName.length < 2) throw Object.assign(new Error('Escribe el nombre del trabajador.'), { code:'EMPLOYEE_NAME_REQUIRED' });
      if (!/^\+?[0-9][0-9 ()-]{4,30}$/.test(phoneNumber) || phoneNumber.replace(/\D/g, '').length < 6 || phoneNumber.replace(/\D/g, '').length > 15) {
        throw Object.assign(new Error('Escribe un teléfono válido con entre 6 y 15 dígitos.'), { code:'PHONE_NUMBER_REQUIRED' });
      }
      const bridge = api();
      if (!bridge || typeof bridge.proventaGenerateActivationCodeFromPvid !== 'function') throw new Error('Actualiza juntos main.js y preload.js para habilitar el código PVLA2 de instalación.');
      setMessage('Selecciona el archivo .pvid exportado desde el teléfono. Se verificará su identidad criptográfica…');
      const result = await bridge.proventaGenerateActivationCodeFromPvid({ employeeName, phoneNumber, replacesAuthorizationId:replacingAuthorizationId, replacementReason, authToken });
      if (!result || result.ok !== true) throw Object.assign(new Error(result && (result.message || result.code) || 'PVID_ACTIVATION_FAILED'), { canceled:!!(result && result.canceled), code:result && result.code });
      if (typeof result.activationCode !== 'string' || !result.activationCode.startsWith('PVLA2:')) throw new Error('ProControl no devolvió un código PVLA2 válido. No se registró el teléfono.');
      hideQr();
      latestAuthorization = { authorizationId:result.authorizationId, activationCode:result.activationCode, employeeName:result.employeeName, deviceId:result.deviceId, installationId:result.installationId, qrExpiresAt:result.qrExpiresAt, renewalSequence:result.renewalSequence, status:result.status };
      $('proventa-auth-code-details').textContent = `Trabajador: ${result.employeeName} · Teléfono: ${result.deviceId} · Renovación #${result.renewalSequence} · Vence: ${formatDate(result.qrExpiresAt)}`;
      $('proventa-auth-code-card').style.display = 'block';
      replacingAuthorizationId = null; replacementReason = '';
      $('proventa-auth-employee').value = ''; $('proventa-auth-phone').value = '';
      setMessage(`QR de alta generado para ${result.employeeName}. Cuando ProVenta abra, confirma el teléfono para guardar y habilitar el registro.`);
      await refreshAdmin();
    } catch (error) { showError(error); }
  }
  async function issueRenewal(authorizationId) {
    try {
      const row = getAuthorization(authorizationId);
      if (!row || !row.deviceId || !['active','pending','expired'].includes(row.status)) throw new Error('No se encontró un teléfono válido para generar el QR.');
      const authToken = await requireOwnerSession(true);
      const bridge = api();
      if (!bridge || typeof bridge.proventaIssueDeviceRenewalCode !== 'function') throw new Error('Actualiza juntos main.js y preload.js para habilitar los QR de renovación.');
      const result = await bridge.proventaIssueDeviceRenewalCode({ authorizationId, authToken });
      if (!result || result.ok !== true || typeof result.activationCode !== 'string' || !result.activationCode.startsWith('PVLA2:')) {
        throw new Error(result && result.code || 'DEVICE_AUTHORIZATION_RENEWAL_FAILED');
      }
      latestAuthorization = { ...result };
      const details = $('proventa-auth-code-details');
      if (details) details.textContent = `Trabajador: ${result.employeeName} · Teléfono: ${result.deviceId} · Renovación #${result.renewalSequence} · Vence: ${formatDate(result.qrExpiresAt)}`;
      const card = $('proventa-auth-code-card');
      if (card) card.style.display = 'block';
      renderQr();
      setMessage(`QR #${result.renewalSequence} listo para ${result.employeeName}. Escanéalo en ese teléfono antes de ${formatDate(result.qrExpiresAt)}.`);
      await refreshAdmin();
    } catch (error) { showError(error); }
  }
  async function confirmEnrollment() {
    try {
      if (!latestAuthorization || !latestAuthorization.authorizationId || latestAuthorization.status !== 'pending') {
        throw new Error('Solo se puede confirmar un teléfono que todavía esté pendiente de alta.');
      }
      if (!window.confirm(`¿Confirmas que ${latestAuthorization.employeeName} abrió ProVenta en el teléfono ${latestAuthorization.deviceId}?`)) return;
      const authToken = await requireOwnerSession();
      const result = await api().proventaConfirmDeviceAuthorization({ authorizationId:latestAuthorization.authorizationId, authToken });
      if (!result || result.ok !== true) throw new Error(result && result.code || 'AUTHORIZATION_CONFIRMATION_FAILED');
      latestAuthorization.status = 'active';
      setMessage('Teléfono confirmado y habilitado. El vínculo y sus claves quedaron guardados en ProControl.');
      await refreshAdmin();
    } catch (error) { showError(error); }
  }
  function hideQr() {
    const wrap = $('proventa-auth-qr-wrap');
    const image = $('proventa-auth-qr-image');
    if (wrap) wrap.style.display = 'none';
    if (image) image.src = '';
  }
  function renderQr() {
    try {
      const code = latestAuthorization && latestAuthorization.activationCode;
      if (!code) throw new Error('Primero genera la autorización PVLA2 del teléfono.');
      if (Number(latestAuthorization.qrExpiresAt) <= Date.now()) throw new Error('Este QR venció. Genera uno nuevo desde la ficha del teléfono.');
      const qr = window.ProControlLocalQR;
      if (!qr || typeof qr.toDataUrl !== 'function') throw new Error('No se cargó el generador local de QR. Reinicia ProControl y vuelve a intentarlo.');
      const image = $('proventa-auth-qr-image');
      const wrap = $('proventa-auth-qr-wrap');
      if (!image || !wrap) throw new Error('No está disponible el espacio para mostrar el QR.');
      image.src = qr.toDataUrl(code, 7);
      wrap.style.display = 'block';
      setMessage('QR de autorización listo. Escanéalo desde ProVenta. No necesitas exportar el archivo si utilizas esta opción.');
    } catch (error) { showError(error); }
  }
  async function showQr() {
    try {
      await requireOwnerSession(true);
      renderQr();
    } catch (error) { showError(error); }
  }
  async function revoke(authorizationId) {
    try {
      const row = getAuthorization(authorizationId);
      if (!row) throw new Error('No se encontró la autorización seleccionada. Actualiza la lista.');
      const reason = await askReason(`Invalidar autorización de ${row.employeeName || 'este trabajador'}`, 'Invalidar autorización');
      if (!window.confirm(`¿Invalidar definitivamente la autorización de ${row.employeeName || 'este trabajador'}? El teléfono dejará de estar autorizado cuando vuelva a comunicarse con ProControl.`)) return;
      const authToken = await requireOwnerSession();
      const result = await api().proventaRevokeDeviceAuthorization({ authorizationId, reason, authToken });
      if (!result || result.ok !== true) throw new Error(result && result.code || 'AUTHORIZATION_REVOKE_FAILED');
      setMessage('Autorización invalidada. El evento y su motivo quedaron conservados en el historial.');
      await refreshAdmin(); renderDeviceDetail(authorizationId);
    } catch (error) { showError(error); }
  }
  let replacementReason = '';
  async function startReplacement(authorizationId, employeeName) {
    try {
      const row = getAuthorization(authorizationId);
      if (!row) throw new Error('No se encontró la autorización que deseas sustituir.');
      const reason = await askReason(`Sustituir el teléfono de ${employeeName || row.employeeName || 'este trabajador'}`, 'Continuar con sustitución');
      if (!window.confirm('El teléfono anterior quedará invalidado antes de autorizar el nuevo. ¿Continuar?')) return;
      const authToken = await requireOwnerSession();
      if (row.status !== 'invalidated') {
        const revoked = await api().proventaRevokeDeviceAuthorization({ authorizationId, reason, authToken });
        if (!revoked || revoked.ok !== true) throw new Error(revoked && revoked.code || 'OLD_DEVICE_REVOCATION_FAILED');
      }
      replacingAuthorizationId = authorizationId; replacementReason = reason;
      $('proventa-auth-employee').value = employeeName || row.employeeName || ''; $('proventa-auth-phone').value = '';
      setMessage(`Autorización anterior invalidada por: ${reason}. Selecciona ahora el archivo .pvid del teléfono nuevo. La sustitución conservará ambos registros.`);
      await refreshAdmin(); $('proventa-auth-employee').focus();
    } catch (error) { showError(error); }
  }
  async function refreshShiftPanel() {
    const posId = requireCurrentPos();
    const authToken = await requireOwnerSession();
    const result = await api().proventaListDeviceAuthorizations({ authToken });
    if (!result || result.ok !== true) throw new Error(result && result.code || 'AUTHORIZATION_LIST_FAILED');
    const permitResult = await api().listShiftPermits({ posId, authToken });
    if (!permitResult || permitResult.ok !== true) throw new Error(permitResult && permitResult.code || 'SHIFT_PERMIT_LIST_FAILED');
    authorizationRows = Array.isArray(result.authorizations) ? result.authorizations : [];
    shiftPermitRows = (Array.isArray(permitResult.permits) ? permitResult.permits : []).filter(row => row && row.posId === posId && row.status === 'issued' && row.permitId && row.deviceId && Number.isFinite(Number(row.endsAt)) && Number(row.endsAt) > Date.now());
    const permitRecovery = $('proventa-shift-permit-recovery');
    if (permitRecovery) permitRecovery.innerHTML = shiftPermitRows.length
      ? '<div style="font-weight:800;margin-bottom:.35rem;">Aperturas completas disponibles para exportar o volver a exportar</div>' + shiftPermitRows.map(row => `<div style="display:flex;gap:.55rem;align-items:center;justify-content:space-between;flex-wrap:wrap;padding:.45rem 0;border-top:1px solid var(--color-border);"><div><strong>${esc(row.employee || 'Trabajador')}</strong><div class="proventa-auth-sub">${esc(row.permitId)} · ${esc(row.deviceId)} · Hasta ${esc(formatDate(row.endsAt))}</div></div><button type="button" class="btn btn-outline" data-proventa-action="retry-permit-export" data-permit-id="${esc(row.permitId)}" data-device-id="${esc(row.deviceId)}">Exportar apertura completa (.pcopen + QR)</button></div>`).join('')
      : '<span style="font-size:.76rem;color:var(--color-text-muted);">No hay permisos vigentes pendientes de apertura para este POS.</span>';
    const deviceSelect = $('proventa-shift-device');
    if (deviceSelect) {
      const eligible = authorizationRows.filter(row => row.status === 'active' && row.deviceId && (Number(row.protocolVersion) >= 5 || String(row.authorizedPosId || '') === String(posId)));
      const previous = deviceSelect.value;
      deviceSelect.innerHTML = eligible.length ? eligible.map(row => `<option value="${esc(row.deviceId)}" data-employee="${esc(row.employeeName)}">${esc(row.employeeName)} · ${esc(row.deviceLabel || row.deviceId)} · ${Number(row.protocolVersion) >= 5 ? 'Instalación' : 'POS anterior'}</option>`).join('') : '<option value="">No hay teléfonos activos autorizados para este POS</option>';
      if (eligible.some(row => row.deviceId === previous)) deviceSelect.value = previous;
    }
    const posLabel = $('proventa-shift-pos'); if (posLabel) posLabel.textContent = `${currentPosName} · ${currentPosId}`;
    return authorizationRows;
  }
  function setShiftMessage(text, error = false) {
    const target = $('proventa-shift-message');
    if (!target) return;
    target.textContent = String(text || '');
    target.style.borderColor = error ? '#d9534f' : 'var(--color-accent)';
    target.style.background = error ? 'rgba(217,83,79,.10)' : 'rgba(197,160,89,.08)';
  }

  function formatLocalDateTime(date) {
    const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 16);
  }

  function initializeShiftDateFields() {
    const starts = $('proventa-shift-starts');
    const ends = $('proventa-shift-ends');
    const now = new Date();
    if (starts && !starts.value) starts.value = formatLocalDateTime(now);
    if (ends && !ends.value) ends.value = formatLocalDateTime(new Date(now.getTime() + 8 * 60 * 60 * 1000));
  }

  async function exportPermit(permitId, posId, deviceId, authToken) {
    const result = await api().exportShiftOpeningBundle({ permitId, posId, deviceId, authToken });
    if (!result || result.ok !== true) {
      if (result && result.canceled) {
        pendingShiftPermit = { permitId, posId, deviceId };
        const retry = $('proventa-shift-export-retry');
        if (retry) retry.style.display = 'inline-flex';
        setShiftMessage('No se exportó el archivo porque se canceló el selector. El permiso quedó guardado en ProControl; pulsa «Reintentar exportación» para guardarlo sin crear otro turno.');
        return false;
      }
      throw Object.assign(new Error(result && (result.message || result.code) || 'SHIFT_PERMIT_EXPORT_FAILED'), { code: result && result.code });
    }
    if (typeof result.bundleJson !== 'string' || !result.bundleJson) {
      throw new Error('ProControl no devolvió el paquete completo para verificar y mostrar la secuencia QR.');
    }
    pendingShiftPermit = null;
    const retry = $('proventa-shift-export-retry');
    if (retry) retry.style.display = 'none';
    showOpeningQr(result.bundleJson);
    setShiftMessage(`Apertura completa exportada y verificada: ${result.fileName}. POS: ${currentPosName}. Inventario: ${fmtNumber(result.productCount)} productos. QR: ${openingQrPieces.length} cuadros. Entrega el archivo o escanea la secuencia completa desde ProVenta.`);
    return true;
  }

  function renderOpeningQr() {
    const target = $('proventa-opening-qr-wrap');
    const piece = openingQrPieces[openingQrIndex];
    if (!target || !piece) return;
    target.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;gap:.6rem;flex-wrap:wrap;"><strong>Escanear apertura completa · ${openingQrIndex + 1} / ${openingQrPieces.length}</strong><button type="button" class="btn btn-outline" onclick="ProVentaAuthorizationUI.closeOpeningQr()">Cerrar QR</button></div><p style="font-size:.78rem;color:var(--color-text-muted);">Deja el QR visible y escanea todos los cuadros en orden. ProVenta debe reunir la secuencia y verificar firmas, cifrado y alcance antes de importar. El inventario viaja cifrado para este teléfono.</p><div style="text-align:center;padding:.5rem;"><img src="${esc(piece.dataUrl)}" alt="QR ${piece.index} de ${piece.total}" width="300" height="300" style="width:min(300px,75vw);height:auto;image-rendering:pixelated;background:#fff;"></div><div style="display:flex;justify-content:center;align-items:center;gap:.5rem;flex-wrap:wrap;"><button type="button" class="btn btn-outline" onclick="ProVentaAuthorizationUI.previousOpeningQr()" ${openingQrIndex === 0 ? 'disabled' : ''}>Anterior</button><button type="button" class="btn btn-primary" onclick="ProVentaAuthorizationUI.startOpeningQrSequence()">${openingQrTimer ? 'Detener secuencia' : 'Reproducir secuencia'}</button><button type="button" class="btn btn-outline" onclick="ProVentaAuthorizationUI.nextOpeningQr()" ${openingQrIndex === openingQrPieces.length - 1 ? 'disabled' : ''}>Siguiente</button></div>`;
    target.style.display = 'block';
    target.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function showOpeningQr(bundleJson) {
    const qr = window.ProControlLocalQR;
    if (!qr || typeof qr.splitOpeningBundle !== 'function') throw new Error('No está disponible el generador local de QR para aperturas completas.');
    openingQrPieces = qr.splitOpeningBundle(bundleJson);
    openingQrIndex = 0;
    if (!openingQrPieces.length) throw new Error('El paquete de apertura no generó cuadros QR.');
    renderOpeningQr();
  }

  function nextOpeningQr() {
    if (!openingQrPieces.length) return;
    openingQrIndex = (openingQrIndex + 1) % openingQrPieces.length;
    renderOpeningQr();
  }

  function previousOpeningQr() {
    if (!openingQrPieces.length) return;
    openingQrIndex = (openingQrIndex + openingQrPieces.length - 1) % openingQrPieces.length;
    renderOpeningQr();
  }

  function startOpeningQrSequence() {
    if (openingQrTimer) {
      clearInterval(openingQrTimer);
      openingQrTimer = null;
    } else {
      openingQrTimer = setInterval(() => {
        openingQrIndex = (openingQrIndex + 1) % openingQrPieces.length;
        renderOpeningQr();
      }, 2500);
    }
    renderOpeningQr();
  }

  function closeOpeningQr() {
    if (openingQrTimer) clearInterval(openingQrTimer);
    openingQrTimer = null;
    openingQrPieces = [];
    openingQrIndex = 0;
    const target = $('proventa-opening-qr-wrap');
    if (target) { target.innerHTML = ''; target.style.display = 'none'; }
  }

  async function issueShiftPermit() {
    try {
      const posId = requireCurrentPos();
      const authToken = await requireOwnerSession();
      const select = $('proventa-shift-device');
      const deviceId = String(select && select.value || '');
      const deviceRow = authorizationRows.find(row => row.status === 'active' && row.deviceId === deviceId && (Number(row.protocolVersion) >= 5 || String(row.authorizedPosId || '') === posId));
      if (!deviceRow) throw new Error('Selecciona un teléfono activo de esta instalación. Si es una autorización antigua, debe pertenecer a este POS.');
      const startsText = String($('proventa-shift-starts') && $('proventa-shift-starts').value || '');
      const endsText = String($('proventa-shift-ends') && $('proventa-shift-ends').value || '');
      const startsAt = Date.parse(startsText);
      const endsAt = Date.parse(endsText);
      if (!Number.isFinite(startsAt) || !Number.isFinite(endsAt) || endsAt <= startsAt || endsAt - startsAt > 24 * 60 * 60 * 1000) {
        throw new Error('Revisa la fecha y hora. El fin debe ser posterior al inicio y el turno no puede superar 24 horas.');
      }
      const listing = await api().listShiftPermits({ posId, authToken });
      if (!listing || listing.ok !== true) throw new Error(listing && listing.code || 'SHIFT_PERMIT_LIST_FAILED');
      const lastSequence = (listing.permits || []).filter(row => row.deviceId === deviceId && row.posId === posId)
        .reduce((max, row) => Math.max(max, Number(row.sequence) || 0), 0);
      const issued = await api().issueShiftPermit({
        authToken, posId, deviceId, employee: deviceRow.employeeName,
        startsAt, endsAt, sequence: lastSequence + 1,
        emergency: { enabled: false, maxSales: 0, expiresAt: null, reason: null }
      });
      if (!issued || issued.ok !== true || !issued.permitId) throw new Error(issued && issued.code || 'SHIFT_PERMIT_ISSUE_FAILED');
      setShiftMessage('Permiso creado. Se está exportando y verificando el archivo…');
      await exportPermit(issued.permitId, posId, deviceId, authToken);
    } catch (error) { if (!error || !error.canceled) setShiftMessage((error && (error.message || error.code)) || 'No se pudo crear el permiso.', true); }
  }

  async function retryShiftPermitExport() {
    try {
      const posId = requireCurrentPos();
      const authToken = await requireOwnerSession();
      if (!pendingShiftPermit || pendingShiftPermit.posId !== posId) throw new Error('No hay un permiso pendiente de exportación para este POS. Usa el registro de permisos disponibles para recuperar uno guardado anteriormente.');
      const exported = await exportPermit(pendingShiftPermit.permitId, posId, pendingShiftPermit.deviceId, authToken);
      if (exported) await refreshShiftPanel();
    } catch (error) { if (!error || !error.canceled) setShiftMessage((error && (error.message || error.code)) || 'No se pudo reintentar la exportación.', true); }
  }

  async function exportExistingShiftPermit(permitId, deviceId) {
    try {
      const posId = requireCurrentPos();
      const authToken = await requireOwnerSession();
      const row = shiftPermitRows.find(item => item.permitId === permitId && item.deviceId === deviceId && item.posId === posId);
      if (!row || row.status !== 'issued' || Number(row.endsAt) <= Date.now()) {
        throw new Error('Ese permiso no está disponible para exportación en este POS. Actualiza el registro y comprueba su vigencia.');
      }
      const exported = await exportPermit(permitId, posId, deviceId, authToken);
      if (exported) await refreshShiftPanel();
    } catch (error) { if (!error || !error.canceled) setShiftMessage((error && (error.message || error.code)) || 'No se pudo recuperar el permiso.', true); }
  }

  function validateCloseReport(pos, pkg) {
    if (!pkg || pkg.type !== 'shift_close' || !pkg.payload || typeof pkg.payload !== 'object') throw new Error('El archivo importado no es un paquete firmado de cierre de turno. No se modificó el inventario.');
    const payload = pkg.payload;
    const shift = payload.shift;
    const report = payload.closingReport;
    if (!shift || !report || typeof report !== 'object') throw new Error('El paquete no contiene el turno y el informe de cierre requeridos. No se modificó el inventario.');
    const posId = String(pos && pos.id || '');
    if (!posId || String(payload.shiftPermitId || '') !== String(shift.permitId || '') ||
        String(shift.posId || '') !== posId || String(report.posId || '') !== posId ||
        String(report.permitId || '') !== String(shift.permitId || '') || String(report.shiftId || '') !== String(shift.id || '')) {
      throw new Error('El cierre pertenece a otro POS, permiso o turno. Abre el POS correcto; no se modificó ningún inventario.');
    }
    const rows = report.products;
    if (!Array.isArray(rows)) throw new Error('El informe no contiene la lista de cantidades finales. No se modificó el inventario.');
    const current = Array.isArray(pos.inventory) ? pos.inventory : [];
    const expected = new Map();
    for (const item of current) {
      const id = String(item && item.productId || '');
      if (!id || expected.has(id)) throw new Error('El inventario actual del POS tiene un producto sin ID o IDs repetidos. No se aplicó el cierre.');
      expected.set(id, String(item.unit || ''));
    }
    const seen = new Set();
    const updates = [];
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (!row || typeof row !== 'object' || Array.isArray(row)) throw new Error(`La fila ${i + 1} del informe no es un objeto válido. No se aplicó el cierre.`);
      const id = String(row.productId || '');
      if (!id || seen.has(id)) throw new Error(`La fila ${i + 1} tiene un ID vacío o repetido. No se aplicó el cierre.`);
      seen.add(id);
      if (!expected.has(id)) throw new Error(`El producto ${String(row.name || id)} no pertenece al inventario actual de este POS. No se aplicó el cierre.`);
      if (String(row.unit || '') !== expected.get(id)) throw new Error(`La unidad de ${String(row.name || id)} no coincide con el registro local. No se aplicó el cierre.`);
      const quantity = row.finalQuantityMicros;
      if (!Number.isSafeInteger(quantity) || quantity < 0) throw new Error(`La cantidad final de ${String(row.name || id)} no es un entero seguro de microunidades. No se aplicó el cierre.`);
      updates.push({ productId: id, qty: quantity / 1000000 });
    }
    const missing = [...expected.keys()].filter(id => !seen.has(id));
    if (missing.length || seen.size !== expected.size) throw new Error(`El informe no coincide con el inventario del POS: faltan ${missing.length} productos o hay elementos adicionales. No se aplicó el cierre.`);
    return { posId, permitId: String(shift.permitId), shiftId: String(shift.id), updates };
  }

  async function importShiftClose() {
    let packageId = '';
    try {
      const posId = requireCurrentPos();
      const authToken = await requireOwnerSession();
      setShiftMessage(`Selecciona el archivo de cierre exportado desde ProVenta. Solo se procesará el POS ${currentPosName}…`);
      const imported = await api().importFile({ authToken });
      if (!imported || imported.ok !== true) {
        if (imported && imported.canceled) return;
        throw new Error((imported && imported.code) || 'No se pudo importar el archivo de cierre.');
      }
      packageId = String(imported.packageId || '');
      if (!packageId) throw new Error('ProControl no devolvió el identificador del paquete importado. No se modificó el inventario.');
      const fetched = await api().getPackage(packageId);
      const pkg = fetched && fetched.package;
      if (!fetched || fetched.ok !== true || !pkg) throw new Error(fetched && fetched.code || 'No se pudo volver a leer el paquete guardado en ProControl.');
      if (pkg.type !== 'shift_close') throw new Error(`El archivo contiene una operación «${String(pkg.type || 'sin tipo')}», no un cierre. No se modificó el inventario.`);
      if (pkg.status === 'conflict' || pkg.status === 'rejected') throw new Error(`ProControl mantiene este paquete con estado ${pkg.status}; no se puede aplicar.`);
      const state = typeof appState !== 'undefined' ? appState : null;
      const selectedIndex = state ? Number(state.selectedPOSIndex) : -1;
      const currentPos = state && Array.isArray(state.pointsOfSale) && Number.isInteger(selectedIndex) ? state.pointsOfSale[selectedIndex] : null;
      if (!currentPos || String(currentPos.id || '') !== posId) throw new Error('El POS activo cambió durante la importación. Selecciona de nuevo el POS de destino; no se modificó el inventario.');
      const validated = validateCloseReport(currentPos, pkg);
      const payloadHash = String(pkg.payloadHash || '');
      if (!/^[a-f0-9]{64}$/i.test(payloadHash)) throw new Error('El paquete guardado no contiene una huella SHA-256 reconocible. No se aplicó el cierre.');

      // Aceptar y registrar la conciliación antes de tocar stock. La importación
      // ya verificó criptográficamente la firma y el hash en el proceso principal.
      if (pkg.status === 'pending_review' || pkg.status === 'conflict') {
        const decision = await api().decidePackage({ packageId, decision: 'accepted_for_reconciliation', note: 'Cierre validado contra el inventario del POS de destino.', authToken });
        if (!decision || decision.ok !== true) throw new Error(decision && decision.code || 'No se pudo aceptar el cierre para conciliación.');
      }
      const begin = await api().beginPackageApply({ packageId, authToken });
      if (!begin || begin.ok !== true) throw new Error(begin && begin.code || 'No se pudo iniciar la conciliación del cierre.');

      // La marca "reconciled" NO se escribe todavía en el puente SQLite:
      // primero se guarda el inventario y el recibo idempotente mediante DataStore.save().
      // Así, si el disco falla, el paquete continúa siendo reintentable en ProControl.
      const receiptList = Array.isArray(currentPos.proventaClosureReceipts) ? currentPos.proventaClosureReceipts : [];
      const prior = receiptList.find(item => item && item.packageId === packageId);
      if (prior && prior.payloadHash !== payloadHash) {
        try { await api().failPackageApply({ packageId, authToken, errorCode: 'SHIFT_CLOSE_RECEIPT_HASH_CONFLICT' }); } catch (_) {}
        throw new Error('Este identificador de cierre ya existe con otra huella. Se bloqueó para evitar aplicar datos distintos.');
      }
      if (!prior) {
        const updatesById = new Map(validated.updates.map(item => [item.productId, item.qty]));
        const tx = DataStore.transaction('proventa-shift-close-reconcile', ['pointsOfSale', 'auditLog'], () => {
          const latestIndex = Number(appState.selectedPOSIndex);
          const targetPos = Array.isArray(appState.pointsOfSale) ? appState.pointsOfSale[latestIndex] : null;
          if (!targetPos || String(targetPos.id || '') !== posId || !Array.isArray(targetPos.inventory)) throw new Error('El POS de destino cambió antes de guardar.');
          const liveIds = targetPos.inventory.map(item => String(item && item.productId || ''));
          if (liveIds.some(id => !id) || new Set(liveIds).size !== liveIds.length ||
              liveIds.length !== updatesById.size || liveIds.some(id => !updatesById.has(id))) {
            throw new Error('El inventario del POS cambió mientras se importaba el cierre. Se canceló la actualización completa; vuelve a revisar el POS y el archivo.');
          }
          for (const item of targetPos.inventory) {
            const id = String(item && item.productId || '');
            item.qty = updatesById.get(id);
          }
          targetPos.proventaClosureReceipts = Array.isArray(targetPos.proventaClosureReceipts) ? targetPos.proventaClosureReceipts : [];
          targetPos.proventaClosureReceipts.push({ packageId, payloadHash, permitId: validated.permitId, shiftId: validated.shiftId, appliedAt: new Date().toISOString() });
          if (!History.logEvent('correction', `Cierre de ProVenta conciliado para ${currentPosName}. Se actualizaron ${validated.updates.length} productos del POS.`, {
            source: 'proventa_shift_close', packageId, payloadHash, posId, permitId: validated.permitId, shiftId: validated.shiftId,
            changedProductCount: validated.updates.length, inventoryChanged: true
          })) throw new Error('ProControl no confirmó en disco el inventario y el historial. La transacción se revirtió.');
        });
        if (!tx || tx.ok !== true) {
          try {
            await api().failPackageApply({ packageId, authToken, errorCode: 'SHIFT_CLOSE_LOCAL_INVENTORY_SAVE_FAILED' });
          } catch (_) { /* el cierre firmado sigue guardado; se puede volver a importar */ }
          throw new Error(tx && tx.error && tx.error.message || 'No se pudo guardar el cierre; la operación se revirtió y el archivo puede volver a importarse.');
        }
      }

      // El inventario durable ya existe (o ya existía con el mismo packageId/hash).
      // Ahora sí se confirma la conciliación en el puente y se libera el acuse.
      const applied = await api().markPackageApplied({
        packageId, authToken,
        result: { type: 'shift_close', payloadHash, newOperations: validated.updates.length, changedStock: true }
      });
      if (!applied || applied.ok !== true) {
        try { await api().failPackageApply({ packageId, authToken, errorCode: 'SHIFT_CLOSE_RECONCILIATION_MARK_FAILED' }); } catch (_) {}
        throw new Error(applied && applied.code || 'El inventario quedó guardado, pero ProControl no pudo marcar la conciliación. Importa de nuevo el mismo cierre para completar sin duplicar movimientos.');
      }
      if (typeof Inventory !== 'undefined' && typeof Inventory.refreshVisibleViews === 'function') Inventory.refreshVisibleViews();

      const closureResult = await api().listPendingClosures({ posId, authToken });
      const closure = closureResult && (closureResult.closures || []).find(row => row.packageId === packageId && row.posId === posId);
      if (closure) {
        const confirmed = await api().decidePendingClosure({ closureId: closure.closureId, decision: 'confirmed', posId, note: 'Inventario final del POS aplicado de forma transaccional.', authToken });
        if (!confirmed || confirmed.ok !== true) throw new Error(confirmed && confirmed.code || 'El inventario se aplicó, pero falta confirmar el cierre en el control de turnos. Importa de nuevo el mismo archivo para completar el paso pendiente.');
      }
      // Si el cierre ya fue confirmado en un intento anterior, la bandeja pendiente
      // queda vacía. La creación del acuse es idempotente y devuelve el acuse guardado.
      const acknowledgement = await api().createPackageAcknowledgement({ packageId, authToken });
      if (acknowledgement && acknowledgement.ok === true && acknowledgement.acknowledgement) {
        const savedAck = await api().savePackageAcknowledgement({ acknowledgement: acknowledgement.acknowledgement, authToken });
        if (!savedAck || savedAck.ok !== true) {
          if (savedAck && savedAck.canceled) setShiftMessage(`Cierre aplicado al POS ${currentPosName}: ${validated.updates.length} productos actualizados. El acuse firmado no se exportó porque se canceló el selector; permanece guardado en ProControl.`, false);
          else setShiftMessage(`Cierre aplicado al POS ${currentPosName}: ${validated.updates.length} productos actualizados. No se pudo exportar el acuse (${savedAck && savedAck.code || 'error'}); permanece guardado en ProControl.`, true);
        } else {
          setShiftMessage(`Cierre conciliado y confirmado. Se actualizaron ${validated.updates.length} productos exclusivamente en ${currentPosName}. Acuse firmado exportado: ${savedAck.fileName}.`, false);
        }
      } else {
        setShiftMessage(`Inventario final aplicado al POS ${currentPosName}. No fue posible generar el acuse firmado (${acknowledgement && acknowledgement.code || 'error'}); el cierre permanece registrado para revisión.`, true);
      }
      await refreshShiftPanel();
    } catch (error) {
      if (!error || !error.canceled) setShiftMessage((error && (error.message || error.code)) || 'No se pudo importar el cierre.', true);
    }
  }

  async function exportInventorySnapshot(authorizationId, deviceId) {
    try {
      const posId = requireCurrentPos();
      const authToken = await requireOwnerSession();
      const targetDevice = authorizationRows.find(row => row && row.deviceId === deviceId && row.status === 'active' &&
        (Number(row.protocolVersion) >= 5 || String(row.authorizedPosId || '') === String(posId)));
      if (!targetDevice) throw new Error('El teléfono no tiene una autorización activa para esta instalación y el POS seleccionado.');
      if (Number(targetDevice.encryptionConfigured) !== 1) throw new Error('No se pueden enviar datos: el teléfono no registró una clave de cifrado válida. Vuelve a importar su identidad .pvid y comprueba su ficha.');
      const result = await api().proventaExportInventorySnapshot({ deviceId, posId, authToken });
      if (!result || result.ok !== true) throw new Error(result && result.code || 'INVENTORY_SNAPSHOT_EXPORT_FAILED');
      const expiry = new Date(Number(result.expiresAt)).toLocaleString();
      setShiftMessage(`Paquete cifrado guardado: ${result.fileName}. POS: ${result.posName}. Productos: ${fmtNumber(result.productCount)}. Caduca: ${expiry}.`);
    } catch (error) { setShiftMessage((error && (error.message || error.code)) || 'No se pudo exportar el inventario cifrado.', true); }
  }
  async function exportSelectedInventorySnapshot() {
    const select = $('proventa-shift-device');
    const deviceId = String(select && select.value || '');
    if (!deviceId) { setShiftMessage('Selecciona un teléfono activo antes de preparar el inventario.', true); return; }
    await exportInventorySnapshot(null, deviceId);
  }

  window.ProVentaAuthorizationUI = {
    openAdmin,
    refreshAdmin: () => refreshAdmin().catch(showError),
    closeAdmin() { if (typeof UI !== 'undefined') UI.showPage('page-dashboard'); },
    async openForCurrentPOS(mode) {
      try {
        const posId = requireCurrentPos();
        if (typeof Auth === 'undefined' || !Auth.requireRole(['Dueño'], 'Solo el Dueño puede emitir permisos de turno e importar cierres.')) return;
        const overlay = $('proventa-auth-overlay');
        if (!overlay) throw new Error('No se encontró el panel de operaciones del POS.');
        overlay.style.display = 'flex';
        if (ownerSession && ownerSession.expiresAt <= Date.now() + 5000) ownerSession = null;
        await requireOwnerSession();
        const posLabel = $('proventa-shift-pos');
        if (posLabel) posLabel.textContent = `${currentPosName} · ${posId}`;
        await refreshShiftPanel();
        initializeShiftDateFields();
        if (mode === 'close') { const target = $('proventa-shift-message'); if (target) target.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
        else if (mode === 'open') { const target = $('proventa-shift-device'); if (target) target.focus(); }
      } catch (error) { setShiftMessage((error && (error.message || error.code)) || 'No se pudo abrir la gestión de turno.', true); }
    },
    close() {
      closeOpeningQr();
      const overlay = $('proventa-auth-overlay'); if (overlay) overlay.style.display = 'none';
      currentPosId = null; currentPosName = null; pendingShiftPermit = null;
    },
    closeOpeningQr, nextOpeningQr, previousOpeningQr, startOpeningQrSequence,
    generate, showQr, hideQr, issueRenewal, confirmEnrollment, revoke, startReplacement, renderDeviceDetail,
    exportInventorySnapshot, exportSelectedInventorySnapshot,
    issueShiftPermit, retryShiftPermitExport, exportExistingShiftPermit, importShiftClose,
    refreshShiftPanel: () => refreshShiftPanel().catch(error => setShiftMessage((error && (error.message || error.code)) || 'No se pudo actualizar el panel.', true))
  };

  document.addEventListener('input', event => {
    if (event.target && event.target.id === 'proventa-admin-search') renderAdminDevices();
  });
  document.addEventListener('change', event => {
    if (event.target && event.target.id === 'proventa-admin-status-filter') renderAdminDevices();
  });
  document.addEventListener('click', event => {
    const adminButton = event.target && event.target.closest ? event.target.closest('[data-proventa-admin-action]') : null;
    if (adminButton) {
      const action = adminButton.dataset.proventaAdminAction;
      const authId = adminButton.dataset.authId;
      if (action === 'detail') renderDeviceDetail(authId);
      if (action === 'renew') issueRenewal(authId);
      if (action === 'confirm') {
        const row = getAuthorization(authId);
        if (row) latestAuthorization = { authorizationId:row.authorizationId, employeeName:row.employeeName, deviceId:row.deviceId, status:'pending' };
        confirmEnrollment();
      }
      if (action === 'revoke') revoke(authId);
      if (action === 'replace') startReplacement(authId, (getAuthorization(authId) || {}).employeeName);
      return;
    }
    const shiftButton = event.target && event.target.closest ? event.target.closest('[data-proventa-action]') : null;
    if (!shiftButton) return;
    if (shiftButton.dataset.proventaAction === 'retry-permit-export') exportExistingShiftPermit(shiftButton.dataset.permitId, shiftButton.dataset.deviceId);
  });
})();
