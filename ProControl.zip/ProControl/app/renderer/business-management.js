/* ProControl Gestión Empresarial — módulo local, sin servicios externos.
 * Datos separados para no alterar el esquema ni las operaciones existentes.
 */
(function (root) {
'use strict';
const STORAGE_KEY = 'pc_business_management_v1';
const CURRENCIES = ['CUP', 'USD', 'EUR', 'MLC', 'OTRA'];
const CATEGORIES = ['Ventas', 'Compras', 'Salarios', 'Transporte', 'Servicios', 'Mermas', 'Alquiler', 'Mantenimiento', 'Otros'];
function decodeProControlStoredValue(raw) {
  if (raw == null || String(raw) === '') return null;
  const text = String(raw);
  try {
    const first = atob(text);
    const separator = first.indexOf(':');
    if (separator > 0 && first.slice(0, separator) === 'PROCONTROL_SECRET_2026') {
      const json = decodeURIComponent(escape(atob(first.slice(separator + 1))));
      return JSON.parse(json);
    }
  } catch (_) { /* Puede ser JSON plano de una versión anterior. */ }
  try { return JSON.parse(text); } catch (_) { return null; }
}
function readProControlStoredArray(storage, key) {
  try {
    if (!storage || typeof storage.getItem !== 'function') return [];
    const decoded = decodeProControlStoredValue(storage.getItem(key));
    return Array.isArray(decoded) ? decoded : [];
  } catch (_) { return []; }
}
function isSalePendingClose(sale) {
  if (!sale || typeof sale !== 'object') return false;
  const status = cleanText(sale.status || '', 60).toLowerCase().replace(/_/g, '-');
  return status === 'pending-close' || sale.pending === true || sale.pendingReview === true;
}
const DEFAULTS = { version: 1, branches:[], accounts: [{id:'cash-cup',name:'Caja principal',currency:'CUP',opening:0,active:true}], transactions:[], receivables:[], payables:[], suppliers:[], rates:[{date:new Date().toISOString().slice(0,10),currency:'USD',rate:0,source:'Tasa inicial por configurar'}], audit:[], settings:{lowStockDays:14} };
const clone = value => JSON.parse(JSON.stringify(value));
const money = value => root.ProControlNumberFormat
  ? root.ProControlNumberFormat.formatMoney(value)
  : new Intl.NumberFormat('en-US', { useGrouping:true, minimumFractionDigits:2, maximumFractionDigits:2 }).format(Number(value)||0);
const grouped = (value, digits = 2) => root.ProControlNumberFormat
  ? root.ProControlNumberFormat.formatNumber(value, digits)
  : new Intl.NumberFormat('en-US', { useGrouping:true, maximumFractionDigits:Math.min(2, digits) }).format(Number(value)||0);
const id = prefix => prefix+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9);
const cleanText = (value, max=180) => String(value == null ? '' : value).trim().slice(0,max);
function cleanCurrencyLabel(value){return cleanText(value,40).replace(/\s+/g,' ').trim();}
function rateCurrencyLabel(record){return record&&record.currency==='OTRA'?(cleanCurrencyLabel(record.customCurrency)||'OTRA'):String(record&&record.currency||'').toUpperCase();}
const positive = value => Number.isFinite(Number(value)) && Number(value) > 0;
function validateState(s) {
  if (!s || typeof s !== 'object' || s.version !== 1) throw new Error('El archivo no tiene un formato de Gestión Empresarial reconocido.');
  if(!s.settings || typeof s.settings!=='object' || Array.isArray(s.settings)) throw new Error('La configuración del módulo no es válida.');
  if(!Array.isArray(s.branches)) s.branches=[]; if(s.branches.length>1000)throw new Error('El respaldo contiene demasiados establecimientos.');
  for (const k of ['accounts','transactions','receivables','payables','suppliers','rates','audit']) if (!Array.isArray(s[k])) throw new Error('El archivo contiene una sección inválida: '+k+'.');
  if (s.accounts.length > 5000 || s.transactions.length > 200000 || s.audit.length > 500000) throw new Error('El archivo supera los límites de seguridad admitidos.');
  const accountIds=new Set(); for (const a of s.accounts) { if (!a || !a.id || !cleanText(a.name,100) || !CURRENCIES.includes(a.currency) || !Number.isFinite(Number(a.opening)) || accountIds.has(a.id)) throw new Error('Hay una cuenta inválida o duplicada en el archivo.'); accountIds.add(a.id); }
  const transactionIds=new Set(); for (const t of s.transactions) { if (!t || !t.id || transactionIds.has(t.id) || !['income','expense','transfer','settlement'].includes(t.type) || !positive(t.amount) || !CURRENCIES.includes(t.currency) || !/^\d{4}-\d{2}-\d{2}$/.test(t.date)) throw new Error('Hay un movimiento inválido o duplicado en el archivo.'); transactionIds.add(t.id); if(t.accountId&&!accountIds.has(t.accountId))throw new Error('Un movimiento referencia una cuenta inexistente.'); if(t.type==='transfer'&&(!accountIds.has(t.toAccountId)||t.toAccountId===t.accountId))throw new Error('Hay una transferencia con cuenta de destino inválida.'); if(t.type==='transfer'&&s.accounts.find(a=>a.id===t.toAccountId)?.currency!==t.currency)throw new Error('La transferencia usa una moneda incompatible con la cuenta de destino.'); }
  for (const d of [...s.receivables,...s.payables]) if (!d || !d.id || !cleanText(d.name,180) || !positive(d.amount) || !CURRENCIES.includes(d.currency) || !Number.isFinite(Number(d.paid||0)) || Number(d.paid||0)<0 || Number(d.paid||0)>Number(d.amount)) throw new Error('Hay una cuenta por cobrar o pagar inválida.');
  for (const r of s.rates) if (!r || !CURRENCIES.includes(r.currency) || !/^\d{4}-\d{2}-\d{2}$/.test(r.date) || !Number.isFinite(Number(r.rate)) || Number(r.rate)<0 || (r.currency==='OTRA' && r.customCurrency!=null && (typeof r.customCurrency!=='string' || cleanCurrencyLabel(r.customCurrency).length>40))) throw new Error('Hay una tasa de cambio inválida.');
  return s;
}
function balanceForAccount(state, accountId) {
  const a=state.accounts.find(x=>x.id===accountId); if(!a) return 0;
  let total=Number(a.opening)||0;
  for(const t of state.transactions) if(t.currency===a.currency && t.status!=='pending-approval') {
    if(t.accountId===accountId && (t.type==='income' || (t.type==='settlement' && t.debtKind==='receivables'))) total+=Number(t.amount)||0;
    if(t.accountId===accountId && (t.type==='expense' || (t.type==='settlement' && t.debtKind==='payables'))) total-=Number(t.amount)||0;
    if(t.type==='transfer' && t.toAccountId===accountId) total+=Number(t.amount)||0;
    if(t.type==='transfer' && t.accountId===accountId) total-=Number(t.amount)||0;
  }
  return Math.round((total+Number.EPSILON)*100)/100;
}
function openDebts(state, type) { return state[type].reduce((sum,d)=>sum+Math.max(0,Number(d.amount)-Number(d.paid||0)),0); }
function canApproveTransfer(transfer, user) { return Boolean(transfer && transfer.type==='transfer' && transfer.status==='pending-approval' && cleanText(user,80) && cleanText(user,80)!==cleanText(transfer.createdBy,80)); }
function simulatePrice(quantity,currentPrice,newPrice,unitCost){
 const q=Number(quantity),p0=Number(currentPrice),p1=Number(newPrice),c=Number(unitCost);
 if(![q,p0,p1,c].every(Number.isFinite)||q<0||p0<0||p1<0||c<0)throw new Error('Introduce cantidades y precios válidos no negativos.');
 const currentRevenue=q*p0,newRevenue=q*p1,currentGrossProfit=q*(p0-c),newGrossProfit=q*(p1-c);
 const currentMargin=p0>0?((p0-c)/p0)*100:null,newMargin=p1>0?((p1-c)/p1)*100:null;
 return {currentRevenue,newRevenue,currentGrossProfit,newGrossProfit,currentMargin,newMargin,grossProfitDelta:newGrossProfit-currentGrossProfit,marginDelta:currentMargin===null||newMargin===null?null:newMargin-currentMargin,assumption:'Importes en CUP. Mantiene constante la cantidad vendida; no predice cómo reaccionará la demanda al precio.'};
}
function priceSimulatorProductDefaults(product){
 if(!product||typeof product!=='object')throw new Error('Selecciona un producto válido del Almacén Central.');
 const readNumber=keys=>{for(const key of keys){const raw=product[key];if(raw===null||raw===undefined||String(raw).trim()==='')continue;const value=Number(raw);if(Number.isFinite(value)&&value>=0)return value;}return null;};
 const currentPriceRaw=readNumber(['sale','salePrice','cashPrice','price']);
 const unitCost=readNumber(['cost','unitCost','costPrice','purchasePrice','acquisitionCost']);
 const stock=readNumber(['qty','quantity','stock']);
 const currentPrice=currentPriceRaw!==null&&currentPriceRaw>0?currentPriceRaw:null;
 return {
  productId:cleanText(product.productId||product.id||'',160)||null,
  name:cleanText(product.name||product.productName||'Producto',160),
  unit:cleanText(product.unit||product.baseUnit||'u',30)||'u',
  currentPrice,unitCost,stock
 };
}
function simulateStock(currentStock,purchaseQty,dailyDemand,leadDays){
 const values=[currentStock,purchaseQty,dailyDemand,leadDays].map(Number);
 if(!values.every(Number.isFinite)||values.some(v=>v<0))throw new Error('Introduce cantidades y días válidos no negativos.');
 const [stock,order,demand,lead]=values,after=stock+order,estimatedDemandDuringLead=demand*lead;
 const projectedBalanceAtLead=after-estimatedDemandDuringLead;
 const shortageAtLead=Math.max(0,-projectedBalanceAtLead),surplusAtLead=Math.max(0,projectedBalanceAtLead);
 return {stockAfterPurchase:after,coverageDays:demand>0?after/demand:null,estimatedDemandDuringLead,projectedBalanceAtLead,stockAfterLead:Math.max(0,projectedBalanceAtLead),shortageAtLead,surplusAtLead};
}
function firstNumericField(record, keys) {
  const values=(keys||[]).map(key=>record&&record[key]).filter(value=>value!==null&&value!==undefined&&String(value).trim()!==''&&Number.isFinite(Number(value))&&Number(value)>=0).map(Number);
  return values.find(value=>value>0) ?? values[0] ?? NaN;
}
function buildMarginAnalysis(products) {
  return (Array.isArray(products)?products:[]).map(p=>{
    const cost=firstNumericField(p,['cost','unitCost','costPrice','purchasePrice','acquisitionCost']);
    const cashPrice=firstNumericField(p,['sale','salePrice','cashPrice','price']);
    const transferPrice=firstNumericField(p,['saleTransf','saleTransfer','transferSalePrice','saleTransferPrice']);
    const cashMargin=Number.isFinite(cost)&&cost>=0&&cashPrice>0?((cashPrice-cost)/cashPrice)*100:null;
    const transferMargin=Number.isFinite(cost)&&cost>=0&&transferPrice>0?((transferPrice-cost)/transferPrice)*100:null;
    const margin=cashMargin!==null?cashMargin:transferMargin;
    return {productId:cleanText(p&& (p.productId||p.id)||'',160)||null,name:cleanText(p&&(p.name||p.productName)||'Producto',160),cost,cashPrice,transferPrice,cashMargin,transferMargin,margin};
  }).filter(row=>Number.isFinite(row.cost)&&row.cost>=0&&((Number.isFinite(row.cashPrice)&&row.cashPrice>0)||(Number.isFinite(row.transferPrice)&&row.transferPrice>0)));
}
function abcAnalysis(products) {
  const rows=(Array.isArray(products)?products:[]).map(p=>{
    const soldValue=p.sold??p.quantitySold??p.unitsSold??p.qty??p.quantity??p.units??0;
    const sold=Math.max(0,Number(soldValue)||0);
    return {productId:cleanText(p.productId||p.id||'',160)||null,name:cleanText(p.name||p.productName||'Producto sin nombre',160),sold,qty:sold,revenue:Math.max(0,Number(p.revenue??p.salesValue??0)||0)};
  });
  const total=rows.reduce((sum,p)=>sum+(p.revenue>0?p.revenue:0),0); rows.sort((a,b)=>b.revenue-a.revenue);
  let cumulative=0;
  return rows.map(p=>{const value=p.revenue>0?p.revenue:0;const before=total>0?cumulative/total:0;cumulative+=value;const share=total>0?value/total:0;const cum=total>0?cumulative/total:0;return {...p,share,cumulativeShare:cum,category:total<=0||value<=0?'Sin datos':before<.8?'A':before<.95?'B':'C'};});
}
function healthScore(metrics) {
  const checks=[]; let score=100;
  const add=(label, penalty, ok, detail)=>{ if(!ok) score-=penalty; checks.push({label,ok,detail}); };
  add('Datos suficientes',20,metrics.hasTransactions || metrics.hasInventory,'Todavía hay pocos datos para evaluar el negocio con confianza.');
  add('Liquidez registrada',25,metrics.cashAvailable>=0,metrics.hasTransactions?(metrics.cashAvailable<0?'La liquidez registrada es negativa.':'La liquidez registrada no es negativa.'):'No hay movimientos económicos suficientes para evaluar la liquidez.');
  add('Deudas vencidas',20,metrics.overdue===0,metrics.overdue>0?'Hay cuentas vencidas por revisar.':'No se han registrado cuentas vencidas.');
  add('Movimientos pendientes',15,metrics.pending===0,metrics.pending>0?'Hay operaciones que necesitan revisión.':'No hay operaciones pendientes registradas.');
  add('Inventario',20,metrics.stockAlerts===0,metrics.stockAlerts>0?'Hay productos que podrían necesitar reposición.':'No hay productos en el umbral de reposición con los datos disponibles.');
  const enough=Boolean(metrics.hasTransactions);
  return {score:enough?Math.max(0,Math.min(100,score)):null,checks};
}
function healthAssessment(metrics) {
  const m=metrics&&typeof metrics==='object'?metrics:{};
  const hasTransactions=Boolean(m.hasTransactions),hasInventory=Boolean(m.hasInventory);
  const includeLiquidity=m.includeLiquidity!==false,includePendingOperations=m.includePendingOperations!==false;
  const liquidityKnown=m.liquidityKnown!==false&&Number.isFinite(Number(m.cashAvailable));
  const cashAvailable=Number(m.cashAvailable),overdue=Math.max(0,Number(m.overdue)||0),pending=Math.max(0,Number(m.pending)||0),stockAlerts=Math.max(0,Number(m.stockAlerts)||0);
  const checks=[];let urgent=false,attention=false;
  if(includeLiquidity){
    if(!liquidityKnown)checks.push({label:'Dinero disponible',state:'unknown',detail:cleanText(m.liquidityReason||'No se puede calcular con seguridad; revisa los saldos y las tasas necesarias.',240)});
    else if(hasTransactions&&cashAvailable<0){urgent=true;checks.push({label:'Dinero disponible',state:'risk',detail:'La liquidez estimada después de los pagos conocidos es negativa.'});}
    else checks.push({label:'Dinero disponible',state:hasTransactions?'ok':'unknown',detail:hasTransactions?'La liquidez estimada no es negativa después de los compromisos conocidos.':'Todavía no hay una base confirmada para evaluar la liquidez.'});
  }
  if(overdue>0){attention=true;checks.push({label:'Cuentas vencidas',state:'attention',detail:`${overdue} cuenta(s) por cobrar o pagar tienen saldo vencido; revisa cada vencimiento.`});}
  else checks.push({label:'Cuentas vencidas',state:'ok',detail:'No hay cuentas vencidas registradas en este módulo.'});
  if(includePendingOperations){
    if(pending>0){attention=true;checks.push({label:'Operaciones por revisar',state:'attention',detail:`${pending} operación(es) necesitan revisión o segunda autorización.`});}
    else checks.push({label:'Operaciones por revisar',state:'ok',detail:'No hay operaciones pendientes de autorización registradas.'});
  }
  if(!hasInventory)checks.push({label:'Inventario',state:'unknown',detail:'No hay productos disponibles para evaluar las necesidades de reposición.'});
  else if(stockAlerts>0){attention=true;checks.push({label:'Inventario',state:'attention',detail:`${stockAlerts} producto(s) tienen una sugerencia de reposición; comprueba existencias y demanda antes de decidir.`});}
  else checks.push({label:'Inventario',state:'ok',detail:'No hay sugerencias de reposición con la configuración y los datos disponibles.'});

  const requireMainOperationalEvidence=m.requireMainOperationalEvidence===true;
  const hasSalesEvidence=m.hasSalesEvidence===true,hasClosingEvidence=m.hasClosingEvidence===true;
  const closingDifferences=Math.max(0,Number(m.closingDifferences)||0),pendingSales=Math.max(0,Number(m.pendingSales)||0),movementReviewCount=Math.max(0,Number(m.movementReviewCount)||0),negativeMargins=Math.max(0,Number(m.negativeMargins)||0);
  if(requireMainOperationalEvidence){
    if(hasSalesEvidence)checks.push({label:'Ventas y demanda',state:'ok',detail:cleanText(m.salesEvidenceDetail||'Hay ventas registradas o cierres históricos IPV que permiten estimar movimiento.',240)});
    else checks.push({label:'Ventas y demanda',state:'unknown',detail:'No hay tickets ni cierres con productos vendidos suficientes para evaluar la demanda del inventario.'});
    if(!hasClosingEvidence)checks.push({label:'Cierres de caja',state:'unknown',detail:'Todavía no hay cierres registrados para comparar los resultados del punto de venta.'});
    else if(closingDifferences>0){attention=true;checks.push({label:'Diferencias de cierre',state:'attention',detail:`${closingDifferences} cierre(s) tienen una diferencia registrada distinta de cero. Revisa el cierre original; esta señal no demuestra por sí sola una irregularidad.`});}
    else checks.push({label:'Diferencias de cierre',state:'ok',detail:'Los cierres registrados no muestran diferencias numéricas distintas de cero.'});
    if(pendingSales>0){attention=true;checks.push({label:'Ventas por cerrar',state:'attention',detail:`${pendingSales} venta(s) están marcadas explícitamente como pendientes de cierre.`});}
    else checks.push({label:'Ventas por cerrar',state:'ok',detail:'No hay ventas marcadas explícitamente como pendientes de cierre.'});
    if(movementReviewCount>0&&hasSalesEvidence){attention=true;checks.push({label:'Movimiento de mercancía',state:'attention',detail:`${movementReviewCount} producto(s) con existencias requieren revisar ventas antiguas o historial de movimiento incompleto.`});}
    else if(!hasSalesEvidence)checks.push({label:'Movimiento de mercancía',state:'unknown',detail:'Sin ventas ni cierres con productos no puede determinarse qué mercancía está inmovilizada.'});
    else checks.push({label:'Movimiento de mercancía',state:'ok',detail:'No se han detectado productos que superen el umbral de revisión con el historial disponible.'});
    if(negativeMargins>0){attention=true;checks.push({label:'Productos con margen bruto negativo',state:'attention',detail:`${negativeMargins} producto(s) muestran un precio efectivo o de transferencia inferior al coste unitario registrado en CUP, incluido el Extra asignado.`});}
    else checks.push({label:'Productos con margen bruto negativo',state:'ok',detail:'No se detectaron márgenes brutos negativos con el coste y los precios CUP disponibles.'});
  }
  const enoughData=(!includeLiquidity||(hasTransactions&&liquidityKnown))&&hasInventory&&(!requireMainOperationalEvidence||(hasSalesEvidence&&hasClosingEvidence));
  let status,label,summary;
  if(urgent){status='risk';label='Necesita atención urgente';summary='La liquidez estimada disponible después de los pagos conocidos es negativa. Revisa los importes y vencimientos antes de asumir nuevos compromisos.';}
  else if(attention){status='attention';label='Hay asuntos por revisar';summary='Hay señales concretas que conviene revisar. La lista inferior explica cuáles son; no implica por sí sola que exista una irregularidad.';}
  else if(!enoughData){status='unknown';label='Datos insuficientes';summary='No hay información completa para declarar estable la situación. Registra o verifica los datos que faltan; no se asigna una calificación por defecto.';}
  else{status='stable';label='Sin asuntos prioritarios detectados';summary='Con los datos disponibles no se detectan asuntos prioritarios en las categorías que revisa este indicador. No es una garantía de rentabilidad ni una evaluación fiscal.';}
  return {status,label,summary,checks,enoughData};
}
function aggregateProductSales(products, sales) {
  const byId = new Map();
  const byName = new Map();
  const getRow = (map, key, productId = null) => {
    let row = map.get(key);
    if (!row) { row = { productId, sold: 0, revenue: 0, revenueKnown: true, lastSaleDate: null, hasLine: false }; map.set(key, row); }
    row.hasLine = true;
    return row;
  };
  for (const sale of Array.isArray(sales) ? sales : []) {
    if (!sale || typeof sale !== 'object' || !Array.isArray(sale.items)) continue;
    const sign = sale.kind === 'return' ? -1 : 1;
    for (const line of sale.items) {
      const productId = cleanText(line && (line.productId || line.productID || line.id), 160);
      const name = normalizeSupplierKey(cleanText(line && (line.name || line.productName || line.title), 160));
      if (!productId && !name) continue;
      const qty = Number(line.baseQty ?? line.quantity ?? line.qty ?? line.sold ?? line.unitsSold ?? line.quantitySold ?? line.units ?? 0);
      const hasRecordedCUP = line.lineTotalCUP != null && String(line.lineTotalCUP).trim() !== '' && Number.isFinite(Number(line.lineTotalCUP));
      const lineCurrency = cleanText(line.currency || sale.currency || '', 10).toUpperCase();
      const hasRecordedCUPNative = !hasRecordedCUP && lineCurrency === 'CUP' && line.lineTotal != null && String(line.lineTotal).trim() !== '' && Number.isFinite(Number(line.lineTotal));
      const amount = hasRecordedCUP ? Number(line.lineTotalCUP) : hasRecordedCUPNative ? Number(line.lineTotal) : null;
      const row = productId ? getRow(byId, productId, productId) : getRow(byName, name, null);
      if (Number.isFinite(qty)) row.sold += sign * Math.abs(qty);
      if (amount == null) row.revenueKnown = false;
      else row.revenue += sign * Math.abs(amount);
      if (sale.kind !== 'return') {
        const when = sale.ts || sale.date || sale.createdAt || '';
        const date = recordDateISO({ ts: when });
        if (date && (!row.lastSaleDate || date > row.lastSaleDate)) row.lastSaleDate = date;
      }
    }
  }
  const productRows = Array.isArray(products) ? products : [];
  const nameFrequencies = new Map();
  for (const product of productRows) {
    const key = normalizeSupplierKey(cleanText(product && (product.name || product.productName || 'Producto sin nombre'),160));
    if (key) nameFrequencies.set(key,(nameFrequencies.get(key)||0)+1);
  }
  return productRows.map(p => {
    const name = cleanText(p && (p.name || p.productName || 'Producto sin nombre'), 160);
    const productId = cleanText(p && (p.productId || p.id), 160);
    const nameKey = normalizeSupplierKey(name);
    const nameFrequency = nameFrequencies.get(nameKey) || 0;
    let ledger = productId ? byId.get(productId) : null;
    if (!ledger && nameFrequency === 1) ledger = byName.get(nameKey);
    if (ledger) return { productId: productId || ledger.productId || null, name, sold: Math.max(0, ledger.sold), revenue: ledger.revenueKnown ? Math.max(0, ledger.revenue) : 0, lastSaleDate: ledger.lastSaleDate, source: ledger.revenueKnown ? 'book' : 'none' };
    const explicitRevenue = Number(p && (p.revenue ?? p.salesValue));
    const hasExplicitRevenue = p && (p.revenue != null || p.salesValue != null) && Number.isFinite(explicitRevenue) && explicitRevenue >= 0;
    return { productId: productId || null, name, sold: Math.max(0, Number(p && (p.sold ?? p.unitsSold)) || 0), revenue: hasExplicitRevenue ? explicitRevenue : 0, lastSaleDate: null, source: hasExplicitRevenue ? 'product' : 'none' };
  });
}

function inventoryMovementAnalysis(products, sales, referenceDate, limitDays=30) {
  const rows = aggregateProductSales(products, sales);
  const ref = referenceDate ? new Date(referenceDate) : new Date();
  const today = Number.isFinite(ref.getTime()) ? ref : new Date();
  const threshold = Math.max(1, Math.min(3650, Number(limitDays) || 30));
  const productRows=Array.isArray(products)?products:[];
  const productsById = new Map(productRows.filter(p => p && (p.productId || p.id)).map(p => [String(p.productId || p.id), p]));
  const productsByName = new Map(), ambiguousNames = new Set();
  for(const product of productRows){const key=normalizeSupplierKey(cleanText(product&&(product.name||product.productName||'Producto sin nombre'),160));if(!key)continue;if(productsByName.has(key))ambiguousNames.add(key);else productsByName.set(key,product);}
  for(const key of ambiguousNames)productsByName.delete(key);
  return rows.map(row => {
    const nameKey=normalizeSupplierKey(row.name);
    const product = (row.productId && productsById.get(String(row.productId))) || productsByName.get(nameKey) || {};
    const stock = Math.max(0, Number(product.quantity ?? product.qty ?? product.stock ?? product.units ?? 0) || 0);
    const daysSinceSale = row.lastSaleDate ? Math.max(0, Math.floor((Date.UTC(today.getUTCFullYear(),today.getUTCMonth(),today.getUTCDate()) - Date.parse(row.lastSaleDate+'T00:00:00Z')) / 86400000)) : null;
    let movement;
    if (stock <= 0) movement = 'Sin existencias';
    else if (!Array.isArray(sales) || sales.length === 0) movement = 'Sin historial de ventas disponible';
    else if (!row.lastSaleDate) movement = 'Sin ventas registradas para este producto';
    else if (daysSinceSale >= threshold) movement = `Sin venta registrada en ${daysSinceSale} días`;
    else movement = 'Movimiento reciente';
    return { name: row.name, stock, lastSaleDate: row.lastSaleDate, daysSinceSale, movement, needsReview: stock > 0 && (daysSinceSale === null || daysSinceSale >= threshold), source: row.source };
  }).filter(r => r.stock > 0).sort((a,b) => {
    const aDays = a.daysSinceSale == null ? Number.POSITIVE_INFINITY : a.daysSinceSale;
    const bDays = b.daysSinceSale == null ? Number.POSITIVE_INFINITY : b.daysSinceSale;
    return bDays-aDays || a.name.localeCompare(b.name);
  });
}

function suggestReplenishment(products, sales, days=14, referenceDate=new Date(), options={}) {
  const rows=Array.isArray(products)?products:[],sourceSales=Array.isArray(sales)?sales:[];
  const ref=referenceDate instanceof Date?referenceDate:new Date(referenceDate),today=Number.isFinite(ref.getTime())?ref:new Date();
  const endDay=Date.UTC(today.getUTCFullYear(),today.getUTCMonth(),today.getUTCDate());
  const endISO=new Date(endDay).toISOString().slice(0,10),historyDays=Math.max(30,Math.min(365,Number(options.historyDays)||90));
  const cutoff90=new Date(endDay-(historyDays-1)*86400000).toISOString().slice(0,10),cutoff30=new Date(endDay-29*86400000).toISOString().slice(0,10);
  const hasAnyDatedSales=sourceSales.some(sale=>Boolean(recordDateISO(sale)));
  const byProduct=new Map(),nameFrequency=new Map();
  for(const product of rows){const key=normalizeSupplierKey(product&&(product.name||product.productName)||'');if(key)nameFrequency.set(key,(nameFrequency.get(key)||0)+1);}
  for(const sale of sourceSales){
    if(!sale||!Array.isArray(sale.items))continue;
    const date=recordDateISO(sale);
    // Los tickets sin fecha no se convierten en demanda diaria arbitraria.
    // Si hay alguna fecha fiable, se excluyen los registros sin fecha; si no,
    // se guardan como evidencia no fechada y solo se usan campos agregados con periodo explícito.
    if(!date&&hasAnyDatedSales)continue;
    if(date&&(date<cutoff90||date>endISO))continue;
    const age=date?Math.max(0,Math.floor((endDay-Date.parse(date+'T00:00:00Z'))/86400000)):null;
    for(const line of sale.items){
      const productId=cleanText(line&&(line.productId||line.productID||line.id),160);
      const key=normalizeSupplierKey(cleanText(line&&(line.name||line.productName)||'',160));
      if(!productId&&!key)continue;
      const qtyRaw=Number(line.baseQty??line.quantity??line.qty??line.units??line.sold??0);
      if(!Number.isFinite(qtyRaw))continue;
      const lookup=productId?'id:'+productId:'name:'+key;
      let bucket=byProduct.get(lookup);if(!bucket){bucket={sold90:0,sold30:0,records:0,undatedRecords:0,undatedQty:0};byProduct.set(lookup,bucket);}
      if(age===null){bucket.undatedRecords++;bucket.undatedQty+=Math.abs(qtyRaw);continue;}
      const signed=(sale.kind==='return'?-1:1)*Math.abs(qtyRaw);
      bucket.sold90+=signed;if(age<=29)bucket.sold30+=signed;bucket.records++;
    }
  }
  const posRows=Array.isArray(options.pointsOfSale)?options.pointsOfSale:[];
  const supplierRows=Array.isArray(options.supplierDirectory)?options.supplierDirectory:[];
  const purchases=Array.isArray(options.purchases)?options.purchases:[];
  const matchProduct=(candidate,product)=>{
    const a=cleanText(candidate&&(candidate.productId||candidate.id),160),b=cleanText(product&&(product.productId||product.id),160);
    if(a&&b)return a===b;
    const key=normalizeSupplierKey(candidate&&(candidate.name||candidate.productName)||''),target=normalizeSupplierKey(product&&(product.name||product.productName)||'');
    return !!key&&key===target&&(!nameFrequency.has(target)||nameFrequency.get(target)===1);
  };
  const quantityOf=item=>Math.max(0,Number(item&&(item.quantity??item.qty??item.stock??item.units)||0));
  const currencyUnitStep=unit=>/\b(kg|kilogram|g|gram|lb|lbs|libra|l|litro|ml|m|metro)\b/i.test(String(unit||''))?0.01:1;
  const median=values=>{const sorted=values.filter(v=>Number.isFinite(v)&&v>0).sort((a,b)=>a-b);if(!sorted.length)return null;const mid=Math.floor(sorted.length/2);return sorted.length%2?sorted[mid]:(sorted[mid-1]+sorted[mid])/2;};
  return rows.map(product=>{
    const name=cleanText(product&&(product.name||product.productName)||'Producto',160),productId=cleanText(product&&(product.productId||product.id)||'',160),nameKey=normalizeSupplierKey(name);
    const bucket=(productId&&byProduct.get('id:'+productId))||(!productId&&nameFrequency.get(nameKey)===1?byProduct.get('name:'+nameKey):null)||byProduct.get('name:'+nameKey)||null;
    const rawStock=quantityOf(product),posStockRows=[];
    let posStock=0;
    for(const pos of posRows){for(const item of Array.isArray(pos&&pos.inventory)?pos.inventory:[]){if(matchProduct(item,product)){const qty=quantityOf(item);posStock+=qty;posStockRows.push({posName:cleanText(pos.name||pos.posName||'Punto de venta',100),qty});}}}
    const totalNetworkStock=rawStock+posStock;
    const explicit90=Number(product.sold90??product.unitsSold90??NaN),explicit30=Number(product.sold30??product.unitsSold30??NaN);
    const datedSales=Boolean(bucket&&bucket.records>0);
    const sold90=datedSales?Math.max(0,bucket.sold90):(Number.isFinite(explicit90)&&explicit90>=0?explicit90:0);
    const sold30=datedSales?Math.max(0,bucket.sold30):(Number.isFinite(explicit30)&&explicit30>=0?explicit30:0);
    const hasDemand=datedSales||(Number.isFinite(explicit90)&&explicit90>0)||(Number.isFinite(explicit30)&&explicit30>0);
    let daily=0;
    if(datedSales){const avg90=Math.max(0,bucket.sold90)/historyDays,avg30=Math.max(0,bucket.sold30)/30;daily=avg90>0&&avg30>0?(avg90*0.4+avg30*0.6):Math.max(avg90,avg30);}
    else if(Number.isFinite(explicit90)&&explicit90>0&&Number.isFinite(explicit30)&&explicit30>0)daily=(explicit90/historyDays)*0.4+(explicit30/30)*0.6;
    else if(Number.isFinite(explicit90)&&explicit90>0)daily=explicit90/historyDays;
    else if(Number.isFinite(explicit30)&&explicit30>0)daily=explicit30/30;
    const alertCfg=product.stockAlertSettings&&typeof product.stockAlertSettings==='object'?product.stockAlertSettings:{};
    const min=Math.max(0,Number(alertCfg.manualMinimum??product.minimumStock??product.minStock??product.minQty??product.stockMin??0)||0);
    const supplierName=cleanText(product.supplier||product.supplierName||product.vendor||'',180);
    const supplier=supplierRows.find(row=>normalizeSupplierKey(row.name)===normalizeSupplierKey(supplierName));
    const lead=Math.max(0,Number(alertCfg.leadTimeDays)||Number(product.leadTimeDays)||Number(supplier&&supplier.leadDays)||7);
    const matchingPurchases=purchases.filter(p=>Array.isArray(p&&p.items)&&p.items.some(item=>matchProduct(item,product)));
    const purchaseDates=[...new Set(matchingPurchases.map(recordDateISO).filter(Boolean))].sort();
    const intervals=purchaseDates.slice(1).map((date,index)=>Math.round((Date.parse(date+'T00:00:00Z')-Date.parse(purchaseDates[index]+'T00:00:00Z'))/86400000));
    const purchaseCycleDays=intervals.length>=2?Math.max(1,Math.min(60,median(intervals))):null;
    const coverDays=Math.max(1,Math.min(365,Number(days)||14)),effectiveCoverDays=Math.max(coverDays,purchaseCycleDays||0),safetyDays=7,targetDays=lead+effectiveCoverDays+safetyDays;
    const demandTarget=hasDemand?daily*targetDays:0;
    const targetStock=Math.max(min,demandTarget);
    const rawSuggested=Math.max(0,targetStock-totalNetworkStock);
    const step=currencyUnitStep(product.unit||product.measureUnit||product.measurementUnit);
    const suggested=rawSuggested>0?Math.ceil(rawSuggested/step)*step:0;
    const inventoryCost=Number(product.cost??product.unitCost??product.purchasePrice??product.acquisitionCost);
    // Las líneas de compra guardan cost final por unidad; si falta el coste del catálogo,
    // reconstruimos un promedio ponderado de compras que ya incluye Extra asignado.
    const purchaseCostLines=matchingPurchases.flatMap(p=>p.items.filter(item=>matchProduct(item,product)).map(item=>{
      const qty=Math.max(0,Number(item.qty??item.quantity??item.baseQty??0)||0);
      const direct=Number(item.cost??item.unitCost??item.purchasePrice??item.acquisitionCost);
      const base=Number(item.baseCost),extra=Number(item.extraPerUnit);
      const finalCost=Number.isFinite(direct)&&direct>0?direct:(Number.isFinite(base)&&base>0?base+Math.max(0,Number.isFinite(extra)?extra:0):NaN);
      return {qty,cost:finalCost};
    }).filter(row=>row.qty>0&&Number.isFinite(row.cost)&&row.cost>0));
    const purchaseQty=purchaseCostLines.reduce((sum,row)=>sum+row.qty,0);
    const purchaseWeightedCost=purchaseQty>0?purchaseCostLines.reduce((sum,row)=>sum+row.qty*row.cost,0)/purchaseQty:null;
    const unitCost=Number.isFinite(inventoryCost)&&inventoryCost>0?inventoryCost:(purchaseWeightedCost??null);
    const unitCostSource=Number.isFinite(inventoryCost)&&inventoryCost>0?'inventario':(purchaseWeightedCost!==null?'compras históricas':'no disponible');
    const estimatedPurchaseValue=unitCost!==null?suggested*unitCost:null;
    const lastPurchase=purchaseDates.at(-1)||'';
    let reason='';
    if(!hasDemand&&bucket&&bucket.undatedRecords)reason='Hay ventas sin fecha verificable; no se inventa una demanda diaria. Se usa el mínimo manual solo como referencia.';
    else if(!hasDemand)reason=totalNetworkStock<min?'No hay demanda histórica fechada suficiente; se usa el mínimo manual solo como referencia.':'Sin demanda fechada; el stock cubre el mínimo configurado.';
    else if(daily<=0)reason='No hay venta neta positiva en el periodo; revisar devoluciones y registros antes de comprar.';
    else if(rawSuggested>0&&totalNetworkStock<daily*lead)reason='El stock total de almacén y puntos de venta no cubre la demanda durante el plazo de abastecimiento.';
    else if(rawSuggested>0)reason='Reposición calculada con demanda neta, plazo del proveedor, ciclo observado de compra, cobertura objetivo y reserva de seguridad.';
    else reason='El stock de la red cubre la demanda proyectada para el horizonte objetivo.';
    return {productId:productId||null,name,stock:rawStock,posStock,totalNetworkStock,min,sold30,sold90,daily,leadDays:lead,coverDays,effectiveCoverDays,purchaseCycleDays,safetyDays,targetDays,targetStock,suggested,estimatedPurchaseValue,unitCost:unitCost!==null?unitCost:null,unitCostSource,purchaseHistoryCount:matchingPurchases.length,lastPurchase,undatedSalesRecords:bucket?bucket.undatedRecords:0,source:hasDemand?'sales-history':'manual-minimum',reason,posStockRows};
  }).filter(row=>row.suggested>0).sort((a,b)=>(b.estimatedPurchaseValue??b.suggested)-(a.estimatedPurchaseValue??a.suggested));
}
function canCompareUnitCurrencies(costCurrency, priceCurrency) {
  const cost = cleanText(costCurrency, 10).toUpperCase();
  const price = cleanText(priceCurrency, 10).toUpperCase();
  // Legacy products may omit both currency fields; one-sided or conflicting
  // currency metadata is not enough to calculate a defensible margin.
  return (!cost && !price) || Boolean(cost && price && cost === price);
}
function findPotentialDuplicateTransactions(transactions) {
  // One pass: the old nested .some() performed O(n²) comparisons and could
  // freeze the UI on a large transaction history.
  const groups = new Map();
  for (const t of Array.isArray(transactions) ? transactions : []) {
    if (!t || typeof t !== 'object') continue;
    const key = JSON.stringify([
      String(t.date || ''), Number(t.amount), cleanText(t.name, 180).toLocaleLowerCase(),
      String(t.type || ''), String(t.currency || ''), String(t.accountId || ''), String(t.toAccountId || '')
    ]);
    const group = groups.get(key);
    if (group) group.push(t);
    else groups.set(key, [t]);
  }
  return Array.from(groups.values()).filter(group => group.length > 1).flat();
}
function summarizeBranches(branches, accounts, transactions) {
  const accountById = new Map((Array.isArray(accounts) ? accounts : []).map(a => [String(a.id), a]));
  const summaries = new Map();
  for (const branch of Array.isArray(branches) ? branches : []) {
    if (branch && branch.id != null) summaries.set(String(branch.id), { branch, transactions: 0, byCurrency: new Map() });
  }
  for (const t of Array.isArray(transactions) ? transactions : []) {
    if (!t || typeof t !== 'object') continue;
    const account = accountById.get(String(t.accountId || ''));
    const summary = account && account.branchId != null ? summaries.get(String(account.branchId)) : null;
    if (!summary) continue;
    summary.transactions++;
    if (!CURRENCIES.includes(t.currency)) continue;
    let row = summary.byCurrency.get(t.currency);
    if (!row) { row = { currency: t.currency, income: 0, expenses: 0 }; summary.byCurrency.set(t.currency, row); }
    const amount = Number(t.amount) || 0;
    if (t.type === 'income' || (t.type === 'settlement' && t.debtKind === 'receivables')) row.income += amount;
    if (t.type === 'expense' || (t.type === 'settlement' && t.debtKind === 'payables')) row.expenses += amount;
  }
  return Array.from(summaries.values()).map(summary => ({
    branch: summary.branch,
    transactions: summary.transactions,
    byCurrency: CURRENCIES.filter(currency => summary.byCurrency.has(currency)).map(currency => summary.byCurrency.get(currency))
  }));
}
function normalizeSupplierKey(value) {
  return cleanText(value, 180).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').toLocaleLowerCase();
}
function recordDateISO(record) {
  const row = record && typeof record === 'object' ? record : {};
  const preferred = row.ts || row.createdAt || row.timestamp || row.date || '';
  if (!preferred) return '';
  const raw = String(preferred).trim();
  const es = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (es) return `${es[3]}-${String(es[2]).padStart(2, '0')}-${String(es[1]).padStart(2, '0')}`;
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  const parsed = new Date(raw);
  return Number.isFinite(parsed.getTime()) ? parsed.toISOString().slice(0, 10) : '';
}
function purchaseRecordAmount(purchase) {
  if (purchase && purchase.totalAmount != null && Number.isFinite(Number(purchase.totalAmount)) && Number(purchase.totalAmount) >= 0) return Number(purchase.totalAmount);
  const items = purchase && Array.isArray(purchase.items) ? purchase.items : [];
  if (!items.length) return null;
  let total = 0;
  for (const item of items) {
    const cost = Number(item && item.cost), qty = Number(item && item.qty);
    if (!Number.isFinite(cost) || !Number.isFinite(qty) || cost < 0 || qty < 0) return null;
    total += cost * qty;
  }
  return Number.isFinite(total) ? total : null;
}
function salesRecordAmountCUP(sale) {
  if (!sale || typeof sale !== 'object') return null;
  if (sale.totalCUP != null && String(sale.totalCUP).trim() !== '' && Number.isFinite(Number(sale.totalCUP))) {
    const value = Number(sale.totalCUP);
    return sale.kind === 'return' && value > 0 ? -value : value;
  }
  const items = Array.isArray(sale.items) ? sale.items : [];
  if (!items.length) return null;
  let total = 0;
  for (const line of items) {
    if (line.lineTotalCUP != null && String(line.lineTotalCUP).trim() !== '' && Number.isFinite(Number(line.lineTotalCUP))) total += Number(line.lineTotalCUP);
    else if (String(line.currency || sale.currency || '').toUpperCase() === 'CUP' && line.lineTotal != null && Number.isFinite(Number(line.lineTotal))) total += Number(line.lineTotal);
    else return null;
  }
  return sale.kind === 'return' && total > 0 ? -total : total;
}
function summarizeSupplierPurchases(purchases, legacySuppliers = []) {
  const byName = new Map();
  const records = (Array.isArray(purchases) ? purchases : []).filter(p => p && typeof p === 'object' && !p.__archivedRecordStub)
    .slice().sort((a, b) => recordDateISO(a).localeCompare(recordDateISO(b)));
  for (const p of records) {
    const name = cleanText(p.supplier || p.supplierName || p.vendor || '', 180);
    const key = normalizeSupplierKey(name);
    if (!key || ['no especificado', 'sin proveedor', 'proveedor'].includes(key)) continue;
    const date = recordDateISO(p);
    const phone = cleanText(p.supplierPhone || p.phone || p.supplierTelephone || '', 80);
    const total = purchaseRecordAmount(p);
    let row = byName.get(key);
    if (!row) row = { key, name, phone: '', phoneDate: '', purchaseCount: 0, totalAcquisition: 0, totalKnown: true, lastPurchase: '', lastPurchaseId: null, contact: '', leadDays: null, notes: '', source: 'Compras registradas' };
    row.purchaseCount++;
    if (total == null) row.totalKnown = false; else row.totalAcquisition += total;
    if (date >= row.lastPurchase) { row.lastPurchase = date; row.lastPurchaseId = p.id == null ? null : String(p.id); if (name) row.name = name; }
    if (phone && date >= row.phoneDate) { row.phone = phone; row.phoneDate = date; }
    byName.set(key, row);
  }
  for (const legacy of Array.isArray(legacySuppliers) ? legacySuppliers : []) {
    if (!legacy || typeof legacy !== 'object') continue;
    const name = cleanText(legacy.name || '', 180), key = normalizeSupplierKey(name);
    if (!key) continue;
    let row = byName.get(key);
    if (!row) {
      row = { key, name, phone: '', phoneDate: '', purchaseCount: 0, totalAcquisition: 0, totalKnown: true, lastPurchase: '', lastPurchaseId: null, contact: '', leadDays: null, notes: '', source: 'Proveedor antiguo sin compra asociada' };
      byName.set(key, row);
    }
    if (!row.phone) row.phone = cleanText(legacy.phone || legacy.telephone || '', 80);
    row.contact = cleanText(legacy.contact || '', 180);
    row.notes = cleanText(legacy.notes || '', 500);
    const lead = Number(legacy.leadDays);
    row.leadDays = Number.isFinite(lead) && lead >= 0 ? lead : null;
    if (row.purchaseCount) row.source = 'Historial de compras';
  }
  return Array.from(byName.values()).map(row => ({ ...row, totalAcquisition: row.totalKnown ? Math.round((row.totalAcquisition + Number.EPSILON) * 100) / 100 : null }))
    .sort((a, b) => b.purchaseCount - a.purchaseCount || a.name.localeCompare(b.name, 'es', { sensitivity: 'base' }));
}
function isLegacyEstimatedClosing(closing, sales = []) {
  if (!closing || typeof closing !== 'object' || closing.__archivedRecordStub) return false;
  if (closing.salesTrackingMode === true || Number(closing.rotationDataVersion) >= 2) return false;
  const ledgerIds = Array.isArray(closing.salesLedgerIds) ? closing.salesLedgerIds.map(String) : [];
  if (ledgerIds.length) return false;
  const closeId = closing.id == null ? '' : String(closing.id);
  if (closeId && (Array.isArray(sales) ? sales : []).some(sale => sale && String(sale.closingId || '') === closeId)) return false;
  return Array.isArray(closing.products) && closing.products.length > 0;
}
function buildLegacyClosingSales(closings, sales = []) {
  const out = [];
  for (const closing of Array.isArray(closings) ? closings : []) {
    if (!isLegacyEstimatedClosing(closing, sales)) continue;
    const date = recordDateISO(closing);
    const ts = closing.ts || closing.createdAt || (date ? `${date}T12:00:00.000Z` : '');
    const items = [];
    for (const row of closing.products) {
      if (!row || typeof row !== 'object') continue;
      const sold = Number(row.sold);
      if (!Number.isFinite(sold) || sold <= 0) continue;
      const name = cleanText(row.name || row.productName || '', 160);
      if (!name) continue;
      const line = {
        productId: cleanText(row.productId || row.id || '', 160) || null,
        name,
        baseQty: sold,
        currency: 'CUP'
      };
      // Only reuse a subtotal explicitly stored by the closing. Never reconstruct
      // historical revenue from today's product price.
      if (row.subtotal != null && String(row.subtotal).trim() !== '' && Number.isFinite(Number(row.subtotal)) && Number(row.subtotal) >= 0) {
        line.lineTotalCUP = Number(row.subtotal);
      }
      items.push(line);
    }
    const explicitTotal = closing.totalRevenue != null && String(closing.totalRevenue).trim() !== '' && Number.isFinite(Number(closing.totalRevenue)) && Number(closing.totalRevenue) >= 0
      ? Number(closing.totalRevenue) : null;
    if (!items.length && explicitTotal == null) continue;
    out.push({
      id: `closing-estimate:${String(closing.id || date || out.length)}`,
      source: 'closing-estimate', estimatedFromClosing: true,
      kind: 'sale', status: 'estimated-from-closing', ts, date,
      closingId: closing.id == null ? null : String(closing.id),
      posId: closing.posId || null, posName: closing.posName || closing.pointOfSale || '',
      currency: 'CUP', totalCUP: explicitTotal, items
    });
  }
  return out;
}

function summarizeSalesByPOS(sales, closings = [], pointsOfSale = []) {
  const groups = new Map();
  const ensure = (idValue, nameValue) => {
    const id = String(idValue || '').trim();
    const name = cleanText(nameValue || '', 120) || (id ? `Punto ${id}` : 'Punto de venta sin identificar');
    const key = id ? `id:${id}` : `name:${normalizeSupplierKey(name)}`;
    if (!groups.has(key)) groups.set(key, { key, posId: id || null, name, saleCount: 0, returnCount: 0, pendingCloseCount: 0, netSalesCUP: 0, salesCUPKnown: true, hasSalesValue: false, estimatedClosingCount: 0, closings: 0, closingDifferences: [], transferCount: 0 });
    return groups.get(key);
  };
  for (const pos of Array.isArray(pointsOfSale) ? pointsOfSale : []) if (pos) ensure(pos.id || pos.posId, pos.name || pos.posName);
  for (const sale of Array.isArray(sales) ? sales : []) {
    if (!sale || typeof sale !== 'object') continue;
    const row = ensure(sale.posId, sale.posName || sale.pointOfSale || sale.pos || '');
    if (sale.kind === 'return') row.returnCount++; else row.saleCount++;
    if (isSalePendingClose(sale)) row.pendingCloseCount++;
    const amount = salesRecordAmountCUP(sale);
    if (amount == null) row.salesCUPKnown = false; else { row.netSalesCUP += amount; row.hasSalesValue = true; }
  }
  for (const closing of Array.isArray(closings) ? closings : []) {
    if (!closing || typeof closing !== 'object') continue;
    const row = ensure(closing.posId, closing.posName || closing.pointOfSale || '');
    row.closings++;
    const difference = Number(closing.difference);
    if (Number.isFinite(difference)) row.closingDifferences.push(difference);
    if (isLegacyEstimatedClosing(closing, sales)) {
      const amount = closing.totalRevenue != null && String(closing.totalRevenue).trim() !== '' && Number.isFinite(Number(closing.totalRevenue)) && Number(closing.totalRevenue) >= 0 ? Number(closing.totalRevenue) : null;
      row.estimatedClosingCount++;
      if (amount == null) row.salesCUPKnown = false;
      else { row.netSalesCUP += amount; row.hasSalesValue = true; }
    }
  }
  return Array.from(groups.values()).map(row => ({ ...row, netSalesCUP: row.salesCUPKnown && row.hasSalesValue ? Math.round((row.netSalesCUP + Number.EPSILON) * 100) / 100 : null }))
    .sort((a, b) => a.name.localeCompare(b.name, 'es', { sensitivity: 'base' }));
}
function summarizeProductSalesByPOS(sales, pointsOfSale=[]) {
 const keyOf=(idValue,nameValue)=>{const id=String(idValue||'').trim();return id?'id:'+id:'name:'+normalizeSupplierKey(nameValue||'Punto sin identificar');};
 const groups=new Map();
 const ensure=(idValue,nameValue)=>{const key=keyOf(idValue,nameValue);if(!groups.has(key))groups.set(key,{key,posId:String(idValue||'')||null,name:cleanText(nameValue||'Punto de venta',120),products:new Map(),ticketCount:0,returnCount:0,ticketSalesCUP:0,ticketSalesKnown:true,hasTicketValue:false});return groups.get(key);};
 for(const pos of Array.isArray(pointsOfSale)?pointsOfSale:[])if(pos)ensure(pos.id||pos.posId,pos.name||pos.posName);
 const nameCounts=new Map();for(const pos of Array.isArray(pointsOfSale)?pointsOfSale:[]){const key=normalizeSupplierKey(pos&&(pos.name||pos.posName)||'');if(key)nameCounts.set(key,(nameCounts.get(key)||0)+1);}
 for(const sale of Array.isArray(sales)?sales:[]){if(!sale||typeof sale!=='object')continue;const name=sale.posName||sale.pointOfSale||sale.pos||'',idValue=sale.posId||(name&&nameCounts.get(normalizeSupplierKey(name))===1?(pointsOfSale.find(p=>normalizeSupplierKey(p.name||p.posName)===normalizeSupplierKey(name))||{}).id:'');const row=ensure(idValue,name);const sign=sale.kind==='return'?-1:1;if(sign<0)row.returnCount++;else row.ticketCount++;
  if(sign>0){const amount=salesRecordAmountCUP(sale);if(amount==null)row.ticketSalesKnown=false;else{row.ticketSalesCUP+=amount;row.hasTicketValue=true;}}
  for(const line of Array.isArray(sale.items)?sale.items:[]){const productName=cleanText(line&&(line.name||line.productName||line.title)||'Producto sin nombre',160),productId=cleanText(line&&(line.productId||line.productID||line.id)||'',160),productKey=productId?'id:'+productId:'name:'+normalizeSupplierKey(productName);const rawQty=Number(line.baseQty??line.quantity??line.qty??line.units??line.sold??0);if(!Number.isFinite(rawQty))continue;let product=row.products.get(productKey);if(!product){product={productId:productId||null,name:productName,units:0,knownRevenue:true,revenue:0};row.products.set(productKey,product);}product.units+=sign*Math.abs(rawQty);const lineAmount=line.lineTotalCUP!=null&&Number.isFinite(Number(line.lineTotalCUP))?Number(line.lineTotalCUP):(String(line.currency||sale.currency||'').toUpperCase()==='CUP'&&line.lineTotal!=null&&Number.isFinite(Number(line.lineTotal))?Number(line.lineTotal):null);if(lineAmount==null)product.knownRevenue=false;else product.revenue+=sign*Math.abs(lineAmount);
  }
 }
 return Array.from(groups.values()).map(row=>{const products=Array.from(row.products.values()).filter(p=>p.units>0).sort((a,b)=>b.units-a.units);const topProducts=products.slice(0,5).map(p=>({...p,units:Math.round((p.units+Number.EPSILON)*100)/100}));return {posId:row.posId,name:row.name,ticketCount:row.ticketCount,returnCount:row.returnCount,returnRate:row.ticketCount+row.returnCount>0?row.returnCount/(row.ticketCount+row.returnCount)*100:null,averageTicketCUP:row.ticketCount>0&&row.ticketSalesKnown&&row.hasTicketValue?row.ticketSalesCUP/row.ticketCount:null,totalNetUnits:products.reduce((sum,p)=>sum+p.units,0),distinctProducts:products.length,topProducts};}).sort((a,b)=>a.name.localeCompare(b.name,'es',{sensitivity:'base'}));
}
function summarizeRealOperations(purchases, sales, closings, transfers, pointsOfSale, referenceDate = new Date()) {
  const ref = referenceDate instanceof Date ? referenceDate : new Date(referenceDate);
  const date = Number.isFinite(ref.getTime()) ? ref : new Date();
  const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
  const inMonth = record => recordDateISO(record).slice(0, 7) === month;
  const purchaseRows = (Array.isArray(purchases) ? purchases : []).filter(p => p && !p.__archivedRecordStub && inMonth(p));
  let purchaseTotal = 0, purchasesTotalKnown = true;
  for (const p of purchaseRows) { const amount = purchaseRecordAmount(p); if (amount == null) purchasesTotalKnown = false; else purchaseTotal += amount; }
  const salesRows = (Array.isArray(sales) ? sales : []).filter(s => s && inMonth(s));
  let netSalesCUP = 0, salesTotalKnown = true, saleCount = 0, returnCount = 0, pendingCloseCount = 0;
  for (const sale of salesRows) {
    const amount = salesRecordAmountCUP(sale);
    if (sale.kind === 'return') returnCount++; else saleCount++;
    if (isSalePendingClose(sale)) pendingCloseCount++;
    if (amount == null) salesTotalKnown = false; else netSalesCUP += amount;
  }
  const closingRows = (Array.isArray(closings) ? closings : []).filter(inMonth);
  let estimatedClosingSales = 0, estimatedClosingsCount = 0, closingSalesKnown = true;
  for (const closing of closingRows) {
    if (!isLegacyEstimatedClosing(closing, sales)) continue;
    estimatedClosingsCount++;
    const amount = closing.totalRevenue != null && String(closing.totalRevenue).trim() !== '' && Number.isFinite(Number(closing.totalRevenue)) && Number(closing.totalRevenue) >= 0 ? Number(closing.totalRevenue) : null;
    if (amount == null) closingSalesKnown = false; else estimatedClosingSales += amount;
  }
  const transferRows = (Array.isArray(transfers) ? transfers : []).filter(t => t && !t.__archivedRecordStub && inMonth(t));
  const supplierCount = summarizeSupplierPurchases(purchases).length;
  const hasSalesBasis = salesRows.length > 0 || estimatedClosingsCount > 0;
  const totalSalesKnown = salesTotalKnown && closingSalesKnown;
  return {
    month, purchaseCount: purchaseRows.length,
    purchaseTotalCUP: purchasesTotalKnown ? Math.round((purchaseTotal + Number.EPSILON) * 100) / 100 : null,
    salesCount: saleCount, returnCount, pendingCloseCount,
    netSalesCUP: totalSalesKnown && hasSalesBasis ? Math.round((netSalesCUP + estimatedClosingSales + Number.EPSILON) * 100) / 100 : null,
    salesRows: salesRows.length, estimatedClosingsCount, closingsCount: closingRows.length, transfersCount: transferRows.length,
    salesSource: salesRows.length && estimatedClosingsCount ? 'Mixta: tickets y cierres IPV estimados' : salesRows.length ? 'Tickets registrados' : estimatedClosingsCount ? 'Estimación mediante cierre IPV' : 'Sin datos de ventas',
    supplierCount, pointCount: Array.isArray(pointsOfSale) ? pointsOfSale.filter(Boolean).length : 0
  };
}
function summarizeRealPeriods(purchases, sales, closings, transfers, referenceDate = new Date()) {
  const ref = referenceDate instanceof Date ? referenceDate : new Date(referenceDate);
  const validRef = Number.isFinite(ref.getTime()) ? ref : new Date();
  const months = [];
  const current = new Date(validRef.getFullYear(), validRef.getMonth(), 1);
  const previous = new Date(validRef.getFullYear(), validRef.getMonth() - 1, 1);
  for (const date of [current, previous]) {
    const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    const inMonth = row => recordDateISO(row).slice(0, 7) === month;
    const pRows = (Array.isArray(purchases) ? purchases : []).filter(p => p && !p.__archivedRecordStub && inMonth(p));
    let pTotal = 0, pKnown = true;
    for (const p of pRows) { const n = purchaseRecordAmount(p); if (n == null) pKnown = false; else pTotal += n; }
    const sRows = (Array.isArray(sales) ? sales : []).filter(s => s && inMonth(s));
    let sTotal = 0, sKnown = true, saleCount = 0, returnCount = 0, pendingCloseCount = 0;
    for (const sale of sRows) {
      const n = salesRecordAmountCUP(sale);
      if (sale.kind === 'return') returnCount++; else saleCount++;
      if (isSalePendingClose(sale)) pendingCloseCount++;
      if (n == null) sKnown = false; else sTotal += n;
    }
    const closingRows = (Array.isArray(closings) ? closings : []).filter(inMonth);
    let estimatedTotal = 0, estimatedCount = 0, estimatesKnown = true;
    for (const closing of closingRows) {
      if (!isLegacyEstimatedClosing(closing, sales)) continue;
      estimatedCount++;
      const amount = closing.totalRevenue != null && String(closing.totalRevenue).trim() !== '' && Number.isFinite(Number(closing.totalRevenue)) && Number(closing.totalRevenue) >= 0 ? Number(closing.totalRevenue) : null;
      if (amount == null) estimatesKnown = false; else estimatedTotal += amount;
    }
    const hasSalesBasis = sRows.length > 0 || estimatedCount > 0;
    months.push({
      month,
      purchaseCount: pRows.length,
      purchaseTotalCUP: pKnown ? Math.round((pTotal + Number.EPSILON) * 100) / 100 : null,
      salesCount: saleCount, returnCount,
      netSalesCUP: sKnown && estimatesKnown && hasSalesBasis ? Math.round((sTotal + estimatedTotal + Number.EPSILON) * 100) / 100 : null,
      salesRecords: sRows.length, estimatedClosingsCount: estimatedCount, pendingCloseCount,
      salesSource: sRows.length && estimatedCount ? 'Mixta: tickets y cierres IPV estimados' : sRows.length ? 'Tickets registrados' : estimatedCount ? 'Estimación mediante cierre IPV' : 'Sin datos de ventas',
      closingCount: closingRows.length,
      transferCount: (Array.isArray(transfers) ? transfers : []).filter(t => t && !t.__archivedRecordStub && inMonth(t)).length
    });
  }
  return months;
}

const Core={validateState,balanceForAccount,openDebts,abcAnalysis,healthScore,healthAssessment,aggregateProductSales,buildMarginAnalysis,inventoryMovementAnalysis,suggestReplenishment,canApproveTransfer,simulatePrice,priceSimulatorProductDefaults,simulateStock,canCompareUnitCurrencies,findPotentialDuplicateTransactions,summarizeBranches,normalizeSupplierKey,recordDateISO,purchaseRecordAmount,salesRecordAmountCUP,summarizeSupplierPurchases,isLegacyEstimatedClosing,buildLegacyClosingSales,summarizeSalesByPOS,summarizeProductSalesByPOS,summarizeRealOperations,summarizeRealPeriods,decodeProControlStoredValue,readProControlStoredArray,isSalePendingClose,latestCurrencyRates,rateCurrencyLabel,CURRENCIES,CATEGORIES};
if (typeof module!=='undefined' && module.exports) module.exports=Core;
if (!root || !root.document) return;
const doc=root.document;
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store=root.procontrolDB || root.localStorage;
let storageCorrupt=false; let lastSavedState=null;
function readState(){
  storageCorrupt=false; let raw=null; try { raw=store.getItem(STORAGE_KEY); } catch(e) { console.error(e); storageCorrupt=true; }
  if(!raw) return clone(DEFAULTS);
  try { return validateState(JSON.parse(raw)); } catch(e) { console.error('[ProControl Gestión]',e); storageCorrupt=true; return clone(DEFAULTS); }
}
let state=readState(); lastSavedState=clone(state); let activeTab='overview';
function actorUser(){try{const a=root.PCBusinessContext&&root.PCBusinessContext.getActor?root.PCBusinessContext.getActor():null;if(a&&a.user)return cleanText(a.user,80);}catch(_){}return ''; }
function actor(){ try{const a=root.PCBusinessContext&&root.PCBusinessContext.getActor?root.PCBusinessContext.getActor():null;if(a&&a.user)return cleanText(a.user,80)+' ('+cleanText(a.role||'Usuario',50)+')';}catch(_){} const el=doc.getElementById('display-role-badge'); return cleanText(el&&el.textContent||'Usuario',80)||'Usuario'; }
function canOwner(){try{if(root.PCBusinessContext&&root.PCBusinessContext.canOwner)return root.PCBusinessContext.canOwner()===true;}catch(_){}return actor().startsWith('Dueño');}
function canWrite(){ try{if(root.PCBusinessContext&&root.PCBusinessContext.canWrite)return root.PCBusinessContext.canWrite()===true;}catch(_){} return ['Dueño','Administrador','Economico','Económico'].includes(actor()); }
function requireWrite(){ if(canWrite()) return true; notify('Tu perfil puede consultar Gestión Empresarial, pero no registrar ni modificar operaciones. Solicita autorización al Dueño o Administrador.'); return false; }
function log(action,details){ state.audit.unshift({id:id('audit'),at:new Date().toISOString(),actor:actor(),action:cleanText(action,100),details:cleanText(details,300)}); if(state.audit.length>5000) state.audit.length=5000; }
function persist(action,details){ if(storageCorrupt){state=clone(lastSavedState);notify('Guardado bloqueado: los datos anteriores de Gestión Empresarial parecen dañados. Restaura un respaldo válido antes de seguir.');return false;} if(!canWrite()){state=clone(lastSavedState);notify('Operación no autorizada para el perfil actual.');return false;} try{log(action,details);validateState(state);store.setItem(STORAGE_KEY,JSON.stringify(state));lastSavedState=clone(state);return true;}catch(e){state=clone(lastSavedState);alert('No se pudo guardar Gestión Empresarial. Los cambios no se conservaron.\n\n'+e.message);return false;} }
function notify(message){const el=doc.getElementById('pcbm-status'); if(el) el.textContent=message; else alert(message);}
function getCurrentDateISO(){return new Date().toISOString().slice(0,10);}
function latestCurrencyRates(rates,date=new Date().toISOString().slice(0,10),fallbackUSD=0){
 const rows=Array.isArray(rates)?rates:[];const groups=new Map();
 rows.forEach((record,index)=>{
  if(!record||!CURRENCIES.includes(record.currency)||!/^\d{4}-\d{2}-\d{2}$/.test(String(record.date||''))||record.date>date||!Number.isFinite(Number(record.rate))||Number(record.rate)<=0)return;
  const label=rateCurrencyLabel(record);if(!label)return;
  const key=record.currency==='OTRA'?'OTRA:'+label.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase():record.currency;
  const previous=groups.get(key);
  if(!previous||record.date>previous.date||(record.date===previous.date&&index>previous.index))groups.set(key,{currency:record.currency,label,rate:Number(record.rate),date:record.date,source:cleanText(record.source||'',180),index});
 });
 const result=Array.from(groups.values()).map(({index,...row})=>row);
 if(!result.some(row=>row.currency==='USD')&&Number.isFinite(Number(fallbackUSD))&&Number(fallbackUSD)>0)result.push({currency:'USD',label:'USD',rate:Number(fallbackUSD),date:'Tasa principal',source:'Tasa principal de ProControl'});
 const order={USD:0,EUR:1,MLC:2,OTRA:3};
 return result.sort((a,b)=>(order[a.currency]??4)-(order[b.currency]??4)||a.label.localeCompare(b.label,'es',{sensitivity:'base'}));
}
function latestRate(currency,date=new Date().toISOString().slice(0,10),customCurrency=''){ if(currency==='CUP') return 1; const customKey=cleanCurrencyLabel(customCurrency).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase(); const recorded=state.rates.filter(r=>r.currency===currency&&r.date<=date&&Number(r.rate)>0&&(currency!=='OTRA'||cleanCurrencyLabel(r.customCurrency).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase()===customKey)).sort((a,b)=>b.date.localeCompare(a.date))[0]; if(recorded)return Number(recorded.rate); if(currency==='USD'&&String(date)>=new Date().toISOString().slice(0,10))return getMainDollarRate(); return 0; }
function accountOptions(selected){return state.accounts.filter(a=>a.active!==false).map(a=>`<option value="${esc(a.id)}" ${a.id===selected?'selected':''}>${esc(a.name)} (${esc(a.currency)})</option>`).join('');}
function branchOptions(selected=''){return `<option value="">Sin sucursal asignada</option>`+operationalBranches().map(b=>`<option value="${esc(b.id)}" ${String(b.id)===String(selected)?'selected':''}>${esc(b.name)}</option>`).join('');}
function currencyOptions(selected='CUP'){return CURRENCIES.map(c=>`<option ${c===selected?'selected':''} value="${c}">${c}</option>`).join('');}
function field(label,id,type='text',value='',extra=''){return `<label class="pcbm-field">${label}<input id="${id}" type="${type}" value="${esc(value)}" ${extra}></label>`;}
function panel(title,body){return `<section class="pcbm-card"><h3>${title}</h3>${body}</section>`;}
function disclosure(title,body,open=false){return `<details class="pcbm-disclosure" ${open?'open':''}><summary>${esc(title)}</summary><div class="pcbm-disclosure-body">${body}</div></details>`;}
function balances(){return state.accounts.filter(a=>a.active!==false).map(a=>({account:a,balance:balanceForAccount(state,a.id)}));}
function readMainStoredValue(key){
  try { return decodeProControlStoredValue(store && typeof store.getItem === 'function' ? store.getItem(key) : null); }
  catch (_) { return null; }
}
function readMainStoredArray(key){ return readProControlStoredArray(store, key); }
function readMainArray(key){ return readMainStoredArray(key).filter(row => row && typeof row === 'object' && !row.__archivedRecordStub); }
function getLegacyArray(key){ return readMainArray(key); }
function getPurchases(){ return readMainArray('elite_purchases'); }
function getInventory(){ return readMainArray('elite_inventory'); }
function getSales(){ return readMainArray('elite_sales_ledger'); }
function getClosingHistory(){ return readMainArray('elite_closing_history'); }
function getTransfers(){ return readMainArray('elite_transfers').filter(t => t.id && t.source && Array.isArray(t.destinations)); }
function getPointsOfSale(){
  const rows = readMainStoredArray('elite_pos').filter(pos => pos && !(typeof pos === 'object' && pos.__archivedRecordStub));
  return rows.map(pos => typeof pos === 'string' ? { name: pos, inventory: [] } : ({ ...pos, inventory: Array.isArray(pos.inventory) ? pos.inventory : [] }))
    .filter(pos => cleanText(pos.name || pos.posName || '', 120));
}
function getProductCatalog(){ return readMainArray('elite_product_catalog'); }
function getMainDollarRate(){
  try {
    const stored=decodeProControlStoredValue(store.getItem('elite_dollar_rate'));
    const direct=Number(stored);
    if(Number.isFinite(direct)&&direct>0)return direct;
    const business=decodeProControlStoredValue(store.getItem('elite_biz_data'));
    const fallback=Number(business&&business.dollarRate);
    return Number.isFinite(fallback)&&fallback>0?fallback:0;
  } catch(_){ return 0; }
}
function getAnalysisSales(){ const ledger=getSales(); return ledger.concat(buildLegacyClosingSales(getClosingHistory(),ledger)); }

function operationalBranches(){
 const known=getPointsOfSale().map(p=>({id:String(p.id||p.posId||p.name||''),name:cleanText(p.name||p.posName||'Punto de venta',100),notes:'Registrado en los puntos de venta principales',source:'pos'})).filter(p=>p.id);
 const seen=new Set(known.map(p=>normalizeSupplierKey(p.name)));
 for(const b of state.branches){if(!seen.has(normalizeSupplierKey(b.name))){known.push({...b,source:'economy'});seen.add(normalizeSupplierKey(b.name));}}
 return known;
}
function realOperations(){const purchases=getPurchases(),sales=getSales(),closings=getClosingHistory(),transfers=getTransfers(),points=getPointsOfSale();return {purchases,sales,analysisSales:sales.concat(buildLegacyClosingSales(closings,sales)),closings,transfers,points,supplierDirectory:summarizeSupplierPurchases(purchases,state.suppliers),summary:summarizeRealOperations(purchases,sales,closings,transfers,points)};}
function actualActivityEntries(limit=12){
 const data=realOperations(),entries=[];
 for(const p of data.purchases){const date=recordDateISO(p),amount=purchaseRecordAmount(p),supplier=cleanText(p.supplier||p.supplierName||'Proveedor no especificado',180),phone=cleanText(p.supplierPhone||p.phone||'',80);entries.push({date,ts:String(p.ts||p.createdAt||date),type:'Compra registrada',detail:`${supplier}${phone?' · Tel. '+phone:''} · ${(Array.isArray(p.items)?p.items.length:0)} línea(s)`,amount:amount===null?'Importe no calculable':money(amount)+' CUP',sort:String(p.ts||p.createdAt||date)});}
 for(const sale of data.sales){if(!sale||typeof sale!=='object')continue;const date=recordDateISO(sale),amount=salesRecordAmountCUP(sale),isReturn=sale.kind==='return';entries.push({date,ts:String(sale.ts||sale.createdAt||date),type:isReturn?'Devolución registrada':'Venta registrada',detail:`${cleanText(sale.posName||sale.pointOfSale||'Punto de venta no identificado',120)} · ${(sale.items&&sale.items.length)||0} línea(s) · ${sale.status==='pending-close'?'Pendiente de cierre':sale.status==='reconciled'?'Conciliada':'Estado no confirmado'}`,amount:amount===null?'Importe no disponible':money(amount)+' CUP',sort:String(sale.ts||sale.createdAt||date)});}
 for(const c of data.closings){if(!c||typeof c!=='object')continue;const date=recordDateISO(c),difference=Number(c.difference),diffText=Number.isFinite(difference)?`Diferencia registrada: ${money(difference)}`:'Diferencia no disponible',isEstimate=isLegacyEstimatedClosing(c,data.sales);entries.push({date,ts:String(c.ts||c.createdAt||date),type:isEstimate?'Cierre IPV · ventas estimadas':'Cierre de caja',detail:`${cleanText(c.posName||c.pointOfSale||'Punto de venta no identificado',120)} · ${cleanText(c.diffStatus||'Estado no indicado',80)} · ${diffText} (según el cierre)`,amount:Number.isFinite(Number(c.totalRevenue))?(isEstimate?'Total estimado: ':'Total registrado: ')+money(c.totalRevenue):'Total no disponible',sort:String(c.ts||c.createdAt||date)});}
 for(const t of data.transfers){if(!t||typeof t!=='object')continue;const date=recordDateISO(t),destinations=Array.isArray(t.destinations)?t.destinations.join(', '):String(t.destinations||'Destino no indicado');entries.push({date,ts:String(t.ts||t.createdAt||date),type:'Transferencia de inventario',detail:`${cleanText(t.product||'Producto no identificado',160)} · ${cleanText(t.source||'Origen no indicado',100)} → ${cleanText(destinations,180)} · Cantidad por destino: ${Number.isFinite(Number(t.qtyPerDest))?Number(t.qtyPerDest):'No indicada'}`,amount:'Movimiento de mercancía',sort:String(t.ts||t.createdAt||date)});}
 entries.sort((a,b)=>b.sort.localeCompare(a.sort));return entries.slice(0,Math.max(1,Math.min(100,Number(limit)||12)));
}
function actualActivityBody(limit=12){
 const data=realOperations(),summary=data.summary,rows=actualActivityEntries(limit);
 const purchaseTotal=summary.purchaseTotalCUP===null?'No calculable':money(summary.purchaseTotalCUP)+' CUP';
 const netSales=summary.netSalesCUP===null?'No disponible':money(summary.netSalesCUP)+' CUP';
 const table=rows.length?`<div class="pcbm-table-wrap"><table class="pcbm-table"><thead><tr><th>Fecha</th><th>Registro principal</th><th>Detalle</th><th>Importe / estado</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.date||'Sin fecha')}</td><td><b>${esc(r.type)}</b></td><td>${esc(r.detail)}</td><td>${esc(r.amount)}</td></tr>`).join('')}</tbody></table></div>`:'<p>Los registros de Compras, Ventas, Cierres y Transferencias aparecerán aquí automáticamente cuando existan operaciones guardadas.</p>';
 return `<div class="pcbm-grid pcbm-kpis"><div class="pcbm-kpi"><span>Compras del mes</span><strong>${summary.purchaseCount}</strong><small>Valor registrado: ${esc(purchaseTotal)}. No indica si está pagado.</small></div><div class="pcbm-kpi"><span>Ventas netas registradas en CUP</span><strong>${esc(netSales)}</strong><small>${summary.salesCount} venta(s) y ${summary.returnCount} devolución(es) en tickets este mes; ${summary.estimatedClosingsCount||0} cierre(s) IPV estimado(s). Fuente: ${esc(summary.salesSource||'Sin datos de ventas')}. No equivale por sí solo a efectivo cobrado.</small></div><div class="pcbm-kpi"><span>Cierres / transferencias del mes</span><strong>${summary.closingsCount} / ${summary.transfersCount}</strong><small>${summary.pendingCloseCount} venta(s) marcada(s) explícitamente como pendiente(s) de cierre.</small></div></div>${table}<p class="pcbm-note">Datos de solo lectura del registro principal de ProControl. No se crean movimientos de caja ni deudas automáticamente porque el historial no siempre especifica método de pago, crédito o vencimiento.</p>`;
}
function actualPurchasePayablesReference(limit=8){
 const rows=getPurchases().slice().sort((a,b)=>String(b.ts||b.createdAt||recordDateISO(b)).localeCompare(String(a.ts||a.createdAt||recordDateISO(a)))).slice(0,limit);
 return panel('Compras reales que no tienen estado de pago registrado',rows.length?`<p>Estas compras se leen del registro principal. La compra no indica necesariamente si se pagó al contado, quedó a crédito ni la fecha pactada. Se muestran como referencia, pero no se convierten automáticamente en cuentas por pagar.</p><div class="pcbm-table-wrap"><table class="pcbm-table"><thead><tr><th>Fecha</th><th>Proveedor</th><th>Teléfono</th><th>Importe</th><th>Estado de pago</th></tr></thead><tbody>${rows.map(p=>{const amount=purchaseRecordAmount(p);return `<tr><td>${esc(recordDateISO(p)||'Sin fecha')}</td><td>${esc(p.supplier||p.supplierName||'Sin proveedor')}</td><td>${esc(p.supplierPhone||p.phone||'No registrado')}</td><td>${amount===null?'No calculable':money(amount)+' CUP'}</td><td>No capturado en la compra</td></tr>`;}).join('')}</tbody></table></div>`:'<p>No hay compras registradas en el sistema principal.</p>');
}

const tabs=[
 ['overview','Resumen y salud económica','Indicadores resumidos, salud del inventario y prioridades.'],
 ['receivables','Cuentas por cobrar','Controla clientes, vencimientos, cobros parciales y saldos pendientes.'],
 ['payables','Cuentas por pagar','Controla obligaciones, vencimientos, pagos parciales y compromisos.'],
 ['suppliers','Proveedores','Organiza contactos y plazos de abastecimiento.'],
 ['rates','Monedas y tasas','Registra tasas actuales, incluida una moneda personalizada.'],
 ['replenishment','Compras inteligentes','Consulta propuestas de reposición y los motivos de cada sugerencia.'],
 ['abc','Inventario ABC','Prioriza los productos según su movimiento y participación en ventas comparables.'],
 ['movement','Mercancía inmovilizada','Detecta existencias con ventas antiguas o historial insuficiente.'],
 ['margins','Márgenes estimados','Compara coste de adquisición con precios en CUP, efectivo y transferencia.'],
 ['simPrice','Simulador de precios','Compara ingresos y margen bruto estimados antes de cambiar un precio.'],
 ['simStock','Simulador de reposición','Evalúa cobertura y posible faltante sin modificar el inventario real.'],
 ['branches','Comparación de puntos de venta','Compara ventas, productos líderes, devoluciones e inventario local por punto.'],
];
let transactionChartCurrency='CUP';
const CHART_COLORS=['#e6c574','#7bb4e3','#82c99b','#d58d9b','#b5a0e8','#e5a96d','#d7a7ef','#8dcad0','#c1a26c','#9caedb'];
const chartModes=new Map(),chartConfigs=new Map();
// La comparación se construye a demanda: el Dueño añade hasta cuatro puntos, nunca se precargan todos.
let selectedBranchIds=[];
function branchSelectionKey(point){const id=String(point&&(point.id||point.posId)||'').trim();return id?'id:'+id:'name:'+normalizeSupplierKey(point&&(point.name||point.posName)||'Punto de venta');}
function bindBranchControls(container){
 const add=container.querySelector('[data-branch-add]');
 if(add)add.addEventListener('click',()=>{const select=container.querySelector('#pcbm-branch-select'),key=String(select&&select.value||'');if(!key||selectedBranchIds.includes(key)||selectedBranchIds.length>=4)return;selectedBranchIds.push(key);render();});
 container.querySelectorAll('[data-branch-remove]').forEach(button=>button.addEventListener('click',()=>{const key=String(button.getAttribute('data-branch-remove')||'');selectedBranchIds=selectedBranchIds.filter(value=>value!==key);render();}));
}
const formatChartValue=(v,unit='count')=>unit==='money'?money(v):unit==='percent'?`${grouped(v,2)}%`:unit==='days'?`${grouped(v,0)} días`:grouped(v,2);
function chartEmpty(message='Todavía no hay datos suficientes para mostrar esta gráfica.'){return `<div class="pcbm-chart-empty"><span aria-hidden="true">▥</span><p>${esc(message)}</p></div>`;}
function chartVisual(rows,mode,options={}){
 const unit=options.unit||'count',suffix=options.suffix?` ${esc(options.suffix)}`:'';
 const valid=(rows||[]).filter(row=>row&&Number.isFinite(Number(row.value))).slice(0,options.limit||12).map(row=>({...row,value:Number(row.value)}));
 if(!valid.length||!valid.some(row=>Math.abs(row.value)>0))return chartEmpty(options.emptyMessage||'Todavía no hay datos suficientes para mostrar esta gráfica.');
 const positiveRows=valid.map(row=>({...row,value:Math.max(0,row.value)}));
 if(mode==='pie'){
  if(valid.some(row=>row.value<0))return chartEmpty('El gráfico de pastel no representa valores negativos. Cambia a barras, líneas o área para comparar resultados por encima y por debajo de cero.');
  const pieRows=positiveRows.filter(row=>row.value>0),total=pieRows.reduce((sum,row)=>sum+row.value,0);if(!total)return chartEmpty(options.emptyMessage);
  let cursor=0;const stops=pieRows.map((row,index)=>{const start=cursor;cursor+=row.value/total*100;return `${CHART_COLORS[index%CHART_COLORS.length]} ${start.toFixed(2)}% ${cursor.toFixed(2)}%`;}).join(',');
  return `<div class="pcbm-donut-layout"><div class="pcbm-donut" role="img" aria-label="${esc(options.title||'Gráfico de pastel')}; total ${formatChartValue(total,unit)}" style="background:conic-gradient(${stops})"><div class="pcbm-donut-hole"><strong>${formatChartValue(total,unit)}</strong><small>${esc(options.centerLabel||'Total')}</small></div></div><ul class="pcbm-chart-legend">${pieRows.map((row,index)=>`<li><span class="pcbm-legend-dot" style="background:${CHART_COLORS[index%CHART_COLORS.length]}"></span><span class="pcbm-legend-label">${esc(row.label)}</span><strong>${formatChartValue(row.value,unit)}${suffix}</strong><small>${grouped(row.value/total*100,2)}%</small></li>`).join('')}</ul></div>`;
 }
 const width=960,height=350,right=28,top=28,bottom=78;
 const minValue=Math.min(0,...valid.map(row=>row.value)),maxValue=Math.max(0,...valid.map(row=>row.value)),range=Math.max(1,maxValue-minValue);
 // El eje Y calcula su margen con las etiquetas reales; nunca recorta cifras largas como 100.010.000.
 const axisLabels=Array.from({length:5},(_,i)=>formatChartValue(maxValue-(range*i/4),unit));
 const axisFontSize=20;
 const longestAxisLabel=axisLabels.reduce((longest,label)=>Math.max(longest,String(label).length),0);
 const estimatedAxisLabelWidth=longestAxisLabel*axisFontSize*.64;
 const left=Math.max(104,Math.ceil(estimatedAxisLabelWidth+30));
 const plotW=Math.max(260,width-left-right),plotH=height-top-bottom;
 const zeroY=top+(maxValue/range)*plotH;
 const y=value=>top+((maxValue-value)/range)*plotH;
 const count=valid.length,slot=plotW/count,barW=Math.max(12,Math.min(48,slot*.62)),numberLabelSize=count>8?17:20;
 const grid=axisLabels.map((label,i)=>{const value=maxValue-(range*i/4),yy=y(value);return `<line x1="${left}" y1="${yy.toFixed(1)}" x2="${width-right}" y2="${yy.toFixed(1)}" stroke="#344252" stroke-dasharray="4 5"/><text x="${left-10}" y="${(yy+4).toFixed(1)}" text-anchor="end" font-size="${axisFontSize}" font-weight="700" fill="#c5d0dc">${esc(label)}</text>`;}).join('');
 const xLabel=(row,index)=>{const x=left+slot*index+slot/2;const label=String(row.label||'').length>16?String(row.label).slice(0,15)+'…':String(row.label||'');return `<text x="${x.toFixed(1)}" y="${height-28}" text-anchor="middle" font-size="18" font-weight="700" fill="#d6e0ea">${esc(label)}</text>`;};
 let marks='';
 if(mode==='bar'){
  marks=valid.map((row,index)=>{const x=left+slot*index+(slot-barW)/2,yy=y(row.value),base=zeroY,bh=Math.max(1,Math.abs(base-yy));return `<rect x="${x.toFixed(1)}" y="${Math.min(yy,base).toFixed(1)}" width="${barW.toFixed(1)}" height="${bh.toFixed(1)}" rx="5" fill="${CHART_COLORS[index%CHART_COLORS.length]}" opacity=".93"><title>${esc(row.label)}: ${esc(formatChartValue(row.value,unit))}${suffix}</title></rect><text x="${(x+barW/2).toFixed(1)}" y="${(Math.min(yy,base)-7).toFixed(1)}" text-anchor="middle" font-size="${numberLabelSize}" font-weight="700" fill="#f6e4b1">${esc(formatChartValue(row.value,unit))}</text>`;}).join('');
 }else{
  const points=valid.map((row,index)=>({x:left+slot*index+slot/2,y:y(row.value),row}));
  const line=points.map(point=>`${point.x.toFixed(1)},${point.y.toFixed(1)}`).join(' ');
  const area=mode==='area'?`<polygon points="${points[0].x},${zeroY} ${line} ${points[points.length-1].x},${zeroY}" fill="#d7b45f" opacity=".18"/>`:'';
  marks=area+`<polyline points="${line}" fill="none" stroke="#e6c574" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>`+points.map((point,index)=>`<circle cx="${point.x.toFixed(1)}" cy="${point.y.toFixed(1)}" r="6" fill="${CHART_COLORS[index%CHART_COLORS.length]}" stroke="#101923" stroke-width="2"><title>${esc(point.row.label)}: ${esc(formatChartValue(point.row.value,unit))}${suffix}</title></circle><text x="${point.x.toFixed(1)}" y="${Math.max(18,point.y-13).toFixed(1)}" text-anchor="middle" font-size="${numberLabelSize}" font-weight="700" fill="#f6e4b1">${esc(formatChartValue(point.row.value,unit))}</text>`).join('');
 }
 return `<div class="pcbm-svg-chart"><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(options.title||'Gráfico')} en ${mode==='bar'?'barras':mode==='line'?'líneas':mode==='area'?'área':'pastel'}" preserveAspectRatio="xMidYMid meet">${grid}<line x1="${left}" y1="${zeroY.toFixed(1)}" x2="${width-right}" y2="${zeroY.toFixed(1)}" stroke="#8997a7" stroke-width="1.2"/>${marks}${valid.map(xLabel).join('')}</svg></div>`;
}
function chartWidget(title,items,options={},defaultMode='bar'){
 const rows=(items||[]).filter(row=>row&&Number.isFinite(Number(row.value))).slice(0,options.limit||12),chartSlug=String(title||'grafico').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,64),idKey=`pcbm-chart-${chartSlug||'grafico'}`;
 const config={...options,title};chartConfigs.set(idKey,{rows,options:config});
 const mode=chartModes.get(idKey)||defaultMode;
 const desc=options.description?`<p class="pcbm-chart-desc">${esc(options.description)}</p>`:'';
 const selector=`<label class="pcbm-chart-mode-label">Ver como<select class="pcbm-chart-mode" data-chart-mode="${idKey}" aria-label="Tipo de gráfico para ${esc(title)}"><option value="bar" ${mode==='bar'?'selected':''}>Barras</option><option value="line" ${mode==='line'?'selected':''}>Líneas</option><option value="pie" ${mode==='pie'?'selected':''}>Pastel</option><option value="area" ${mode==='area'?'selected':''}>Área</option></select></label>`;
 return `<section class="pcbm-chart-card"><div class="pcbm-chart-heading"><h3>${esc(title)}</h3><div class="pcbm-chart-tools">${options.badge?`<span class="pcbm-chart-badge">${esc(options.badge)}</span>`:''}${selector}</div></div>${desc}<div class="pcbm-chart-visual">${chartVisual(rows,mode,config)}</div></section>`;
}
function barChart(title,items,options={}){return chartWidget(title,items,options,'bar');}
function donutChart(title,items,options={}){return chartWidget(title,items,{...options,centerLabel:options.centerLabel||'Total'},'pie');}
function chartGrid(...charts){return `<div class="pcbm-chart-grid">${charts.filter(Boolean).join('')}</div>`;}
function viewIntro(eyebrow,title,description){return `<div class="pcbm-view-intro"><p class="pcbm-eyebrow">${esc(eyebrow)}</p><h3>${esc(title)}</h3><p>${esc(description)}</p></div>`;}
function kpi(label,value,help){return `<div class="pcbm-kpi"><span>${esc(label)}</span><strong>${esc(value)}</strong><small>${esc(help)}</small></div>`;}
function actionButton(label,tab,icon='↗'){return `<button type="button" class="pcbm-btn" data-open-tab="${esc(tab)}"><span aria-hidden="true">${icon}</span> ${esc(label)}</button>`;}
function dueRows(type){const today=new Date().toISOString().slice(0,10);return state[type].map(d=>{const remaining=Math.max(0,Number(d.amount)-Number(d.paid||0));return {...d,remaining,settled:remaining<=0,overdue:remaining>0&&Boolean(d.dueDate)&&d.dueDate<today,dueSoon:remaining>0&&Boolean(d.dueDate)&&d.dueDate>=today&&d.dueDate<=new Date(Date.now()+7*86400000).toISOString().slice(0,10)};});}
function summaryMetrics(){
 const inventory=getInventory(),sales=getSales(),closings=getClosingHistory();
 const closingSales=buildLegacyClosingSales(closings,sales),analysisSales=sales.concat(closingSales);
 const today=new Date().toISOString().slice(0,10);
 const planningDays=Math.max(1,Math.min(365,Number(state.settings.lowStockDays)||14));
 const suggestions=suggestReplenishment(inventory,analysisSales,planningDays,new Date(),{pointsOfSale:getPointsOfSale(),supplierDirectory:summarizeSupplierPurchases(getPurchases(),state.suppliers),purchases:getPurchases()});
 const overduePayables=dueRows('payables').filter(d=>d.overdue),overdueReceivables=dueRows('receivables').filter(d=>d.overdue);
 const overdueRows=[...overduePayables,...overdueReceivables];
 const pendingSales=sales.filter(isSalePendingClose).length;
 const salesEvidence=sales.some(r=>r&&typeof r==='object'&&Array.isArray(r.items)&&r.items.length>0)||closingSales.some(r=>Array.isArray(r.items)&&r.items.length>0);
 const closingDifferences=closings.filter(c=>c&&c.difference!=null&&String(c.difference).trim()!==''&&Number.isFinite(Number(c.difference))&&Math.abs(Number(c.difference))>0.000001).length;
 const movementReviewCount=salesEvidence?inventoryMovementAnalysis(inventory,analysisSales,new Date(),30).filter(r=>r.needsReview).length:0;
 const marginRows=buildMarginAnalysis(inventory);
 const negativeMargins=marginRows.filter(p=>(p.cashMargin!==null&&p.cashMargin<0)||(p.transferMargin!==null&&p.transferMargin<0)).length;
 const assessment=healthAssessment({hasTransactions:false,hasInventory:inventory.length>0,liquidityKnown:false,cashAvailable:NaN,includeLiquidity:false,includePendingOperations:false,overdue:overdueRows.length,pending:0,stockAlerts:suggestions.length,requireMainOperationalEvidence:true,hasSalesEvidence:salesEvidence,hasClosingEvidence:closings.length>0,closingDifferences,pendingSales,movementReviewCount,negativeMargins,salesEvidenceDetail:closingSales.length&&!sales.some(r=>r&&Array.isArray(r.items)&&r.items.length)?'La demanda incluye estimaciones del flujo IPV guardadas en cierres; no son tickets individuales.':'La demanda se calcula con registros de venta guardados y devoluciones cuando están disponibles.'});
 const actions=[];
 if(overduePayables.length)actions.push({kind:'attention',title:`${overduePayables.length} cuenta(s) por pagar vencida(s)`,detail:'Revisa el vencimiento y actualiza el seguimiento cuando el pago se haya realizado en tu aplicación bancaria.',tab:'payables'});
 if(overdueReceivables.length)actions.push({kind:'attention',title:`${overdueReceivables.length} cuenta(s) por cobrar vencida(s)`,detail:'Revisa el cobro y actualiza el seguimiento cuando se haya recibido el dinero.',tab:'receivables'});
 if(negativeMargins)actions.push({kind:'attention',title:`${negativeMargins} producto(s) con margen bruto negativo`,detail:'El precio efectivo o de transferencia está por debajo del coste de adquisición, incluido el Extra asignado.',tab:'margins'});
 if(suggestions.length)actions.push({kind:'attention',title:`${suggestions.length} producto(s) con reposición sugerida`,detail:'Confirma existencias, demanda y margen antes de decidir.',tab:'replenishment'});
 if(movementReviewCount)actions.push({kind:'attention',title:`${movementReviewCount} producto(s) necesitan revisar su movimiento`,detail:'El historial disponible muestra ventas antiguas o sin fecha; comprueba los registros antes de considerar mercancía inmovilizada.',tab:'movement'});
 if(!inventory.length)actions.push({kind:'unknown',title:'Inventario sin datos suficientes',detail:'No hay productos disponibles para evaluar la reposición o la mercancía inmovilizada.',tab:'movement'});
 if(!salesEvidence)actions.push({kind:'unknown',title:'Aún no hay historial suficiente de ventas por producto',detail:'El análisis de demanda y ABC se actualizará con los datos operativos disponibles; no es obligatorio registrar tickets individuales.',tab:'abc'});
 if(!closings.length)actions.push({kind:'unknown',title:'Todavía no hay cierres registrados',detail:'Cuando haya cierres, podrán evaluarse las diferencias registradas.',tab:'branches'});
 return {inventory,sales,analysisSales,closings,closingSales,suggestions,planningDays,today,overdueRows,pendingSales,closingDifferences,movementReviewCount,negativeMargins,salesEvidence,assessment,actions,overduePayables,overdueReceivables};
}
function overview(){
 const m=summaryMetrics(),symbol={risk:'!',attention:'•',unknown:'?',stable:'✓'};
 const actionHtml=m.actions.length?`<ul class="pcbm-priority-list">${m.actions.slice(0,6).map(a=>`<li class="pcbm-priority-item pcbm-priority-${a.kind}"><span>${symbol[a.kind]||'•'}</span><div><b>${esc(a.title)}</b><small>${esc(a.detail)}</small><div class="pcbm-inline-action">${actionButton('Revisar',a.tab,'↗')}</div></div></li>`).join('')}</ul>`:'<p>No hay acciones prioritarias calculadas. Los indicadores se actualizarán con las operaciones disponibles.</p>';
 const abcRows=analyticsData().abc;const abcCounts=['A','B','C'].map(category=>({label:'Clase '+category,value:abcRows.filter(row=>row.category===category).length}));
 return `${viewIntro('RESUMEN DEL NEGOCIO','Resumen y salud económica','Indicadores resumidos de inventario y seguimiento comercial. El detalle de los registros y operaciones se consulta en Histórico; esta vista no muestra movimientos ni listados de registros.')} 
 <section class="pcbm-health-card pcbm-health-${m.assessment.status}" aria-live="polite"><div class="pcbm-health-top"><span class="pcbm-health-light" aria-hidden="true">${symbol[m.assessment.status]}</span><div><span class="pcbm-eyebrow">SEMÁFORO DE SALUD ECONÓMICA</span><h3>${esc(m.assessment.label)}</h3></div></div><p>${esc(m.assessment.summary)}</p><details class="pcbm-health-details"><summary>¿Qué factores forman este estado?</summary><ul class="pcbm-list">${m.assessment.checks.map(c=>`<li class="pcbm-check-${c.state}"><b>${esc(c.label)}:</b> ${esc(c.detail)}</li>`).join('')}</ul></details></section>
 <div class="pcbm-grid pcbm-kpis pcbm-kpis-main">${kpi('Productos en inventario',String(m.inventory.length),'Cantidad de productos disponibles en el inventario.')}${kpi('Reposiciones sugeridas',String(m.suggestions.length),'Productos cuyos mínimos o demanda requieren revisión.')}${kpi('Cuentas por pagar vencidas',String(m.overduePayables.length),'Seguimiento de obligaciones vencidas.')}${kpi('Cuentas por cobrar vencidas',String(m.overdueReceivables.length),'Seguimiento de cobros vencidos.')}</div>
 ${chartGrid(barChart('Productos con reposición sugerida',m.suggestions.slice().sort((a,b)=>b.suggested-a.suggested).slice(0,10).map(r=>({label:r.name,value:r.suggested})),{unit:'count',description:'Cantidad sugerida por producto, no valor monetario.',emptyMessage:'No hay productos con reposición sugerida.'}),donutChart('Distribución del inventario ABC',abcCounts,{centerLabel:'Productos',description:'Cantidad de productos en cada clase según su participación en ingresos comparables.'}))}
 ${panel('Qué necesita atención',actionHtml)}<div class="pcbm-actions">${actionButton('Ver compras sugeridas','replenishment','▤')}${actionButton('Revisar márgenes','margins','％')}</div>
 <p class="pcbm-footnote">Los indicadores son señales orientativas basadas en inventario, ventas, cierres y obligaciones registradas. El detalle se mantiene en Histórico y el dinero bancario se gestiona en la aplicación bancaria correspondiente.</p>`;
}
function debtView(type){
 const label=type==='receivables'?'por cobrar':'por pagar';const title=type==='receivables'?'Cuentas por cobrar':'Cuentas por pagar';const arr=dueRows(type);const open=arr.filter(d=>!d.settled);const overdue=arr.filter(d=>d.overdue);const overdueCount=overdue.length;const outstandingByCurrency=CURRENCIES.map(currency=>({label:currency,value:open.filter(d=>d.currency===currency).reduce((s,d)=>s+d.remaining,0)})).filter(x=>x.value>0);
 const statusPie=[{label:'Vencidas',value:overdue.length},{label:'Pendientes vigentes',value:open.filter(d=>!d.overdue).length},{label:'Liquidadas',value:arr.filter(d=>d.settled).length}];
 const rows=arr.slice().sort((a,b)=>(a.dueDate||'').localeCompare(b.dueDate||''));
 return `${viewIntro(type==='receivables'?'COBROS':'PAGOS',title, type==='receivables'?'Registra clientes o entidades que deben dinero al negocio, fechas de vencimiento y cobros parciales.':'Registra obligaciones con proveedores u otras personas. Mantén los vencimientos y pagos parciales actualizados.')}
 <div class="pcbm-grid pcbm-kpis">${kpi('Cuentas registradas',String(arr.length),'Incluye cuentas liquidadas y abiertas.')}${kpi('Pendientes',String(open.length),'Cuentas con saldo por cobrar o pagar.')}${kpi('Vencidas',String(overdueCount),'Requieren revisión; no indica por sí solo que sean incobrables.')}</div>
 ${chartGrid(donutChart('Estado de las cuentas',statusPie,{centerLabel:'Cuentas'}),...outstandingByCurrency.map(x=>barChart(`Saldo pendiente · ${x.label}`,[{label:title,value:x.value}],{unit:'money',suffix:x.label,description:'Importes de esta moneda; no se suman con otras monedas.'})))}
 ${panel(`Registrar cuenta ${label}`,`<form id="pcbm-debt-form" class="pcbm-form">${field(type==='receivables'?'Cliente':'Proveedor o destinatario','pcbm-debt-name')}${field('Descripción','pcbm-debt-desc')}${field('Importe total','pcbm-debt-amount','number','',{min:'0.01',step:'0.01',required:'required'})}<label class="pcbm-field">Moneda<select id="pcbm-debt-currency">${currencyOptions()}</select></label>${field('Fecha de vencimiento','pcbm-debt-due','date',new Date().toISOString().slice(0,10),'required')}<p class="pcbm-note pcbm-wide">Este apartado solo da seguimiento a la deuda. El pago o cobro real se realiza y verifica en la aplicación bancaria correspondiente.</p><button class="pcbm-btn pcbm-primary" type="submit">Guardar cuenta</button></form>`)}
 ${panel(`Cuentas ${label}`,rows.length?`<div class="pcbm-table-wrap"><table class="pcbm-table"><thead><tr><th>Nombre</th><th>Vence</th><th>Total</th><th>Pagado/cobrado</th><th>Pendiente</th><th>Estado/acción</th></tr></thead><tbody>${rows.map(d=>`<tr><td>${esc(d.name)}<small>${esc(d.description||'')}</small></td><td>${esc(d.dueDate||'—')}</td><td>${money(d.amount)} ${esc(d.currency)}</td><td>${money(d.paid||0)} ${esc(d.currency)}</td><td>${money(d.remaining)} ${esc(d.currency)}</td><td>${d.settled?'Liquidada':d.overdue?'Vencida':d.dueSoon?'Vence en 7 días':'Pendiente'} ${!d.settled?`<button class="pcbm-btn" data-settle="${esc(d.id)}" data-type="${type}">${type==='receivables'?'Registrar cobro':'Registrar pago'}</button>`:''}</td></tr>`).join('')}</tbody></table></div>`:'<p>No hay cuentas registradas. Utiliza el formulario para añadir la primera.</p>')}${type==='payables'?actualPurchasePayablesReference(8):''}`;
}
function suppliersView(){
 const suppliers=summarizeSupplierPurchases(getPurchases(),state.suppliers);
 const purchased=suppliers.filter(s=>s.purchaseCount>0),legacy=suppliers.filter(s=>s.purchaseCount===0);
 const withPhone=purchased.filter(s=>s.phone).length;
 const countChart=barChart('Compras registradas por proveedor',purchased.slice().sort((a,b)=>b.purchaseCount-a.purchaseCount).slice(0,10).map(s=>({label:s.name,value:s.purchaseCount})),{unit:'count',description:'Se cuentan compras guardadas en el módulo principal, no pagos.'});
 const spendRows=purchased.filter(s=>s.totalAcquisition!==null).slice().sort((a,b)=>b.totalAcquisition-a.totalAcquisition).slice(0,10);
 const spendChart=barChart('Valor de compra registrado por proveedor',spendRows.map(s=>({label:s.name,value:s.totalAcquisition})),{unit:'money',suffix:'CUP',description:'Importes registrados en las compras, incluido el Extra si existía. No es un saldo pendiente.'});
 const selectOptions=suppliers.map(s=>`<option value="${esc(s.key)}">${esc(s.name)}${s.phone?' · '+esc(s.phone):''}</option>`).join('');
 const table=suppliers.length?`<div class="pcbm-table-wrap"><table class="pcbm-table"><thead><tr><th>Proveedor</th><th>Teléfono</th><th>Compras guardadas</th><th>Última compra</th><th>Valor total registrado</th><th>Plazo logístico opcional</th><th>Origen</th></tr></thead><tbody>${suppliers.map(s=>`<tr><td><b>${esc(s.name)}</b>${s.notes?`<small>${esc(s.notes)}</small>`:''}</td><td>${s.phone?`<a href="tel:${esc(s.phone)}">${esc(s.phone)}</a>`:'<span class="pcbm-note">No registrado</span>'}</td><td>${s.purchaseCount}</td><td>${esc(s.lastPurchase||'Sin fecha')}</td><td>${s.purchaseCount===0?'—':s.totalAcquisition===null?'No calculable':money(s.totalAcquisition)+' CUP'}</td><td>${Number(s.leadDays)>0?`${Number(s.leadDays)} días`:'Sin configurar'}</td><td>${s.purchaseCount?'Compras reales':'Registro antiguo'}</td></tr>`).join('')}</tbody></table></div>`:'<p>No hay proveedores identificados todavía. La lista aparecerá automáticamente cuando registres una compra con el nombre del proveedor en Compras → Nueva compra.</p>';
 const logisticsForm=suppliers.length
  ? `<p class="pcbm-note">No vuelvas a escribir el nombre o el teléfono aquí. Esos datos se mantienen desde Compras. Este formulario solo guarda contacto adicional, plazo habitual y notas para ayudar con la reposición.</p><form id="pcbm-supplier-form" class="pcbm-form"><label class="pcbm-field pcbm-wide">Proveedor<select id="pcbm-supplier-key" required><option value="">Seleccionar proveedor existente</option>${selectOptions}</select></label>${field('Contacto adicional (opcional)','pcbm-supplier-contact')}${field('Plazo de abastecimiento (días, si se conoce)','pcbm-supplier-lead','number','','min="0" max="3650" step="1"')}<label class="pcbm-field pcbm-wide">Notas logísticas (opcional)<input id="pcbm-supplier-notes" maxlength="500"></label><button class="pcbm-btn pcbm-primary" type="submit">Guardar datos logísticos</button></form>`
  : '<p>Primero registra una compra con proveedor desde el módulo principal. No es necesario crear el proveedor manualmente aquí.</p>';
 return `${viewIntro('ABASTECIMIENTO','Proveedores','El directorio principal se construye automáticamente desde las compras reales. El nombre y el teléfono se introducen una vez en Compras; aquí solo se completan datos logísticos que la aplicación no conoce.')}
 <div class="pcbm-grid pcbm-kpis">${kpi('Proveedores encontrados',String(suppliers.length),'Derivados de las compras y registros anteriores.')}${kpi('Con teléfono conocido',String(withPhone),'Se obtiene del teléfono opcional guardado en las compras.')}${kpi('Con compra registrada',String(purchased.length),`${purchased.reduce((n,s)=>n+s.purchaseCount,0)} compras en el historial principal.`)}</div>
 ${chartGrid(countChart,spendChart,donutChart('Origen del directorio',[{label:'Con compras',value:purchased.length},{label:'Solo registro antiguo',value:legacy.length}],{centerLabel:'Proveedores'}))}
 ${panel('Directorio automático de proveedores',table)}
 ${panel('Completar datos logísticos opcionales',logisticsForm)}`;
}
function ratesView(){
 const today=new Date().toISOString().slice(0,10);
 const normalizeCurrencyName=value=>cleanCurrencyLabel(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase();
 const currentByKey=new Map();
 const addDefault=(currency,label)=>currentByKey.set(currency,{currency,label,rate:0,date:'',source:'',hasRecord:false});
 addDefault('USD','USD');addDefault('EUR','EUR');addDefault('MLC','MLC');
 state.rates.forEach((record,index)=>{
  if(!record||!record.currency||String(record.date||'')>today||!/^\d{4}-\d{2}-\d{2}$/.test(String(record.date||'')))return;
  const currency=String(record.currency).toUpperCase();
  const label=rateCurrencyLabel(record);
  if(!['USD','EUR','MLC','OTRA'].includes(currency)||!label)return;
  const key=currency==='OTRA'?'OTRA:'+normalizeCurrencyName(label):currency;
  const previous=currentByKey.get(key);
  if(!previous||!previous.hasRecord||String(record.date)>String(previous.date)||(String(record.date)===String(previous.date)&&index>previous.index)){
   currentByKey.set(key,{currency,label,rate:Number(record.rate)||0,date:String(record.date||''),source:String(record.source||''),hasRecord:true,index});
  }
 });
 if(!currentByKey.get('USD')?.hasRecord){const fallback=Number(getMainDollarRate());if(Number.isFinite(fallback)&&fallback>0)currentByKey.set('USD',{currency:'USD',label:'USD',rate:fallback,date:'',source:'Tasa principal de ProControl',hasRecord:false});}
 const order={USD:0,EUR:1,MLC:2,OTRA:3};
 const currencies=Array.from(currentByKey.values()).sort((a,b)=>(order[a.currency]??4)-(order[b.currency]??4)||a.label.localeCompare(b.label,'es',{sensitivity:'base'}));
 const rows=currencies.map(row=>`<article class="pcbm-rate-current-card"><div class="pcbm-rate-current-meta"><span class="pcbm-rate-current-code">${esc(row.label)}</span><strong>${row.rate>0?money(row.rate)+' CUP':'Sin tasa configurada'}</strong></div><button type="button" class="pcbm-btn pcbm-rate-edit" data-edit-rate="${esc(row.currency)}" data-edit-rate-custom="${esc(row.currency==='OTRA'?row.label:'')}" data-edit-rate-value="${esc(row.rate>0?String(row.rate):'')}" aria-label="Editar tasa de ${esc(row.label)}">Editar precio</button></article>`).join('');
 return `${viewIntro('CONFIGURACIÓN MULTIMONEDA','Monedas y tasas','Añade una moneda disponible o edita su equivalencia actual en CUP. La tasa se aplica desde hoy; el historial de operaciones anteriores se conserva internamente.')}
 <style>.pcbm-rate-current-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.pcbm-rate-current-card{min-width:0;display:flex;flex-direction:column;justify-content:space-between;gap:10px;padding:12px;border:1px solid #8e7744;border-radius:9px;background:#111b27}.pcbm-rate-current-meta{display:flex;flex-direction:column;gap:5px;min-width:0}.pcbm-rate-current-code{color:#f0d58b;font-size:12px;font-weight:850;overflow-wrap:anywhere}.pcbm-rate-current-meta strong{color:#fff;font-size:16px;overflow-wrap:anywhere}.pcbm-rate-edit{align-self:flex-start;padding:6px 9px;font-size:11px}@media(max-width:560px){.pcbm-rate-current-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.pcbm-rate-current-meta strong{font-size:13px}}</style>
 ${panel('Añadir moneda o editar su precio',`<form id="pcbm-rate-form" class="pcbm-form"><label class="pcbm-field">Moneda<select id="pcbm-rate-currency">${['USD','EUR','MLC','OTRA'].map(c=>`<option value="${c}">${c==='OTRA'?'Otra moneda':c}</option>`).join('')}</select></label><label id="pcbm-rate-custom-wrap" class="pcbm-field" style="display:none">Nombre de la moneda<input id="pcbm-rate-custom" type="text" maxlength="40" placeholder="Ej.: BRL, CAD, Real brasileño"></label>${field('Valor de 1 unidad en CUP','pcbm-rate-value','number','','min="0" step="any" inputmode="decimal" required="required"')}<label class="pcbm-field pcbm-wide">Nota (opcional)<input id="pcbm-rate-source" type="text" maxlength="180" placeholder="Origen o referencia de la tasa"></label><button class="pcbm-btn pcbm-primary" type="submit">Guardar tasa actual</button><button class="pcbm-btn" type="button" id="pcbm-rate-cancel" hidden>Cancelar edición</button></form>`)}
 ${panel('Monedas disponibles',`<div class="pcbm-rate-current-grid">${rows}</div><p class="pcbm-note">Las monedas sin una tasa positiva aparecen como «Sin tasa configurada». Usa «Editar precio» para establecer su valor actual en CUP.</p>`)}`;
}
function replenishmentView(){
 const m=summaryMetrics(),rows=m.suggestions,top=rows.slice().sort((a,b)=>b.suggested-a.suggested).slice(0,12);
 const noDemand=rows.filter(row=>row.source!=='sales-history').length,totalSuggestedValue=rows.reduce((sum,row)=>sum+(Number(row.estimatedPurchaseValue)||0),0);
 const reasonCounts=[{label:'Por demanda y plazo',value:rows.filter(row=>row.source==='sales-history').length},{label:'Solo mínimo manual',value:noDemand}];
 const estimatedValueKnown=rows.every(row=>row.estimatedPurchaseValue!==null);
 return `${viewIntro('PLANIFICACIÓN DE ABASTECIMIENTO','Compras inteligentes','La propuesta cruza la demanda neta reciente, devoluciones, existencias del almacén y de cada Punto de venta, el plazo del proveedor, la reserva de seguridad y el coste unitario conocido. No es una orden automática: revisa cada producto antes de comprar.')}
 <div class="pcbm-grid pcbm-kpis">${kpi('Productos con propuesta',String(rows.length),'Solo productos con necesidad estimada mayor que cero.')}${kpi('Horizonte de cobertura',`${m.planningDays} días + plazo + reserva`,'La cantidad busca cubrir el plazo de entrega, la cobertura configurada y 7 días de seguridad.')}${kpi('Valor estimado de compra',estimatedValueKnown?money(totalSuggestedValue)+' CUP':'Parcial / no disponible','Se calcula con el coste unitario registrado en el inventario, que incorpora el Extra asignado cuando está distribuido.')}${kpi('Propuestas sin historial de demanda',String(noDemand),'Se usa el mínimo manual únicamente cuando no existe un historial suficiente por producto.')}</div>
 ${chartGrid(barChart('Cantidad propuesta por producto',top.map(row=>({label:row.name,value:row.suggested})),{unit:'count',description:'La cantidad está expresada en la unidad base de cada producto; no sumes unidades de medida distintas como si fueran equivalentes.'}),barChart('Valor estimado de compra por producto',top.filter(row=>row.estimatedPurchaseValue!==null).map(row=>({label:row.name,value:row.estimatedPurchaseValue})),{unit:'money',suffix:'CUP',description:'Estimación basada en coste unitario registrado. Los productos sin coste conocido se excluyen de este gráfico.'}),donutChart('Origen de las propuestas',reasonCounts,{centerLabel:'Productos',description:'Distingue las propuestas calculadas a partir de demanda de las que solo tienen un mínimo manual.'}))}
 ${panel('Detalle de la propuesta por producto',rows.length?`<div class="pcbm-table-wrap"><table class="pcbm-table"><thead><tr><th>Producto</th><th>Stock almacén</th><th>Stock en POS</th><th>Demanda diaria</th><th>Plazo</th><th>Cobertura / ciclo</th><th>Stock objetivo</th><th>Comprar</th><th>Coste unitario CUP</th><th>Valor estimado CUP</th><th>Última compra</th><th>Motivo / fuente</th></tr></thead><tbody>${rows.map(row=>`<tr><td><b>${esc(row.name)}</b></td><td>${money(row.stock)}</td><td>${money(row.posStock)}</td><td>${row.daily>0?grouped(row.daily,2):'Sin dato'}</td><td>${grouped(row.leadDays,0)} días</td><td>${grouped(row.effectiveCoverDays,2)} + ${grouped(row.safetyDays,0)} días${row.purchaseCycleDays?`<small>Ciclo observado: ${row.purchaseCycleDays} días</small>`:`<small>Sin ciclo suficiente; usa cobertura base</small>`}</td><td>${money(row.targetStock)}</td><td><b>${money(row.suggested)}</b></td><td>${row.unitCost===null?'No disponible':`${money(row.unitCost)} CUP`}<small>Fuente: ${esc(row.unitCostSource||'no disponible')}</small></td><td>${row.estimatedPurchaseValue===null?'No calculable':money(row.estimatedPurchaseValue)+' CUP'}</td><td>${esc(row.lastPurchase||'Sin compra identificada')}</td><td>${esc(row.reason)}<small>Fuente: ${row.source==='sales-history'?'historial de ventas':'mínimo manual'}${row.purchaseHistoryCount?` · ${row.purchaseHistoryCount} compra(s) anteriores`:''}</small></td></tr>`).join('')}</tbody></table></div>`:'<p>No hay compras sugeridas. Esto significa que, con el stock y la demanda conocidos, los productos cubren el horizonte objetivo. Comprueba que los registros de ventas y los mínimos estén actualizados.</p>')}
 <div class="pcbm-card"><h3>Cómo se calcula la cantidad</h3><ol class="pcbm-list"><li>Se calcula la demanda neta a partir de ventas fechadas de hasta 90 días, con más peso para los últimos 30 días, y se descuentan devoluciones. Los tickets sin fecha no se convierten en una tasa diaria inventada.</li><li>Se suma el stock del almacén y de todos los Puntos de venta para evitar comprar mercancía que ya existe en la red.</li><li>Se usa el plazo configurado del proveedor (o 7 días por defecto), la mayor entre la cobertura base y el ciclo de compra observado cuando hay al menos tres fechas de compra, y 7 días de reserva.</li><li>La cantidad sugerida es el objetivo menos el stock de toda la red, respetando el mínimo manual solo como suelo cuando no hay demanda fechada suficiente. Si no hay coste conocido, no se inventa el valor monetario.</li></ol><p class="pcbm-note">${noDemand?`${noDemand} propuesta(s) no tienen demanda fechada suficiente; el mínimo manual se muestra como referencia, no como previsión de consumo.`:'Todas las propuestas disponen de registros de demanda por producto.'} Los cierres IPV sin detalle de productos no se reparten artificialmente entre el inventario.</p></div>`;
}
function analyticsData(){
 const inventory=getInventory(),ledgerSales=getSales(),closings=getClosingHistory(),closingSales=buildLegacyClosingSales(closings,ledgerSales),salesRecords=ledgerSales.concat(closingSales);
 const salesMetrics=aggregateProductSales(inventory,salesRecords);
 const ledgerHasLines=ledgerSales.some(r=>r&&Array.isArray(r.items)&&r.items.length>0);
 const closingHasLines=closingSales.some(r=>r&&Array.isArray(r.items)&&r.items.length>0);
 const legacyRevenueRows=inventory.filter(p=>p&&(p.revenue!=null||p.salesValue!=null)&&Number.isFinite(Number(p.revenue??p.salesValue))&&Number(p.revenue??p.salesValue)>=0);
 const legacyCurrencies=[...new Set(legacyRevenueRows.map(p=>cleanText(p.salesCurrency||p.priceCurrency||p.currency||'',10).toUpperCase()))];
 const legacyRevenueComparable=!ledgerHasLines&&!closingHasLines&&legacyRevenueRows.length>0&&legacyCurrencies.length===1&&Boolean(legacyCurrencies[0]);
 const source=ledgerHasLines&&closingHasLines?'mixed':ledgerHasLines?'book':closingHasLines?'closing':legacyRevenueComparable?'product':'none';
 const hasRecordedLineSales=['book','mixed','closing'].includes(source);
 const abc=abcAnalysis(salesMetrics.map(p=>({productId:p.productId,name:p.name,sold:hasRecordedLineSales?(Number(p.sold)||0):source==='product'&&p.source==='product'?(Number(p.sold)||0):0,revenue:hasRecordedLineSales&&p.source==='book'?p.revenue:source==='product'&&p.source==='product'?p.revenue:0})));
 const margins=buildMarginAnalysis(inventory).sort((a,b)=>(Math.max(a.cashMargin??-Infinity,a.transferMargin??-Infinity))-(Math.max(b.cashMargin??-Infinity,b.transferMargin??-Infinity))).reverse();
 const movement=inventoryMovementAnalysis(inventory,salesRecords,new Date(),30);
 const suggestions=suggestReplenishment(inventory,salesRecords,Number(state.settings.lowStockDays)||14,new Date(),{pointsOfSale:getPointsOfSale(),supplierDirectory:summarizeSupplierPurchases(getPurchases(),state.suppliers),purchases:getPurchases()});
 return {inventory,ledgerSales,closingSales,salesRecords,salesMetrics,ledgerHasLines,closingHasLines,source,legacyCurrencies,abc,margins,movement,suggestions};
}
function abcView(){
 const d=analyticsData(),valid=d.abc.filter(row=>row.category!=='Sin datos'&&row.revenue>0),classes=['A','B','C'].map(category=>{const products=valid.filter(row=>row.category===category);return {label:`Clase ${category}`,value:products.reduce((sum,row)=>sum+row.revenue,0),count:products.length,top:products.slice(0,3)};});
 const revenueSuffix=['book','mixed','closing'].includes(d.source)?'CUP':d.legacyCurrencies?.[0]||'';
 const topRevenue=valid.slice().sort((a,b)=>b.revenue-a.revenue).slice(0,10),topUnits=d.abc.filter(row=>row.sold>0).slice().sort((a,b)=>b.sold-a.sold).slice(0,10);
 const classCounts=['A','B','C'].map(category=>({label:`Clase ${category}`,value:valid.filter(row=>row.category===category).length}));
 const sourceText=d.source==='book'?'Libro de ventas: importes registrados y devoluciones descontadas.':d.source==='closing'?'Cierres IPV históricos: importes estimados y no tickets individuales.':d.source==='mixed'?'Tickets y cierres IPV antiguos sin tickets asociados; la parte IPV es estimada.':d.source==='product'?'Importes explícitos de productos, todos en una moneda identificada.':'No hay ventas comparables. No se estima ingreso multiplicando las unidades por el precio actual ni se mezclan monedas desconocidas.';
 const productShare=valid.length?valid[0].share*100:0;
 return `${viewIntro('PRIORIZACIÓN Y CONCENTRACIÓN','Inventario ABC','El ABC ordena productos por su participación acumulada en ingresos comparables: A concentra aproximadamente el primer 80%, B el siguiente tramo hasta 95% y C el resto. Las unidades, ingresos y participación son métricas distintas; esta clasificación no representa beneficio neto.')}
 <div class="pcbm-grid pcbm-kpis">${kpi('Productos en inventario',String(d.inventory.length),'Catálogo principal del almacén.')}${kpi('Productos con clase',String(valid.length),'Solo se clasifican productos con ventas comparables.')}${kpi('Productos sin datos',String(d.abc.filter(row=>row.category==='Sin datos').length),'No reciben una clase artificial si faltan importes comparables.')}${kpi('Concentración del producto líder',valid.length?grouped(productShare,2)+'%':'No calculable',valid.length?`El producto principal es ${valid[0].name}.`:'No hay ingresos comparables.')}</div>
 ${chartGrid(donutChart('Participación de ingresos por clase',classes.map(row=>({label:row.label,value:row.value})),{unit:'money',suffix:revenueSuffix,centerLabel:'Ingresos',description:'El pastel muestra el reparto monetario entre clases; no es cantidad de productos.'}),barChart('Top 10 por ingresos comparables',topRevenue.map(row=>({label:row.name,value:row.revenue})),{unit:'money',suffix:revenueSuffix,description:'Importes de la fuente identificada; no equivalen a margen ni beneficio.'}),barChart('Top 10 por unidades vendidas',topUnits.map(row=>({label:row.name,value:row.sold})),{unit:'count',description:'Cantidad neta vendida en la unidad base del producto; sirve para ver movimiento, no para calcular la clase monetaria.'}),barChart('Cantidad de productos por clase',classCounts,{unit:'count',description:'Compara cuántos productos quedaron en cada clase según los ingresos disponibles.'}),barChart('Participación acumulada de los 10 principales',topRevenue.slice(0,10).map(row=>({label:row.name,value:row.cumulativeShare*100})),{unit:'percent',description:'Muestra cuánto ingreso acumulado explican los productos ordenados de mayor a menor. Referencias de clasificación: A hasta aproximadamente 80%; B hasta 95%; C el resto.'}))}
 ${panel('Lectura de cada clase',`<div class="pcbm-grid">${classes.map(row=>`<article class="pcbm-kpi"><span>${esc(row.label)} · ${row.count} producto(s)</span><strong>${money(row.value)} ${esc(revenueSuffix)}</strong><small>${row.top.length?`Productos principales: ${row.top.map(item=>esc(item.name)).join(', ')}.`:'No hay productos clasificados en este grupo.'}</small></article>`).join('')}</div><p><b>Clase A:</b> productos que concentran la mayor parte del ingreso; conviene proteger su disponibilidad y revisar sus márgenes con frecuencia.</p><p><b>Clase B:</b> aportan una parte intermedia; pueden crecer si se mejora su exposición o disponibilidad, según la demanda observada.</p><p><b>Clase C:</b> tienen menor participación; no significa que deban eliminarse automáticamente. Comprueba su utilidad, función estratégica y coste de mantenerlos.</p>`)}
 ${panel('Clasificación detallada y criterio de cálculo',`<p>${esc(sourceText)}</p><p>El porcentaje es la participación del ingreso del producto respecto al total comparable; el acumulado suma productos ordenados de mayor a menor. Si un registro no permite comparar la moneda o el importe, la clase aparece como «Sin datos».</p>${d.abc.length?`<div class="pcbm-table-wrap"><table class="pcbm-table"><thead><tr><th>Producto</th><th>Unidades vendidas</th><th>Ingreso comparable</th><th>Ingreso por unidad</th><th>Participación</th><th>Acumulado</th><th>Clase</th></tr></thead><tbody>${d.abc.slice(0,300).map(row=>`<tr><td>${esc(row.name)}</td><td>${money(row.sold)}</td><td>${row.category==='Sin datos'?'Sin datos':`${money(row.revenue)} ${esc(revenueSuffix)}`}</td><td>${row.category==='Sin datos'||row.sold<=0?'—':`${money(row.revenue/row.sold)} ${esc(revenueSuffix)}`}</td><td>${row.category==='Sin datos'?'—':`${grouped(row.share*100,2)}%`}</td><td>${row.category==='Sin datos'?'—':`${grouped(row.cumulativeShare*100,2)}%`}</td><td><b class="pcbm-abc-chip pcbm-abc-${row.category.toLowerCase()}">${esc(row.category)}</b></td></tr>`).join('')}</tbody></table></div>`:'<p>No hay productos en el catálogo.</p>'}`)}
 <div class="pcbm-actions">${actionButton('Revisar productos sin movimiento','movement','◷')}${actionButton('Consultar margen estimado','margins','％')}</div>`;
}
function movementView(){
 const d=analyticsData(),rows=d.movement;const known=rows.filter(r=>r.daysSinceSale!=null);const old=known.filter(r=>r.daysSinceSale>=30);const noHistory=rows.filter(r=>r.daysSinceSale==null);const recent=known.filter(r=>r.daysSinceSale<30);
 const pie=[{label:'Venta registrada hace menos de 30 días',value:recent.length},{label:'30 días o más',value:old.length},{label:'Sin fecha de venta identificable',value:noHistory.length}];
 return `${viewIntro('ROTACIÓN Y CAPITAL INMOVILIZADO','Mercancía sin movimiento reciente','Muestra productos que aún tienen existencias pero tienen ventas antiguas o no disponen de historial suficiente. La falta de historial no demuestra que el producto esté obsoleto.')}
 <div class="pcbm-grid pcbm-kpis">${kpi('Con existencias',String(rows.length),'Productos con stock mayor que cero.')}${kpi('Venta antigua (30+ días)',String(old.length),'Requieren revisar el historial y la demanda.')}${kpi('Sin fecha identificable',String(noHistory.length),'Confirma que el libro de ventas cubra el período.')}</div>
 ${chartGrid(donutChart('Estado del movimiento de inventario',pie,{centerLabel:'Productos'}),barChart('Días desde la última venta conocida',known.slice().sort((a,b)=>b.daysSinceSale-a.daysSinceSale).slice(0,10).map(r=>({label:r.name,value:r.daysSinceSale})),{unit:'days',description:'Solo incluye productos con una fecha de venta identificable.'}))}
 ${panel('Productos para revisar',rows.length?`<div class="pcbm-table-wrap"><table class="pcbm-table"><thead><tr><th>Producto</th><th>Existencias</th><th>Última venta conocida</th><th>Días sin venta</th><th>Lectura</th></tr></thead><tbody>${rows.slice(0,200).map(r=>`<tr><td>${esc(r.name)}</td><td>${r.stock}</td><td>${r.lastSaleDate?esc(r.lastSaleDate):'Sin fecha identificable'}</td><td>${r.daysSinceSale==null?'—':r.daysSinceSale}</td><td>${esc(r.movement)}</td></tr>`).join('')}</tbody></table></div>`:'<p>No hay productos con existencias positivas para revisar.</p>')}<p class="pcbm-note">${d.ledgerHasLines&&d.closingHasLines?'El historial combina tickets y cierres IPV antiguos identificados como estimados; no se duplican los cierres que ya contienen tickets.':d.ledgerHasLines?'El análisis se basa en tickets registrados.':d.closingHasLines?'El análisis se basa en cierres IPV antiguos y es estimado, no equivale a tickets individuales.':'No se dispone de ventas por producto suficientes para datar el movimiento.'} La falta de una venta registrada no demuestra que el producto esté obsoleto.</p>`;
}
function marginsView(){
 const rows=analyticsData().margins;
 const caseRows=rows.flatMap(p=>[
  ...(p.cashPrice>0&&p.cashMargin!==null?[{productId:p.productId,name:p.name,method:'Efectivo',price:p.cashPrice,margin:p.cashMargin,cost:p.cost}]:[]),
  ...(p.transferPrice>0&&p.transferMargin!==null?[{productId:p.productId,name:p.name,method:'Transferencia',price:p.transferPrice,margin:p.transferMargin,cost:p.cost}]:[])
 ]);
 const positive=caseRows.filter(p=>p.margin>0).length,negative=caseRows.filter(p=>p.margin<0).length,zero=caseRows.filter(p=>p.margin===0).length;
 const chartRows=caseRows.slice().sort((a,b)=>b.margin-a.margin).slice(0,10).map(p=>({label:`${p.name} · ${p.method}`,value:p.margin}));
 return `${viewIntro('RENTABILIDAD ORIENTATIVA','Márgenes estimados','El margen utiliza el coste unitario de adquisición del inventario, que incluye el Extra asignado en Compras. Los precios de efectivo y transferencia se consideran CUP. No es beneficio neto porque no descuenta otros gastos no registrados.')}
 <div class="pcbm-grid pcbm-kpis">${kpi('Productos con margen calculable',String(rows.length),'Productos con coste y al menos un precio de venta válido.')}${kpi('Precios con margen positivo',String(positive),'Precio en CUP superior al coste unitario.')}${kpi('Precios con margen cero o negativo',String(zero+negative),'Revisa precios que no cubren el coste de adquisición.')}</div>
 ${chartGrid(barChart('Mayores márgenes brutos estimados',chartRows,{unit:'percent',description:'Porcentaje = (precio de venta en CUP − coste de adquisición en CUP) ÷ precio de venta en CUP.',emptyMessage:'Faltan precios o costes unitarios para calcular márgenes.'}),donutChart('Resultado por modalidad de venta',[{label:'Positivo',value:positive},{label:'Cero',value:zero},{label:'Negativo',value:negative}],{centerLabel:'Precios'}))}
 ${panel('Detalle por producto',rows.length?`<div class="pcbm-table-wrap"><table class="pcbm-table"><thead><tr><th>Producto</th><th>Coste unitario con Extra (CUP)</th><th>Precio efectivo (CUP)</th><th>Margen efectivo</th><th>Precio transferencia (CUP)</th><th>Margen transferencia</th></tr></thead><tbody>${rows.slice(0,250).map(p=>`<tr><td>${esc(p.name)}</td><td>${money(p.cost)}</td><td>${p.cashPrice>0?money(p.cashPrice):'—'}</td><td>${p.cashMargin===null?'—':`<b>${grouped(p.cashMargin,2)}%</b>`}</td><td>${p.transferPrice>0?money(p.transferPrice):'—'}</td><td>${p.transferMargin===null?'—':`<b>${grouped(p.transferMargin,2)}%</b>`}</td></tr>`).join('')}</tbody></table></div>`:'<p>No hay suficientes datos de coste o precios de efectivo/transferencia. El sistema no inventa precios ni añade gastos que no estén registrados.</p>')}
 <p class="pcbm-note">El coste usado es el campo de coste por unidad del inventario (coste promedio de adquisición); en las compras actuales ese valor incorpora la parte proporcional de Extra asignado. Si un producto todavía conserva un coste histórico sin actualizar, revisa su registro antes de tomar decisiones.</p>`;
}
function priceSimulatorView(){
 const products=getInventory();
 const options=products.map((product,index)=>({product,index,defaults:Core.priceSimulatorProductDefaults(product)}))
  .sort((a,b)=>a.defaults.name.localeCompare(b.defaults.name,'es',{sensitivity:'base'}));
 const productOptions=options.length
  ? options.map(row=>`<option value="${row.index}">${esc(row.defaults.name)} · ${esc(row.defaults.unit)}${row.defaults.productId?' · '+esc(row.defaults.productId.slice(0,18)):''}</option>`).join('')
  : '<option value="">No hay productos en el Almacén Central</option>';
 return `${viewIntro('SIMULAR PRECIOS','Simulador de precios y margen','Selecciona un producto del Almacén Central para cargar sus datos reales. Puedes cambiar el precio propuesto y la cantidad que deseas simular. Esta herramienta no modifica precios ni existencias.')}
 ${panel('Comparar un escenario',`<form id="pcbm-price-sim-form" class="pcbm-form">
 <label class="pcbm-field pcbm-wide"><span>Producto de prueba</span><select id="pcbm-price-product" ${options.length?'':'disabled'}><option value="">Selecciona un producto del inventario…</option>${productOptions}</select></label>
 <div id="pcbm-price-product-summary" class="pcbm-result pcbm-wide" aria-live="polite">Selecciona un producto para cargar automáticamente su precio actual, coste de adquisición, unidad y existencia. También puedes completar los campos manualmente.</div>
 ${field('Unidades que venderías','pcbm-price-qty','number','','min="0" step="any" required')}
 ${field('Precio actual por unidad (CUP)','pcbm-price-current','number','','min="0" step="0.01" required')}
 ${field('Precio propuesto por unidad (CUP)','pcbm-price-new','number','','min="0" step="0.01" placeholder="Introduce el nuevo precio" required')}
 ${field('Coste unitario conocido (CUP)','pcbm-price-cost','number','','min="0" step="0.01" required')}
 <button class="pcbm-btn pcbm-primary" type="submit">Comparar precios</button></form><div id="pcbm-price-sim-result" class="pcbm-result" aria-live="polite">Completa el escenario para ver ingresos, margen porcentual, margen en CUP y la diferencia entre ambos precios.</div><div id="pcbm-price-sim-chart" class="pcbm-chart-grid">${chartEmpty('Completa el escenario para generar las gráficas.')}</div>`)}
 <div class="pcbm-card"><h3>Qué significa cada cifra</h3><p><b>Margen %:</b> (precio − coste) ÷ precio. <b>Margen en CUP:</b> (precio − coste) × unidades. La diferencia en CUP indica cuánto más o menos dejaría la operación si se vendiera la misma cantidad.</p><p>Al seleccionar un producto, la cantidad se precarga con su existencia actual como referencia, pero puedes cambiarla por la cantidad que esperas vender. El precio actual y el coste unitario se leen del producto. La simulación no modifica inventario, compras ni precios guardados.</p><p>Si el producto no tiene precio actual o coste registrado, tendrás que introducir ese dato manualmente; ProControl no inventará valores.</p></div>`;
}
function stockSimulatorView(){return `${viewIntro('PLANIFICAR REPOSICIÓN','Simulador de cobertura de stock','Proyecta stock actual + pedido − consumo esperado durante el plazo. Informa por separado faltante y sobrante estimados, cobertura y saldo proyectado. No modifica el inventario real.')}
 ${panel('Definir escenario de reposición',`<form id="pcbm-stock-sim-form" class="pcbm-form">${field('Existencia actual','pcbm-stock-current','number','','min="0" step="any" required')}${field('Unidades que comprarías','pcbm-stock-order','number','','min="0" step="any" required')}${field('Demanda diaria estimada','pcbm-stock-demand','number','','min="0" step="any" required')}${field('Plazo de abastecimiento (días)','pcbm-stock-lead','number','','min="0" step="1" required')}<button class="pcbm-btn pcbm-primary" type="submit">Simular compra</button></form><div id="pcbm-stock-sim-result" class="pcbm-result" aria-live="polite">Las existencias reales no se modificarán. El resultado distinguirá faltante estimado y sobrante estimado.</div><div id="pcbm-stock-sim-chart" class="pcbm-chart-grid">${chartEmpty('Completa el escenario para generar la proyección.')}</div>`)}
 <div class="pcbm-card"><h3>Cómo interpretar la proyección</h3><p><b>Faltante estimado:</b> unidades que faltarían para cubrir la demanda proyectada antes de recibir el pedido. <b>Sobrante estimado:</b> unidades que quedarían después de descontar esa demanda. Si ambos son cero, el stock previsto y la demanda coinciden.</p><p>La simulación asume una demanda diaria uniforme; no contempla picos, estacionalidad, retrasos ni compras parciales.</p></div>`;}
function branchesView(){
 const sales=getSales(),closings=getClosingHistory(),pos=getPointsOfSale(),analysisSales=sales.concat(buildLegacyClosingSales(closings,sales));
 const selectedPoints=selectedBranchIds.map(key=>pos.find(point=>branchSelectionKey(point)===key)).filter(Boolean).slice(0,4);
 const available=pos.filter(point=>!selectedBranchIds.includes(branchSelectionKey(point)));
 const selector=`<div class="pcbm-branch-picker"><label class="pcbm-field" for="pcbm-branch-select">Añadir un punto de venta<select id="pcbm-branch-select" ${selectedBranchIds.length>=4||!available.length?'disabled':''}><option value="">Selecciona un punto de venta…</option>${available.map(point=>`<option value="${esc(branchSelectionKey(point))}">${esc(point.name||point.posName||'Punto de venta')}</option>`).join('')}</select></label><button type="button" class="pcbm-btn pcbm-primary" data-branch-add ${selectedBranchIds.length>=4||!available.length?'disabled':''}>＋ Añadir punto</button><span class="pcbm-branch-count">${selectedPoints.length} / 4 seleccionados</span></div>`;
 const intro=viewIntro('COMPARAR LO COMPARABLE','Comparación de puntos de venta','Añade entre uno y cuatro establecimientos. Cada punto tendrá su propia ficha con ventas, productos líderes, devoluciones e inventario local; los gráficos compararán únicamente los puntos que hayas seleccionado.');
 if(!selectedPoints.length){
  return `${intro}${panel('Selecciona los puntos que deseas comparar',`${selector}<div class="pcbm-branch-empty"><span aria-hidden="true">⌂</span><b>Aún no has añadido ningún punto de venta</b><p>Selecciona uno en la lista y pulsa «Añadir punto». Después podrás añadir otro, hasta un máximo de cuatro.</p>${pos.length?'':'<small>No hay puntos de venta configurados todavía. Crea primero uno en la sección Puntos de venta.</small>'}</div>`)}`;
 }
 const rows=summarizeSalesByPOS(sales,closings,pos),productRows=summarizeProductSalesByPOS(analysisSales,pos);
 const expanded=selectedPoints.map(point=>{
  const key=branchSelectionKey(point),name=cleanText(point.name||point.posName||'Punto de venta',120);
  const row=rows.find(item=>(item.posId&&key==='id:'+item.posId)||(!item.posId&&normalizeSupplierKey(item.name)===normalizeSupplierKey(name)))||{posId:point.id||point.posId||null,name,saleCount:0,returnCount:0,pendingCloseCount:0,netSalesCUP:null,estimatedClosingCount:0,hasSalesValue:false};
  const product=productRows.find(item=>(item.posId&&key==='id:'+item.posId)||(!item.posId&&normalizeSupplierKey(item.name)===normalizeSupplierKey(name)))||{topProducts:[],totalNetUnits:0,distinctProducts:0,averageTicketCUP:null,returnRate:null};
  const inventory=Array.isArray(point.inventory)?point.inventory:[];
  const lowStock=inventory.filter(item=>{const stock=Math.max(0,Number(item.qty??item.quantity??item.stock??0)||0),cfg=item.stockAlertSettings&&typeof item.stockAlertSettings==='object'?item.stockAlertSettings:{},min=Math.max(0,Number(cfg.manualMinimum??item.minimumStock??item.minStock??item.minQty??10)||0);return stock<=min;}).length;
  const stocked=inventory.filter(item=>Number(item.qty??item.quantity??item.stock??0)>0).length;
  return {...row,name,productStats:product,inventoryProducts:inventory.length,stockedProducts:stocked,lowStockProducts:lowStock,selectionKey:key};
 });
 const salesLeaders=expanded.filter(row=>row.netSalesCUP!==null).map(row=>({label:row.name,value:row.netSalesCUP}));
 const ticketLeaders=expanded.filter(row=>row.productStats.averageTicketCUP!=null).map(row=>({label:row.name,value:row.productStats.averageTicketCUP}));
 const returnLeaders=expanded.filter(row=>row.productStats.returnRate!=null).map(row=>({label:row.name,value:row.productStats.returnRate}));
 const productLeaders=expanded.map(row=>({label:row.name,value:row.productStats.distinctProducts||0}));
 const cards=expanded.map((row,index)=>{
  const top=(row.productStats.topProducts||[]).slice(0,5);
  const topHtml=top.length?`<ol>${top.map(item=>`<li><b>${esc(item.name)}</b><span class="pcbm-quantity">${money(item.units)} unidades base netas</span>${item.knownRevenue?`<small>${money(item.revenue)} CUP de ingreso de línea registrado</small>`:'<small>Ingreso por producto no comparable en esta operación</small>'}</li>`).join('')}</ol>`:'<p>No hay desglose de productos suficiente para construir un top 5. Los cierres IPV sin detalle no se convierten en cantidades inventadas.</p>';
  const opportunity=[];
  if(row.lowStockProducts>0)opportunity.push(`${row.lowStockProducts} productos están en el mínimo o por debajo; revisa la reposición local.`);
  if(row.productStats.returnRate!=null&&row.productStats.returnRate>=5)opportunity.push(`La tasa de devoluciones es ${grouped(row.productStats.returnRate,2)}%; revisa motivos y productos en Histórico.`);
  if(top.length)opportunity.push(`Prioriza visibilidad y disponibilidad de ${top.slice(0,3).map(item=>item.name).join(', ')}.`);
  if(!opportunity.length)opportunity.push('No hay señales operativas suficientes para proponer una acción específica.');
  return `<article class="pcbm-pos-compare-card"><header class="pcbm-pos-compare-head"><div><span class="pcbm-pos-index">PUNTO DE VENTA ${index+1}</span><h3>${esc(row.name)}</h3></div><button type="button" class="pcbm-btn pcbm-remove-pos" data-branch-remove="${esc(row.selectionKey)}" aria-label="Quitar ${esc(row.name)} de la comparación">Quitar ×</button></header><div class="pcbm-pos-metrics">${kpi('Venta neta comparable',row.netSalesCUP===null?'No disponible':money(row.netSalesCUP)+' CUP',row.estimatedClosingCount?`${row.estimatedClosingCount} cierre(s) IPV estimado(s) incluidos`:'Importe de ventas con datos comparables.')}${kpi('Ventas / devoluciones',`${row.saleCount} / ${row.returnCount}`,'Operaciones registradas por separado.')}${kpi('Promedio por ticket',row.productStats.averageTicketCUP==null?'No calculable':money(row.productStats.averageTicketCUP)+' CUP','Solo tickets con importes conocidos; no usa IPV como ticket.')}${kpi('Tasa de devolución',row.productStats.returnRate==null?'—':grouped(row.productStats.returnRate,2)+'%','Devoluciones respecto a ventas y devoluciones.')}</div><div class="pcbm-pos-detail-grid"><section class="pcbm-pos-detail"><h4>5 productos más vendidos</h4>${topHtml}<small>${row.productStats.totalNetUnits?`${money(row.productStats.totalNetUnits)} unidades base netas en las líneas detalladas.`:'Sin unidades detalladas disponibles.'}</small></section><section class="pcbm-pos-detail"><h4>Inventario local</h4><div class="pcbm-pos-inventory-stats"><div><b>${row.inventoryProducts}</b><span>productos en inventario</span></div><div><b>${row.stockedProducts}</b><span>con existencia positiva</span></div><div><b>${row.lowStockProducts}</b><span>en mínimo o por debajo</span></div><div><b>${row.pendingCloseCount||0}</b><span>ventas pendientes de cierre</span></div></div><small>No se suman unidades de medida distintas en un total común.</small></section><section class="pcbm-pos-detail pcbm-pos-opportunity"><h4>Cómo aprovechar este punto</h4><ul>${opportunity.map(item=>`<li>${esc(item)}</li>`).join('')}</ul></section></div><p class="pcbm-note">${row.estimatedClosingCount?`Incluye ${row.estimatedClosingCount} cierre(s) IPV estimado(s); sus totales no son tickets individuales.`:'Los importes mostrados dependen de las operaciones que tengan moneda y total comparables.'} No se declara rentabilidad sin costes y gastos atribuibles a este establecimiento.</p></article>`;
 }).join('');
 const charts=chartGrid(barChart('Ventas netas comparables por punto · CUP',salesLeaders,{unit:'money',suffix:'CUP',description:'Compara solo importes en CUP conocidos. Los cierres IPV estimados se identifican en la ficha.'}),barChart('Promedio por ticket registrado · CUP',ticketLeaders,{unit:'money',suffix:'CUP',description:'No incorpora cierres IPV estimados como tickets.'}),barChart('Porcentaje de devoluciones',returnLeaders,{unit:'percent',description:'Devoluciones / (ventas + devoluciones). Interpreta con cuidado si existen pocos registros.'}),barChart('Productos distintos vendidos',productLeaders,{unit:'count',description:'Variedad de productos presentes en líneas detalladas; no es una medida de rentabilidad.'}));
 return `${intro}${panel('Puntos seleccionados',`${selector}<div class="pcbm-pos-compare-grid">${cards}</div><p class="pcbm-note">Cada ficha reúne toda la información disponible de ese establecimiento. Puedes retirar un punto y añadir otro; el máximo simultáneo es cuatro.</p>`)}${panel('Comparación entre los puntos añadidos',charts||chartEmpty('No hay métricas comparables para los puntos seleccionados.'))}<p class="pcbm-note">Los cierres IPV antiguos pueden aportar totales estimados, pero no siempre desglosan unidades por producto. Cuando faltan datos, se muestra «No disponible» en lugar de inventar cifras.</p>`;
}
function renderView(){switch(activeTab){case'overview':return overview();case'receivables':return debtView('receivables');case'payables':return debtView('payables');case'suppliers':return suppliersView();case'rates':return ratesView();case'replenishment':return replenishmentView();case'abc':return abcView();case'movement':return movementView();case'margins':return marginsView();case'simPrice':return priceSimulatorView();case'simStock':return stockSimulatorView();case'branches':return branchesView();default:return overview();}}
function ensureUI(){if(doc.getElementById('pcbm-overlay'))return;const style=doc.createElement('style');style.textContent=`
#pcbm-overlay{position:fixed;inset:0;z-index:99999;background:rgba(4,8,15,.88);backdrop-filter:blur(7px);display:none;place-items:center;overflow:auto;padding:clamp(8px,2vw,24px);color:#edf1f7;font:14px/1.5 system-ui,Segoe UI,sans-serif}#pcbm-overlay.pcbm-open{display:grid}#pcbm-app{width:min(1520px,98vw);height:min(930px,94vh);min-height:min(620px,90vh);box-sizing:border-box;margin:auto;background:#101720;border:1px solid rgba(218,178,84,.55);border-radius:16px;box-shadow:0 25px 80px #000a;padding:clamp(14px,1.8vw,26px);display:flex;flex-direction:column;overflow:hidden}#pcbm-app h2,#pcbm-app h3,#pcbm-app h4{color:#e5c574;margin:0 0 10px}#pcbm-app h2{font-size:clamp(20px,2vw,28px)}#pcbm-app h3{font-size:17px}#pcbm-app h4{font-size:14px}#pcbm-app p,#pcbm-app small{color:#c3ccd8}#pcbm-head{display:flex;align-items:center;justify-content:space-between;gap:14px;border-bottom:1px solid #39414c;padding-bottom:12px;margin-bottom:10px;flex:0 0 auto}#pcbm-head-main{min-width:180px}#pcbm-head-controls{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap}#pcbm-title{margin-bottom:3px!important}#pcbm-subtitle{margin:0;font-size:12px}#pcbm-window-switch{max-width:270px;min-width:170px;background:#0e141c;color:#f2f4f8;border:1px solid #596677;border-radius:8px;padding:9px}.pcbm-btn{background:#202a36;color:#f1f4f8;border:1px solid #647184;border-radius:8px;padding:9px 12px;cursor:pointer;font-weight:650;display:inline-flex;align-items:center;justify-content:center;gap:7px}.pcbm-btn:hover{border-color:#e5c574}.pcbm-btn:focus-visible,#pcbm-app input:focus-visible,#pcbm-app select:focus-visible,#pcbm-app summary:focus-visible{outline:2px solid #f5df9a;outline-offset:2px}.pcbm-primary{background:linear-gradient(120deg,#8b6525,#e6c878);color:#171717;border-color:#f5df9a}.pcbm-card,.pcbm-chart-card{background:#171f29;border:1px solid #384351;border-radius:12px;padding:15px;margin:12px 0;min-width:0;box-sizing:border-box}.pcbm-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}.pcbm-kpi{padding:14px;background:#202a36;border:1px solid #4a5563;border-radius:11px;display:flex;flex-direction:column;gap:6px;min-width:0}.pcbm-kpi span{color:#e5c574;font-weight:700}.pcbm-kpi strong{font-size:clamp(19px,2vw,26px);overflow-wrap:anywhere}.pcbm-kpi small{font-size:11px}.pcbm-form{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;align-items:end}.pcbm-field{display:flex;flex-direction:column;gap:5px;color:#e6c879;font-weight:650}.pcbm-field input,.pcbm-field select{width:100%;min-width:0;box-sizing:border-box;border:1px solid #596677;background:#0e141c;color:#f2f4f8;padding:10px;border-radius:7px}.pcbm-wide{grid-column:1/-1}.pcbm-table-wrap{overflow:auto;max-width:100%;max-height:360px;border-radius:8px}.pcbm-table{width:100%;border-collapse:collapse;min-width:620px}.pcbm-table th,.pcbm-table td{text-align:left;padding:9px;border-bottom:1px solid #394351;vertical-align:top}.pcbm-table th{color:#e5c574;background:#202a36;position:sticky;top:0}.pcbm-table td small{display:block}.pcbm-list{padding-left:20px}.pcbm-list li{margin:7px 0}.pcbm-actions{display:flex;gap:9px;flex-wrap:wrap}.pcbm-note{font-size:12px!important;border-left:3px solid #b99042;padding-left:10px}.pcbm-result{padding:13px;margin-top:12px;border:1px dashed #b99042;border-radius:9px}.pcbm-status{margin-top:8px;color:#e5c574;min-height:1.5em;font-size:12px;flex:0 0 auto}#pcbm-content{flex:1 1 auto;min-height:0;overflow:auto;padding:0 5px 10px 0;scrollbar-color:#80652d #111923;scrollbar-width:thin}.pcbm-view-intro{margin:4px 0 15px}.pcbm-view-intro h3{font-size:clamp(21px,2vw,25px)!important;margin:0 0 5px!important}.pcbm-view-intro p:last-child{margin:0;max-width:1000px}.pcbm-eyebrow{font-size:10px!important;letter-spacing:.14em;color:#e5c574!important;font-weight:800;margin:0 0 5px}.pcbm-health-card{padding:17px;border:1px solid #4b5664;border-radius:13px;background:#171f29;margin:12px 0}.pcbm-health-top{display:flex;align-items:center;gap:12px}.pcbm-health-top h3{margin:0!important;font-size:20px!important}.pcbm-health-light{width:38px;height:38px;flex:0 0 38px;border-radius:50%;display:grid;place-items:center;font-size:21px;font-weight:900;border:2px solid currentColor}.pcbm-health-risk{border-color:#db6666;background:linear-gradient(120deg,#3b2025,#191f27)}.pcbm-health-risk .pcbm-health-light{color:#ff8585;background:#5c252b}.pcbm-health-attention{border-color:#c49d4d;background:linear-gradient(120deg,#352b1c,#191f27)}.pcbm-health-attention .pcbm-health-light{color:#f2c86e;background:#53401f}.pcbm-health-unknown{border-color:#667688}.pcbm-health-unknown .pcbm-health-light{color:#bac5d1;background:#293440}.pcbm-health-stable{border-color:#5c9875;background:linear-gradient(120deg,#1c332a,#191f27)}.pcbm-health-stable .pcbm-health-light{color:#8bddaa;background:#234b37}.pcbm-health-details{margin-top:10px;border-top:1px solid #3d4651;padding-top:9px}.pcbm-health-details summary{cursor:pointer;color:#e5c574;font-weight:750;padding:7px 2px}.pcbm-check-unknown{color:#c1ccd8}.pcbm-check-risk{color:#ff9999}.pcbm-check-attention{color:#f3ce7d}.pcbm-check-ok{color:#c8d4df}.pcbm-priority-list{list-style:none;padding:0;margin:0;display:grid;gap:10px}.pcbm-priority-item{display:flex;align-items:flex-start;gap:10px;padding:10px 11px;border-radius:9px;background:#202a36;border:1px solid #3b4755}.pcbm-priority-item>span{font-weight:900;font-size:16px;min-width:15px}.pcbm-priority-item b{display:block;color:#f0f3f7}.pcbm-priority-item small{display:block;margin-top:2px;line-height:1.45}.pcbm-priority-risk>span{color:#ff8585}.pcbm-priority-attention>span{color:#f2c86e}.pcbm-priority-unknown>span{color:#c1ccd8}.pcbm-chart-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr));gap:12px;align-items:stretch;margin:12px 0}.pcbm-chart-card{margin:0;min-height:235px;display:flex;flex-direction:column;gap:8px}.pcbm-chart-heading{display:flex;justify-content:space-between;align-items:center;gap:10px}.pcbm-chart-heading h3{margin:0!important}.pcbm-chart-desc{font-size:12px!important;margin:0;line-height:1.45}.pcbm-chart-badge{font-size:10px;border:1px solid #6d5b32;border-radius:999px;padding:3px 8px;color:#e5c574}.pcbm-bars{display:grid;gap:11px;margin-top:8px}.pcbm-bar-row{display:grid;grid-template-columns:minmax(90px,1fr) minmax(70px,1.8fr) max-content;align-items:center;gap:9px}.pcbm-bar-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#e4eaf1;font-size:14px}.pcbm-bar-track{height:13px;border-radius:999px;background:#0b1118;border:1px solid #3c4755;overflow:hidden}.pcbm-bar-fill{display:block;height:100%;border-radius:999px;background:var(--pcbm-bar-color);min-width:2px}.pcbm-bar-fill.is-negative{background:#e47e7e}.pcbm-bar-value{font-size:14px;white-space:nowrap;color:#f0d88e;font-variant-numeric:tabular-nums}.pcbm-donut-layout{display:grid;grid-template-columns:minmax(130px,.75fr) minmax(160px,1.25fr);gap:18px;align-items:center;flex:1}.pcbm-donut{aspect-ratio:1/1;width:min(100%,190px);min-width:110px;border-radius:50%;display:grid;place-items:center;justify-self:center;position:relative}.pcbm-donut-hole{width:62%;height:62%;border-radius:50%;background:#171f29;border:1px solid #4a5563;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden}.pcbm-donut-hole strong{font-size:clamp(16px,1.6vw,22px);color:#f3d88e;overflow-wrap:anywhere;max-width:90%;text-align:center}.pcbm-donut-hole small{font-size:12px;text-align:center}.pcbm-chart-legend{list-style:none;padding:0;margin:0;display:grid;gap:8px;min-width:0}.pcbm-chart-legend li{display:grid;grid-template-columns:10px minmax(0,1fr) max-content;align-items:center;gap:6px;font-size:11px}.pcbm-legend-dot{width:9px;height:9px;border-radius:50%}.pcbm-legend-label{overflow-wrap:anywhere;color:#e2e9f1}.pcbm-chart-legend strong{color:#f0d88e;font-variant-numeric:tabular-nums}.pcbm-chart-legend small{grid-column:2/4;text-align:right;font-size:12px}.pcbm-chart-empty{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;gap:8px;flex:1;min-height:130px;padding:10px 15px;border:1px dashed #3a4654;border-radius:10px;background:#111923}.pcbm-chart-empty span{font-size:28px;color:#d8b75e}.pcbm-chart-empty p{margin:0;font-size:12px;max-width:380px}.pcbm-currency-heading{margin:20px 0 8px!important;border-left:3px solid #d5ad4d;padding-left:10px}.pcbm-inline-action{margin-top:5px}.pcbm-inline-action .pcbm-btn{padding:5px 9px;font-size:11px}.pcbm-footnote{font-size:11px!important;color:#9daab8!important;margin-top:16px}.pcbm-business-menu{max-height:min(72vh,720px);overflow-y:auto;overscroll-behavior:contain}.pcbm-menu-heading{padding:8px 13px 4px;font-size:10px;font-weight:800;letter-spacing:.12em;color:#d6b55e;text-transform:uppercase;pointer-events:none}.pcbm-menu-divider{height:1px;background:rgba(212,184,112,.2);margin:5px 10px}@media(max-width:900px){#pcbm-head{align-items:flex-start;flex-direction:column}#pcbm-head-controls{justify-content:flex-start;width:100%}#pcbm-window-switch{max-width:100%;flex:1}}@media(max-width:650px){#pcbm-app{height:94vh;min-height:500px;width:98vw;border-radius:12px}#pcbm-head-controls{display:grid;grid-template-columns:1fr 1fr}#pcbm-window-switch{grid-column:1/-1;width:100%;box-sizing:border-box}.pcbm-form{grid-template-columns:1fr}.pcbm-wide{grid-column:auto}.pcbm-table{min-width:560px}.pcbm-donut-layout{grid-template-columns:1fr}.pcbm-donut{width:150px}.pcbm-bar-row{grid-template-columns:minmax(80px,1fr) minmax(60px,1.3fr) max-content}.pcbm-chart-grid{grid-template-columns:1fr}}

/* Accesibilidad: contraste uniforme para todas las vistas y controles del módulo económico. */
#pcbm-app,#pcbm-app *{color-scheme:dark}
#pcbm-app{color:#f2f6fb!important}
#pcbm-app label,#pcbm-app .pcbm-field,#pcbm-app legend{color:#f2d891!important}
#pcbm-app p,#pcbm-app small,#pcbm-app li,#pcbm-app dd,#pcbm-app dt,#pcbm-app .pcbm-note,#pcbm-app .pcbm-chart-desc,#pcbm-app .pcbm-status{color:#d5dfeb!important}
#pcbm-app input:not([type=checkbox]):not([type=radio]),#pcbm-app select,#pcbm-app textarea{background:#080e15!important;color:#fff!important;-webkit-text-fill-color:#fff!important;border:1px solid #91a0b3!important;caret-color:#ffe39b!important;opacity:1!important}
#pcbm-app input::placeholder,#pcbm-app textarea::placeholder{color:#bfcbd9!important;-webkit-text-fill-color:#bfcbd9!important;opacity:1!important}
#pcbm-app select option{background:#101923!important;color:#fff!important}
#pcbm-app input:disabled,#pcbm-app select:disabled,#pcbm-app textarea:disabled{background:#222c38!important;color:#cbd5e1!important;-webkit-text-fill-color:#cbd5e1!important;border-color:#536274!important;opacity:1!important}
#pcbm-app .pcbm-table td,#pcbm-app .pcbm-table td *{color:#f0f4fa!important}
#pcbm-app .pcbm-table th{color:#ffe29a!important}
#pcbm-app .pcbm-primary{color:#151515!important;-webkit-text-fill-color:#151515!important}
#pcbm-app button:disabled{color:#c5ced9!important;opacity:1!important}
#pcbm-app :focus-visible{outline:2px solid #ffe39b!important;outline-offset:2px}
\n.pcbm-chart-tools{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap}.pcbm-chart-mode-label{display:flex;align-items:center;gap:5px;font-size:10px!important;color:#d7c28b!important;font-weight:700;white-space:nowrap}.pcbm-chart-mode{background:#101923;color:#f6e4b1;border:1px solid #806a3f;border-radius:7px;padding:5px 7px;font-size:11px;max-width:115px}.pcbm-chart-visual{min-width:0;flex:1;display:flex;align-items:center}.pcbm-svg-chart{width:100%;min-width:0;overflow:hidden}.pcbm-svg-chart svg{display:block;width:100%;height:auto;min-height:200px}.pcbm-pos-insight{padding:12px 14px;margin:9px 0;background:#202a36;border:1px solid #445364;border-radius:10px}.pcbm-pos-insight h4{margin:0 0 7px;color:#f0d58b}.pcbm-pos-insight ol{margin:0;padding-left:22px}.pcbm-pos-insight li{padding:3px 0}.pcbm-abc-chip{display:inline-block;padding:4px 10px;border-radius:999px;border:1px solid currentColor}.pcbm-abc-a{color:#8bddaa!important;background:#1d3d2c}.pcbm-abc-b{color:#f2c86e!important;background:#463819}.pcbm-abc-c{color:#9fc9eb!important;background:#20374d}.pcbm-chart-card{min-height:310px}.pcbm-chart-heading h3{font-size:16px!important;line-height:1.35}.pcbm-table td small{margin-top:3px;line-height:1.4}\n.pcbm-svg-chart svg{min-height:230px}.pcbm-chart-legend li{font-size:13px}.pcbm-chart-legend strong{font-size:13px}.pcbm-chart-legend small{font-size:12px}.pcbm-donut-hole strong{font-size:clamp(20px,1.9vw,25px)}.pcbm-donut-hole small{font-size:12px}.pcbm-chart-mode-label{font-size:12px!important}.pcbm-chart-mode{font-size:12px;max-width:130px}
.pcbm-branch-picker{display:flex;align-items:end;gap:10px;flex-wrap:wrap;padding:12px;background:#202a36;border:1px solid #485665;border-radius:10px;margin:4px 0 14px}.pcbm-branch-picker .pcbm-field{flex:1 1 260px;max-width:520px}.pcbm-branch-picker .pcbm-field select{min-height:40px}.pcbm-branch-count{font-size:12px;color:#e5c574;font-weight:750;padding:10px 4px}.pcbm-branch-empty{display:flex;flex-direction:column;align-items:center;text-align:center;gap:7px;padding:28px 14px;border:1px dashed #586678;border-radius:10px;margin-top:10px;background:#111923}.pcbm-branch-empty>span{font-size:32px;color:#e5c574}.pcbm-branch-empty b{font-size:16px;color:#f0d88e}.pcbm-branch-empty p{margin:0;max-width:560px}.pcbm-pos-compare-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,460px),1fr));gap:14px;margin-top:14px;align-items:start}.pcbm-pos-compare-card{min-width:0;background:#151e28;border:1px solid #526071;border-top:3px solid #c6a253;border-radius:12px;padding:14px;box-sizing:border-box}.pcbm-pos-compare-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding-bottom:10px;margin-bottom:10px;border-bottom:1px solid #394655}.pcbm-pos-compare-head h3{font-size:18px!important;margin:2px 0 0!important}.pcbm-pos-index{font-size:10px;letter-spacing:.12em;font-weight:850;color:#e5c574}.pcbm-remove-pos{padding:5px 9px;font-size:11px;flex:0 0 auto}.pcbm-pos-metrics{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.pcbm-pos-metrics .pcbm-kpi{padding:10px}.pcbm-pos-metrics .pcbm-kpi strong{font-size:clamp(16px,1.5vw,21px)}.pcbm-pos-detail-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,190px),1fr));gap:10px;margin-top:10px}.pcbm-pos-detail{min-width:0;padding:11px;background:#202a36;border:1px solid #3d4a59;border-radius:9px}.pcbm-pos-detail h4{font-size:13px!important;margin:0 0 8px!important}.pcbm-pos-detail ol,.pcbm-pos-detail ul{margin:0;padding-left:19px}.pcbm-pos-detail li{padding:4px 0;overflow-wrap:anywhere}.pcbm-pos-detail li .pcbm-quantity{display:block;color:#79b6f2;font-weight:750;font-size:12px}.pcbm-pos-detail li small{display:block;font-size:11px}.pcbm-pos-inventory-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.pcbm-pos-inventory-stats div{display:flex;flex-direction:column;background:#151e28;border-radius:7px;padding:8px;gap:2px}.pcbm-pos-inventory-stats b{font-size:20px;color:#e5c574}.pcbm-pos-inventory-stats span{font-size:11px;color:#c3ccd8}.pcbm-pos-opportunity li{font-size:12px}
@media(max-width:650px){.pcbm-pos-metrics{grid-template-columns:1fr 1fr}.pcbm-pos-compare-grid{grid-template-columns:1fr}.pcbm-branch-picker .pcbm-btn{width:100%}}
`;doc.head.appendChild(style);
 const wrap=doc.createElement('div');wrap.id='pcbm-overlay';wrap.innerHTML=`<main id="pcbm-app" role="dialog" aria-modal="true" aria-labelledby="pcbm-title"><header id="pcbm-head"><div id="pcbm-head-main"><h2 id="pcbm-title">Gestión económica · Resumen y salud económica</h2><p id="pcbm-subtitle">Estado general y señales prioritarias.</p></div><div id="pcbm-head-controls"><select id="pcbm-window-switch" aria-label="Cambiar función de Gestión económica"></select><button type="button" class="pcbm-btn" id="pcbm-back">⌂ Resumen</button><button type="button" class="pcbm-btn" id="pcbm-close">Cerrar ×</button></div></header><div id="pcbm-content"></div><div id="pcbm-status" class="pcbm-status" role="status" aria-live="polite"></div></main>`;
 doc.body.appendChild(wrap);wrap.addEventListener('click',e=>{if(e.target===wrap)close();});doc.getElementById('pcbm-close').addEventListener('click',close);doc.getElementById('pcbm-back').addEventListener('click',()=>{activeTab='overview';render();});doc.getElementById('pcbm-window-switch').addEventListener('change',e=>{if(tabs.some(([key])=>key===e.target.value)){activeTab=e.target.value;render();}});doc.addEventListener('keydown',e=>{if(e.key==='Escape')close();});}

function render(){chartConfigs.clear();ensureUI();const meta=tabs.find(([key])=>key===activeTab)||tabs[0];const title=doc.getElementById('pcbm-title');const subtitle=doc.getElementById('pcbm-subtitle');if(title)title.textContent='Gestión económica · '+meta[1];if(subtitle)subtitle.textContent=meta[2];const select=doc.getElementById('pcbm-window-switch');if(select){const selected=activeTab;select.innerHTML='<option value="" disabled>Ir a otra función…</option>'+tabs.map(([key,label])=>`<option value="${key}" ${key===selected?'selected':''}>${esc(label)}</option>`).join('');select.value=selected;}const content=doc.getElementById('pcbm-content');content.innerHTML=renderView();content.scrollTop=0;doc.getElementById('pcbm-status').textContent='Datos guardados localmente en este equipo.';doc.getElementById('pcbm-content').querySelectorAll('[data-open-tab]').forEach(b=>b.addEventListener('click',()=>{const target=b.dataset.openTab;if(tabs.some(([key])=>key===target)){activeTab=target;render();}}));bindBranchControls(content);bindForms();}
function open(requestedTab='overview'){if(!canOwner()){notify('Solo el Dueño puede acceder a Análisis.');return false;}const allowedTabs=new Set(tabs.map(([key])=>key));activeTab=allowedTabs.has(requestedTab)?requestedTab:'overview';state=readState();lastSavedState=clone(state);ensureUI();const overlay=doc.getElementById('pcbm-overlay');if(!overlay)throw new Error('No se pudo crear la ventana de Gestión económica.');overlay.classList.add('pcbm-open');render();if(storageCorrupt)notify('ADVERTENCIA: los datos guardados no se pudieron leer. No se permitirá escribir encima; restaura un respaldo válido.');return true;}
function close(){const el=doc.getElementById('pcbm-overlay');if(el)el.classList.remove('pcbm-open');}
function handleNavbarMenuAction(event){const item=event.target&&event.target.closest?event.target.closest('[data-pcbm-tab]'):null;if(!item)return;const requestedTab=item.getAttribute('data-pcbm-tab');if(!tabs.some(([key])=>key===requestedTab))return;event.preventDefault();const dropdown=item.closest('.nav-dropdown');if(dropdown){dropdown.querySelectorAll('.nav-dropdown-content').forEach(menu=>menu.classList.add('hidden'));dropdown.classList.remove('open');const trigger=dropdown.querySelector(':scope > button[aria-haspopup="true"]');if(trigger)trigger.setAttribute('aria-expanded','false');}try{open(requestedTab);}catch(error){console.error('[ProControl Gestión económica] No se pudo abrir la sección:',error);alert('No se pudo abrir Gestión económica. '+(error&&error.message?error.message:'Revisa la consola para más información.'));}}
function installFallbackDropdown(nav){if(!nav||nav.querySelector('[data-pcbm-open]'))return;const wrap=doc.createElement('div');wrap.className='nav-dropdown pcbm-nav-dropdown';wrap.innerHTML='<button class="navbar-btn" type="button" data-pcbm-open="1" title="Gestión económica" aria-label="Abrir opciones de Gestión económica" aria-haspopup="true" aria-expanded="false"><span class="navbar-icon" aria-hidden="true">◈</span><span class="navbar-label">Gestión económica</span><span class="arrow-down" aria-hidden="true">▾</span></button><div class="nav-dropdown-content hidden pcbm-business-menu" role="menu" aria-label="Opciones de Gestión económica">'+menuMarkupFallback()+'</div>';
 const trigger=wrap.querySelector('[data-pcbm-open]');trigger.addEventListener('click',()=>{const menu=wrap.querySelector('.nav-dropdown-content');const opening=menu.classList.contains('hidden');doc.querySelectorAll('.nav-dropdown-content').forEach(other=>other.classList.add('hidden'));doc.querySelectorAll('.nav-dropdown').forEach(other=>{other.classList.remove('open');const b=other.querySelector(':scope > button[aria-haspopup="true"]');if(b)b.setAttribute('aria-expanded','false');});menu.classList.toggle('hidden',!opening);wrap.classList.toggle('open',opening);trigger.setAttribute('aria-expanded',String(opening));});
 const managementMenu=nav.querySelector('#menu-gestion');const managementDropdown=managementMenu&&managementMenu.closest('.nav-dropdown');if(managementDropdown&&managementDropdown.parentElement===nav)managementDropdown.insertAdjacentElement('afterend',wrap);else{const home=nav.querySelector('[data-page="page-dashboard"]');if(home)home.insertAdjacentElement('afterend',wrap);else nav.appendChild(wrap);}}
function menuMarkupFallback(){const groups=[['GENERAL',[['overview','Resumen y salud económica','◉'],['receivables','Cuentas por cobrar','↙'],['payables','Cuentas por pagar','↗']]],['ABASTECIMIENTO',[['suppliers','Proveedores','♙'],['replenishment','Compras inteligentes','▤']]],['ANÁLISIS',[['rates','Monedas y tasas','¤'],['abc','Inventario ABC','▥'],['movement','Mercancía inmovilizada','◷'],['margins','Márgenes estimados','％'],['simPrice','Simulador de precios','％'],['simStock','Simulador de reposición','▣'],['branches','Comparar puntos de venta','⌂']]]];return groups.map((g,gi)=>`<div class="pcbm-menu-heading">${g[0]}</div>${g[1].map(([key,label,icon])=>`<button class="dropdown-item pcbm-menu-action" type="button" role="menuitem" data-pcbm-tab="${key}"><span class="dropdown-icon" aria-hidden="true">${icon}</span><span>${label}</span></button>`).join('')}${gi<groups.length-1?'<div class="pcbm-menu-divider"></div>':''}`).join('');}
function bindForms(){
 const debt=doc.getElementById('pcbm-debt-form');if(debt)debt.onsubmit=e=>{e.preventDefault();if(!requireWrite())return;const amount=Number(doc.getElementById('pcbm-debt-amount').value);if(!positive(amount)){notify('El importe debe ser mayor que cero.');return;}const type=activeTab==='receivables'||activeTab==='payables'?activeTab:'receivables',entry={id:id('debt'),name:cleanText(doc.getElementById('pcbm-debt-name').value,180)||'Sin nombre',description:cleanText(doc.getElementById('pcbm-debt-desc').value,250),amount,paid:0,currency:doc.getElementById('pcbm-debt-currency').value,dueDate:doc.getElementById('pcbm-debt-due').value,createdAt:new Date().toISOString()};state[type].push(entry);if(persist(type==='receivables'?'Cuenta por cobrar creada':'Cuenta por pagar creada',entry.name+' · '+amount+' '+entry.currency)){render();notify('Cuenta guardada.');}};
 const supplier=doc.getElementById('pcbm-supplier-form');if(supplier){const select=doc.getElementById('pcbm-supplier-key');const loadSupplierMeta=()=>{const key=select&&select.value;const existing=state.suppliers.find(s=>normalizeSupplierKey(s.name)===key);const contact=doc.getElementById('pcbm-supplier-contact'),lead=doc.getElementById('pcbm-supplier-lead'),notes=doc.getElementById('pcbm-supplier-notes');if(contact)contact.value=existing?.contact||'';if(lead)lead.value=existing&&Number(existing.leadDays)>0?String(existing.leadDays):'';if(notes)notes.value=existing?.notes||'';};if(select)select.addEventListener('change',loadSupplierMeta);supplier.onsubmit=e=>{e.preventDefault();if(!requireWrite())return;const key=select&&select.value;const actual=summarizeSupplierPurchases(getPurchases(),state.suppliers).find(s=>s.key===key);if(!actual){notify('Selecciona un proveedor que aparezca en el directorio. Para agregar uno nuevo, regístralo en Compras → Nueva compra.');return;}const values={contact:cleanText(doc.getElementById('pcbm-supplier-contact').value,180),leadDays:Math.max(0,Math.min(3650,Number(doc.getElementById('pcbm-supplier-lead').value)||0)),notes:cleanText(doc.getElementById('pcbm-supplier-notes').value,500)};let existing=state.suppliers.find(s=>normalizeSupplierKey(s.name)===key);if(!existing){existing={id:id('supplier-meta'),name:actual.name,contact:'',leadDays:0,notes:''};state.suppliers.push(existing);}Object.assign(existing,values,{name:actual.name});if(persist('Datos logísticos de proveedor actualizados',actual.name)){render();notify('Datos logísticos guardados. Nombre, teléfono e historial siguen vinculados a las compras reales.');}};}
 const rateCurrency=doc.getElementById('pcbm-rate-currency');const rateCustomWrap=doc.getElementById('pcbm-rate-custom-wrap');const rateCustom=doc.getElementById('pcbm-rate-custom');const rateForm=doc.getElementById('pcbm-rate-form');const rateValue=doc.getElementById('pcbm-rate-value');const rateSource=doc.getElementById('pcbm-rate-source');const rateCancel=doc.getElementById('pcbm-rate-cancel');const syncRateCustomField=()=>{if(rateCustomWrap)rateCustomWrap.style.display=rateCurrency&&rateCurrency.value==='OTRA'?'flex':'none';};if(rateCurrency)rateCurrency.onchange=syncRateCustomField;syncRateCustomField();
 const resetRateEditor=()=>{if(!rateForm)return;rateForm.reset();if(rateCurrency)rateCurrency.value='USD';if(rateValue)rateValue.value='';if(rateCustom)rateCustom.value='';if(rateSource)rateSource.value='';if(rateCancel)rateCancel.hidden=true;syncRateCustomField();};
 doc.querySelectorAll('[data-edit-rate]').forEach(button=>button.addEventListener('click',()=>{if(!rateForm)return;const currency=String(button.dataset.editRate||'USD').toUpperCase();if(rateCurrency)rateCurrency.value=['USD','EUR','MLC','OTRA'].includes(currency)?currency:'OTRA';if(rateCustom)rateCustom.value=currency==='OTRA'?String(button.dataset.editRateCustom||''):'';if(rateValue)rateValue.value=String(button.dataset.editRateValue||'');if(rateSource)rateSource.value='Actualizada manualmente';if(rateCancel)rateCancel.hidden=false;syncRateCustomField();rateForm.scrollIntoView({block:'nearest'});if(rateValue)rateValue.focus();}));
 if(rateCancel)rateCancel.onclick=resetRateEditor;
 if(rateForm)rateForm.onsubmit=e=>{e.preventDefault();if(!requireWrite())return;const currency=String(rateCurrency&&rateCurrency.value||'USD').toUpperCase(),value=Number(rateValue&&rateValue.value),today=new Date().toISOString().slice(0,10),customCurrency=currency==='OTRA'?cleanCurrencyLabel(rateCustom&&rateCustom.value):'',source=cleanText(rateSource&&rateSource.value||'Introducida por el usuario',180);if(!Number.isFinite(value)||value<=0){notify('El valor de la moneda en CUP debe ser mayor que cero.');return;}if(currency==='OTRA'&&!customCurrency){notify('Escribe el nombre o código de la otra moneda.');if(rateCustom)rateCustom.focus();return;}if(currency==='OTRA'&&['CUP','USD','EUR','MLC','OTRA'].includes(customCurrency.toUpperCase())){notify('Ese nombre corresponde a una moneda ya disponible. Escribe otra moneda distinta.');if(rateCustom)rateCustom.focus();return;}const normalize=value=>cleanCurrencyLabel(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase();const sameCurrency=record=>record&&String(record.currency||'').toUpperCase()===currency&&(currency!=='OTRA'||normalize(rateCurrencyLabel(record))===normalize(customCurrency));const todays=state.rates.map((record,index)=>({record,index})).filter(row=>sameCurrency(row.record)&&String(row.record.date||'')===today).sort((a,b)=>b.index-a.index);if(todays.length){const existing=todays[0].record;existing.rate=value;existing.source=source;if(currency==='OTRA')existing.customCurrency=customCurrency;}else{state.rates.push({id:id('rate'),currency,customCurrency:currency==='OTRA'?customCurrency:'',rate:value,date:today,source});}if(persist('Tasa actualizada',(currency==='OTRA'?customCurrency:currency)+' · '+value+' CUP por unidad')){render();notify('La tasa actual quedó guardada. El historial de operaciones anteriores se conserva.');}};
 const priceProduct=doc.getElementById('pcbm-price-product');if(priceProduct)priceProduct.onchange=()=>{const summary=doc.getElementById('pcbm-price-product-summary'),result=doc.getElementById('pcbm-price-sim-result'),chart=doc.getElementById('pcbm-price-sim-chart');const rawIndex=priceProduct.value;if(rawIndex===''){if(summary)summary.textContent='Selecciona un producto para cargar sus datos. También puedes completar los campos manualmente.';return;}const index=Number(rawIndex),products=getInventory(),product=Number.isInteger(index)&&index>=0?products[index]:null;if(!product){notify('No se pudo localizar el producto seleccionado. Actualiza la vista e inténtalo de nuevo.');return;}const defaults=Core.priceSimulatorProductDefaults(product),qty=doc.getElementById('pcbm-price-qty'),current=doc.getElementById('pcbm-price-current'),proposed=doc.getElementById('pcbm-price-new'),cost=doc.getElementById('pcbm-price-cost');if(qty)qty.value=defaults.stock===null?'':String(defaults.stock);if(current)current.value=defaults.currentPrice===null?'':String(defaults.currentPrice);if(proposed)proposed.value='';if(cost)cost.value=defaults.unitCost===null?'':String(defaults.unitCost);if(summary){const stockText=defaults.stock===null?'existencia no disponible':`${money(defaults.stock)} ${defaults.unit} disponibles (referencia inicial para la cantidad)`;const currentText=defaults.currentPrice===null?'precio de venta no registrado':`${money(defaults.currentPrice)} CUP por ${defaults.unit}`;const costText=defaults.unitCost===null?'coste de adquisición no registrado':`${money(defaults.unitCost)} CUP por ${defaults.unit}`;summary.innerHTML=`<b>${esc(defaults.name)}</b><br>Unidad base: ${esc(defaults.unit)} · Existencia: ${esc(stockText)}<br>Precio actual: ${esc(currentText)}<br>Coste unitario: ${esc(costText)}<br><small>El precio propuesto queda vacío para que introduzcas el nuevo importe. Todos los campos pueden editarse para la simulación.</small>`;}if(result)result.textContent='Producto cargado. Introduce el precio propuesto y pulsa «Comparar precios».';if(chart)chart.innerHTML=chartEmpty('Completa el escenario para generar las gráficas.');};
 const priceSim=doc.getElementById('pcbm-price-sim-form');if(priceSim)priceSim.onsubmit=e=>{e.preventDefault();const priceFields=['pcbm-price-qty','pcbm-price-current','pcbm-price-new','pcbm-price-cost'].map(id=>doc.getElementById(id).value);if(priceFields.some(v=>!String(v).trim())){notify('Completa las unidades, el precio actual, el nuevo precio y el costo unitario conocido.');return;}try{const r=Core.simulatePrice(...priceFields);doc.getElementById('pcbm-price-sim-result').innerHTML=`<div class="pcbm-grid pcbm-kpis">${kpi('Margen actual',r.currentMargin===null?'N/D':grouped(r.currentMargin,2)+'%',`Margen en dinero: ${money(r.currentGrossProfit)} CUP`)}${kpi('Margen propuesto',r.newMargin===null?'N/D':grouped(r.newMargin,2)+'%',`Margen en dinero: ${money(r.newGrossProfit)} CUP`)}${kpi('Cambio de ganancia',`${r.grossProfitDelta>=0?'+':''}${money(r.grossProfitDelta)} CUP`,'Diferencia en dinero manteniendo la misma cantidad vendida.')}${kpi('Cambio de margen',r.marginDelta===null?'N/D':`${r.marginDelta>=0?'+':''}${grouped(r.marginDelta,2)} puntos porcentuales`,'Diferencia entre los porcentajes de margen.')}</div><p>Ingresos: ${money(r.currentRevenue)} → ${money(r.newRevenue)} CUP. ${r.assumption}</p>`;const chart=doc.getElementById('pcbm-price-sim-chart');if(chart)chart.innerHTML=chartGrid(barChart('Ingresos y ganancia bruta · CUP',[{label:'Ingreso actual',value:r.currentRevenue},{label:'Ingreso propuesto',value:r.newRevenue},{label:'Ganancia actual',value:r.currentGrossProfit},{label:'Ganancia propuesta',value:r.newGrossProfit}],{unit:'money',suffix:'CUP',description:'Se mantiene la cantidad de unidades introducida.'}),barChart('Margen porcentual',[{label:'Margen actual',value:r.currentMargin??0},{label:'Margen propuesto',value:r.newMargin??0}],{unit:'percent',description:'Porcentaje de la venta que queda tras descontar el coste unitario conocido.'}),barChart('Diferencia monetaria del margen',[{label:'Cambio de ganancia',value:r.grossProfitDelta}],{unit:'money',suffix:'CUP',description:'Importe adicional o menor que deja la operación en el escenario propuesto.'}));}catch(err){notify(err.message);}};
 const stockSim=doc.getElementById('pcbm-stock-sim-form');if(stockSim)stockSim.onsubmit=e=>{e.preventDefault();const stockFields=['pcbm-stock-current','pcbm-stock-order','pcbm-stock-demand','pcbm-stock-lead'].map(id=>doc.getElementById(id).value);if(stockFields.some(v=>!String(v).trim())){notify('Completa existencias, cantidad a comprar, demanda diaria y plazo de abastecimiento.');return;}try{const r=Core.simulateStock(...stockFields);doc.getElementById('pcbm-stock-sim-result').innerHTML=`<div class="pcbm-grid pcbm-kpis">${kpi('Stock tras recibir compra',money(r.stockAfterPurchase),'Existencia actual más la cantidad que comprarías.')}${kpi('Demanda durante el plazo',money(r.estimatedDemandDuringLead),'Unidades que se consumirían antes de llegar el pedido.')}${kpi('Faltante estimado',money(r.shortageAtLead),'Unidades que no alcanzarían para cubrir la demanda.')}${kpi('Sobrante estimado',money(r.surplusAtLead),'Stock que quedaría después de cubrir la demanda del plazo.')}${kpi('Cobertura tras compra',r.coverageDays===null?'No calculable':grouped(r.coverageDays,2)+' días','Cobertura teórica si se mantiene la demanda diaria.')}</div><p>Saldo proyectado al llegar el pedido: ${money(r.projectedBalanceAtLead)} unidades. La compra simulada no modifica el inventario real.</p>`;const chart=doc.getElementById('pcbm-stock-sim-chart');if(chart)chart.innerHTML=chartGrid(barChart('Stock, demanda y saldo proyectado',[{label:'Existencia actual',value:Number(stockFields[0])},{label:'Stock tras compra',value:r.stockAfterPurchase},{label:'Demanda al llegar',value:r.estimatedDemandDuringLead},{label:'Saldo sobrante',value:r.surplusAtLead}],{unit:'count',description:'Compara stock disponible y consumo proyectado.'}),barChart('Faltante frente a sobrante estimado',[{label:'Faltante',value:r.shortageAtLead},{label:'Sobrante',value:r.surplusAtLead}],{unit:'count',description:'Solo una de estas magnitudes será mayor que cero para un mismo escenario.'}));}catch(err){notify(err.message);}};
 doc.querySelectorAll('[data-settle]').forEach(b=>b.onclick=()=>{if(!requireWrite())return;const type=b.dataset.type,d=state[type].find(x=>x.id===b.dataset.settle);if(!d)return;const remaining=Number(d.amount)-Number(d.paid||0);const raw=prompt('Importe a '+(type==='receivables'?'cobrar':'pagar')+' (saldo pendiente '+money(remaining)+' '+d.currency+')');if(raw===null)return;const amount=Number(raw);if(!positive(amount)||amount>remaining){notify('El importe debe ser positivo y no superar el saldo pendiente.');return;}d.paid=Number(d.paid||0)+amount;if(persist(type==='receivables'?'Seguimiento de cobro actualizado':'Seguimiento de pago actualizado',d.name+' · '+amount+' '+d.currency)){render();notify('Seguimiento actualizado en ProControl. El movimiento bancario real se gestiona en tu aplicación bancaria; aquí solo se actualiza el saldo pendiente.');}});

}
function installNavButton(){
 const navs=doc.querySelectorAll('nav.top-navbar .nav-right');
 navs.forEach(nav=>installFallbackDropdown(nav));
}
function init(){
 doc.addEventListener('change',event=>{const selector=event.target&&event.target.closest?event.target.closest('[data-chart-mode]'):null;if(!selector)return;const idKey=selector.getAttribute('data-chart-mode'),config=chartConfigs.get(idKey);if(!config)return;const mode=['bar','line','pie','area'].includes(selector.value)?selector.value:'bar';chartModes.set(idKey,mode);const card=selector.closest('.pcbm-chart-card'),visual=card&&card.querySelector('.pcbm-chart-visual');if(visual)visual.innerHTML=chartVisual(config.rows,mode,config.options);});
 installNavButton();
 doc.addEventListener('click',handleNavbarMenuAction);
 const observer=new MutationObserver(()=>installNavButton());
 doc.querySelectorAll('nav.top-navbar').forEach(n=>observer.observe(n,{childList:true,subtree:true}));
}
root.PCBusinessManagement={open,close,core:Core,version:5,getAvailableViews:()=>tabs.map(([key,label,description])=>({key,label,description})),getCurrentView:()=>activeTab,getDashboardRates:()=>{const fresh=readState();return latestCurrencyRates(fresh.rates,getCurrentDateISO(),getMainDollarRate()).map(({currency,label,rate,date,source})=>({currency,label,rate,date,source}));}};
if(doc.readyState==='loading')doc.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(typeof window!=='undefined'?window:globalThis);
