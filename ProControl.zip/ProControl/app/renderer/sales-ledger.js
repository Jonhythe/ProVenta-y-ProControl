'use strict';

/*
 * ProControl — registro transaccional de ventas.
 * Módulo puro: no accede al DOM ni modifica inventarios. La UI debe aplicar
 * línea, stock, historial y auditoría dentro de una misma transacción.
 */
(function exposeSalesLedger(root) {
  const round = (value, decimals = 2) => {
    const factor = 10 ** decimals;
    return Math.round((Number(value) + Number.EPSILON) * factor) / factor;
  };

  const normalizeName = value => String(value || '').trim().toLocaleLowerCase();
  const isIndividualUnit = unit => ['u', 'unidad', 'unidades'].includes(String(unit || '').trim().toLowerCase());
  const isDiscreteBaseUnit = unit => ['u', 'unidad', 'unidades', 'pqt', 'paquete', 'paquetes', 'caja', 'cajas', 'box', 'boxes'].includes(String(unit || '').trim().toLowerCase());

  function makeLine(input) {
    const item = input && typeof input === 'object' ? input : {};
    const productId = String(item.productId || '').trim();
    const name = String(item.name || '').trim();
    const baseUnit = String(item.baseUnit || '').trim();
    const presentation = String(item.presentation || 'unit').trim().toLowerCase();
    const quantity = Number(item.quantity);
    const unitPrice = Number(item.unitPrice);
    const currency = String(item.currency || 'CUP').trim().toUpperCase();
    const exchangeRate = Number(item.exchangeRate || 0);
    const unitsPerBox = item.unitsPerBox == null || item.unitsPerBox === '' ? null : Number(item.unitsPerBox);

    if (!productId || !name || !baseUnit) throw new Error('La venta necesita un ID estable, nombre y unidad base de producto.');
    if (!Number.isFinite(quantity) || quantity <= 0) throw new Error('La cantidad vendida debe ser mayor que cero.');
    if (!Number.isFinite(unitPrice) || unitPrice < 0) throw new Error('El precio de venta no es válido.');
    if (!['CUP', 'USD'].includes(currency)) throw new Error('La moneda de la venta no es válida.');
    if (currency === 'USD' && (!Number.isFinite(exchangeRate) || exchangeRate <= 0)) throw new Error('Configure una tasa de cambio positiva antes de registrar ventas en USD.');

    let baseQty = quantity;
    let normalizedFactor = null;
    let presentationLabel = baseUnit;
    let factorAtSale = item.unitsPerBoxAtSale == null || item.unitsPerBoxAtSale === '' ? null : Number(item.unitsPerBoxAtSale);
    if (presentation === 'box') {
      if (!isIndividualUnit(baseUnit)) throw new Error('Solo se pueden vender cajas cuando la unidad base del producto es Unidad.');
      if (!Number.isSafeInteger(quantity)) throw new Error('La cantidad de cajas debe ser un número entero.');
      if (!Number.isSafeInteger(unitsPerBox) || unitsPerBox <= 0) throw new Error('Configure un número entero positivo de unidades por caja.');
      baseQty = quantity * unitsPerBox;
      if (!Number.isSafeInteger(baseQty)) throw new Error('La conversión de cajas supera el límite numérico seguro.');
      normalizedFactor = unitsPerBox;
      presentationLabel = `caja${quantity === 1 ? '' : 's'}`;
      if (factorAtSale !== null && factorAtSale !== unitsPerBox) throw new Error('La equivalencia guardada de la caja no coincide con la presentación vendida.');
      factorAtSale = unitsPerBox;
    } else if (presentation === 'unit') {
      if (isDiscreteBaseUnit(baseUnit) && !Number.isSafeInteger(quantity)) throw new Error(`La unidad ${baseUnit} requiere cantidades enteras.`);
    } else {
      throw new Error('La presentación de venta no es compatible.');
    }

    if (factorAtSale !== null) {
      if (!Number.isSafeInteger(factorAtSale) || factorAtSale <= 0) throw new Error('La equivalencia histórica de caja no es válida.');
    }
    const lineTotal = round(quantity * unitPrice, 2);
    const lineTotalCUP = currency === 'USD' ? round(lineTotal * exchangeRate, 2) : lineTotal;
    return {
      productId,
      name,
      baseUnit,
      presentation,
      presentationQty: quantity,
      presentationLabel,
      unitsPerBox: normalizedFactor,
      unitsPerBoxAtSale: factorAtSale,
      baseQty,
      unitPrice: round(unitPrice, 4),
      currency,
      lineTotal,
      exchangeRate: currency === 'USD' ? round(exchangeRate, 6) : null,
      lineTotalCUP
    };
  }

  function buildTransaction(input) {
    const data = input && typeof input === 'object' ? input : {};
    const id = String(data.id || '').trim();
    const posId = String(data.posId || '').trim();
    const posName = String(data.posName || '').trim();
    const user = String(data.user || '').trim();
    const paymentMethod = String(data.paymentMethod || '').trim().toLowerCase();
    const currency = paymentMethod === 'usd' ? 'USD' : 'CUP';
    if (!id || !posId || !posName || !user) throw new Error('La venta no tiene una identidad completa de ticket, POS o usuario.');
    if (!['cash', 'transfer', 'usd'].includes(paymentMethod)) throw new Error('Seleccione efectivo, transferencia o USD como método de pago.');

    const rawLines = Array.isArray(data.lines) ? data.lines : (data.line && typeof data.line === 'object' ? [data.line] : []);
    if (!rawLines.length) throw new Error('Añada al menos un producto al ticket.');
    if (rawLines.length > 100) throw new Error('Un ticket no puede contener más de 100 líneas.');
    const lines = rawLines.map(supplied => {
      const source = supplied && typeof supplied === 'object' ? supplied : {};
      return makeLine({
        ...source,
        quantity: source.quantity ?? source.presentationQty,
        currency,
        exchangeRate: source.exchangeRate ?? data.exchangeRate,
        unitsPerBox: source.unitsPerBox
      });
    });
    const now = data.ts ? new Date(data.ts) : new Date();
    if (!Number.isFinite(now.getTime())) throw new Error('La fecha del ticket no es válida.');
    const totalNative = round(lines.reduce((sum, line) => sum + line.lineTotal, 0), 2);
    const totalCUP = round(lines.reduce((sum, line) => sum + line.lineTotalCUP, 0), 2);
    return {
      id,
      idempotencyKey: id,
      schemaVersion: 1,
      kind: 'sale',
      source: String(data.source || 'desktop'),
      ts: now.toISOString(),
      posId,
      posName,
      user,
      paymentMethod,
      currency,
      exchangeRate: currency === 'USD' ? round(Number(data.exchangeRate), 6) : null,
      note: String(data.note || '').trim().slice(0, 500),
      items: lines,
      totalNative,
      totalCUP,
      status: 'pending-close',
      closingId: null,
      reconciledAt: null
    };
  }

  // Una devolución completa se registra como un evento nuevo y negativo.
  // El ticket original permanece intacto y sirve como evidencia histórica.
  function buildReturnTransaction(input) {
    const data = input && typeof input === 'object' ? input : {};
    const original = data.originalSale;
    if (!original || !validateTransaction(original) || original.kind === 'return') {
      throw new Error('El ticket original no es válido para una devolución.');
    }
    if (!data.id || !data.user) throw new Error('La devolución necesita un identificador y un usuario.');
    const lines = original.items.map(line => ({
      ...line,
      presentationQty: -Math.abs(Number(line.presentationQty)),
      presentationLabel: `devolución de ${line.presentationLabel || line.baseUnit}`,
      baseQty: -Math.abs(Number(line.baseQty)),
      lineTotal: -Math.abs(Number(line.lineTotal)),
      lineTotalCUP: -Math.abs(Number(line.lineTotalCUP))
    }));
    const now = data.ts ? new Date(data.ts) : new Date();
    if (!Number.isFinite(now.getTime())) throw new Error('La fecha de devolución no es válida.');
    return {
      id: String(data.id),
      idempotencyKey: String(data.id),
      schemaVersion: 1,
      kind: 'return',
      returnOf: String(original.id),
      source: 'desktop',
      ts: now.toISOString(),
      posId: original.posId,
      posName: original.posName,
      user: String(data.user).trim(),
      paymentMethod: `return:${original.paymentMethod || original.currency}`,
      currency: original.currency || 'CUP',
      exchangeRate: original.exchangeRate == null ? null : original.exchangeRate,
      note: String(data.note || `Devolución completa del ticket ${original.id}`).trim().slice(0, 500),
      items: lines,
      totalNative: -Math.abs(Number(original.totalNative) || 0),
      totalCUP: -Math.abs(Number(original.totalCUP) || 0),
      status: 'pending-close',
      closingId: null,
      reconciledAt: null
    };
  }

  function canReturnSale(records, sale) {
    if (!sale || !sale.id || sale.kind === 'return' || !validateTransaction(sale)) return false;
    const list = Array.isArray(records) ? records : [];
    return !list.some(record => record && record.kind === 'return' && String(record.returnOf) === String(sale.id));
  }

  function validateAvailableStock(currentQty, baseQty) {
    const stock = Number(currentQty);
    const need = Number(baseQty);
    if (!Number.isFinite(stock) || stock < 0) throw new Error('El stock del producto no es válido.');
    if (!Number.isFinite(need) || need <= 0) throw new Error('La cantidad base de la venta no es válida.');
    if (need > stock + 1e-9) throw new Error(`Stock insuficiente: hay ${stock} en inventario y la venta requiere ${need}.`);
    return round(stock - need, 4);
  }

  function pendingForPOS(records, posId) {
    const ref = String(posId || '');
    if (!Array.isArray(records) || !ref) return [];
    return records.filter(record => record && record.posId === ref && !record.closingId && record.status === 'pending-close');
  }

  function summarizeProduct(records, posId, productId, name) {
    const id = String(productId || '').trim();
    const key = normalizeName(name);
    const lines = [];
    for (const transaction of pendingForPOS(records, posId)) {
      for (const line of (Array.isArray(transaction.items) ? transaction.items : [])) {
        const matchesId = id && String(line.productId || '').trim() === id;
        const matchesLegacyName = !id && normalizeName(line.name) === key;
        if (matchesId || matchesLegacyName) lines.push({ transaction, line });
      }
    }
    let baseQty = 0;
    let revenueCUP = 0;
    let boxes = 0;
    let units = 0;
    let otherPresentationQty = 0;
    let returnedBoxes = 0;
    let returnedUnits = 0;
    let returnedOther = 0;
    for (const { transaction, line } of lines) {
      const qty = Math.abs(Number(line.presentationQty) || 0);
      const isReturn = transaction.kind === 'return';
      const sign = isReturn ? -1 : 1;
      baseQty += Number(line.baseQty) || 0;
      revenueCUP += Number(line.lineTotalCUP) || 0;
      if (line.presentation === 'box') {
        boxes += sign * qty;
        if (isReturn) returnedBoxes += qty;
      } else if (isIndividualUnit(line.baseUnit)) {
        units += sign * qty;
        if (isReturn) returnedUnits += qty;
      } else {
        otherPresentationQty += sign * qty;
        if (isReturn) returnedOther += qty;
      }
    }
    const parts = [];
    if (boxes > 1e-9) parts.push(`${round(boxes, 4)} caja${boxes === 1 ? '' : 's'} neta(s)`);
    if (units > 1e-9) parts.push(`${round(units, 4)} u netas`);
    if (otherPresentationQty > 1e-9) parts.push(`${round(otherPresentationQty, 4)} ${lines.find(x => !isIndividualUnit(x.line.baseUnit))?.line.baseUnit || ''} netos`.trim());
    const returns = [];
    if (returnedBoxes > 0) returns.push(`${round(returnedBoxes,4)} caja(s) devuelta(s)`);
    if (returnedUnits > 0) returns.push(`${round(returnedUnits,4)} u devueltas`);
    if (returnedOther > 0) returns.push(`${round(returnedOther,4)} unidad(es) devuelta(s)`);
    if (returns.length) parts.push(...returns);
    return {
      transactionCount: lines.length,
      baseQty: round(baseQty, 4),
      revenueCUP: round(revenueCUP, 2),
      boxes: round(boxes, 4),
      units: round(units, 4),
      returnedBoxes: round(returnedBoxes,4),
      returnedUnits: round(returnedUnits,4),
      presentationLabel: parts.join(' + ') || '0',
      transactionIds: Array.from(new Set(lines.map(x => x.transaction.id)))
    };
  }

  function stockDifference(systemQty, physicalQty) {
    const system = Number(systemQty);
    const physical = Number(physicalQty);
    if (!Number.isFinite(system) || !Number.isFinite(physical) || system < 0 || physical < 0) {
      throw new Error('Las cantidades para reconciliar inventario deben ser números válidos y no negativos.');
    }
    return round(system - physical, 4);
  }

  function findMissingPendingProducts(records, posId, inventory, getProductId) {
    const items = Array.isArray(inventory) ? inventory : [];
    const getId = typeof getProductId === 'function'
      ? getProductId
      : item => item && item.productId;
    const missing = [];
    for (const sale of pendingForPOS(records, posId)) {
      for (const line of (Array.isArray(sale.items) ? sale.items : [])) {
        const lineId = String(line && line.productId || '').trim();
        const lineName = normalizeName(line && line.name);
        const exists = items.some(item => {
          if (!item || typeof item !== 'object') return false;
          const itemId = String(getId(item) || '').trim();
          if (lineId) return itemId === lineId;
          return normalizeName(item.name) === lineName;
        });
        if (!exists) missing.push({ saleId: sale.id, productId: lineId, name: String(line && line.name || 'Producto sin nombre') });
      }
    }
    return missing;
  }

  function validateTransaction(transaction) {
    if (!transaction || typeof transaction !== 'object' || Array.isArray(transaction)) return false;
    if (!transaction.id || transaction.idempotencyKey !== transaction.id) return false;
    if (!transaction.posId || !transaction.user || !Array.isArray(transaction.items) || transaction.items.length < 1 || transaction.items.length > 100) return false;
    const isReturn = transaction.kind === 'return';
    if (!isReturn && transaction.kind && transaction.kind !== 'sale') return false;
    for (const line of transaction.items) {
      if (!line || !line.productId || !line.name || !Number.isFinite(Number(line.baseQty)) || !Number.isFinite(Number(line.lineTotalCUP))) return false;
      if (!Number.isFinite(Number(line.presentationQty)) || !Number.isFinite(Number(line.lineTotal))) return false;
      if (isReturn) {
        if (Number(line.baseQty) >= 0 || Number(line.presentationQty) >= 0 || Number(line.lineTotal) > 0 || Number(line.lineTotalCUP) > 0) return false;
      } else if (Number(line.baseQty) <= 0 || Number(line.presentationQty) <= 0 || Number(line.lineTotal) < 0 || Number(line.lineTotalCUP) < 0) return false;
    }
    const native = Number(transaction.totalNative);
    const cup = Number(transaction.totalCUP);
    if (!Number.isFinite(native) || !Number.isFinite(cup)) return false;
    const lineNative = round(transaction.items.reduce((sum, line) => sum + Number(line.lineTotal), 0), 2);
    const lineCup = round(transaction.items.reduce((sum, line) => sum + Number(line.lineTotalCUP), 0), 2);
    if (Math.abs(native - lineNative) > 0.011 || Math.abs(cup - lineCup) > 0.011) return false;
    if (isReturn) return native <= 0 && cup <= 0 && !!transaction.returnOf;
    return native >= 0 && cup >= 0;
  }

  const api = Object.freeze({
    makeLine,
    buildTransaction,
    buildReturnTransaction,
    canReturnSale,
    validateAvailableStock,
    pendingForPOS,
    summarizeProduct,
    stockDifference,
    findMissingPendingProducts,
    validateTransaction,
    round
  });
  root.SalesLedgerOps = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
