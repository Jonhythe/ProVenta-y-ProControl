'use strict';

/* Formato visual unificado: miles con coma, decimales con punto y máximo de dos posiciones. */
(function exposeProControlNumberFormat(root) {
  const MAX_DECIMALS = 2;
  const cache = new Map();
  function digitsOf(value, fallback = 2) {
    const n = Number(value);
    return Math.max(0, Math.min(MAX_DECIMALS, Number.isFinite(n) ? Math.trunc(n) : fallback));
  }
  function formatter(digits, fixed) {
    const key = (fixed ? 'fixed:' : 'number:') + digits;
    if (!cache.has(key)) {
      const options = { useGrouping: true, maximumFractionDigits: digits };
      if (fixed) options.minimumFractionDigits = digits;
      cache.set(key, new Intl.NumberFormat('en-US', options));
    }
    return cache.get(key);
  }
  function finite(value) {
    if (value === null || value === undefined || value === '') return 0;
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  function formatNumber(value, maximumFractionDigits = 2) {
    const n = finite(value);
    if (n === null) return '—';
    return formatter(digitsOf(maximumFractionDigits), false).format(n);
  }
  function formatFixed(value, fractionDigits = 2) {
    const n = finite(value);
    const d = digitsOf(fractionDigits);
    return formatter(d, true).format(n === null ? 0 : n);
  }
  function formatMoney(value) { return formatFixed(value, 2); }
  root.ProControlNumberFormat = Object.freeze({ maxDecimals: MAX_DECIMALS, formatNumber, formatFixed, formatMoney });
  if (typeof module !== 'undefined' && module.exports) module.exports = root.ProControlNumberFormat;
})(typeof window !== 'undefined' ? window : globalThis);
