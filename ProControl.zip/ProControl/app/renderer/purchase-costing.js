'use strict';

(function attachPurchaseCosting(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.PurchaseCosting = api;
})(typeof window !== 'undefined' ? window : globalThis, function createPurchaseCosting() {
  const roundMoney = value => Math.round((Number(value) + Number.EPSILON) * 100) / 100;

  function parseExtraAmount(value) {
    if (value === null || value === undefined || String(value).trim() === '') {
      return { ok: true, amount: 0, cents: 0 };
    }
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed < 0) {
      return { ok: false, message: 'El Extra de compra debe ser un importe válido igual o mayor que cero.' };
    }
    const cents = Math.round((parsed + Number.EPSILON) * 100);
    if (!Number.isSafeInteger(cents)) {
      return { ok: false, message: 'El Extra de compra supera el importe máximo que se puede procesar con seguridad.' };
    }
    return { ok: true, amount: cents / 100, cents };
  }

  /**
   * Distribuye un importe global extra por valor de compra de cada línea.
   * La entrada usa el coste por unidad de compra (también cuando se compra por caja)
   * y la cantidad de esa unidad de compra. `cost` en el resultado es el coste unitario
   * efectivo, con su parte del extra incluida; `baseCost` conserva el precio original.
   * Las asignaciones de dinero se calculan en céntimos y usan mayores restos para que
   * la suma de `extraAllocated` sea exactamente igual al extra registrado.
   */
  function allocateExtra(items, extraInput) {
    if (!Array.isArray(items) || items.length === 0) {
      return { ok: false, message: 'Añada al menos una línea de compra válida.' };
    }
    const extra = parseExtraAmount(extraInput);
    if (!extra.ok) return extra;

    const normalized = [];
    let totalWeight = 0;
    for (let index = 0; index < items.length; index += 1) {
      const source = items[index] || {};
      const qty = Number(source.qty);
      const baseCost = Number(source.baseCost !== undefined && source.baseCost !== null ? source.baseCost : source.cost);
      if (!Number.isFinite(qty) || qty <= 0 || !Number.isFinite(baseCost) || baseCost <= 0) {
        return { ok: false, message: `La línea ${index + 1} necesita una cantidad y un precio de compra válidos.` };
      }
      const weight = baseCost * qty;
      if (!Number.isFinite(weight) || weight <= 0) {
        return { ok: false, message: `El valor de la línea ${index + 1} no se puede calcular con seguridad.` };
      }
      totalWeight += weight;
      normalized.push({ source, index, qty, baseCost, weight });
    }
    if (!Number.isFinite(totalWeight) || totalWeight <= 0) {
      return { ok: false, message: 'No se pudo calcular el valor total de la mercancía.' };
    }

    // Reparto en céntimos mediante mayores restos: no se pierden importes por redondeo.
    const shares = normalized.map(line => {
      const exactCents = extra.cents * (line.weight / totalWeight);
      const floorCents = Math.floor(exactCents);
      return { ...line, exactCents, allocatedCents: floorCents, remainder: exactCents - floorCents };
    });
    let centsLeft = extra.cents - shares.reduce((sum, line) => sum + line.allocatedCents, 0);
    const tieSorted = [...shares].sort((a, b) =>
      b.remainder - a.remainder ||
      String(a.source.name || '').localeCompare(String(b.source.name || ''), 'es', { sensitivity: 'base' }) ||
      a.index - b.index
    );
    // Por teoría de mayores restos el residuo debe ser menor que el número de líneas;
    // aun así se corrige cualquier desviación de coma flotante sin perder ni crear céntimos.
    if (centsLeft > 0) {
      for (let i = 0; i < centsLeft; i += 1) tieSorted[i % tieSorted.length].allocatedCents += 1;
    } else if (centsLeft < 0) {
      const reverse = [...tieSorted].reverse();
      let need = -centsLeft;
      let cursor = 0;
      while (need > 0 && cursor < reverse.length * 2) {
        if (reverse[cursor % reverse.length].allocatedCents > 0) {
          reverse[cursor % reverse.length].allocatedCents -= 1;
          need -= 1;
        }
        cursor += 1;
      }
      if (need > 0) return { ok: false, message: 'No se pudo cuadrar el reparto del Extra al céntimo exacto.' };
    }

    const assignedByIndex = new Map(shares.map(line => [line.index, line.allocatedCents]));
    const outputItems = normalized.map(line => {
      const allocatedCents = assignedByIndex.get(line.index) || 0;
      const extraAllocated = allocatedCents / 100;
      const extraPerUnit = extraAllocated / line.qty;
      return {
        ...line.source,
        baseCost: line.baseCost,
        extraAllocated,
        extraPerUnit,
        cost: line.baseCost + extraPerUnit
      };
    });
    const goodsAmount = roundMoney(totalWeight);
    const extraAmount = extra.amount;
    return {
      ok: true,
      items: outputItems,
      goodsAmount,
      extraAmount,
      totalAmount: roundMoney(goodsAmount + extraAmount),
      method: 'proportional-value'
    };
  }

  return { allocateExtra, parseExtraAmount, roundMoney };
});
