/* Cifrado de la bóveda de registros antiguos. Nunca persiste claves en claro. */
(function () {
  'use strict';
  const ITERATIONS = 310000;
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const toB64 = bytes => { const input = new Uint8Array(bytes); let binary = ''; for (let i = 0; i < input.length; i += 0x8000) binary += String.fromCharCode(...input.subarray(i, i + 0x8000)); return btoa(binary); };
  const fromB64 = text => Uint8Array.from(atob(String(text)), ch => ch.charCodeAt(0));
  const toHex = bytes => Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, '0')).join('');
  const randomBytes = n => crypto.getRandomValues(new Uint8Array(n));
  async function derive(secret, salt, iterations = ITERATIONS) {
    if (typeof secret !== 'string' || secret.length < 6 || secret.length > 512) throw new Error('La contraseña o el código de recuperación no tiene un formato válido.');
    const material = await crypto.subtle.importKey('raw', encoder.encode(secret), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function wrapMaster(masterRaw, secret, purpose) {
    const salt = randomBytes(16); const iv = randomBytes(12);
    const key = await derive(secret, salt);
    const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: encoder.encode('ProControl-record-vault-v1:' + purpose) }, key, masterRaw);
    return { kdf: 'PBKDF2-SHA256', iterations: ITERATIONS, salt: toB64(salt), iv: toB64(iv), ciphertext: toB64(ciphertext) };
  }
  async function unwrapMaster(wrapper, secret, purpose) {
    if (!wrapper || wrapper.kdf !== 'PBKDF2-SHA256' || wrapper.iterations < 200000 || wrapper.iterations > 1000000) throw new Error('La configuración criptográfica del archivo antiguo no es válida.');
    const key = await derive(secret, fromB64(wrapper.salt), Number(wrapper.iterations));
    try {
      return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(wrapper.iv), additionalData: encoder.encode('ProControl-record-vault-v1:' + purpose) }, key, fromB64(wrapper.ciphertext)));
    } catch (_) { throw new Error('No se pudo desbloquear el archivo. Comprueba la contraseña o el código de recuperación.'); }
  }
  function code() {
    const raw = toHex(randomBytes(16)).toUpperCase();
    return raw.match(/.{1,4}/g).join('-');
  }
  async function initialize(password) {
    if (!crypto || !crypto.subtle) throw new Error('Web Crypto no está disponible en este entorno.');
    const masterRaw = randomBytes(32); const recoveryCode = code();
    const config = { version: 1, algorithm: 'AES-256-GCM', createdAt: new Date().toISOString(), passwordWrap: await wrapMaster(masterRaw, password, 'password'), recoveryWrap: await wrapMaster(masterRaw, recoveryCode.replace(/-/g, ''), 'recovery') };
    const key = await crypto.subtle.importKey('raw', masterRaw, { name: 'AES-GCM' }, true, ['encrypt', 'decrypt']);
    masterRaw.fill(0);
    return { config, recoveryCode, key };
  }
  async function unlockWithPassword(password, config) {
    const raw = await unwrapMaster(config && config.passwordWrap, password, 'password');
    const key = await crypto.subtle.importKey('raw', raw, { name: 'AES-GCM' }, true, ['encrypt', 'decrypt']); raw.fill(0); return key;
  }
  async function unlockWithRecovery(codeValue, config) {
    const normalized = String(codeValue || '').toUpperCase().replace(/[^0-9A-F]/g, '');
    if (!/^[0-9A-F]{32}$/.test(normalized)) throw new Error('El código de recuperación debe contener los 32 caracteres hexadecimales que se mostraron al activar el archivo.');
    const raw = await unwrapMaster(config && config.recoveryWrap, normalized, 'recovery');
    const key = await crypto.subtle.importKey('raw', raw, { name: 'AES-GCM' }, true, ['encrypt', 'decrypt']); raw.fill(0); return key;
  }
  async function rewrapPassword(key, password, existingConfig) {
    const raw = new Uint8Array(await crypto.subtle.exportKey('raw', key));
    const config = { ...existingConfig, passwordWrap: await wrapMaster(raw, password, 'password'), updatedAt: new Date().toISOString() };
    raw.fill(0); return config;
  }
  async function rewrapRecovery(key, existingConfig) {
    const raw = new Uint8Array(await crypto.subtle.exportKey('raw', key));
    const recoveryCode = code();
    const config = { ...existingConfig, recoveryWrap: await wrapMaster(raw, recoveryCode.replace(/-/g, ''), 'recovery'), recoveryRotatedAt: new Date().toISOString() };
    raw.fill(0); return { config, recoveryCode };
  }
  async function encryptArchive(key, section, date, records) {
    const iv = randomBytes(12);
    const plaintext = encoder.encode(JSON.stringify({ version: 1, section, date, archivedAt: new Date().toISOString(), records }));
    const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: encoder.encode(`ProControl-archive-file-v1:${section}:${date}`) }, key, plaintext);
    plaintext.fill(0);
    return JSON.stringify({ format: 'procontrol.encrypted-archive.v1', algorithm: 'AES-256-GCM', section, date, iv: toB64(iv), ciphertext: toB64(ciphertext) });
  }
  async function decryptArchive(key, contents) {
    let envelope;
    try { envelope = JSON.parse(contents); } catch (_) { throw new Error('El archivo cifrado no es JSON válido.'); }
    if (!envelope || envelope.format !== 'procontrol.encrypted-archive.v1' || envelope.algorithm !== 'AES-256-GCM' || !/^[a-z]+$/.test(String(envelope.section || '')) || !/^\d{4}-\d{2}-\d{2}$/.test(String(envelope.date || ''))) throw new Error('Formato del archivo cifrado incompatible.');
    let plaintext;
    try { plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(envelope.iv), additionalData: encoder.encode(`ProControl-archive-file-v1:${envelope.section}:${envelope.date}`) }, key, fromB64(envelope.ciphertext)); }
    catch (_) { throw new Error('La firma criptográfica del archivo no coincide; el contenido fue alterado o la clave no corresponde.'); }
    let payload;
    try { payload = JSON.parse(decoder.decode(plaintext)); } finally { new Uint8Array(plaintext).fill(0); }
    if (!payload || payload.version !== 1 || payload.section !== envelope.section || payload.date !== envelope.date || !Array.isArray(payload.records)) throw new Error('El contenido del archivo no coincide con sus metadatos.');
    return payload;
  }
  async function sha256Hex(text) { return toHex(await crypto.subtle.digest('SHA-256', encoder.encode(String(text)))); }
  window.PCRecordArchiveCrypto = { ITERATIONS, initialize, unlockWithPassword, unlockWithRecovery, rewrapPassword, rewrapRecovery, encryptArchive, decryptArchive, sha256Hex };
})();
