'use strict';
/*
 * Reconciliador local para paquetes firmados del puente móvil.
 * Nunca acepta cambios parciales: valida el paquete completo, aplica dentro de
 * DataStore.transaction y guarda antes de marcar el paquete como conciliado.
 */
(function exposeMobileReconcile(root) {
  const own = (o, k) => Object.prototype.hasOwnProperty.call(o || {}, k);
  const norm = value => String(value == null ? '' : value).trim().toLocaleLowerCase();
  const displayNumber = (value, digits = 2) => root.ProControlNumberFormat
    ? root.ProControlNumberFormat.formatNumber(value, digits)
    : new Intl.NumberFormat('en-US', { useGrouping:true, maximumFractionDigits:Math.min(2, digits) }).format(Number(value) || 0);
  const round = (value, decimals = 4) => {
    const f = 10 ** decimals;
    return Math.round((Number(value) + Number.EPSILON) * f) / f;
  };
  const idOf = (item, deps) => {
    try { return String(deps.Inventory._productIdForItem(item, deps.appState) || deps.Inventory.productIdForName(item && item.name, deps.appState) || '').trim(); }
    catch (_) { return String(item && item.productId || '').trim(); }
  };
  const posRef = (pos, deps) => String(deps.Inventory.posReference(pos) || '').trim();
  function getPOS(reference, deps) {
    const state = deps.appState;
    const idx = (state.pointsOfSale || []).findIndex(pos => pos && posRef(pos, deps) === String(reference || ''));
    return idx < 0 ? null : { idx, pos: state.pointsOfSale[idx], ref: String(reference) };
  }
  function getInventory(reference, deps) {
    if (String(reference) === 'warehouse') return { key: 'warehouse', inventory: deps.appState.inventory, pos: null, idx: null };
    const context = getPOS(reference, deps);
    if (!context || !Array.isArray(context.pos.inventory)) return null;
    return { key: context.ref, inventory: context.pos.inventory, pos: context.pos, idx: context.idx };
  }
  function partialClose(session) {
    return !!(session && ((session.counts && Object.keys(session.counts).length) ||
      (session.cash && Object.keys(session.cash).length) || (session.usd && Object.keys(session.usd).length) ||
      Number(session.transfer || 0) > 0 || session.breakdownDone === true));
  }
  function findItem(inventory, productId, deps) {
    const matches = (Array.isArray(inventory) ? inventory : []).filter(item => item && idOf(item, deps) === String(productId));
    if (matches.length > 1) throw new Error(`Hay más de un artículo con el ID ${productId}; se detuvo la conciliación.`);
    return matches[0] || null;
  }
  function validatePackageRecord(record) {
    if (!record || typeof record !== 'object' || !record.packageId || !record.payload || typeof record.payload !== 'object' || Array.isArray(record.payload)) throw new Error('El paquete no tiene una estructura válida.');
    if (record.status !== 'accepted_for_reconciliation') throw new Error('El paquete debe estar aceptado para conciliación antes de aplicarlo.');
    if (!/^[A-Za-z0-9_-]{8,100}$/.test(String(record.packageId))) throw new Error('El identificador del paquete no tiene un formato válido.');
    if (!/^[a-f0-9]{64}$/i.test(String(record.payloadHash || ''))) throw new Error('El paquete no tiene una huella SHA-256 verificable.');
    if (!['sale_batch', 'goods_receipt', 'return', 'transfer', 'shift_open', 'shift_close', 'inventory_snapshot', 'heartbeat'].includes(record.type)) throw new Error('Tipo de paquete no compatible.');
  }
  function findDurableReceipt(record, deps) {
    const receiptId = `mobile-package-receipt:${record.packageId}`;
    const marker = (deps.appState.auditLog || []).find(entry => entry && entry.id === receiptId && entry.type === 'mobile-package-receipt');
    if (!marker) return null;
    const data = marker.extraData && typeof marker.extraData === 'object' ? marker.extraData : {};
    if (String(data.payloadHash || '').toLowerCase() !== String(record.payloadHash).toLowerCase() || String(data.packageType || '') !== String(record.type)) {
      throw new Error('PACKAGE_ID_CONFLICT: el almacén comercial ya contiene un recibo con otra huella o tipo. No se modificó nada.');
    }
    return data;
  }
  function addDurableReceipt(record, deps, result, now) {
    const existing = findDurableReceipt(record, deps);
    if (existing) return existing;
    const receipt = {
      packageId: record.packageId, payloadHash: String(record.payloadHash).toLowerCase(), packageType: record.type,
      appliedAt: now, newOperations: Math.max(0, Number(result.newOperations) || 0),
      changedStock: !!result.changedStock, message: String(result.message || '').slice(0, 500)
    };
    deps.appState.auditLog.push({
      id: `mobile-package-receipt:${record.packageId}`, ts: now,
      timestamp: new Date(now).toLocaleString('es-ES'), user: deps.appState.currentUser || 'usuario',
      type: 'mobile-package-receipt', details: `Recibo durable de conciliación del paquete ${record.packageId}.`,
      extraData: receipt
    });
    return receipt;
  }
  function validateSaleTransaction(tx, type, deps) {
    if (!deps.SalesLedgerOps || !deps.SalesLedgerOps.validateTransaction(tx)) throw new Error(`El ticket ${tx && tx.id || '(sin ID)'} no supera la validación del registro de ventas.`);
    if (type === 'sale_batch' && tx.kind === 'return') throw new Error('Un paquete de ventas no puede contener devoluciones.');
    if (type === 'return' && tx.kind !== 'return') throw new Error('Un paquete de devolución debe contener exclusivamente eventos de devolución.');
  }
  function verifyLineAgainstProduct(line, item, deps) {
    if (norm(item.unit || 'u') !== norm(line.baseUnit || 'u')) throw new Error(`La unidad base de “${line.name}” ha cambiado. No se aplicó el paquete.`);
    const presentation = String(line.presentation || 'unit').toLowerCase();
    const q = Number(line.presentationQty);
    const baseQty = Number(line.baseQty);
    if (!Number.isFinite(q) || q <= 0 || !Number.isFinite(baseQty) || baseQty <= 0) throw new Error(`Cantidad inválida para “${line.name}”.`);
    if (presentation === 'box') {
      const factor = deps.Inventory.unitsPerBoxForPOSItem(item, deps.appState);
      if (!Number.isSafeInteger(Number(factor)) || Number(factor) <= 0 || Number(line.unitsPerBox) !== Number(factor) || baseQty !== q * Number(factor)) {
        throw new Error(`La equivalencia de caja de “${line.name}” no coincide con la configuración actual.`);
      }
    } else if (presentation === 'unit') {
      if (Math.abs(baseQty - q) > 1e-8) throw new Error(`La cantidad base del producto “${line.name}” no coincide con su presentación.`);
    } else throw new Error(`Presentación no admitida para “${line.name}”.`);
  }
  function salePlan(record, deps) {
    const payload = record.payload;
    if (payload.schemaVersion !== 1 || !Array.isArray(payload.transactions) || !payload.transactions.length || payload.transactions.length > 250) throw new Error('El paquete de ventas debe contener entre 1 y 250 tickets con schemaVersion 1.');
    const sales = [];
    const deltas = new Map();
    const seenInPackage = new Set();
    for (const supplied of payload.transactions) {
      validateSaleTransaction(supplied, 'sale_batch', deps);
      if (seenInPackage.has(String(supplied.id))) throw new Error(`El paquete repite el ticket ${supplied.id}.`);
      seenInPackage.add(String(supplied.id));
      const context = getPOS(supplied.posId, deps);
      if (!context) throw new Error(`El punto de venta ${supplied.posId} no existe en esta instalación.`);
      if (!context.pos.salesTrackingEnabled) throw new Error(`El punto de venta “${context.pos.name}” no tiene activado el registro de tickets. Abra el turno desde el escritorio antes de importar ventas.`);
      if (partialClose(deps.appState.closingSessions && deps.appState.closingSessions[String(context.idx)])) throw new Error(`El punto de venta “${context.pos.name}” tiene un cierre parcial; termínelo antes de importar ventas.`);
      const existing = (deps.appState.salesLedger || []).find(old => old && old.id === supplied.id);
      if (existing) {
        if (!sameTransaction(existing, supplied)) throw new Error(`El ID de ticket ${supplied.id} ya existe con datos distintos; se marcó el paquete como conflicto.`);
        sales.push({ tx: supplied, context, alreadyApplied: true, lineItems: [] });
        continue;
      }
      const lineItems = [];
      for (const line of supplied.items) {
        const item = findItem(context.pos.inventory, line.productId, deps);
        if (!item) throw new Error(`No se encuentra el producto ${line.name} (${line.productId}) en el inventario del punto de venta.`);
        verifyLineAgainstProduct(line, item, deps);
        const key = `${context.idx}::${line.productId}`;
        deltas.set(key, { context, productId: line.productId, item, qty: (deltas.get(key)?.qty || 0) + Number(line.baseQty) });
        lineItems.push({ line, item });
      }
      sales.push({ tx: supplied, context, alreadyApplied: false, lineItems });
    }
    // Todas las líneas (incluidos productos repetidos y tickets distintos) se contrastan contra el stock actual.
    for (const row of deltas.values()) {
      const need = row.qty;
      if (Number(row.item.qty) + 1e-9 < need) throw new Error(`Stock insuficiente de ${row.item.name}: disponible ${displayNumber(row.item.qty)}, paquete requiere ${displayNumber(need)}.`);
    }
    return { sales, deltas: Array.from(deltas.values()) };
  }
  function sameTransaction(a, b) {
    try {
      const keys = ['id','kind','posId','currency','paymentMethod','totalNative','totalCUP'];
      if (keys.some(key => String(a[key] == null ? '' : a[key]) !== String(b[key] == null ? '' : b[key]))) return false;
      if (!Array.isArray(a.items) || !Array.isArray(b.items) || a.items.length !== b.items.length) return false;
      return a.items.every((line, i) => {
        const other = b.items[i];
        return ['productId','presentation','presentationQty','baseQty','baseUnit','unitPrice','lineTotal','lineTotalCUP'].every(k => Number.isFinite(Number(line[k])) && Number.isFinite(Number(other[k])) ? Number(line[k]) === Number(other[k]) : String(line[k] ?? '') === String(other[k] ?? ''));
      });
    } catch (_) { return false; }
  }
  function returnPlan(record, deps) {
    const payload = record.payload;
    if (payload.schemaVersion !== 1 || !Array.isArray(payload.transactions) || !payload.transactions.length || payload.transactions.length > 100) throw new Error('El paquete de devoluciones debe contener entre 1 y 100 operaciones con schemaVersion 1.');
    const plans = [];
    const simulated = new Map();
    for (const ret of payload.transactions) {
      validateSaleTransaction(ret, 'return', deps);
      const original = (deps.appState.salesLedger || []).find(s => s && s.id === ret.returnOf);
      if (!original || original.kind === 'return') throw new Error(`No se encuentra el ticket original ${ret.returnOf}; impórtelo antes de la devolución.`);
      if (ret.posId !== original.posId) throw new Error('La devolución no corresponde al mismo punto de venta del ticket original.');
      const existingReturn = (deps.appState.salesLedger || []).find(s => s && s.kind === 'return' && s.returnOf === original.id);
      const existingById = (deps.appState.salesLedger || []).find(s => s && s.id === ret.id);
      if (existingById) {
        if (!sameTransaction(existingById, ret)) throw new Error(`El ID de devolución ${ret.id} ya existe con datos distintos.`);
        plans.push({ ret, original, alreadyApplied: true, groups: [] });
        continue;
      }
      if (existingReturn) throw new Error(`El ticket ${original.id} ya tiene una devolución registrada.`);
      const ctx = getPOS(original.posId, deps);
      if (!ctx) throw new Error(`No existe el punto de venta ${original.posId} para la devolución.`);
      if (partialClose(deps.appState.closingSessions && deps.appState.closingSessions[String(ctx.idx)])) throw new Error('Hay un cierre parcial en curso. Termine o reinicie el conteo antes de importar devoluciones.');
      if (ret.items.length !== original.items.length) throw new Error('La devolución no contiene las mismas líneas que el ticket original.');
      const groups = new Map();
      for (let i=0; i<original.items.length; i++) {
        const origLine = original.items[i], retLine = ret.items[i];
        if (retLine.productId !== origLine.productId || Number(retLine.baseQty) !== -Math.abs(Number(origLine.baseQty)) || Number(retLine.presentationQty) !== -Math.abs(Number(origLine.presentationQty)) || Math.abs(Number(retLine.lineTotalCUP) + Math.abs(Number(origLine.lineTotalCUP))) > .011) throw new Error(`La línea ${origLine.name} de la devolución no coincide con el ticket original.`);
        const item = findItem(ctx.pos.inventory, origLine.productId, deps) || findItem(deps.appState.inventory, origLine.productId, deps);
        if (!item) throw new Error(`No se puede restituir “${origLine.name}”: falta el producto maestro.`);
        if (norm(item.unit || 'u') !== norm(origLine.baseUnit || 'u')) throw new Error(`La unidad base de “${origLine.name}” cambió desde la venta.`);
        const key = `${ctx.idx}::${origLine.productId}`;
        const group = groups.get(key) || { ctx, item, productId: origLine.productId, qty: 0, restoreToPOS: !findItem(ctx.pos.inventory, origLine.productId, deps) };
        group.qty += Math.abs(Number(origLine.baseQty));
        groups.set(key, group);
      }
      for (const [key, group] of groups) simulated.set(key, (simulated.get(key) || 0) + group.qty);
      plans.push({ ret, original, ctx, alreadyApplied: false, groups: Array.from(groups.values()) });
    }
    return { returns: plans, additions: simulated };
  }
  function transferPlan(record, deps) {
    const payload = record.payload;
    const t = payload.transfer || payload;
    if (payload.schemaVersion !== 1 || !t || !t.id || !t.source || !t.destination || t.source === t.destination || !Array.isArray(t.items) || !t.items.length || t.items.length > 300) throw new Error('La transferencia no tiene un formato compatible (schemaVersion 1).');
    const source = getInventory(t.source, deps), dest = getInventory(t.destination, deps);
    if (!source || !dest) throw new Error('El origen o destino de la transferencia no existe o no tiene ID estable.');
    const groups = new Map();
    for (const line of t.items) {
      const productId = String(line.productId || '').trim();
      const qty = Number(line.qty ?? line.quantity);
      if (!productId || !Number.isFinite(qty) || qty <= 0) throw new Error('La transferencia contiene un producto o una cantidad inválida.');
      const item = findItem(source.inventory, productId, deps);
      if (!item) throw new Error(`No existe ${line.name || productId} en el origen de la transferencia.`);
      if (line.unit && norm(line.unit) !== norm(item.unit || 'u')) throw new Error(`La unidad de ${item.name} no coincide con el origen.`);
      const key = productId;
      const group = groups.get(key) || { productId, name: item.name, unit: item.unit || 'u', qty: 0, item };
      group.qty += qty;
      groups.set(key, group);
    }
    for (const group of groups.values()) if (Number(group.item.qty) + 1e-9 < group.qty) throw new Error(`Stock insuficiente para transferir ${group.name}: hay ${displayNumber(group.item.qty)}, se solicitan ${displayNumber(group.qty)}.`);
    const priorByPackage = (deps.appState.transfers || []).some(x => x && x.mobilePackageId === record.packageId);
    if (priorByPackage) return { transfer: t, source, dest, groups: [], alreadyApplied: true };
    const existingId = (deps.appState.transfers || []).some(x => x && (x.id === t.id || String(x.id || '').startsWith(`${t.id}:`)));
    if (existingId) throw new Error(`La transferencia ${t.id} ya existe sin referencia inequívoca al paquete; revise el historial antes de repetirla.`);
    return { transfer: t, source, dest, groups: Array.from(groups.values()), alreadyApplied: false };
  }
  function preview(record, deps) {
    validatePackageRecord(record);
    if (record.type === 'sale_batch') { const p = salePlan(record, deps); return { ok: true, type: record.type, operationCount: p.sales.length, newOperations: p.sales.filter(s => !s.alreadyApplied).length, message: 'Se añadirán tickets al registro y se descontará el stock en una sola transacción.' }; }
    if (record.type === 'return') { const p = returnPlan(record, deps); return { ok: true, type: record.type, operationCount: p.returns.length, newOperations: p.returns.filter(r => !r.alreadyApplied).length, message: 'Se registrarán devoluciones inversas; los tickets originales permanecerán intactos.' }; }
    if (record.type === 'transfer') { const p = transferPlan(record, deps); return { ok: true, type: record.type, operationCount: p.groups.length, newOperations: p.alreadyApplied ? 0 : p.groups.length, alreadyApplied: !!p.alreadyApplied, message: p.alreadyApplied ? 'Esta transferencia ya se aplicó para este paquete; no se volverá a descontar stock.' : `Se moverá stock de ${p.source.key} a ${p.dest.key}.` }; }
    if (record.type === 'shift_open' || record.type === 'shift_close') {
      const s = record.payload.shift;
      if (record.payload.schemaVersion !== 1 || !s || !s.id || !s.posId || !getPOS(s.posId, deps)) throw new Error('El evento de turno requiere un POS existente e identificadores válidos.');
      return { ok: true, type: record.type, operationCount: 1, newOperations: 1, message: record.type === 'shift_open' ? 'Se habilitará el registro de tickets para este POS.' : 'Se registrará una solicitud de cierre; el cierre físico y de caja se debe completar en el escritorio.' };
    }
    if (record.type === 'inventory_snapshot') {
      const incoming = Array.isArray(record.payload.inventory) ? record.payload.inventory : [];
      const incomingPOS = Array.isArray(record.payload.pointsOfSale) ? record.payload.pointsOfSale : [];
      const local = Array.isArray(deps.appState.inventory) ? deps.appState.inventory : [];
      const differences = [];
      const compareRows = (rows, localRows, scope, scopeId = null) => {
        for (const row of rows) {
          if (!row || !row.productId || !Number.isFinite(Number(row.qty))) {
            differences.push({ productId: row && row.productId || null, name: row && row.name || '', mobileQty: null, desktopQty: null, kind: 'invalid-snapshot-row', scope, scopeId });
            continue;
          }
          const item = findItem(localRows, row.productId, deps);
          if (!item) differences.push({ productId: row.productId, name: row.name, mobileQty: Number(row.qty), desktopQty: null, kind: 'missing-on-desktop', scope, scopeId });
          else if (Math.abs(Number(item.qty) - Number(row.qty)) > 1e-8) differences.push({ productId: row.productId, name: row.name, mobileQty: Number(row.qty), desktopQty: Number(item.qty), kind: 'quantity-difference', scope, scopeId });
        }
      };
      compareRows(incoming, local, 'warehouse');
      for (const posSnapshot of incomingPOS) {
        if (!posSnapshot || !posSnapshot.posId || !Array.isArray(posSnapshot.inventory)) {
          differences.push({ productId: null, name: posSnapshot && posSnapshot.name || '', mobileQty: null, desktopQty: null, kind: 'invalid-pos-snapshot', scope: 'pos', scopeId: posSnapshot && posSnapshot.posId || null });
          continue;
        }
        const context = getPOS(posSnapshot.posId, deps);
        if (!context) {
          differences.push({ productId: null, name: posSnapshot.name || '', mobileQty: null, desktopQty: null, kind: 'missing-pos-on-desktop', scope: 'pos', scopeId: posSnapshot.posId });
          continue;
        }
        compareRows(posSnapshot.inventory, context.pos.inventory || [], 'pos', posSnapshot.posId);
      }
      return { ok: true, type: record.type, operationCount: incoming.length + incomingPOS.reduce((n, p) => n + (Array.isArray(p && p.inventory) ? p.inventory.length : 0), 0), newOperations: 0, differences, message: `Instantánea de solo lectura: ${displayNumber(differences.length,0)} diferencia(s). No sobrescribe inventario.` };
    }
    if (record.type === 'goods_receipt') {
      const p = record.payload || {};
      const rows = Array.isArray(p.items) ? p.items : [];
      if (p.schemaVersion !== 1 || !/^[A-Za-z0-9:_-]{8,120}$/.test(String(p.dispatchId || '')) ||
          !p.posId || !/^[a-f0-9]{64}$/.test(String(p.itemsHash || '')) ||
          !/^\d{8}$/.test(String(p.confirmationCode || '')) ||
          !String(p.shiftPermitId || '') || !rows.length || rows.length > 300) {
        throw new Error('La recepción móvil no contiene el manifiesto y la confirmación requeridos.');
      }
      const context = getPOS(p.posId, deps);
      if (!context) throw new Error('El punto de venta del despacho ya no existe en ProControl.');
      const seen = new Set();
      for (const item of rows) {
        if (!item || !item.productId || seen.has(String(item.productId)) ||
            !Number.isFinite(Number(item.quantity)) || Number(item.quantity) <= 0) {
          throw new Error('El detalle de la recepción contiene productos duplicados o cantidades inválidas.');
        }
        seen.add(String(item.productId));
      }
      const already = (deps.appState.auditLog || []).some(x => x && x.id === 'mobile-goods-receipt:' + p.dispatchId);
      return {
        ok:true, type:record.type, operationCount:rows.length, newOperations:already ? 0 : 1,
        alreadyApplied:already,
        message:already
          ? 'Esta recepción ya se registró; no se volverá a alterar el inventario.'
          : 'Se registrará la evidencia de recepción del despacho confirmado. El inventario de ProControl NO se modificará porque ya fue actualizado al ejecutar el despacho.'
      };
    }
    if (record.type === 'heartbeat') return { ok: true, type: record.type, operationCount: 1, newOperations: 1, message: 'Se añadirá un evento de conectividad al registro de auditoría.' };
    throw new Error('Tipo de paquete no conciliable.');
  }
  function apply(record, deps) {
    if (!deps || !deps.appState || !deps.DataStore || !deps.Inventory) throw new Error('Falta el contexto de ProControl para conciliar.');
    validatePackageRecord(record);
    const durableReceipt = findDurableReceipt(record, deps);
    if (durableReceipt) {
      return {
        ok: true, type: record.type, packageId: record.packageId, applied: true,
        recovered: true, alreadyApplied: true, newOperations: 0,
        changedStock: !!durableReceipt.changedStock,
        message: 'La operación ya estaba guardada en el almacén comercial; se recuperó su recibo sin volver a aplicar movimientos.',
        result: durableReceipt
      };
    }
    const plan = preview(record, deps);
    if (record.type === 'inventory_snapshot') {
      const auditId = `mobile-snapshot:${record.packageId}`;
      const now = new Date().toISOString();
      const tx = deps.DataStore.transaction('mobile-reconcile-inventory-snapshot', ['auditLog'], () => {
        if (!(deps.appState.auditLog || []).some(x => x && x.id === auditId)) {
          deps.appState.auditLog.push({ id: auditId, ts: now, timestamp: new Date().toLocaleString('es-ES'), user: deps.appState.currentUser || 'usuario', type: 'mobile-inventory-snapshot-review', details: `Instantánea móvil revisada: ${displayNumber(plan.differences.length,0)} diferencia(s). No se sobrescribió inventario.`, extraData: { packageId: record.packageId, differences: plan.differences } });
        }
        addDurableReceipt(record, deps, { ...plan, changedStock: false }, now);
        if (!deps.DataStore.save()) throw new Error('No se pudo guardar la revisión de la instantánea.');
        return true;
      });
      if (!tx.ok) throw tx.error || new Error('No se pudo guardar la revisión de la instantánea.');
      return { ...plan, applied: true, changedStock: false };
    }
    const keys = ['inventory','pointsOfSale','transfers','salesLedger','closingSessions','auditLog','productCatalog'];
    const tx = deps.DataStore.transaction(`mobile-reconcile-${record.type}`, keys, () => {
      const now = new Date().toISOString();
      if (record.type === 'sale_batch') {
        const checked = salePlan(record, deps);
        const pendingDeltas = new Map();
        for (const sale of checked.sales) {
          if (sale.alreadyApplied) continue;
          for (const line of sale.tx.items) {
            const key = `${sale.context.idx}::${line.productId}`;
            pendingDeltas.set(key, (pendingDeltas.get(key) || 0) + Number(line.baseQty));
          }
        }
        for (const sale of checked.sales) {
          if (sale.alreadyApplied) continue;
          for (const line of sale.tx.items) {
            const current = findItem(sale.context.pos.inventory, line.productId, deps);
            if (!current) throw new Error(`El producto ${line.name} desapareció durante la conciliación.`);
            const qty = Number(current.qty) || 0;
            const need = pendingDeltas.get(`${sale.context.idx}::${line.productId}`) || 0;
            if (qty + 1e-9 < need) throw new Error(`Stock insuficiente de ${line.name} al confirmar el paquete.`);
          }
        }
        for (const sale of checked.sales) {
          if (sale.alreadyApplied) continue;
          const stored = JSON.parse(JSON.stringify(sale.tx));
          stored.source = `mobile:${record.deviceId}`;
          stored.mobilePackageId = record.packageId;
          stored.status = 'pending-close'; stored.closingId = null; stored.reconciledAt = null;
          for (const line of stored.items) {
            const item = findItem(sale.context.pos.inventory, line.productId, deps);
            const key = `${sale.context.idx}::${line.productId}`;
            item.qty = round(Number(item.qty) - Number(line.baseQty), 4);
            // Si un producto se repite dentro del mismo ticket, solo se descuenta una vez por línea, que es lo correcto.
          }
          deps.appState.salesLedger.push(stored);
          deps.appState.auditLog.push({ id: `mobile-sale:${stored.id}`, ts: now, timestamp: new Date(now).toLocaleString('es-ES'), user: deps.appState.currentUser || 'usuario', type: 'mobile-sale-import', details: `Ticket móvil ${stored.id} conciliado en ${sale.context.pos.name}.`, extraData: { packageId: record.packageId, deviceId: record.deviceId, saleId: stored.id, posId: stored.posId, totalCUP: stored.totalCUP } });
        }
      } else if (record.type === 'return') {
        const checked = returnPlan(record, deps);
        for (const itemPlan of checked.returns) {
          if (itemPlan.alreadyApplied) continue;
          // Restaurar stock en el POS, recuperando desde almacén maestro solo si falta la línea local.
          for (const group of itemPlan.groups) {
            let posItem = findItem(itemPlan.ctx.pos.inventory, group.productId, deps);
            if (!posItem && group.restoreToPOS) {
              posItem = JSON.parse(JSON.stringify(group.item)); posItem.qty = 0; posItem.productId = group.productId;
              itemPlan.ctx.pos.inventory.push(posItem);
            }
            if (!posItem) throw new Error(`No se pudo restaurar ${group.productId} al POS.`);
            posItem.qty = round(Number(posItem.qty || 0) + group.qty, 4);
          }
          const ret = JSON.parse(JSON.stringify(itemPlan.ret));
          ret.source = `mobile:${record.deviceId}`; ret.mobilePackageId = record.packageId; ret.status = 'pending-close'; ret.closingId = null; ret.reconciledAt = null;
          deps.appState.salesLedger.push(ret);
          deps.appState.auditLog.push({ id: `mobile-return:${ret.id}`, ts: now, timestamp: new Date(now).toLocaleString('es-ES'), user: deps.appState.currentUser || 'usuario', type: 'mobile-sale-return-import', details: `Devolución móvil ${ret.id} del ticket ${ret.returnOf}.`, extraData: { packageId: record.packageId, deviceId: record.deviceId, returnId: ret.id, originalSaleId: ret.returnOf, totalCUP: ret.totalCUP } });
        }
      } else if (record.type === 'transfer') {
        const checked = transferPlan(record, deps);
        const transfer = checked.transfer;
        if (!checked.alreadyApplied) {
          for (const group of checked.groups) {
            const sourceItem = findItem(checked.source.inventory, group.productId, deps);
            if (!sourceItem || Number(sourceItem.qty) + 1e-9 < group.qty) throw new Error(`No hay stock suficiente para transferir ${group.name} en el origen.`);
          }
          for (const group of checked.groups) {
            const sourceItem = findItem(checked.source.inventory, group.productId, deps);
            sourceItem.qty = round(Number(sourceItem.qty) - group.qty, 4);
            let destItem = findItem(checked.dest.inventory, group.productId, deps);
            if (destItem) {
              if (norm(destItem.unit || 'u') !== norm(sourceItem.unit || 'u')) throw new Error(`La unidad base del destino no coincide para ${group.name}.`);
              destItem.qty = round(Number(destItem.qty || 0) + group.qty, 4);
            } else {
              destItem = JSON.parse(JSON.stringify(sourceItem)); destItem.qty = round(group.qty, 4); destItem.productId = group.productId;
              checked.dest.inventory.push(destItem);
            }
            deps.appState.transfers.push({ id: `${transfer.id}:${group.productId}`, date: new Date(now).toLocaleString('es-ES'), ts: now, source: checked.source.key, destinations: [checked.dest.key], product: group.name, productId: group.productId, qtyPerDest: group.qty, mobilePackageId: record.packageId });
          }
          deps.appState.auditLog.push({ id: `mobile-transfer:${transfer.id}`, ts: now, timestamp: new Date(now).toLocaleString('es-ES'), user: deps.appState.currentUser || 'usuario', type: 'mobile-transfer-import', details: `Transferencia móvil ${transfer.id} conciliada.`, extraData: { packageId: record.packageId, transferId: transfer.id, source: checked.source.key, destination: checked.dest.key } });
        }
      } else if (record.type === 'shift_open' || record.type === 'shift_close') {
        const shift = record.payload.shift;
        const context = getPOS(shift.posId, deps);
        const auditId = `mobile-${record.type}:${shift.id}`;
        if (!(deps.appState.auditLog || []).some(x => x && x.id === auditId)) {
          if (record.type === 'shift_open') {
            const existingId = context.pos.mobileShiftId;
            if (existingId && existingId !== shift.id) throw new Error(`El POS ya tiene registrado otro turno móvil (${existingId}).`);
            context.pos.salesTrackingEnabled = true;
            context.pos.salesTrackingStartedAt = context.pos.salesTrackingStartedAt || shift.startedAt || now;
            context.pos.mobileShiftId = shift.id;
          }
          deps.appState.auditLog.push({ id: auditId, ts: now, timestamp: new Date(now).toLocaleString('es-ES'), user: deps.appState.currentUser || 'usuario', type: record.type === 'shift_open' ? 'mobile-shift-open' : 'mobile-shift-close-request', details: record.type === 'shift_open' ? `Inicio de turno móvil recibido para ${context.pos.name}.` : `Solicitud de cierre recibida para ${context.pos.name}; completar conteo y cierre desde escritorio.`, extraData: { packageId: record.packageId, shiftId: shift.id, posId: shift.posId } });
        }
      } else if (record.type === 'goods_receipt') {
        const receipt = record.payload;
        const auditId = 'mobile-goods-receipt:' + receipt.dispatchId;
        const already = (deps.appState.auditLog || []).some(x => x && x.id === auditId);
        if (!already) {
          deps.appState.auditLog.push({
            id:auditId, ts:now, timestamp:new Date(now).toLocaleString('es-ES'),
            user:deps.appState.currentUser || 'usuario',
            type:'mobile-goods-receipt',
            details:'Recepción móvil confirmada para ' + (getPOS(receipt.posId,deps).pos.name || receipt.posId) +
              '. ' + receipt.items.length + ' producto(s) revisados. El despacho ya había actualizado el inventario del PC.',
            extraData:{
              packageId:record.packageId, deviceId:record.deviceId,
              dispatchId:receipt.dispatchId, posId:receipt.posId,
              itemsHash:receipt.itemsHash, shiftPermitId:receipt.shiftPermitId,
              items:receipt.items.map(item=>({
                productId:item.productId,name:item.name,unit:item.unit,quantity:item.quantity,
                sale:item.sale,saleTransf:item.saleTransf,saleUSD:item.saleUSD,
                saleCurrency:item.saleCurrency,saleCustomCurrency:item.saleCustomCurrency
              }))
            }
          });
        }
      } else if (record.type === 'heartbeat') {
        const auditId = `mobile-heartbeat:${record.packageId}`;
        if (!(deps.appState.auditLog || []).some(x => x && x.id === auditId)) deps.appState.auditLog.push({ id: auditId, ts: now, timestamp: new Date(now).toLocaleString('es-ES'), user: deps.appState.currentUser || 'usuario', type: 'mobile-heartbeat', details: 'Se recibió un paquete de estado del dispositivo móvil.', extraData: { packageId: record.packageId, deviceId: record.deviceId, payload: record.payload } });
      }
      const changedStock = ['sale_batch', 'return', 'transfer'].includes(record.type) && Number(plan.newOperations || 0) > 0;
      addDurableReceipt(record, deps, { ...plan, changedStock }, now);
      if (!deps.DataStore.save()) throw new Error('ProControl no pudo guardar los cambios de conciliación. No continúe hasta comprobar el almacenamiento.');
      return { packageId: record.packageId, type: record.type, payloadHash: record.payloadHash, newOperations: plan.newOperations, changedStock, message: plan.message };
    });
    if (!tx.ok) throw tx.error || new Error('La conciliación se revirtió.');
    const changedStock = ['sale_batch', 'return', 'transfer'].includes(record.type) && Number(plan.newOperations || 0) > 0;
    return { ...plan, applied: true, changedStock, result: tx.result };
  }
  const api = Object.freeze({ preview, apply, validatePackageRecord, sameTransaction, findDurableReceipt });
  root.MobileReconcile = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
