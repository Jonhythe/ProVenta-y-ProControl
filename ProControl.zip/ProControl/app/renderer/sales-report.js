'use strict';

/*
 * ProControl — informe mensual de productos vendidos.
 * Integra tickets del escritorio y ProVenta, más cierres IPV antiguos sin tickets.
 * Los cierres con tickets se excluyen porque sus líneas ya existen en salesLedger.
 */
(function exposeSalesReport(root) {
  const round = (value, decimals) => {
    const factor = Math.pow(10, decimals || 2);
    return Math.round((Number(value) + Number.EPSILON) * factor) / factor;
  };
  const normalize = value => String(value || '').trim().normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase();

  function parseDate(value) {
    if (value instanceof Date) return Number.isFinite(value.getTime()) ? new Date(value.getTime()) : null;
    if (typeof value !== 'string' || !value.trim()) return null;
    const text = value.trim();
    let match = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(text);
    if (match) {
      const date = new Date(Number(match[3]), Number(match[2]) - 1, Number(match[1]));
      return date.getFullYear() === Number(match[3]) && date.getMonth() === Number(match[2]) - 1 && date.getDate() === Number(match[1]) ? date : null;
    }
    match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
    if (match) {
      const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
      return date.getFullYear() === Number(match[1]) && date.getMonth() === Number(match[2]) - 1 && date.getDate() === Number(match[3]) ? date : null;
    }
    const date = new Date(text);
    return Number.isFinite(date.getTime()) ? date : null;
  }

  function monthParts(date) {
    return {
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      monthKey: String(date.getFullYear()) + '-' + String(date.getMonth() + 1).padStart(2, '0'),
      monthLabel: new Intl.DateTimeFormat('es-ES', { month: 'long', year: 'numeric' }).format(date)
        .replace(/^./, letter => letter.toLocaleUpperCase())
    };
  }

  function collectLedgerRows(salesLedger) {
    const rows = [];
    const seen = new Set();
    for (const tx of (Array.isArray(salesLedger) ? salesLedger : [])) {
      if (!tx || typeof tx !== 'object') continue;
      const id = String(tx.id || '').trim();
      if (!id || seen.has(id)) continue;
      const kind = tx.kind || 'sale';
      if (kind !== 'sale' && kind !== 'return') continue;
      const date = parseDate(tx.ts || tx.date);
      const posId = String(tx.posId || '').trim();
      if (!date || !posId || !Array.isArray(tx.items)) continue;
      seen.add(id);
      for (const line of tx.items) {
        if (!line || typeof line !== 'object') continue;
        let quantity = Number(line.baseQty);
        let revenueCUP = Number(line.lineTotalCUP);
        if (!Number.isFinite(quantity) || !Number.isFinite(revenueCUP) || quantity === 0) continue;
        if (kind === 'return') {
          quantity = -Math.abs(quantity);
          revenueCUP = -Math.abs(revenueCUP);
        } else {
          quantity = Math.abs(quantity);
          revenueCUP = Math.abs(revenueCUP);
        }
        const name = String(line.name || '').trim();
        const baseUnit = String(line.baseUnit || line.unit || '').trim();
        if (!name || !baseUnit) continue;
        rows.push(Object.assign({}, monthParts(date), {
          date,
          productId: String(line.productId || '').trim(),
          name,
          baseUnit,
          quantity,
          revenueCUP,
          posId,
          posName: String(tx.posName || '').trim(),
          transactionId: id,
          source: String(tx.source || 'desktop')
        }));
      }
    }
    return rows;
  }

  function collectLegacyClosingRows(closingHistory) {
    const rows = [];
    for (const closing of (Array.isArray(closingHistory) ? closingHistory : [])) {
      if (!closing || typeof closing !== 'object') continue;
      if (closing.salesTrackingMode === true || Number(closing.rotationDataVersion) >= 2 ||
          (Array.isArray(closing.salesLedgerIds) && closing.salesLedgerIds.length > 0)) continue;
      const date = parseDate(closing.ts || closing.date);
      if (!date || !Array.isArray(closing.products)) continue;
      const posId = String(closing.posId || '').trim();
      const posName = String(closing.posName || '').trim();
      if (!posId && !posName) continue;
      for (const product of closing.products) {
        if (!product || typeof product !== 'object') continue;
        const quantity = Number(product.sold);
        if (!Number.isFinite(quantity) || quantity <= 0) continue;
        let revenueCUP = Number(product.subtotal);
        if (!Number.isFinite(revenueCUP)) revenueCUP = quantity * Number(product.price);
        if (!Number.isFinite(revenueCUP)) continue;
        const name = String(product.name || '').trim();
        const baseUnit = String(product.baseUnit || product.unit || 'u').trim();
        if (!name) continue;
        rows.push(Object.assign({}, monthParts(date), {
          date,
          productId: String(product.productId || '').trim(),
          name,
          baseUnit,
          quantity,
          revenueCUP,
          posId,
          posName,
          transactionId: String(closing.id || ('legacy-close-' + date.getTime())),
          source: 'closing-ipv'
        }));
      }
    }
    return rows;
  }

  function matchesPOS(row, filter) {
    if (!filter || filter.id === 'all') return true;
    const id = String(filter.id || '').trim();
    if (row.posId) return !!id && row.posId === id;
    return !!filter.name && normalize(row.posName) === normalize(filter.name);
  }

  function buildMonthlyReport(options) {
    const config = options || {};
    const sourceRows = collectLedgerRows(config.salesLedger).concat(collectLegacyClosingRows(config.closingHistory));
    const years = Array.from(new Set(sourceRows.map(row => row.year))).sort((a, b) => b - a);
    const requestedYear = Number(config.year);
    const year = Number.isInteger(requestedYear) && requestedYear >= 1900 && requestedYear <= 9999
      ? requestedYear : (years[0] || new Date().getFullYear());
    const sortBy = config.sortBy === 'quantity' ? 'quantity' : 'revenue';
    const filter = config.posFilter || { id: 'all' };
    const monthly = new Map();

    for (const record of sourceRows) {
      if (record.year !== year || !matchesPOS(record, filter)) continue;
      let month = monthly.get(record.monthKey);
      if (!month) {
        month = Object.assign({}, monthParts(record.date), { products: new Map() });
        monthly.set(record.monthKey, month);
      }
      const identity = record.productId
        ? record.productId + '\u0000' + normalize(record.baseUnit)
        : normalize(record.name) + '\u0000' + normalize(record.baseUnit);
      let product = month.products.get(identity);
      if (!product) {
        product = {
          productId: record.productId, name: record.name, baseUnit: record.baseUnit,
          quantity: 0, revenueCUP: 0, transactionIds: new Set(), latestDate: record.date.getTime()
        };
        month.products.set(identity, product);
      }
      product.quantity += record.quantity;
      product.revenueCUP += record.revenueCUP;
      if (record.date.getTime() >= product.latestDate) {
        product.name = record.name;
        product.latestDate = record.date.getTime();
      }
      product.transactionIds.add(record.transactionId);
    }

    const months = Array.from(monthly.values()).map(month => {
      const rows = Array.from(month.products.values()).map(product => ({
        productId: product.productId,
        name: product.name,
        baseUnit: product.baseUnit,
        quantity: round(product.quantity, 4),
        revenueCUP: round(product.revenueCUP, 2),
        transactionCount: product.transactionIds.size
      }));
      rows.sort((a, b) => sortBy === 'quantity'
        ? (b.quantity - a.quantity || b.revenueCUP - a.revenueCUP || a.name.localeCompare(b.name, 'es', { sensitivity: 'base' }))
        : (b.revenueCUP - a.revenueCUP || b.quantity - a.quantity || a.name.localeCompare(b.name, 'es', { sensitivity: 'base' })));
      return {
        monthKey: month.monthKey,
        year: month.year,
        month: month.month,
        monthLabel: month.monthLabel,
        rows,
        revenueCUP: round(rows.reduce((sum, row) => sum + row.revenueCUP, 0), 2),
        productCount: rows.length
      };
    }).sort((a, b) => b.monthKey.localeCompare(a.monthKey));

    return {
      year,
      years,
      sortBy,
      months,
      revenueCUP: round(months.reduce((sum, month) => sum + month.revenueCUP, 0), 2),
      productCount: new Set(months.flatMap(month => month.rows.map(row =>
        (row.productId || normalize(row.name)) + '\u0000' + normalize(row.baseUnit)
      ))).size
    };
  }

  const uiState = { year: null, posIndex: null, sortBy: 'revenue', appState: null, container: null };
  function safeText(value) {
    if (typeof esc === 'function') return esc(value);
    return String(value == null ? '' : value).replace(/[&<>"']/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[char]));
  }
  function groupedNumber(value) {
    return typeof formatGroupedNumber === 'function'
      ? formatGroupedNumber(value, 4)
      : Number(value || 0).toLocaleString('en-US', { useGrouping: true, maximumFractionDigits: 2 });
  }
  function money(value) {
    return typeof formatMoney === 'function'
      ? formatMoney(value)
      : Number(value || 0).toLocaleString('en-US', { useGrouping: true, minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function reportOptions() {
    const app = uiState.appState || {};
    let posFilter = { id: 'all' };
    if (uiState.posIndex !== null) {
      const pos = Array.isArray(app.pointsOfSale) ? app.pointsOfSale[uiState.posIndex] : null;
      if (pos) {
        const inventoryApi = typeof Inventory !== 'undefined' ? Inventory : null;
        const id = (inventoryApi && typeof inventoryApi.posReference === 'function' && inventoryApi.posReference(pos)) || pos.id || '';
        posFilter = { id: String(id), name: String(pos.name || '') };
      }
    }
    return {
      salesLedger: app.salesLedger,
      closingHistory: app.closingHistory,
      year: uiState.year,
      sortBy: uiState.sortBy,
      posFilter
    };
  }
  function render(container, appState) {
    if (!container || !root.SalesReportOps) return;
    uiState.appState = appState || {};
    uiState.container = container;
    const allYears = buildMonthlyReport({
      salesLedger: uiState.appState.salesLedger,
      closingHistory: uiState.appState.closingHistory
    }).years;
    if (!Number.isInteger(uiState.year) || (allYears.length && !allYears.includes(uiState.year))) {
      uiState.year = allYears[0] || new Date().getFullYear();
    }
    const years = allYears.length ? allYears : [uiState.year];
    const points = Array.isArray(uiState.appState.pointsOfSale) ? uiState.appState.pointsOfSale : [];
    const yearOptions = years.map(year =>
      '<option value="' + year + '"' + (year === uiState.year ? ' selected' : '') + '>' + year + '</option>'
    ).join('');
    const posOptions = points.map((pos, index) =>
      '<option value="' + index + '"' + (index === uiState.posIndex ? ' selected' : '') + '>' +
      safeText(pos && pos.name || ('Punto de Venta ' + (index + 1))) + '</option>'
    ).join('');

    container.innerHTML =
      '<h2 style="color:var(--color-accent);text-align:center;">Registro de Productos Vendidos</h2>' +
      '<div class="gold-divider"></div>' +
      '<p style="color:var(--color-text-muted);text-align:center;margin:.4rem 0 1.2rem;">' +
      'Reúne los tickets del escritorio y de ProVenta, además de los cierres IPV históricos sin tickets. Los importes se muestran netos en CUP; las devoluciones se descuentan. Las cantidades se expresan en la unidad base de cada producto y no son comparables entre unidades distintas.' +
      '</p>' +
      '<div style="display:flex;align-items:end;justify-content:center;gap:12px;flex-wrap:wrap;margin:0 auto 1.2rem;max-width:900px;">' +
        '<div class="form-group" style="flex:1 1 130px;min-width:120px;margin:0;">' +
          '<label for="sold-products-year" style="color:var(--color-accent);font-weight:700;">Año</label>' +
          '<select id="sold-products-year" style="width:100%;" onchange="SoldProductsUI.setYear(this.value)">' + yearOptions + '</select>' +
        '</div>' +
        '<div class="form-group" style="flex:2 1 220px;min-width:180px;margin:0;">' +
          '<label for="sold-products-pos" style="color:var(--color-accent);font-weight:700;">Punto de Venta</label>' +
          '<select id="sold-products-pos" style="width:100%;" onchange="SoldProductsUI.setPOS(this.value)">' +
            '<option value="all"' + (uiState.posIndex === null ? ' selected' : '') + '>Consolidado Global (Todos)</option>' +
            posOptions +
          '</select>' +
        '</div>' +
        '<div class="form-group" style="flex:1 1 190px;min-width:170px;margin:0;">' +
          '<label for="sold-products-sort" style="color:var(--color-accent);font-weight:700;">Ordenar productos</label>' +
          '<select id="sold-products-sort" style="width:100%;" onchange="SoldProductsUI.setSort(this.value)">' +
            '<option value="revenue"' + (uiState.sortBy === 'revenue' ? ' selected' : '') + '>Mayor importe vendido</option>' +
            '<option value="quantity"' + (uiState.sortBy === 'quantity' ? ' selected' : '') + '>Mayor cantidad vendida</option>' +
          '</select>' +
        '</div>' +
      '</div>' +
      '<div id="sold-products-report" aria-live="polite"></div>';
    renderReport();
  }
  function renderReport() {
    const host = root.document && root.document.getElementById('sold-products-report');
    if (!host || !uiState.appState) return;
    const report = buildMonthlyReport(reportOptions());
    if (!report.months.length) {
      host.innerHTML =
        '<div class="insight-box" style="text-align:center;padding:2rem;">' +
          '<h3 style="color:var(--color-accent);">Sin registros para este período</h3>' +
          '<p style="color:var(--color-text-muted);">Cuando se registren ventas desde ProControl, se importen ventas de ProVenta o se guarden cierres IPV, aparecerán aquí agrupadas por mes.</p>' +
        '</div>';
      return;
    }
    let monthMarkup = '';
    report.months.forEach((month, index) => {
      const rows = month.rows.map(row =>
        '<tr>' +
          '<td style="overflow-wrap:anywhere;">' + safeText(row.name) + '</td>' +
          '<td>' + groupedNumber(row.quantity) + ' ' + safeText(row.baseUnit) + '</td>' +
          '<td>' + money(row.revenueCUP) + '</td>' +
        '</tr>'
      ).join('');
      monthMarkup +=
        '<details class="insight-box" ' + (index === 0 ? 'open' : '') + ' style="margin:0 0 12px;padding:0;overflow:hidden;">' +
          '<summary style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;cursor:pointer;padding:14px 16px;color:var(--color-accent);font-weight:800;">' +
            '<span>' + safeText(month.monthLabel) + '</span>' +
            '<span style="color:var(--color-text-surface);">' + money(month.revenueCUP) + ' CUP</span>' +
          '</summary>' +
          '<div style="padding:0 12px 12px;">' +
            '<div style="overflow-x:hidden;width:100%;">' +
              '<table class="purchase-table" style="width:100%;min-width:0;table-layout:fixed;border-collapse:collapse;">' +
                '<thead><tr><th style="width:44%;">Producto</th><th style="width:27%;">Cantidad</th><th style="width:29%;">Importe (CUP)</th></tr></thead>' +
                '<tbody>' + rows + '</tbody>' +
                '<tfoot><tr><th colspan="2" style="text-align:right;">Total del mes</th><th>' + money(month.revenueCUP) + ' CUP</th></tr></tfoot>' +
              '</table>' +
            '</div>' +
          '</div>' +
        '</details>';
    });
    host.innerHTML =
      '<div class="insight-box" style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:14px;">' +
        '<div><h3 style="margin:0;color:var(--color-accent);">Total neto de ' + report.year + '</h3>' +
          '<small style="color:var(--color-text-muted);">' + report.productCount + ' productos · ' + report.months.length + ' meses con actividad</small></div>' +
        '<strong style="font-size:1.35rem;color:var(--color-text-surface);">' + money(report.revenueCUP) + ' CUP</strong>' +
      '</div>' + monthMarkup;
  }
  function setYear(value) {
    const year = Number(value);
    if (!Number.isInteger(year) || year < 1900 || year > 9999) return;
    uiState.year = year;
    renderReport();
  }
  function setPOS(value) {
    if (value === 'all') uiState.posIndex = null;
    else {
      const index = Number(value);
      const points = uiState.appState && Array.isArray(uiState.appState.pointsOfSale) ? uiState.appState.pointsOfSale : [];
      if (!Number.isInteger(index) || index < 0 || index >= points.length) return;
      uiState.posIndex = index;
    }
    renderReport();
  }
  function setSort(value) {
    uiState.sortBy = value === 'quantity' ? 'quantity' : 'revenue';
    renderReport();
  }

  function refresh() {
    if (!uiState.container || !uiState.appState || !root.document || !root.document.getElementById('sold-products-report')) return false;
    render(uiState.container, uiState.appState);
    return true;
  }

  root.SalesReportOps = Object.freeze({ parseDate, collectLedgerRows, collectLegacyClosingRows, buildMonthlyReport });
  root.SoldProductsUI = Object.freeze({ render, refresh, setYear, setPOS, setSort });
  if (typeof module !== 'undefined' && module.exports) module.exports = root.SalesReportOps;
})(typeof window !== 'undefined' ? window : globalThis);
