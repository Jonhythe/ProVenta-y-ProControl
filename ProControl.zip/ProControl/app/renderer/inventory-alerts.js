'use strict';

/*
 * ProControl — alertas manuales de stock.
 * La alerta depende únicamente de las existencias actuales y del límite
 * configurado por producto. No requiere tickets ni cierres de venta.
 */
(function exposeInventoryStockAlerts(root) {
  const DEFAULT_MANUAL_MINIMUM = 10;
  const WARNING_BAND_UNITS = 10;

  const numberOrNull = value => {
    if (value === null || value === undefined || String(value).trim() === '') return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  };

  function evaluate(inventoryInput) {
    const inventory = Array.isArray(inventoryInput) ? inventoryInput : [];
    const results = inventory.map((value, index) => {
      const item = value && typeof value === 'object' ? value : {};
      const settings = item.stockAlertSettings && typeof item.stockAlertSettings === 'object'
        ? item.stockAlertSettings : {};
      const rawThreshold = settings.alertStock ?? settings.manualMinimum
        ?? item.minimumStock ?? item.minStock ?? item.minQty;
      const configuredThreshold = numberOrNull(rawThreshold);
      const alertStock = configuredThreshold !== null && configuredThreshold >= 0
        ? configuredThreshold : DEFAULT_MANUAL_MINIMUM;
      const qtyCandidate = numberOrNull(item.qty);
      const qty = qtyCandidate === null ? 0 : qtyCandidate;
      const warningThreshold = alertStock + WARNING_BAND_UNITS;

      let status = 'ok';
      let message = 'Stock suficiente';
      if (qtyCandidate === null) {
        status = 'critical';
        message = 'Cantidad de stock no válida; revisar el registro';
      } else if (qty <= 0) {
        status = 'critical';
        message = 'Agotado';
      } else if (qty <= alertStock) {
        status = 'critical';
        message = 'Alcanzó el stock de alerta';
      } else if (qty <= warningThreshold) {
        status = 'reorder';
        message = 'Dentro del margen preventivo de 10 unidades';
      }

      return {
        index,
        item,
        qty,
        unit: String(item.unit || item.baseUnit || 'u'),
        hasRecentDemand: false,
        netUnits: 0,
        averageDailySales: 0,
        demandSource: 'manual',
        leadTimeDays: 0,
        safetyStockUnits: 0,
        hasFixedSafety: false,
        manualMinimum: alertStock,
        alertStock,
        criticalThreshold: alertStock,
        warningBandUnits: WARNING_BAND_UNITS,
        warningThreshold,
        reorderPoint: warningThreshold,
        coverageDays: null,
        status,
        message
      };
    });

    const rank = { critical: 0, reorder: 1, ok: 2 };
    results.sort((a, b) => {
      if (rank[a.status] !== rank[b.status]) return rank[a.status] - rank[b.status];
      if (a.qty !== b.qty) return a.qty - b.qty;
      return String(a.item.name || '').localeCompare(String(b.item.name || ''), 'es');
    });
    return results;
  }

  const api = Object.freeze({ DEFAULT_MANUAL_MINIMUM, WARNING_BAND_UNITS, evaluate });
  root.InventoryStockAlerts = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
