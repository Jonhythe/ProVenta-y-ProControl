'use strict';

// Almacenamiento de bóvedas de registros históricos cifrados.
// El proceso principal solo ve sobres cifrados: nunca recibe contraseñas ni claves.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MAX_FILE_BYTES = 25 * 1024 * 1024;
// Los nuevos nombres son opacos; la forma antigua se acepta solo para compatibilidad con candidatos previos.
const FILE_RE = /^v1_(?:(?:sessions|audit|entries|corrections|transfers|closings|returns)_\d{4}-\d{2}-\d{2}_)?[0-9a-f-]{36}\.pca$/i;

function hashText(text) {
  return crypto.createHash('sha256').update(String(text), 'utf8').digest('hex');
}
function validateName(fileName) {
  if (typeof fileName !== 'string' || !FILE_RE.test(fileName) || fileName.includes('..') || fileName.includes('/') || fileName.includes('\\')) {
    const e = new Error('ARCHIVE_NAME_INVALID'); e.code = 'ARCHIVE_NAME_INVALID'; throw e;
  }
  return fileName;
}
function validateEnvelope(raw) {
  if (typeof raw !== 'string' || Buffer.byteLength(raw, 'utf8') > MAX_FILE_BYTES) {
    const e = new Error('ARCHIVE_SIZE_INVALID'); e.code = 'ARCHIVE_SIZE_INVALID'; throw e;
  }
  let envelope;
  try { envelope = JSON.parse(raw); } catch (_) { const e = new Error('ARCHIVE_ENVELOPE_INVALID'); e.code = e.message; throw e; }
  if (!envelope || envelope.format !== 'procontrol.encrypted-archive.v1' || envelope.algorithm !== 'AES-256-GCM' ||
      !/^[a-z]+$/.test(String(envelope.section || '')) || !/^\d{4}-\d{2}-\d{2}$/.test(String(envelope.date || '')) ||
      typeof envelope.iv !== 'string' || typeof envelope.ciphertext !== 'string' || envelope.iv.length > 64 || envelope.ciphertext.length > MAX_FILE_BYTES * 2) {
    const e = new Error('ARCHIVE_ENVELOPE_INVALID'); e.code = e.message; throw e;
  }
  return envelope;
}
class RecordArchiveStore {
  constructor(userDataDir) {
    this.root = path.join(userDataDir, 'registros-antiguos');
  }
  // Reintenta al iniciar la aplicación la eliminación de carpetas apartadas por
  // un borrado anterior si Windows/antivirus tenía alguno de los archivos bloqueado.
  // Solo afecta carpetas con el nombre exacto que genera stageClearAll().
  cleanupPendingWipeStages() {
    if (!fs.existsSync(this.root)) return { ok: true, deletedDirs: 0, pendingDirs: 0 };
    let deletedDirs = 0;
    let pendingDirs = 0;
    for (const entry of fs.readdirSync(this.root, { withFileTypes: true })) {
      if (!entry.isDirectory() || !/^\.wipe-stage-[0-9a-f-]{36}$/i.test(entry.name)) continue;
      const target = path.join(this.root, entry.name);
      try {
        const stat = fs.lstatSync(target);
        if (!stat.isDirectory() || stat.isSymbolicLink()) continue;
        fs.rmSync(target, { recursive: true, force: false });
        deletedDirs++;
      } catch (_) {
        pendingDirs++;
      }
    }
    return { ok: pendingDirs === 0, deletedDirs, pendingDirs };
  }
  _ensureDir() { fs.mkdirSync(this.root, { recursive: true, mode: 0o700 }); }
  _file(fileName) { return path.join(this.root, validateName(fileName)); }
  listFiles() {
    this._ensureDir();
    return fs.readdirSync(this.root, { withFileTypes: true })
      .filter(d => d.isFile() && FILE_RE.test(d.name))
      .map(d => {
        const full = this._file(d.name); const st = fs.statSync(full);
        return { fileName: d.name, bytes: st.size, modifiedAt: st.mtime.toISOString() };
      }).sort((a,b) => a.fileName.localeCompare(b.fileName));
  }
  readEncrypted(fileName) {
    this._ensureDir(); const full = this._file(fileName); const st = fs.lstatSync(full);
    if (!st.isFile() || st.isSymbolicLink() || st.size > MAX_FILE_BYTES) { const e = new Error('ARCHIVE_FILE_INVALID'); e.code = e.message; throw e; }
    const contents = fs.readFileSync(full, 'utf8');
    validateEnvelope(contents);
    return { fileName, contents, bytes: st.size, sha256: hashText(contents) };
  }
  writeEncrypted(input) {
    this._ensureDir();
    const fileName = validateName(input && input.fileName);
    const contents = String(input && input.contents || '');
    validateEnvelope(contents);
    const actualHash = hashText(contents);
    if (actualHash !== String(input && input.sha256 || '')) { const e = new Error('ARCHIVE_HASH_MISMATCH'); e.code = e.message; throw e; }
    const finalPath = this._file(fileName);
    if (fs.existsSync(finalPath)) { const e = new Error('ARCHIVE_ALREADY_EXISTS'); e.code = e.message; throw e; }
    const tempPath = path.join(this.root, `.tmp-${crypto.randomUUID()}.part`);
    let fd;
    try {
      fd = fs.openSync(tempPath, 'wx', 0o600);
      fs.writeFileSync(fd, contents, { encoding: 'utf8' });
      fs.fsyncSync(fd);
      fs.closeSync(fd); fd = null;
      const reread = fs.readFileSync(tempPath, 'utf8');
      if (hashText(reread) !== actualHash) { const e = new Error('ARCHIVE_VERIFY_FAILED'); e.code = e.message; throw e; }
      validateEnvelope(reread);
      // Atomic commit on the same volume. The DB/index is updated by the renderer only after this returns.
      fs.renameSync(tempPath, finalPath);
      try { const dirFd = fs.openSync(this.root, 'r'); fs.fsyncSync(dirFd); fs.closeSync(dirFd); } catch (_) { /* Windows may not fsync a directory. */ }
      return { ok: true, fileName, bytes: Buffer.byteLength(contents, 'utf8'), sha256: actualHash };
    } catch (error) {
      if (fd !== null && fd !== undefined) { try { fs.closeSync(fd); } catch (_) {} }
      try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch (_) {}
      throw error;
    }
  }
  deleteEncrypted(fileName, expectedHash) {
    this._ensureDir();
    const full = this._file(fileName);
    let st;
    try { st = fs.lstatSync(full); }
    catch (error) {
      if (error && error.code === 'ENOENT') { const e = new Error('ARCHIVE_FILE_NOT_FOUND'); e.code = e.message; throw e; }
      throw error;
    }
    if (!st.isFile() || st.isSymbolicLink() || st.size > MAX_FILE_BYTES) { const e = new Error('ARCHIVE_FILE_INVALID'); e.code = e.message; throw e; }
    const contents = fs.readFileSync(full, 'utf8');
    validateEnvelope(contents);
    const actualHash = hashText(contents);
    if (actualHash !== String(expectedHash || '')) { const e = new Error('ARCHIVE_HASH_MISMATCH'); e.code = e.message; throw e; }
    fs.unlinkSync(full);
    try { const dirFd = fs.openSync(this.root, 'r'); fs.fsyncSync(dirFd); fs.closeSync(dirFd); } catch (_) { /* Windows may not fsync a directory. */ }
    return { ok: true, fileName, sha256: actualHash };
  }
  stageClearAll() {
    this._ensureDir();
    const stageDir = path.join(this.root, '.wipe-stage-' + crypto.randomUUID());
    fs.mkdirSync(stageDir, { recursive: false, mode: 0o700 });
    const moved = [];
    try {
      for (const entry of fs.readdirSync(this.root, { withFileTypes: true })) {
        if (!entry.isFile()) continue;
        if (!FILE_RE.test(entry.name) && !/^\.tmp-[0-9a-f-]{36}\.part$/i.test(entry.name)) continue;
        const source = path.join(this.root, entry.name);
        const stat = fs.lstatSync(source);
        if (!stat.isFile() || stat.isSymbolicLink()) {
          const error = new Error('ARCHIVE_WIPE_FILE_INVALID'); error.code = error.message; throw error;
        }
        fs.renameSync(source, path.join(stageDir, entry.name));
        moved.push(entry.name);
      }
    } catch (error) {
      for (const name of moved.reverse()) {
        try { fs.renameSync(path.join(stageDir, name), path.join(this.root, name)); } catch (_) {}
      }
      try { fs.rmSync(stageDir, { recursive: true, force: true }); } catch (_) {}
      throw error;
    }
    let finished = false;
    return {
      count: moved.length,
      rollback: () => {
        if (finished) return;
        for (const name of moved) {
          const staged = path.join(stageDir, name);
          if (fs.existsSync(staged)) fs.renameSync(staged, path.join(this.root, name));
        }
        fs.rmSync(stageDir, { recursive: true, force: true });
        finished = true;
      },
      commit: () => {
        if (finished) return { ok: true, deletedFiles: moved.length };
        try {
          fs.rmSync(stageDir, { recursive: true, force: false });
          finished = true;
          try { const dirFd = fs.openSync(this.root, 'r'); fs.fsyncSync(dirFd); fs.closeSync(dirFd); } catch (_) {}
          return { ok: true, deletedFiles: moved.length };
        } catch (error) {
          // Un bloqueo antivirus no debe resucitar los históricos: quedan apartados
          // y cleanupPendingWipeStages los elimina al próximo inicio.
          return { ok: false, pending: true, code: error && error.code || 'ARCHIVE_CLEANUP_PENDING', deletedFiles: moved.length };
        }
      }
    };
  }
  inspectFiles(indexedNames) {
    const names = new Set(Array.isArray(indexedNames) ? indexedNames.map(String) : []);
    const files = this.listFiles().map(file => {
      try { const actual = this.readEncrypted(file.fileName); return { ...file, sha256: actual.sha256, indexed: names.has(file.fileName), valid: true }; }
      catch (e) { return { ...file, indexed: names.has(file.fileName), valid: false, error: e.code || 'ARCHIVE_READ_FAILED' }; }
    });
    const present = new Set(files.map(f => f.fileName));
    const missing = Array.from(names).filter(name => !present.has(name));
    return { files, missing };
  }
}
module.exports = { RecordArchiveStore, MAX_FILE_BYTES, FILE_RE, hashText, validateEnvelope };
