'use strict';

function normalizePOSId(value) {
  const raw = String(value || '').trim();
  return raw.startsWith('pos:') ? raw.slice(4) : raw;
}


function resolveDesktopSalesGate(posIdInput, policyState, canDesktopSell) {
  if (!policyState || policyState.ok !== true) return { ok: false, code: String(policyState && policyState.code || 'POS_POLICY_UNAVAILABLE') };
  const posId = normalizePOSId(posIdInput);
  const modes = policyState.modes instanceof Map ? policyState.modes : new Map();
  const mode = modes.has(posId) ? String(modes.get(posId)) : 'SIN_APP';
  if (!['SIN_APP', 'CON_APP'].includes(mode)) return { ok: false, code: 'POS_MODE_INVALID', mode };
  // Un modo CON_APP almacenado por un paquete anterior no debe quedar habilitado
  // silenciosamente: sin una app móvil real, tampoco se autoriza vender desde escritorio.
  if (mode === 'CON_APP') return { ok: false, code: 'MOBILE_APP_NOT_AVAILABLE', mode };
  // Compatibilidad legacy: si el dueño aún no activó el control estricto para todos
  // los POS, no inicializamos el puente ni migramos su clave durante una venta normal.
  if (policyState.strictLicensing !== true) return { ok: true, mode: 'SIN_APP', strictLicensing: false, compatibilityMode: true };
  if (typeof canDesktopSell !== 'function') return { ok: false, code: 'POS_POLICY_UNAVAILABLE' };
  try { return canDesktopSell(posId); }
  catch (_) { return { ok: false, code: 'POS_POLICY_UNAVAILABLE' }; }
}

function stableSerialize(value) {
  if (Array.isArray(value)) return '[' + value.map(stableSerialize).join(',') + ']';
  if (value && typeof value === 'object') {
    return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + stableSerialize(value[key])).join(',') + '}';
  }
  return JSON.stringify(value);
}

function immutableTransaction(record) {
  if (!record || typeof record !== 'object') return record;
  const clone = { ...record };
  // Estos campos describen el ciclo de conciliación y pueden cambiar sin alterar
  // el ticket comercial original. Todo lo demás se conserva de forma inmutable.
  delete clone.status;
  delete clone.closingId;
  delete clone.reconciledAt;
  return clone;
}

function sameImmutableTransaction(previous, next) {
  // Los backfills de productId solo se aplican mediante la migración verificada.
  // Un write ordinario del renderer no puede asignar identidades a tickets históricos.
  return stableSerialize(immutableTransaction(previous)) === stableSerialize(immutableTransaction(next));
}

function validateUniqueStoreKeys(entries) {
  if (!Array.isArray(entries)) return { ok: false, code: 'STORE_ENTRIES_INVALID' };
  const seen = new Set();
  for (const entry of entries) {
    if (!Array.isArray(entry) || entry.length < 2 || entry.length > 2) return { ok: false, code: 'STORE_ENTRY_INVALID' };
    const key = String(entry[0] == null ? '' : entry[0]);
    if (!key) return { ok: false, code: 'STORE_KEY_REQUIRED' };
    if (seen.has(key)) return { ok: false, code: 'STORE_KEY_DUPLICATE', key };
    seen.add(key);
  }
  return { ok: true };
}

function authorizeSalesLedgerDelta(currentLedger, nextLedger, canDesktopSell, options = {}) {
  const maxTransactions = Number.isInteger(options.maxTransactions) && options.maxTransactions > 0 ? options.maxTransactions : 10000;
  if (!Array.isArray(currentLedger) || !Array.isArray(nextLedger)) return { ok: false, code: 'SALES_LEDGER_INVALID' };
  if (typeof canDesktopSell !== 'function') return { ok: false, code: 'POS_POLICY_UNAVAILABLE' };

  const currentById = new Map();
  for (const record of currentLedger) {
    if (!record || typeof record !== 'object' || typeof record.id !== 'string' || !record.id.trim()) return { ok: false, code: 'SALES_HISTORY_CORRUPT' };
    if (currentById.has(record.id)) return { ok: false, code: 'SALES_HISTORY_CORRUPT', transactionId: record.id };
    currentById.set(record.id, record);
  }
  const nextById = new Map();
  const seenNextIds = new Set();
  const newTransactions = [];
  for (const record of nextLedger) {
    if (!record || typeof record !== 'object' || !['sale', 'return'].includes(String(record.kind || ''))) continue;
    const id = String(record.id || '').trim();
    if (!id) return { ok: false, code: 'SALES_TRANSACTION_ID_REQUIRED' };
    if (seenNextIds.has(id)) return { ok: false, code: 'SALES_TRANSACTION_ID_DUPLICATE', transactionId: id };
    seenNextIds.add(id);
    nextById.set(id, record);
    const previous = currentById.get(id);
    if (previous) {
      if (!sameImmutableTransaction(previous, record)) {
        return { ok: false, code: 'SALES_HISTORY_MUTATION_BLOCKED', transactionId: id };
      }
    } else newTransactions.push(record);
  }
  for (const [id, previous] of currentById) {
    if (['sale', 'return'].includes(String(previous.kind || '')) && !nextById.has(id)) {
      return { ok: false, code: 'SALES_HISTORY_DELETE_BLOCKED', transactionId: id };
    }
  }
  if (newTransactions.length > maxTransactions) return { ok: false, code: 'SALES_BATCH_TOO_LARGE' };

  for (const transaction of newTransactions) {
    const posId = normalizePOSId(transaction.posId);
    if (!posId || posId.length > 160 || !/^[A-Za-z0-9:_-]+$/.test(posId)) {
      return { ok: false, code: 'SALES_POS_ID_INVALID', transactionId: transaction.id };
    }
    let gate;
    try { gate = canDesktopSell(posId); }
    catch (_) { return { ok: false, code: 'POS_POLICY_UNAVAILABLE', transactionId: transaction.id }; }
    if (!gate || gate.ok !== true) {
      return { ok: false, code: String(gate && gate.code || 'POS_SALE_DENIED'), transactionId: transaction.id, posId };
    }
  }
  return { ok: true, authorizedTransactions: newTransactions.length };
}

module.exports = { normalizePOSId, resolveDesktopSalesGate, authorizeSalesLedgerDelta, validateUniqueStoreKeys, stableSerialize, sameImmutableTransaction };
