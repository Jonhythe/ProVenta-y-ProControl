'use strict';

const POS_ID_RE = /^[A-Za-z0-9:_-]{1,160}$/;
const PRODUCT_ID_RE = /^[A-Za-z0-9:_-]{1,160}$/;

function finiteNonNegative(value, field, productId) {
  if (value == null || value === '') return null;
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) {
    throw Object.assign(new Error(`INVALID_${field.toUpperCase()}_${productId}`), { code: `INVALID_${field.toUpperCase()}` });
  }
  return number;
}

function buildProVentaInventorySnapshot(input = {}) {
  const posId = String(input.posId || '').trim();
  const installationId = String(input.installationId || '').trim();
  if (!POS_ID_RE.test(posId)) throw Object.assign(new Error('INVALID_POS_ID'), { code: 'INVALID_POS_ID' });
  if (!/^pcinst_[a-f0-9]{32}$/.test(installationId)) throw Object.assign(new Error('INVALID_INSTALLATION_ID'), { code: 'INVALID_INSTALLATION_ID' });

  const posList = Array.isArray(input.pointsOfSale) ? input.pointsOfSale : [];
  const pos = posList.find(row => row && typeof row === 'object' && String(row.id || '') === posId);
  if (!pos) throw Object.assign(new Error('POS_NOT_FOUND'), { code: 'POS_NOT_FOUND' });
  if (!Array.isArray(pos.inventory)) throw Object.assign(new Error('POS_INVENTORY_INVALID'), { code: 'POS_INVENTORY_INVALID' });

  const seen = new Set();
  const inventory = pos.inventory.map((row, index) => {
    if (!row || typeof row !== 'object' || Array.isArray(row)) throw Object.assign(new Error(`INVALID_INVENTORY_ROW_${index + 1}`), { code: 'INVALID_INVENTORY_ROW' });
    const productId = String(row.productId || '').trim();
    const name = String(row.name || '').trim();
    const unit = String(row.unit || row.baseUnit || '').trim();
    if (!PRODUCT_ID_RE.test(productId)) throw Object.assign(new Error(`PRODUCT_ID_REQUIRED_${index + 1}`), { code: 'PRODUCT_ID_REQUIRED' });
    if (seen.has(productId)) throw Object.assign(new Error(`DUPLICATE_PRODUCT_ID_${productId}`), { code: 'DUPLICATE_PRODUCT_ID' });
    seen.add(productId);
    if (!name || name.length > 200 || !unit || unit.length > 40) throw Object.assign(new Error(`PRODUCT_DATA_INVALID_${productId}`), { code: 'PRODUCT_DATA_INVALID' });
    const qty = Number(row.qty);
    if (!Number.isFinite(qty) || qty < 0) throw Object.assign(new Error(`INVALID_STOCK_${productId}`), { code: 'INVALID_STOCK' });

    const result = { productId, name, unit, qty };
    const family = String(row.family || '').trim();
    if (family) result.family = family.slice(0, 100);
    for (const field of ['sale', 'saleTransf', 'saleUSD']) {
      const value = finiteNonNegative(row[field], field, productId);
      if (value !== null) result[field] = value;
    }
    const transferMode = String(row.saleTransfMode || '').trim().toLowerCase();
    if (transferMode === 'percentage' || transferMode === 'manual') result.saleTransfMode = transferMode;
    if (transferMode === 'percentage') {
      const percent = finiteNonNegative(row.saleTransfPercent, 'saleTransfPercent', productId);
      if (percent === null) throw Object.assign(new Error(`TRANSFER_PERCENT_REQUIRED_${productId}`), { code: 'TRANSFER_PERCENT_REQUIRED' });
      result.saleTransfPercent = percent;
    }
    const currency = String(row.saleCurrency || row.priceCurrency || '').trim().toUpperCase();
    if (currency) {
      if (!['USD', 'EUR', 'MLC', 'OTRA'].includes(currency)) throw Object.assign(new Error(`INVALID_SALE_CURRENCY_${productId}`), { code: 'INVALID_SALE_CURRENCY' });
      result.saleCurrency = currency;
    }
    const customCurrency = String(row.saleCustomCurrency || row.customPriceCurrency || '').trim();
    if (currency === 'OTRA') {
      if (!customCurrency || customCurrency.length > 40) throw Object.assign(new Error(`CUSTOM_CURRENCY_REQUIRED_${productId}`), { code: 'CUSTOM_CURRENCY_REQUIRED' });
      result.saleCustomCurrency = customCurrency;
    }
    return result;
  });

  const productIds = new Set(seen);
  const catalogRows = Array.isArray(input.productCatalog) ? input.productCatalog : [];
  const catalog = [];
  const catalogSeen = new Set();
  for (const row of catalogRows) {
    if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
    const productId = String(row.id || row.productId || '').trim();
    if (!productIds.has(productId) || catalogSeen.has(productId)) continue;
    catalogSeen.add(productId);
    const entry = { productId, name: String(row.name || '').trim() };
    if (!entry.name) continue;
    const unit = String(row.unit || '').trim();
    if (unit) entry.unit = unit;
    const family = String(row.family || '').trim();
    if (family) entry.family = family;
    if (Array.isArray(row.aliases)) entry.aliases = row.aliases.filter(value => typeof value === 'string' && value.trim()).map(value => value.trim().slice(0, 100)).slice(0, 50);
    catalog.push(entry);
  }

  const dollarRate = Number(input.dollarRate);
  const exchangeRates = {};
  const suppliedRates = input.exchangeRates && typeof input.exchangeRates === 'object' && !Array.isArray(input.exchangeRates)
    ? input.exchangeRates : {};
  for (const currency of ['USD', 'EUR', 'MLC']) {
    const value = Number(suppliedRates[currency + '_CUP']);
    if (Number.isFinite(value) && value > 0) exchangeRates[currency + '_CUP'] = value;
  }
  if (!Object.prototype.hasOwnProperty.call(exchangeRates, 'USD_CUP') &&
      Number.isFinite(dollarRate) && dollarRate > 0) {
    exchangeRates.USD_CUP = dollarRate;
  }
  const generatedAt = Number.isFinite(Number(input.now)) ? new Date(Number(input.now)).toISOString() : new Date().toISOString();
  return {
    schema: 'proventa.inventory-snapshot',
    schemaVersion: 1,
    installationId,
    posId,
    posName: String(pos.name || '').trim().slice(0, 160),
    generatedAt,
    exchangeRates,
    catalog,
    inventory
  };
}

module.exports = { buildProVentaInventorySnapshot };
