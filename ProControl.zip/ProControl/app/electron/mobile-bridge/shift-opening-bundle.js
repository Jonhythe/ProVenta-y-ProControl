'use strict';

const crypto = require('node:crypto');
const { stableJson, signedFields, sha256, DEVICE_DATA_PACKAGE_FORMAT } = require('./store');

const SHIFT_OPENING_BUNDLE_FORMAT = 'procontrol.shift-opening-bundle';
const SHIFT_OPENING_BUNDLE_VERSION = 1;
const MAX_SHIFT_OPENING_BUNDLE_BYTES = 96 * 1024;
const MAX_SHIFT_OPENING_ENVELOPE_BYTES = MAX_SHIFT_OPENING_BUNDLE_BYTES - 8 * 1024;

function fail(code) {
  throw Object.assign(new Error(code), { code });
}

function verifySignature(document, publicKey, signature) {
  try {
    return crypto.verify(null, signedFields(document), crypto.createPublicKey(publicKey),
      Buffer.from(signature, 'base64'));
  } catch (_) {
    return false;
  }
}

function verifyShiftOpeningBundle(bundle, expectedPublicKey) {
  if (!bundle || typeof bundle !== 'object' || Array.isArray(bundle) ||
      bundle.format !== SHIFT_OPENING_BUNDLE_FORMAT || bundle.version !== SHIFT_OPENING_BUNDLE_VERSION ||
      typeof bundle.bundleId !== 'string' || !/^[a-f0-9-]{36}$/i.test(bundle.bundleId) ||
      !bundle.permit || typeof bundle.permit !== 'object' ||
      !bundle.inventoryPackage || typeof bundle.inventoryPackage !== 'object' ||
      !bundle.signature || bundle.signature.algorithm !== 'Ed25519' ||
      typeof bundle.signature.value !== 'string') return { ok: false, code: 'SHIFT_OPENING_BUNDLE_FORMAT_INVALID' };

  const permit = bundle.permit;
  const inventory = bundle.inventoryPackage;
  const publicKey = String(expectedPublicKey || permit.desktopPublicKey || '');
  if (!publicKey || permit.desktopPublicKey !== publicKey ||
      permit.format !== 'procontrol.shift-permit' || Number(permit.version) !== 2 ||
      permit.installationId !== bundle.installationId || permit.authorizationId !== bundle.authorizationId ||
      permit.deviceId !== bundle.deviceId || permit.posId !== bundle.posId ||
      permit.permitId !== bundle.permitId || permit.authorizedPosId !== bundle.posId ||
      bundle.signerPublicKey !== publicKey ||
      inventory.format !== DEVICE_DATA_PACKAGE_FORMAT || Number(inventory.version) !== 1 ||
      inventory.type !== 'inventory_snapshot' || inventory.installationId !== bundle.installationId ||
      inventory.authorizationId !== bundle.authorizationId || inventory.deviceId !== bundle.deviceId ||
      inventory.posId !== bundle.posId || inventory.signerPublicKey !== publicKey ||
      !/^[A-Za-z0-9_-]{8,100}$/.test(String(inventory.packageId || '')) ||
      !/^[a-f0-9]{64}$/.test(String(inventory.payloadHash || '')) ||
      inventory.algorithm !== 'RSA-OAEP-256+A256GCM' ||
      !inventory.encryption || inventory.encryption.keyWrap !== 'RSA-OAEP-SHA256' ||
      inventory.encryption.contentCipher !== 'AES-256-GCM' ||
      typeof inventory.encryption.wrappedKey !== 'string' ||
      typeof inventory.encryption.iv !== 'string' ||
      typeof inventory.encryption.tag !== 'string' ||
      typeof inventory.ciphertext !== 'string' || !inventory.ciphertext ||
      bundle.inventoryPackageHash !== sha256(stableJson(inventory))) {
    return { ok: false, code: 'SHIFT_OPENING_BUNDLE_SCOPE_MISMATCH' };
  }

  if (!verifySignature(permit, publicKey, permit.signature)) {
    return { ok: false, code: 'SHIFT_OPENING_PERMIT_SIGNATURE_INVALID' };
  }
  if (!inventory.signature || inventory.signature.algorithm !== 'Ed25519' ||
      !verifySignature(inventory, publicKey, inventory.signature.value)) {
    return { ok: false, code: 'SHIFT_OPENING_INVENTORY_SIGNATURE_INVALID' };
  }
  if (!verifySignature(bundle, publicKey, bundle.signature.value)) {
    return { ok: false, code: 'SHIFT_OPENING_BUNDLE_SIGNATURE_INVALID' };
  }

  const bytes = Buffer.byteLength(stableJson(bundle), 'utf8');
  if (bytes > MAX_SHIFT_OPENING_BUNDLE_BYTES) return { ok: false, code: 'SHIFT_OPENING_BUNDLE_TOO_LARGE', bytes };
  return { ok: true, bundle, bytes };
}

function createShiftOpeningBundle(input = {}) {
  const permit = input.permit;
  const inventoryPackage = input.inventoryPackage;
  const publicKey = String(input.desktopPublicKey || '');
  if (!permit || !inventoryPackage || !input.desktopPrivateKey || !publicKey) fail('SHIFT_OPENING_BUNDLE_INPUT_INVALID');

  const bundle = {
    format: SHIFT_OPENING_BUNDLE_FORMAT,
    version: SHIFT_OPENING_BUNDLE_VERSION,
    bundleId: String(input.bundleId || crypto.randomUUID()),
    createdAt: new Date(Number.isFinite(Number(input.now)) ? Number(input.now) : Date.now()).toISOString(),
    installationId: String(permit.installationId || ''),
    authorizationId: String(permit.authorizationId || ''),
    deviceId: String(permit.deviceId || ''),
    posId: String(permit.posId || ''),
    permitId: String(permit.permitId || ''),
    permit,
    inventoryPackage,
    inventoryPackageHash: sha256(stableJson(inventoryPackage)),
    signerPublicKey: publicKey
  };
  const unsignedBytes = Buffer.from(stableJson(bundle), 'utf8');
  bundle.signature = {
    algorithm: 'Ed25519',
    value: crypto.sign(null, unsignedBytes, input.desktopPrivateKey).toString('base64')
  };
  const verified = verifyShiftOpeningBundle(bundle, publicKey);
  if (!verified.ok) fail(verified.code);
  return { bundle, json: stableJson(bundle), bytes: verified.bytes };
}

module.exports = {
  SHIFT_OPENING_BUNDLE_FORMAT,
  SHIFT_OPENING_BUNDLE_VERSION,
  MAX_SHIFT_OPENING_BUNDLE_BYTES,
  MAX_SHIFT_OPENING_ENVELOPE_BYTES,
  createShiftOpeningBundle,
  verifyShiftOpeningBundle
};
