'use strict';

// Fragmentación local de paquetes .pcpkg para USB. Los fragmentos son transporte,
// nunca operaciones comerciales independientes: el paquete firmado se verifica completo al reconstruirlo.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { MAX_PACKAGE_BYTES } = require('./store');

const MAX_TRANSFER_BYTES = MAX_PACKAGE_BYTES + 65536;
const DEFAULT_CHUNK_BYTES = 256 * 1024;
const MANIFEST_FORMAT = 'procontrol.fragment-manifest';

function digest(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function fail(code) { throw Object.assign(new Error(code), { code }); }
function safeLeaf(value) {
  return typeof value === 'string' && value.length > 0 && value.length <= 180 &&
    value !== '.' && value !== '..' && path.basename(value) === value && !/[\\/\x00-\x1f]/.test(value);
}
function atomicCreate(file, bytes) {
  const temp = `${file}.tmp-${process.pid}-${crypto.randomBytes(5).toString('hex')}`;
  let fd;
  try {
    // On Windows, fsync/FlushFileBuffers requires a writable handle. Opening the
    // completed temp file with 'r' can fail with EPERM even though the file was
    // created by this process. Create it exclusively with a read/write handle,
    // write and flush through that same descriptor, then publish atomically.
    fd = fs.openSync(temp, 'wx+', 0o600);
    fs.writeFileSync(fd, bytes);
    fs.fsyncSync(fd);
    fs.closeSync(fd);
    fd = undefined;
    // hard-link publication is atomic and refuses to overwrite an existing target.
    fs.linkSync(temp, file);
    fs.unlinkSync(temp);
  } catch (error) {
    if (fd !== undefined) { try { fs.closeSync(fd); } catch (_) {} }
    try { fs.unlinkSync(temp); } catch (_) {}
    throw error;
  }
}

function writeFragmentSet(contentsInput, manifestPathInput, options = {}) {
  const contents = Buffer.isBuffer(contentsInput) ? Buffer.from(contentsInput) : Buffer.from(String(contentsInput), 'utf8');
  const manifestPath = path.resolve(String(manifestPathInput || ''));
  if (!manifestPath.toLowerCase().endsWith('.pcmanifest')) fail('MANIFEST_EXTENSION_REQUIRED');
  if (!contents.length || contents.length > MAX_TRANSFER_BYTES) fail('TRANSFER_SIZE_OUT_OF_RANGE');
  const chunkSize = Number(options.chunkSize || DEFAULT_CHUNK_BYTES);
  if (!Number.isSafeInteger(chunkSize) || chunkSize < 16 * 1024 || chunkSize > DEFAULT_CHUNK_BYTES) fail('INVALID_FRAGMENT_SIZE');
  if (fs.existsSync(manifestPath)) fail('MANIFEST_ALREADY_EXISTS');
  const directory = path.dirname(manifestPath);
  fs.mkdirSync(directory, { recursive: true });
  const base = path.basename(manifestPath, '.pcmanifest').replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 100) || 'ProControl';
  const totalChunks = Math.ceil(contents.length / chunkSize);
  if (totalChunks < 1 || totalChunks > 512) fail('TOO_MANY_FRAGMENTS');
  const totalSha256 = digest(contents);
  const fragments = [];
  const created = [];
  try {
    for (let offset = 0, index = 1; offset < contents.length; offset += chunkSize, index++) {
      const data = contents.subarray(offset, Math.min(contents.length, offset + chunkSize));
      const name = `${base}-part-${String(index).padStart(4, '0')}-of-${String(totalChunks).padStart(4, '0')}.pcfrag`;
      if (!safeLeaf(name)) fail('INVALID_FRAGMENT_NAME');
      const target = path.join(directory, name);
      if (fs.existsSync(target)) fail('FRAGMENT_ALREADY_EXISTS');
      atomicCreate(target, data);
      created.push(target);
      fragments.push({ index, name, bytes: data.length, sha256: digest(data) });
    }
    const manifest = {
      format: MANIFEST_FORMAT,
      version: 1,
      bundleId: totalSha256.slice(0, 24),
      originalName: `${base}.pcpkg`,
      createdAt: new Date().toISOString(),
      totalBytes: contents.length,
      totalSha256,
      chunkSize,
      totalChunks,
      fragments
    };
    atomicCreate(manifestPath, Buffer.from(JSON.stringify(manifest, null, 2), 'utf8'));
    return { manifestPath, manifest, fragmentPaths: created };
  } catch (error) {
    for (const file of created) { try { fs.unlinkSync(file); } catch (_) {} }
    throw error;
  }
}

function readFragmentSet(manifestPathInput) {
  const manifestPath = path.resolve(String(manifestPathInput || ''));
  if (!manifestPath.toLowerCase().endsWith('.pcmanifest')) fail('MANIFEST_EXTENSION_REQUIRED');
  let manifest;
  try { manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8')); } catch (_) { fail('MANIFEST_INVALID_JSON'); }
  if (!manifest || manifest.format !== MANIFEST_FORMAT || manifest.version !== 1 ||
      !Number.isSafeInteger(manifest.totalBytes) || manifest.totalBytes < 1 || manifest.totalBytes > MAX_TRANSFER_BYTES ||
      !Number.isSafeInteger(manifest.chunkSize) || manifest.chunkSize < 1 || manifest.chunkSize > DEFAULT_CHUNK_BYTES ||
      !Number.isSafeInteger(manifest.totalChunks) || manifest.totalChunks < 1 || manifest.totalChunks > 512 ||
      !/^[a-f0-9]{64}$/.test(String(manifest.totalSha256 || '')) || manifest.fragments?.length !== manifest.totalChunks ||
      !safeLeaf(manifest.originalName)) fail('MANIFEST_INVALID_SCHEMA');
  const seenIndexes = new Set();
  const seenNames = new Set();
  const parts = [];
  let bytesTotal = 0;
  const directory = path.dirname(manifestPath);
  for (const entry of manifest.fragments) {
    if (!entry || !Number.isSafeInteger(entry.index) || entry.index < 1 || entry.index > manifest.totalChunks ||
        !safeLeaf(entry.name) || !Number.isSafeInteger(entry.bytes) || entry.bytes < 1 || entry.bytes > manifest.chunkSize ||
        !/^[a-f0-9]{64}$/.test(String(entry.sha256 || '')) || seenIndexes.has(entry.index) || seenNames.has(entry.name)) fail('FRAGMENT_MANIFEST_ENTRY_INVALID');
    seenIndexes.add(entry.index); seenNames.add(entry.name);
    const target = path.resolve(directory, entry.name);
    if (path.dirname(target) !== directory) fail('FRAGMENT_PATH_INVALID');
    let data;
    try { data = fs.readFileSync(target); } catch (_) { fail('FRAGMENT_MISSING'); }
    if (data.length !== entry.bytes || digest(data) !== entry.sha256) fail('FRAGMENT_HASH_MISMATCH');
    bytesTotal += data.length;
    parts[entry.index - 1] = data;
  }
  if (seenIndexes.size !== manifest.totalChunks || bytesTotal !== manifest.totalBytes) fail('FRAGMENT_SET_INCOMPLETE');
  const contents = Buffer.concat(parts);
  if (contents.length !== manifest.totalBytes || digest(contents) !== manifest.totalSha256 || manifest.bundleId !== manifest.totalSha256.slice(0, 24)) fail('TRANSFER_HASH_MISMATCH');
  return { contents, manifest };
}

module.exports = { MAX_TRANSFER_BYTES, DEFAULT_CHUNK_BYTES, MANIFEST_FORMAT, digest, writeFragmentSet, readFragmentSet };
