'use strict';

const fs = require('node:fs');
const path = require('node:path');

const CODE_PATTERN = /^PVLA2:[0-9ABCDEFGHJKMNPQRSTVWXYZ]+$/;

/**
 * Guarda una autorización PVLA2 como archivo independiente en el Escritorio.
 * Nunca sobrescribe una autorización anterior: usa un sufijo incremental.
 */
function writeProVentaAuthorizationFile(activationCode, desktopDirectory) {
  const code = String(activationCode || '').trim();
  if (code.length < 46 || code.length > 4006 || !CODE_PATTERN.test(code)) {
    throw Object.assign(new Error('INVALID_ACTIVATION_CODE'), { code: 'INVALID_ACTIVATION_CODE' });
  }
  const suppliedDirectory = String(desktopDirectory || '').trim();
  if (!suppliedDirectory || !path.isAbsolute(suppliedDirectory)) {
    throw Object.assign(new Error('DESKTOP_DIRECTORY_INVALID'), { code: 'DESKTOP_DIRECTORY_INVALID' });
  }
  const directory = path.resolve(suppliedDirectory);
  fs.mkdirSync(directory, { recursive: true });

  for (let index = 0; index < 1000; index += 1) {
    const suffix = index === 0 ? '' : ` (${index + 1})`;
    const fileName = `ProVenta Codigo${suffix}.pvla2`;
    const filePath = path.join(directory, fileName);
    let fd;
    try {
      fd = fs.openSync(filePath, 'wx', 0o600);
      fs.writeFileSync(fd, `${code}\n`, 'utf8');
      fs.fsyncSync(fd);
      fs.closeSync(fd);
      fd = undefined;
      return { ok: true, fileName, filePath, directory };
    } catch (error) {
      if (fd !== undefined) {
        try { fs.closeSync(fd); } catch (_) {}
      }
      if (error && error.code === 'EEXIST') continue;
      try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (_) {}
      throw error;
    }
  }
  throw Object.assign(new Error('PROVENTA_CODE_FILENAME_EXHAUSTED'), { code: 'PROVENTA_CODE_FILENAME_EXHAUSTED' });
}


/**
 * Exporta una copia explícita de una autorización PVLA2 al destino elegido
 * por el Dueño en el diálogo nativo de Guardar. Puede reemplazar el destino
 * solo después de que el diálogo de Windows haya confirmado la operación.
 */
function writeProVentaAuthorizationFileAtPath(activationCode, destinationPath) {
  const code = String(activationCode || '').trim();
  if (code.length < 46 || code.length > 4006 || !CODE_PATTERN.test(code)) {
    throw Object.assign(new Error('INVALID_ACTIVATION_CODE'), { code: 'INVALID_ACTIVATION_CODE' });
  }
  const suppliedPath = String(destinationPath || '').trim();
  if (!suppliedPath || !path.isAbsolute(suppliedPath)) {
    throw Object.assign(new Error('EXPORT_DESTINATION_INVALID'), { code: 'EXPORT_DESTINATION_INVALID' });
  }
  const resolved = path.resolve(suppliedPath);
  const finalPath = path.extname(resolved).toLowerCase() === '.pvla2' ? resolved : `${resolved}.pvla2`;
  const directory = path.dirname(finalPath);
  fs.mkdirSync(directory, { recursive: true });
  fs.writeFileSync(finalPath, `${code}\n`, { encoding: 'utf8', mode: 0o600, flag: 'w' });
  return { ok: true, fileName: path.basename(finalPath), filePath: finalPath, directory };
}

module.exports = { writeProVentaAuthorizationFile, writeProVentaAuthorizationFileAtPath };
