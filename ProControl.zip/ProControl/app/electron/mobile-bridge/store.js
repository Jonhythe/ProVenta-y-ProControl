'use strict';

// ProControl offline bridge. No TCP/HTTP listener and no automatic stock mutation.
// Incoming packages must be Ed25519-signed by a paired device key.
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { DatabaseSync } = require('node:sqlite');

const MAX_PACKAGE_BYTES = 2 * 1024 * 1024;
const CODE_TTL_MS = 5 * 60 * 1000;
const VALID_ROLES = new Set(['operator', 'supervisor', 'admin']);
const VALID_TYPES = new Set(['inventory_snapshot', 'sale_batch', 'goods_receipt', 'shift_open', 'shift_close', 'transfer', 'return', 'heartbeat']);
const PACKAGE_FORMAT = 'procontrol.offline-package';
const DEVICE_DATA_PACKAGE_FORMAT = 'procontrol.device-data-package';
const MAX_DEVICE_DATA_PACKAGE_BYTES = 16 * 1024 * 1024;
const DEVICE_DATA_PACKAGE_TTL_MS = 24 * 60 * 60 * 1000;
const PAIRING_FORMAT = 'procontrol.pairing-descriptor';

function stableJson(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return '[' + value.map(stableJson).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stableJson(value[k])).join(',') + '}';
  if (typeof value === 'number' && !Number.isFinite(value)) throw new Error('Los datos contienen un número no finito.');
  if (typeof value === 'undefined' || typeof value === 'function' || typeof value === 'symbol') throw new Error('Los datos contienen un valor no serializable.');
  return JSON.stringify(value);
}
function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function safeId(value) { return typeof value === 'string' && /^[A-Za-z0-9_-]{8,100}$/.test(value); }
function boundedString(value, max = 120) { return typeof value === 'string' && value.trim().length > 0 && value.trim().length <= max; }
function safePosRef(value) { return typeof value === 'string' && value.length > 0 && value.length <= 160 && /^[A-Za-z0-9:_-]+$/.test(value); }
function verifyPublicKey(publicKey) {
  if (typeof publicKey !== 'string' || publicKey.length > 4096) return null;
  try {
    const key = crypto.createPublicKey(publicKey);
    if (key.asymmetricKeyType !== 'ed25519') return null;
    return key.export({ type: 'spki', format: 'pem' }).toString();
  } catch (_) { return null; }
}
function verifyRsaEncryptionPublicKey(publicKey) {
  if (typeof publicKey !== 'string' || publicKey.length > 8192) return null;
  try {
    const key = crypto.createPublicKey(publicKey);
    const details = key.asymmetricKeyDetails || {};
    if (key.asymmetricKeyType !== 'rsa' || !Number.isInteger(details.modulusLength) || details.modulusLength < 3072 || details.modulusLength > 8192 || BigInt(details.publicExponent || 0) !== 65537n) return null;
    return key.export({ type: 'spki', format: 'pem' }).toString();
  } catch (_) { return null; }
}
function signedFields(document) {
  const copy = { ...document };
  delete copy.signature;
  return Buffer.from(stableJson(copy), 'utf8');
}

const PROVENTA_CODE_PREFIX = 'PVLA2:';
const PROVENTA_CODE_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
function encodeProVentaBase32(bytes) {
  let buffer = 0;
  let bits = 0;
  let output = '';
  for (const byte of bytes) {
    buffer = (buffer << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      bits -= 5;
      output += PROVENTA_CODE_ALPHABET[(buffer >>> bits) & 31];
    }
  }
  if (bits > 0) output += PROVENTA_CODE_ALPHABET[(buffer << (5 - bits)) & 31];
  return output;
}
function decodeProVentaBase32(value) {
  let buffer = 0;
  let bits = 0;
  const output = [];
  for (const char of value) {
    const n = PROVENTA_CODE_ALPHABET.indexOf(char);
    if (n < 0) throw new Error('PVLA2 contains an invalid base32 character.');
    buffer = (buffer << 5) | n;
    bits += 5;
    if (bits >= 8) {
      bits -= 8;
      output.push((buffer >>> bits) & 0xff);
    }
  }
  if (bits > 0 && (buffer & ((1 << bits) - 1)) !== 0) throw new Error('PVLA2 has a non-canonical final block.');
  return Buffer.from(output);
}
function encodeProVentaActivationCode(rawJson) {
  const input = Buffer.from(String(rawJson), 'utf8');
  if (!input.length || input.length > 64 * 1024) throw new Error('PROVENTA_AUTHORIZATION_TOO_LARGE');
  const compressed = zlib.deflateRawSync(input, { level: 9 });
  if (!compressed.length || compressed.length > 16 * 1024) throw new Error('PROVENTA_AUTHORIZATION_COMPRESSION_INVALID');
  const checksum = crypto.createHash('sha256').update(compressed).digest().subarray(0, 4);
  return PROVENTA_CODE_PREFIX + encodeProVentaBase32(Buffer.concat([compressed, checksum]));
}
function decodeProVentaActivationCode(code) {
  const compact = String(code || '').toUpperCase().replace(/[\s:-]/g, '');
  if (!compact.startsWith('PVLA2')) throw new Error('ACTIVATION_CODE_PREFIX_INVALID');
  const encoded = compact.slice(5);
  if (encoded.length < 40 || encoded.length > 4000) throw new Error('ACTIVATION_CODE_LENGTH_INVALID');
  const packed = decodeProVentaBase32(encoded);
  if (packed.length < 6) throw new Error('ACTIVATION_CODE_PAYLOAD_INVALID');
  const compressed = packed.subarray(0, -4);
  const supplied = packed.subarray(-4);
  const actual = crypto.createHash('sha256').update(compressed).digest().subarray(0, 4);
  if (!crypto.timingSafeEqual(supplied, actual)) throw new Error('ACTIVATION_CODE_CHECKSUM_INVALID');
  const rawJson = zlib.inflateRawSync(compressed, { maxOutputLength: 64 * 1024 }).toString('utf8');
  const descriptor = JSON.parse(rawJson);
  if (!descriptor || descriptor.format !== 'procontrol.device-authorization' || ![4, 5, 6].includes(Number(descriptor.version)) || descriptor.permanent !== true) {
    throw new Error('ACTIVATION_CODE_DESCRIPTOR_INVALID');
  }
  return { rawJson, descriptor };
}
function decodeProVentaDeviceIdentity(rawToken) {
  const token = String(rawToken || '').trim();
  if (Buffer.byteLength(token, 'utf8') < 16 || Buffer.byteLength(token, 'utf8') > 64 * 1024 || !token.startsWith('PVID1:')) {
    throw Object.assign(new Error('PVID1_IDENTITY_FORMAT_INVALID'), { code: 'PVID1_IDENTITY_FORMAT_INVALID' });
  }
  const encoded = token.slice('PVID1:'.length);
  if (!encoded || !/^[A-Za-z0-9_-]+$/.test(encoded)) {
    throw Object.assign(new Error('PVID1_IDENTITY_BASE64_INVALID'), { code: 'PVID1_IDENTITY_BASE64_INVALID' });
  }
  let doc;
  try {
    const bytes = Buffer.from(encoded, 'base64url');
    if (!bytes.length || bytes.length > 48 * 1024) throw new Error('identity size');
    doc = JSON.parse(bytes.toString('utf8'));
  } catch (_) {
    throw Object.assign(new Error('PVID1_IDENTITY_JSON_INVALID'), { code: 'PVID1_IDENTITY_JSON_INVALID' });
  }
  if (!doc || typeof doc !== 'object' || Array.isArray(doc) || doc.format !== 'proventa.device-identity' || doc.version !== 1) {
    throw Object.assign(new Error('PVID1_IDENTITY_UNSUPPORTED'), { code: 'PVID1_IDENTITY_UNSUPPORTED' });
  }
  if (!/^device_[a-f0-9]{32}$/.test(String(doc.deviceId || '')) || !boundedString(doc.label, 80) || !Number.isFinite(Date.parse(doc.createdAt))) {
    throw Object.assign(new Error('PVID1_IDENTITY_FIELDS_INVALID'), { code: 'PVID1_IDENTITY_FIELDS_INVALID' });
  }
  const signingPublicKeyPem = verifyPublicKey(doc.devicePublicKey);
  if (!signingPublicKeyPem) throw Object.assign(new Error('PVID1_SIGNING_KEY_INVALID'), { code: 'PVID1_SIGNING_KEY_INVALID' });
  const encryptionPublicKeyPem = verifyRsaEncryptionPublicKey(doc.deviceEncryptionPublicKey);
  if (!encryptionPublicKeyPem) throw Object.assign(new Error('PVID1_ENCRYPTION_KEY_INVALID'), { code: 'PVID1_ENCRYPTION_KEY_INVALID' });
  if (!doc.signature || doc.signature.algorithm !== 'Ed25519' || typeof doc.signature.value !== 'string' || doc.signature.value.length > 512 || !/^[A-Za-z0-9+/]+={0,2}$/.test(doc.signature.value)) {
    throw Object.assign(new Error('PVID1_SIGNATURE_MISSING'), { code: 'PVID1_SIGNATURE_MISSING' });
  }
  let signature;
  try { signature = Buffer.from(doc.signature.value, 'base64'); } catch (_) { signature = Buffer.alloc(0); }
  if (signature.length !== 64 || !crypto.verify(null, signedFields(doc), crypto.createPublicKey(signingPublicKeyPem), signature)) {
    throw Object.assign(new Error('PVID1_SIGNATURE_INVALID'), { code: 'PVID1_SIGNATURE_INVALID' });
  }
  const signingDer = crypto.createPublicKey(signingPublicKeyPem).export({ type: 'spki', format: 'der' });
  const signingPublicKeyHash = crypto.createHash('sha256').update(signingDer).digest('hex');
  return { deviceId: doc.deviceId, label: doc.label.trim(), createdAt: doc.createdAt,
    signingPublicKeyPem, encryptionPublicKeyPem, signingPublicKeyHash };
}
function validateEnvelopeShape(doc) {
  if (!doc || typeof doc !== 'object' || Array.isArray(doc)) return 'INVALID_ENVELOPE';
  if (doc.format !== PACKAGE_FORMAT || doc.version !== 1) return 'UNSUPPORTED_FORMAT';
  if (!safeId(doc.packageId) || !safeId(doc.deviceId) || !VALID_TYPES.has(doc.type)) return 'INVALID_ENVELOPE';
  if (!Number.isFinite(Date.parse(doc.createdAt))) return 'INVALID_TIMESTAMP';
  if (!doc.payload || typeof doc.payload !== 'object' || Array.isArray(doc.payload)) return 'INVALID_PAYLOAD';
  if (typeof doc.payloadHash !== 'string' || !/^[a-f0-9]{64}$/.test(doc.payloadHash)) return 'INVALID_HASH';
  if (!doc.signature || doc.signature.algorithm !== 'Ed25519' || typeof doc.signature.value !== 'string' || doc.signature.value.length > 512) return 'SIGNATURE_MISSING';
  return null;
}

function validatePackageProductIdentity(type, payload) {
  const validProductId = value => typeof value === 'string' && /^[A-Za-z0-9:_-]{1,160}$/.test(value.trim());
  const checkRows = rows => {
    if (!Array.isArray(rows)) return 'PACKAGE_PRODUCT_LIST_REQUIRED';
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (!row || typeof row !== 'object' || Array.isArray(row)) return 'PACKAGE_PRODUCT_ROW_INVALID';
      if (!validProductId(row.productId)) return 'PACKAGE_PRODUCT_ID_REQUIRED';
    }
    return null;
  };
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return 'INVALID_PAYLOAD';
  if (type === 'inventory_snapshot') return checkRows(payload.inventory ?? payload.items);
  if (type === 'goods_receipt') return checkRows(payload.items);
  if (type === 'sale_batch' || type === 'return') {
    if (!Array.isArray(payload.transactions)) return 'PACKAGE_TRANSACTIONS_REQUIRED';
    for (const transaction of payload.transactions) {
      if (!transaction || typeof transaction !== 'object' || Array.isArray(transaction)) return 'PACKAGE_TRANSACTION_INVALID';
      const error = checkRows(transaction.items ?? transaction.lines);
      if (error) return error;
    }
  }
  if (type === 'transfer') {
    const transfer = payload.transfer && typeof payload.transfer === 'object' && !Array.isArray(payload.transfer) ? payload.transfer : payload;
    if (Array.isArray(transfer.items)) return checkRows(transfer.items);
    if (Array.isArray(transfer.lines)) return checkRows(transfer.lines);
    if (!validProductId(transfer.productId)) return 'PACKAGE_PRODUCT_ID_REQUIRED';
  }
  return null;
}

class MobileBridgeStore {
  constructor(userDataDir, options = {}) {
    fs.mkdirSync(userDataDir, { recursive: true });
    this.userDataDir = userDataDir;
    this.desktopId = options && typeof options.desktopId === 'string' && safeId(options.desktopId) ? options.desktopId : 'desktop-local';
    this.safeStorage = options && options.safeStorage ? options.safeStorage : null;
    this.controlPlane = null;
    this.db = new DatabaseSync(path.join(userDataDir, 'mobile-bridge.db'));
    this.db.exec(`PRAGMA journal_mode=WAL;
      PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS bridge_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS pairing_codes (
        code_hash TEXT PRIMARY KEY, expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL,
        consumed_at INTEGER, created_by TEXT NOT NULL, assigned_role TEXT NOT NULL DEFAULT 'operator',
        assigned_pos_id TEXT, authorization_id TEXT, installation_id TEXT
      );
      CREATE TABLE IF NOT EXISTS devices (
        device_id TEXT PRIMARY KEY, label TEXT NOT NULL, role TEXT NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1, paired_at INTEGER NOT NULL,
        last_seen_at INTEGER, revoked_at INTEGER, public_key TEXT, pos_id TEXT,
        installation_id TEXT, employee_name TEXT, employee_data_json TEXT,
        authorization_id TEXT
      );
      CREATE TABLE IF NOT EXISTS device_authorizations (
        authorization_id TEXT PRIMARY KEY, installation_id TEXT NOT NULL,
        employee_name TEXT NOT NULL, employee_data_json TEXT NOT NULL DEFAULT '{}',
        code_hash TEXT NOT NULL UNIQUE, issued_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('pending','active','invalidated','superseded')),
        created_by TEXT NOT NULL, authorized_pos_id TEXT, device_id TEXT, replaces_authorization_id TEXT,
        replaced_by_authorization_id TEXT, paired_at INTEGER, revoked_at INTEGER,
        protocol_version INTEGER NOT NULL DEFAULT 0, device_signing_key_hash TEXT,
        renewal_sequence INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_device_authorizations_status ON device_authorizations(status, issued_at);
      CREATE INDEX IF NOT EXISTS idx_device_authorizations_worker ON device_authorizations(employee_name, issued_at);
      CREATE TABLE IF NOT EXISTS incoming_packages (
        package_id TEXT PRIMARY KEY, device_id TEXT NOT NULL, package_type TEXT NOT NULL,
        payload_json TEXT NOT NULL, payload_hash TEXT NOT NULL, status TEXT NOT NULL,
        received_at INTEGER NOT NULL, applied_at INTEGER, ack_json TEXT,
        FOREIGN KEY(device_id) REFERENCES devices(device_id)
      );
      CREATE TABLE IF NOT EXISTS bridge_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL,
        action TEXT NOT NULL, actor TEXT NOT NULL, detail_json TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_bridge_packages_status ON incoming_packages(status, received_at);
      CREATE TABLE IF NOT EXISTS reconciliation_jobs (
        package_id TEXT PRIMARY KEY, payload_hash TEXT NOT NULL, status TEXT NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0, first_received_at INTEGER NOT NULL,
        last_attempt_at INTEGER, last_error_code TEXT, last_error_at INTEGER,
        applied_at INTEGER, receipt_json TEXT, updated_at INTEGER NOT NULL,
        FOREIGN KEY(package_id) REFERENCES incoming_packages(package_id)
      );
      CREATE TABLE IF NOT EXISTS pos_licenses (
        pos_id TEXT PRIMARY KEY, pos_name TEXT NOT NULL, license_token TEXT NOT NULL,
        license_id TEXT NOT NULL, device_id TEXT NOT NULL, installed_at INTEGER NOT NULL,
        active INTEGER NOT NULL DEFAULT 1
      );
      CREATE TABLE IF NOT EXISTS pos_modes (
        pos_id TEXT PRIMARY KEY, mode TEXT NOT NULL DEFAULT 'SIN_APP',
        cut_at INTEGER, snapshot_json TEXT, changed_by TEXT, changed_at INTEGER, change_id TEXT
      );
      CREATE TABLE IF NOT EXISTS shift_permits (
        permit_id TEXT PRIMARY KEY, pos_id TEXT NOT NULL, device_id TEXT NOT NULL,
        employee TEXT NOT NULL, sequence INTEGER NOT NULL, starts_at INTEGER NOT NULL,
        ends_at INTEGER NOT NULL, permit_json TEXT NOT NULL, signature TEXT NOT NULL,
        status TEXT NOT NULL, created_by TEXT NOT NULL, created_at INTEGER NOT NULL,
        open_package_id TEXT, opened_at INTEGER, close_package_id TEXT,
        UNIQUE(pos_id, device_id, sequence)
      );
      CREATE TABLE IF NOT EXISTS pending_closures (
        closure_id TEXT PRIMARY KEY, package_id TEXT NOT NULL UNIQUE, permit_id TEXT NOT NULL,
        pos_id TEXT NOT NULL, device_id TEXT NOT NULL, shift_id TEXT NOT NULL,
        payload_json TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending_confirmation',
        submitted_at INTEGER NOT NULL, decided_at INTEGER, decided_by TEXT, decision_note TEXT
      );
      CREATE TABLE IF NOT EXISTS transfer_events (
        event_id TEXT PRIMARY KEY, transfer_id TEXT NOT NULL, status TEXT NOT NULL,
        at INTEGER NOT NULL, actor TEXT NOT NULL, payload_json TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_pending_closures_status ON pending_closures(status, submitted_at);
      CREATE INDEX IF NOT EXISTS idx_transfer_events_id ON transfer_events(transfer_id, at);
      CREATE TABLE IF NOT EXISTS outgoing_device_packages (
        package_id TEXT PRIMARY KEY, request_id TEXT NOT NULL UNIQUE, device_id TEXT NOT NULL,
        authorization_id TEXT NOT NULL, pos_id TEXT NOT NULL, package_type TEXT NOT NULL,
        payload_hash TEXT NOT NULL, envelope_json TEXT NOT NULL, created_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'issued'
      );
      CREATE INDEX IF NOT EXISTS idx_outgoing_device_packages_device ON outgoing_device_packages(device_id, created_at);`);
    this._ensureColumn('pairing_codes', 'assigned_role', "TEXT NOT NULL DEFAULT 'operator'");
    this._ensureColumn('pairing_codes', 'assigned_pos_id', 'TEXT');
    this._ensureColumn('pairing_codes', 'authorization_id', 'TEXT');
    this._ensureColumn('pairing_codes', 'installation_id', 'TEXT');
    this._ensureColumn('devices', 'public_key', 'TEXT');
    this._ensureColumn('devices', 'pos_id', 'TEXT');
    this._ensureColumn('devices', 'installation_id', 'TEXT');
    this._ensureColumn('devices', 'employee_name', 'TEXT');
    this._ensureColumn('devices', 'employee_data_json', 'TEXT');
    this._ensureColumn('devices', 'authorization_id', 'TEXT');
    this._ensureColumn('devices', 'encryption_public_key', 'TEXT');
    // Las autorizaciones anteriores no tenían POS fijo: permanecen sin alcance y no pueden operar hasta volver a autorizarse.
    this._ensureColumn('device_authorizations', 'authorized_pos_id', 'TEXT');
    this._ensureColumn('device_authorizations', 'protocol_version', 'INTEGER NOT NULL DEFAULT 0');
    this._ensureColumn('device_authorizations', 'device_signing_key_hash', 'TEXT');
    this._ensureColumn('device_authorizations', 'renewal_sequence', 'INTEGER NOT NULL DEFAULT 0');
    // Migración conservadora de autorizaciones PVID1 ya emitidas por esta app:
    // se reconocen solo cuando el móvil conserva claves, instalación y autorización coincidentes.
    const legacyV4Rows = this.db.prepare(`SELECT a.authorization_id AS authorizationId,d.public_key AS publicKey
      FROM device_authorizations a INNER JOIN devices d ON d.device_id=a.device_id
      WHERE a.protocol_version=0 AND a.status='active' AND d.enabled=1
        AND a.installation_id=d.installation_id AND a.authorization_id=d.authorization_id
        AND d.encryption_public_key IS NOT NULL AND d.encryption_public_key<>''
        AND d.public_key IS NOT NULL AND d.public_key<>''`).all();
    for (const row of legacyV4Rows) {
      try {
        const publicKey = verifyPublicKey(row.publicKey);
        if (!publicKey) continue;
        const der = crypto.createPublicKey(publicKey).export({ type: 'spki', format: 'der' });
        this.db.prepare(`UPDATE device_authorizations SET protocol_version=4,device_signing_key_hash=?
          WHERE authorization_id=? AND protocol_version=0 AND status='active'`).run(sha256(der), row.authorizationId);
      } catch (_) { /* Fail closed: no se eleva una autorización con clave no verificable. */ }
    }
    this.db.exec(`INSERT OR IGNORE INTO reconciliation_jobs(package_id,payload_hash,status,attempts,first_received_at,updated_at)
      SELECT package_id,payload_hash,status,0,received_at,received_at FROM incoming_packages`);
    this.insertAudit = this.db.prepare('INSERT INTO bridge_audit(at,action,actor,detail_json) VALUES(?,?,?,?)');
    // Si falla la inicialización de la identidad, liberar SQLite antes de propagar
    // el error. En Windows, una conexión abierta puede impedir borrar el directorio
    // temporal de las pruebas y, además, dejar recursos abiertos durante el arranque.
    try {
      this._ensureDesktopKeyPair();
      this.installationId = this._ensureInstallationIdentity();
    } catch (error) {
      try { this.db.close(); } catch (_) {}
      throw error;
    }
  }
  _ensureColumn(table, column, declaration) {
    const columns = this.db.prepare(`PRAGMA table_info(${table})`).all().map(row => row.name);
    if (!columns.includes(column)) this.db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${declaration}`);
  }
  _ensureInstallationIdentity() {
    if (!this.desktopPublicKey) throw new Error('BRIDGE_PUBLIC_KEY_UNAVAILABLE');
    const publicKey = crypto.createPublicKey(this.desktopPublicKey);
    const publicDer = publicKey.export({ type: 'spki', format: 'der' });
    const fingerprint = 'pcinst_' + sha256(publicDer).slice(0, 32);
    const stored = this.db.prepare('SELECT value FROM bridge_meta WHERE key=?').get('installation_id');
    if (stored && stored.value !== fingerprint) {
      throw Object.assign(new Error('La identidad criptográfica de esta instalación no coincide con la identidad persistida. Restaura las claves originales antes de continuar.'), { code: 'INSTALLATION_IDENTITY_MISMATCH' });
    }
    if (!stored) this.db.prepare('INSERT INTO bridge_meta(key,value) VALUES(?,?)').run('installation_id', fingerprint);
    return fingerprint;
  }
  _atomicWrite(file, bytes, mode = 0o600) {
    const temp = file + '.tmp-' + process.pid + '-' + Date.now();
    try {
      fs.writeFileSync(temp, bytes, { mode, flag: 'wx' });
      fs.renameSync(temp, file);
    } catch (error) {
      try { fs.unlinkSync(temp); } catch (_) {}
      throw error;
    }
  }
  _safeStorageReady() {
    return !!(this.safeStorage && typeof this.safeStorage.isEncryptionAvailable === 'function' && this.safeStorage.isEncryptionAvailable() && typeof this.safeStorage.encryptString === 'function' && typeof this.safeStorage.decryptString === 'function');
  }
  _encodeEmployeeData(value) {
    const json = JSON.stringify(value && typeof value === 'object' ? value : {});
    if (this._safeStorageReady()) return 'dpapi:v1:' + this.safeStorage.encryptString(json).toString('base64');
    // Node tests only: Electron runtime refuses to initialize the bridge without safeStorage.
    return 'test:v1:' + Buffer.from(json, 'utf8').toString('base64');
  }
  _decodeEmployeeData(value) {
    const raw = String(value || '');
    let json = raw;
    if (raw.startsWith('dpapi:v1:')) {
      if (!this._safeStorageReady()) throw new Error('EMPLOYEE_DATA_DECRYPTION_UNAVAILABLE');
      json = this.safeStorage.decryptString(Buffer.from(raw.slice('dpapi:v1:'.length), 'base64'));
    } else if (raw.startsWith('test:v1:')) {
      json = Buffer.from(raw.slice('test:v1:'.length), 'base64').toString('utf8');
    }
    const parsed = JSON.parse(json || '{}');
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  }
  _validateKeyPair(privateKeyInput, publicKeyInput) {
    let privateKey;
    try { privateKey = crypto.createPrivateKey(privateKeyInput); }
    catch (_) { throw new Error('La clave privada local del puente no es válida. Restaura una copia de seguridad antes de continuar.'); }
    const publicKey = verifyPublicKey(publicKeyInput);
    if (!publicKey) throw new Error('La clave pública local del puente no es válida.');
    const derived = crypto.createPublicKey(privateKey).export({ type: 'spki', format: 'pem' }).toString();
    if (derived.replace(/\r/g, '').trim() !== publicKey.replace(/\r/g, '').trim()) {
      throw new Error('Las claves del puente no forman un par válido. No se ha generado una identidad nueva para evitar romper los dispositivos emparejados.');
    }
    return { privateKey, publicKey };
  }
  _proveKeyPair(pair) {
    // Prueba de posesión real: se firma un reto aleatorio y se verifica con la clave pública.
    // No basta con que ambas claves se puedan parsear o derivar una de otra.
    const challenge = crypto.randomBytes(32);
    const signature = crypto.sign(null, challenge, pair.privateKey);
    if (!crypto.verify(null, challenge, crypto.createPublicKey(pair.publicKey), signature)) {
      throw new Error('La prueba de firma/verificación de la identidad del puente falló.');
    }
    return true;
  }
  _ensureDesktopKeyPair() {
    const plainPrivatePath = path.join(this.userDataDir, 'mobile-bridge-desktop-private.pem');
    const encryptedPrivatePath = path.join(this.userDataDir, 'mobile-bridge-desktop-private.dpapi');
    const encryptedBackupPath = encryptedPrivatePath + '.bak';
    const publicPath = path.join(this.userDataDir, 'mobile-bridge-desktop-public.pem');
    const isElectronRuntime = !!(process.versions && process.versions.electron);
    const secureAvailable = this._safeStorageReady();
    let publicExists = fs.existsSync(publicPath);
    let encryptedExists = fs.existsSync(encryptedPrivatePath);
    let backupExists = fs.existsSync(encryptedBackupPath);
    let plainExists = fs.existsSync(plainPrivatePath);

    if (isElectronRuntime && !secureAvailable) {
      throw Object.assign(new Error('WINDOWS_KEY_PROTECTION_UNAVAILABLE'), { code: 'WINDOWS_KEY_PROTECTION_UNAVAILABLE' });
    }

    const derivePublicFromPrivate = privateInput => {
      const privateKey = crypto.createPrivateKey(privateInput);
      return crypto.createPublicKey(privateKey).export({ type: 'spki', format: 'pem' }).toString();
    };
    const loadEncrypted = encryptedPath => {
      const privatePem = this.safeStorage.decryptString(fs.readFileSync(encryptedPath));
      const publicPem = publicExists ? fs.readFileSync(publicPath, 'utf8') : derivePublicFromPrivate(privatePem);
      const pair = this._validateKeyPair(privatePem, publicPem);
      this._proveKeyPair(pair);
      return { pair, bytes: fs.readFileSync(encryptedPath) };
    };
    const verifyEncryptedBackup = (bytes, expectedPair) => {
      this._atomicWrite(encryptedBackupPath, bytes, 0o600);
      const backupPrivate = this.safeStorage.decryptString(fs.readFileSync(encryptedBackupPath));
      const backupPublic = publicExists ? fs.readFileSync(publicPath, 'utf8') : expectedPair.publicKey;
      const backupPair = this._validateKeyPair(backupPrivate, backupPublic);
      this._proveKeyPair(backupPair);
      const expectedDer = expectedPair.privateKey.export({ type: 'pkcs8', format: 'der' });
      const backupDer = backupPair.privateKey.export({ type: 'pkcs8', format: 'der' });
      if (!expectedDer.equals(backupDer)) throw new Error('La copia cifrada de recuperación no contiene la misma identidad del puente.');
    };

    // Recuperación tras una interrupción: si el archivo principal falta pero existe
    // la copia DPAPI, se valida antes de restaurar. No se genera una identidad nueva.
    if (!encryptedExists && backupExists) {
      if (!secureAvailable) throw Object.assign(new Error('WINDOWS_KEY_PROTECTION_UNAVAILABLE'), { code: 'WINDOWS_KEY_PROTECTION_UNAVAILABLE' });
      try {
        const recovered = loadEncrypted(encryptedBackupPath);
        if (!publicExists) {
          this._atomicWrite(publicPath, recovered.pair.publicKey, 0o644);
          publicExists = true;
        }
        this._atomicWrite(encryptedPrivatePath, recovered.bytes, 0o600);
        encryptedExists = true;
      } catch (_) {
        // Si también existe el PEM original, se mantiene para una recuperación manual; nunca se borra.
        if (!plainExists) throw new Error('No se pudo recuperar la identidad cifrada del puente. Restaura un respaldo válido antes de continuar.');
      }
    }

    if (encryptedExists) {
      if (!secureAvailable) throw Object.assign(new Error('WINDOWS_KEY_PROTECTION_UNAVAILABLE'), { code: 'WINDOWS_KEY_PROTECTION_UNAVAILABLE' });
      let loaded = null;
      let primaryError = null;
      try { loaded = loadEncrypted(encryptedPrivatePath); }
      catch (error) { primaryError = error; }
      if (!loaded && backupExists) {
        try {
          loaded = loadEncrypted(encryptedBackupPath);
          this._atomicWrite(encryptedPrivatePath, loaded.bytes, 0o600);
        } catch (_) { loaded = null; }
      }
      // Última vía conservadora: si el archivo cifrado está dañado pero aún existe el PEM
      // original, reconstruir el mismo cifrado desde esa clave y validarlo antes de eliminarlo.
      if (!loaded && plainExists) {
        try {
          const plainPem = fs.readFileSync(plainPrivatePath, 'utf8');
          const expectedPublic = publicExists ? fs.readFileSync(publicPath, 'utf8') : derivePublicFromPrivate(plainPem);
          const plainPair = this._validateKeyPair(plainPem, expectedPublic);
          this._proveKeyPair(plainPair);
          const encrypted = this.safeStorage.encryptString(plainPair.privateKey.export({ type: 'pkcs8', format: 'pem' }).toString());
          this._atomicWrite(encryptedPrivatePath, encrypted, 0o600);
          const roundTrip = this.safeStorage.decryptString(fs.readFileSync(encryptedPrivatePath));
          const checked = this._validateKeyPair(roundTrip, plainPair.publicKey);
          this._proveKeyPair(checked);
          if (!checked.privateKey.export({ type: 'pkcs8', format: 'der' }).equals(plainPair.privateKey.export({ type: 'pkcs8', format: 'der' }))) {
            throw new Error('La recuperación desde el PEM original no conservó la identidad.');
          }
          if (!publicExists) {
            this._atomicWrite(publicPath, plainPair.publicKey, 0o644);
            publicExists = true;
          }
          loaded = { pair: checked, bytes: fs.readFileSync(encryptedPrivatePath) };
          verifyEncryptedBackup(loaded.bytes, checked);
        } catch (_) { loaded = null; }
      }
      if (!loaded) {
        throw new Error('No se pudo validar la clave privada cifrada del puente. No se ha generado otra identidad. ' + (primaryError && primaryError.message ? primaryError.message : 'Restaura una copia de seguridad.'));
      }
      const pair = loaded.pair;
      if (!publicExists) {
        this._atomicWrite(publicPath, pair.publicKey, 0o644);
        publicExists = true;
      }
      // Asegura una copia de recuperación DPAPI verificada antes de retirar el PEM antiguo.
      verifyEncryptedBackup(loaded.bytes, pair);
      if (plainExists) {
        const plainPair = this._validateKeyPair(fs.readFileSync(plainPrivatePath, 'utf8'), fs.readFileSync(publicPath, 'utf8'));
        this._proveKeyPair(plainPair);
        const encryptedDer = pair.privateKey.export({ type: 'pkcs8', format: 'der' });
        const plainDer = plainPair.privateKey.export({ type: 'pkcs8', format: 'der' });
        if (!encryptedDer.equals(plainDer)) throw new Error('Las claves cifrada y antigua no coinciden; se conserva la copia antigua y se bloquea el puente.');
        // Borrado solo después de validación de par, firma/verificación y backup recuperable.
        fs.unlinkSync(plainPrivatePath);
      }
      this.desktopPrivateKey = pair.privateKey;
      this.desktopPublicKey = pair.publicKey;
      return;
    }

    if (plainExists && publicExists) {
      const originalPair = this._validateKeyPair(fs.readFileSync(plainPrivatePath, 'utf8'), fs.readFileSync(publicPath, 'utf8'));
      this._proveKeyPair(originalPair);
      if (secureAvailable) {
        const encrypted = this.safeStorage.encryptString(originalPair.privateKey.export({ type: 'pkcs8', format: 'pem' }).toString());
        try {
          this._atomicWrite(encryptedPrivatePath, encrypted, 0o600);
          const roundTrip = this.safeStorage.decryptString(fs.readFileSync(encryptedPrivatePath));
          const checked = this._validateKeyPair(roundTrip, originalPair.publicKey);
          this._proveKeyPair(checked);
          const expected = originalPair.privateKey.export({ type: 'pkcs8', format: 'der' });
          const actual = checked.privateKey.export({ type: 'pkcs8', format: 'der' });
          if (!expected.equals(actual)) throw new Error('La verificación posterior al cifrado de la clave del puente falló.');
          verifyEncryptedBackup(fs.readFileSync(encryptedPrivatePath), checked);
          // No borrar el único PEM recuperable hasta completar todas las verificaciones anteriores.
          fs.unlinkSync(plainPrivatePath);
          this.desktopPrivateKey = checked.privateKey;
          this.desktopPublicKey = checked.publicKey;
        } catch (error) {
          // El PEM original permanece cuando una verificación falla. Limpiar artefactos nuevos
          // evita que un intento posterior confunda un archivo parcial con una migración final.
          try { fs.unlinkSync(encryptedPrivatePath); } catch (_) {}
          try { fs.unlinkSync(encryptedBackupPath); } catch (_) {}
          throw error;
        }
      } else {
        // Compatibilidad exclusiva para Node en pruebas; Electron exige safeStorage.
        this.desktopPrivateKey = originalPair.privateKey;
        this.desktopPublicKey = originalPair.publicKey;
      }
      return;
    }

    if (plainExists !== publicExists) throw new Error('Identidad del puente incompleta: falta la clave privada o pública. Restaura una copia de seguridad antes de continuar.');

    const pair = crypto.generateKeyPairSync('ed25519');
    const privPem = pair.privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
    const pubPem = pair.publicKey.export({ type: 'spki', format: 'pem' }).toString();
    const verifiedPair = this._validateKeyPair(privPem, pubPem);
    this._proveKeyPair(verifiedPair);
    if (secureAvailable) {
      const encrypted = this.safeStorage.encryptString(privPem);
      try {
        this._atomicWrite(encryptedPrivatePath, encrypted, 0o600);
        const roundTrip = this.safeStorage.decryptString(fs.readFileSync(encryptedPrivatePath));
        const checked = this._validateKeyPair(roundTrip, pubPem);
        this._proveKeyPair(checked);
        verifyEncryptedBackup(fs.readFileSync(encryptedPrivatePath), checked);
        this._atomicWrite(publicPath, pubPem, 0o644);
        this.desktopPrivateKey = checked.privateKey;
        this.desktopPublicKey = pubPem;
      } catch (error) {
        try { fs.unlinkSync(encryptedPrivatePath); } catch (_) {}
        try { fs.unlinkSync(encryptedBackupPath); } catch (_) {}
        try { fs.unlinkSync(publicPath); } catch (_) {}
        throw error;
      }
    } else if (!isElectronRuntime) {
      this._atomicWrite(plainPrivatePath, privPem, 0o600);
      this._atomicWrite(publicPath, pubPem, 0o644);
      this.desktopPrivateKey = verifiedPair.privateKey;
      this.desktopPublicKey = pubPem;
    } else {
      throw Object.assign(new Error('WINDOWS_KEY_PROTECTION_UNAVAILABLE'), { code: 'WINDOWS_KEY_PROTECTION_UNAVAILABLE' });
    }
  }
  audit(action, actor, detail) { this.insertAudit.run(Date.now(), action, String(actor || 'desktop-local'), JSON.stringify(detail || {})); }
  getDesktopPublicKey() { return this.desktopPublicKey; }
  getInstallationId() { return this.installationId; }
  // Stable human-readable identity shared by the PC authorization and signed shift permits.
  // It is derived only from the persistent installation identifier, so reinstalling the app
  // does not silently create a different visible code while the bridge identity is retained.
  getInstallationCode() {
    const prefix = 'pcinst_';
    const hex = String(this.installationId || '').startsWith(prefix)
      ? String(this.installationId).slice(prefix.length, prefix.length + 16).toUpperCase()
      : '';
    if (!/^[A-F0-9]{16}$/.test(hex)) throw Object.assign(new Error('INSTALLATION_IDENTITY_UNAVAILABLE'), { code: 'INSTALLATION_IDENTITY_UNAVAILABLE' });
    return `PC-${hex.slice(0,4)}-${hex.slice(4,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}`;
  }
  // Cada instalación tiene un perfil estable de seis cifras derivado de su
  // identidad Ed25519. El perfil es una marca visual, NO una credencial ni una
  // frontera criptográfica: la autorización sigue dependiendo de Ed25519,
  // installationId, deviceId y authorizedPosId.
  getInstallationCodePattern() {
    if (!this.installationId) throw new Error('INSTALLATION_IDENTITY_UNAVAILABLE');
    const digest = crypto.createHash('sha256')
      .update('procontrol-proventa-code-pattern-v1\0', 'utf8')
      .update(this.installationId, 'utf8')
      .digest();
    const mode = (digest[0] & 1) === 0 ? 'starts_with' : 'odd_count';
    const firstDigit = mode === 'starts_with' ? digest[1] % 10 : null;
    const oddDigitCount = mode === 'odd_count' ? 1 + (digest[1] % 5) : null;
    const patternId = 'P1-' + digest.subarray(2, 10).toString('hex');
    const rule = mode === 'starts_with'
      ? `Todos los códigos de este negocio comienzan por ${firstDigit}.`
      : `Todos los códigos de este negocio contienen exactamente ${oddDigitCount} ${oddDigitCount === 1 ? 'cifra impar' : 'cifras impares'}.`;
    return {
      version: 1,
      patternId,
      mode,
      firstDigit,
      oddDigitCount,
      checksumAlgorithm: 'sha256-installation-scoped-v1',
      description: `${rule} El último dígito es una comprobación propia de esta instalación ProControl.`
    };
  }
  _installationCodeCheckDigit(firstFiveDigits) {
    const digest = crypto.createHash('sha256')
      .update('procontrol-proventa-code-check-v1\0', 'utf8')
      .update(this.installationId, 'utf8')
      .update('\0', 'utf8')
      .update(firstFiveDigits, 'utf8')
      .digest();
    return String(digest[0] % 10);
  }
  _codeMatchesInstallationPattern(code, pattern = this.getInstallationCodePattern()) {
    if (typeof code !== 'string' || !/^\d{6}$/.test(code)) return false;
    const firstFiveDigits = code.slice(0, 5);
    if (code[5] !== this._installationCodeCheckDigit(firstFiveDigits)) return false;
    if (pattern.mode === 'starts_with') return Number(code[0]) === pattern.firstDigit;
    if (pattern.mode === 'odd_count') {
      const oddDigitCount = [...code].filter(digit => Number(digit) % 2 === 1).length;
      return oddDigitCount === pattern.oddDigitCount;
    }
    return false;
  }
  _generateInstallationScopedCode() {
    const codePattern = this.getInstallationCodePattern();
    const used = this.db.prepare(`SELECT 1 AS used FROM device_authorizations WHERE code_hash=?
      UNION ALL SELECT 1 AS used FROM pairing_codes WHERE code_hash=? LIMIT 1`);
    // La primera parte del código es aleatoria. El sexto dígito comprueba la
    // identidad concreta de esta instalación y la regla visible varía por PC.
    // El espacio resultante conserva miles de opciones por instalación.
    for (let attempt = 0; attempt < 100000; attempt++) {
      const firstFiveDigits = String(crypto.randomInt(0, 100000)).padStart(5, '0');
      const code = firstFiveDigits + this._installationCodeCheckDigit(firstFiveDigits);
      if (!this._codeMatchesInstallationPattern(code, codePattern)) continue;
      const codeHash = sha256(code);
      if (used.get(codeHash, codeHash)) continue;
      return { code, codeHash, codePattern };
    }
    throw Object.assign(new Error('No fue posible generar un código nuevo para el patrón de esta instalación. Reintenta; no se modificó la identidad del negocio.'), { code: 'INSTALLATION_CODE_PATTERN_EXHAUSTED' });
  }
  createDeviceAuthorizationFromIdentity(rawIdentityToken, input, actor = 'desktop-local') {
    const data = input && typeof input === 'object' ? input : {};
    const employeeName = String(data.employeeName || '').trim();
    const employeeData = String(data.employeeData || '').trim();
    const phoneNumber = String(data.phoneNumber || '').trim();
    const phoneDigits = phoneNumber.replace(/\D/g, '');
    // New authorizations belong to the complete ProControl installation. POS scope
    // is assigned later by each signed shift permit. Legacy v4 remains POS-bound.
    const installationWide = data.installationWide === true || data.authorizationScope === 'installation';
    const posInput = installationWide ? '' : String(data.posId || '').trim();
    const authorizedPosId = installationWide ? null : (posInput.startsWith('pos:') ? posInput.slice(4) : posInput);
    const replacesAuthorizationId = data.replacesAuthorizationId == null ? null : String(data.replacesAuthorizationId);
    const invalidPhone = phoneNumber.length > 32 || !/^\+?[0-9][0-9 ()-]{4,30}$/.test(phoneNumber) ||
      phoneDigits.length < 6 || phoneDigits.length > 15;
    if (employeeName.length < 2 || employeeName.length > 100 || employeeData.length > 1000 ||
        (installationWide && invalidPhone)) {
      throw Object.assign(new Error('INVALID_EMPLOYEE_DATA'), { code: 'INVALID_EMPLOYEE_DATA' });
    }
    if (!installationWide && (!safePosRef(posInput) || !safePosRef(authorizedPosId))) {
      throw Object.assign(new Error('POS_SCOPE_REQUIRED'), { code: 'POS_SCOPE_REQUIRED' });
    }
    // Las autorizaciones de instalación exigen motivo auditable al sustituir; V4 conserva su comportamiento.
    const replacementReason = String(data.replacementReason || '').trim();
    if (replacesAuthorizationId && installationWide && (replacementReason.length < 3 || replacementReason.length > 240)) {
      throw Object.assign(new Error('REPLACEMENT_REASON_REQUIRED'), { code: 'REPLACEMENT_REASON_REQUIRED' });
    }
    const identity = decodeProVentaDeviceIdentity(rawIdentityToken);
    let replaced = null;
    if (replacesAuthorizationId) {
      replaced = this.db.prepare(`SELECT authorization_id AS authorizationId,employee_name AS employeeName,status,
        installation_id AS installationId,authorized_pos_id AS authorizedPosId,device_id AS deviceId
        FROM device_authorizations WHERE authorization_id=?`).get(replacesAuthorizationId);
      if (!replaced || replaced.status !== 'invalidated' || replaced.installationId !== this.installationId) {
        throw Object.assign(new Error('REPLACEMENT_AUTHORIZATION_NOT_INVALIDATED'), { code: 'REPLACEMENT_AUTHORIZATION_NOT_INVALIDATED' });
      }
      if (replaced.employeeName.toLocaleLowerCase() !== employeeName.toLocaleLowerCase()) {
        throw Object.assign(new Error('REPLACEMENT_EMPLOYEE_MISMATCH'), { code: 'REPLACEMENT_EMPLOYEE_MISMATCH' });
      }
      if (!installationWide && replaced.authorizedPosId && replaced.authorizedPosId !== authorizedPosId) {
        throw Object.assign(new Error('REPLACEMENT_POS_SCOPE_MISMATCH'), { code: 'REPLACEMENT_POS_SCOPE_MISMATCH' });
      }
    }

    const existingDevice = this.db.prepare(`SELECT device_id AS deviceId,enabled,authorization_id AS authorizationId
      FROM devices WHERE device_id=?`).get(identity.deviceId);
    if (existingDevice) {
      const isExpectedReplacement = !!replaced && existingDevice.enabled === 0 &&
        existingDevice.authorizationId === replacesAuthorizationId && replaced.deviceId === identity.deviceId;
      if (!isExpectedReplacement) {
        throw Object.assign(new Error('DEVICE_ALREADY_REGISTERED'), { code: 'DEVICE_ALREADY_REGISTERED' });
      }
    }

    const now = Date.now();
    const authorizationId = 'auth_' + crypto.randomUUID();
    // Keep the internal numeric field for schema compatibility; the worker never enters it.
    const internalBindingCode = String(crypto.randomInt(0, 100000000)).padStart(8, '0');
    const expiresAt = now + CODE_TTL_MS;
    const protocolVersion = installationWide ? 6 : 4;
    const codeDocument = {
      format: 'procontrol.device-authorization',
      version: protocolVersion,
      permanent: true,
      installationId: this.installationId,
      installationCode: this.getInstallationCode(),
      authorizationId,
      deviceId: identity.deviceId,
      deviceSigningPublicKeyHash: identity.signingPublicKeyHash,
      ...(installationWide ? { authorizationScope: 'installation' } : {
        authorizedPosId,
        ...(String(data.authorizedPosName || '').trim() ? { authorizedPosName: String(data.authorizedPosName).trim().slice(0, 100) } : {})
      }),
      employeeName,
      code: internalBindingCode,
      expiresAt,
      ...(installationWide ? { renewalSequence: 1 } : {}),
      createdAt: new Date(now).toISOString(),
      desktopPublicKey: this.desktopPublicKey
    };
    codeDocument.signature = {
      algorithm: 'Ed25519',
      value: crypto.sign(null, signedFields(codeDocument), this.desktopPrivateKey).toString('base64')
    };
    const activationCode = encodeProVentaActivationCode(JSON.stringify(codeDocument));
    const codeHash = sha256(activationCode);
    const safeEmployeeData = this._encodeEmployeeData({ note: employeeData, phoneNumber });
    const initialStatus = installationWide ? 'pending' : 'active';
    const deviceEnabled = installationWide ? 0 : 1;

    this.db.exec('BEGIN IMMEDIATE');
    try {
      const latestDevice = this.db.prepare(`SELECT enabled,authorization_id AS authorizationId FROM devices WHERE device_id=?`).get(identity.deviceId);
      if (latestDevice && (!replaced || latestDevice.enabled !== 0 || latestDevice.authorizationId !== replacesAuthorizationId)) {
        throw Object.assign(new Error('DEVICE_ALREADY_REGISTERED'), { code: 'DEVICE_ALREADY_REGISTERED' });
      }
      if (replacesAuthorizationId) {
        const latestReplacement = this.db.prepare(`SELECT status,installation_id AS installationId,authorized_pos_id AS authorizedPosId
          FROM device_authorizations WHERE authorization_id=?`).get(replacesAuthorizationId);
        if (!latestReplacement || latestReplacement.status !== 'invalidated' || latestReplacement.installationId !== this.installationId ||
            (!installationWide && latestReplacement.authorizedPosId && latestReplacement.authorizedPosId !== authorizedPosId)) {
          throw Object.assign(new Error('REPLACEMENT_AUTHORIZATION_CHANGED'), { code: 'REPLACEMENT_AUTHORIZATION_CHANGED' });
        }
      }
      this.db.prepare(`INSERT INTO device_authorizations(authorization_id,installation_id,employee_name,employee_data_json,
        code_hash,issued_at,expires_at,status,created_by,authorized_pos_id,device_id,replaces_authorization_id,paired_at,
        protocol_version,device_signing_key_hash,renewal_sequence,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
        .run(authorizationId, this.installationId, employeeName, safeEmployeeData, codeHash, now, expiresAt,
          initialStatus, actor, authorizedPosId, identity.deviceId, replacesAuthorizationId,
          installationWide ? null : now, protocolVersion, identity.signingPublicKeyHash,
          installationWide ? 1 : 0, now);

      if (latestDevice) {
        const updated = this.db.prepare(`UPDATE devices SET label=?,role='operator',enabled=?,paired_at=?,last_seen_at=?,revoked_at=NULL,
          public_key=?,encryption_public_key=?,pos_id=?,installation_id=?,employee_name=?,employee_data_json=?,authorization_id=?
          WHERE device_id=? AND enabled=0 AND authorization_id=?`)
          .run(identity.label, deviceEnabled, now, now, identity.signingPublicKeyPem, identity.encryptionPublicKeyPem,
            authorizedPosId, this.installationId, employeeName, safeEmployeeData, authorizationId,
            identity.deviceId, replacesAuthorizationId);
        if (updated.changes !== 1) throw Object.assign(new Error('DEVICE_REPLACEMENT_CONFLICT'), { code: 'DEVICE_REPLACEMENT_CONFLICT' });
      } else {
        this.db.prepare(`INSERT INTO devices(device_id,label,role,enabled,paired_at,last_seen_at,revoked_at,public_key,pos_id,
          installation_id,employee_name,employee_data_json,authorization_id,encryption_public_key)
          VALUES(?,?,'operator',?,?,?,NULL,?,?,?,?,?,?,?)`)
          .run(identity.deviceId, identity.label, deviceEnabled, now, now, identity.signingPublicKeyPem, authorizedPosId,
            this.installationId, employeeName, safeEmployeeData, authorizationId, identity.encryptionPublicKeyPem);
      }

      if (replacesAuthorizationId) {
        const previous = this.db.prepare(`SELECT device_id AS deviceId FROM device_authorizations WHERE authorization_id=? AND installation_id=? AND status='invalidated'`)
          .get(replacesAuthorizationId, this.installationId);
        if (!previous) throw Object.assign(new Error('REPLACEMENT_AUTHORIZATION_CHANGED'), { code: 'REPLACEMENT_AUTHORIZATION_CHANGED' });
        const changed = this.db.prepare(`UPDATE device_authorizations SET status='superseded',replaced_by_authorization_id=?,updated_at=?
          WHERE authorization_id=? AND installation_id=? AND status='invalidated'`)
          .run(authorizationId, now, replacesAuthorizationId, this.installationId);
        if (changed.changes !== 1) throw Object.assign(new Error('REPLACEMENT_AUTHORIZATION_CHANGED'), { code: 'REPLACEMENT_AUTHORIZATION_CHANGED' });
        this.audit('device_authorization_superseded', actor, {
          authorizationId: replacesAuthorizationId, replacedByAuthorizationId: authorizationId,
          deviceId: previous.deviceId || null, replacementDeviceId: identity.deviceId, reason: String(data.replacementReason || '').trim().slice(0, 240)
        });
        if (previous.deviceId && previous.deviceId !== identity.deviceId) {
          this.db.prepare('UPDATE devices SET enabled=0,revoked_at=? WHERE device_id=?').run(now, previous.deviceId);
        }
      }
      this.audit('device_authorized_from_pvid', actor, {
        authorizationId, installationId: this.installationId, deviceId: identity.deviceId,
        authorizationScope: installationWide ? 'installation' : 'pos', authorizedPosId,
        employeeName, phoneNumber, replacesAuthorizationId, activationCodeHash: codeHash,
        status: initialStatus, renewalSequence: installationWide ? 1 : 0
      });
      this.db.exec('COMMIT');
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      throw error;
    }
    return {
      ok: true,
      authorizationId,
      activationCode,
      employeeName,
      deviceId: identity.deviceId,
      deviceLabel: identity.label,
      installationId: this.installationId,
      authorizedPosId,
      authorizationScope: installationWide ? 'installation' : 'pos',
      protocolVersion,
      issuedAt: now,
      phoneNumber,
      status: initialStatus,
      renewalSequence: installationWide ? 1 : 0,
      qrExpiresAt: expiresAt,
      permanent: true,
      replacesAuthorizationId
    };
  }

  issueDeviceAuthorizationRenewal(authorizationIdInput, actor = 'desktop-local') {
    const authorizationId = String(authorizationIdInput || '');
    if (!/^auth_[A-Za-z0-9-]{20,60}$/.test(authorizationId)) {
      throw Object.assign(new Error('INVALID_AUTHORIZATION_ID'), { code: 'INVALID_AUTHORIZATION_ID' });
    }
    const row = this.db.prepare(`SELECT a.installation_id AS installationId,a.employee_name AS employeeName,
      a.status,a.device_id AS deviceId,a.renewal_sequence AS renewalSequence,
      d.label AS deviceLabel,d.enabled,d.public_key AS publicKey,d.encryption_public_key AS encryptionPublicKey,
      d.authorization_id AS deviceAuthorizationId
      FROM device_authorizations a LEFT JOIN devices d ON d.device_id=a.device_id
      WHERE a.authorization_id=?`).get(authorizationId);
    if (!row || row.installationId !== this.installationId ||
        !['pending', 'active'].includes(row.status) || !row.deviceId ||
        row.deviceAuthorizationId !== authorizationId || !row.publicKey || !row.encryptionPublicKey) {
      throw Object.assign(new Error('AUTHORIZATION_NOT_RENEWABLE'), { code: 'AUTHORIZATION_NOT_RENEWABLE' });
    }
    if ((row.status === 'active' && row.enabled !== 1) || (row.status === 'pending' && row.enabled !== 0)) {
      throw Object.assign(new Error('DEVICE_AUTHORIZATION_STATE_MISMATCH'), { code: 'DEVICE_AUTHORIZATION_STATE_MISMATCH' });
    }
    const publicKey = verifyPublicKey(row.publicKey);
    if (!publicKey) throw Object.assign(new Error('DEVICE_SIGNING_KEY_INVALID'), { code: 'DEVICE_SIGNING_KEY_INVALID' });
    const signingKeyHash = sha256(crypto.createPublicKey(publicKey).export({ type: 'spki', format: 'der' }));
    const sequence = Number(row.renewalSequence || 0) + 1;
    if (!Number.isSafeInteger(sequence) || sequence < 1) {
      throw Object.assign(new Error('RENEWAL_SEQUENCE_INVALID'), { code: 'RENEWAL_SEQUENCE_INVALID' });
    }
    const now = Date.now();
    const expiresAt = now + CODE_TTL_MS;
    const code = String(crypto.randomInt(0, 100000000)).padStart(8, '0');
    const descriptor = {
      format: 'procontrol.device-authorization',
      version: 6,
      permanent: true,
      installationId: this.installationId,
      installationCode: this.getInstallationCode(),
      authorizationId,
      deviceId: row.deviceId,
      deviceSigningPublicKeyHash: signingKeyHash,
      authorizationScope: 'installation',
      employeeName: row.employeeName,
      code,
      expiresAt,
      renewalSequence: sequence,
      createdAt: new Date(now).toISOString(),
      desktopPublicKey: this.desktopPublicKey
    };
    descriptor.signature = {
      algorithm: 'Ed25519',
      value: crypto.sign(null, signedFields(descriptor), this.desktopPrivateKey).toString('base64')
    };
    const activationCode = encodeProVentaActivationCode(JSON.stringify(descriptor));
    const codeHash = sha256(activationCode);

    this.db.exec('BEGIN IMMEDIATE');
    try {
      const current = this.db.prepare(`SELECT a.status,a.renewal_sequence AS renewalSequence,
        a.installation_id AS installationId,a.device_id AS deviceId,d.enabled,
        d.authorization_id AS deviceAuthorizationId
        FROM device_authorizations a LEFT JOIN devices d ON d.device_id=a.device_id
        WHERE a.authorization_id=?`).get(authorizationId);
      if (!current || current.installationId !== this.installationId ||
          current.status !== row.status || Number(current.renewalSequence || 0) !== Number(row.renewalSequence || 0) ||
          current.deviceId !== row.deviceId || current.deviceAuthorizationId !== authorizationId ||
          current.enabled !== row.enabled) {
        throw Object.assign(new Error('AUTHORIZATION_CHANGED_DURING_RENEWAL'), { code: 'AUTHORIZATION_CHANGED_DURING_RENEWAL' });
      }
      const updated = this.db.prepare(`UPDATE device_authorizations SET code_hash=?,expires_at=?,protocol_version=6,
        authorized_pos_id=NULL,device_signing_key_hash=?,renewal_sequence=?,updated_at=?
        WHERE authorization_id=? AND installation_id=? AND renewal_sequence=? AND status=?`)
        .run(codeHash, expiresAt, signingKeyHash, sequence, now, authorizationId, this.installationId,
          Number(row.renewalSequence || 0), row.status);
      if (updated.changes !== 1) throw Object.assign(new Error('AUTHORIZATION_CHANGED_DURING_RENEWAL'), { code: 'AUTHORIZATION_CHANGED_DURING_RENEWAL' });
      const updatedDevice = this.db.prepare(`UPDATE devices SET pos_id=NULL,installation_id=?,employee_name=?,
        authorization_id=? WHERE device_id=? AND authorization_id=? AND enabled=?`)
        .run(this.installationId, row.employeeName, authorizationId, row.deviceId, authorizationId, row.enabled);
      if (updatedDevice.changes !== 1) throw Object.assign(new Error('DEVICE_AUTHORIZATION_STATE_MISMATCH'), { code: 'DEVICE_AUTHORIZATION_STATE_MISMATCH' });
      this.audit('device_authorization_renewal_issued', actor, {
        authorizationId, installationId: this.installationId, deviceId: row.deviceId,
        employeeName: row.employeeName, renewalSequence: sequence, expiresAt, activationCodeHash: codeHash
      });
      this.db.exec('COMMIT');
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      throw error;
    }
    return {
      ok: true, authorizationId, activationCode, employeeName: row.employeeName,
      deviceId: row.deviceId, deviceLabel: row.deviceLabel, installationId: this.installationId,
      protocolVersion: 6, renewalSequence: sequence, qrExpiresAt: expiresAt, status: row.status
    };
  }

  confirmDeviceAuthorization(authorizationIdInput, actor = 'desktop-local') {
    const authorizationId = String(authorizationIdInput || '');
    if (!/^auth_[A-Za-z0-9-]{20,60}$/.test(authorizationId)) {
      return { ok: false, code: 'INVALID_AUTHORIZATION_ID' };
    }
    const now = Date.now();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const row = this.db.prepare(`SELECT a.status,a.installation_id AS installationId,a.device_id AS deviceId,
        a.employee_name AS employeeName,d.enabled,d.authorization_id AS deviceAuthorizationId
        FROM device_authorizations a LEFT JOIN devices d ON d.device_id=a.device_id
        WHERE a.authorization_id=?`).get(authorizationId);
      if (!row || row.installationId !== this.installationId || !row.deviceId ||
          row.deviceAuthorizationId !== authorizationId) {
        throw Object.assign(new Error('AUTHORIZATION_NOT_FOUND'), { code: 'AUTHORIZATION_NOT_FOUND' });
      }
      if (row.status === 'active' && row.enabled === 1) {
        this.db.exec('COMMIT');
        return { ok: true, duplicate: true, authorizationId, deviceId: row.deviceId, status: 'active' };
      }
      if (row.status !== 'pending' || row.enabled !== 0) {
        throw Object.assign(new Error('AUTHORIZATION_NOT_PENDING_CONFIRMATION'), { code: 'AUTHORIZATION_NOT_PENDING_CONFIRMATION' });
      }
      const authorizationUpdate = this.db.prepare(`UPDATE device_authorizations SET status='active',paired_at=?,updated_at=?
        WHERE authorization_id=? AND installation_id=? AND status='pending'`).run(now, now, authorizationId, this.installationId);
      const deviceUpdate = this.db.prepare(`UPDATE devices SET enabled=1,paired_at=?,last_seen_at=?,revoked_at=NULL
        WHERE device_id=? AND authorization_id=? AND enabled=0`).run(now, now, row.deviceId, authorizationId);
      if (authorizationUpdate.changes !== 1 || deviceUpdate.changes !== 1) {
        throw Object.assign(new Error('AUTHORIZATION_CONFIRMATION_CONFLICT'), { code: 'AUTHORIZATION_CONFIRMATION_CONFLICT' });
      }
      this.audit('device_authorization_confirmed', actor, {
        authorizationId, installationId: this.installationId, deviceId: row.deviceId,
        employeeName: row.employeeName
      });
      this.db.exec('COMMIT');
      return { ok: true, authorizationId, deviceId: row.deviceId, status: 'active' };
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      return { ok: false, code: error && error.code || 'AUTHORIZATION_CONFIRMATION_FAILED' };
    }
  }

  createDeviceAuthorization(input, actor = 'desktop-local') {
    const data = input && typeof input === 'object' ? input : {};
    const employeeName = String(data.employeeName || '').trim();
    const employeeData = String(data.employeeData || '').trim();
    const posInput = String(data.posId || '').trim();
    const authorizedPosId = posInput.startsWith('pos:') ? posInput.slice(4) : posInput;
    const replacesAuthorizationId = data.replacesAuthorizationId == null ? null : String(data.replacesAuthorizationId);
    if (employeeName.length < 2 || employeeName.length > 100 || employeeData.length > 1000) {
      throw Object.assign(new Error('INVALID_EMPLOYEE_DATA'), { code: 'INVALID_EMPLOYEE_DATA' });
    }
    if (!safePosRef(posInput) || !safePosRef(authorizedPosId)) {
      throw Object.assign(new Error('POS_SCOPE_REQUIRED'), { code: 'POS_SCOPE_REQUIRED' });
    }
    let replaced = null;
    if (replacesAuthorizationId) {
      replaced = this.db.prepare(`SELECT authorization_id AS authorizationId,employee_name AS employeeName,status,installation_id AS installationId,authorized_pos_id AS authorizedPosId
        FROM device_authorizations WHERE authorization_id=?`).get(replacesAuthorizationId);
      if (!replaced || !['active', 'invalidated'].includes(replaced.status) || replaced.installationId !== this.installationId) {
        throw Object.assign(new Error('REPLACEMENT_AUTHORIZATION_NOT_ACTIVE'), { code: 'REPLACEMENT_AUTHORIZATION_NOT_ACTIVE' });
      }
      if (replaced.employeeName.toLocaleLowerCase() !== employeeName.toLocaleLowerCase()) {
        throw Object.assign(new Error('REPLACEMENT_EMPLOYEE_MISMATCH'), { code: 'REPLACEMENT_EMPLOYEE_MISMATCH' });
      }
      // Una sustitución conserva el POS de la autorización previa. Solo los
      // registros heredados sin POS pueden fijarse por primera vez durante la migración.
      if (replaced.authorizedPosId && replaced.authorizedPosId !== authorizedPosId) {
        throw Object.assign(new Error('REPLACEMENT_POS_SCOPE_MISMATCH'), { code: 'REPLACEMENT_POS_SCOPE_MISMATCH' });
      }
    }
    const generatedCode = this._generateInstallationScopedCode();
    const raw = generatedCode.code;
    const codeHash = generatedCode.codeHash;
    const codePattern = generatedCode.codePattern;
    const now = Date.now();
    const expiresAt = now + CODE_TTL_MS;
    const authorizationId = 'auth_' + crypto.randomUUID();
    const safeEmployeeData = this._encodeEmployeeData({ note: employeeData });
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.db.prepare(`UPDATE device_authorizations SET status='invalidated',updated_at=?
        WHERE status='pending' AND expires_at<?`).run(now, now);
      this.db.prepare(`INSERT INTO device_authorizations(authorization_id,installation_id,employee_name,employee_data_json,code_hash,issued_at,expires_at,status,created_by,authorized_pos_id,replaces_authorization_id,updated_at)
        VALUES(?,?,?,?,?,?,?,'pending',?,?,?,?)`).run(authorizationId, this.installationId, employeeName, safeEmployeeData, codeHash, now, expiresAt, actor, authorizedPosId, replacesAuthorizationId, now);
      this.db.prepare(`INSERT INTO pairing_codes(code_hash,expires_at,created_at,created_by,assigned_role,assigned_pos_id,authorization_id,installation_id)
        VALUES(?,?,?,?,'operator',?,?,?)`).run(codeHash, expiresAt, now, actor, authorizedPosId, authorizationId, this.installationId);
      this.audit('device_authorization_issued', actor, { authorizationId, installationId: this.installationId, authorizedPosId, employeeName, replacesAuthorizationId, expiresAt });
      this.db.exec('COMMIT');
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      throw error;
    }
    return { ok: true, authorizationId, code: raw, codePattern, employeeName, installationId: this.installationId, authorizedPosId, expiresAt, ttlSeconds: CODE_TTL_MS / 1000, replacesAuthorizationId };
  }
  createDeviceAuthorizationDescriptor(input, actor = 'desktop-local') {
    const data = input && typeof input === 'object' ? input : {};
    const authorizationId = String(data.authorizationId || '');
    const code = String(data.code || '');
    if (!/^auth_[A-Za-z0-9-]{20,60}$/.test(authorizationId) || !/^\d{6}$/.test(code)) {
      throw Object.assign(new Error('INVALID_AUTHORIZATION_DESCRIPTOR'), { code: 'INVALID_AUTHORIZATION_DESCRIPTOR' });
    }
    const row = this.db.prepare(`SELECT installation_id AS installationId,employee_name AS employeeName,authorized_pos_id AS authorizedPosId,expires_at AS expiresAt,status,code_hash AS codeHash
      FROM device_authorizations WHERE authorization_id=?`).get(authorizationId);
    if (!row || row.installationId !== this.installationId || !safePosRef(row.authorizedPosId || '') || row.status !== 'pending' || row.expiresAt < Date.now() || row.codeHash !== sha256(code)) {
      throw Object.assign(new Error('AUTHORIZATION_NOT_PENDING_OR_EXPIRED'), { code: 'AUTHORIZATION_NOT_PENDING_OR_EXPIRED' });
    }
    const codePattern = this.getInstallationCodePattern();
    // Las autorizaciones pendientes emitidas por una versión anterior pueden
    // conservar códigos aleatorios sin el patrón nuevo. Se exportan como ficha
    // legacy firmada (sin codePattern); las nuevas siempre incluyen la regla.
    const patternFields = this._codeMatchesInstallationPattern(code, codePattern) ? {
      codePattern: {
        version: codePattern.version,
        patternId: codePattern.patternId,
        mode: codePattern.mode,
        firstDigit: codePattern.firstDigit,
        oddDigitCount: codePattern.oddDigitCount,
        checksumAlgorithm: codePattern.checksumAlgorithm
      }
    } : {};
    const doc = {
      format: 'procontrol.device-authorization', version: 2,
      installationId: this.installationId, authorizationId, desktopId: this.desktopId,
      authorizedPosId: row.authorizedPosId, employeeName: row.employeeName, code,
      ...patternFields,
      expiresAt: row.expiresAt,
      desktopPublicKey: this.desktopPublicKey, createdAt: new Date().toISOString()
    };
    doc.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(doc), this.desktopPrivateKey).toString('base64') };
    this.audit('device_authorization_descriptor_exported', actor, { authorizationId, installationId: this.installationId });
    return JSON.stringify(doc, null, 2);
  }
  listDeviceAuthorizations(posIdInput = null) {
    const selectedPosId = posIdInput == null ? null : (String(posIdInput).startsWith('pos:') ? String(posIdInput).slice(4) : String(posIdInput));
    const rows = this.db.prepare(`SELECT a.authorization_id AS authorizationId,a.installation_id AS installationId,
      a.employee_name AS employeeName,a.authorized_pos_id AS authorizedPosId,a.employee_data_json AS employeeDataJson,a.issued_at AS issuedAt,
      a.expires_at AS expiresAt,a.status,a.created_by AS createdBy,a.device_id AS deviceId,
      a.replaces_authorization_id AS replacesAuthorizationId,a.replaced_by_authorization_id AS replacedByAuthorizationId,
      a.paired_at AS pairedAt,a.revoked_at AS revokedAt,a.protocol_version AS protocolVersion,
      a.renewal_sequence AS renewalSequence,
      d.label AS deviceLabel,d.last_seen_at AS lastSeenAt,d.enabled AS deviceEnabled,
      CASE WHEN d.encryption_public_key IS NULL THEN 0 ELSE 1 END AS encryptionConfigured
      FROM device_authorizations a LEFT JOIN devices d ON d.device_id=a.device_id
      WHERE a.installation_id=? AND (? IS NULL OR a.authorized_pos_id=? OR a.authorized_pos_id IS NULL) ORDER BY a.issued_at DESC LIMIT 500`).all(this.installationId, selectedPosId, selectedPosId);
    return rows.map(row => {
      let employeeData = {};
      try { employeeData = this._decodeEmployeeData(row.employeeDataJson || '{}'); } catch (_) {}
      return { ...row, employeeData, employeeDataJson: undefined, recordStatus: row.status,
        status: row.status === 'pending' && row.expiresAt < Date.now() ? 'expired' : row.status };
    });
  }
  revokeDeviceAuthorization(authorizationId, actor = 'desktop-local', expectedPosId = null, reason = '') {
    const id = String(authorizationId || '');
    const note = String(reason || '').trim();
    if (!/^auth_[A-Za-z0-9-]{20,60}$/.test(id)) return { ok: false, code: 'INVALID_AUTHORIZATION_ID' };
    const row = this.db.prepare(`SELECT status,device_id AS deviceId,installation_id AS installationId,
      authorized_pos_id AS authorizedPosId,protocol_version AS protocolVersion
      FROM device_authorizations WHERE authorization_id=?`).get(id);
    if (!row || row.installationId !== this.installationId) return { ok: false, code: 'AUTHORIZATION_NOT_FOUND' };
    if (Number(row.protocolVersion) >= 5 && (note.length < 3 || note.length > 240)) return { ok: false, code: 'REVOCATION_REASON_REQUIRED' };
    if (note.length > 240) return { ok: false, code: 'REVOCATION_REASON_REQUIRED' };
    if (expectedPosId != null) { const expected = String(expectedPosId).startsWith('pos:') ? String(expectedPosId).slice(4) : String(expectedPosId); if (row.authorizedPosId && row.authorizedPosId !== expected) return { ok: false, code: 'AUTHORIZATION_POS_SCOPE_MISMATCH' }; }
    if (row.status === 'superseded') return { ok: false, code: 'AUTHORIZATION_ALREADY_SUPERSEDED' };
    if (row.status === 'invalidated') return { ok: true, duplicate: true };
    const now = Date.now();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.db.prepare(`UPDATE device_authorizations SET status='invalidated',revoked_at=?,updated_at=? WHERE authorization_id=?`).run(now, now, id);
      if (row.deviceId) this.db.prepare('UPDATE devices SET enabled=0,revoked_at=? WHERE device_id=?').run(now, row.deviceId);
      this.db.prepare('DELETE FROM pairing_codes WHERE code_hash=(SELECT code_hash FROM device_authorizations WHERE authorization_id=?) AND consumed_at IS NULL').run(id);
      this.audit('device_authorization_revoked', actor, { authorizationId: id, deviceId: row.deviceId || null, installationId: this.installationId, reason: note });
      this.db.exec('COMMIT');
      return { ok: true, authorizationId: id, deviceId: row.deviceId || null, status: 'invalidated', reason: note };
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      return { ok: false, code: error && error.code || 'AUTHORIZATION_REVOKE_FAILED' };
    }
  }
  listDeviceAuthorizationHistory(limit = 200) {
    const take = Math.max(1, Math.min(500, Math.trunc(Number(limit) || 200)));
    const actions = [
      'device_authorized_from_pvid', 'device_authorization_issued',
      'device_authorization_revoked', 'device_authorization_superseded',
      'device_authorization_descriptor_exported', 'device_enabled', 'device_revoked',
      'device_enrollment_request_imported', 'device_identity_imported',
      'device_authorization_renewal_issued', 'device_authorization_confirmed'
    ];
    const placeholders = actions.map(() => '?').join(',');
    const rows = this.db.prepare(`SELECT id,at,action,actor,detail_json AS detailJson
      FROM bridge_audit WHERE action IN (${placeholders}) ORDER BY id DESC LIMIT ?`).all(...actions, take);
    return rows.map(row => {
      let detail = {};
      try { detail = JSON.parse(row.detailJson || '{}'); } catch (_) {}
      return { id: row.id, at: row.at, action: row.action, actor: row.actor, detail };
    });
  }

  createPairingCode(actor = 'desktop-local', assignedRole = 'operator', posId = null) {
    if (!VALID_ROLES.has(assignedRole) || assignedRole === 'admin') throw Object.assign(new Error('ADMIN_ROLE_REQUIRES_AUTHORIZATION'), { code: 'ADMIN_ROLE_REQUIRES_AUTHORIZATION' });
    if (posId != null && !safePosRef(posId)) throw Object.assign(new Error('INVALID_POS_SCOPE'), { code: 'INVALID_POS_SCOPE' });
    if (!posId) throw Object.assign(new Error('POS_SCOPE_REQUIRED'), { code: 'POS_SCOPE_REQUIRED' });
    const generatedCode = this._generateInstallationScopedCode();
    const raw = generatedCode.code;
    const now = Date.now();
    this.db.prepare('DELETE FROM pairing_codes WHERE expires_at < ? OR consumed_at IS NOT NULL').run(now);
    this.db.prepare('INSERT INTO pairing_codes(code_hash,expires_at,created_at,created_by,assigned_role,assigned_pos_id) VALUES(?,?,?,?,?,?)')
      .run(sha256(raw), now + CODE_TTL_MS, now, actor, assignedRole, posId);
    this.audit('pairing_code_created', actor, { expiresAt: now + CODE_TTL_MS, role: assignedRole, posId });
    return { code: raw, codePattern: generatedCode.codePattern, expiresAt: now + CODE_TTL_MS, ttlSeconds: CODE_TTL_MS / 1000, assignedRole, assignedPosId: posId };
  }
  createPairingDescriptor(input, actor = 'desktop-local') {
    const data = input && typeof input === 'object' ? input : {};
    if (!/^\d{6}$/.test(String(data.code || '')) || !VALID_ROLES.has(data.role) || data.role === 'admin' || !safePosRef(data.posId) || !Number.isFinite(Number(data.expiresAt)) || Number(data.expiresAt) <= Date.now() || Number(data.expiresAt) > Date.now() + CODE_TTL_MS + 15000) {
      throw Object.assign(new Error('INVALID_PAIRING_DESCRIPTOR'), { code: 'INVALID_PAIRING_DESCRIPTOR' });
    }
    const code = String(data.code);
    const codePattern = this.getInstallationCodePattern();
    const patternFields = this._codeMatchesInstallationPattern(code, codePattern) ? { codePattern } : {};
    const doc = { format: PAIRING_FORMAT, version: 1, desktopId: this.desktopId, code, ...patternFields, role: data.role, posId: data.posId, expiresAt: Number(data.expiresAt), desktopPublicKey: this.desktopPublicKey, createdAt: new Date().toISOString() };
    doc.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(doc), this.desktopPrivateKey).toString('base64') };
    this.audit('pairing_descriptor_exported', actor, { role: data.role, posId: data.posId, expiresAt: doc.expiresAt });
    return JSON.stringify(doc, null, 2);
  }
  pairDevice(input, actor = 'desktop-local') {
    if (!input || typeof input !== 'object' || !/^\d{6}$/.test(String(input.code || '')) || !safeId(input.deviceId) || !boundedString(input.label, 80))
      return { ok: false, code: 'INVALID_INPUT' };
    const suppliedPublicKey = input.publicKey == null ? null : verifyPublicKey(input.publicKey);
    if (input.publicKey != null && !suppliedPublicKey) return { ok: false, code: 'INVALID_DEVICE_PUBLIC_KEY' };
    const suppliedEncryptionPublicKey = input.encryptionPublicKey == null ? null : verifyRsaEncryptionPublicKey(input.encryptionPublicKey);
    if (input.encryptionPublicKey != null && !suppliedEncryptionPublicKey) return { ok: false, code: 'INVALID_DEVICE_ENCRYPTION_PUBLIC_KEY' };
    const now = Date.now();
    const row = this.db.prepare('SELECT * FROM pairing_codes WHERE code_hash=? AND consumed_at IS NULL AND expires_at>=?')
      .get(sha256(String(input.code)), now);
    if (!row) return { ok: false, code: 'PAIRING_CODE_INVALID_OR_EXPIRED' };
    const existing = this.db.prepare('SELECT device_id AS deviceId,enabled,public_key AS publicKey,encryption_public_key AS encryptionPublicKey,authorization_id AS authorizationId,pos_id AS posId FROM devices WHERE device_id=?').get(input.deviceId);
    const isInstallationAuthorization = !!row.authorization_id;
    let authorization = null;
    if (isInstallationAuthorization && input.authorizationId && String(input.authorizationId) !== String(row.authorization_id)) return { ok: false, code: 'AUTHORIZATION_ID_MISMATCH' };
    if (existing && !isInstallationAuthorization) return { ok: false, code: 'DEVICE_ALREADY_REGISTERED' };
    if (isInstallationAuthorization) {
      authorization = this.db.prepare(`SELECT * FROM device_authorizations WHERE authorization_id=?`).get(row.authorization_id);
      if (!authorization || authorization.status !== 'pending' || authorization.installation_id !== this.installationId || row.installation_id !== this.installationId) return { ok: false, code: 'INSTALLATION_AUTHORIZATION_INVALID' };
      if (input.installationId !== this.installationId) return { ok: false, code: 'INSTALLATION_MISMATCH' };
      if (!safePosRef(authorization.authorized_pos_id || '') || String(input.authorizedPosId || '') !== String(authorization.authorized_pos_id)) return { ok: false, code: 'AUTHORIZATION_POS_SCOPE_MISMATCH' };
      if (String(row.assigned_pos_id || '') !== String(authorization.authorized_pos_id)) return { ok: false, code: 'PAIRING_POS_SCOPE_MISMATCH' };
      if (!suppliedPublicKey) return { ok: false, code: 'DEVICE_SIGNING_KEY_REQUIRED' };
    }
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const consumed = this.db.prepare('UPDATE pairing_codes SET consumed_at=? WHERE code_hash=? AND consumed_at IS NULL AND expires_at>=?').run(now, row.code_hash, now);
      if (consumed.changes !== 1) throw Object.assign(new Error('PAIRING_CODE_ALREADY_USED'), { code: 'PAIRING_CODE_ALREADY_USED' });
      if (existing) {
        const previousAuthorization = isInstallationAuthorization && authorization.replaces_authorization_id
          ? this.db.prepare(`SELECT authorized_pos_id AS authorizedPosId,status FROM device_authorizations WHERE authorization_id=? AND installation_id=?`)
            .get(authorization.replaces_authorization_id, this.installationId)
          : null;
        const replacingSamePhone = isInstallationAuthorization && previousAuthorization &&
          authorization.replaces_authorization_id && existing.enabled === 0 &&
          existing.authorizationId === authorization.replaces_authorization_id &&
          existing.publicKey === suppliedPublicKey && String(existing.posId || '') === String(previousAuthorization.authorizedPosId || '') &&
          ['invalidated', 'active'].includes(previousAuthorization.status);
        if (!replacingSamePhone) throw Object.assign(new Error('DEVICE_ALREADY_REGISTERED'), { code: 'DEVICE_ALREADY_REGISTERED' });
        const updated = this.db.prepare(`UPDATE devices SET label=?,role='operator',enabled=1,paired_at=?,last_seen_at=?,revoked_at=NULL,
          public_key=?,encryption_public_key=?,pos_id=?,installation_id=?,employee_name=?,employee_data_json=?,authorization_id=? WHERE device_id=? AND enabled=0 AND authorization_id=?`)
          .run(input.label.trim(), now, now, suppliedPublicKey, suppliedEncryptionPublicKey, authorization.authorized_pos_id,
            this.installationId, authorization.employee_name, authorization.employee_data_json, authorization.authorization_id,
            input.deviceId, authorization.replaces_authorization_id);
        if (updated.changes !== 1) throw Object.assign(new Error('DEVICE_REPLACEMENT_CONFLICT'), { code: 'DEVICE_REPLACEMENT_CONFLICT' });
      } else {
        this.db.prepare(`INSERT INTO devices(device_id,label,role,enabled,paired_at,last_seen_at,public_key,encryption_public_key,pos_id,installation_id,employee_name,employee_data_json,authorization_id)
          VALUES(?,?,?,1,?,?,?,?,?,?,?,?,?)`)
          .run(input.deviceId, input.label.trim(), isInstallationAuthorization ? 'operator' : (row.assigned_role || 'operator'), now, now, suppliedPublicKey, suppliedEncryptionPublicKey,
            isInstallationAuthorization ? authorization.authorized_pos_id : (row.assigned_pos_id || null), isInstallationAuthorization ? this.installationId : null,
            isInstallationAuthorization ? authorization.employee_name : null, isInstallationAuthorization ? authorization.employee_data_json : null,
            isInstallationAuthorization ? authorization.authorization_id : null);
      }
      if (isInstallationAuthorization) {
        const activated = this.db.prepare(`UPDATE device_authorizations SET status='active',device_id=?,paired_at=?,updated_at=? WHERE authorization_id=? AND status='pending' AND installation_id=?`)
          .run(input.deviceId, now, now, authorization.authorization_id, this.installationId);
        if (activated.changes !== 1) throw Object.assign(new Error('INSTALLATION_AUTHORIZATION_ALREADY_USED'), { code: 'INSTALLATION_AUTHORIZATION_ALREADY_USED' });
        if (authorization.replaces_authorization_id) {
          const previous = this.db.prepare(`SELECT device_id AS deviceId,status FROM device_authorizations WHERE authorization_id=? AND installation_id=?`)
            .get(authorization.replaces_authorization_id, this.installationId);
          if (!previous || !['active', 'invalidated'].includes(previous.status)) throw Object.assign(new Error('REPLACEMENT_AUTHORIZATION_CHANGED'), { code: 'REPLACEMENT_AUTHORIZATION_CHANGED' });
          this.db.prepare(`UPDATE device_authorizations SET status='superseded',replaced_by_authorization_id=?,updated_at=? WHERE authorization_id=? AND status IN ('active','invalidated')`)
            .run(authorization.authorization_id, now, authorization.replaces_authorization_id);
          if (previous.deviceId) this.db.prepare('UPDATE devices SET enabled=0,revoked_at=? WHERE device_id=?').run(now, previous.deviceId);
          this.audit('device_authorization_superseded', actor, { previousAuthorizationId: authorization.replaces_authorization_id, newAuthorizationId: authorization.authorization_id, previousDeviceId: previous.deviceId || null, newDeviceId: input.deviceId });
        }
      }
      this.audit(isInstallationAuthorization ? 'device_authorized_for_installation' : 'device_paired_legacy_pos', actor,
        { deviceId: input.deviceId, label: input.label.trim(), role: isInstallationAuthorization ? 'operator' : (row.assigned_role || 'operator'), posId: isInstallationAuthorization ? authorization.authorized_pos_id : (row.assigned_pos_id || null), installationId: isInstallationAuthorization ? this.installationId : null, authorizationId: isInstallationAuthorization ? authorization.authorization_id : null, hasPublicKey: !!suppliedPublicKey });
      this.db.exec('COMMIT');
      return { ok: true, deviceId: input.deviceId, role: isInstallationAuthorization ? 'operator' : (row.assigned_role || 'operator'), posId: isInstallationAuthorization ? authorization.authorized_pos_id : (row.assigned_pos_id || null), authorizedPosId: isInstallationAuthorization ? authorization.authorized_pos_id : null, installationId: isInstallationAuthorization ? this.installationId : null, authorizationId: isInstallationAuthorization ? authorization.authorization_id : null, pairedAt: now, signingConfigured: !!suppliedPublicKey, encryptionConfigured: !!suppliedEncryptionPublicKey };
    } catch (e) { try { this.db.exec('ROLLBACK'); } catch (_) {} return { ok: false, code: e && e.code || 'DEVICE_PAIRING_FAILED' }; }
  }
  importDeviceEnrollment(rawDocument, actor = 'desktop-local', expectedPosId = null) {
    let doc = rawDocument;
    if (typeof rawDocument === 'string') {
      if (Buffer.byteLength(rawDocument, 'utf8') > 64 * 1024) return { ok: false, code: 'ENROLLMENT_REQUEST_TOO_LARGE' };
      try { doc = JSON.parse(rawDocument); } catch (_) { return { ok: false, code: 'ENROLLMENT_REQUEST_INVALID_JSON' }; }
    }
    if (!doc || typeof doc !== 'object' || Array.isArray(doc) || doc.format !== 'procontrol.device-enrollment-request' || ![1, 2, 3].includes(doc.version)) return { ok: false, code: 'ENROLLMENT_REQUEST_UNSUPPORTED' };
    if (doc.installationId !== this.installationId) return { ok: false, code: 'INSTALLATION_MISMATCH' };
    if (!/^auth_[A-Za-z0-9-]{20,60}$/.test(String(doc.authorizationId || '')) || !/^\d{6}$/.test(String(doc.code || '')) ||
        !safeId(doc.deviceId) || !boundedString(doc.label, 80) || !Number.isFinite(Date.parse(doc.createdAt)) || !safePosRef(doc.authorizedPosId || '')) return { ok: false, code: 'ENROLLMENT_REQUEST_INVALID' };
    if (expectedPosId != null) { const expected = String(expectedPosId).startsWith('pos:') ? String(expectedPosId).slice(4) : String(expectedPosId); if (String(doc.authorizedPosId || '') !== expected) return { ok: false, code: 'ENROLLMENT_POS_CONTEXT_MISMATCH' }; }
    const publicKeyPem = verifyPublicKey(doc.devicePublicKey);
    if (!publicKeyPem) return { ok: false, code: 'INVALID_DEVICE_PUBLIC_KEY' };
    const encryptionPublicKeyPem = doc.deviceEncryptionPublicKey == null ? null : verifyRsaEncryptionPublicKey(doc.deviceEncryptionPublicKey);
    if (doc.version >= 2 && !encryptionPublicKeyPem) return { ok: false, code: 'INVALID_DEVICE_ENCRYPTION_PUBLIC_KEY' };
    if (doc.deviceEncryptionPublicKey != null && !encryptionPublicKeyPem) return { ok: false, code: 'INVALID_DEVICE_ENCRYPTION_PUBLIC_KEY' };
    if (!doc.signature || doc.signature.algorithm !== 'Ed25519' || typeof doc.signature.value !== 'string' || doc.signature.value.length > 512) return { ok: false, code: 'ENROLLMENT_SIGNATURE_MISSING' };
    let signature;
    try { signature = Buffer.from(doc.signature.value, 'base64'); } catch (_) { return { ok: false, code: 'ENROLLMENT_SIGNATURE_INVALID' }; }
    try {
      if (!crypto.verify(null, signedFields(doc), crypto.createPublicKey(publicKeyPem), signature)) return { ok: false, code: 'ENROLLMENT_SIGNATURE_INVALID' };
    } catch (_) { return { ok: false, code: 'ENROLLMENT_SIGNATURE_INVALID' }; }
    const result = this.pairDevice({
      code: String(doc.code), authorizationId: String(doc.authorizationId), installationId: String(doc.installationId),
      deviceId: String(doc.deviceId), label: String(doc.label), publicKey: publicKeyPem, encryptionPublicKey: encryptionPublicKeyPem, authorizedPosId: String(doc.authorizedPosId)
    }, actor);
    if (result.ok) this.audit('device_enrollment_request_imported', actor, { authorizationId: result.authorizationId, deviceId: result.deviceId, installationId: this.installationId, encryptionConfigured: !!encryptionPublicKeyPem });
    if (result.ok) result.encryptionConfigured = !!encryptionPublicKeyPem;
    return result;
  }
  listDevices() {
    return this.db.prepare(`SELECT device_id AS deviceId,label,role,enabled,paired_at AS pairedAt,last_seen_at AS lastSeenAt,
      revoked_at AS revokedAt,pos_id AS posId,installation_id AS installationId,employee_name AS employeeName,
      authorization_id AS authorizationId,CASE WHEN public_key IS NULL THEN 0 ELSE 1 END AS signingConfigured,
      CASE WHEN encryption_public_key IS NULL THEN 0 ELSE 1 END AS encryptionConfigured
      FROM devices ORDER BY paired_at DESC`).all();
  }
  setDeviceEnabled(deviceId, enabled, actor = 'desktop-local') {
    if (!safeId(deviceId) || typeof enabled !== 'boolean') return { ok: false, code: 'INVALID_INPUT' };
    const device = this.db.prepare('SELECT authorization_id AS authorizationId FROM devices WHERE device_id=?').get(deviceId);
    if (!device) return { ok: false, code: 'DEVICE_NOT_FOUND' };
    if (enabled && device.authorizationId) {
      const authorization = this.db.prepare('SELECT status FROM device_authorizations WHERE authorization_id=?').get(device.authorizationId);
      if (!authorization || authorization.status !== 'active') return { ok: false, code: 'DEVICE_AUTHORIZATION_NOT_REACTIVATABLE' };
    }
    const now = Date.now();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const r = this.db.prepare('UPDATE devices SET enabled=?,revoked_at=? WHERE device_id=?').run(enabled ? 1 : 0, enabled ? null : now, deviceId);
      if (device.authorizationId && !enabled) this.db.prepare(`UPDATE device_authorizations SET status='invalidated',revoked_at=?,updated_at=? WHERE authorization_id=? AND status IN ('active','invalidated')`).run(now, now, device.authorizationId);
      this.audit(enabled ? 'device_enabled' : 'device_revoked', actor, { deviceId, authorizationId: device.authorizationId || null });
      this.db.exec('COMMIT');
      return { ok: true };
    } catch (error) { try { this.db.exec('ROLLBACK'); } catch (_) {} return { ok: false, code: error && error.code || 'DEVICE_STATUS_UPDATE_FAILED' }; }
  }
  _checkDeviceScope(device, type, payload) {
    const role = String(device.role || 'operator');
    const deviceId = String(device.device_id || device.deviceId || '');
    const boundPosId = String(device.pos_id || device.posId || '');
    const installationId = String(device.installation_id || device.installationId || '');
    const authorizationId = String(device.authorization_id || device.authorizationId || '');
    const isInstallationDevice = !!installationId || !!authorizationId;

    // La autorización permanente pertenece a la instalación y al dispositivo.
    // Su estado se vuelve a comprobar en cada importación: no basta con que el
    // registro devices.enabled siga siendo 1 si la autorización fue invalidada.
    if (isInstallationDevice) {
      if (!installationId || installationId !== this.installationId || !authorizationId) return 'INSTALLATION_MISMATCH';
      const authorization = this.db.prepare(`SELECT status,device_id AS deviceId,installation_id AS installationId,authorized_pos_id AS authorizedPosId,protocol_version AS protocolVersion
        FROM device_authorizations WHERE authorization_id=?`).get(authorizationId);
      if (!authorization || authorization.status !== 'active' || authorization.deviceId !== deviceId || authorization.installationId !== this.installationId) {
        return 'DEVICE_AUTHORIZATION_INACTIVE';
      }
      if (Number(authorization.protocolVersion) >= 5) {
        if (authorization.authorizedPosId != null || boundPosId) return 'DEVICE_AUTHORIZATION_SCOPE_INVALID';
      } else if (!safePosRef(authorization.authorizedPosId || '') || !boundPosId || authorization.authorizedPosId !== boundPosId) return 'DEVICE_POS_SCOPE_MISMATCH';
    }

    const operations = Array.isArray(payload.transactions) ? payload.transactions : [];
    if (['sale_batch', 'goods_receipt', 'return', 'shift_open', 'shift_close'].includes(type)) {
      const refs = type === 'goods_receipt'
        ? [payload.posId]
        : (type === 'sale_batch' || type === 'return')
          ? operations.map(tx => tx && tx.posId)
          : [payload.shift && payload.shift.posId];
      if (!refs.length || refs.some(ref => !safePosRef(String(ref || '')))) return 'PACKAGE_POS_SCOPE_REQUIRED';
      const uniqueRefs = [...new Set(refs.map(ref => String(ref)))];
      if (uniqueRefs.length !== 1) return 'PACKAGE_MULTIPLE_POS_NOT_ALLOWED';
      // Legacy v4 is fixed to a POS. v5 installation-wide phones may operate only
      // within the unique POS named by a signed, current shift permit (control plane).
      const authVersion = isInstallationDevice ? Number(this.db.prepare('SELECT protocol_version AS version FROM device_authorizations WHERE authorization_id=?').get(authorizationId)?.version || 0) : 0;
      if (authVersion < 5 && (!boundPosId || uniqueRefs[0] !== boundPosId)) return boundPosId ? 'DEVICE_POS_SCOPE_MISMATCH' : 'DEVICE_POS_NOT_BOUND';
    }
    if (['transfer', 'return'].includes(type) && role !== 'supervisor' && role !== 'admin') return 'ROLE_NOT_ALLOWED';
    if (type === 'transfer') {
      if (!boundPosId) return isInstallationDevice ? 'TRANSFER_PERMISSION_NOT_READY' : 'DEVICE_POS_NOT_BOUND';
      const t = payload.transfer || payload;
      if (![t.source, t.destination].some(ref => String(ref || '') === boundPosId)) return 'TRANSFER_OUTSIDE_DEVICE_SCOPE';
    }
    if (type === 'inventory_snapshot' && role === 'operator') return 'ROLE_NOT_ALLOWED';
    return null;
  }
  _storeVerifiedPackage(input, signerDeviceId, controlContext = null) {
    const identityError = validatePackageProductIdentity(input.type, input.payload);
    if (identityError) return { ok: false, code: identityError };
    const json = stableJson(input.payload);
    if (Buffer.byteLength(json, 'utf8') > MAX_PACKAGE_BYTES) return { ok: false, code: 'PACKAGE_TOO_LARGE' };
    const hash = sha256(json);
    if (input.payloadHash && input.payloadHash !== hash) return { ok: false, code: 'HASH_MISMATCH' };
    const existing = this.db.prepare('SELECT payload_hash AS payloadHash,status,ack_json AS ackJson FROM incoming_packages WHERE package_id=?').get(input.packageId);
    if (existing) {
      if (existing.payloadHash !== hash) return { ok: false, code: 'PACKAGE_ID_CONFLICT' };
      // Preserve the original identity on a duplicate import so a reattempt can
      // reopen the exact stored package and complete any unfinished reconciliation/ack.
      return { ok: true, packageId: input.packageId, deviceId: signerDeviceId, type: input.type,
        payloadHash: hash, duplicate: true, status: existing.status,
        ack: existing.ackJson ? JSON.parse(existing.ackJson) : null };
    }
    const now = Date.now();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      if (controlContext && controlContext.signed === true && this.controlPlane) {
        const control = this.controlPlane.checkAndRecordIncomingPackage(input, controlContext.device, hash);
        if (!control || control.ok !== true) {
          throw Object.assign(new Error(control && control.code || 'CONTROL_PACKAGE_REJECTED'), { code: control && control.code || 'CONTROL_PACKAGE_REJECTED' });
        }
      }
      this.db.prepare(`INSERT INTO incoming_packages(package_id,device_id,package_type,payload_json,payload_hash,status,received_at)
        VALUES(?,?,?,?,?,'pending_review',?)`).run(input.packageId, signerDeviceId, input.type, json, hash, now);
      this.db.prepare(`INSERT INTO reconciliation_jobs(package_id,payload_hash,status,attempts,first_received_at,updated_at)
        VALUES(?,?,'pending_review',0,?,?)`).run(input.packageId, hash, now, now);
      this.db.prepare('UPDATE devices SET last_seen_at=? WHERE device_id=?').run(now, signerDeviceId);
      this.audit('package_received_verified', signerDeviceId, { packageId: input.packageId, type: input.type, hash });
      this.db.exec('COMMIT');
      return { ok: true, packageId: input.packageId, duplicate: false, status: 'pending_review', ack: { packageId: input.packageId, payloadHash: hash, receivedAt: now, status: 'received_pending_review' } };
    } catch (e) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      if (e && e.code) return { ok: false, code: e.code };
      throw e;
    }
  }
  receivePackage(input) {
    // Internal compatibility API for tests/local harness only. The desktop UI no longer exposes it to arbitrary renderer calls.
    if (!input || typeof input !== 'object' || !safeId(input.packageId) || !safeId(input.deviceId) || !VALID_TYPES.has(input.type)) return { ok: false, code: 'INVALID_ENVELOPE' };
    const device = this.db.prepare('SELECT device_id,role,enabled,pos_id,installation_id,authorization_id FROM devices WHERE device_id=?').get(input.deviceId);
    if (!device || !device.enabled) return { ok: false, code: 'DEVICE_NOT_AUTHORIZED' };
    const scope = this._checkDeviceScope(device, input.type, input.payload || {});
    if (scope) return { ok: false, code: scope };
    return this._storeVerifiedPackage(input, input.deviceId);
  }
  createDesktopBundle(type, payload) {
    if (!VALID_TYPES.has(type)) throw Object.assign(new Error('INVALID_PACKAGE_TYPE'), { code: 'INVALID_PACKAGE_TYPE' });
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw Object.assign(new Error('INVALID_PAYLOAD'), { code: 'INVALID_PAYLOAD' });
    const identityError = validatePackageProductIdentity(type, payload);
    if (identityError) throw Object.assign(new Error(identityError), { code: identityError });
    const payloadJson = stableJson(payload);
    if (Buffer.byteLength(payloadJson, 'utf8') > MAX_PACKAGE_BYTES) throw Object.assign(new Error('PACKAGE_TOO_LARGE'), { code: 'PACKAGE_TOO_LARGE' });
    const doc = { format: PACKAGE_FORMAT, version: 1, packageId: crypto.randomUUID(), deviceId: this.desktopId, type, createdAt: new Date().toISOString(), payload, payloadHash: sha256(payloadJson), signerPublicKey: this.desktopPublicKey };
    doc.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(doc), this.desktopPrivateKey).toString('base64') };
    this.audit('desktop_package_exported', 'desktop-local', { packageId: doc.packageId, type, payloadHash: doc.payloadHash });
    return JSON.stringify(doc, null, 2);
  }
  createDeviceBoundDataPackage(input, actor = 'desktop-local', options = {}) {
    const data = input && typeof input === 'object' ? input : {};
    const deviceId = String(data.deviceId || '');
    const posId = String(data.posId || '');
    const requestId = String(data.requestId || crypto.randomUUID());
    const type = String(data.type || 'inventory_snapshot');
    const payload = data.payload;
    if (!safeId(deviceId) || !safePosRef(posId) || !safeId(requestId) || type !== 'inventory_snapshot') return { ok: false, code: 'INVALID_DEVICE_DATA_PACKAGE_INPUT' };
    if (!payload || typeof payload !== 'object' || Array.isArray(payload) || String(payload.posId || '') !== posId || String(payload.installationId || '') !== this.installationId) return { ok: false, code: 'DEVICE_DATA_PACKAGE_SCOPE_MISMATCH' };
    const identityError = validatePackageProductIdentity(type, payload);
    if (identityError) return { ok: false, code: identityError };
    let payloadJson;
    try { payloadJson = stableJson(payload); } catch (_) { return { ok: false, code: 'DEVICE_DATA_PACKAGE_INVALID_PAYLOAD' }; }
    const payloadBytes = Buffer.byteLength(payloadJson, 'utf8');
    if (payloadBytes > MAX_DEVICE_DATA_PACKAGE_BYTES) return { ok: false, code: 'DEVICE_DATA_PACKAGE_TOO_LARGE' };
    const payloadHash = sha256(payloadJson);
    const device = this.db.prepare(`SELECT device_id AS deviceId,enabled,pos_id AS posId,
      installation_id AS installationId,authorization_id AS authorizationId,
      encryption_public_key AS encryptionPublicKey FROM devices WHERE device_id=?`).get(deviceId);
    if (!device || Number(device.enabled) !== 1) return { ok: false, code: 'DEVICE_NOT_AUTHORIZED' };
    if (device.installationId !== this.installationId || !device.authorizationId) return { ok: false, code: 'DEVICE_NOT_INSTALLATION_AUTHORIZED' };
    const authorization = this.db.prepare(`SELECT status,device_id AS deviceId,installation_id AS installationId,
      authorized_pos_id AS authorizedPosId,protocol_version AS protocolVersion
      FROM device_authorizations WHERE authorization_id=?`).get(device.authorizationId);
    if (!authorization || authorization.status !== 'active' || authorization.deviceId !== deviceId || authorization.installationId !== this.installationId) return { ok: false, code: 'DEVICE_AUTHORIZATION_INACTIVE' };
    if (Number(authorization.protocolVersion) >= 5) {
      // An installation-wide phone has no permanent POS. The selected POS is only the scope of
      // this encrypted snapshot; operational access still requires a signed shift permit.
      if (authorization.authorizedPosId != null || device.posId) return { ok: false, code: 'DEVICE_AUTHORIZATION_SCOPE_INVALID' };
    } else if (!authorization.authorizedPosId || authorization.authorizedPosId !== posId || authorization.authorizedPosId !== String(device.posId || '')) {
      return { ok: false, code: 'DEVICE_POS_SCOPE_MISMATCH' };
    }
    const encryptionPublicKey = verifyRsaEncryptionPublicKey(device.encryptionPublicKey);
    if (!encryptionPublicKey) return { ok: false, code: 'DEVICE_ENCRYPTION_KEY_NOT_REGISTERED' };
    // La autorización se valida ANTES de devolver un paquete idempotente: una revocación
    // impide también volver a exportar el mismo archivo desde ProControl.
    const existing = this.db.prepare(`SELECT package_id AS packageId,device_id AS deviceId,pos_id AS posId,payload_hash AS payloadHash,envelope_json AS envelopeJson,expires_at AS expiresAt
      FROM outgoing_device_packages WHERE request_id=?`).get(requestId);
    if (existing) {
      if (existing.deviceId !== deviceId || existing.posId !== posId || existing.payloadHash !== payloadHash) return { ok: false, code: 'DEVICE_DATA_REQUEST_ID_CONFLICT' };
      if (Number(existing.expiresAt) < Date.now()) return { ok: false, code: 'DEVICE_DATA_PACKAGE_EXPIRED' };
      return { ok: true, duplicate: true, packageId: existing.packageId, deviceId, posId, payloadHash, expiresAt: Number(existing.expiresAt), envelopeJson: existing.envelopeJson };
    }

    const now = Date.now();
    const expiresAt = now + DEVICE_DATA_PACKAGE_TTL_MS;
    const packageId = crypto.randomUUID();
    const header = {
      format: DEVICE_DATA_PACKAGE_FORMAT, version: 1, algorithm: 'RSA-OAEP-256+A256GCM',
      packageId, installationId: this.installationId, authorizationId: device.authorizationId,
      deviceId, posId, type, createdAt: new Date(now).toISOString(), expiresAt,
      payloadHash, signerPublicKey: this.desktopPublicKey
    };
    const contentKey = crypto.randomBytes(32);
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', contentKey, iv);
    cipher.setAAD(Buffer.from(stableJson(header), 'utf8'));
    const ciphertext = Buffer.concat([cipher.update(payloadJson, 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();
    const wrappedKey = crypto.publicEncrypt({ key: encryptionPublicKey, padding: crypto.constants.RSA_PKCS1_OAEP_PADDING, oaepHash: 'sha256' }, contentKey);
    contentKey.fill(0);
    const envelope = {
      ...header,
      encryption: { keyWrap: 'RSA-OAEP-SHA256', contentCipher: 'AES-256-GCM', wrappedKey: wrappedKey.toString('base64'), iv: iv.toString('base64'), tag: tag.toString('base64') },
      ciphertext: ciphertext.toString('base64')
    };
    envelope.signature = { algorithm: 'Ed25519', value: crypto.sign(null, signedFields(envelope), this.desktopPrivateKey).toString('base64') };
    const envelopeJson = JSON.stringify(envelope, null, 2);
    if (Buffer.byteLength(envelopeJson, 'utf8') > MAX_DEVICE_DATA_PACKAGE_BYTES + 65536) return { ok: false, code: 'DEVICE_DATA_PACKAGE_TOO_LARGE' };
    const maxEnvelopeBytes = Number(options && options.maxEnvelopeBytes);
    if (Number.isSafeInteger(maxEnvelopeBytes) && maxEnvelopeBytes > 0 &&
        Buffer.byteLength(envelopeJson, 'utf8') > maxEnvelopeBytes) {
      return { ok: false, code: 'SHIFT_OPENING_INVENTORY_TOO_LARGE', maxBytes: maxEnvelopeBytes };
    }

    this.db.exec('BEGIN IMMEDIATE');
    try {
      const current = this.db.prepare(`SELECT d.enabled,d.pos_id AS devicePosId,d.installation_id AS installationId,
        d.authorization_id AS authorizationId,a.status,a.device_id AS authorizedDeviceId,
        a.protocol_version AS protocolVersion,a.authorized_pos_id AS authorizedPosId
        FROM devices d LEFT JOIN device_authorizations a ON a.authorization_id=d.authorization_id WHERE d.device_id=?`).get(deviceId);
      if (!current || Number(current.enabled) !== 1 || current.installationId !== this.installationId || current.authorizationId !== device.authorizationId || current.status !== 'active' || current.authorizedDeviceId !== deviceId) {
        throw Object.assign(new Error('DEVICE_AUTHORIZATION_INACTIVE'), { code: 'DEVICE_AUTHORIZATION_INACTIVE' });
      }
      if (Number(current.protocolVersion) >= 5) {
        if (current.authorizedPosId != null || current.devicePosId) throw Object.assign(new Error('DEVICE_AUTHORIZATION_SCOPE_INVALID'), { code: 'DEVICE_AUTHORIZATION_SCOPE_INVALID' });
      } else if (current.authorizedPosId !== posId || current.devicePosId !== posId) {
        throw Object.assign(new Error('DEVICE_POS_SCOPE_MISMATCH'), { code: 'DEVICE_POS_SCOPE_MISMATCH' });
      }
      this.db.prepare(`INSERT INTO outgoing_device_packages(package_id,request_id,device_id,authorization_id,pos_id,package_type,payload_hash,envelope_json,created_at,expires_at,status)
        VALUES(?,?,?,?,?,?,?,?,?,?,'issued')`).run(packageId, requestId, deviceId, device.authorizationId, posId, type, payloadHash, envelopeJson, now, expiresAt);
      this.audit('device_data_package_created', actor, { packageId, deviceId, posId, type, payloadHash, bytes: Buffer.byteLength(envelopeJson, 'utf8'), expiresAt });
      this.db.exec('COMMIT');
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      return { ok: false, code: error && error.code || 'DEVICE_DATA_PACKAGE_CREATE_FAILED' };
    }
    return { ok: true, duplicate: false, packageId, deviceId, posId, payloadHash, expiresAt, bytes: Buffer.byteLength(envelopeJson, 'utf8'), envelopeJson };
  }
  importOfflineBundle(rawText) {
    if (typeof rawText !== 'string' || Buffer.byteLength(rawText, 'utf8') > MAX_PACKAGE_BYTES + 65536) return { ok: false, code: 'PACKAGE_TOO_LARGE' };
    let doc;
    try { doc = JSON.parse(rawText); } catch (_) { return { ok: false, code: 'INVALID_JSON' }; }
    const shapeError = validateEnvelopeShape(doc);
    if (shapeError) return { ok: false, code: shapeError };
    const device = this.db.prepare('SELECT device_id,role,enabled,pos_id,installation_id,authorization_id,public_key AS publicKey FROM devices WHERE device_id=?').get(doc.deviceId);
    if (!device || !device.enabled) return { ok: false, code: 'DEVICE_NOT_AUTHORIZED' };
    if (!device.publicKey) return { ok: false, code: 'DEVICE_SIGNING_KEY_NOT_REGISTERED' };
    const expectedKey = verifyPublicKey(device.publicKey);
    const suppliedKey = verifyPublicKey(doc.signerPublicKey);
    if (!expectedKey || !suppliedKey || expectedKey !== suppliedKey) return { ok: false, code: 'SIGNER_KEY_MISMATCH' };
    let payloadJson;
    try { payloadJson = stableJson(doc.payload); } catch (_) { return { ok: false, code: 'INVALID_PAYLOAD' }; }
    if (sha256(payloadJson) !== doc.payloadHash) return { ok: false, code: 'HASH_MISMATCH' };
    let signature;
    try { signature = Buffer.from(doc.signature.value, 'base64'); } catch (_) { return { ok: false, code: 'SIGNATURE_INVALID' }; }
    try {
      if (!crypto.verify(null, signedFields(doc), crypto.createPublicKey(expectedKey), signature)) return { ok: false, code: 'SIGNATURE_INVALID' };
    } catch (_) { return { ok: false, code: 'SIGNATURE_INVALID' }; }
    const scope = this._checkDeviceScope(device, doc.type, doc.payload);
    if (scope) return { ok: false, code: scope };
    const result = this._storeVerifiedPackage(doc, doc.deviceId, { signed: true, device });
    if (result.ok && !result.duplicate) this.audit('package_signature_verified', doc.deviceId, { packageId: doc.packageId, type: doc.type });
    return result;
  }
  listPendingPackages() {
    return this.db.prepare(`SELECT package_id AS packageId,device_id AS deviceId,package_type AS type,payload_hash AS payloadHash,status,received_at AS receivedAt
      FROM incoming_packages WHERE status IN ('pending_review','conflict','accepted_for_reconciliation') ORDER BY received_at`).all();
  }
  getPackage(packageId) {
    if (!safeId(packageId)) return null;
    const row = this.db.prepare(`SELECT package_id AS packageId,device_id AS deviceId,package_type AS type,payload_json AS payloadJson,payload_hash AS payloadHash,status,received_at AS receivedAt,applied_at AS appliedAt,ack_json AS ackJson
      FROM incoming_packages WHERE package_id=?`).get(packageId);
    if (!row) return null;
    row.payload = JSON.parse(row.payloadJson); delete row.payloadJson;
    row.ack = row.ackJson ? JSON.parse(row.ackJson) : null; delete row.ackJson;
    return row;
  }
  markPackage(packageId, decision, actor = 'desktop-local', note = '') {
    if (!safeId(packageId) || !['accepted_for_reconciliation', 'rejected', 'conflict'].includes(decision)) return { ok: false, code: 'INVALID_DECISION' };
    const row = this.db.prepare('SELECT package_id,status FROM incoming_packages WHERE package_id=?').get(packageId);
    if (!row) return { ok: false, code: 'PACKAGE_NOT_FOUND' };
    if (!['pending_review', 'conflict'].includes(row.status)) return { ok: false, code: 'INVALID_STATUS_TRANSITION' };
    const ack = { packageId, status: decision, decidedAt: Date.now(), note: String(note).slice(0, 500) };
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const updated = this.db.prepare(`UPDATE incoming_packages SET status=?,ack_json=? WHERE package_id=? AND status IN ('pending_review','conflict')`)
        .run(decision, JSON.stringify(ack), packageId);
      if (!updated.changes) throw Object.assign(new Error('INVALID_STATUS_TRANSITION'), { code: 'INVALID_STATUS_TRANSITION' });
      this.db.prepare('UPDATE reconciliation_jobs SET status=?,last_error_code=?,updated_at=? WHERE package_id=?')
        .run(decision, decision === 'conflict' ? String(note || 'CONFLICT').slice(0, 120) : null, Date.now(), packageId);
      if (this.controlPlane) this.controlPlane.afterPackageDecision(packageId, decision, actor);
      this.audit('package_decided', actor, ack);
      this.db.exec('COMMIT');
      return { ok: true, ack };
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      return { ok: false, code: error && error.code || 'PACKAGE_DECISION_FAILED' };
    }
  }
  beginPackageApply(packageId, actor = 'desktop-local') {
    if (!safeId(packageId)) return { ok: false, code: 'INVALID_PACKAGE_ID' };
    const row = this.db.prepare(`SELECT p.status,p.payload_hash AS payloadHash,j.status AS jobStatus,j.attempts
      FROM incoming_packages p LEFT JOIN reconciliation_jobs j ON j.package_id=p.package_id WHERE p.package_id=?`).get(packageId);
    if (!row) return { ok: false, code: 'PACKAGE_NOT_FOUND' };
    if (row.status === 'reconciled' || row.jobStatus === 'applied') return { ok: true, duplicate: true, status: 'applied', payloadHash: row.payloadHash };
    if (row.status !== 'accepted_for_reconciliation') return { ok: false, code: 'PACKAGE_NOT_ACCEPTED' };
    const now = Date.now();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const job = this.db.prepare('SELECT payload_hash AS payloadHash,status,attempts FROM reconciliation_jobs WHERE package_id=?').get(packageId);
      if (!job || job.payloadHash !== row.payloadHash) throw Object.assign(new Error('RECONCILIATION_HASH_MISMATCH'), { code: 'RECONCILIATION_HASH_MISMATCH' });
      if (job.status === 'applied') { this.db.exec('COMMIT'); return { ok: true, duplicate: true, status: 'applied', payloadHash: row.payloadHash }; }
      const updated = this.db.prepare(`UPDATE reconciliation_jobs SET status='applying',attempts=attempts+1,last_attempt_at=?,last_error_code=NULL,last_error_at=NULL,updated_at=?
        WHERE package_id=? AND payload_hash=? AND status IN ('accepted_for_reconciliation','applying')`).run(now, now, packageId, row.payloadHash);
      if (!updated.changes) throw Object.assign(new Error('RECONCILIATION_JOB_STATE_INVALID'), { code: 'RECONCILIATION_JOB_STATE_INVALID' });
      this.audit('package_apply_started', actor, { packageId, payloadHash: row.payloadHash, attempt: Number(job.attempts || 0) + 1 });
      this.db.exec('COMMIT');
      return { ok: true, status: 'applying', payloadHash: row.payloadHash, attempt: Number(job.attempts || 0) + 1 };
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      return { ok: false, code: error && error.code || 'PACKAGE_APPLY_BEGIN_FAILED' };
    }
  }
  failPackageApply(packageId, actor = 'desktop-local', errorCode = 'RECONCILIATION_FAILED') {
    if (!safeId(packageId)) return { ok: false, code: 'INVALID_PACKAGE_ID' };
    const safeCode = String(errorCode || 'RECONCILIATION_FAILED').replace(/[^A-Za-z0-9_:-]/g, '_').slice(0, 120) || 'RECONCILIATION_FAILED';
    const now = Date.now();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const row = this.db.prepare('SELECT status FROM incoming_packages WHERE package_id=?').get(packageId);
      if (!row) throw Object.assign(new Error('PACKAGE_NOT_FOUND'), { code: 'PACKAGE_NOT_FOUND' });
      const job = this.db.prepare(`UPDATE reconciliation_jobs SET status='accepted_for_reconciliation',last_error_code=?,last_error_at=?,updated_at=?
        WHERE package_id=? AND status='applying'`).run(safeCode, now, now, packageId);
      if (job.changes) this.audit('package_apply_failed_retryable', actor, { packageId, code: safeCode });
      this.db.exec('COMMIT');
      return { ok: true, retryable: true, recorded: !!job.changes };
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      return { ok: false, code: error && error.code || 'PACKAGE_APPLY_FAILURE_RECORD_FAILED' };
    }
  }
  markPackageApplied(packageId, actor = 'desktop-local', result = {}) {
    if (!safeId(packageId)) return { ok: false, code: 'INVALID_PACKAGE_ID' };
    let resultJson;
    try {
      resultJson = JSON.stringify(result || {});
      if (typeof resultJson !== 'string' || Buffer.byteLength(resultJson, 'utf8') > 65536) return { ok: false, code: 'RECONCILIATION_RESULT_INVALID' };
    } catch (_) { return { ok: false, code: 'RECONCILIATION_RESULT_INVALID' }; }
    const row = this.db.prepare('SELECT package_type AS type,status,payload_hash AS payloadHash,payload_json AS payloadJson FROM incoming_packages WHERE package_id=?').get(packageId);
    if (!row) return { ok: false, code: 'PACKAGE_NOT_FOUND' };
    const job = this.db.prepare('SELECT payload_hash AS payloadHash,status FROM reconciliation_jobs WHERE package_id=?').get(packageId);
    if (!job || job.payloadHash !== row.payloadHash) return { ok: false, code: 'RECONCILIATION_HASH_MISMATCH' };
    if (row.status === 'reconciled' || job.status === 'applied') return { ok: true, duplicate: true };
    if (row.status !== 'accepted_for_reconciliation') return { ok: false, code: 'PACKAGE_NOT_ACCEPTED' };
    if (job.status !== 'applying') return { ok: false, code: 'RECONCILIATION_JOB_NOT_APPLYING' };
    const now = Date.now();
    const ack = { packageId, status: 'reconciled', payloadHash: row.payloadHash, reconciledAt: now, result: JSON.parse(resultJson) };
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const updated = this.db.prepare(`UPDATE incoming_packages SET status='reconciled',applied_at=?,ack_json=? WHERE package_id=? AND status='accepted_for_reconciliation' AND payload_hash=?`)
        .run(now, JSON.stringify(ack), packageId, row.payloadHash);
      if (!updated.changes) {
        const latest = this.db.prepare('SELECT status FROM incoming_packages WHERE package_id=?').get(packageId);
        if (latest && latest.status === 'reconciled') { this.db.exec('COMMIT'); return { ok: true, duplicate: true }; }
        throw Object.assign(new Error('PACKAGE_NOT_ACCEPTED'), { code: 'PACKAGE_NOT_ACCEPTED' });
      }
      this.db.prepare(`UPDATE reconciliation_jobs SET status='applied',applied_at=?,receipt_json=?,last_error_code=NULL,last_error_at=NULL,updated_at=? WHERE package_id=? AND payload_hash=?`)
        .run(now, JSON.stringify(ack), now, packageId, row.payloadHash);
      if (this.controlPlane && ['transfer', 'goods_receipt'].includes(row.type)) {
        const transferResult = this.controlPlane.afterPackageApplied(packageId, actor);
        if (!transferResult || transferResult.ok !== true) throw Object.assign(new Error(transferResult && transferResult.code || 'TRANSFER_RECONCILIATION_FINALIZE_FAILED'), { code: transferResult && transferResult.code || 'TRANSFER_RECONCILIATION_FINALIZE_FAILED' });
      }
      this.audit('package_reconciled', actor, ack);
      this.db.exec('COMMIT');
      return { ok: true, ack };
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      return { ok: false, code: error && error.code || 'PACKAGE_APPLY_FINALIZE_FAILED' };
    }
  }
  getReconciliationJob(packageId) {
    if (!safeId(packageId)) return null;
    return this.db.prepare(`SELECT package_id AS packageId,payload_hash AS payloadHash,status,attempts,first_received_at AS firstReceivedAt,last_attempt_at AS lastAttemptAt,last_error_code AS lastErrorCode,last_error_at AS lastErrorAt,applied_at AS appliedAt,receipt_json AS receiptJson,updated_at AS updatedAt FROM reconciliation_jobs WHERE package_id=?`).get(packageId) || null;
  }
  status() {
    return { version: 2, desktopId: this.desktopId, transport: 'offline-file', networkListener: false,
      devices: this.db.prepare('SELECT COUNT(*) AS n FROM devices WHERE enabled=1').get().n,
      pendingPackages: this.db.prepare("SELECT COUNT(*) AS n FROM incoming_packages WHERE status IN ('pending_review','conflict','accepted_for_reconciliation')").get().n,
      note: 'Transferencia por archivo local/USB; no se abre ningún puerto de red. Los paquetes entrantes requieren firma del dispositivo y conciliación explícita.' };
  }
  close() { this.db.close(); }
}
module.exports = { MobileBridgeStore, MAX_PACKAGE_BYTES, MAX_DEVICE_DATA_PACKAGE_BYTES, DEVICE_DATA_PACKAGE_TTL_MS, DEVICE_DATA_PACKAGE_FORMAT, VALID_TYPES, PACKAGE_FORMAT, stableJson, sha256, signedFields, verifyPublicKey, verifyRsaEncryptionPublicKey, validatePackageProductIdentity, decodeProVentaDeviceIdentity, encodeProVentaActivationCode, decodeProVentaActivationCode };
