'use strict';

// Control plane de escritorio para licencias POS, modos operativos,
// permisos de turno y cierres móviles pendientes. Comparte SQLite y la clave
// Ed25519 dedicada del puente; nunca utiliza la clave privada PCL1.
const crypto = require('node:crypto');

const POS_MODES = new Set(['SIN_APP', 'CON_APP']);
// Se activa solo en la entrega de integración end-to-end con una app móvil real.
// Mientras no exista esa app, el cambio de autoridad del POS y los permisos exportables deben fallar cerrados.
const MOBILE_APP_READY = false;
const ADMIN_ROLES = new Set(['Dueño', 'Administrador']);
const LEGACY_MODULES = ['core', 'inventory', 'purchases', 'pos', 'closings', 'reports'];

function stableJson(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return '[' + value.map(stableJson).join(',') + ']';
  if (value && typeof value === 'object') {
    return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stableJson(value[k])).join(',') + '}';
  }
  if (typeof value === 'number' && !Number.isFinite(value)) throw new Error('NON_FINITE_NUMBER');
  if (typeof value === 'undefined' || typeof value === 'function' || typeof value === 'symbol') throw new Error('NON_SERIALIZABLE_VALUE');
  return JSON.stringify(value);
}
function sha256(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function isPosId(value) { return typeof value === 'string' && /^[A-Za-z0-9:_-]{1,160}$/.test(value); }
function normalizePosId(value) { const raw = String(value || '').trim(); return raw.startsWith('pos:') ? raw.slice(4) : raw; }
function isDeviceId(value) { return typeof value === 'string' && /^[A-Za-z0-9_-]{8,100}$/.test(value); }
function parseTime(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const n = Date.parse(String(value || ''));
  return Number.isFinite(n) ? n : NaN;
}
function asActor(actor) {
  if (!actor || !ADMIN_ROLES.has(actor.role) || typeof actor.user !== 'string' || !actor.user.trim()) {
    throw Object.assign(new Error('PRIVILEGED_AUTH_REQUIRED'), { code: 'PRIVILEGED_AUTH_REQUIRED' });
  }
  return { user: actor.user.trim().slice(0, 100), role: actor.role };
}

class MobileControlPlane {
  constructor(bridgeStore, options = {}) {
    if (!bridgeStore || !bridgeStore.db || !bridgeStore.desktopPrivateKey || !bridgeStore.desktopPublicKey) {
      throw new Error('BRIDGE_IDENTITY_REQUIRED');
    }
    this.bridge = bridgeStore;
    this.db = bridgeStore.db;
    this.deviceId = String(options.deviceId || '');
    this.verifyPointLicense = typeof options.verifyPointLicense === 'function' ? options.verifyPointLicense : null;
    this.getInstallationLicense = typeof options.getInstallationLicense === 'function' ? options.getInstallationLicense : null;
    this.now = typeof options.now === 'function' ? options.now : () => Date.now();
    this.mobileAppReady = MOBILE_APP_READY;
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS point_license_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS shift_emergency_usage (
        permit_id TEXT PRIMARY KEY, sales_count INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS shift_emergency_packages (
        package_id TEXT PRIMARY KEY, permit_id TEXT NOT NULL, sales_count INTEGER NOT NULL,
        payload_hash TEXT NOT NULL, received_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS pos_audit_modes (
        id INTEGER PRIMARY KEY AUTOINCREMENT, pos_id TEXT NOT NULL, mode TEXT NOT NULL,
        changed_at INTEGER NOT NULL, changed_by TEXT NOT NULL, change_id TEXT NOT NULL,
        cut_at INTEGER, snapshot_json TEXT, previous_mode TEXT
      );
      CREATE TABLE IF NOT EXISTS shift_permit_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT, permit_id TEXT NOT NULL, action TEXT NOT NULL,
        at INTEGER NOT NULL, actor TEXT NOT NULL, detail_json TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS package_acknowledgements (
        package_id TEXT PRIMARY KEY, acknowledgement_json TEXT NOT NULL, created_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS goods_dispatch_manifests (
        dispatch_id TEXT PRIMARY KEY,
        pos_id TEXT NOT NULL,
        items_hash TEXT NOT NULL,
        confirmation_hash TEXT NOT NULL,
        confirmation_code_data TEXT NOT NULL DEFAULT '',
        manifest_json TEXT NOT NULL,
        status TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        desktop_confirmed_at INTEGER,
        desktop_confirmed_by TEXT
      );
    `);
    const dispatchColumns = this.db.prepare('PRAGMA table_info(goods_dispatch_manifests)').all().map(row => row.name);
    if (!dispatchColumns.includes('confirmation_code_data')) {
      this.db.exec("ALTER TABLE goods_dispatch_manifests ADD COLUMN confirmation_code_data TEXT NOT NULL DEFAULT ''");
    }
    const transferColumns = this.db.prepare('PRAGMA table_info(transfer_events)').all().map(row => row.name);
    if (!transferColumns.includes('operation_id')) this.db.exec('ALTER TABLE transfer_events ADD COLUMN operation_id TEXT');
    if (!transferColumns.includes('operation_hash')) this.db.exec('ALTER TABLE transfer_events ADD COLUMN operation_hash TEXT');
    this.db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_transfer_operation_id ON transfer_events(operation_id) WHERE operation_id IS NOT NULL');
    const shiftPermitColumns = this.db.prepare('PRAGMA table_info(shift_permits)').all().map(row => row.name);
    if (!shiftPermitColumns.includes('shift_id')) this.db.exec('ALTER TABLE shift_permits ADD COLUMN shift_id TEXT');
    // Schema comes from MobileBridgeStore; these records share one SQLite file so package intake,
    // permit usage, close-request state and transfer events commit together.
  }

  _encodeDispatchConfirmationCode(code) {
    const safeStorage = this.bridge.safeStorage;
    if (safeStorage && typeof this.bridge._safeStorageReady === 'function' && this.bridge._safeStorageReady()) {
      return 'dpapi:' + safeStorage.encryptString(String(code)).toString('base64');
    }
    if (!(process.versions && process.versions.electron)) {
      return 'test:' + Buffer.from(String(code), 'utf8').toString('base64');
    }
    throw Object.assign(new Error('WINDOWS_KEY_PROTECTION_UNAVAILABLE'), { code:'WINDOWS_KEY_PROTECTION_UNAVAILABLE' });
  }
  _decodeDispatchConfirmationCode(record) {
    const value = String(record || '');
    if (value.startsWith('dpapi:')) {
      const safeStorage = this.bridge.safeStorage;
      if (!safeStorage || typeof this.bridge._safeStorageReady !== 'function' || !this.bridge._safeStorageReady()) {
        throw Object.assign(new Error('WINDOWS_KEY_PROTECTION_UNAVAILABLE'), { code:'WINDOWS_KEY_PROTECTION_UNAVAILABLE' });
      }
      return safeStorage.decryptString(Buffer.from(value.slice(6), 'base64'));
    }
    if (value.startsWith('test:') && !(process.versions && process.versions.electron)) {
      return Buffer.from(value.slice(5), 'base64').toString('utf8');
    }
    throw Object.assign(new Error('GOODS_DISPATCH_CONFIRMATION_UNAVAILABLE'), { code:'GOODS_DISPATCH_CONFIRMATION_UNAVAILABLE' });
  }
  _meta(key) {
    const row = this.db.prepare('SELECT value FROM bridge_meta WHERE key=?').get(String(key));
    return row ? row.value : null;
  }
  _setMeta(key, value) {
    this.db.prepare('INSERT INTO bridge_meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
      .run(String(key), String(value));
  }
  _isStrictLicensing() { return this._meta('strict_pos_licensing') === '1'; }
  _installationPolicy() {
    let payload = null;
    try { payload = this.getInstallationLicense ? this.getInstallationLicense() : null; } catch (_) {}
    return {
      payload,
      modules: payload && Array.isArray(payload.modules) ? payload.modules : LEGACY_MODULES,
      allowedModes: payload && Array.isArray(payload.allowedModes) ? payload.allowedModes : ['SIN_APP']
    };
  }
  _audit(action, actor, detail) {
    this.bridge.audit(action, actor || 'desktop-local', detail || {});
  }
  _licenseRow(posId) {
    if (!isPosId(posId)) return null;
    return this.db.prepare('SELECT pos_id AS posId,pos_name AS posName,license_token AS token,license_id AS licenseId,device_id AS deviceId,installed_at AS installedAt,active FROM pos_licenses WHERE pos_id=?').get(posId) || null;
  }
  _deviceAuthorization(device) {
    if (!device) return { ok: false, code: 'DEVICE_NOT_AUTHORIZED' };
    const deviceId = String(device.device_id || device.deviceId || '');
    const installationId = String(device.installation_id || device.installationId || '');
    const authorizationId = String(device.authorization_id || device.authorizationId || '');
    if (!installationId || !authorizationId) return { ok: false, code: 'DEVICE_NOT_INSTALLATION_AUTHORIZED' };
    if (installationId !== this.bridge.getInstallationId()) return { ok: false, code: 'INSTALLATION_MISMATCH' };
    const authorization = this.db.prepare(`SELECT status,device_id AS deviceId,installation_id AS installationId,
      employee_name AS employeeName,authorized_pos_id AS authorizedPosId,protocol_version AS protocolVersion,
      device_signing_key_hash AS deviceSigningKeyHash,authorization_id AS authorizationId
      FROM device_authorizations WHERE authorization_id=?`).get(authorizationId);
    if (!authorization || authorization.status !== 'active' || authorization.deviceId !== deviceId || authorization.installationId !== installationId) {
      return { ok: false, code: 'DEVICE_AUTHORIZATION_INACTIVE' };
    }
    const devicePosId = String(device.pos_id || device.posId || '');
    const protocolVersion = Number(authorization.protocolVersion || 0);
    if (protocolVersion >= 5) {
      // V5+ authorizations are scoped to this installation and device, never to a POS.
      // The POS is granted only by a signed shift permit.
      if (authorization.authorizedPosId != null || devicePosId) {
        return { ok: false, code: 'DEVICE_AUTHORIZATION_SCOPE_INVALID' };
      }
    } else {
      // Protocol 0 is retained only for the pre-V4 POS-bound pairing flow.
      // It is never promoted to installation-wide scope.
      if (!authorization.authorizedPosId || !devicePosId || authorization.authorizedPosId !== devicePosId) {
        return { ok: false, code: 'DEVICE_POS_SCOPE_MISMATCH' };
      }
    }
    return { ok: true, authorization };
  }
  _packagePOSIds(type, payload) {
    const shift = payload && payload.shift && typeof payload.shift === 'object' ? payload.shift : {};
    if (type === 'shift_open' || type === 'shift_close') return [String(shift.posId || '')];
    if (type === 'goods_receipt') return [String(payload && payload.posId || '')];
    if (type === 'sale_batch' || type === 'return') {
      const txs = Array.isArray(payload && payload.transactions) ? payload.transactions : [];
      return txs.map(tx => String(tx && tx.posId || ''));
    }
    if (type === 'transfer') {
      const transfer = payload && payload.transfer && typeof payload.transfer === 'object' ? payload.transfer : (payload || {});
      return [String(transfer.destination || '')];
    }
    return [];
  }
  _verifyStoredLicense(row) {
    if (!row || Number(row.active) !== 1 || !this.verifyPointLicense) return { ok: false, code: 'POS_LICENSE_MISSING' };
    let checked;
    try { checked = this.verifyPointLicense(row.token, row.posId, row.posName); }
    catch (_) { return { ok: false, code: 'POS_LICENSE_INVALID' }; }
    if (!checked || checked.ok !== true || !checked.payload) return { ok: false, code: checked && checked.code || 'POS_LICENSE_INVALID' };
    if (String(checked.payload.deviceId || '').toUpperCase().replace(/[^0-9A-F]/g, '') !== String(this.deviceId).toUpperCase().replace(/[^0-9A-F]/g, '')) return { ok: false, code: 'POS_LICENSE_OTHER_PC' };
    if (String(checked.payload.posId || '') !== row.posId) return { ok: false, code: 'POS_LICENSE_SCOPE_MISMATCH' };
    if (String(checked.payload.installationMachineId || '').toUpperCase().replace(/[^0-9A-F]/g, '') !== String(this.deviceId).toUpperCase().replace(/[^0-9A-F]/g, '')) return { ok: false, code: 'POS_LICENSE_OTHER_PC' };
    if (String(checked.payload.licenseType || checked.payload.type || '') !== 'point-of-sale') return { ok: false, code: 'LICENSE_TYPE_MISMATCH' };
    return { ok: true, payload: checked.payload };
  }
  installPointLicense(input, actorInput) {
    const actor = asActor(actorInput);
    const data = input && typeof input === 'object' ? input : {};
    const posId = String(data.posId || '');
    const posName = String(data.posName || '').trim();
    const token = String(data.token || '').trim();
    if (!isPosId(posId) || !posName || posName.length > 160 || token.length < 20 || token.length > 4096) {
      return { ok: false, code: 'INVALID_POS_LICENSE_INPUT' };
    }
    if (!this.verifyPointLicense) return { ok: false, code: 'POS_LICENSE_VERIFIER_UNAVAILABLE' };
    if (!this._installationPolicy().modules.includes('pos')) return { ok: false, code: 'INSTALLATION_MODULE_NOT_LICENSED' };
    const checked = this.verifyPointLicense(token, posId, posName);
    if (!checked || checked.ok !== true || !checked.payload) return { ok: false, code: checked && checked.code || 'POS_LICENSE_INVALID' };
    const payload = checked.payload;
    if (String(payload.licenseType || payload.type || '') !== 'point-of-sale') return { ok: false, code: 'LICENSE_TYPE_MISMATCH' };
    if (String(payload.posId || '') !== posId) return { ok: false, code: 'POS_LICENSE_SCOPE_MISMATCH' };
    if (String(payload.deviceId || '').toUpperCase().replace(/[^0-9A-F]/g, '') !== String(this.deviceId).toUpperCase().replace(/[^0-9A-F]/g, '') ||
        String(payload.installationMachineId || '').toUpperCase().replace(/[^0-9A-F]/g, '') !== String(this.deviceId).toUpperCase().replace(/[^0-9A-F]/g, '')) return { ok: false, code: 'POS_LICENSE_OTHER_PC' };
    const existing = this._licenseRow(posId);
    const now = this.now();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.db.prepare(`INSERT INTO pos_licenses(pos_id,pos_name,license_token,license_id,device_id,installed_at,active)
        VALUES(?,?,?,?,?,?,1) ON CONFLICT(pos_id) DO UPDATE SET pos_name=excluded.pos_name,license_token=excluded.license_token,license_id=excluded.license_id,device_id=excluded.device_id,installed_at=excluded.installed_at,active=1`)
        .run(posId, posName, token, String(payload.licenseId || sha256(token).slice(0, 24)), this.deviceId, now);
      this.db.prepare(`INSERT INTO pos_modes(pos_id,mode) VALUES(?,'SIN_APP') ON CONFLICT(pos_id) DO NOTHING`).run(posId);
      this._audit(existing ? 'pos_license_renewed' : 'pos_license_installed', actor.user, { posId, posName, licenseId: String(payload.licenseId || '') });
      this.db.exec('COMMIT');
      return { ok: true, posId, posName, licenseId: String(payload.licenseId || ''), installedAt: now };
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      return { ok: false, code: error && error.code || 'POS_LICENSE_STORE_FAILED' };
    }
  }
  getPOSPolicy(posIdInput) {
    const posId = normalizePosId(posIdInput);
    if (!isPosId(posId)) return { ok: false, code: 'INVALID_POS_ID' };
    const row = this._licenseRow(posId);
    const licenseStatus = this._verifyStoredLicense(row);
    const modeRow = this.db.prepare('SELECT mode,cut_at AS cutAt,changed_at AS changedAt,changed_by AS changedBy,change_id AS changeId FROM pos_modes WHERE pos_id=?').get(posId);
    const mode = modeRow ? String(modeRow.mode || '') : 'SIN_APP';
    if (!POS_MODES.has(mode)) return { ok: false, code: 'POS_MODE_INVALID', posId };
    return {
      ok: true, posId, mode, licenseValid: licenseStatus.ok,
      licenseCode: licenseStatus.ok ? null : licenseStatus.code,
      licenseId: row && row.licenseId || null, posName: row && row.posName || null,
      strictLicensing: this._isStrictLicensing(), cutAt: modeRow && modeRow.cutAt || null,
      changedAt: modeRow && modeRow.changedAt || null, changedBy: modeRow && modeRow.changedBy || null,
      changeId: modeRow && modeRow.changeId || null
    };
  }
  listPOSPolicies(posList) {
    return (Array.isArray(posList) ? posList : []).filter(p => p && isPosId(String(p.id || p.posId || '')))
      .map(p => ({ ...this.getPOSPolicy(String(p.id || p.posId)), requestedName: String(p.name || p.posName || '') }));
  }
  enablePointLicenseEnforcement(posList, actorInput) {
    const actor = asActor(actorInput);
    const list = Array.isArray(posList) ? posList : [];
    if (!list.length) return { ok: false, code: 'POS_LIST_EMPTY' };
    if (!this._installationPolicy().modules.includes('pos')) return { ok: false, code: 'INSTALLATION_MODULE_NOT_LICENSED' };
    const unique = new Set();
    for (const pos of list) {
      const id = String(pos && (pos.id || pos.posId) || '');
      if (!isPosId(id) || unique.has(id)) return { ok: false, code: 'INVALID_OR_DUPLICATE_POS_ID' };
      unique.add(id);
      const status = this.getPOSPolicy(id);
      if (!status.licenseValid) return { ok: false, code: 'POS_LICENSE_REQUIRED', posId: id, licenseCode: status.licenseCode };
    }
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this._setMeta('strict_pos_licensing', '1');
      this._audit('strict_pos_licensing_enabled', actor.user, { posIds: [...unique] });
      this.db.exec('COMMIT');
      return { ok: true, enabled: true, licensedPOSCount: unique.size };
    } catch (error) { try { this.db.exec('ROLLBACK'); } catch (_) {} return { ok: false, code: error && error.code || 'LICENSING_ENABLE_FAILED' }; }
  }
  canDesktopSell(posId) {
    const state = this.getPOSPolicy(posId);
    if (!state.ok) return state;
    if (!this._installationPolicy().modules.includes('pos')) return { ok: false, code: 'INSTALLATION_MODULE_NOT_LICENSED', mode: state.mode };
    if (state.mode === 'CON_APP') return { ok: false, code: 'POS_MOBILE_MODE_READ_ONLY', mode: state.mode };
    if (state.strictLicensing && !state.licenseValid) return { ok: false, code: 'POS_LICENSE_REQUIRED', mode: state.mode };
    return { ok: true, mode: state.mode, strictLicensing: state.strictLicensing, licenseValid: state.licenseValid };
  }
  setPOSMode(input, actorInput) {
    const actor = asActor(actorInput);
    const data = input && typeof input === 'object' ? input : {};
    const posId = String(data.posId || '');
    const mode = String(data.mode || '');
    if (!isPosId(posId) || !POS_MODES.has(mode)) return { ok: false, code: 'INVALID_POS_MODE' };
    if (mode === 'CON_APP' && !this.mobileAppReady) return { ok: false, code: 'MOBILE_APP_NOT_AVAILABLE' };
    const before = this.getPOSPolicy(posId);
    if (!before || before.ok !== true) return before || { ok:false, code:'POS_POLICY_UNAVAILABLE' };
    if (mode === 'CON_APP') {
      if (!before.licenseValid) return { ok: false, code: 'POS_LICENSE_REQUIRED' };
      const installation = this._installationPolicy();
      if (!installation.allowedModes.includes('CON_APP')) return { ok: false, code: 'INSTALLATION_MODE_NOT_LICENSED' };
      if (!installation.modules.includes('mobile-integration')) return { ok: false, code: 'INSTALLATION_MODULE_NOT_LICENSED' };
      const cut = data.cutInfo;
      if (!cut || cut.backupVerified !== true || !/^[a-f0-9]{64}$/i.test(String(cut.backupSha256 || '')) || !Number.isFinite(parseTime(cut.cutAt)) || !Array.isArray(cut.inventorySnapshot) || cut.inventorySnapshot.length > 100000) {
        return { ok: false, code: 'MODE_SWITCH_BACKUP_AND_CUT_REQUIRED' };
      }
      const productIds = new Set();
      for (const row of cut.inventorySnapshot) {
        if (!row || !isPosId(String(row.productId || '')) || productIds.has(String(row.productId)) || !Number.isFinite(Number(row.qty)) || Number(row.qty) < 0 || !String(row.unit || '').trim()) {
          return { ok: false, code: 'INVALID_INVENTORY_SNAPSHOT' };
        }
        productIds.add(String(row.productId));
      }
    }
    const now = this.now();
    const changeId = crypto.randomUUID();
    const cut = mode === 'CON_APP' ? data.cutInfo : null;
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.db.prepare(`INSERT INTO pos_modes(pos_id,mode,cut_at,snapshot_json,changed_by,changed_at,change_id)
        VALUES(?,?,?,?,?,?,?) ON CONFLICT(pos_id) DO UPDATE SET mode=excluded.mode,cut_at=excluded.cut_at,snapshot_json=excluded.snapshot_json,changed_by=excluded.changed_by,changed_at=excluded.changed_at,change_id=excluded.change_id`)
        .run(posId, mode, cut ? parseTime(cut.cutAt) : null, cut ? JSON.stringify(cut.inventorySnapshot) : null, actor.user, now, changeId);
      this.db.prepare(`INSERT INTO pos_audit_modes(pos_id,mode,changed_at,changed_by,change_id,cut_at,snapshot_json,previous_mode) VALUES(?,?,?,?,?,?,?,?)`)
        .run(posId, mode, now, actor.user, changeId, cut ? parseTime(cut.cutAt) : null, cut ? JSON.stringify(cut.inventorySnapshot) : null, before.mode);
      this._audit('pos_mode_changed', actor.user, { posId, from: before.mode, to: mode, changeId, cutAt: cut ? parseTime(cut.cutAt) : null, backupSha256: cut ? cut.backupSha256 : null });
      this.db.exec('COMMIT');
      return { ok: true, posId, mode, changeId, changedAt: now, cutAt: cut ? parseTime(cut.cutAt) : null };
    } catch (error) { try { this.db.exec('ROLLBACK'); } catch (_) {} return { ok: false, code: error && error.code || 'POS_MODE_CHANGE_FAILED' }; }
  }
  issueShiftPermit(input, actorInput) {
    if (!this.mobileAppReady) return { ok: false, code: 'MOBILE_APP_NOT_AVAILABLE' };
    const actor = asActor(actorInput);
    const data = input && typeof input === 'object' ? input : {};
    const posId = String(data.posId || '');
    const deviceId = String(data.deviceId || '');
    const employee = String(data.employee || '').trim();
    const startsAt = parseTime(data.startsAt);
    const endsAt = parseTime(data.endsAt);
    const sequence = Number(data.sequence);
    if (!isPosId(posId) || !isDeviceId(deviceId) || !employee || employee.length > 100 || !Number.isFinite(startsAt) || !Number.isFinite(endsAt) || endsAt <= startsAt || endsAt - startsAt > 24 * 60 * 60 * 1000 || !Number.isSafeInteger(sequence) || sequence < 1) return { ok: false, code: 'INVALID_SHIFT_PERMIT_INPUT' };
    const device = this.db.prepare(`SELECT device_id AS deviceId,role,enabled,pos_id AS posId,
      installation_id AS installationId,authorization_id AS authorizationId,employee_name AS employeeName
      FROM devices WHERE device_id=?`).get(deviceId);
    if (!device || Number(device.enabled) !== 1) return { ok: false, code: 'DEVICE_NOT_AUTHORIZED' };
    let deviceAuthorization = null;
    if (device.installationId || device.authorizationId) {
      const authorization = this._deviceAuthorization(device);
      if (!authorization.ok) return authorization;
      deviceAuthorization = authorization.authorization;
      if (Number(deviceAuthorization.protocolVersion) < 5 && deviceAuthorization.authorizedPosId !== posId) {
        return { ok: false, code: 'DEVICE_POS_SCOPE_MISMATCH' };
      }
      const expectedEmployee = String(deviceAuthorization.employeeName || '').trim().normalize('NFC').toLocaleLowerCase();
      const requestedEmployee = employee.normalize('NFC').toLocaleLowerCase();
      if (!expectedEmployee || expectedEmployee !== requestedEmployee) return { ok: false, code: 'EMPLOYEE_DEVICE_MISMATCH' };
    } else if (String(device.posId || '') !== posId) {
      // Compatibilidad temporal con móviles antiguos que sí estaban ligados a un POS.
      return { ok: false, code: device.posId ? 'DEVICE_POS_SCOPE_MISMATCH' : 'DEVICE_NOT_INSTALLATION_AUTHORIZED' };
    }
    const sequenceRow = this.db.prepare('SELECT MAX(sequence) AS maxSequence FROM shift_permits WHERE pos_id=? AND device_id=?').get(posId, deviceId);
    if (Number.isFinite(Number(sequenceRow && sequenceRow.maxSequence)) && sequence <= Number(sequenceRow.maxSequence)) return { ok: false, code: 'SHIFT_SEQUENCE_NOT_MONOTONIC' };
    const permitNow = this.now();
    const activePermit = Number(deviceAuthorization && deviceAuthorization.protocolVersion) >= 5
      ? this.db.prepare(`SELECT permit_id AS permitId,status,ends_at AS endsAt FROM shift_permits
          WHERE device_id=? AND (status IN ('open_pending_review','opened','close_pending') OR (status='issued' AND ends_at>?))
          ORDER BY created_at DESC LIMIT 1`).get(deviceId, permitNow)
      : this.db.prepare(`SELECT permit_id AS permitId,status,ends_at AS endsAt FROM shift_permits
          WHERE pos_id=? AND (status IN ('open_pending_review','opened','close_pending') OR (status='issued' AND ends_at>?))
          ORDER BY sequence DESC LIMIT 1`).get(posId, permitNow);
    if (activePermit) return { ok: false, code: Number(deviceAuthorization && deviceAuthorization.protocolVersion) >= 5
      ? 'ACTIVE_DEVICE_SHIFT_PERMIT_EXISTS' : 'ACTIVE_SHIFT_PERMIT_EXISTS', permitId: activePermit.permitId, status: activePermit.status };
    const emergencyInput = data.emergency && typeof data.emergency === 'object' && !Array.isArray(data.emergency) ? data.emergency : {};
    let emergency = { enabled: false, maxSales: 0, expiresAt: null, reason: null };
    if (emergencyInput.enabled === true) {
      const maxSales = Number(emergencyInput.maxSales);
      const emergencyExpiresAt = parseTime(emergencyInput.expiresAt);
      const reason = String(emergencyInput.reason || '').trim();
      if (actor.role !== 'Dueño') return { ok: false, code: 'EMERGENCY_REQUIRES_OWNER' };
      if (!Number.isSafeInteger(maxSales) || maxSales < 1 || maxSales > 50 || !Number.isFinite(emergencyExpiresAt) || emergencyExpiresAt <= this.now() || emergencyExpiresAt > endsAt || emergencyExpiresAt - this.now() > 4 * 60 * 60 * 1000 || reason.length < 8 || reason.length > 240) return { ok: false, code: 'INVALID_EMERGENCY_LIMITS' };
      emergency = { enabled: true, maxSales, expiresAt: emergencyExpiresAt, reason };
    } else if (emergencyInput.enabled != null && emergencyInput.enabled !== false) {
      return { ok: false, code: 'INVALID_EMERGENCY_LIMITS' };
    } else if ((emergencyInput.maxSales != null && Number(emergencyInput.maxSales) !== 0) || (emergencyInput.expiresAt != null && emergencyInput.expiresAt !== '')) {
      return { ok: false, code: 'EMERGENCY_MUST_BE_DISABLED_BY_DEFAULT' };
    }
    const licenseStatus = this.getPOSPolicy(posId);
    if (!licenseStatus.licenseValid) return { ok: false, code: 'POS_LICENSE_REQUIRED' };
    const installation = this._installationPolicy();
    if (!installation.modules.includes('mobile-integration')) return { ok: false, code: 'INSTALLATION_MODULE_NOT_LICENSED' };
    if (!installation.allowedModes.includes('CON_APP')) return { ok: false, code: 'INSTALLATION_MODE_NOT_LICENSED' };
    const permitId = crypto.randomUUID();
    const now = this.now();
    const isV4Authorization = Number(device.installationId ? (this._deviceAuthorization(device).authorization || {}).protocolVersion : 0) >= 4;
    const permit = {
      format: 'procontrol.shift-permit', version: isV4Authorization ? 2 : 1, permitId,
      desktopDeviceId: this.deviceId, posId, deviceId, employee,
      startsAt, endsAt, sequence, emergency, issuedAt: now,
      desktopPublicKey: this.bridge.desktopPublicKey,
      ...(isV4Authorization ? {
        installationId: this.bridge.getInstallationId(),
        installationCode: this.bridge.getInstallationCode(),
        authorizationId: device.authorizationId,
        deviceSigningPublicKeyHash: (this._deviceAuthorization(device).authorization || {}).deviceSigningKeyHash,
        authorizedPosId: posId
      } : {})
    };
    const signedBytes = Buffer.from(stableJson(permit), 'utf8');
    const signature = crypto.sign(null, signedBytes, this.bridge.desktopPrivateKey).toString('base64');
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.db.prepare(`INSERT INTO shift_permits(permit_id,pos_id,device_id,employee,sequence,starts_at,ends_at,permit_json,signature,status,created_by,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,'issued',?,?)`)
        .run(permitId, posId, deviceId, employee, sequence, startsAt, endsAt, stableJson(permit), signature, actor.user, now);
      this.db.prepare('INSERT INTO shift_permit_audit(permit_id,action,at,actor,detail_json) VALUES(?,?,?,?,?)')
        .run(permitId, 'issued', now, actor.user, JSON.stringify({ posId, deviceId, employee, sequence, startsAt, endsAt, emergency }));
      this._audit('shift_permit_issued', actor.user, { permitId, posId, deviceId, sequence, startsAt, endsAt });
      this.db.exec('COMMIT');
      return { ok: true, permit: { ...permit, signature }, permitId, bytes: Buffer.byteLength(stableJson({ ...permit, signature }), 'utf8') };
    } catch (error) { try { this.db.exec('ROLLBACK'); } catch (_) {} return { ok: false, code: error && error.code || 'SHIFT_PERMIT_ISSUE_FAILED' }; }
  }
  _loadPermit(permitId) {
    if (typeof permitId !== 'string' || permitId.length > 100) return null;
    const row = this.db.prepare(`SELECT permit_id AS permitId,pos_id AS posId,device_id AS deviceId,employee,sequence,starts_at AS startsAt,ends_at AS endsAt,permit_json AS permitJson,signature,status,created_by AS createdBy,created_at AS createdAt,open_package_id AS openPackageId,opened_at AS openedAt,close_package_id AS closePackageId,shift_id AS shiftId FROM shift_permits WHERE permit_id=?`).get(permitId);
    if (!row) return null;
    try { row.permit = JSON.parse(row.permitJson); } catch (_) { return null; }
    return row;
  }
  verifyShiftPermit(permitId, expected = {}) {
    const row = this._loadPermit(String(permitId || ''));
    if (!row) return { ok: false, code: 'SHIFT_PERMIT_NOT_FOUND' };
    let signature;
    try { signature = Buffer.from(row.signature, 'base64'); } catch (_) { return { ok: false, code: 'SHIFT_PERMIT_SIGNATURE_INVALID' }; }
    const publicKey = crypto.createPublicKey(this.bridge.desktopPublicKey);
    if (!crypto.verify(null, Buffer.from(stableJson(row.permit), 'utf8'), publicKey, signature)) return { ok: false, code: 'SHIFT_PERMIT_SIGNATURE_INVALID' };
    const now = this.now();
    if (row.permit.format !== 'procontrol.shift-permit' || ![1, 2].includes(Number(row.permit.version))) return { ok: false, code: 'SHIFT_PERMIT_FORMAT_INVALID' };
    if (Number(row.permit.version) === 2) {
      const permit = row.permit;
      if (!permit.installationId || permit.installationId !== this.bridge.getInstallationId() ||
          permit.installationCode !== this.bridge.getInstallationCode() ||
          permit.authorizedPosId !== row.posId || permit.posId !== row.posId ||
          permit.deviceId !== row.deviceId || typeof permit.authorizationId !== 'string' ||
          !/^[a-f0-9]{64}$/.test(String(permit.deviceSigningPublicKeyHash || ''))) {
        return { ok: false, code: 'SHIFT_PERMIT_INSTALLATION_SCOPE_MISMATCH' };
      }
      const linkedDevice = this.db.prepare(`SELECT device_id AS deviceId,enabled,pos_id AS posId,
        installation_id AS installationId,authorization_id AS authorizationId
        FROM devices WHERE device_id=?`).get(row.deviceId);
      if (!linkedDevice || Number(linkedDevice.enabled) !== 1) return { ok: false, code: 'DEVICE_NOT_AUTHORIZED' };
      const activeAuthorization = this._deviceAuthorization(linkedDevice);
      const activeAuth = activeAuthorization.authorization || {};
      const isInstallationWide = Number(activeAuth.protocolVersion) >= 5;
      const scopeMatches = isInstallationWide
        ? activeAuth.authorizedPosId == null && !String(linkedDevice.posId || '')
        : activeAuth.authorizedPosId === row.posId;
      if (!activeAuthorization.ok || activeAuth.authorizationId !== permit.authorizationId ||
          Number(activeAuth.protocolVersion) < 4 ||
          activeAuth.deviceSigningKeyHash !== permit.deviceSigningPublicKeyHash ||
          String(activeAuth.employeeName || '').trim().normalize('NFC').toLocaleLowerCase() !==
            String(permit.employee || '').trim().normalize('NFC').toLocaleLowerCase() ||
          !scopeMatches) {
        return { ok: false, code: activeAuthorization.code || 'SHIFT_PERMIT_AUTHORIZATION_MISMATCH' };
      }
    }
    const emergency = row.permit.emergency;
    if (!emergency || typeof emergency !== 'object' || Array.isArray(emergency) || typeof emergency.enabled !== 'boolean') return { ok: false, code: 'SHIFT_PERMIT_EMERGENCY_POLICY_INVALID' };
    if (emergency.enabled) {
      if (!Number.isSafeInteger(Number(emergency.maxSales)) || Number(emergency.maxSales) < 1 || Number(emergency.maxSales) > 50 || !Number.isFinite(parseTime(emergency.expiresAt)) || parseTime(emergency.expiresAt) <= Number(row.startsAt) || parseTime(emergency.expiresAt) > Number(row.endsAt) || typeof emergency.reason !== 'string' || emergency.reason.trim().length < 8 || emergency.reason.length > 240) return { ok: false, code: 'SHIFT_PERMIT_EMERGENCY_POLICY_INVALID' };
    } else if (Number(emergency.maxSales || 0) !== 0 || emergency.expiresAt != null || (emergency.reason != null && emergency.reason !== '')) {
      return { ok: false, code: 'SHIFT_PERMIT_EMERGENCY_POLICY_INVALID' };
    }
    if (row.permit.desktopDeviceId !== this.deviceId) return { ok: false, code: 'SHIFT_PERMIT_OTHER_PC' };
    // Los paquetes pueden llegar por USB después del turno. Se valida la hora del evento
    // firmada por el dispositivo contra la ventana del permiso, no la hora de importación.
    if (expected.forExport !== true) {
      const eventAt = expected.eventAt == null ? now : parseTime(expected.eventAt);
      if (!Number.isFinite(eventAt) || eventAt < Number(row.startsAt) || eventAt > Number(row.endsAt)) return { ok: false, code: 'SHIFT_PERMIT_EXPIRED_OR_NOT_STARTED' };
      if (eventAt > now + 5 * 60 * 1000) return { ok: false, code: 'SHIFT_EVENT_TIME_IN_FUTURE' };
    } else if (now > Number(row.endsAt)) {
      return { ok: false, code: 'SHIFT_PERMIT_EXPIRED' };
    }
    if (expected.deviceId && row.deviceId !== expected.deviceId) return { ok: false, code: 'SHIFT_PERMIT_DEVICE_MISMATCH' };
    if (expected.posId && row.posId !== expected.posId) return { ok: false, code: 'SHIFT_PERMIT_POS_MISMATCH' };
    if (expected.sequence != null && Number(row.sequence) !== Number(expected.sequence)) return { ok: false, code: 'SHIFT_PERMIT_SEQUENCE_MISMATCH' };
    return { ok: true, permit: { ...row.permit, signature: row.signature }, status: row.status, shiftId: row.shiftId || null };
  }
  getShiftPermitForExport(permitId, expected = {}) {
    if (!expected || typeof expected !== 'object' || Array.isArray(expected) ||
        !isDeviceId(expected.deviceId) || !isPosId(expected.posId)) {
      return { ok: false, code: 'SHIFT_PERMIT_EXPORT_SCOPE_REQUIRED' };
    }
    const checked = this.verifyShiftPermit(permitId, {
      deviceId: expected.deviceId,
      posId: expected.posId,
      forExport: true
    });
    if (!checked.ok) return checked;
    if (checked.status !== 'issued') return { ok: false, code: 'SHIFT_PERMIT_NOT_EXPORTABLE' };
    return {
      ok: true,
      permit: checked.permit,
      permitId: checked.permit.permitId,
      status: checked.status
    };
  }
  listShiftPermits(posId) {
    const rows = posId && isPosId(posId)
      ? this.db.prepare('SELECT permit_id AS permitId,pos_id AS posId,device_id AS deviceId,employee,sequence,starts_at AS startsAt,ends_at AS endsAt,status,created_by AS createdBy,created_at AS createdAt,opened_at AS openedAt FROM shift_permits WHERE pos_id=? ORDER BY created_at DESC').all(posId)
      : this.db.prepare('SELECT permit_id AS permitId,pos_id AS posId,device_id AS deviceId,employee,sequence,starts_at AS startsAt,ends_at AS endsAt,status,created_by AS createdBy,created_at AS createdAt,opened_at AS openedAt FROM shift_permits ORDER BY created_at DESC').all();
    return rows;
  }
  _findPermitId(payload) {
    if (!payload || typeof payload !== 'object') return '';
    return String(payload.shiftPermitId || payload.permitId || (payload.shift && (payload.shift.permitId || payload.shift.shiftPermitId)) || '');
  }
  checkAndRecordIncomingPackage(doc, device, payloadHash) {
    // Debe ejecutarse dentro de la transacción que inserta incoming_packages.
    if (!doc || !device) return { ok: true };
    const payload = doc.payload || {};
    const type = String(doc.type || '');
    const now = this.now();
    // La autorización permanente habilita el dispositivo para la instalación,
    // pero no concede por sí sola acceso a ningún POS. Cada operación debe señalar
    // un único POS y demostrar un permiso de turno firmado para ese POS y dispositivo.
    const deviceId = String(device.device_id || device.deviceId || doc.deviceId || '');
    const boundPosId = String(device.pos_id || device.posId || '');
    const hasInstallationAuthorization = !!(device.installation_id || device.installationId || device.authorization_id || device.authorizationId);
    let permanentAuthorization = null;
    if (hasInstallationAuthorization) {
      const authorization = this._deviceAuthorization(device);
      if (!authorization.ok) return authorization;
      permanentAuthorization = authorization.authorization;
    }
    const isInstallationWideDevice = Number(permanentAuthorization && permanentAuthorization.protocolVersion) >= 5;
    if (['shift_open', 'sale_batch', 'goods_receipt', 'return', 'shift_close', 'transfer'].includes(type)) {
      const posIds = type === 'transfer' && !hasInstallationAuthorization
        ? [boundPosId]
        : this._packagePOSIds(type, payload);
      if (!posIds.length || posIds.some(id => !isPosId(id))) return { ok: false, code: 'PACKAGE_POS_SCOPE_REQUIRED' };
      const uniquePosIds = [...new Set(posIds)];
      if (uniquePosIds.length !== 1) return { ok: false, code: 'PACKAGE_MULTIPLE_POS_NOT_ALLOWED' };
      const scopedPosId = uniquePosIds[0];
      if (isInstallationWideDevice) {
        if (boundPosId) return { ok: false, code: 'DEVICE_AUTHORIZATION_SCOPE_INVALID' };
      } else if (!boundPosId || scopedPosId !== boundPosId) {
        return { ok: false, code: 'DEVICE_POS_SCOPE_MISMATCH' };
      }
      if (type === 'transfer' && hasInstallationAuthorization) return { ok: false, code: 'TRANSFER_PERMISSION_NOT_READY' };
      const policy = this.getPOSPolicy(scopedPosId);
      if (!policy.ok || policy.mode !== 'CON_APP') return { ok: false, code: 'MOBILE_MODE_NOT_ENABLED' };
    }
    if (type === 'shift_open') {
      const permitId = this._findPermitId(payload);
      const sequence = payload.shift && payload.shift.sequence != null ? payload.shift.sequence : payload.sequence;
      const shift = payload.shift || {};
      const eventAt = shift.startedAt || shift.openedAt || payload.startedAt || doc.createdAt;
      const checked = this.verifyShiftPermit(permitId, { deviceId, posId: String(shift.posId || ''), sequence, eventAt });
      if (!checked.ok) return checked;
      if (checked.status !== 'issued') return { ok: false, code: 'SHIFT_PERMIT_ALREADY_USED' };
      if (String(shift.posId || '') !== checked.permit.posId || !shift.id) return { ok: false, code: 'SHIFT_OPEN_SCOPE_INVALID' };
      const changed = this.db.prepare(`UPDATE shift_permits SET status='open_pending_review',open_package_id=?,opened_at=?,shift_id=? WHERE permit_id=? AND status='issued'`)
        .run(doc.packageId, now, String(shift.id), permitId);
      if (!changed.changes) return { ok: false, code: 'SHIFT_PERMIT_ALREADY_USED' };
      this.db.prepare('INSERT INTO shift_permit_audit(permit_id,action,at,actor,detail_json) VALUES(?,?,?,?,?)')
        .run(permitId, 'open_received_pending_review', now, doc.deviceId, JSON.stringify({ packageId: doc.packageId, payloadHash }));
    } else if (type === 'sale_batch' || type === 'return') {
      const permitId = this._findPermitId(payload) || (() => {
        const txs = Array.isArray(payload.transactions) ? payload.transactions : [];
        const ids = [...new Set(txs.map(tx => String(tx && tx.shiftPermitId || '')).filter(Boolean))];
        return ids.length === 1 ? ids[0] : '';
      })();
      if (!permitId) return { ok: false, code: 'SHIFT_PERMIT_REQUIRED' };
      const txs = Array.isArray(payload.transactions) ? payload.transactions : [];
      if (!txs.length || txs.length > (type === 'sale_batch' ? 250 : 100)) return { ok: false, code: 'SHIFT_PERMIT_TRANSACTION_COUNT_INVALID' };
      const eventTimes = txs.map(tx => tx && (tx.ts || tx.timestamp || tx.createdAt)).filter(Boolean);
      const checked = this.verifyShiftPermit(permitId, { deviceId, posId: String(txs[0] && txs[0].posId || ''), eventAt: eventTimes.length ? eventTimes[0] : doc.createdAt });
      if (!checked.ok) return checked;
      if (checked.status !== 'opened') return { ok: false, code: 'SHIFT_OPEN_NOT_CONFIRMED' };
      if (txs.some(tx => !tx || String(tx.posId || '') !== checked.permit.posId || String(tx.shiftPermitId || '') !== permitId)) return { ok: false, code: 'SHIFT_PERMIT_TRANSACTION_SCOPE_MISMATCH' };
      const parsedTimes = [];
      for (const tx of txs) {
        const at = tx.ts || tx.timestamp || tx.createdAt || doc.createdAt;
        const when = parseTime(at);
        if (!Number.isFinite(when) || when < checked.permit.startsAt || when > checked.permit.endsAt) return { ok: false, code: 'SHIFT_PERMIT_EVENT_OUTSIDE_WINDOW' };
        parsedTimes.push(when);
      }
      if (checked.permit.emergency && checked.permit.emergency.enabled) {
        if (type === 'return') return { ok: false, code: 'EMERGENCY_RETURNS_NOT_ALLOWED' };
        const emergencyExpiry = parseTime(checked.permit.emergency.expiresAt);
        // Se comprueba la hora firmada de cada venta. Un paquete válido puede llegar
        // tarde por USB; la fecha de importación no debe reescribir el historial del turno.
        if (parsedTimes.some(when => when > emergencyExpiry)) return { ok: false, code: 'EMERGENCY_PERMIT_EXPIRED' };
        const already = this.db.prepare('SELECT payload_hash AS payloadHash,sales_count AS salesCount FROM shift_emergency_packages WHERE package_id=?').get(doc.packageId);
        if (already) return already.payloadHash === payloadHash ? { ok: true, duplicateEmergencyUsage: true } : { ok: false, code: 'PACKAGE_ID_CONFLICT' };
        const current = this.db.prepare('SELECT sales_count AS salesCount FROM shift_emergency_usage WHERE permit_id=?').get(permitId);
        const used = Number(current && current.salesCount || 0);
        const salesCount = txs.length;
        if (used + salesCount > Number(checked.permit.emergency.maxSales)) return { ok: false, code: 'EMERGENCY_SALE_LIMIT_REACHED', used, requested: salesCount, maximum: Number(checked.permit.emergency.maxSales) };
        this.db.prepare(`INSERT INTO shift_emergency_packages(package_id,permit_id,sales_count,payload_hash,received_at) VALUES(?,?,?,?,?)`)
          .run(doc.packageId, permitId, salesCount, payloadHash, now);
        this.db.prepare(`INSERT INTO shift_emergency_usage(permit_id,sales_count,updated_at) VALUES(?,?,?)
          ON CONFLICT(permit_id) DO UPDATE SET sales_count=excluded.sales_count,updated_at=excluded.updated_at`)
          .run(permitId, used + salesCount, now);
        this.db.prepare('INSERT INTO shift_permit_audit(permit_id,action,at,actor,detail_json) VALUES(?,?,?,?,?)')
          .run(permitId, 'emergency_sales_received', now, doc.deviceId, JSON.stringify({ packageId: doc.packageId, payloadHash, salesCount, usedAfter: used + salesCount, maximum: Number(checked.permit.emergency.maxSales) }));
      }
    } else if (type === 'shift_close') {
      const permitId = this._findPermitId(payload);
      const shift = payload.shift || {};
      const closeAt = shift.closedAt || shift.endedAt || payload.closedAt || doc.createdAt;
      const checked = this.verifyShiftPermit(permitId, { deviceId, posId: String(shift.posId || ''), eventAt: closeAt });
      if (!checked.ok) return checked;
      if (checked.status !== 'opened') return { ok: false, code: 'SHIFT_OPEN_NOT_CONFIRMED' };
      if (!shift.id || String(shift.posId || '') !== checked.permit.posId || !checked.shiftId || String(shift.id) !== String(checked.shiftId)) return { ok: false, code: 'SHIFT_CLOSE_SCOPE_INVALID' };
      const existing = this.db.prepare('SELECT closure_id FROM pending_closures WHERE package_id=?').get(doc.packageId);
      if (!existing) {
        this.db.prepare(`INSERT INTO pending_closures(closure_id,package_id,permit_id,pos_id,device_id,shift_id,payload_json,status,submitted_at)
          VALUES(?,?,?,?,?,?,?,'pending_confirmation',?)`)
          .run('close_' + doc.packageId, doc.packageId, permitId, checked.permit.posId, doc.deviceId, String(shift.id), JSON.stringify(payload), now);
        this.db.prepare(`UPDATE shift_permits SET status='close_pending',close_package_id=? WHERE permit_id=? AND status='opened'`).run(doc.packageId, permitId);
      }
    } else if (type === 'goods_receipt') {
      const dispatchId = String(payload.dispatchId || '');
      const posId = String(payload.posId || '');
      const confirmationCode = String(payload.confirmationCode || '');
      const itemsHash = String(payload.itemsHash || '');
      const items = Array.isArray(payload.items) ? payload.items : [];
      const receivedAt = payload.receivedAt || doc.createdAt;
      if (!/^[A-Za-z0-9:_-]{8,120}$/.test(dispatchId) ||
          !isPosId(posId) || !/^\d{8}$/.test(confirmationCode) ||
          !/^[a-f0-9]{64}$/.test(itemsHash) || !items.length || items.length > 300) {
        return { ok:false, code:'GOODS_RECEIPT_PAYLOAD_INVALID' };
      }
      const manifestRow = this.db.prepare('SELECT pos_id AS posId,items_hash AS itemsHash,confirmation_hash AS confirmationHash,manifest_json AS manifestJson,status FROM goods_dispatch_manifests WHERE dispatch_id=?').get(dispatchId);
      if (!manifestRow) return { ok:false, code:'GOODS_DISPATCH_NOT_FOUND' };
      if (manifestRow.status !== 'desktop_confirmed') {
        return { ok:false, code:'GOODS_DISPATCH_NOT_CONFIRMED_ON_DESKTOP', status:manifestRow.status };
      }
      if (manifestRow.posId !== posId || manifestRow.itemsHash !== itemsHash ||
          sha256(confirmationCode) !== manifestRow.confirmationHash ||
          sha256(stableJson(items)) !== itemsHash) {
        return { ok:false, code:'GOODS_RECEIPT_MANIFEST_MISMATCH' };
      }
      let manifest;
      try { manifest = JSON.parse(manifestRow.manifestJson); } catch (_) { return { ok:false, code:'GOODS_DISPATCH_MANIFEST_CORRUPT' }; }
      if (stableJson(manifest.items) !== stableJson(items) ||
          String(manifest.confirmationCodeHash || '') !== manifestRow.confirmationHash ||
          String(manifest.posId || '') !== posId) {
        return { ok:false, code:'GOODS_RECEIPT_CONTENT_MISMATCH' };
      }
      const receivedAtMs = parseTime(receivedAt);
      if (!Number.isFinite(receivedAtMs) ||
          receivedAtMs < Date.parse(manifest.createdAt) ||
          receivedAtMs > Number(manifest.expiresAt) ||
          this.now() > Number(manifest.expiresAt)) {
        return { ok:false, code:'GOODS_DISPATCH_EXPIRED' };
      }
      const permitId = String(payload.shiftPermitId || '');
      const checked = this.verifyShiftPermit(permitId, { deviceId, posId, eventAt:receivedAt });
      if (!checked.ok) return checked;
      if (checked.status !== 'opened') return { ok:false, code:'SHIFT_OPEN_NOT_CONFIRMED' };
      if (checked.permit.posId !== posId) return { ok:false, code:'SHIFT_PERMIT_SCOPE_MISMATCH' };
      this.db.prepare('INSERT INTO shift_permit_audit(permit_id,action,at,actor,detail_json) VALUES(?,?,?,?,?)')
        .run(permitId, 'goods_receipt_received_pending_review', now, deviceId,
          JSON.stringify({ packageId:doc.packageId,dispatchId,posId,itemsHash,payloadHash }));
      this._audit('goods_receipt_package_received', deviceId, { packageId:doc.packageId,dispatchId,posId,itemsHash });
    } else if (type === 'transfer') {
      const transfer = payload.transfer || payload;
      const transferId = String(transfer.id || doc.packageId);
      if (!transferId || transferId.length > 120) return { ok: false, code: 'TRANSFER_ID_INVALID' };
      const existingReceive = this.db.prepare('SELECT status,operation_id AS operationId,operation_hash AS operationHash,payload_json AS payloadJson FROM transfer_events WHERE transfer_id=? ORDER BY at DESC,rowid DESC LIMIT 1').get(transferId);
      const eventPayload = { packageId: doc.packageId, payloadHash, transfer };
      const operationId = `receive:${doc.packageId}`;
      const operationHash = sha256(stableJson({ transferId, status: 'received', payload: eventPayload }));
      if (existingReceive && ['cancelled','returned','reconciled'].includes(existingReceive.status)) return { ok: false, code: 'TRANSFER_ALREADY_FINALIZED' };
      if (existingReceive && existingReceive.status === 'received') {
        let prior; try { prior = JSON.parse(existingReceive.payloadJson || '{}'); } catch (_) { prior = {}; }
        if (prior.payloadHash !== payloadHash || String(prior.transfer && prior.transfer.id || '') !== transferId) return { ok: false, code: 'TRANSFER_ID_CONFLICT' };
        return { ok: false, code: 'TRANSFER_ALREADY_RECEIVED' };
      }
      if (existingReceive && !['sent','difference'].includes(existingReceive.status)) return { ok: false, code: 'TRANSFER_INVALID_INTAKE_STATE' };
      this.db.prepare('INSERT INTO transfer_events(event_id,transfer_id,status,at,actor,payload_json,operation_id,operation_hash) VALUES(?,?,?,?,?,?,?,?)')
        .run(crypto.randomUUID(), transferId, 'received', now, doc.deviceId, JSON.stringify({ ...eventPayload, previousStatus: existingReceive ? existingReceive.status : 'draft' }), operationId, operationHash);
    }
    return { ok: true };
  }
  afterPackageDecision(packageId, decision, actor) {
    const row = this.db.prepare('SELECT package_type AS type,payload_json AS payloadJson FROM incoming_packages WHERE package_id=?').get(packageId);
    if (!row) return;
    let payload; try { payload = JSON.parse(row.payloadJson); } catch (_) { return; }
    if (row.type === 'shift_open') {
      const permitId = this._findPermitId(payload);
      if (decision === 'accepted_for_reconciliation') {
        this.db.prepare(`UPDATE shift_permits SET status='opened' WHERE permit_id=? AND status='open_pending_review' AND open_package_id=?`).run(permitId, packageId);
      } else if (decision === 'rejected') {
        this.db.prepare(`UPDATE shift_permits SET status='rejected' WHERE permit_id=? AND status='open_pending_review' AND open_package_id=?`).run(permitId, packageId);
      }
      this.db.prepare('INSERT INTO shift_permit_audit(permit_id,action,at,actor,detail_json) VALUES(?,?,?,?,?)')
        .run(permitId || 'unknown', 'open_package_decision', this.now(), String(actor || 'desktop-local'), JSON.stringify({ packageId, decision }));
    }
    if (row.type === 'shift_close' && decision === 'rejected') {
      const now = this.now();
      const closure = this.db.prepare("SELECT permit_id AS permitId FROM pending_closures WHERE package_id=? AND status='pending_confirmation'").get(packageId);
      this.db.prepare(`UPDATE pending_closures SET status='rejected',decided_at=?,decided_by=?,decision_note=? WHERE package_id=? AND status='pending_confirmation'`)
        .run(now, String(actor || 'desktop-local'), 'Paquete de cierre rechazado', packageId);
      if (closure) {
        this.db.prepare(`UPDATE shift_permits SET status='opened',close_package_id=NULL WHERE permit_id=? AND status='close_pending'`).run(closure.permitId);
        this.db.prepare('INSERT INTO shift_permit_audit(permit_id,action,at,actor,detail_json) VALUES(?,?,?,?,?)')
          .run(closure.permitId, 'close_package_rejected', now, String(actor || 'desktop-local'), JSON.stringify({ packageId, decision }));
      }
    }
  }
  listPendingClosures(posId) {
    if (typeof posId !== 'string' || !isPosId(posId)) return [];
    return this.db.prepare(`SELECT c.closure_id AS closureId,c.package_id AS packageId,c.permit_id AS permitId,c.pos_id AS posId,c.device_id AS deviceId,c.shift_id AS shiftId,c.payload_json AS payloadJson,c.status,p.status AS packageStatus,c.submitted_at AS submittedAt,c.decided_at AS decidedAt,c.decided_by AS decidedBy,c.decision_note AS decisionNote
      FROM pending_closures c JOIN incoming_packages p ON p.package_id=c.package_id
      WHERE c.status='pending_confirmation' AND p.status IN ('accepted_for_reconciliation','reconciled') AND c.pos_id=? ORDER BY c.submitted_at`).all(posId).map(row => {
      try { row.payload = JSON.parse(row.payloadJson); } catch (_) { row.payload = null; }
      delete row.payloadJson;
      return row;
    });
  }
  decidePendingClosure(input, actorInput) {
    const actor = asActor(actorInput);
    const data = input && typeof input === 'object' ? input : {};
    const closureId = String(data.closureId || '');
    const decision = String(data.decision || '');
    const posId = data.posId;
    if (!/^close_[A-Za-z0-9_-]{8,100}$/.test(closureId) || !['confirmed', 'rejected'].includes(decision)) return { ok: false, code: 'INVALID_CLOSURE_DECISION' };
    if (!isPosId(posId)) return { ok: false, code: 'CLOSURE_POS_SCOPE_REQUIRED' };
    const row = this.db.prepare(`SELECT c.status,c.permit_id AS permitId,c.package_id AS packageId,c.pos_id AS posId,p.status AS packageStatus
      FROM pending_closures c JOIN incoming_packages p ON p.package_id=c.package_id WHERE c.closure_id=?`).get(closureId);
    if (!row) return { ok: false, code: 'CLOSURE_NOT_FOUND' };
    if (row.posId !== posId) return { ok: false, code: 'CLOSURE_POS_SCOPE_MISMATCH' };
    if (row.status !== 'pending_confirmation') {
      if (row.status === decision) return { ok: true, duplicate: true, closureId, status: row.status, note: 'La misma decisión ya estaba registrada.' };
      return { ok: false, code: 'CLOSURE_ALREADY_DECIDED', status: row.status };
    }
    if (row.packageStatus !== 'reconciled') return { ok: false, code: 'CLOSURE_PACKAGE_NOT_RECONCILED', note: 'Primero debes conciliar el paquete de cierre antes de aprobar o rechazar el informe.' };
    const now = this.now();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const updated = this.db.prepare(`UPDATE pending_closures SET status=?,decided_at=?,decided_by=?,decision_note=? WHERE closure_id=? AND pos_id=? AND status='pending_confirmation'`)
        .run(decision, now, actor.user, String(data.note || '').slice(0, 500), closureId, posId);
      if (!updated.changes) throw Object.assign(new Error('CLOSURE_ALREADY_DECIDED'), { code: 'CLOSURE_ALREADY_DECIDED' });
      if (decision === 'rejected') {
        const packageUpdate = this.db.prepare(`UPDATE incoming_packages SET status='rejected',ack_json=NULL WHERE package_id=? AND status='reconciled'`).run(row.packageId);
        if (!packageUpdate.changes) throw Object.assign(new Error('CLOSURE_PACKAGE_STATE_CHANGED'), { code: 'CLOSURE_PACKAGE_STATE_CHANGED' });
        this.db.prepare(`UPDATE reconciliation_jobs SET status='rejected',last_error_code='SHIFT_CLOSE_REJECTED_BY_OWNER',updated_at=? WHERE package_id=? AND status='applied'`)
          .run(now, row.packageId);
      }
      const permitUpdate = decision === 'confirmed'
        ? this.db.prepare(`UPDATE shift_permits SET status='closed' WHERE permit_id=? AND status='close_pending'`).run(row.permitId)
        : this.db.prepare(`UPDATE shift_permits SET status='opened',close_package_id=NULL WHERE permit_id=? AND status='close_pending'`).run(row.permitId);
      if (!permitUpdate.changes) throw Object.assign(new Error('SHIFT_PERMIT_NOT_CLOSE_PENDING'), { code: 'SHIFT_PERMIT_NOT_CLOSE_PENDING' });
      this.db.prepare('INSERT INTO shift_permit_audit(permit_id,action,at,actor,detail_json) VALUES(?,?,?,?,?)')
        .run(row.permitId, 'close_' + decision, now, actor.user, JSON.stringify({ closureId, packageId: row.packageId, posId: row.posId, note: String(data.note || '').slice(0, 500) }));
      this._audit('mobile_close_' + decision, actor.user, { closureId, packageId: row.packageId, posId: row.posId });
      this.db.exec('COMMIT');
      return { ok: true, closureId, status: decision, decidedAt: now, note: decision === 'confirmed' ? 'Solicitud confirmada. El conteo físico y el cierre contable siguen debiendo completarse en el escritorio.' : 'Solicitud rechazada; la caja no se modificó.' };
    } catch (error) { try { this.db.exec('ROLLBACK'); } catch (_) {} return { ok: false, code: error && error.code || 'CLOSURE_DECISION_FAILED' }; }
  }
  createPackageAcknowledgement(packageIdInput, actorInput) {
    const actor = asActor(actorInput);
    const packageId = String(packageIdInput || '');
    if (!/^[A-Za-z0-9_-]{8,100}$/.test(packageId)) return { ok: false, code: 'INVALID_PACKAGE_ID' };
    const row = this.db.prepare(`SELECT package_id AS packageId,device_id AS deviceId,package_type AS packageType,
      payload_hash AS payloadHash,status,received_at AS receivedAt,applied_at AS appliedAt
      FROM incoming_packages WHERE package_id=?`).get(packageId);
    if (!row) return { ok: false, code: 'PACKAGE_NOT_FOUND' };
    if (!['reconciled', 'rejected', 'conflict'].includes(String(row.status))) return { ok: false, code: 'ACK_REQUIRES_TERMINAL_RESULT' };
    if (row.packageType === 'shift_close') {
      const closure = this.db.prepare('SELECT status FROM pending_closures WHERE package_id=?').get(packageId);
      const expectedStatus = closure && closure.status === 'confirmed' ? 'reconciled' :
        closure && closure.status === 'rejected' ? 'rejected' : null;
      if (!expectedStatus || row.status !== expectedStatus) {
        return { ok: false, code: 'SHIFT_CLOSE_REQUIRES_OWNER_DECISION' };
      }
    }
    const existingAck = this.db.prepare('SELECT acknowledgement_json AS acknowledgementJson FROM package_acknowledgements WHERE package_id=?').get(packageId);
    if (existingAck) {
      let acknowledgement;
      try { acknowledgement = JSON.parse(existingAck.acknowledgementJson); } catch (_) { return { ok: false, code: 'ACK_STORED_INVALID' }; }
      const verified = this.verifyPackageAcknowledgement(acknowledgement);
      if (!verified.ok) return { ok: false, code: 'ACK_STORED_INVALID' };
      return { ok: true, acknowledgement, duplicate: true };
    }
    const ack = {
      format: 'procontrol.package-ack', version: 1,
      desktopId: String(this.bridge.desktopId || 'desktop-local'),
      desktopPublicKey: this.bridge.desktopPublicKey,
      deviceId: row.deviceId, packageId: row.packageId,
      packageType: row.packageType, payloadHash: row.payloadHash,
      status: row.status, result: row.status === 'reconciled' ? 'applied' : row.status,
      receivedAt: Number(row.receivedAt), appliedAt: row.appliedAt == null ? null : Number(row.appliedAt),
      acknowledgedAt: this.now()
    };
    ack.signature = { algorithm: 'Ed25519', value: crypto.sign(null, Buffer.from(stableJson(ack), 'utf8'), this.bridge.desktopPrivateKey).toString('base64') };
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const finalRow = this.db.prepare('SELECT status,payload_hash AS payloadHash,device_id AS deviceId FROM incoming_packages WHERE package_id=?').get(packageId);
      if (!finalRow || finalRow.status !== row.status || finalRow.payloadHash !== row.payloadHash || finalRow.deviceId !== row.deviceId) throw Object.assign(new Error('ACK_PACKAGE_CHANGED'), { code: 'ACK_PACKAGE_CHANGED' });
      this.db.prepare('INSERT INTO package_acknowledgements(package_id,acknowledgement_json,created_at) VALUES(?,?,?)')
        .run(packageId, JSON.stringify(ack), this.now());
      this._audit('package_acknowledgement_created', actor.user, { packageId, deviceId: row.deviceId, status: row.status, payloadHash: row.payloadHash });
      this.db.exec('COMMIT');
      return { ok: true, acknowledgement: ack };
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      if (error && error.code === 'SQLITE_CONSTRAINT_PRIMARYKEY') {
        const retry = this.db.prepare('SELECT acknowledgement_json AS acknowledgementJson FROM package_acknowledgements WHERE package_id=?').get(packageId);
        if (retry) { try { const acknowledgement = JSON.parse(retry.acknowledgementJson); if (this.verifyPackageAcknowledgement(acknowledgement).ok) return { ok: true, acknowledgement, duplicate: true }; } catch (_) {} }
      }
      return { ok: false, code: error && error.code || 'ACK_CREATE_FAILED' };
    }
  }
  listPackageAcknowledgements(limitInput = 50) {
    const limit = Math.max(1, Math.min(100, Number.isSafeInteger(Number(limitInput)) ? Number(limitInput) : 50));
    return this.db.prepare('SELECT package_id AS packageId,acknowledgement_json AS acknowledgementJson,created_at AS createdAt FROM package_acknowledgements ORDER BY created_at DESC LIMIT ?')
      .all(limit).map(row => {
        let acknowledgement = null; try { acknowledgement = JSON.parse(row.acknowledgementJson); } catch (_) {}
        return { packageId: row.packageId, result: acknowledgement && acknowledgement.result || 'unknown', createdAt: Number(row.createdAt) };
      });
  }
  verifyPackageAcknowledgement(ackInput) {
    const ack = ackInput && typeof ackInput === 'object' && !Array.isArray(ackInput) ? ackInput : null;
    if (!ack || ack.format !== 'procontrol.package-ack' || ack.version !== 1 ||
        !/^[A-Za-z0-9_-]{8,100}$/.test(String(ack.packageId || '')) ||
        !/^[a-f0-9]{64}$/.test(String(ack.payloadHash || '')) ||
        !ack.signature || ack.signature.algorithm !== 'Ed25519' || typeof ack.signature.value !== 'string') {
      return { ok: false, code: 'ACK_SCHEMA_INVALID' };
    }
    const row = this.db.prepare(`SELECT package_id AS packageId,device_id AS deviceId,package_type AS packageType,
      payload_hash AS payloadHash,status,received_at AS receivedAt,applied_at AS appliedAt
      FROM incoming_packages WHERE package_id=?`).get(ack.packageId);
    if (!row) return { ok: false, code: 'PACKAGE_NOT_FOUND' };
    if (!['reconciled', 'rejected', 'conflict'].includes(String(row.status))) return { ok: false, code: 'ACK_REQUIRES_TERMINAL_RESULT' };
    if (row.packageType === 'shift_close') {
      const closure = this.db.prepare('SELECT status FROM pending_closures WHERE package_id=?').get(row.packageId);
      const expectedStatus = closure && closure.status === 'confirmed' ? 'reconciled' :
        closure && closure.status === 'rejected' ? 'rejected' : null;
      if (!expectedStatus || row.status !== expectedStatus) {
        return { ok: false, code: 'SHIFT_CLOSE_REQUIRES_OWNER_DECISION' };
      }
    }
    if (String(ack.deviceId) !== String(row.deviceId) || String(ack.packageType) !== String(row.packageType) ||
        String(ack.payloadHash) !== String(row.payloadHash) || String(ack.status) !== String(row.status) ||
        String(ack.result) !== (row.status === 'reconciled' ? 'applied' : row.status) ||
        String(ack.desktopPublicKey || '').replace(/\r/g, '').trim() !== String(this.bridge.desktopPublicKey || '').replace(/\r/g, '').trim()) {
      return { ok: false, code: 'ACK_SCOPE_MISMATCH' };
    }
    const unsigned = { ...ack }; delete unsigned.signature;
    let signature;
    try { signature = Buffer.from(ack.signature.value, 'base64'); } catch (_) { return { ok: false, code: 'ACK_SIGNATURE_INVALID' }; }
    try {
      if (!crypto.verify(null, Buffer.from(stableJson(unsigned), 'utf8'), crypto.createPublicKey(this.bridge.desktopPublicKey), signature)) return { ok: false, code: 'ACK_SIGNATURE_INVALID' };
    } catch (_) { return { ok: false, code: 'ACK_SIGNATURE_INVALID' }; }
    return { ok: true, packageId: row.packageId, deviceId: row.deviceId, result: ack.result };
  }

  createGoodsDispatchManifest(input, actorInput) {
    const actor = asActor(actorInput);
    const data = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
    const dispatchId = String(data.dispatchId || '');
    const posId = String(data.posId || '');
    const posName = String(data.posName || '').trim();
    const rawItems = Array.isArray(data.items) ? data.items : [];
    if (!/^[A-Za-z0-9:_-]{8,120}$/.test(dispatchId) || !isPosId(posId) ||
        !posName || posName.length > 160 || !rawItems.length || rawItems.length > 300) {
      return { ok: false, code: 'GOODS_DISPATCH_INPUT_INVALID' };
    }
    const seen = new Set();
    const items = [];
    for (const row of rawItems) {
      if (!row || typeof row !== 'object' || Array.isArray(row)) return { ok:false, code:'GOODS_DISPATCH_ITEM_INVALID' };
      const productId = String(row.productId || '').trim();
      const name = String(row.name || '').trim();
      const unit = String(row.unit || '').trim().toLowerCase();
      const quantity = Number(row.quantity);
      if (!/^[A-Za-z0-9:_-]{1,160}$/.test(productId) || !name || name.length > 180 ||
          !['u','pqt','lb','kg','lt'].includes(unit) || !Number.isFinite(quantity) || quantity <= 0 || quantity > 100000000) {
        return { ok:false, code:'GOODS_DISPATCH_ITEM_INVALID' };
      }
      if (seen.has(productId)) return { ok:false, code:'GOODS_DISPATCH_DUPLICATE_PRODUCT' };
      seen.add(productId);
      const price = field => {
        const value = row[field] == null || row[field] === '' ? 0 : Number(row[field]);
        return Number.isFinite(value) && value >= 0 && value <= 1000000000 ? value : NaN;
      };
      const sale = price('sale');
      const saleTransf = price('saleTransf');
      const saleUSD = price('saleUSD');
      if (![sale,saleTransf,saleUSD].every(Number.isFinite)) return { ok:false, code:'GOODS_DISPATCH_PRICE_INVALID' };
      const saleCurrency = String(row.saleCurrency || 'USD').trim().toUpperCase();
      const saleCustomCurrency = String(row.saleCustomCurrency || '').trim().replace(/\s+/g,' ').slice(0,40);
      if (!['USD','EUR','MLC','OTRA'].includes(saleCurrency) ||
          (saleCurrency === 'OTRA' && (!saleCustomCurrency || ['CUP','USD','EUR','MLC','OTRA'].includes(saleCustomCurrency.toUpperCase())))) {
        return { ok:false, code:'GOODS_DISPATCH_CURRENCY_INVALID' };
      }
      const saleTransfMode = ['percentage','manual'].includes(String(row.saleTransfMode || '')) ? String(row.saleTransfMode) : null;
      const percent = row.saleTransfPercent == null ? null : Number(row.saleTransfPercent);
      if (percent != null && (!Number.isFinite(percent) || percent < 0 || percent > 100)) return { ok:false, code:'GOODS_DISPATCH_TRANSFER_PERCENT_INVALID' };
      const aliases = Array.isArray(row.aliases) ? row.aliases.map(x => String(x || '').trim().slice(0,100)).filter(Boolean).slice(0,50) : [];
      items.push({
        productId, name, family: String(row.family || '').trim().slice(0,80), unit,
        quantity, sale, saleTransf, saleTransfMode, saleTransfPercent: saleTransfMode === 'percentage' ? percent : null,
        saleUSD, saleCurrency, saleCustomCurrency, aliases
      });
    }
    const itemsHash = sha256(stableJson(items));
    const existing = this.db.prepare('SELECT pos_id AS posId,items_hash AS itemsHash,confirmation_hash AS confirmationHash,confirmation_code_data AS confirmationCodeData,manifest_json AS manifestJson,status FROM goods_dispatch_manifests WHERE dispatch_id=?').get(dispatchId);
    if (existing) {
      if (existing.posId !== posId || existing.itemsHash !== itemsHash) return { ok:false, code:'GOODS_DISPATCH_ID_CONFLICT' };
      let manifest;
      let confirmationCode;
      try {
        manifest = JSON.parse(existing.manifestJson);
        if (existing.confirmationCodeData) {
          confirmationCode = this._decodeDispatchConfirmationCode(existing.confirmationCodeData);
        } else if (manifest.confirmationCode && /^\d{8}$/.test(String(manifest.confirmationCode))) {
          // One-time migration for a development manifest created before the
          // confirmation code was removed from the signed QR payload.
          confirmationCode = String(manifest.confirmationCode);
          const unsigned = { ...manifest };
          delete unsigned.signature;
          delete unsigned.confirmationCode;
          unsigned.confirmationCodeHash = sha256(confirmationCode);
          const signature = crypto.sign(null, Buffer.from(stableJson(unsigned),'utf8'), this.bridge.desktopPrivateKey).toString('base64');
          manifest = { ...unsigned, signature:{ algorithm:'Ed25519', value:signature } };
          const migratedJson = JSON.stringify(manifest,null,2);
          const confirmationCodeData = this._encodeDispatchConfirmationCode(confirmationCode);
          this.db.prepare('UPDATE goods_dispatch_manifests SET confirmation_hash=?,confirmation_code_data=?,manifest_json=? WHERE dispatch_id=?')
            .run(sha256(confirmationCode),confirmationCodeData,migratedJson,dispatchId);
          return { ok:true, duplicate:true, manifest, manifestJson:migratedJson, confirmationCode, itemsHash, status:existing.status };
        } else {
          throw new Error('GOODS_DISPATCH_CONFIRMATION_UNAVAILABLE');
        }
      } catch (_) { return { ok:false, code:'GOODS_DISPATCH_RECORD_CORRUPT' }; }
      return { ok:true, duplicate:true, manifest, manifestJson:existing.manifestJson,
        confirmationCode, itemsHash, status:existing.status };
    }

    const now = this.now();
    const confirmationCode = String(crypto.randomInt(0,100000000)).padStart(8,'0');
    const confirmationHash = sha256(confirmationCode);
    const confirmationCodeData = this._encodeDispatchConfirmationCode(confirmationCode);
    const unsigned = {
      format:'procontrol.goods-dispatch', version:1,
      installationId:this.bridge.getInstallationId(),
      desktopId:this.deviceId,
      dispatchId, posId, posName,
      createdAt:new Date(now).toISOString(),
      expiresAt:now + 24 * 60 * 60 * 1000,
      itemsHash, confirmationCodeHash:confirmationHash, items,
      desktopPublicKey:this.bridge.desktopPublicKey
    };
    const signature = crypto.sign(null, Buffer.from(stableJson(unsigned),'utf8'), this.bridge.desktopPrivateKey).toString('base64');
    const manifest = Object.assign({}, unsigned, { signature:{ algorithm:'Ed25519', value:signature } });
    const manifestJson = JSON.stringify(manifest,null,2);
    // Version 4-L QR fragments carry at most 40 raw bytes each; 99 frames
    // therefore cap the signed manifest at 3,960 UTF-8 bytes.
    if (Buffer.byteLength(manifestJson,'utf8') > 3960) return { ok:false, code:'GOODS_DISPATCH_QR_TOO_LARGE' };
    this.db.prepare("INSERT INTO goods_dispatch_manifests(dispatch_id,pos_id,items_hash,confirmation_hash,confirmation_code_data,manifest_json,status,created_at) VALUES(?,?,?,?,?,?,'issued',?)")
      .run(dispatchId,posId,itemsHash,confirmationHash,confirmationCodeData,manifestJson,now);
    this._audit('goods_dispatch_manifest_issued',actor.user,{dispatchId,posId,itemsHash,itemCount:items.length});
    return { ok:true, duplicate:false, manifest, manifestJson, confirmationCode, itemsHash, status:'issued' };
  }

  cancelGoodsDispatchManifest(input, actorInput) {
    const actor = asActor(actorInput);
    const data = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
    const dispatchId = String(data.dispatchId || '');
    if (!/^[A-Za-z0-9:_-]{8,120}$/.test(dispatchId)) return { ok:false, code:'GOODS_DISPATCH_ID_INVALID' };
    const row = this.db.prepare('SELECT status,pos_id AS posId FROM goods_dispatch_manifests WHERE dispatch_id=?').get(dispatchId);
    if (!row) return { ok:false, code:'GOODS_DISPATCH_NOT_FOUND' };
    if (row.status === 'void') return { ok:true, duplicate:true, dispatchId, status:'void' };
    if (row.status !== 'issued') return { ok:false, code:'GOODS_DISPATCH_ALREADY_EXPOSED', status:row.status };
    const updated = this.db.prepare("UPDATE goods_dispatch_manifests SET status='void' WHERE dispatch_id=? AND status='issued'").run(dispatchId);
    if (updated.changes !== 1) return { ok:false, code:'GOODS_DISPATCH_STATE_CHANGED' };
    this._audit('goods_dispatch_manifest_voided',actor.user,{dispatchId,posId:row.posId});
    return { ok:true, duplicate:false, dispatchId, status:'void' };
  }

  confirmGoodsDispatch(input, actorInput) {
    const actor = asActor(actorInput);
    const data = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
    const dispatchId = String(data.dispatchId || '');
    const code = String(data.confirmationCode || '').trim();
    if (!/^[A-Za-z0-9:_-]{8,120}$/.test(dispatchId) || !/^\d{8}$/.test(code)) {
      return { ok:false, code:'GOODS_DISPATCH_CONFIRMATION_INPUT_INVALID' };
    }
    const row = this.db.prepare('SELECT confirmation_hash AS confirmationHash,status,pos_id AS posId,manifest_json AS manifestJson FROM goods_dispatch_manifests WHERE dispatch_id=?').get(dispatchId);
    if (!row) return { ok:false, code:'GOODS_DISPATCH_NOT_FOUND' };
    let manifest;
    try { manifest = JSON.parse(row.manifestJson); } catch (_) { return { ok:false, code:'GOODS_DISPATCH_MANIFEST_CORRUPT' }; }
    if (!Number.isFinite(Number(manifest.expiresAt)) || Number(manifest.expiresAt) <= this.now()) {
      return { ok:false, code:'GOODS_DISPATCH_EXPIRED' };
    }
    const actual = Buffer.from(sha256(code),'hex');
    const expected = Buffer.from(String(row.confirmationHash || ''),'hex');
    if (expected.length !== actual.length || !crypto.timingSafeEqual(expected,actual)) {
      this._audit('goods_dispatch_confirmation_mismatch',actor.user,{dispatchId,posId:row.posId});
      return { ok:false, code:'GOODS_DISPATCH_CONFIRMATION_MISMATCH' };
    }
    if (row.status === 'desktop_confirmed' || row.status === 'mobile_confirmed' || row.status === 'reconciled') {
      return { ok:true, duplicate:true, dispatchId, posId:row.posId, status:row.status };
    }
    if (row.status !== 'issued') return { ok:false, code:'GOODS_DISPATCH_NOT_CONFIRMABLE', status:row.status };
    const now = this.now();
    const updated = this.db.prepare("UPDATE goods_dispatch_manifests SET status='desktop_confirmed',desktop_confirmed_at=?,desktop_confirmed_by=? WHERE dispatch_id=? AND status='issued'")
      .run(now,actor.user,dispatchId);
    if (updated.changes !== 1) return { ok:false, code:'GOODS_DISPATCH_STATE_CHANGED' };
    this._audit('goods_dispatch_desktop_confirmed',actor.user,{dispatchId,posId:row.posId});
    return { ok:true, duplicate:false, dispatchId, posId:row.posId, status:'desktop_confirmed', confirmedAt:now };
  }

  listTransferHistory(transferId) {
    if (transferId && typeof transferId !== 'string') return [];
    return this.db.prepare(`SELECT event_id AS eventId,transfer_id AS transferId,status,at,actor,payload_json AS payloadJson,operation_id AS operationId FROM transfer_events ${transferId ? 'WHERE transfer_id=?' : ''} ORDER BY at DESC,rowid DESC LIMIT 1000`)
      .all(...(transferId ? [transferId] : [])).map(row => { try { row.payload = JSON.parse(row.payloadJson); } catch (_) { row.payload = null; } delete row.payloadJson; return row; });
  }
  recordTransferStatus(input, actorInput) {
    const actor = asActor(actorInput);
    const data = input && typeof input === 'object' ? input : {};
    const transferId = String(data.transferId || '');
    const nextStatus = String(data.status || '');
    const operationId = String(data.operationId || '').trim();
    if (!transferId || transferId.length > 120 || !['sent','received','difference','cancelled','returned','reconciled'].includes(nextStatus)) return { ok: false, code: 'INVALID_TRANSFER_STATE' };
    if (!/^[A-Za-z0-9:_-]{8,160}$/.test(operationId)) return { ok: false, code: 'IDEMPOTENCY_KEY_REQUIRED' };
    const payload = data.payload && typeof data.payload === 'object' && !Array.isArray(data.payload) ? data.payload : {};
    let requestHash;
    try { requestHash = sha256(stableJson({ transferId, status: nextStatus, payload })); } catch (_) { return { ok: false, code: 'TRANSFER_PAYLOAD_INVALID' }; }
    const now = this.now();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const previousOperation = this.db.prepare('SELECT event_id AS eventId,transfer_id AS transferId,status,operation_hash AS operationHash FROM transfer_events WHERE operation_id=?').get(operationId);
      if (previousOperation) {
        if (previousOperation.transferId === transferId && previousOperation.status === nextStatus && previousOperation.operationHash === requestHash) {
          this.db.exec('COMMIT');
          return { ok: true, duplicate: true, eventId: previousOperation.eventId, transferId, status: nextStatus };
        }
        throw Object.assign(new Error('IDEMPOTENCY_KEY_CONFLICT'), { code: 'IDEMPOTENCY_KEY_CONFLICT' });
      }
      const current = this.db.prepare('SELECT status FROM transfer_events WHERE transfer_id=? ORDER BY at DESC,rowid DESC LIMIT 1').get(transferId);
      const previous = current ? current.status : 'draft';
      const allowed = {
        draft: new Set(['sent','cancelled']),
        sent: new Set(['received','difference','cancelled']),
        received: new Set(['reconciled','difference','returned']),
        difference: new Set(['received','cancelled','returned']),
        cancelled: new Set(), returned: new Set(), reconciled: new Set(['difference'])
      };
      if (!allowed[previous] || !allowed[previous].has(nextStatus)) throw Object.assign(new Error('INVALID_TRANSFER_TRANSITION'), { code: 'INVALID_TRANSFER_TRANSITION', previous, nextStatus });
      const eventId = crypto.randomUUID();
      this.db.prepare('INSERT INTO transfer_events(event_id,transfer_id,status,at,actor,payload_json,operation_id,operation_hash) VALUES(?,?,?,?,?,?,?,?)')
        .run(eventId, transferId, nextStatus, now, actor.user, stableJson({ ...payload, previousStatus: previous }), operationId, requestHash);
      this._audit('transfer_status_' + nextStatus, actor.user, { transferId, previous, nextStatus, eventId, operationId });
      this.db.exec('COMMIT');
      return { ok: true, eventId, transferId, previous, status: nextStatus, at: now };
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch (_) {}
      return { ok: false, code: error && error.code || 'TRANSFER_STATUS_FAILED', previous: error && error.previous, nextStatus };
    }
  }
  afterPackageApplied(packageId, actor = 'desktop-local') {
    const row = this.db.prepare('SELECT package_type AS type,payload_hash AS payloadHash,payload_json AS payloadJson FROM incoming_packages WHERE package_id=?').get(packageId);
    if (!row) return { ok: true, skipped: true };
    if (row.type === 'goods_receipt') {
      let payload;
      try { payload = JSON.parse(row.payloadJson); } catch (_) { return { ok:false, code:'GOODS_RECEIPT_PAYLOAD_INVALID' }; }
      const dispatchId = String(payload.dispatchId || '');
      const dispatch = this.db.prepare('SELECT status,pos_id AS posId,items_hash AS itemsHash FROM goods_dispatch_manifests WHERE dispatch_id=?').get(dispatchId);
      if (!dispatch || dispatch.posId !== String(payload.posId || '') || dispatch.itemsHash !== String(payload.itemsHash || '')) {
        return { ok:false, code:'GOODS_RECEIPT_DISPATCH_MISMATCH' };
      }
      if (dispatch.status === 'reconciled') return { ok:true, duplicate:true, dispatchId };
      if (dispatch.status !== 'desktop_confirmed') return { ok:false, code:'GOODS_DISPATCH_NOT_CONFIRMED_ON_DESKTOP' };
      this.db.prepare("UPDATE goods_dispatch_manifests SET status='reconciled' WHERE dispatch_id=? AND status='desktop_confirmed'").run(dispatchId);
      this._audit('goods_dispatch_mobile_receipt_reconciled', actor, { packageId,dispatchId,posId:dispatch.posId,itemsHash:dispatch.itemsHash,payloadHash:row.payloadHash });
      return { ok:true, dispatchId, status:'reconciled' };
    }
    if (row.type !== 'transfer') return { ok: true, skipped: true };
    let payload;
    try { payload = JSON.parse(row.payloadJson); } catch (_) { return { ok: false, code: 'TRANSFER_PAYLOAD_INVALID' }; }
    const transfer = payload.transfer || payload;
    const transferId = String(transfer.id || packageId);
    const last = this.db.prepare('SELECT event_id AS eventId,status,payload_json AS payloadJson FROM transfer_events WHERE transfer_id=? ORDER BY at DESC,rowid DESC LIMIT 1').get(transferId);
    if (!last) return { ok: false, code: 'TRANSFER_HISTORY_MISSING' };
    if (last.status === 'reconciled') return { ok: true, duplicate: true, transferId };
    if (last.status === 'difference') {
      this._audit('transfer_package_applied_with_difference', actor, { packageId, transferId, payloadHash: row.payloadHash });
      return { ok: true, discrepancyPreserved: true, transferId };
    }
    if (last.status !== 'received') return { ok: false, code: 'TRANSFER_NOT_READY_TO_RECONCILE' };
    const operationId = `apply:${packageId}`;
    const eventPayload = { packageId, payloadHash: row.payloadHash, transferId };
    const operationHash = sha256(stableJson({ transferId, status: 'reconciled', payload: eventPayload }));
    this.db.prepare('INSERT INTO transfer_events(event_id,transfer_id,status,at,actor,payload_json,operation_id,operation_hash) VALUES(?,?,?,?,?,?,?,?)')
      .run(crypto.randomUUID(), transferId, 'reconciled', this.now(), String(actor || 'desktop-local'), JSON.stringify({ ...eventPayload, previousStatus: last.status }), operationId, operationHash);
    this._audit('transfer_status_reconciled', actor, { packageId, transferId, previous: last.status, payloadHash: row.payloadHash });
    return { ok: true, transferId, status: 'reconciled' };
  }

}

module.exports = { MobileControlPlane, POS_MODES, stableJson, isPosId, isDeviceId, sha256, ADMIN_ROLES };
