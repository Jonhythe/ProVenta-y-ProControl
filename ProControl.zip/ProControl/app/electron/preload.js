
 // ============================================================
 // PROCONTROL - PRELOAD
 // ============================================================
 // Inyecta window.procontrolDB: la capa de almacenamiento que el
 // HTML de ProControl ya espera.
 // Motor: SQLite integrado de Node (node:sqlite).
 // ============================================================
 const { contextBridge, ipcRenderer } = require('electron');

 let backend = null;

 function validateUniqueStoreEntries(entries) {
   if (!Array.isArray(entries)) throw new Error('STORE_ENTRIES_INVALID');
   const seen = new Set();
   for (const entry of entries) {
     if (!Array.isArray(entry) || entry.length !== 2) throw new Error('STORE_ENTRY_INVALID');
     const key = String(entry[0] == null ? '' : entry[0]);
     if (!key) throw new Error('STORE_KEY_REQUIRED');
     if (seen.has(key)) throw new Error('STORE_KEY_DUPLICATE');
     seen.add(key);
   }
 }

 // ---------- Motor 1: SQLite ----------
 function makeSqliteBackend() {
   const { DatabaseSync } = require('node:sqlite');
   const dbPath = ipcRenderer.sendSync('pc:db-path');
   const db = new DatabaseSync(dbPath);

   db.exec('CREATE TABLE IF NOT EXISTS store (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
   db.exec('PRAGMA journal_mode = WAL;');

   const stmtGet = db.prepare('SELECT value FROM store WHERE key = ?');
   const stmtSet = db.prepare(
     'INSERT INTO store (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
   );
   const stmtDel = db.prepare('DELETE FROM store WHERE key = ?');
   const stmtKeys = db.prepare('SELECT key FROM store ORDER BY key');
   const stmtClear = db.prepare('DELETE FROM store');
   const authorizeLedgerIfChanged = (nextRaw) => {
     const current = stmtGet.get('elite_sales_ledger');
     const previousRaw = current ? current.value : null;
     const normalizedNext = nextRaw == null ? null : String(nextRaw);
     if (previousRaw === normalizedNext) return;
     const approval = ipcRenderer.sendSync('mobile-control:authorize-sales-ledger-write', normalizedNext);
     if (!approval || approval.ok !== true) {
       const error = new Error('El proceso principal rechazó el cambio del libro de ventas (' + String(approval && approval.code || 'POS_POLICY_UNAVAILABLE') + ').');
       error.code = String(approval && approval.code || 'POS_POLICY_UNAVAILABLE');
       throw error;
     }
   };

   return {
     getItem: (k) => {
       const r = stmtGet.get(String(k));
       return r ? r.value : null;
     },
     setItem: (k, v) => {
       const key = String(k);
       const value = String(v == null ? '' : v);
       if (key === 'elite_sales_ledger') authorizeLedgerIfChanged(value);
       stmtSet.run(key, value);
     },
     removeItem: (k) => {
       const key = String(k);
       if (key === 'elite_sales_ledger') authorizeLedgerIfChanged(null);
       stmtDel.run(key);
     },
     keys: () => stmtKeys.all().map((row) => row.key),
     key: (i) => {
       const ks = stmtKeys.all();
       return i >= 0 && i < ks.length ? ks[i].key : null;
     },
     get length() {
       return stmtKeys.all().length;
     },
     clear: () => {
       authorizeLedgerIfChanged(null);
       stmtClear.run();
     },
     // Operación excepcional: el proceso principal vuelve a autenticar al Dueño
     // antes de borrar el almacén completo. No se reutiliza para guardados normales.
     wipeAll: (credentials) => ipcRenderer.sendSync('pc:store-wipe-owner', credentials || {}),
     setMany: (entries) => {
       if (!Array.isArray(entries)) return;
       validateUniqueStoreEntries(entries);
       const ledgerEntry = entries.find((entry) => String(entry[0]) === 'elite_sales_ledger');
       if (ledgerEntry) authorizeLedgerIfChanged(ledgerEntry[1]);
       db.exec('BEGIN');
       try {
         for (const [k, v] of entries) {
           stmtSet.run(String(k), String(v == null ? '' : v));
         }
         db.exec('COMMIT');
       } catch (e) {
         try {
           db.exec('ROLLBACK');
         } catch (_) {}
         throw e;
       }
     }
   };
 }

 // ---------- Motor 2: respaldo JSON por IPC ----------
 function makeMemoryBackend() {
   let data = {};
   let loaded = false;

   const load = () => {
     if (!loaded) {
       data = ipcRenderer.sendSync('pc:store-load') || {};
       loaded = true;
     }
   };

   const save = (nextData) => {
     const candidate = nextData && typeof nextData === 'object' ? nextData : {};
     const saved = ipcRenderer.sendSync('pc:store-save', candidate);
     if (saved !== true) {
       throw new Error('No se pudo guardar el almacén JSON de ProControl; el proceso principal rechazó el cambio.');
     }
     data = candidate;
   };

   return {
     getItem: (k) => {
       load();
       return Object.prototype.hasOwnProperty.call(data, String(k))
         ? data[String(k)]
         : null;
     },
     setItem: (k, v) => {
       load();
       const candidate = { ...data, [String(k)]: String(v == null ? '' : v) };
       save(candidate);
     },
     removeItem: (k) => {
       load();
       const candidate = { ...data };
       delete candidate[String(k)];
       save(candidate);
     },
     keys: () => {
       load();
       return Object.keys(data).sort();
     },
     key: (i) => {
       load();
       const ks = Object.keys(data).sort();
       return i >= 0 && i < ks.length ? ks[i] : null;
     },
     get length() {
       load();
       return Object.keys(data).length;
     },
     clear: () => {
       load();
       save({});
     },
     wipeAll: (credentials) => {
       const result = ipcRenderer.sendSync('pc:store-wipe-owner', credentials || {});
       if (result && result.ok === true) { data = {}; loaded = true; }
       return result || { ok: false, code: 'STORE_WIPE_NO_RESPONSE' };
     },
     setMany: (entries) => {
       if (!Array.isArray(entries)) return;
       validateUniqueStoreEntries(entries);
       load();
       const candidate = { ...data };
       for (const [k, v] of entries) candidate[String(k)] = String(v == null ? '' : v);
       save(candidate);
     }
   };
 }

 let engineName = 'desconocido';

 try {
   backend = makeSqliteBackend();
   engineName = 'SQLite';
 } catch (e) {
   console.warn(
     '[ProControl] SQLite no disponible (' + (e && e.message) +
     '), usando backend JSON (más lento)'
   );
   backend = makeMemoryBackend();
   engineName = 'JSON';
 }

 // API de almacenamiento utilizada por el HTML
 contextBridge.exposeInMainWorld('procontrolDB', backend);

 // Información del entorno
 contextBridge.exposeInMainWorld('ProControlDesktop', {
   platform: 'electron',
   isDesktop: true,
   storage: engineName
 });

 // API de integración móvil (estructura local preparada; transporte aún no activado).
 contextBridge.exposeInMainWorld('PCMobileBridge', {
   status: () => ipcRenderer.invoke('mobile-bridge:status'),
   createPairingCode: (input) => ipcRenderer.invoke('mobile-bridge:create-pairing-code', input),
   pairDevice: (input) => ipcRenderer.invoke('mobile-bridge:pair-device', input),
   listDevices: () => ipcRenderer.invoke('mobile-bridge:list-devices'),
   setDeviceEnabled: (input) => ipcRenderer.invoke('mobile-bridge:set-device-enabled', input),
   receiveSignedBundle: (input) => ipcRenderer.invoke('mobile-bridge:receive-package', input),
   listPendingPackages: () => ipcRenderer.invoke('mobile-bridge:list-pending'),
   getPackage: (packageId) => ipcRenderer.invoke('mobile-bridge:get-package', packageId),
   decidePackage: (input) => ipcRenderer.invoke('mobile-bridge:decide-package', input),
  importFile: (input) => ipcRenderer.invoke('mobile-bridge:import-file', input),
  exportDesktopPackage: (input) => ipcRenderer.invoke('mobile-bridge:export-desktop-package', input),
  exportDesktopFragments: (input) => ipcRenderer.invoke('mobile-bridge:export-package-fragments', input),
  exportPairingDescriptor: (input) => ipcRenderer.invoke('mobile-bridge:export-pairing-descriptor', input),
  beginPackageApply: (input) => ipcRenderer.invoke('mobile-bridge:begin-package-apply', input),
  failPackageApply: (input) => ipcRenderer.invoke('mobile-bridge:fail-package-apply', input),
  markPackageApplied: (input) => ipcRenderer.invoke('mobile-bridge:mark-package-applied', input),
  authorizeControl: (input) => ipcRenderer.invoke('mobile-control:authorize', input),
  authorizeOwnerControl: (input) => ipcRenderer.invoke('mobile-control:authorize-owner', input),
  registerAccount: (input) => ipcRenderer.invoke('auth:register-account', input),
  recoverUsername: (input) => ipcRenderer.invoke('auth:recover-username', input),
  revokeControlSession: (input) => ipcRenderer.invoke('mobile-control:revoke-session', input),
  proventaCreateDeviceAuthorization: (input) => ipcRenderer.invoke('proventa:create-device-authorization', input),
  proventaGenerateActivationCodeFromPvid: (input) => ipcRenderer.invoke('proventa:generate-activation-code-from-pvid', input),
  proventaIssueDeviceRenewalCode: (input) => ipcRenderer.invoke('proventa:issue-device-renewal-code', input),
  proventaConfirmDeviceAuthorization: (input) => ipcRenderer.invoke('proventa:confirm-device-authorization', input),
  proventaListDeviceAuthorizationHistory: (input) => ipcRenderer.invoke('proventa:list-device-authorization-history', input),
  proventaListDeviceAuthorizations: (input) => ipcRenderer.invoke('proventa:list-device-authorizations', input),
  proventaRevokeDeviceAuthorization: (input) => ipcRenderer.invoke('proventa:revoke-device-authorization', input),
  proventaImportDeviceEnrollment: (input) => ipcRenderer.invoke('proventa:import-device-enrollment', input),
  proventaGetDeviceAuthorizationDescriptor: (input) => ipcRenderer.invoke('proventa:get-device-authorization-descriptor', input),
  proventaExportDeviceAuthorization: (input) => ipcRenderer.invoke('proventa:export-device-authorization', input),
  proventaListExportTargets: (input) => ipcRenderer.invoke('proventa:list-export-targets', input),
  proventaExportInventorySnapshot: (input) => ipcRenderer.invoke('proventa:export-inventory-snapshot', input),
  listPOSPolicy: (input) => ipcRenderer.invoke('mobile-control:list-pos-policy', input),
  setPOSMode: (input) => ipcRenderer.invoke('mobile-control:set-pos-mode', input),
  installPOSLicense: (input) => ipcRenderer.invoke('mobile-control:install-pos-license', input),
  enablePOSLicensing: (input) => ipcRenderer.invoke('mobile-control:enable-pos-licensing', input),
  canDesktopSell: (input) => ipcRenderer.invoke('mobile-control:can-desktop-sell', input),
  issueShiftPermit: (input) => ipcRenderer.invoke('mobile-control:issue-shift-permit', input),
  exportShiftPermit: (input) => ipcRenderer.invoke('mobile-control:export-shift-permit', input),
  exportShiftOpeningBundle: (input) => ipcRenderer.invoke('mobile-control:export-shift-opening-bundle', input),
  listShiftPermits: (input) => ipcRenderer.invoke('mobile-control:list-shift-permits', input),
  listPendingClosures: (input) => ipcRenderer.invoke('mobile-control:list-pending-closures', input),
  decidePendingClosure: (input) => ipcRenderer.invoke('mobile-control:decide-pending-closure', input),
  listPackageAcknowledgements: (input) => ipcRenderer.invoke('mobile-control:list-package-acks', input),
  createPackageAcknowledgement: (input) => ipcRenderer.invoke('mobile-control:create-package-ack', input),
  savePackageAcknowledgement: (input) => ipcRenderer.invoke('mobile-control:save-package-ack', input),
  listTransferHistory: (input) => ipcRenderer.invoke('mobile-control:list-transfer-history', input),
  recordTransferStatus: (input) => ipcRenderer.invoke('mobile-control:record-transfer-status', input),
  createGoodsDispatchManifest: (input) => ipcRenderer.invoke('mobile-control:create-goods-dispatch-manifest', input),
  confirmGoodsDispatch: (input) => ipcRenderer.invoke('mobile-control:confirm-goods-dispatch', input),
  cancelGoodsDispatchManifest: (input) => ipcRenderer.invoke('mobile-control:cancel-goods-dispatch-manifest', input),
  checkRecordArchiveStartup: () => ipcRenderer.invoke('record-archive:startup-check'),
  listRecordArchiveFiles: (input) => ipcRenderer.invoke('record-archive:list-files', input),
  readRecordArchiveFile: (input) => ipcRenderer.invoke('record-archive:read-file', input),
  writeRecordArchiveFile: (input) => ipcRenderer.invoke('record-archive:write-file', input),
  inspectRecordArchiveFiles: (input) => ipcRenderer.invoke('record-archive:inspect', input),
  deleteSupersededRecordArchiveFile: (input) => ipcRenderer.invoke('record-archive:delete-superseded', input)
 });

 // Cierre de la aplicación
 contextBridge.exposeInMainWorld('PCApp', {
   exit: () => ipcRenderer.invoke('app:exit-now')
 });

 // APIs de licencia
 contextBridge.exposeInMainWorld('PCLicense', {
   status: () => ipcRenderer.invoke('license:status'),
   activateText: (text) => ipcRenderer.invoke('license:activate-text', text),
   activateFile: () => ipcRenderer.invoke('license:activate-file'),
   finish: () => ipcRenderer.invoke('license:done'),
   openSupport: () => ipcRenderer.invoke('license:open-support'),
   copyDeviceId: () => ipcRenderer.invoke('license:copy-device'),
   finishSplash: () => ipcRenderer.invoke('splash:done')
 });
