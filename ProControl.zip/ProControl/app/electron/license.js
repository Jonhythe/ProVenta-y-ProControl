// ============================================================
// PROCONTROL - LICENCIAS (proceso principal)
// ============================================================
// Licencias 100% offline firmadas con Ed25519.
//
// - La app SOLO lleva la clave PUBLICA (license-config.js).
// - La clave PRIVADA vive en licensor/private/license_private.pem
//   y jamas se empaqueta.
// - license.dat = { "license": "PCL1.<payload>.<firma>" }
//   y se vuelve a verificar en CADA arranque.
//
// Este archivo NO implementa criptografia: delega en node:crypto
// (a traves de license-core.js) y en el MachineGuid de Windows.
// ============================================================
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

const config = require('./license-config');
const core = require('./license-core');

const LICENSE_FILE = 'license.dat';
const LEGACY_BACKUP = 'license.dat.old-hmac';
const CLOCK_STATE_FILE = 'license-clock-state.json';
const CLOCK_ROLLBACK_TOLERANCE_MS = 5 * 60 * 1000;
const MAX_LIC_FILE_BYTES = 4096;

// Identificador leido UNA sola vez con exito y memorizado.
let cachedDeviceId = null;
// Ultimo resultado de verificacion (para que status() explique el motivo).
let lastResult = null;

function idError(message) {
  const err = new Error(message || core.MESSAGES.ID_ILEGIBLE);
  err.code = 'ID_ILEGIBLE';
  return err;
}

// ---------- Identidad de la maquina (MachineGuid) ----------
function readMachineGuid() {
  const winDir = process.env.SystemRoot || process.env.windir || 'C:\\Windows';
  const regExe = path.join(winDir, 'System32', 'reg.exe');
  let out;
  try {
    out = execFileSync(regExe, [
      'query',
      'HKLM\\SOFTWARE\\Microsoft\\Cryptography',
      '/v',
      'MachineGuid'
    ], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 5000
    });
  } catch (_) {
    throw idError();
  }
  const m = /REG_SZ\s+(\S+)/i.exec(String(out));
  if (!m) throw idError();
  const clean = m[1].trim().toUpperCase().replace(/[^0-9A-F]/g, '');
  if (clean.length !== 32) throw idError();
  return clean;
}

// Si falla la lectura NO se memoriza el fallo: el proximo intento vuelve a leer.
function getDeviceId() {
  if (cachedDeviceId) return cachedDeviceId;
  cachedDeviceId = readMachineGuid();
  return cachedDeviceId;
}

// ---------- Rutas ----------
function userDataPath() {
  try {
    const electron = require('electron');
    if (electron && electron.app && typeof electron.app.getPath === 'function') {
      return electron.app.getPath('userData');
    }
  } catch (_) { /* fuera de Electron (pruebas) */ }
  const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  return path.join(appData, 'ProControl');
}

function licensePath() {
  return path.join(userDataPath(), LICENSE_FILE);
}

function clockStatePath() {
  return path.join(userDataPath(), CLOCK_STATE_FILE);
}

// Proteccion local de mejor esfuerzo contra retroceso del reloj durante trials.
// No es antimanipulacion criptografica: un usuario con control total del equipo
// puede borrar datos locales. Evita, sin embargo, el retroceso accidental/comun.
function checkAndUpdateTrialClock(now) {
  const current = Number(now);
  if (!Number.isFinite(current)) return { ok: false, code: 'RELOJ_RETROCEDIDO', error: core.MESSAGES.RELOJ_RETROCEDIDO };
  const file = clockStatePath();
  let previous = null;
  try {
    const state = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (state && Number.isFinite(state.lastSeen)) previous = state.lastSeen;
  } catch (_) { /* primer uso o estado ausente/dañado */ }
  if (previous !== null && current < previous - CLOCK_ROLLBACK_TOLERANCE_MS) {
    return { ok: false, code: 'RELOJ_RETROCEDIDO', error: core.MESSAGES.RELOJ_RETROCEDIDO };
  }
  if (previous === null || current > previous) {
    try { writeAtomic(file, JSON.stringify({ v: 1, lastSeen: current })); }
    catch (_) { /* no bloquear licencia legitima si el disco no permite guardar */ }
  }
  return { ok: true };
}

// ---------- Verificacion ----------
function verifyText(text, expectedType = 'installation') {
  let deviceId;
  try {
    deviceId = getDeviceId();
  } catch (_) {
    return { ok: false, code: 'ID_ILEGIBLE', error: core.MESSAGES.ID_ILEGIBLE };
  }
  const now = Date.now();
  const result = core.verifyLicense(text, {
    publicKey: config.LICENSE_PUBLIC_KEY_PEM,
    deviceId: deviceId,
    now: now,
    expectedType
  });
  if (result.ok && expectedType === 'installation' && result.payload.plan === 'trial') {
    const clock = checkAndUpdateTrialClock(now);
    if (!clock.ok) return clock;
  }
  return result;
}

// Verifica una licencia de POS sin instalarla como licencia principal.
// El identificador del equipo sigue siendo obligatorio y la firma se valida
// antes de interpretar el payload, igual que con PCL1 de instalación.
function verifyPointLicense(text, expectedPosId, expectedPosName) {
  const result = verifyText(text, 'point-of-sale');
  if (!result.ok) return result;
  if (String(result.payload.posId || '') !== String(expectedPosId || '')) {
    return { ok: false, code: 'POS_ID_MISMATCH', error: 'La licencia pertenece a otro punto de venta.' };
  }
  // posName es descriptivo; el alcance de seguridad depende del ID estable del POS y la PC.
  return result;
}

function cleanLicenseText(text) {
  return typeof text === 'string' ? text.replace(/\s+/g, '') : '';
}

// ---------- Lectura de license.dat ----------
function moveLegacyAside(file) {
  try {
    const target = path.join(path.dirname(file), LEGACY_BACKUP);
    try {
      fs.renameSync(file, target);
    } catch (_) {
      // Si Windows no reemplaza un backup previo, lo apartamos con marca de tiempo.
      fs.renameSync(file, target + '-' + Date.now());
    }
    return true;
  } catch (_) {
    return false;
  }
}

function readLicenseFile() {
  const file = licensePath();
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (_) {
    lastResult = { ok: false, code: 'SIN_LICENCIA', error: 'Sin licencia instalada.' };
    return null;
  }

  let record;
  try {
    record = JSON.parse(raw);
  } catch (_) {
    lastResult = { ok: false, code: 'FORMATO', error: 'El archivo de licencia esta dañado.' };
    return null;
  }

  if (!record || typeof record !== 'object') {
    lastResult = { ok: false, code: 'FORMATO', error: 'El archivo de licencia esta dañado.' };
    return null;
  }

  // Formato VIEJO (HMAC): payload + sig. Se aparta y se trata como "sin licencia".
  if (typeof record.payload === 'string' && typeof record.sig === 'string') {
    moveLegacyAside(file);
    lastResult = { ok: false, code: 'SIN_LICENCIA', error: 'Licencia del formato anterior. Pida una licencia nueva al soporte.' };
    return null;
  }

  if (typeof record.license !== 'string') {
    lastResult = { ok: false, code: 'FORMATO', error: 'El archivo de licencia esta dañado.' };
    return null;
  }

  const result = verifyText(record.license);
  lastResult = result;
  return result.ok ? result.payload : null;
}

function loadLicense() {
  try {
    return readLicenseFile();
  } catch (_) {
    return null;
  }
}

function isLicensed() {
  return loadLicense() !== null;
}

// ---------- Guardado atomico ----------
function writeAtomic(file, contents) {
  const dir = path.dirname(file);
  fs.mkdirSync(dir, { recursive: true });
  const tmp = path.join(dir, LICENSE_FILE + '.tmp-' + process.pid + '-' + Date.now());
  try {
    fs.writeFileSync(tmp, contents, { encoding: 'utf8', mode: 0o600 });
    fs.renameSync(tmp, file);       // reemplazo atomico dentro del mismo volumen
    return true;
  } catch (err) {
    try { fs.unlinkSync(tmp); } catch (_) { /* nada que limpiar */ }
    throw err;
  }
}

// Verifica y, solo si es valida, escribe license.dat.
function saveLicense(text) {
  const result = verifyText(text);
  if (!result.ok) return result;

  const clean = cleanLicenseText(text);
  try {
    writeAtomic(licensePath(), JSON.stringify({ license: clean }));
  } catch (_) {
    return {
      ok: false,
      code: 'FORMATO',
      error: 'No se pudo guardar la licencia en el disco. Verifique los permisos de la carpeta de datos.'
    };
  }
  lastResult = { ok: true, payload: result.payload };
  return { ok: true, payload: result.payload };
}

function activateFromText(text) {
  const result = saveLicense(text);
  if (result.ok) result.status = status();
  return result;
}

function activateFromFile(filePath) {
  let stat;
  try {
    stat = fs.statSync(filePath);
  } catch (_) {
    return { ok: false, code: 'FORMATO', error: 'No se pudo abrir el archivo de licencia.' };
  }
  if (!stat.isFile() || stat.size === 0) {
    return { ok: false, code: 'FORMATO', error: 'El archivo de licencia esta vacio.' };
  }
  if (stat.size > MAX_LIC_FILE_BYTES) {
    return { ok: false, code: 'FORMATO', error: 'El archivo de licencia supera los 4 KB permitidos.' };
  }

  let text;
  try {
    text = fs.readFileSync(filePath, 'utf8');
  } catch (_) {
    return { ok: false, code: 'FORMATO', error: 'No se pudo leer el archivo de licencia.' };
  }
  return activateFromText(text);
}

function status() {
  let deviceId = null;
  try {
    deviceId = getDeviceId();
  } catch (_) {
    return {
      licensed: false,
      device: null,
      code: 'ID_ILEGIBLE',
      error: core.MESSAGES.ID_ILEGIBLE
    };
  }

  const payload = loadLicense();
  if (!payload) {
    return {
      licensed: false,
      device: deviceId,
      code: lastResult ? lastResult.code : 'SIN_LICENCIA',
      error: lastResult ? lastResult.error : 'Sin licencia instalada.'
    };
  }

  return {
    licensed: true,
    device: deviceId,
    plan: payload.plan,
    customer: payload.customer || null,
    issuedAt: payload.issuedAt || null,
    expiresAt: payload.expiresAt || null,
    licenseId: payload.licenseId || null,
    code: null,
    error: null
  };
}

module.exports = {
  getDeviceId,
  licensePath,
  clockStatePath,
  loadLicense,
  saveLicense,
  isLicensed,
  activateFromText,
  activateFromFile,
  verifyText,
  verifyPointLicense,
  status
};
