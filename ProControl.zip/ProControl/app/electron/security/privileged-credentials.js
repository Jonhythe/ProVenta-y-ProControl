'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');

const STORE_SECRET_PREFIX = 'PROCONTROL_SECRET_2026:';
const MAX_STORED_VALUE_CHARS = 2 * 1024 * 1024;
const PASSWORD_ITERATIONS = 600000;
const PRIVILEGED_ROLES = new Set(['Dueño', 'Administrador']);
const LOGIN_ROLES = new Set(['Dueño', 'Administrador', 'Economico']);
const RESERVED_USERNAMES = new Set(['__proto__', 'constructor', 'prototype']);
const SECURITY_QUESTIONS = new Set([
  '¿Cuál es el nombre de su primera mascota?',
  '¿En qué ciudad nació?',
  '¿Cómo se llamaba su primer colegio?',
  '¿Cuál es el nombre de su mejor amigo de la infancia?',
  '¿Cuál es su comida favorita?',
  '¿Cuál es el apellido de soltera de su madre?'
]);

function registrationError(code) {
  const error = new Error(code);
  error.code = code;
  return error;
}

function normalizeUsername(value) {
  return String(value || '').normalize('NFKC').trim().toLowerCase().replace(/\s+/g, ' ');
}

function createPasswordRecord(password) {
  const salt = crypto.randomBytes(16);
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(password, salt, PASSWORD_ITERATIONS, 32, 'sha256', (error, derived) => {
      if (error) return reject(error);
      resolve(`pbkdf2$${PASSWORD_ITERATIONS}$${salt.toString('hex')}$${derived.toString('hex')}`);
    });
  });
}

function encodeStoredValue(value) {
  const json = Buffer.from(JSON.stringify(value), 'utf8').toString('base64');
  return Buffer.from(`${STORE_SECRET_PREFIX}${json}`, 'utf8').toString('base64');
}

function readStoreObject(db, key) {
  const row = db.prepare('SELECT value FROM store WHERE key=?').get(key);
  if (!row) return {};
  const value = decodeStoredValue(row.value);
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw registrationError('ACCOUNT_STORE_CORRUPT');
  }
  return value;
}

async function registerAccountInStore({ db, username, password, phone, countryCode, email, question, answer }) {
  const user = typeof username === 'string' ? username.trim() : '';
  if (!/^[\p{L}\p{N} ._-]{3,30}$/u.test(user) || RESERVED_USERNAMES.has(user.toLowerCase())) {
    return { ok: false, code: 'INVALID_USERNAME' };
  }
  if (typeof password !== 'string' || password.length < 6 || password.length > 512) {
    return { ok: false, code: 'INVALID_PASSWORD' };
  }
  if (typeof phone !== 'string' || !/^\d{6,15}$/.test(phone) ||
      typeof countryCode !== 'string' || !/^\+\d{1,3}$/.test(countryCode)) {
    return { ok: false, code: 'INVALID_PHONE' };
  }
  if (typeof email !== 'string' || email.length > 254 ||
      (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) {
    return { ok: false, code: 'INVALID_EMAIL' };
  }
  if (typeof question !== 'string' || !SECURITY_QUESTIONS.has(question) ||
      typeof answer !== 'string' || answer.trim().length < 2 || answer.length > 512) {
    return { ok: false, code: 'INVALID_SECURITY_QUESTION' };
  }
  if (!db || typeof db.prepare !== 'function' || typeof db.exec !== 'function') {
    return { ok: false, code: 'ACCOUNT_STORE_UNAVAILABLE' };
  }

  const normalizedUser = normalizeUsername(user);
  const loadAccountMaps = () => ({
    roles: readStoreObject(db, 'elite_user_roles'),
    passwords: readStoreObject(db, 'elite_user_passwords'),
    phones: readStoreObject(db, 'elite_user_phones'),
    questions: readStoreObject(db, 'elite_user_questions')
  });
  const hasUsername = maps => {
    const existingUsers = new Set([
      ...Object.keys(maps.roles),
      ...Object.keys(maps.passwords),
      ...Object.keys(maps.phones),
      ...Object.keys(maps.questions)
    ]);
    return [...existingUsers].some(existing => normalizeUsername(existing) === normalizedUser);
  };
  try {
    db.exec('CREATE TABLE IF NOT EXISTS store (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
    if (hasUsername(loadAccountMaps())) return { ok: false, code: 'USERNAME_EXISTS' };
  } catch (error) {
    if (error && error.code === 'ACCOUNT_STORE_CORRUPT') return { ok: false, code: error.code };
    throw error;
  }

  const [passwordRecord, answerRecord] = await Promise.all([
    createPasswordRecord(password),
    createPasswordRecord(answer.trim().toLowerCase().replace(/\s+/g, ' '))
  ]);
  let inTransaction = false;
  try {
    db.exec('BEGIN IMMEDIATE');
    inTransaction = true;

    const { roles, passwords, phones, questions } = loadAccountMaps();
    if (hasUsername({ roles, passwords, phones, questions })) {
      db.exec('ROLLBACK');
      inTransaction = false;
      return { ok: false, code: 'USERNAME_EXISTS' };
    }

    const role = Object.values(roles).includes('Dueño') ? 'Pendiente' : 'Dueño';
    roles[user] = role;
    passwords[user] = passwordRecord;
    phones[user] = { code: countryCode, number: phone };
    questions[user] = { question, answerHash: answerRecord };

    const write = db.prepare('INSERT INTO store (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
    write.run('elite_user_roles', encodeStoredValue(roles));
    write.run('elite_user_passwords', encodeStoredValue(passwords));
    write.run('elite_user_phones', encodeStoredValue(phones));
    write.run('elite_user_questions', encodeStoredValue(questions));
    if (role === 'Dueño') write.run('elite_owner_pass', encodeStoredValue(passwordRecord));
    db.exec('COMMIT');
    inTransaction = false;
    return { ok: true, user, role };
  } catch (error) {
    if (inTransaction) {
      try { db.exec('ROLLBACK'); } catch (_) {}
    }
    if (error && error.code === 'ACCOUNT_STORE_CORRUPT') return { ok: false, code: error.code };
    throw error;
  }
}

function decodeStoredValue(raw) {
  if (typeof raw !== 'string' || raw.length === 0 || raw.length > MAX_STORED_VALUE_CHARS) return null;

  // ProControl stores sensitive appState entries as base64(prefix + base64(JSON)).
  // Decode precisely that envelope; never interpret an arbitrary string as a password.
  try {
    const outer = Buffer.from(raw, 'base64').toString('utf8');
    if (outer.startsWith(STORE_SECRET_PREFIX)) {
      const jsonBase64 = outer.slice(STORE_SECRET_PREFIX.length);
      if (!jsonBase64 || jsonBase64.length > MAX_STORED_VALUE_CHARS) return null;
      return JSON.parse(Buffer.from(jsonBase64, 'base64').toString('utf8'));
    }
  } catch (_) {
    // Fall through only to the legacy plain-JSON representation.
  }

  try {
    return JSON.parse(raw);
  } catch (_) {
    return null;
  }
}

function secureEqualHex(actual, expected) {
  if (typeof actual !== 'string' || typeof expected !== 'string' ||
      actual.length !== expected.length || actual.length === 0 || actual.length % 2 !== 0 ||
      !/^[a-f0-9]+$/i.test(actual) || !/^[a-f0-9]+$/i.test(expected)) return false;
  try {
    return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex'));
  } catch (_) {
    return false;
  }
}

function verifyStoredPassword(password, stored) {
  if (typeof stored !== 'string' || !stored || typeof password !== 'string' || password.length > 512) return false;
  try {
    if (stored.startsWith('pbkdf2$')) {
      const parts = stored.split('$');
      if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;
      const iterations = Number(parts[1]);
      const saltHex = parts[2];
      const expectedHex = parts[3];
      if (!Number.isInteger(iterations) || iterations < 1 || iterations > 1000000 ||
          !/^[a-f0-9]{32}$/i.test(saltHex) || !/^[a-f0-9]{64}$/i.test(expectedHex)) return false;
      const actualHex = crypto.pbkdf2Sync(password, Buffer.from(saltHex, 'hex'), iterations, 32, 'sha256').toString('hex');
      return secureEqualHex(actualHex, expectedHex);
    }

    // SHA-256 was the legacy ProControl password format. Keep verification so
    // existing owners are not locked out; the normal login upgrades this record
    // to salted PBKDF2 after a successful authentication.
    if (/^[a-f0-9]{64}$/i.test(stored)) {
      const actualHex = crypto.createHash('sha256').update(password, 'utf8').digest('hex');
      return secureEqualHex(actualHex, stored);
    }
  } catch (_) {
    return false;
  }
  return false;
}

function findPrivilegedCredential({ user, password, roles, passwords, requiredRole = null }) {
  if (typeof user !== 'string' || typeof password !== 'string' || !user.trim() || !password ||
      user.length > 100 || password.length > 512 ||
      !roles || typeof roles !== 'object' || Array.isArray(roles) ||
      !passwords || typeof passwords !== 'object' || Array.isArray(passwords)) {
    return { ok: false, code: 'AUTH_FAILED' };
  }

  const requested = user.trim().toLocaleLowerCase();
  const key = Object.keys(roles).find(name => String(name).toLocaleLowerCase() === requested);
  if (!key) return { ok: false, code: 'AUTH_FAILED' };
  const role = roles[key];
  if (!PRIVILEGED_ROLES.has(role) || !verifyStoredPassword(password, passwords[key])) {
    return { ok: false, code: 'AUTH_FAILED' };
  }
  if (requiredRole && role !== requiredRole) return { ok: false, code: 'OWNER_REQUIRED' };
  return { ok: true, user: key, role };
}

function findOwnerWithPin({ password, pin, roles, passwords, pins }) {
  if (typeof password !== 'string' || !password || password.length > 512 ||
      typeof pin !== 'string' || !/^\d{6}$/.test(pin) ||
      !roles || typeof roles !== 'object' || Array.isArray(roles) ||
      !passwords || typeof passwords !== 'object' || Array.isArray(passwords) ||
      !pins || typeof pins !== 'object' || Array.isArray(pins)) {
    return { ok: false, code: 'INVALID_CREDENTIALS' };
  }

  const owners = Object.keys(roles).filter(name => roles[name] === 'Dueño');
  if (!owners.some(name => typeof pins[name] === 'string' && pins[name])) {
    return { ok: false, code: 'OWNER_PIN_NOT_CONFIGURED' };
  }
  const matches = owners.filter(name =>
    verifyStoredPassword(password, passwords[name]) &&
    verifyStoredPassword(pin, pins[name]));
  if (matches.length !== 1) return { ok: false, code: 'AUTH_FAILED' };
  return { ok: true, user: matches[0], role: 'Dueño' };
}

function findUserWithPasswordAndSecurityAnswer({ password, question, answer, roles, passwords, questions }) {
  if (typeof password !== 'string' || !password || password.length > 512 ||
      typeof question !== 'string' || !question || question.length > 240 ||
      typeof answer !== 'string' || answer.length < 2 || answer.length > 512 ||
      !roles || typeof roles !== 'object' || Array.isArray(roles) ||
      !passwords || typeof passwords !== 'object' || Array.isArray(passwords) ||
      !questions || typeof questions !== 'object' || Array.isArray(questions)) {
    return { ok: false, code: 'AUTH_FAILED' };
  }

  const normalizedAnswer = answer.trim().toLowerCase().replace(/\s+/g, ' ');
  const matches = [];
  for (const name of Object.keys(roles)) {
    if (!LOGIN_ROLES.has(roles[name])) continue;
    const recovery = questions[name];
    if (!recovery || recovery.question !== question ||
        typeof recovery.answerHash !== 'string') continue;
    if (verifyStoredPassword(password, passwords[name]) &&
        verifyStoredPassword(normalizedAnswer, recovery.answerHash)) {
      matches.push({ user: name, role: roles[name] });
    }
  }
  if (matches.length !== 1) return { ok: false, code: 'AUTH_FAILED' };
  return { ok: true, ...matches[0] };
}

function readAppStoreKeysFromDisk({ dbFile, legacyFile, keys, DatabaseSync = null, fsImpl = fs }) {
  if (!Array.isArray(keys) || keys.length > 32 || keys.some(key => typeof key !== 'string' || !key || key.length > 160)) {
    throw new TypeError('AUTH_STORE_KEYS_INVALID');
  }

  const result = {};
  // SQLite is authoritative whenever its database file exists. Never fall back
  // to a possibly stale JSON password after a SQLite read/parse error or when
  // a credential row is absent: that could re-enable a password the owner has
  // already changed or removed.
  if (fsImpl.existsSync(dbFile)) {
    let db = null;
    try {
      const SyncDatabase = DatabaseSync || require('node:sqlite').DatabaseSync;
      db = new SyncDatabase(dbFile, { readOnly: true });
      const table = db.prepare("SELECT 1 AS present FROM sqlite_master WHERE type='table' AND name='store'").get();
      if (!table) return result;
      const stmt = db.prepare('SELECT value FROM store WHERE key=?');
      for (const key of keys) {
        const row = stmt.get(key);
        if (row && typeof row.value === 'string') {
          const decoded = decodeStoredValue(row.value);
          if (decoded !== null) result[key] = decoded;
        }
      }
      return result;
    } catch (_) {
      return result; // fail closed; do not consult stale credentials from JSON
    } finally {
      try { if (db) db.close(); } catch (_) {}
    }
  }

  // The JSON backend is supported only when there is no SQLite database at all.
  if (legacyFile && fsImpl.existsSync(legacyFile)) {
    try {
      const legacy = JSON.parse(fsImpl.readFileSync(legacyFile, 'utf8'));
      if (legacy && typeof legacy === 'object' && !Array.isArray(legacy)) {
        for (const key of keys) {
          if (!Object.prototype.hasOwnProperty.call(legacy, key)) continue;
          const raw = legacy[key];
          const decoded = typeof raw === 'string' ? decodeStoredValue(raw) : raw;
          if (decoded !== null && decoded !== undefined) result[key] = decoded;
        }
      }
    } catch (_) {
      // Fail closed: absent/corrupt credentials never create a privileged session.
    }
  }
  return result;
}

module.exports = {
  decodeStoredValue,
  secureEqualHex,
  verifyStoredPassword,
  findPrivilegedCredential,
  findOwnerWithPin,
  findUserWithPasswordAndSecurityAnswer,
  registerAccountInStore,
  readAppStoreKeysFromDisk
};
