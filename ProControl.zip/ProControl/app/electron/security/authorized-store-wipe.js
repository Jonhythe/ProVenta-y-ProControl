'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

function codedError(code, message) {
  const error = new Error(message || code);
  error.code = code;
  return error;
}

function quoteIdentifier(value) {
  return '"' + String(value).replace(/"/g, '""') + '"';
}

function getTableNames(db) {
  return db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    .all().map(row => String(row.name));
}

function isTablePresent(db, tableName) {
  return db.prepare("SELECT 1 AS found FROM sqlite_master WHERE type='table' AND name=? LIMIT 1").get(tableName) !== undefined;
}

function restoreLegacyFile(file, previousBytes) {
  if (previousBytes === null) {
    try { fs.unlinkSync(file); } catch (error) { if (!error || error.code !== 'ENOENT') throw error; }
    return;
  }
  const temp = file + '.restore-' + process.pid + '-' + crypto.randomUUID() + '.tmp';
  fs.writeFileSync(temp, previousBytes, { flag: 'wx', mode: 0o600 });
  try {
    fs.renameSync(temp, file);
  } catch (error) {
    // Windows no reemplaza siempre un destino existente. La copia original ya
    // está en memoria y se restaura explícitamente si el rename no puede hacerlo.
    try { if (fs.existsSync(file)) fs.unlinkSync(file); } catch (_) {}
    try { fs.renameSync(temp, file); } catch (restoreError) {
      try { fs.writeFileSync(file, previousBytes, { mode: 0o600 }); } catch (_) {}
      try { fs.unlinkSync(temp); } catch (_) {}
      throw restoreError || error;
    }
  }
}

function replaceLegacyJsonAtomically(file, temp, contents) {
  fs.writeFileSync(temp, contents, { encoding: 'utf8', flag: 'wx', mode: 0o600 });
  const verification = fs.readFileSync(temp, 'utf8');
  if (verification !== contents) throw codedError('LEGACY_JSON_VERIFY_FAILED', 'El respaldo JSON temporal no pasó la verificación.');
  try {
    fs.renameSync(temp, file);
  } catch (error) {
    // Node/Windows puede devolver EPERM al reemplazar un JSON existente aunque
    // no haya un handle abierto. Lo hacemos explícito y conservamos los bytes
    // anteriores para poder revertir si la segunda operación también falla.
    if (!fs.existsSync(file)) throw error;
    fs.unlinkSync(file);
    fs.renameSync(temp, file);
  }
}

/**
 * Limpieza autorizada de datos operativos.
 * El llamador DEBE autenticar al Dueño antes de invocar esta función.
 * Conserva: licencia (fuera de estas bases), claves del escritorio y bridge_meta.
 */
function wipeOperationalStoreData(options = {}) {
  const userDataDir = path.resolve(String(options.userDataDir || ''));
  if (!userDataDir || userDataDir === path.parse(userDataDir).root) {
    return { ok: false, code: 'WIPE_PATH_INVALID', stage: 'PRECHECK', detail: 'La ruta de datos no es válida.' };
  }

  const dbFile = path.join(userDataDir, 'procontrol.db');
  const bridgeFile = path.join(userDataDir, 'mobile-bridge.db');
  const legacyFile = path.join(userDataDir, 'procontrol.json');
  const legacyTemp = legacyFile + '.wipe-' + process.pid + '-' + crypto.randomUUID() + '.tmp';
  const archiveRoot = path.join(userDataDir, 'registros-antiguos');

  let stage = 'PRECHECK';
  let mainDb = null;
  let bridgeDb = null;
  let ownsBridgeDb = false;
  let mainTransaction = false;
  let bridgeTransaction = false;
  let bridgeForeignKeysWereOn = false;
  let archiveStage = null;
  let legacyPrevious = null;
  let legacyWasChanged = false;
  let bridgeTablesCleared = [];
  let bridgeCommitted = false;
  let mainCommitted = false;

  const result = {
    ok: false,
    code: 'STORE_WIPE_FAILED',
    stage,
    detail: 'No se pudo completar el borrado.'
  };

  try {
    fs.mkdirSync(userDataDir, { recursive: true });

    // Leer el JSON antes de tocarlo. Si no existe, se recordará para rollback.
    stage = 'READ_LEGACY_JSON_BACKUP';
    legacyPrevious = fs.existsSync(legacyFile) ? fs.readFileSync(legacyFile) : null;

    // Bloquear primero ambas bases. No borrar nada mientras una de ellas no esté bloqueada.
    stage = 'OPEN_MAIN_DATABASE';
    if (fs.existsSync(dbFile)) {
      mainDb = new DatabaseSync(dbFile);
      mainDb.exec('PRAGMA busy_timeout=15000;');
      if (!isTablePresent(mainDb, 'store')) {
        throw codedError('MAIN_STORE_TABLE_MISSING', 'La base de datos principal no contiene la tabla store esperada.');
      }
      stage = 'LOCK_MAIN_DATABASE';
      if (mainDb.isTransaction) mainDb.exec('ROLLBACK;');
      mainDb.exec('BEGIN IMMEDIATE;');
      mainTransaction = true;
    }

    stage = 'OPEN_BRIDGE_DATABASE';
    if (fs.existsSync(bridgeFile)) {
      if (options.bridgeDb) {
        bridgeDb = options.bridgeDb;
      } else {
        bridgeDb = new DatabaseSync(bridgeFile);
        ownsBridgeDb = true;
      }
      bridgeDb.exec('PRAGMA busy_timeout=15000;');
      if (bridgeDb.isTransaction) {
        // Un método anterior pudo dejar una transacción sin cerrar después de
        // una interrupción. La UI está bloqueada durante este IPC: no hay una
        // operación móvil simultánea que deba conservarse.
        bridgeDb.exec('ROLLBACK;');
      }
      const foreignKeyState = bridgeDb.prepare('PRAGMA foreign_keys').get();
      bridgeForeignKeysWereOn = !!(foreignKeyState && Number(foreignKeyState.foreign_keys) === 1);
      bridgeDb.exec('PRAGMA foreign_keys=OFF;');
      stage = 'LOCK_BRIDGE_DATABASE';
      bridgeDb.exec('BEGIN IMMEDIATE;');
      bridgeTransaction = true;
    }

    // Apartar los ficheros cifrados antes de cambiar las bases. Si Windows no
    // permite mover alguno, se aborta y se revierten las transacciones.
    stage = 'STAGE_ENCRYPTED_ARCHIVES';
    if (fs.existsSync(archiveRoot)) {
      if (!options.archiveStore || typeof options.archiveStore.stageClearAll !== 'function') {
        throw codedError('ARCHIVE_WIPE_UNAVAILABLE', 'El almacén de históricos no ofrece el método seguro de apartado.');
      }
      archiveStage = options.archiveStore.stageClearAll();
    }

    stage = 'CLEAR_MAIN_STORE';
    if (mainDb) {
      mainDb.prepare('DELETE FROM store').run();
      const remaining = Number(mainDb.prepare('SELECT COUNT(*) AS n FROM store').get().n || 0);
      if (remaining !== 0) throw codedError('MAIN_STORE_NOT_EMPTY', 'La tabla principal conserva registros después del borrado.');
    }

    stage = 'CLEAR_BRIDGE_OPERATIONAL_TABLES';
    if (bridgeDb) {
      const tables = getTableNames(bridgeDb);
      if (!tables.includes('bridge_meta')) {
        throw codedError('BRIDGE_IDENTITY_TABLE_MISSING', 'No se encontró bridge_meta; se abortó para no regenerar la identidad de instalación.');
      }

      // El esquema móvil evoluciona con el tiempo. En lugar de una lista estática
      // que puede omitir tablas nuevas o romper el orden de FK, vaciamos todas las
      // tablas operativas detectadas y preservamos íntegramente bridge_meta.
      for (const table of tables) {
        if (table === 'bridge_meta') continue;
        bridgeDb.exec('DELETE FROM ' + quoteIdentifier(table));
        bridgeTablesCleared.push(table);
      }
      if (isTablePresent(bridgeDb, 'sqlite_sequence')) bridgeDb.exec('DELETE FROM sqlite_sequence;');

      const remainingTables = getTableNames(bridgeDb).filter(name => name !== 'bridge_meta');
      for (const table of remainingTables) {
        const remaining = Number(bridgeDb.prepare('SELECT COUNT(*) AS n FROM ' + quoteIdentifier(table)).get().n || 0);
        if (remaining !== 0) throw codedError('BRIDGE_TABLE_NOT_EMPTY', 'La tabla operativa ' + table + ' conserva registros.');
      }
      const installationId = bridgeDb.prepare("SELECT value FROM bridge_meta WHERE key='installation_id'").get();
      if (!installationId || typeof installationId.value !== 'string' || !installationId.value) {
        throw codedError('BRIDGE_INSTALLATION_ID_MISSING', 'La identidad de esta instalación no está disponible; se abortó el reinicio.');
      }
    }

    stage = 'RESET_LEGACY_JSON';
    replaceLegacyJsonAtomically(legacyFile, legacyTemp, '{}');
    legacyWasChanged = true;

    // Commit puente primero y negocio al final. La preparación previa bloquea
    // las dos bases, por lo que no debería quedar una operación competidora.
    stage = 'COMMIT_BRIDGE_DATABASE';
    if (bridgeDb) {
      bridgeDb.exec('COMMIT;');
      bridgeTransaction = false;
      bridgeCommitted = true;
    }

    stage = 'COMMIT_MAIN_DATABASE';
    if (mainDb) {
      mainDb.exec('COMMIT;');
      mainTransaction = false;
      mainCommitted = true;
    }

    stage = 'COMMIT_ENCRYPTED_ARCHIVES';
    let archiveCleanupPending = false;
    let archivedFilesRemoved = 0;
    if (archiveStage) {
      const cleanup = archiveStage.commit();
      archivedFilesRemoved = Number(cleanup && cleanup.deletedFiles || 0);
      archiveCleanupPending = !!(cleanup && cleanup.pending === true);
    }

    result.ok = true;
    result.code = 'OK';
    result.stage = 'DONE';
    result.detail = '';
    result.reset = {
      businessStore: !!mainDb || legacyWasChanged,
      mobileBridgeOperationalData: !!bridgeDb,
      bridgeTablesCleared,
      archivedFilesRemoved,
      licensePreserved: true,
      installationIdentityPreserved: true
    };
    result.archiveCleanupPending = archiveCleanupPending;
    return result;
  } catch (error) {
    if (mainTransaction && mainDb) {
      try { mainDb.exec('ROLLBACK;'); } catch (_) {}
      mainTransaction = false;
    }
    if (bridgeTransaction && bridgeDb) {
      try { bridgeDb.exec('ROLLBACK;'); } catch (_) {}
      bridgeTransaction = false;
    }
    try { fs.unlinkSync(legacyTemp); } catch (_) {}
    if (legacyWasChanged) {
      try { restoreLegacyFile(legacyFile, legacyPrevious); } catch (restoreError) {
        result.rollbackWarning = 'LEGACY_JSON_RESTORE_FAILED:' + String(restoreError && restoreError.code || restoreError && restoreError.message || 'UNKNOWN');
      }
    }
    if (archiveStage) {
      try { archiveStage.rollback(); } catch (rollbackError) {
        result.rollbackWarning = (result.rollbackWarning ? result.rollbackWarning + ';' : '') +
          'ARCHIVE_RESTORE_FAILED:' + String(rollbackError && rollbackError.code || rollbackError && rollbackError.message || 'UNKNOWN');
      }
    }

    const rawMessage = String(error && error.message || error || 'Unknown error').replace(/[\r\n\t]+/g, ' ').slice(0, 240);
    const code = String(error && error.code || 'STORE_WIPE_FAILED').replace(/[^A-Za-z0-9_:-]/g, '_').slice(0, 80);
    result.code = code;
    result.stage = stage;
    result.detail = rawMessage;
    result.partialReset = bridgeCommitted || mainCommitted;
    return result;
  } finally {
    if (bridgeDb && bridgeForeignKeysWereOn) {
      try { bridgeDb.exec('PRAGMA foreign_keys=ON;'); } catch (_) {}
    }
    try { if (mainDb) mainDb.close(); } catch (_) {}
    try { if (ownsBridgeDb && bridgeDb) bridgeDb.close(); } catch (_) {}
  }
}

module.exports = { wipeOperationalStoreData };
