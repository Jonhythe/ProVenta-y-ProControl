'use strict';

const TRUSTED_APP_PAGES = new Set(['license.html', 'splash.html', 'index.html']);

function isTrustedAppNavigation(rawUrl) {
  if (typeof rawUrl !== 'string' || rawUrl.length > 2048) return false;
  try {
    const url = new URL(rawUrl);
    return url.protocol === 'app:' &&
      !url.username &&
      !url.password &&
      !url.port &&
      TRUSTED_APP_PAGES.has(url.hostname) &&
      (url.pathname === '/' || url.pathname === '');
  } catch {
    return false;
  }
}

function isPrintPopupUrl(rawUrl) {
  return rawUrl === 'about:blank';
}

module.exports = { isTrustedAppNavigation, isPrintPopupUrl };
