// ============================================================
// PROCONTROL - NUCLEO DE VERIFICACION DE LICENCIAS
// ============================================================
// Funcion PURA: no depende de Electron ni del sistema operativo.
// Se le inyecta { publicKey, deviceId, now } para poder probarla.
//
// Formato de licencia (texto o archivo .lic):
//   PCL1.<payloadB64url>.<firmaB64url>
//
// La firma es Ed25519 sobre los bytes ASCII de:
//   "PCL1." + payloadB64url
// (es decir, todo lo anterior al segundo punto).
//
// Orden OBLIGATORIO:
//   1. quitar TODO espacio en blanco
//   2. longitud maxima 2048
//   3. regex de formato
//   4. firma de exactamente 64 bytes
//   5. VERIFICAR LA FIRMA ANTES de parsear el JSON
//   6. JSON.parse en try/catch
//   7. v, app, plan, deviceId, expiresAt
// ============================================================
'use strict';

const crypto = require('crypto');

const LICENSE_PREFIX = 'PCL1';
const MAX_LENGTH = 2048;
const FORMAT_RE = /^PCL1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/;
const VALID_PLANS = ['permanent', 'trial'];
const VALID_LICENSE_TYPES = ['installation', 'point-of-sale'];
const VALID_LICENSE_MODULES = ['core', 'inventory', 'purchases', 'pos', 'closings', 'reports', 'mobile-integration'];
const VALID_POS_MODES = ['SIN_APP', 'CON_APP'];
const LEGACY_MODULES = ['core', 'inventory', 'purchases', 'pos', 'closings', 'reports'];

const MESSAGES = {
  FORMATO: 'La licencia no tiene el formato correcto. Copiela completa o pida una nueva al soporte.',
  FIRMA: 'La licencia no es valida o fue modificada. Pida una licencia nueva al soporte.',
  OTRA_PC: 'Esta licencia fue emitida para otra PC. Envie el ID de esta PC al soporte para recibir la suya.',
  EXPIRADA: 'La licencia de prueba ya vencio. Contacte al soporte para renovarla.',
  RELOJ_RETROCEDIDO: 'Se detecto que el reloj del equipo retrocedio. Corrija la fecha y hora de Windows y reinicie la aplicacion.',
  ID_ILEGIBLE: 'No se pudo leer el identificador de esta PC. Contacte al soporte tecnico.',
  TIPO_INCORRECTO: 'El tipo de licencia no corresponde a esta operación.'
};

function fail(code, extra) {
  return {
    ok: false,
    code: code,
    error: (extra ? extra + ' ' : '') + (MESSAGES[code] || MESSAGES.FORMATO)
  };
}

function normalizeNow(now) {
  if (now instanceof Date) return now.getTime();
  if (typeof now === 'number' && Number.isFinite(now)) return now;
  return Date.now();
}

function normalizeDeviceId(value) {
  if (typeof value !== 'string') return null;
  const clean = value.toUpperCase().replace(/[^0-9A-F]/g, '');
  return clean.length === 32 ? clean : null;
}

// Verifica una licencia. Devuelve { ok:true, payload } o { ok:false, code, error }.
function verifyLicense(text, options) {
  const opts = options || {};
  const publicKeyInput = opts.publicKey;
  const deviceId = normalizeDeviceId(opts.deviceId);

  if (!deviceId) return fail('ID_ILEGIBLE');

  // 1. Quitar TODO espacio en blanco (espacios, saltos de linea, tabuladores).
  if (typeof text !== 'string') return fail('FORMATO');
  const clean = text.replace(/\s+/g, '');

  // 2. Longitud maxima.
  if (clean.length === 0 || clean.length > MAX_LENGTH) return fail('FORMATO');

  // 3. Formato.
  if (!FORMAT_RE.test(clean)) return fail('FORMATO');

  const firstDot = clean.indexOf('.');
  const secondDot = clean.indexOf('.', firstDot + 1);
  const payloadB64 = clean.slice(firstDot + 1, secondDot);
  const signatureB64 = clean.slice(secondDot + 1);

  // 4. La firma Ed25519 siempre son 64 bytes.
  let signature;
  try {
    signature = Buffer.from(signatureB64, 'base64url');
  } catch (_) {
    return fail('FIRMA');
  }
  if (signature.length !== 64) return fail('FIRMA');

  // 5. VERIFICAR LA FIRMA ANTES DE PARSEAR NADA DEL PAYLOAD.
  try {
    const key = publicKeyInput && publicKeyInput.type === 'public'
      ? publicKeyInput
      : crypto.createPublicKey(publicKeyInput);
    const signedData = Buffer.from(LICENSE_PREFIX + '.' + payloadB64, 'ascii');
    if (!crypto.verify(null, signedData, key, signature)) return fail('FIRMA');
  } catch (_) {
    return fail('FIRMA');
  }

  // 6. Solo despues de una firma valida se interpreta el payload.
  let payload;
  try {
    payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8'));
  } catch (_) {
    return fail('ID_ILEGIBLE');
  }
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return fail('ID_ILEGIBLE');
  }

  // 7. Campos obligatorios.
  if (payload.v !== 1) return fail('FORMATO');
  if (payload.app !== 'procontrol') return fail('FORMATO');
  if (VALID_PLANS.indexOf(payload.plan) === -1) return fail('FORMATO');

  // Compatibilidad: las licencias PCL1 antiguas sin tipo se consideran
  // exclusivamente licencias de instalación. Nunca pueden utilizarse como licencia POS.
  const licenseType = payload.licenseType === undefined && payload.type === undefined
    ? 'installation'
    : String(payload.licenseType || payload.type || '');
  if (VALID_LICENSE_TYPES.indexOf(licenseType) === -1) return fail('FORMATO');
  const expectedType = opts.expectedType || 'installation';
  if (VALID_LICENSE_TYPES.indexOf(expectedType) === -1 || licenseType !== expectedType) return fail('TIPO_INCORRECTO');
  let effectiveModules = LEGACY_MODULES.slice();
  let effectiveAllowedModes = ['SIN_APP'];
  if (licenseType === 'point-of-sale') {
    if (typeof payload.posId !== 'string' || !/^[A-Za-z0-9:_-]{1,160}$/.test(payload.posId)) return fail('FORMATO');
    if (typeof payload.posName !== 'string' || !payload.posName.trim() || payload.posName.length > 160) return fail('FORMATO');
    if (!normalizeDeviceId(payload.installationMachineId)) return fail('FORMATO');
    if (payload.modules !== undefined || payload.allowedModes !== undefined) return fail('FORMATO');
  } else {
    if (payload.posId !== undefined || payload.posName !== undefined || payload.installationMachineId !== undefined) {
      // Evita que un token mal etiquetado mezcle campos POS y de instalación.
      return fail('FORMATO');
    }
    if (payload.modules !== undefined) {
      if (!Array.isArray(payload.modules) || payload.modules.length < 1 || payload.modules.length > VALID_LICENSE_MODULES.length ||
          payload.modules.some(module => typeof module !== 'string' || !VALID_LICENSE_MODULES.includes(module)) ||
          new Set(payload.modules).size !== payload.modules.length) return fail('FORMATO');
      effectiveModules = payload.modules.slice();
    }
    if (payload.allowedModes !== undefined) {
      if (!Array.isArray(payload.allowedModes) || payload.allowedModes.length < 1 || payload.allowedModes.length > VALID_POS_MODES.length ||
          payload.allowedModes.some(mode => !VALID_POS_MODES.includes(mode)) || new Set(payload.allowedModes).size !== payload.allowedModes.length) return fail('FORMATO');
      effectiveAllowedModes = payload.allowedModes.slice();
    }
    if (effectiveAllowedModes.includes('CON_APP') && !effectiveModules.includes('mobile-integration')) return fail('FORMATO');
  }

  const licenseDevice = normalizeDeviceId(payload.deviceId);
  if (!licenseDevice) return fail('FORMATO');
  if (licenseDevice !== deviceId) return fail('OTRA_PC');
  if (licenseType === 'point-of-sale' && normalizeDeviceId(payload.installationMachineId) !== licenseDevice) return fail('OTRA_PC');

  // Las licencias de prueba SIEMPRE deben tener vencimiento.
  const hasExpiry = payload.expiresAt !== undefined && payload.expiresAt !== null && payload.expiresAt !== '';
  if (payload.plan === 'trial' && !hasExpiry) return fail('FORMATO', 'La licencia de prueba no tiene fecha de vencimiento.');

  if (hasExpiry) {
    const expires = Date.parse(String(payload.expiresAt));
    if (!Number.isFinite(expires)) return fail('FORMATO');
    if (expires <= normalizeNow(opts.now)) return fail('EXPIRADA');
  }

  if (payload.issuedAt !== undefined && (typeof payload.issuedAt !== 'string' || !Number.isFinite(Date.parse(payload.issuedAt)))) return fail('FORMATO');
  if (payload.licenseId !== undefined && (typeof payload.licenseId !== 'string' || payload.licenseId.length > 128)) return fail('FORMATO');
  if (payload.customer !== undefined && (typeof payload.customer !== 'string' || payload.customer.length > 256)) return fail('FORMATO');

  return { ok: true, payload: { ...payload, licenseType, modules: effectiveModules, allowedModes: effectiveAllowedModes } };
}

module.exports = {
  LICENSE_PREFIX: LICENSE_PREFIX,
  MAX_LENGTH: MAX_LENGTH,
  FORMAT_RE: FORMAT_RE,
  VALID_LICENSE_TYPES: VALID_LICENSE_TYPES,
  VALID_LICENSE_MODULES: VALID_LICENSE_MODULES,
  VALID_POS_MODES: VALID_POS_MODES,
  MESSAGES: MESSAGES,
  normalizeDeviceId: normalizeDeviceId,
  verifyLicense: verifyLicense
};
