// PROCONTROL — configuración pública de licencias.
// Solo contiene la clave pública Ed25519. La privada nunca se integra en la aplicación.
// Generado por licensor/gen-license-keys.js; no editar manualmente.

module.exports = {
  APP_ID: 'procontrol',
  LICENSE_PREFIX: 'PCL1',
  LICENSE_PUBLIC_KEY_PEM: [
    '-----BEGIN PUBLIC KEY-----',
    'MCowBQYDK2VwAyEAX0KWGQCqKcozVE3isB1Btv5ybX6HXt62ZnpxoYXRVdI=',
    '-----END PUBLIC KEY-----'
  ].join('\n')
};
