'use strict';

function createNativeFileDialogs({ dialog, BrowserWindow, focusDelayMs = 120, wait = null }) {
  if (!dialog || !BrowserWindow) throw new TypeError('NATIVE_DIALOG_DEPENDENCIES_REQUIRED');
  const activeDialogs = new Set();
  const pause = typeof wait === 'function'
    ? wait
    : () => new Promise(resolve => setTimeout(resolve, focusDelayMs));

  async function waitForFullscreenTransition(parent, entering) {
    const eventName = entering ? 'enter-full-screen' : 'leave-full-screen';
    if (!parent || typeof parent.once !== 'function') {
      await pause();
      return;
    }

    await new Promise(resolve => {
      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        if (typeof parent.removeListener === 'function') parent.removeListener(eventName, finish);
        resolve();
      };
      const timer = setTimeout(finish, 700);
      parent.once(eventName, finish);
      // Electron can update isFullScreen before emitting the native transition
      // event. In that case retain a short settling period for Windows/DWM.
      const stateMatches = typeof parent.isFullScreen === 'function' && parent.isFullScreen() === entering;
      if (stateMatches) setTimeout(finish, Math.min(Math.max(focusDelayMs, 80), 180));
    });
    await pause();
  }

  async function run(method, event, options) {
    if (!['showOpenDialog', 'showSaveDialog', 'showMessageBox'].includes(method)) throw new TypeError('NATIVE_DIALOG_METHOD_INVALID');

    let parent = null;
    try {
      if (event && event.sender && typeof BrowserWindow.fromWebContents === 'function') {
        parent = BrowserWindow.fromWebContents(event.sender);
      }
    } catch (_) {
      parent = null;
    }
    if (parent && typeof parent.isDestroyed === 'function' && parent.isDestroyed()) parent = null;

    const key = parent ? `window:${parent.id}` : `sender:${event && event.sender && event.sender.id || 'unknown'}`;
    if (activeDialogs.has(key)) {
      const error = new Error('Ya hay un diálogo nativo abierto para esta ventana.');
      error.code = 'DIALOG_ALREADY_OPEN';
      throw error;
    }
    activeDialogs.add(key);

    let wasFullScreen = false;
    let wasMaximized = false;
    let wasMinimized = false;
    let wasVisible = false;
    try {
      if (parent) {
        wasFullScreen = typeof parent.isFullScreen === 'function' && parent.isFullScreen();
        wasMaximized = typeof parent.isMaximized === 'function' && parent.isMaximized();
        wasMinimized = typeof parent.isMinimized === 'function' && parent.isMinimized();
        wasVisible = typeof parent.isVisible !== 'function' || parent.isVisible();

        // Windows can place native pickers/message boxes behind a fullscreen
        // Electron window. Restore and focus the real sender window first.
        if (wasMinimized && typeof parent.restore === 'function') parent.restore();
        if (wasFullScreen && typeof parent.setFullScreen === 'function') {
          parent.setFullScreen(false);
          await waitForFullscreenTransition(parent, false);
        } else {
          await pause();
        }
        if (typeof parent.show === 'function') parent.show();
        if (typeof parent.focus === 'function') parent.focus();
        return await dialog[method](parent, options);
      }

      // A missing/destroyed parent must not leave a dead modal reference.
      return await dialog[method](options);
    } finally {
      try {
        if (parent && !(typeof parent.isDestroyed === 'function' && parent.isDestroyed())) {
          if (wasFullScreen && typeof parent.setFullScreen === 'function') {
            parent.setFullScreen(true);
            await waitForFullscreenTransition(parent, true);
          } else if (wasMaximized && typeof parent.maximize === 'function') {
            parent.maximize();
          }
          if (wasMinimized && typeof parent.minimize === 'function') parent.minimize();
          else if (wasVisible && typeof parent.show === 'function') parent.show();
          else if (!wasVisible && typeof parent.hide === 'function') parent.hide();
          if (wasVisible && typeof parent.focus === 'function') parent.focus();
        }
      } finally {
        activeDialogs.delete(key);
      }
    }
  }

  return {
    showOpenDialog: (event, options) => run('showOpenDialog', event, options),
    showSaveDialog: (event, options) => run('showSaveDialog', event, options),
    showMessageBox: (event, options) => run('showMessageBox', event, options),
    isDialogOpen: event => {
      let parent = null;
      try { parent = event && event.sender && BrowserWindow.fromWebContents(event.sender); } catch (_) {}
      const key = parent ? `window:${parent.id}` : `sender:${event && event.sender && event.sender.id || 'unknown'}`;
      return activeDialogs.has(key);
    }
  };
}

module.exports = { createNativeFileDialogs };
