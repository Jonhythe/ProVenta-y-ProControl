# ProControl → ProVenta — Fase 4: paquetes de inventario cifrados por dispositivo

## Estado

**Implementado y probado en el lado de ProControl. No es todavía una integración Android terminada.** El modo `CON APP` permanece deshabilitado (`MOBILE_APP_READY = false`).

Esta fase prepara el primer envío de datos comerciales por archivo USB, pero no abre puertos, no usa Internet/Wi-Fi y no modifica existencias del escritorio.

## 1. Alta de la clave de cifrado del teléfono

La solicitud `.pcdevice` admite dos versiones:

- Versión 1: clave pública Ed25519 para autenticar solicitudes. Se conserva por compatibilidad, pero el dispositivo queda sin capacidad de recibir paquetes de datos.
- Versión 2: incluye `devicePublicKey` (Ed25519) y `deviceEncryptionPublicKey` (RSA SPKI de 3072–8192 bits, exponente 65537). La solicitud completa se firma con Ed25519, por lo que la clave RSA queda vinculada a la identidad del dispositivo.

ProControl guarda la clave RSA pública en `devices.encryption_public_key`. La clave privada RSA nunca se envía al PC y debe permanecer en Android Keystore.

## 2. Formato `.pcinv`

El paquete `procontrol.device-data-package` v1 usa cifrado híbrido:

1. ProControl serializa el snapshot con JSON canónico estable.
2. Genera una clave AES aleatoria de 256 bits y un IV de 96 bits.
3. Cifra el contenido con AES-256-GCM. El encabezado del paquete se utiliza como AAD.
4. Envuelve la clave AES con RSA-OAEP usando SHA-256 y la clave pública RSA del teléfono destinatario.
5. Firma la envoltura completa con Ed25519 de la instalación ProControl.

El encabezado identifica `installationId`, `authorizationId`, `deviceId`, `posId`, tipo, fecha, vencimiento y hash del contenido. La firma cubre metadatos, clave envuelta, IV, tag y ciphertext. El vencimiento actual es de 24 horas.

La app Android deberá verificar primero la firma usando la clave pública fijada desde la ficha `.pcpair`; comprobar instalación, autorización, dispositivo, POS y vencimiento; descifrar la clave AES con Android Keystore; descifrar AES-GCM y comparar el SHA-256 del JSON recuperado. En Android, la operación RSA-OAEP debe configurar explícitamente `OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT)` para coincidir con Node/OpenSSL.

## 3. Datos incluidos en el snapshot

La exportación se realiza por acción explícita del Dueño, seleccionando un teléfono autorizado y un POS.

Incluye únicamente:

- Productos del inventario del POS seleccionado, con `productId`, nombre, unidad, familia, cantidad y precios de venta existentes.
- Precio CUP en efectivo (`sale`), precio CUP por transferencia (`saleTransf`) y sus datos de modo porcentual/manual cuando existan.
- Precio en divisas (`saleUSD`) y su código de moneda (`saleCurrency`), además de la moneda personalizada cuando sea `OTRA`.
- Fichas de catálogo que correspondan a los productos de ese POS, con nombre, unidad, familia y alias disponibles.
- Tasa USD/CUP si ProControl tiene una tasa positiva configurada.

No incluye el almacén central, inventarios de otros POS, costes de adquisición, contraseñas, usuarios, teléfonos de trabajadores, historial de ventas ni campos de caja/conversión a caja. Los productos sin `productId` estable, filas duplicadas o cantidades inválidas detienen la exportación; no se corrigen por nombre ni se fusionan automáticamente.

No se inventan tasas EUR/MLC: en este contrato solo se transmite USD/CUP porque es la tasa identificada en la persistencia actual.

## 4. Controles

- Solo el Dueño puede consultar destinos y exportar snapshots; el control se ejecuta en `main.js`, no solo en la interfaz.
- El teléfono debe estar habilitado y tener autorización activa para la instalación actual.
- No se exporta a dispositivos antiguos sin clave RSA de cifrado registrada.
- Se vuelve a comprobar la autorización dentro de la transacción de persistencia del paquete.
- La idempotencia por `requestId` devuelve el mismo archivo solo mientras el dispositivo siga autorizado y el paquete no haya caducado; un `requestId` con destino o contenido distinto se rechaza.
- La revocación bloquea exportaciones nuevas y también impide recuperar desde ProControl un paquete idempotente anterior.
- El archivo guardado contiene ciphertext, no el inventario en claro.

## 5. Límites no resueltos

- La app Android todavía no genera el enrolamiento v2 ni descifra `.pcinv`.
- No se ha probado el intercambio en un teléfono físico.
- El archivo que ya fue exportado y copiado a un teléfono no puede revocarse a distancia mientras el teléfono está desconectado. La expiración reduce la ventana, pero no equivale a borrado remoto.
- Esta fase no asigna ni abre turnos, no autoriza ventas y no cambia el inventario del PC.
- No se habilita `CON APP` ni `MOBILE_APP_READY`.
- El límite de contenido por paquete es 16 MiB; el archivo cifrado permite un margen adicional de envoltura.

## 6. Pruebas

- `tools/test-proventa-device-package.js`: enrolamiento v2, RSA-OAEP, AES-GCM, firma Ed25519, no exposición en claro, rechazo de clave incorrecta, integridad, idempotencia, revocación y compatibilidad legacy sin cifrado.
- `tools/test-proventa-snapshot.js`: aislamiento por POS, campos comerciales, tasa, IDs estables, rechazo de duplicados y exclusión de costes/cajas.
- `tools/test-proventa-snapshot-ui.js`: conexión de UI, preload, IPC y validación de rol Dueño.

Ejecutar desde `app`:

```powershell
node tools/test-proventa-device-package.js
node tools/test-proventa-snapshot.js
node tools/test-proventa-snapshot-ui.js
npm run check-source
```
