// ============================================================
// PROCONTROL - PROCESO PRINCIPAL (Electron)
// ============================================================
// - Puerta de licencias: sin licencia valida solo se sirve
//   license.html; con licencia, splash + app.
// - Protocolo app:// en contexto SEGURO (crypto.subtle activo,
//   necesario para el sistema PBKDF2 del HTML).
// - SQLite integrado (sin modulos nativos que compilar).
// - Dialogo de impresion nativo para las ventanas de recibos/IPV.
// ============================================================
const { app, BrowserWindow, ipcMain, protocol, net, Menu, shell, dialog, safeStorage, clipboard } = require('electron');
const crypto = require('node:crypto');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');

// ------------------------------------------------------------
// CARPETA DE DATOS: %APPDATA%\ProControl
// Debe fijarse ANTES de app.whenReady() y de cualquier getPath().
// Sin esto, Electron usa el "name" de package.json
// (procontrol-desktop) y los datos quedaban en otra carpeta.
// ------------------------------------------------------------
const APP_DATA_DIR = app.getPath('appData');
const USER_DATA_DIR = path.join(APP_DATA_DIR, 'ProControl');
const LEGACY_USER_DATA_DIR = path.join(APP_DATA_DIR, 'procontrol-desktop');
app.setPath('userData', USER_DATA_DIR);

// Identidad estable de ProControl en la barra de tareas de Windows.
// Se establece antes de crear cualquier BrowserWindow.
const WINDOWS_APP_ID = 'com.jonathansotero.procontrol';
if (process.platform === 'win32') {
  app.setAppUserModelId(WINDOWS_APP_ID);
}

// ------------------------------------------------------------
// Bloqueo de instancia unica: si el cliente abre ProControl dos
// veces, dos procesos no deben escribir la misma base de datos.
// ------------------------------------------------------------
const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
  app.quit();
}

app.on('second-instance', () => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
  }
});

const RENDERER_DIR = path.resolve(__dirname, '..', 'renderer');
const RENDERER_PREFIX = RENDERER_DIR + path.sep;

const license = require('./license');
const { MobileBridgeStore } = require('./mobile-bridge/store');
const { MobileControlPlane } = require('./mobile-bridge/control-plane');
const { buildProVentaInventorySnapshot } = require('./mobile-bridge/proventa-snapshot');
const { writeFragmentSet, readFragmentSet, MAX_TRANSFER_BYTES } = require('./mobile-bridge/fragments');
const { normalizePOSId: normalizeSalesPOSId, resolveDesktopSalesGate, authorizeSalesLedgerDelta } = require('./mobile-bridge/sales-write-policy');
const { RecordArchiveStore } = require('./record-archive-store');
const { wipeOperationalStoreData } = require('./security/authorized-store-wipe');
let mobileBridgeStore = null;
let mobileControlPlane = null;
let recordArchiveStore = null;
function getRecordArchiveStore() {
  if (!recordArchiveStore) recordArchiveStore = new RecordArchiveStore(USER_DATA_DIR);
  return recordArchiveStore;
}
function requireArchiveOwner(event, input) {
  const actor = getPrivilegedActor(event, input);
  if (!actor || actor.role !== 'Dueño' || !license.isLicensed()) return null;
  return actor;
}
function getMobileBridgeStore() {
  if (!mobileBridgeStore) mobileBridgeStore = new MobileBridgeStore(USER_DATA_DIR, { safeStorage, desktopId: license.getDeviceId() });
  if (!mobileControlPlane) {
    mobileControlPlane = new MobileControlPlane(mobileBridgeStore, {
      deviceId: license.getDeviceId(),
      verifyPointLicense: (token, posId, posName) => license.verifyPointLicense(token, posId, posName),
      getInstallationLicense: () => license.loadLicense(),
      // Esta instalación incorpora el flujo Android de apertura/cierre firmado.
      mobileAppReady: true
    });
    mobileBridgeStore.controlPlane = mobileControlPlane;
  }
  return mobileBridgeStore;
}
function getMobileControlPlane() { getMobileBridgeStore(); return mobileControlPlane; }

// Exportación fail-closed: escribe primero un temporal exclusivo, fuerza los
// bytes a disco, verifica el temporal y publica el destino sin sobrescribirlo.
// Finalmente vuelve a leer el destino real y ejecuta su validador criptográfico.
function writeExportFileVerified(targetPath, content, validator) {
  const target = path.resolve(String(targetPath || ''));
  const directory = path.dirname(target);
  const base = path.basename(target);
  if (!target || !base || !fs.existsSync(directory)) throw Object.assign(new Error('EXPORT_DIRECTORY_UNAVAILABLE'), { code: 'EXPORT_DIRECTORY_UNAVAILABLE' });
  const bytes = Buffer.isBuffer(content) ? Buffer.from(content) : Buffer.from(String(content), 'utf8');
  if (!bytes.length || bytes.length > MAX_TRANSFER_BYTES) throw Object.assign(new Error('EXPORT_SIZE_INVALID'), { code: 'EXPORT_SIZE_INVALID' });
  const temporary = path.join(directory, `.${base}.${process.pid}.${crypto.randomBytes(10).toString('hex')}.tmp`);
  let fd = null;
  let published = false;
  try {
    if (fs.existsSync(target)) throw Object.assign(new Error('EXPORT_DESTINATION_EXISTS'), { code: 'EXPORT_DESTINATION_EXISTS' });
    fd = fs.openSync(temporary, 'wx', 0o600);
    fs.writeFileSync(fd, bytes);
    fs.fsyncSync(fd);
    fs.closeSync(fd); fd = null;
    const staged = fs.readFileSync(temporary);
    if (staged.length !== bytes.length || !crypto.timingSafeEqual(staged, bytes)) throw Object.assign(new Error('EXPORT_TEMP_READBACK_MISMATCH'), { code: 'EXPORT_TEMP_READBACK_MISMATCH' });
    if (typeof validator === 'function') validator(staged);
    // Preferimos hard-link atómico. En FAT/exFAT algunos volúmenes no lo admiten;
    // entonces usamos rename atómico en el mismo directorio, siempre con destino libre.
    try {
      fs.linkSync(temporary, target);
    } catch (error) {
      const unsupportedLink = error && ['EPERM', 'ENOTSUP', 'EOPNOTSUPP', 'EXDEV', 'ENOSYS'].includes(error.code);
      if (!unsupportedLink || fs.existsSync(target)) throw error;
      fs.renameSync(temporary, target);
    }
    published = true;
    const finalBytes = fs.readFileSync(target);
    if (finalBytes.length !== bytes.length || !crypto.timingSafeEqual(finalBytes, bytes)) throw Object.assign(new Error('EXPORT_FINAL_READBACK_MISMATCH'), { code: 'EXPORT_FINAL_READBACK_MISMATCH' });
    if (typeof validator === 'function') validator(finalBytes);
    return { bytes: finalBytes.length, sha256: crypto.createHash('sha256').update(finalBytes).digest('hex') };
  } finally {
    if (fd !== null) { try { fs.closeSync(fd); } catch (_) {} }
    try { fs.unlinkSync(temporary); } catch (_) {}
    // Nunca se borra el destino publicado en un error de validación: puede
    // ser la única copia escrita y debe quedar disponible para recuperación.
    void published;
    bytes.fill(0);
  }
}

// Reautenticación para operaciones privilegiadas: verifica los mismos usuarios/roles
// almacenados por ProControl. El renderer nunca puede elegir el rol del actor.
const privilegedSessions = new Map();
const authAttempts = new Map();
function decodeStoredValue(raw) {
  if (typeof raw !== 'string' || !raw) return null;
  try {
    const outer = Buffer.from(raw, 'base64').toString('utf8');
    const prefix = 'PROCONTROL_SECRET_2026:';
    if (outer.startsWith(prefix)) return JSON.parse(Buffer.from(outer.slice(prefix.length), 'base64').toString('utf8'));
  } catch (_) {}
  try { return JSON.parse(raw); } catch (_) { return null; }
}
function readAppStoreKeys(keys) {
  const result = {};
  const dbFile = path.join(USER_DATA_DIR, 'procontrol.db');
  try {
    const { DatabaseSync } = require('node:sqlite');
    if (fs.existsSync(dbFile)) {
      const db = new DatabaseSync(dbFile, { readOnly: true });
      try {
        for (const key of keys) {
          const row = db.prepare('SELECT value FROM store WHERE key=?').get(key);
          if (row) result[key] = decodeStoredValue(row.value);
        }
      } finally { db.close(); }
    }
  } catch (error) { console.warn('[ProControl] No se pudieron consultar los datos de autenticación SQLite:', error && error.message); }
  if (!Object.keys(result).length) {
    try {
      const legacy = JSON.parse(fs.readFileSync(path.join(USER_DATA_DIR, 'procontrol.json'), 'utf8'));
      for (const key of keys) if (legacy && Object.prototype.hasOwnProperty.call(legacy, key)) result[key] = decodeStoredValue(legacy[key]) ?? legacy[key];
    } catch (_) {}
  }
  return result;
}
function secureEqualHex(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || !/^[a-f0-9]+$/i.test(a) || !/^[a-f0-9]+$/i.test(b) || a.length !== b.length) return false;
  try { return crypto.timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex')); } catch (_) { return false; }
}
function verifyStoredPassword(password, stored) {
  if (typeof stored !== 'string' || !stored || typeof password !== 'string') return false;
  try {
    if (stored.startsWith('pbkdf2$')) {
      const parts = stored.split('$');
      if (parts.length !== 4) return false;
      const iterations = Number(parts[1]);
      const salt = parts[2]; const expected = parts[3];
      if (!Number.isInteger(iterations) || iterations < 1 || iterations > 1000000 || !/^[a-f0-9]{32}$/i.test(salt) || !/^[a-f0-9]{64}$/i.test(expected)) return false;
      const actual = crypto.pbkdf2Sync(password, Buffer.from(salt, 'hex'), iterations, 32, 'sha256').toString('hex');
      return secureEqualHex(actual, expected);
    }
    if (/^[a-f0-9]{64}$/i.test(stored)) return secureEqualHex(crypto.createHash('sha256').update(password, 'utf8').digest('hex'), stored);
  } catch (_) {}
  return false;
}
function authenticatePrivilegedUser(event, input) {
  if (!isAppSender(event) || !license.isLicensed()) return { ok: false, code: 'ORIGIN_DENIED' };
  const data = input && typeof input === 'object' ? input : {};
  const userInput = String(data.user || '').trim();
  const password = String(data.password || '');
  if (!userInput || !password || userInput.length > 100 || password.length > 512) return { ok: false, code: 'INVALID_CREDENTIALS' };
  const now = Date.now();
  const attempts = authAttempts.get(event.sender.id) || { count: 0, lockedUntil: 0 };
  if (attempts.lockedUntil > now) return { ok: false, code: 'AUTH_RATE_LIMITED', retryAfterMs: attempts.lockedUntil - now };
  const db = readAppStoreKeys(['elite_user_roles', 'elite_user_passwords']);
  const roles = db.elite_user_roles && typeof db.elite_user_roles === 'object' ? db.elite_user_roles : {};
  const passwords = db.elite_user_passwords && typeof db.elite_user_passwords === 'object' ? db.elite_user_passwords : {};
  const key = Object.keys(roles).find(name => name.toLowerCase() === userInput.toLowerCase());
  const role = key ? roles[key] : null;
  const stored = key ? passwords[key] : null;
  if (!key || !['Dueño', 'Administrador'].includes(role) || !verifyStoredPassword(password, stored)) {
    const count = attempts.count + 1;
    authAttempts.set(event.sender.id, { count: count >= 5 ? 0 : count, lockedUntil: count >= 5 ? now + 60000 : 0 });
    return { ok: false, code: 'AUTH_FAILED' };
  }
  authAttempts.delete(event.sender.id);
  const token = crypto.randomBytes(32).toString('base64url');
  privilegedSessions.set(token, { senderId: event.sender.id, user: key, role, expiresAt: now + 5 * 60 * 1000 });
  return { ok: true, token, user: key, role, expiresAt: now + 5 * 60 * 1000 };
}
function getPrivilegedActor(event, input) {
  if (!isAppSender(event) || !input || typeof input.authToken !== 'string') return null;
  const session = privilegedSessions.get(input.authToken);
  if (!session || session.senderId !== event.sender.id || session.expiresAt <= Date.now() || !['Dueño', 'Administrador'].includes(session.role)) {
    if (session) privilegedSessions.delete(input.authToken);
    return null;
  }
  return { user: session.user, role: session.role };
}
function getOwnerPrivilegedActor(event, input) {
  const actor = getPrivilegedActor(event, input);
  return actor && actor.role === 'Dueño' ? actor : null;
}
function readCurrentPOSList() {
  const db = readAppStoreKeys(['elite_pos']);
  return Array.isArray(db.elite_pos) ? db.elite_pos.filter(p => p && typeof p === 'object').map(p => ({ id: String(p.id || ''), name: String(p.name || '') })).filter(p => p.id && p.name) : [];
}


// Lee solo la política persistida. No inicializa el puente ni migra la clave privada
// mientras la instalación siga en compatibilidad legacy (estricto desactivado).
function readMobileSalesPolicySnapshot() {
  const dbFile = path.join(USER_DATA_DIR, 'mobile-bridge.db');
  if (!fs.existsSync(dbFile)) return { ok: true, exists: false, strictLicensing: false, modes: new Map() };
  let db = null;
  try {
    const { DatabaseSync } = require('node:sqlite');
    db = new DatabaseSync(dbFile, { readOnly: true });
    const hasTable = name => !!db.prepare("SELECT 1 AS ok FROM sqlite_master WHERE type='table' AND name=?").get(name);
    let strictLicensing = false;
    const modes = new Map();
    if (hasTable('bridge_meta')) {
      const row = db.prepare("SELECT value FROM bridge_meta WHERE key='strict_pos_licensing'").get();
      strictLicensing = !!(row && row.value === '1');
    }
    if (hasTable('pos_modes')) {
      for (const row of db.prepare('SELECT pos_id, mode FROM pos_modes').all()) modes.set(String(row.pos_id), String(row.mode));
    }
    return { ok: true, exists: true, strictLicensing, modes };
  } catch (_) {
    return { ok: false, code: 'POS_POLICY_UNAVAILABLE' };
  } finally {
    try { if (db) db.close(); } catch (_) {}
  }
}

// Segunda barrera de autorización para el libro de tickets: se ejecuta en el proceso
// principal justo antes de persistir elite_sales_ledger. No confía en la validación del renderer.
function authorizeSalesLedgerWrite(event, nextEncodedLedger, currentLedgerOverride) {
  if (!isAppSender(event) || !license.isLicensed()) return denied();
  const protectedKeys = ['elite_sales_ledger', 'elite_closing_history', 'elite_closing_sessions', 'elite_transfers'];
  const currentData = currentLedgerOverride === undefined ? readAppStoreKeys(protectedKeys) : null;
  const currentLedger = currentLedgerOverride === undefined
    ? (currentData.elite_sales_ledger == null ? [] : currentData.elite_sales_ledger)
    : decodeStoredValue(currentLedgerOverride);
  const safeCurrentLedger = Array.isArray(currentLedger) ? currentLedger : [];
  // No se permite borrar el libro ni reiniciar el almacén si existen cierres o transferencias históricas.
  if (nextEncodedLedger == null) {
    if (currentLedgerOverride === undefined) {
      const hasHistory = protectedKeys.some(key => {
        const value = currentData[key];
        if (Array.isArray(value)) return value.length > 0;
        return value && typeof value === 'object' && Object.keys(value).length > 0;
      });
      return hasHistory ? { ok: false, code: 'HISTORY_DELETE_BLOCKED' } : { ok: true, authorizedTransactions: 0, reset: true };
    }
    return safeCurrentLedger.length === 0
      ? { ok: true, authorizedTransactions: 0, reset: true }
      : { ok: false, code: 'SALES_HISTORY_DELETE_BLOCKED' };
  }
  if (typeof nextEncodedLedger !== 'string' || nextEncodedLedger.length > 12000000) {
    return { ok: false, code: 'SALES_LEDGER_INVALID' };
  }
  const nextLedger = decodeStoredValue(nextEncodedLedger);
  if (!Array.isArray(nextLedger)) return { ok: false, code: 'SALES_LEDGER_INVALID' };
  let policySnapshot = null;
  return authorizeSalesLedgerDelta(safeCurrentLedger, nextLedger, posId => {
    if (!policySnapshot) policySnapshot = readMobileSalesPolicySnapshot();
    return resolveDesktopSalesGate(posId, policySnapshot, id => getMobileControlPlane().canDesktopSell(id));
  }, { maxTransactions: 10000 });
}


// Estado de licencia calculado UNA vez y refrescado al activar.
// El protocolo app:// NO ejecuta reg.exe ni verifica en cada peticion.
let licensedState = false;

// Protocolo app:// preferido antes de que arranque el resto del sistema
protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true } }
]);

let win = null;

// ------------------------------------------------------------
// Migracion de la base de datos desde la carpeta legada
// ------------------------------------------------------------
function migrateLegacyDatabase() {
  try {
    fs.mkdirSync(USER_DATA_DIR, { recursive: true });
    const newDb = path.join(USER_DATA_DIR, 'procontrol.db');
    const oldDb = path.join(LEGACY_USER_DATA_DIR, 'procontrol.db');

    // Solo si la nueva carpeta NO tiene base de datos y la vieja SI.
    if (!fs.existsSync(newDb) && fs.existsSync(oldDb)) {
      const suffixes = ['', '-wal', '-shm'];
      for (const suffix of suffixes) {
        const src = oldDb + suffix;
        if (fs.existsSync(src)) fs.copyFileSync(src, newDb + suffix);
      }
      console.log('[ProControl] Base de datos copiada desde ' + LEGACY_USER_DATA_DIR + ' a ' + USER_DATA_DIR);
    }
  } catch (err) {
    console.error('[ProControl] No se pudo migrar la base de datos: ' + (err && err.message));
  }
}

function refreshLicenseState() {
  try {
    licensedState = license.isLicensed();
  } catch (_) {
    licensedState = false;
  }
  return licensedState;
}

// ------------------------------------------------------------
// Ventana principal
// ------------------------------------------------------------
const SETTINGS_ICON = () => {
  // En Windows empaquetado, el ICO debe existir fuera de app.asar.
  // package.json lo extrae mediante build.asarUnpack: assets/icono.ico.
  const externalIcon = path.join(
    process.resourcesPath,
    'app.asar.unpacked',
    'assets',
    'icono.ico'
  );

  // Una instalación de Windows nunca debe arrancar sin su icono oficial.
  if (process.platform === 'win32' && app.isPackaged) {
    if (!fs.existsSync(externalIcon)) {
      throw new Error(
        `[ProControl] Falta el icono oficial de Windows: ${externalIcon}`
      );
    }

    return externalIcon;
  }

  // Desarrollo y plataformas distintas de Windows: usar el recurso normal.
  const preferred = path.join(
    __dirname,
    '..',
    'assets',
    process.platform === 'win32' ? 'icono.ico' : 'icono.png'
  );

  if (fs.existsSync(preferred)) return preferred;
  return path.join(__dirname, '..', 'assets', 'icono.png');
};

function startWindow() {
  const appIconPath = SETTINGS_ICON();

  // Configuración común de la ventana
  const commonWindowOptions = {
    width: 1500,
    height: 950,
    minWidth: 1150,
    minHeight: 720,
    backgroundColor: '#000d1a',
    autoHideMenuBar: true,
    fullscreen: true,             // abre en pantalla completa (sin barra de tareas ni de titulo)
    title: 'ProControl',
    icon: appIconPath,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,               // el preload necesita node:sqlite
      webSecurity: true,
      allowRunningInsecureContent: false,
      spellcheck: false,
      devTools: false
    }
  };

  // Verificar licencia antes de crear la ventana
  if (!license.isLicensed()) {
    win = new BrowserWindow(commonWindowOptions);
    win.loadURL('app://license.html');
  } else {
    win = new BrowserWindow(commonWindowOptions);
    win.loadURL('app://splash.html');
  }

  // Refuerza el icono de la ventana y la identidad de la barra de tareas.
  if (process.platform === 'win32') {
    win.setIcon(appIconPath);
    if (typeof win.setAppDetails === 'function') {
      win.setAppDetails({
        appId: WINDOWS_APP_ID,
        appIconPath,
        appIconIndex: 0,
        relaunchDisplayName: 'ProControl',
        relaunchCommand: process.execPath
      });
    }
  }

  win.setMenuBarVisibility(false);
  win.on('page-title-updated', (e) => e.preventDefault());
  win.once('ready-to-show', () => win.show());
  // DevTools solo en desarrollo (quitar en producción)
  if (process.env.NODE_ENV === 'development') {
    win.webContents.openDevTools();
  }

  // Las ventanas de impresion (recibos, IPV, inventario) abren como
  // Chromium nativas y se les permite usar el dialogo de impresion.
  win.webContents.setWindowOpenHandler(({ url }) => {
    return {
      action: 'allow',
      overrideBrowserWindowOptions: {
        autoHideMenuBar: true,
        title: 'Vista de impresion',
        webPreferences: {
          contextIsolation: true,
          nodeIntegration: false,
          sandbox: false,
          devTools: false
        }
      }
    };
  });

  loadRightPage();
}

function loadRightPage() {
  // Puerta de licencia: sin licencia valida, solo la pantalla de activacion.
  // Con licencia: la animacion de bienvenida antes de la app.
  const target = licensedState ? 'app://splash.html' : 'app://license.html';
  if (win) win.loadURL(target);
}

// ------------------------------------------------------------
// Servidor del protocolo app:// (archivos locales de renderer/)
// IMPORTANTE: con un esquema "standard", app://splash.html pone
// el nombre del archivo en el HOST y la ruta queda en "/".
// Hay que reconstruir la ruta con host + pathname.
//
// Seguridad:
// - Se decodifica %2f ANTES de comprobar.
// - path.resolve + startsWith(renderer + separador): nada fuera.
// - Sin licencia SOLO se sirve license.html (y lo que esta necesite).
// ------------------------------------------------------------
function registerAppProtocol() {
  protocol.handle('app', (request) => {
    let file;

    try {
      const u = new URL(request.url);
      let rel = (u.hostname || '') + (u.pathname === '/' ? '' : u.pathname);
      try {
        rel = decodeURIComponent(rel);
      } catch (_) {
        rel = '';
      }
      rel = rel.replace(/^\/+/, '');

      const fallback = licensedState ? 'index.html' : 'license.html';
      if (!rel) rel = fallback;

      const resolved = path.resolve(RENDERER_DIR, rel);
      const inside = resolved === RENDERER_DIR || resolved.startsWith(RENDERER_PREFIX);

      // Sin licencia solo se permite license.html.
      if (!licensedState && rel !== 'license.html') {
        file = path.join(RENDERER_DIR, 'license.html');
      } else if (!inside) {
        file = path.join(RENDERER_DIR, fallback);
      } else {
        file = resolved;
        if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
          file = path.join(RENDERER_DIR, fallback);
        }
      }
    } catch (_) {
      file = path.join(RENDERER_DIR, licensedState ? 'index.html' : 'license.html');
    }

    return net.fetch(pathToFileURL(file).toString());
  });
}

// ------------------------------------------------------------
// IPC
// ------------------------------------------------------------
// Solo se aceptan llamadas nacidas de una pagina app://.
function isAppSender(event) {
  try {
    const frame = event && event.senderFrame;
    const rawUrl = frame && frame.url;
    if (typeof rawUrl !== 'string') return false;

    const url = new URL(rawUrl);
    // Solo se autorizan los documentos principales de ProControl.
    // No basta con que la URL empiece por "app://".
    if (url.protocol !== 'app:') return false;
    if (!['license.html', 'splash.html', 'index.html'].includes(url.hostname)) {
      return false;
    }
    if (url.pathname !== '/' && url.pathname !== '') return false;

    return true;
  } catch (_) {
    return false;
  }
}

function denied() {
  return { ok: false, code: 'FORMATO', error: 'Origen no autorizado.' };
}

ipcMain.on('pc:db-path', (event) => {
  if (!isAppSender(event)) {
    event.returnValue = null;
    return;
  }

  event.returnValue = path.join(app.getPath('userData'), 'procontrol.db');
});

ipcMain.on('mobile-control:authorize-sales-ledger-write', (event, encodedLedger) => {
  try { event.returnValue = authorizeSalesLedgerWrite(event, encodedLedger); }
  catch (_) { event.returnValue = { ok: false, code: 'POS_POLICY_UNAVAILABLE' }; }
});

ipcMain.on('pc:store-load', (event) => {
  if (!isAppSender(event)) {
    event.returnValue = {};
    return;
  }

  // Respaldo JSON por si node:sqlite no estuviera disponible.
  const file = path.join(app.getPath('userData'), 'procontrol.json');
  try {
    event.returnValue = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {
    event.returnValue = {};
  }
});

ipcMain.on('pc:store-save', (event, data) => {
  if (!isAppSender(event)) {
    event.returnValue = false;
    return;
  }

  const file = path.join(app.getPath('userData'), 'procontrol.json');
  try {
    const safeData = data && typeof data === 'object' ? data : {};
    let currentJson = {};
    try { currentJson = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) {}
    const protectedKeys = ['elite_sales_ledger', 'elite_closing_history', 'elite_closing_sessions', 'elite_transfers'];
    for (const key of protectedKeys) {
      const oldValue = decodeStoredValue(currentJson[key]);
      const newValue = decodeStoredValue(safeData[key]);
      const oldHasHistory = Array.isArray(oldValue) ? oldValue.length > 0 : !!(oldValue && typeof oldValue === 'object' && Object.keys(oldValue).length > 0);
      if (!oldHasHistory) continue;
      if (Array.isArray(oldValue)) {
        if (!Array.isArray(newValue) || oldValue.some(oldRecord => {
          if (!oldRecord || typeof oldRecord !== 'object') return !newValue.includes(oldRecord);
          const id = String(oldRecord.id || oldRecord.closingId || oldRecord.sessionId || oldRecord.transferId || '');
          return id ? !newValue.some(newRecord => newRecord && typeof newRecord === 'object' && String(newRecord.id || newRecord.closingId || newRecord.sessionId || newRecord.transferId || '') === id) : newValue.length < oldValue.length;
        })) { event.returnValue = false; return; }
      } else if (!newValue || typeof newValue !== 'object' || Array.isArray(newValue) || Object.keys(newValue).length < Object.keys(oldValue).length) {
        event.returnValue = false; return;
      }
    }
    const hasNextLedger = Object.prototype.hasOwnProperty.call(safeData, 'elite_sales_ledger');
    const hasCurrentLedger = Object.prototype.hasOwnProperty.call(currentJson, 'elite_sales_ledger');
    if (hasNextLedger) {
      const approved = authorizeSalesLedgerWrite(event, safeData.elite_sales_ledger, currentJson.elite_sales_ledger);
      if (!approved || approved.ok !== true) { event.returnValue = false; return; }
    } else if (hasCurrentLedger) {
      const approved = authorizeSalesLedgerWrite(event, null, currentJson.elite_sales_ledger);
      if (!approved || approved.ok !== true) { event.returnValue = false; return; }
    }
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(safeData), 'utf8');
    event.returnValue = true;
  } catch (_) {
    event.returnValue = false;
  }
});

// Borrado total explícito, reservado al Dueño y reautenticado en el proceso principal.
// Los guardados ordinarios siguen sujetos a authorizeSalesLedgerWrite y no pueden
// eliminar historiales; esta vía solo se ejecuta tras doble confirmación + contraseña.
ipcMain.on('pc:store-wipe-owner', (event, input) => {
  if (!isAppSender(event) || !license.isLicensed()) {
    event.returnValue = { ok: false, code: 'ORIGIN_DENIED', stage: 'PRECHECK', detail: 'Origen o licencia no autorizados.' };
    return;
  }

  const credentials = input && typeof input === 'object' ? input : {};
  const requestedUser = String(credentials.user || '').trim();
  const password = typeof credentials.password === 'string' ? credentials.password : '';
  if (!requestedUser || !password) {
    event.returnValue = { ok: false, code: 'INVALID_CREDENTIALS', stage: 'AUTHENTICATION', detail: 'Se requiere usuario y contraseña.' };
    return;
  }

  const auth = authenticatePrivilegedUser(event, { user: requestedUser, password });
  if (!auth || auth.ok !== true) {
    event.returnValue = { ok: false, code: auth && auth.code || 'AUTH_FAILED', stage: 'AUTHENTICATION', detail: 'No se pudo reautenticar al usuario.' };
    return;
  }
  // No basta con el rol que afirma el renderer: se comprueba el rol real cargado
  // desde el almacén persistido y se exige que coincida con la cuenta activa solicitada.
  if (auth.role !== 'Dueño' || String(auth.user || '').toLowerCase() !== requestedUser.toLowerCase()) {
    if (auth.token) privilegedSessions.delete(auth.token);
    event.returnValue = { ok: false, code: 'OWNER_REQUIRED', stage: 'AUTHENTICATION', detail: 'Solo el Dueño autenticado puede reiniciar los datos.' };
    return;
  }
  if (auth.token) privilegedSessions.delete(auth.token);

  try {
    // Utilizar la conexión viva del puente evita competir con ella en Windows
    // y permite que el módulo probado vacíe todas las tablas operativas, manteniendo
    // la identidad estable de instalación en bridge_meta.
    const bridgeStore = getMobileBridgeStore();
    const result = wipeOperationalStoreData({
      userDataDir: USER_DATA_DIR,
      bridgeDb: bridgeStore.db,
      archiveStore: getRecordArchiveStore()
    });
    event.returnValue = result;
  } catch (error) {
    console.error('[ProControl] No se pudo completar el borrado total autorizado:', error && error.message);
    event.returnValue = {
      ok: false,
      code: error && error.code || 'STORE_WIPE_FAILED',
      stage: 'PRECHECK',
      detail: String(error && error.message || 'No se pudo iniciar el borrado autorizado.').replace(/[\r\n\t]+/g, ' ').slice(0, 240)
    };
  }
});

// API local-first para futura aplicación móvil. No abre puertos ni sincroniza por red.
// Cada paquete recibido queda pendiente de revisión; nunca modifica inventario/cierres automáticamente.
ipcMain.handle('mobile-bridge:status', (event) => {
  if (!isAppSender(event) || !license.isLicensed()) return denied();
  try { return { ok: true, ...getMobileBridgeStore().status() }; }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-bridge:create-pairing-code', (event, input) => {
  // Emisión antigua con alcance POS deshabilitada: las nuevas autorizaciones son por instalación.
  return { ok: false, code: 'LEGACY_POS_PAIRING_DISABLED' };
});

ipcMain.handle('mobile-bridge:pair-device', (event, input) => {
  // El alta nueva se realiza únicamente mediante la solicitud .pcdevice firmada,
  // importada por el endpoint proventa:import-device-enrollment.
  return { ok: false, code: 'LEGACY_POS_PAIRING_DISABLED' };
});
ipcMain.handle('mobile-bridge:list-devices', (event) => {
  if (!isAppSender(event) || !license.isLicensed()) return denied();
  try { return { ok: true, devices: getMobileBridgeStore().listDevices() }; }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-bridge:set-device-enabled', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileBridgeStore().setDeviceEnabled(input && input.deviceId, input && input.enabled, actor.user); }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-bridge:receive-package', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileBridgeStore().importOfflineBundle(JSON.stringify(input || {})); }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-bridge:list-pending', (event) => {
  if (!isAppSender(event) || !license.isLicensed()) return denied();
  try { return { ok: true, packages: getMobileBridgeStore().listPendingPackages() }; }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-bridge:get-package', (event, packageId) => {
  if (!isAppSender(event) || !license.isLicensed()) return denied();
  try { return { ok: true, package: getMobileBridgeStore().getPackage(packageId) }; }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-bridge:decide-package', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileBridgeStore().markPackage(input && input.packageId, input && input.decision, actor.user, input && input.note); }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});

// Intercambio offline: todos los diálogos y las rutas de archivo se gestionan en el proceso principal.
// El renderer nunca puede indicar una ruta arbitraria para lectura/escritura.
ipcMain.handle('mobile-bridge:import-file', async (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try {
    const picked = await dialog.showOpenDialog(win, {
      title: 'Importar paquete firmado de ProControl',
      properties: ['openFile'],
      filters: [{ name: 'Paquetes ProControl (*.pcoutbox; *.pcpkg; *.json; *.pcmanifest)', extensions: ['pcoutbox', 'pcpkg', 'json', 'pcmanifest'] }]
    });
    if (picked.canceled || !picked.filePaths || !picked.filePaths.length) return { ok: false, canceled: true, code: 'CANCELLED' };
    const selected = picked.filePaths[0];
    const stat = fs.statSync(selected);
    if (!stat.isFile() || stat.size > MAX_TRANSFER_BYTES) return { ok: false, code: 'PACKAGE_TOO_LARGE' };
    let contents;
    let fragmentCount = 0;
    if (path.extname(selected).toLowerCase() === '.pcmanifest') {
      const assembled = readFragmentSet(selected);
      contents = assembled.contents.toString('utf8');
      fragmentCount = assembled.manifest.totalChunks;
    } else {
      contents = fs.readFileSync(selected, 'utf8');
    }
    const result = getMobileBridgeStore().importOfflineBundle(contents);
    if (result.ok) { result.fileName = path.basename(selected); if (fragmentCount) result.fragmentCount = fragmentCount; }
    return result;
  } catch (error) {
    console.error('[ProControl] Falló la importación offline:', error && error.message);
    return { ok: false, code: error && error.code || 'IMPORT_FAILED' };
  }
});
ipcMain.handle('mobile-bridge:export-desktop-package', (event, input) => {
  // No exportar datos empresariales en paquetes genéricos sin destino criptográfico.
  // Se habilitará cuando el paquete esté cifrado y ligado a un dispositivo activo.
  return { ok: false, code: 'DEVICE_BOUND_EXPORT_NOT_READY' };
});
ipcMain.handle('mobile-bridge:export-package-fragments', (event, input) => {
  // Los fragmentos QR/USB no deben transportar datos de empresa sin destino autorizado.
  return { ok: false, code: 'DEVICE_BOUND_EXPORT_NOT_READY' };
});
ipcMain.handle('mobile-bridge:export-pairing-descriptor', (event, input) => {
  // El descriptor heredado está vinculado a POS y no se puede usar en ProVenta.
  return { ok: false, code: 'LEGACY_POS_PAIRING_DISABLED' };
});
ipcMain.handle('mobile-bridge:begin-package-apply', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileBridgeStore().beginPackageApply(input && input.packageId, actor.user); }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-bridge:fail-package-apply', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileBridgeStore().failPackageApply(input && input.packageId, actor.user, input && input.errorCode); }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-bridge:mark-package-applied', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileBridgeStore().markPackageApplied(input && input.packageId, actor.user, input && input.result); }
  catch (_) { return { ok: false, code: 'BRIDGE_UNAVAILABLE' }; }
});


ipcMain.handle('mobile-control:list-package-acks', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return { ok: true, acknowledgements: getMobileControlPlane().listPackageAcknowledgements(input && input.limit) }; }
  catch (error) { return { ok: false, code: error && error.code || 'ACK_LIST_FAILED' }; }
});
ipcMain.handle('mobile-control:create-package-ack', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileControlPlane().createPackageAcknowledgement(input && input.packageId, actor); }
  catch (error) { return { ok: false, code: error && error.code || 'ACK_CREATE_FAILED' }; }
});
ipcMain.handle('mobile-control:save-package-ack', async (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try {
    const ack = input && input.acknowledgement;
    const validation = getMobileControlPlane().verifyPackageAcknowledgement(ack);
    if (!validation || validation.ok !== true) return validation || { ok: false, code: 'ACK_INVALID' };
    const picked = await dialog.showSaveDialog(win, {
      title: 'Guardar acuse firmado de ProControl',
      defaultPath: `ProControl-acuse-${String(ack.packageId).slice(0,36)}.pcack`,
      filters: [{ name: 'Acuse ProControl (*.pcack)', extensions: ['pcack'] }]
    });
    if (picked.canceled || !picked.filePath) return { ok: false, canceled: true, code: 'CANCELLED' };
    const contents = JSON.stringify(ack, null, 2);
    const written = writeExportFileVerified(picked.filePath, contents, bytes => {
      let actual;
      try { actual = JSON.parse(bytes.toString('utf8')); } catch (_) { throw Object.assign(new Error('ACK_EXPORT_JSON_READBACK_FAILED'), { code: 'ACK_EXPORT_JSON_READBACK_FAILED' }); }
      const verified = getMobileControlPlane().verifyPackageAcknowledgement(actual);
      if (!verified || verified.ok !== true || actual.packageId !== ack.packageId) throw Object.assign(new Error('ACK_EXPORT_CRYPTOGRAPHIC_READBACK_FAILED'), { code: 'ACK_EXPORT_CRYPTOGRAPHIC_READBACK_FAILED' });
    });
    return { ok: true, fileName: path.basename(picked.filePath), bytes: written.bytes, sha256: written.sha256, validation };
  } catch (error) { return { ok: false, code: error && error.code || 'ACK_SAVE_FAILED' }; }
});
ipcMain.handle('mobile-control:list-transfer-history', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return { ok: true, transfers: getMobileControlPlane().listTransferHistory(input && input.transferId) }; }
  catch (error) { return { ok: false, code: error && error.code || 'TRANSFER_HISTORY_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-control:record-transfer-status', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileControlPlane().recordTransferStatus(input, actor); }
  catch (error) { return { ok: false, code: error && error.code || 'TRANSFER_STATUS_FAILED' }; }
});
ipcMain.handle('mobile-control:create-goods-dispatch-manifest', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileControlPlane().createGoodsDispatchManifest(input, actor); }
  catch (error) { return { ok:false, code:error && error.code || 'GOODS_DISPATCH_CREATE_FAILED' }; }
});
ipcMain.handle('mobile-control:confirm-goods-dispatch', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileControlPlane().confirmGoodsDispatch(input, actor); }
  catch (error) { return { ok:false, code:error && error.code || 'GOODS_DISPATCH_CONFIRM_FAILED' }; }
});
ipcMain.handle('mobile-control:cancel-goods-dispatch-manifest', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileControlPlane().cancelGoodsDispatchManifest(input, actor); }
  catch (error) { return { ok:false, code:error && error.code || 'GOODS_DISPATCH_CANCEL_FAILED' }; }
});
function resolveProVentaPosContext(value) {
  const raw = String(value || '').trim();
  const posId = raw.startsWith('pos:') ? raw.slice(4) : raw;
  if (!/^[A-Za-z0-9:_-]{1,160}$/.test(posId)) return null;
  return readCurrentPOSList().some(pos => String(pos && pos.id || '') === posId) ? posId : null;
}

ipcMain.handle('proventa:create-device-authorization', (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return actor ? { ok: false, code: 'OWNER_REQUIRED' } : denied();
  try {
    const data = input && typeof input === 'object' ? input : {};
    const posId = resolveProVentaPosContext(data.posId);
    if (!posId) return { ok: false, code: 'POS_CONTEXT_REQUIRED_OR_NOT_FOUND' };
    return getMobileBridgeStore().createDeviceAuthorization({ ...data, posId }, actor.user);
  }
  catch (error) { return { ok: false, code: error && error.code || 'DEVICE_AUTHORIZATION_CREATE_FAILED' }; }
});
ipcMain.handle('proventa:copy-activation-code', (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return { ok: false, code: 'OWNER_REQUIRED' };
  const activationCode = input && typeof input.activationCode === 'string' ? input.activationCode : '';
  if (activationCode.length < 46 || activationCode.length > 4006 ||
      !/^PVLA2:[0-9ABCDEFGHJKMNPQRSTVWXYZ]+$/.test(activationCode)) {
    return { ok: false, code: 'INVALID_ACTIVATION_CODE' };
  }
  try {
    clipboard.writeText(activationCode);
    return { ok: true };
  } catch (_) {
    return { ok: false, code: 'CLIPBOARD_WRITE_FAILED' };
  }
});

ipcMain.handle('proventa:generate-activation-code-from-pvid', async (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return actor ? { ok: false, code: 'OWNER_REQUIRED' } : denied();
  try {
    const data = input && typeof input === 'object' ? input : {};
    const posId = String(data.posId || '').trim();
    const currentPos = readCurrentPOSList().find(pos => pos.id === posId);
    if (!currentPos || !/^[A-Za-z0-9:_-]{1,160}$/.test(posId)) return { ok: false, code: 'POS_SCOPE_REQUIRED' };
    const employeeName = String(data.employeeName || '').trim();
    const employeeData = String(data.employeeData || '').trim();
    if (employeeName.length < 2 || employeeName.length > 100 || employeeData.length > 1000) return { ok: false, code: 'INVALID_EMPLOYEE_DATA' };
    const picked = await dialog.showOpenDialog(win, {
      title: `Seleccionar identidad .pvid para ${currentPos.name}`,
      properties: ['openFile'],
      filters: [{ name: 'Identidad segura de ProVenta (*.pvid)', extensions: ['pvid'] }]
    });
    if (picked.canceled || !picked.filePaths || !picked.filePaths.length) return { ok: false, canceled: true, code: 'CANCELLED' };
    const selected = picked.filePaths[0];
    const stat = fs.statSync(selected);
    if (!stat.isFile() || stat.size < 16 || stat.size > 64 * 1024) return { ok: false, code: 'PVID1_FILE_SIZE_INVALID' };
    const contents = fs.readFileSync(selected, 'utf8');
    const result = getMobileBridgeStore().createDeviceAuthorizationFromIdentity(contents, {
      employeeName,
      employeeData,
      posId,
      authorizedPosName: String(currentPos.name || '').trim().slice(0, 100),
      replacesAuthorizationId: data.replacesAuthorizationId || null
    }, actor.user);
    if (result && result.ok) result.fileName = path.basename(selected);
    return result;
  } catch (error) {
    return { ok: false, code: error && error.code || 'PROVENTA_PVID_ACTIVATION_FAILED', message: String(error && error.message || '').slice(0, 240) };
  }
});

ipcMain.handle('proventa:list-device-authorizations', (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return actor ? { ok: false, code: 'OWNER_REQUIRED' } : denied();
  try {
    const posId = resolveProVentaPosContext(input && input.posId);
    if (!posId) return { ok: false, code: 'POS_CONTEXT_REQUIRED_OR_NOT_FOUND' };
    return { ok: true, posId, installationId: getMobileBridgeStore().getInstallationId(), authorizations: getMobileBridgeStore().listDeviceAuthorizations(posId) };
  } catch (error) { return { ok: false, code: error && error.code || 'DEVICE_AUTHORIZATION_LIST_FAILED' }; }
});
ipcMain.handle('proventa:revoke-device-authorization', (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return actor ? { ok: false, code: 'OWNER_REQUIRED' } : denied();
  try {
    const expectedPosId = resolveProVentaPosContext(input && input.expectedPosId);
    if (!expectedPosId) return { ok: false, code: 'POS_CONTEXT_REQUIRED_OR_NOT_FOUND' };
    return getMobileBridgeStore().revokeDeviceAuthorization(input && input.authorizationId, actor.user, expectedPosId);
  } catch (error) { return { ok: false, code: error && error.code || 'DEVICE_AUTHORIZATION_REVOKE_FAILED' }; }
});
ipcMain.handle('proventa:import-device-enrollment', async (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return actor ? { ok: false, code: 'OWNER_REQUIRED' } : denied();
  try {
    const expectedPosId = resolveProVentaPosContext(input && input.expectedPosId);
    if (!expectedPosId) return { ok: false, code: 'POS_CONTEXT_REQUIRED_OR_NOT_FOUND' };
    const picked = await dialog.showOpenDialog(win, {
      title: 'Importar solicitud de vinculación de ProVenta', properties: ['openFile'],
      filters: [{ name: 'Solicitud de teléfono ProVenta (*.pcdevice)', extensions: ['pcdevice', 'json'] }]
    });
    if (picked.canceled || !picked.filePaths || !picked.filePaths.length) return { ok: false, canceled: true, code: 'CANCELLED' };
    const selected = picked.filePaths[0];
    const stat = fs.statSync(selected);
    if (!stat.isFile() || stat.size > 64 * 1024) return { ok: false, code: 'ENROLLMENT_REQUEST_TOO_LARGE' };
    const contents = fs.readFileSync(selected, 'utf8');
    const result = getMobileBridgeStore().importDeviceEnrollment(contents, actor.user, expectedPosId);
    if (result.ok) result.fileName = path.basename(selected);
    return result;
  } catch (error) { return { ok: false, code: error && error.code || 'DEVICE_ENROLLMENT_IMPORT_FAILED' }; }
});
ipcMain.handle('proventa:list-export-targets', (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return actor ? { ok: false, code: 'OWNER_REQUIRED' } : denied();
  try {
    const posId = resolveProVentaPosContext(input && input.posId);
    if (!posId) return { ok: false, code: 'POS_CONTEXT_REQUIRED_OR_NOT_FOUND' };
    const stored = readAppStoreKeys(['elite_pos']);
    const points = Array.isArray(stored.elite_pos) ? stored.elite_pos : [];
    const pos = points.find(item => item && typeof item === 'object' && !Array.isArray(item) && String(item.id || '') === posId);
    if (!pos || !String(pos.name || '')) return { ok: false, code: 'POS_NOT_FOUND' };
    return { ok: true, pointsOfSale: [{ id: posId, name: String(pos.name), inventoryCount: Array.isArray(pos.inventory) ? pos.inventory.length : 0 }] };
  } catch (error) { return { ok: false, code: error && error.code || 'POS_LIST_UNAVAILABLE' }; }
});
ipcMain.handle('proventa:export-inventory-snapshot', async (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return actor ? { ok: false, code: 'OWNER_REQUIRED' } : denied();
  try {
    const data = input && typeof input === 'object' ? input : {};
    const deviceId = String(data.deviceId || '');
    const posId = resolveProVentaPosContext(data.posId);
    if (!/^[A-Za-z0-9_-]{8,100}$/.test(deviceId) || !posId) return { ok: false, code: 'POS_CONTEXT_REQUIRED_OR_INVALID_EXPORT_TARGET' };
    const stored = readAppStoreKeys(['elite_pos', 'elite_product_catalog', 'elite_dollar_rate', 'pc_business_management_v1']);
    const today = new Date().toISOString().slice(0, 10);
    const latestRates = {};
    const rateRows = stored.pc_business_management_v1 && Array.isArray(stored.pc_business_management_v1.rates)
      ? stored.pc_business_management_v1.rates : [];
    rateRows.forEach((row, index) => {
      const currency = String(row && row.currency || '').toUpperCase();
      const date = String(row && row.date || '');
      const rate = Number(row && row.rate);
      if (!['USD', 'EUR', 'MLC'].includes(currency) ||
          !/^\d{4}-\d{2}-\d{2}$/.test(date) || date > today ||
          !Number.isFinite(rate) || rate <= 0) return;
      const previous = latestRates[currency];
      if (!previous || date > previous.date || (date === previous.date && index > previous.index)) {
        latestRates[currency] = { date, index, rate };
      }
    });
    const exchangeRates = {};
    Object.entries(latestRates).forEach(([currency, row]) => {
      exchangeRates[currency + '_CUP'] = row.rate;
    });
    const snapshot = buildProVentaInventorySnapshot({
      pointsOfSale: Array.isArray(stored.elite_pos) ? stored.elite_pos : [],
      productCatalog: Array.isArray(stored.elite_product_catalog) ? stored.elite_product_catalog : [],
      dollarRate: stored.elite_dollar_rate,
      exchangeRates,
      posId,
      installationId: getMobileBridgeStore().getInstallationId(),
      now: Date.now()
    });
    const picked = await dialog.showSaveDialog(win, {
      title: 'Guardar inventario cifrado para ProVenta',
      defaultPath: `ProVenta-Inventario-${String(snapshot.posName || posId).replace(/[^A-Za-z0-9_-]/g, '_')}-${new Date().toISOString().replace(/[:.]/g, '-')}.pcinv`,
      filters: [{ name: 'Paquete cifrado ProVenta (*.pcinv)', extensions: ['pcinv'] }]
    });
    if (picked.canceled || !picked.filePath) return { ok: false, canceled: true, code: 'CANCELLED' };
    const packageResult = getMobileBridgeStore().createDeviceBoundDataPackage({
      deviceId, posId, requestId: crypto.randomUUID(), type: 'inventory_snapshot', payload: snapshot
    }, actor.user);
    if (!packageResult || packageResult.ok !== true) return packageResult || { ok: false, code: 'DEVICE_DATA_PACKAGE_FAILED' };
    fs.writeFileSync(picked.filePath, packageResult.envelopeJson, { encoding: 'utf8', flag: 'w', mode: 0o600 });
    return {
      ok: true, fileName: path.basename(picked.filePath), packageId: packageResult.packageId,
      deviceId, posId, posName: snapshot.posName, productCount: snapshot.inventory.length,
      bytes: packageResult.bytes, expiresAt: packageResult.expiresAt, payloadHash: packageResult.payloadHash
    };
  } catch (error) {
    return { ok: false, code: error && error.code || 'INVENTORY_SNAPSHOT_EXPORT_FAILED', message: String(error && error.message || '').slice(0, 240) };
  }
});

ipcMain.handle('proventa:get-device-authorization-descriptor', (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return actor ? { ok: false, code: 'OWNER_REQUIRED' } : denied();
  try {
    const data = input && typeof input === 'object' ? input : {};
    const expectedPosId = resolveProVentaPosContext(data.expectedPosId || data.authorizedPosId);
    if (!expectedPosId) return { ok: false, code: 'POS_CONTEXT_REQUIRED_OR_NOT_FOUND' };
    const contents = getMobileBridgeStore().createDeviceAuthorizationDescriptor(data, actor.user);
    const descriptor = JSON.parse(contents);
    if (descriptor.authorizedPosId !== expectedPosId) return { ok: false, code: 'AUTHORIZATION_POS_SCOPE_MISMATCH' };
    const bytes = Buffer.byteLength(contents, 'utf8');
    if (bytes > 8192) return { ok: false, code: 'DEVICE_AUTHORIZATION_QR_TOO_LARGE' };
    const doc = JSON.parse(contents);
    return { ok: true, descriptor: contents, bytes, installationId: doc.installationId, expiresAt: doc.expiresAt };
  } catch (error) {
    return { ok: false, code: error && error.code || 'DEVICE_AUTHORIZATION_QR_FAILED' };
  }
});

ipcMain.handle('proventa:export-device-authorization', async (event, input) => {
  const actor = getOwnerPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return actor ? { ok: false, code: 'OWNER_REQUIRED' } : denied();
  try {
    const data = input && typeof input === 'object' ? input : {};
    const expectedPosId = resolveProVentaPosContext(data.expectedPosId || data.authorizedPosId);
    if (!expectedPosId) return { ok: false, code: 'POS_CONTEXT_REQUIRED_OR_NOT_FOUND' };
    const contents = getMobileBridgeStore().createDeviceAuthorizationDescriptor(data, actor.user);
    const doc = JSON.parse(contents);
    if (doc.authorizedPosId !== expectedPosId) return { ok: false, code: 'AUTHORIZATION_POS_SCOPE_MISMATCH' };
    const picked = await dialog.showSaveDialog(win, {
      title: 'Guardar autorización de ProVenta',
      defaultPath: `ProVenta-autorizacion-${String(doc.employeeName || 'trabajador').replace(/[^A-Za-z0-9_-]/g, '_')}.pcpair`,
      filters: [{ name: 'Autorización ProVenta (*.pcpair)', extensions: ['pcpair', 'json'] }]
    });
    if (picked.canceled || !picked.filePath) return { ok: false, canceled: true, code: 'CANCELLED' };
    fs.writeFileSync(picked.filePath, contents, { encoding: 'utf8', flag: 'wx', mode: 0o600 });
    return { ok: true, fileName: path.basename(picked.filePath), bytes: Buffer.byteLength(contents, 'utf8'), installationId: doc.installationId };
  } catch (error) { return { ok: false, code: error && error.code || 'DEVICE_AUTHORIZATION_EXPORT_FAILED' }; }
});
ipcMain.handle('mobile-control:authorize', (event, input) => authenticatePrivilegedUser(event, input));
ipcMain.handle('mobile-control:list-pos-policy', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return { ok: true, policies: getMobileControlPlane().listPOSPolicies(readCurrentPOSList()) }; }
  catch (error) { return { ok: false, code: error && error.code || 'CONTROL_PLANE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-control:set-pos-mode', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  const data = input && typeof input === 'object' ? input : {};
  const posId = String(data.posId || '');
  if (!readCurrentPOSList().some(p => p.id === posId)) return { ok: false, code: 'POS_NOT_FOUND' };
  try { return getMobileControlPlane().setPOSMode(data, actor); }
  catch (error) { return { ok: false, code: error && error.code || 'POS_MODE_CHANGE_FAILED' }; }
});
ipcMain.handle('mobile-control:install-pos-license', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  const data = input && typeof input === 'object' ? input : {};
  const pos = readCurrentPOSList().find(p => p.id === String(data.posId || ''));
  if (!pos) return { ok: false, code: 'POS_NOT_FOUND' };
  try { return getMobileControlPlane().installPointLicense({ posId: pos.id, posName: pos.name, token: data.token }, actor); }
  catch (error) { return { ok: false, code: error && error.code || 'POS_LICENSE_INSTALL_FAILED' }; }
});
ipcMain.handle('mobile-control:enable-pos-licensing', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileControlPlane().enablePointLicenseEnforcement(readCurrentPOSList(), actor); }
  catch (error) { return { ok: false, code: error && error.code || 'POS_LICENSING_ENABLE_FAILED' }; }
});
ipcMain.handle('mobile-control:can-desktop-sell', (event, input) => {
  if (!isAppSender(event) || !license.isLicensed()) return denied();
  try {
    const posId = normalizeSalesPOSId(input && input.posId || '');
    // No inicializar el puente ni migrar la clave en cada venta legacy SIN_APP.
    const snapshot = readMobileSalesPolicySnapshot();
    return resolveDesktopSalesGate(posId, snapshot, id => getMobileControlPlane().canDesktopSell(id));
  } catch (error) { return { ok: false, code: error && error.code || 'CONTROL_PLANE_UNAVAILABLE' }; }
});
ipcMain.handle('mobile-control:issue-shift-permit', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileControlPlane().issueShiftPermit(input, actor); }
  catch (error) { return { ok: false, code: error && error.code || 'SHIFT_PERMIT_ISSUE_FAILED' }; }
});
ipcMain.handle('mobile-control:list-shift-permits', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return { ok: true, permits: getMobileControlPlane().listShiftPermits(input && input.posId) }; }
  catch (error) { return { ok: false, code: error && error.code || 'SHIFT_PERMIT_LIST_FAILED' }; }
});
ipcMain.handle('mobile-control:list-pending-closures', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return { ok: true, closures: getMobileControlPlane().listPendingClosures(input && input.posId) }; }
  catch (error) { return { ok: false, code: error && error.code || 'CLOSURE_LIST_FAILED' }; }
});
ipcMain.handle('mobile-control:decide-pending-closure', (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try { return getMobileControlPlane().decidePendingClosure(input, actor); }
  catch (error) { return { ok: false, code: error && error.code || 'CLOSURE_DECISION_FAILED' }; }
});
ipcMain.handle('mobile-control:export-shift-permit', async (event, input) => {
  const actor = getPrivilegedActor(event, input);
  if (!actor || !license.isLicensed()) return denied();
  try {
    const permitId = String(input && input.permitId || '');
    const expectedPosId = String(input && input.posId || '');
    const expectedDeviceId = String(input && input.deviceId || '');
    if (!permitId || !expectedPosId || !expectedDeviceId) return { ok: false, code: 'SHIFT_PERMIT_EXPORT_SCOPE_REQUIRED' };
    const resolved = getMobileControlPlane().getShiftPermitForExport(permitId, { posId: expectedPosId, deviceId: expectedDeviceId });
    if (!resolved || resolved.ok !== true || !resolved.permit) return resolved || { ok: false, code: 'SHIFT_PERMIT_NOT_EXPORTABLE' };
    const permit = resolved.permit;
    const picked = await dialog.showSaveDialog(win, { title: 'Guardar permiso de turno', defaultPath: `ProControl-permiso-${permit.permitId}.pcpermit`, filters: [{ name: 'Permiso ProControl (*.pcpermit)', extensions: ['pcpermit'] }] });
    if (picked.canceled || !picked.filePath) return { ok: false, canceled: true, code: 'CANCELLED' };
    const contents = JSON.stringify(permit, null, 2);
    const written = writeExportFileVerified(picked.filePath, contents, bytes => {
      let exported;
      try { exported = JSON.parse(bytes.toString('utf8')); } catch (_) { throw Object.assign(new Error('PERMIT_EXPORT_JSON_READBACK_FAILED'), { code: 'PERMIT_EXPORT_JSON_READBACK_FAILED' }); }
      if (exported.permitId !== permitId || exported.posId !== expectedPosId || exported.deviceId !== expectedDeviceId ||
          exported.format !== 'procontrol.shift-permit' || exported.signature !== permit.signature) {
        throw Object.assign(new Error('PERMIT_EXPORT_READBACK_SCOPE_MISMATCH'), { code: 'PERMIT_EXPORT_READBACK_SCOPE_MISMATCH' });
      }
      const rechecked = getMobileControlPlane().getShiftPermitForExport(permitId, { posId: expectedPosId, deviceId: expectedDeviceId });
      if (!rechecked || rechecked.ok !== true || rechecked.permit.signature !== exported.signature) throw Object.assign(new Error('PERMIT_EXPORT_SIGNATURE_RECHECK_FAILED'), { code: 'PERMIT_EXPORT_SIGNATURE_RECHECK_FAILED' });
    });
    return { ok: true, fileName: path.basename(picked.filePath), bytes: written.bytes, sha256: written.sha256, status: resolved.status };
  } catch (error) { return { ok: false, code: error && error.code || 'PERMIT_EXPORT_FAILED', message: error && error.message || '' }; }
});


// Comprobación de integridad al iniciar. Este IPC es de solo lectura y devuelve solo estado/huellas,
// nunca texto descifrado; permite avisar al Dueño aunque aún no haya desbloqueado la bóveda.
ipcMain.handle('record-archive:startup-check', (event) => {
  if (!isAppSender(event)) return denied();
  try {
    const persisted = readAppStoreKeys(['elite_record_archive_index']);
    const index = persisted.elite_record_archive_index && typeof persisted.elite_record_archive_index === 'object'
      ? persisted.elite_record_archive_index : { version: 1, files: {}, records: {} };
    if (index.version !== 1 || !index.files || typeof index.files !== 'object') {
      return { ok: true, configured: false, indexInvalid: true, problemCount: 1, orphanCount: 0, problems: ['El índice de registros antiguos no tiene un formato válido. No se ha modificado nada.'] };
    }
    const allNames = Object.keys(index.files);
    const current = Object.entries(index.files).filter(([, meta]) => meta && !meta.superseded);
    const inspected = getRecordArchiveStore().inspectFiles(allNames);
    const observed = new Map((inspected.files || []).map(file => [file.fileName, file]));
    const problems = [];
    for (const [name, meta] of Object.entries(index.files)) {
      if (meta && meta.superseded) continue;
      const file = observed.get(name);
      if (!file) problems.push(`Falta el archivo indexado ${name}`);
      else if (!file.valid || file.sha256 !== meta.sha256) problems.push(`No coincide la huella de ${name}`);
    }
    const orphans = (inspected.files || []).filter(file => !file.indexed);
    return {
      ok: true,
      configured: allNames.length > 0,
      activeFileCount: current.length,
      indexedFileCount: allNames.length,
      problemCount: problems.length,
      orphanCount: orphans.length,
      problems: problems.slice(0, 20),
      excessProblems: Math.max(0, problems.length - 20)
    };
  } catch (error) {
    return { ok: false, code: error && error.code || 'ARCHIVE_STARTUP_CHECK_FAILED' };
  }
});

// Archivo histórico: el renderer cifra/descifra con WebCrypto. IPC solo persiste sobres cifrados.
ipcMain.handle('record-archive:list-files', (event, input) => {
  if (!requireArchiveOwner(event, input)) return { ok: false, code: 'OWNER_AUTH_REQUIRED' };
  try { return { ok: true, files: getRecordArchiveStore().listFiles() }; }
  catch (error) { return { ok: false, code: error && error.code || 'ARCHIVE_LIST_FAILED' }; }
});
ipcMain.handle('record-archive:read-file', (event, input) => {
  if (!requireArchiveOwner(event, input)) return { ok: false, code: 'OWNER_AUTH_REQUIRED' };
  try { return { ok: true, ...getRecordArchiveStore().readEncrypted(input && input.fileName) }; }
  catch (error) { return { ok: false, code: error && error.code || 'ARCHIVE_READ_FAILED' }; }
});
ipcMain.handle('record-archive:write-file', (event, input) => {
  if (!requireArchiveOwner(event, input)) return { ok: false, code: 'OWNER_AUTH_REQUIRED' };
  try { return getRecordArchiveStore().writeEncrypted(input); }
  catch (error) { return { ok: false, code: error && error.code || 'ARCHIVE_WRITE_FAILED' }; }
});
ipcMain.handle('record-archive:inspect', (event, input) => {
  if (!requireArchiveOwner(event, input)) return { ok: false, code: 'OWNER_AUTH_REQUIRED' };
  try { return { ok: true, ...getRecordArchiveStore().inspectFiles(input && input.indexedNames) }; }
  catch (error) { return { ok: false, code: error && error.code || 'ARCHIVE_INSPECT_FAILED' }; }
});
ipcMain.handle('record-archive:delete-superseded', (event, input) => {
  if (!requireArchiveOwner(event, input)) return { ok: false, code: 'OWNER_AUTH_REQUIRED' };
  try {
    const fileName = input && input.fileName;
    const persisted = readAppStoreKeys(['elite_record_archive_index']);
    const index = persisted.elite_record_archive_index && typeof persisted.elite_record_archive_index === 'object' ? persisted.elite_record_archive_index : null;
    const meta = index && index.files && index.files[fileName];
    if (!meta || meta.superseded !== true) return { ok: false, code: 'ARCHIVE_NOT_SUPERSEDED' };
    const stillReferenced = Object.values(index.records || {}).some(ref => ref && ref.fileName === fileName);
    if (stillReferenced) return { ok: false, code: 'ARCHIVE_STILL_REFERENCED' };
    if (String(input.expectedHash || '') !== String(meta.sha256 || '')) return { ok: false, code: 'ARCHIVE_INDEX_HASH_MISMATCH' };
    // No compactamos revisiones si falta o está alterado cualquier archivo vigente, o si hay restos sin indexar.
    // Esta última comprobación vive también en el proceso principal para no confiar en la UI.
    const indexedNames = Object.keys(index.files);
    const inspected = getRecordArchiveStore().inspectFiles(indexedNames);
    const observed = new Map((inspected.files || []).map(file => [file.fileName, file]));
    const active = Object.entries(index.files).filter(([, item]) => item && !item.superseded);
    const activeInvalid = active.some(([name, item]) => {
      const file = observed.get(name);
      return !file || !file.valid || file.sha256 !== item.sha256;
    });
    const hasOrphans = (inspected.files || []).some(file => !file.indexed);
    if (activeInvalid || hasOrphans) return { ok: false, code: 'ARCHIVE_COMPACTION_BLOCKED' };
    try { return getRecordArchiveStore().deleteEncrypted(fileName, meta.sha256); }
    catch (error) {
      if (error && (error.code === 'ARCHIVE_FILE_NOT_FOUND' || error.code === 'ENOENT')) return { ok: true, missing: true, fileName };
      throw error;
    }
  } catch (error) { return { ok: false, code: error && error.code || 'ARCHIVE_COMPACTION_FAILED' }; }
});



ipcMain.handle('license:status', (event) => {
  if (!isAppSender(event)) return denied();
  return license.status();
});

ipcMain.handle('license:activate-text', (event, text) => {
  if (!isAppSender(event)) return denied();
  const result = license.activateFromText(String(text || ''));
  if (result.ok) {
    refreshLicenseState();
    result.status = license.status();
  }
  return result;
});

// El proceso principal abre el dialogo y lee el archivo.
// NUNCA se acepta una ruta enviada por el renderer.
ipcMain.handle('license:activate-file', async (event) => {
  if (!isAppSender(event)) return denied();
  try {
    const picked = await dialog.showOpenDialog(win, {
      title: 'Elegir archivo de licencia',
      properties: ['openFile'],
      filters: [
        { name: 'Licencia de ProControl (*.lic)', extensions: ['lic'] },
        { name: 'Todos los archivos', extensions: ['*'] }
      ]
    });
    if (picked.canceled || !picked.filePaths || !picked.filePaths.length) {
      return { ok: false, canceled: true, code: 'CANCELADO', error: '' };
    }
    const result = license.activateFromFile(picked.filePaths[0]);
    if (result.ok) {
      refreshLicenseState();
      result.status = license.status();
    }
    return result;
  } catch (_) {
    return { ok: false, code: 'FORMATO', error: 'No se pudo abrir el archivo de licencia.' };
  }
});

ipcMain.handle('license:done', (event) => {
  if (!isAppSender(event)) return false;
  refreshLicenseState();
  loadRightPage();
  return true;
});

ipcMain.handle('license:open-support', (event) => {
  if (!isAppSender(event)) return false;
  shell.openExternal('https://wa.me/5356464332');
  return true;
});

ipcMain.handle('license:copy-device', (event) => {
  if (!isAppSender(event)) return false;
  try {
    const { clipboard } = require('electron');
    clipboard.writeText(license.getDeviceId());
    return true;
  } catch (_) { return false; }
});

// ---- Salir de la aplicacion DIRECTO (la confirmacion la pinta el renderer con su tema) ----
ipcMain.handle('app:exit-now', async (event) => {
  if (!isAppSender(event)) return false;
  try {
    win?.close();
    app.quit();
    return true;
  } catch (_) { return false; }
});

// (legado) confirmacion nativa: se conserva si alguien la llama, pero el renderer usa el modal propio
ipcMain.handle('app:exit-confirm', async (event) => {
  if (!isAppSender(event)) return false;

  try {
    const result = await dialog.showMessageBox(win, {
      type: 'question',
      title: 'Salir de ProControl',
      message: '¿Está seguro que desea salir de la aplicación?',
      detail: 'Puede volver a abrirla en cualquier momento desde el acceso directo.',
      buttons: ['Sí, salir', 'Cancelar'],
      defaultId: 1,
      cancelId: 1,
      noLink: true
    });
    if (result.response === 0) {
      app.quit();
    }
    return true;
  } catch (_) { return false; }
});

// ------------------------------------------------------------
// Arranque
// ------------------------------------------------------------
app.whenReady().then(() => {
  if (!gotSingleInstanceLock) return;

  migrateLegacyDatabase();
  refreshLicenseState();

  Menu.setApplicationMenu(null);
  registerAppProtocol();
  startWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) startWindow();
  });
});

app.on('window-all-closed', () => {
  app.quit();                            // app de escritorio: cerrar la ventana = salir
});

// Bloqueo de navegacion externa desde la ventana (defensa basica).
// Links reales se abren en el navegador del sistema con shell.openExternal.
app.on('web-contents-created', (_e, contents) => {
  contents.on('will-navigate', (event, url) => {
    if (url.startsWith('app://')) return;
    event.preventDefault();
  });

  // Sin herramientas de desarrollador ni recargas accidentales (modo cliente)
  contents.on('before-input-event', (event, input) => {
    if (!input.key) return;
    const k = input.key.toLowerCase();
    const isDevtoolsKey =
      input.control && input.shift && (k === 'i' || k === 'j' || k === 'c') ||
      k === 'f12';
    const isReloadKey =
      k === 'f5' ||
      (input.control && (k === 'r' || k === 'shift+r'));
    if (isDevtoolsKey || isReloadKey) event.preventDefault();
  });
});

// Log de errores a archivo para poder depurar ejecucion del cliente
process.on('uncaughtException', (err) => {
  try {
    fs.appendFileSync(path.join(app.getPath('userData'), 'main-errors.log'),
      `[${new Date().toISOString()}] ${err.stack || err.message}\n`);
  } catch (_) { /* sin salida */ }
  console.error(err);
});

// ------------------------------------------------------------
// splash:done: si no hay licencia, vuelve a license.html.
// ------------------------------------------------------------
ipcMain.handle('splash:done', (event) => {
  if (!isAppSender(event)) return false;
  if (!license.isLicensed()) {
    licensedState = false;
    if (win) win.loadURL('app://license.html');
    return false;
  }
  licensedState = true;
  if (win) win.loadURL('app://index.html');
  return true;
});

app.on('before-quit', () => { try { if (mobileBridgeStore) mobileBridgeStore.close(); } catch (_) {} });
