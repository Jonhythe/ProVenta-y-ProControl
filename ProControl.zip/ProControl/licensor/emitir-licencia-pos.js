#!/usr/bin/env node
'use strict';

// Emisor heredado de licencias POS. Permanece bloqueado durante esta rotación.
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const PRIVATE_PATH = path.join(__dirname, 'private', 'license_private.pem');
const ROTATION_LOCK_PATH = path.join(__dirname, 'ROTACION-CLAVE-REQUERIDA.txt');
const OUTPUT_DIR = path.join(__dirname, 'emitidas-pos');
const REGISTRY_PATH = path.join(__dirname, 'registro-licencias-pos.json');

function normalizeDeviceId(value) {
  const id = String(value || '').toUpperCase().replace(/[^0-9A-F]/g, '');
  return /^[0-9A-F]{32}$/.test(id) ? id : null;
}
function validPosId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9:_-]{1,160}$/.test(value);
}
function slug(value) {
  return String(value || 'pos').replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, '_').replace(/^[. ]+|[. ]+$/g, '').slice(0, 48) || 'pos';
}
function stamp(date) {
  const p = n => String(n).padStart(2, '0');
  return `${date.getFullYear()}${p(date.getMonth()+1)}${p(date.getDate())}-${p(date.getHours())}${p(date.getMinutes())}${p(date.getSeconds())}`;
}
function csvSafe(value) { return String(value ?? '').replace(/[\r\n,]/g, ' '); }
function readRegistry() {
  try {
    const data = JSON.parse(fs.readFileSync(REGISTRY_PATH, 'utf8'));
    if (data && data.version === 1 && Array.isArray(data.licenses)) return data;
  } catch (_) {}
  return { version: 1, licenses: [] };
}
function signPointLicense(payload, privateKeyInput) {
  if (!payload || payload.v !== 1 || payload.app !== 'procontrol' || payload.licenseType !== 'point-of-sale') throw new Error('INVALID_POS_LICENSE_PAYLOAD');
  if (!normalizeDeviceId(payload.deviceId) || !normalizeDeviceId(payload.installationMachineId) ||
      normalizeDeviceId(payload.installationMachineId) !== normalizeDeviceId(payload.deviceId) ||
      !validPosId(payload.posId) || typeof payload.posName !== 'string' || !payload.posName.trim() || payload.posName.length > 160) {
    throw new Error('INVALID_POS_LICENSE_SCOPE');
  }
  if (!['permanent', 'trial'].includes(payload.plan)) throw new Error('INVALID_LICENSE_PLAN');
  if (payload.plan === 'trial' && !Number.isFinite(Date.parse(String(payload.expiresAt || '')))) throw new Error('TRIAL_EXPIRY_REQUIRED');
  const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const signedData = Buffer.from('PCL1.' + payloadB64, 'ascii');
  const privateKey = privateKeyInput && privateKeyInput.type === 'private' ? privateKeyInput : crypto.createPrivateKey(privateKeyInput);
  if (privateKey.asymmetricKeyType !== 'ed25519') throw new Error('ED25519_KEY_REQUIRED');
  const signature = crypto.sign(null, signedData, privateKey).toString('base64url');
  return 'PCL1.' + payloadB64 + '.' + signature;
}
function issuePointLicense(options) {
  const data = options || {};
  const deviceId = normalizeDeviceId(data.deviceId);
  const posId = String(data.posId || '').trim();
  const posName = String(data.posName || '').trim();
  const customer = String(data.customer || '').trim();
  if (!deviceId) throw new Error('El ID de la PC debe tener 32 caracteres hexadecimales.');
  if (!validPosId(posId)) throw new Error('El ID del punto de venta no es válido.');
  if (!posName || posName.length > 160) throw new Error('El nombre del punto de venta debe tener entre 1 y 160 caracteres.');
  if (!customer || customer.length > 256) throw new Error('El cliente debe tener entre 1 y 256 caracteres.');
  const now = data.now instanceof Date ? data.now : new Date();
  let plan = 'permanent';
  let expiresAt;
  if (data.days !== undefined && data.days !== null) {
    const days = Number(data.days);
    if (!Number.isSafeInteger(days) || days < 1 || days > 3650) throw new Error('Los días de prueba deben ser un entero entre 1 y 3650.');
    plan = 'trial';
    expiresAt = new Date(now.getTime() + days * 86400000).toISOString();
  }
  const payload = {
    v: 1, app: 'procontrol', licenseType: 'point-of-sale',
    deviceId, installationMachineId: deviceId, posId, posName, plan, issuedAt: now.toISOString(),
    licenseId: crypto.randomBytes(8).toString('hex'), customer
  };
  if (expiresAt) payload.expiresAt = expiresAt;
  const token = signPointLicense(payload, data.privateKey);
  return { payload, token };
}
function usage() {
  console.log('Uso: node licensor/emitir-licencia-pos.js <ID_PC> <ID_POS> "<Nombre_POS>" "<Cliente>" [--dias N] [--force]');
  console.log('Ejemplo: node licensor/emitir-licencia-pos.js E5A913DBE60647098605531B320F5D5F5 POS_TIENDA_01 "Tienda principal" "Cliente"');
}
function main(argv) {
  if (fs.existsSync(ROTATION_LOCK_PATH)) throw new Error('Emisión bloqueada: completa la rotación indicada en licensor/ROTACION-CLAVE-REQUERIDA.txt.');
  throw new Error('Este emisor POS de consola está retirado durante la migración a la bóveda cifrada.');
  const args = [...argv];
  const flags = { days: null, force: false, positional: [] };
  for (let i=0; i<args.length; i++) {
    if (args[i] === '--force') flags.force = true;
    else if (args[i] === '--dias') flags.days = args[++i];
    else if (args[i].startsWith('--dias=')) flags.days = args[i].slice(7);
    else flags.positional.push(args[i]);
  }
  if (flags.positional.length < 4) { usage(); process.exitCode = 1; return; }
  if (!fs.existsSync(PRIVATE_PATH)) throw new Error('El emisor POS de consola está retirado mientras se migra a la bóveda cifrada. No se generó ninguna licencia.');
  const [deviceRaw, posRaw, posNameRaw, ...customerParts] = flags.positional;
  const customer = customerParts.join(' ').trim();
  const base = { deviceId: deviceRaw, posId: posRaw, posName: posNameRaw, customer };
  if (flags.days !== null) base.days = flags.days;
  const normalizedDevice = normalizeDeviceId(deviceRaw);
  const posId = String(posRaw || '').trim();
  const registry = readRegistry();
  const duplicate = registry.licenses.some(row => row && row.deviceId === normalizedDevice && row.posId === posId && row.status !== 'revoked');
  if (duplicate && !flags.force) throw new Error('Ya existe una licencia registrada para este equipo y punto. Use --force solo si está emitiendo una renovación autorizada.');
  const privateKey = crypto.createPrivateKey(fs.readFileSync(PRIVATE_PATH, 'utf8'));
  const result = issuePointLicense({ ...base, privateKey });
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  const fileName = `${slug(result.payload.customer)}_${slug(posId)}_${stamp(new Date())}.lic`;
  const outPath = path.join(OUTPUT_DIR, fileName);
  const tmp = outPath + `.tmp-${process.pid}`;
  fs.writeFileSync(tmp, result.token + '\r\n', { encoding: 'utf8', flag: 'wx', mode: 0o600 });
  fs.renameSync(tmp, outPath);
  registry.licenses.push({ issuedAt: result.payload.issuedAt, customer: result.payload.customer, deviceId: result.payload.deviceId, posId: result.payload.posId, posName: result.payload.posName, licenseId: result.payload.licenseId, plan: result.payload.plan, expiresAt: result.payload.expiresAt || null, fileName, status: 'issued' });
  const regTmp = REGISTRY_PATH + `.tmp-${process.pid}`;
  fs.writeFileSync(regTmp, JSON.stringify(registry, null, 2), { encoding:'utf8', flag:'wx', mode:0o600 });
  fs.renameSync(regTmp, REGISTRY_PATH);
  console.log('Licencia de punto de venta emitida correctamente.');
  console.log('Equipo: ' + result.payload.deviceId);
  console.log('Punto: ' + result.payload.posName + ' (' + result.payload.posId + ')');
  console.log('Plan: ' + result.payload.plan + (result.payload.expiresAt ? ' (vence ' + result.payload.expiresAt + ')' : ''));
  console.log('Archivo: ' + outPath);
  console.log('\n--- LICENCIA POS (copiar completa) ---\n' + result.token + '\n--- FIN DE LICENCIA POS ---');
}
if (require.main === module) {
  try { main(process.argv.slice(2)); }
  catch (error) { console.error('ERROR: ' + (error && error.message || 'No se pudo emitir la licencia.')); process.exitCode = 1; }
}
module.exports = { normalizeDeviceId, validPosId, signPointLicense, issuePointLicense, ROTATION_LOCK_PATH };
