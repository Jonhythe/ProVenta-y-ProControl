#!/usr/bin/env node
'use strict';

// Builds the owner-only permanent-license HTML from an encrypted PCKEY1 package.
// The encrypted package is embedded as ciphertext; the private PEM is never written.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function fail(message) {
  process.stderr.write(`ERROR: ${message}\n`);
  process.exit(1);
}

const [packagePath, templatePath, configPath, outputPath] = process.argv.slice(2);
if (![packagePath, templatePath, configPath, outputPath].every(Boolean)) {
  fail('Uso: node build-permanent-generator.js <package.pckey> <plantilla.html> <license-config.js> <salida.html>');
}

let pkg;
try {
  pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
} catch (_) {
  fail('No se pudo leer el paquete cifrado PCKEY1.');
}

if (!pkg || pkg.format !== 'PCKEY1' || pkg.kdf !== 'PBKDF2-SHA256' || pkg.cipher !== 'AES-256-GCM') {
  fail('El paquete no tiene el formato de emisor cifrado esperado.');
}
if (!Number.isInteger(Number(pkg.iterations)) || Number(pkg.iterations) < 300000 || Number(pkg.iterations) > 2000000) {
  fail('El número de iteraciones de protección no es válido.');
}
for (const [field, expectedLength] of [['salt', 16], ['iv', 12], ['tag', 16]]) {
  let bytes;
  try { bytes = Buffer.from(String(pkg[field] || ''), 'base64'); } catch (_) { fail(`Campo cifrado inválido: ${field}`); }
  if (bytes.length !== expectedLength) fail(`Longitud incorrecta del campo cifrado: ${field}`);
}
if (Buffer.from(String(pkg.ciphertext || ''), 'base64').length < 40) fail('El contenido cifrado está vacío o incompleto.');
if (JSON.stringify(pkg).includes('BEGIN PRIVATE KEY')) fail('Se detectó una clave privada en texto claro; se cancela la generación.');

let publicKey;
try { publicKey = crypto.createPublicKey(String(pkg.publicKeyPem || '')); }
catch (_) { fail('El paquete no contiene una clave pública válida.'); }
if (publicKey.asymmetricKeyType !== 'ed25519') fail('La clave pública no es Ed25519.');

const publicDer = publicKey.export({ type: 'spki', format: 'der' });
const fingerprint = crypto.createHash('sha256').update(publicDer).digest('hex');
if (String(pkg.publicFingerprint || '').toLowerCase() !== fingerprint) {
  fail('La huella SHA-256 no coincide con la clave pública del paquete.');
}

let config;
try { config = require(path.resolve(configPath)); }
catch (_) { fail('No se pudo cargar la configuración pública de ProControl.'); }
if (!config || String(config.LICENSE_PUBLIC_KEY_PEM || '').trim() !== String(pkg.publicKeyPem).trim()) {
  fail('El paquete del dueño y la clave pública integrada en ProControl no corresponden.');
}

const template = fs.readFileSync(templatePath, 'utf8');
const marker = 'const EMBEDDED_PACKAGE = null;';
if (template.split(marker).length !== 2) fail('La plantilla no contiene exactamente un marcador EMBEDDED_PACKAGE.');

const output = template.replace(marker, `const EMBEDDED_PACKAGE = ${JSON.stringify(pkg)};`);
if (!output.includes(`const EMBEDDED_PACKAGE = ${JSON.stringify(pkg)};`)) fail('No se pudo integrar el paquete cifrado.');
if (/id=["'](?:customer|plan)["']/i.test(output) || /Prueba de 1 hora|Prueba de 1 semana|expiresAt/.test(output)) {
  fail('La plantilla todavía contiene opciones de prueba o campos adicionales.');
}
if (!/plan:'permanent'/.test(output)) fail('El generador no fuerza la licencia permanente.');
if (output.includes('BEGIN PRIVATE KEY')) fail('El HTML contiene una clave privada en texto claro.');

fs.mkdirSync(path.dirname(path.resolve(outputPath)), { recursive: true });
fs.writeFileSync(outputPath, output, { encoding: 'utf8', mode: 0o600, flag: 'w' });
process.stdout.write('PERMANENT_OWNER_GENERATOR_CREATED\n');
process.stdout.write(`PUBLIC_KEY_FINGERPRINT=${fingerprint}\n`);
