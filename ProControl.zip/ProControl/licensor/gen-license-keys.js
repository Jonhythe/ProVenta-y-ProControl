#!/usr/bin/env node
// PROCONTROL — Rotación segura de claves Ed25519.
// La clave privada solo se guarda cifrada en ProControl-Emisor.pckey.
// El HTML del generador contiene una copia del mismo paquete CIFRADO.
'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const FORCE = process.argv.includes('--force');
const PRIVATE_DIR = path.join(__dirname, 'private');
const LEGACY_PRIVATE_PATH = path.join(PRIVATE_DIR, 'license_private.pem');
const PACKAGE_PATH = path.join(PRIVATE_DIR, 'ProControl-Emisor.pckey');
const PUBLIC_PATH = path.join(__dirname, 'license_public.pem');
const CONFIG_PATH = path.join(__dirname, '..', 'app', 'electron', 'license-config.js');
const LOCK_PATH = path.join(__dirname, 'ROTACION-CLAVE-REQUERIDA.txt');
const TEMPLATE_PATH = path.join(__dirname, 'Generador-Codigos-ProControl.template.html');
const GENERATOR_PATH = path.join(__dirname, 'Generador-Codigos-ProControl.html');
const ROTATION_HISTORY = path.join(__dirname, 'rotation-history');
const ITERATIONS = 600000;
const STAMP = new Date().toISOString().replace(/[:.]/g, '-');
const NONCE = `${process.pid}-${crypto.randomBytes(6).toString('hex')}`;
const staged = [];

function fail(message) { throw new Error(message); }

function fingerprint(publicPem) {
  const key = crypto.createPublicKey(publicPem);
  const der = key.export({ type: 'spki', format: 'der' });
  return crypto.createHash('sha256').update(der).digest('hex');
}

function assertPair(privatePem, publicPem) {
  const privateKey = crypto.createPrivateKey(privatePem);
  const publicKey = crypto.createPublicKey(publicPem);
  if (privateKey.asymmetricKeyType !== 'ed25519' || publicKey.asymmetricKeyType !== 'ed25519') fail('El par no es Ed25519.');
  const derived = crypto.createPublicKey(privateKey).export({ type: 'spki', format: 'der' });
  const supplied = publicKey.export({ type: 'spki', format: 'der' });
  if (!derived.equals(supplied)) fail('La clave privada y la pública no corresponden.');
  const challenge = crypto.randomBytes(48);
  const signature = crypto.sign(null, challenge, privateKey);
  if (!crypto.verify(null, challenge, publicKey, signature)) fail('Falló la prueba de firma/verificación.');
}

function renderConfig(publicPem) {
  const lines = publicPem.trim().split(/\r?\n/).map(line => `    '${line}'`);
  return [
    '// PROCONTROL — configuración pública de licencias.',
    '// Solo contiene la clave pública Ed25519. La privada nunca se integra en la aplicación.',
    '// Generado por licensor/gen-license-keys.js; no editar manualmente.',
    '',
    'module.exports = {',
    "  APP_ID: 'procontrol',",
    "  LICENSE_PREFIX: 'PCL1',",
    '  LICENSE_PUBLIC_KEY_PEM: [',
    lines.join(',\n'),
    "  ].join('\\n')",
    '};',
    ''
  ].join('\n');
}

function b64(buffer) { return Buffer.from(buffer).toString('base64'); }

function createEncryptedPackage(privatePem, publicPem, password) {
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const key = crypto.pbkdf2Sync(password, salt, ITERATIONS, 32, 'sha256');
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(Buffer.from(privatePem, 'utf8')), cipher.final()]);
  const publicFingerprint = fingerprint(publicPem);
  const pkg = {
    format: 'PCKEY1',
    kdf: 'PBKDF2-SHA256',
    cipher: 'AES-256-GCM',
    iterations: ITERATIONS,
    salt: b64(salt),
    iv: b64(iv),
    tag: b64(cipher.getAuthTag()),
    ciphertext: b64(encrypted),
    publicKeyPem: publicPem.trim(),
    publicFingerprint,
    createdAt: new Date().toISOString()
  };
  // Desencripta y comprueba la pareja antes de permitir cualquier escritura.
  const checkKey = crypto.pbkdf2Sync(password, salt, ITERATIONS, 32, 'sha256');
  const decipher = crypto.createDecipheriv('aes-256-gcm', checkKey, iv);
  decipher.setAuthTag(cipher.getAuthTag());
  const plain = Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
  assertPair(plain, publicPem);
  return pkg;
}

function readHidden(promptText) {
  if (process.env.NODE_ENV === 'test' && process.env.PROCONTROL_TEST_KEY_PASSWORD) return process.env.PROCONTROL_TEST_KEY_PASSWORD;
  const input = process.stdin;
  if (!input.isTTY || typeof input.setRawMode !== 'function') {
    fail('Abre configurar-claves.bat desde la consola de Windows. La contraseña se introduce sin mostrarse en pantalla.');
  }
  process.stdout.write(promptText);
  input.setRawMode(true);
  input.resume();
  let value = '';
  try {
    const one = Buffer.alloc(1);
    while (true) {
      const count = fs.readSync(input.fd, one, 0, 1, null);
      if (!count) continue;
      const c = one[0];
      if (c === 3) fail('Operación cancelada.');
      if (c === 13 || c === 10) break;
      if (c === 8 || c === 127) { value = value.slice(0, -1); continue; }
      if (c >= 32 && c <= 126) value += String.fromCharCode(c);
    }
  } finally {
    input.setRawMode(false);
    process.stdout.write('\n');
  }
  return value;
}

function getPassword() {
  if (process.env.GITHUB_ACTIONS === 'true') {
    const password = String(process.env.PROCONTROL_KEY_PASSWORD || '');
    if (password.length < 20) {
      fail('Falta PROCONTROL_KEY_PASSWORD o tiene menos de 20 caracteres. No se modificó ninguna clave.');
    }
    return password;
  }
  const first = readHidden('Crea una contraseña nueva (mínimo 16 caracteres): ');
  if (first.length < 16) fail('La contraseña debe tener al menos 16 caracteres. No se modificó ninguna clave.');
  const second = readHidden('Repite la contraseña: ');
  if (first !== second) fail('Las contraseñas no coinciden. No se modificó ninguna clave.');
  return first;
}

function stageFile(target, contents, mode = 0o600) {
  fs.mkdirSync(path.dirname(target), { recursive: true });
  const tmp = `${target}.stage-${NONCE}`;
  fs.writeFileSync(tmp, contents, { encoding: 'utf8', flag: 'wx', mode });
  staged.push(tmp);
  return tmp;
}

function replaceFromStage(stage, target) {
  try { fs.rmSync(target, { force: true }); } catch (_) {}
  fs.renameSync(stage, target);
  const index = staged.indexOf(stage);
  if (index >= 0) staged.splice(index, 1);
}

function backupPublicConfigurationOnly() {
  const existing = [PUBLIC_PATH, CONFIG_PATH].filter(file => fs.existsSync(file));
  if (!existing.length) return null;
  fs.mkdirSync(ROTATION_HISTORY, { recursive: true, mode: 0o700 });
  const targetDir = path.join(ROTATION_HISTORY, `${STAMP}-${NONCE}`);
  fs.mkdirSync(targetDir, { recursive: false, mode: 0o700 });
  for (const file of existing) {
    const base = file === PUBLIC_PATH ? 'license_public.pem' : 'license-config.js';
    fs.copyFileSync(file, path.join(targetDir, base), fs.constants.COPYFILE_EXCL);
  }
  const metadata = [
    'ProControl — respaldo de configuración pública previo a la rotación.',
    `Fecha UTC: ${new Date().toISOString()}`,
    `Fingerprint público anterior SHA-256: ${fs.existsSync(PUBLIC_PATH) ? fingerprint(fs.readFileSync(PUBLIC_PATH, 'utf8')) : 'no disponible'}`,
    'Solo se respaldó información pública.',
    'La clave privada anterior se considera comprometida y nunca debe restaurarse.'
  ].join('\n') + '\n';
  fs.writeFileSync(path.join(targetDir, 'INFO.txt'), metadata, { encoding: 'utf8', flag: 'wx', mode: 0o600 });
  return targetDir;
}

function main() {
  if (!fs.existsSync(LOCK_PATH)) fail('No existe ROTACION-CLAVE-REQUERIDA.txt. No se realizará una rotación sin bloqueo explícito.');
  const existingLegacyPrivate = fs.existsSync(LEGACY_PRIVATE_PATH);
  if (fs.existsSync(PACKAGE_PATH)) fail('Ya existe ProControl-Emisor.pckey. Por seguridad, este configurador solo crea el primer par y no debe ejecutarse de nuevo para evitar invalidar licencias ya emitidas.');
  if (existingLegacyPrivate && !FORCE) fail('Se encontró la clave privada antigua. Ejecuta configurar-claves.bat para confirmar la rotación.');
  if (!fs.existsSync(CONFIG_PATH)) fail('No se encuentra app/electron/license-config.js.');
  if (!fs.existsSync(TEMPLATE_PATH)) fail('No se encuentra Generador-Codigos-ProControl.template.html.');

  const password = getPassword();
  const oldPublicExists = fs.existsSync(PUBLIC_PATH) || fs.existsSync(CONFIG_PATH);
  const backupDir = oldPublicExists ? backupPublicConfigurationOnly() : null;
  const pair = crypto.generateKeyPairSync('ed25519');
  const privatePem = pair.privateKey.export({ type: 'pkcs8', format: 'pem' });
  const publicPem = pair.publicKey.export({ type: 'spki', format: 'pem' });
  assertPair(privatePem, publicPem);
  const pkg = createEncryptedPackage(privatePem, publicPem, password);
  const packageText = JSON.stringify(pkg, null, 2) + '\n';
  const configText = renderConfig(publicPem);
  let html = fs.readFileSync(TEMPLATE_PATH, 'utf8');
  if (!html.includes('const EMBEDDED_PACKAGE = null;')) fail('La plantilla HTML no contiene el marcador EMBEDDED_PACKAGE esperado.');
  html = html.replace('const EMBEDDED_PACKAGE = null;', `const EMBEDDED_PACKAGE = ${JSON.stringify(pkg)};`);
  if (!html.includes(`const EMBEDDED_PACKAGE = ${JSON.stringify(pkg)};`)) fail('No se pudo integrar el paquete cifrado en el generador HTML.');

  const packageStage = stageFile(PACKAGE_PATH, packageText, 0o600);
  const publicStage = stageFile(PUBLIC_PATH, publicPem, 0o600);
  const configStage = stageFile(CONFIG_PATH, configText, 0o600);
  const htmlStage = stageFile(GENERATOR_PATH, html, 0o600);

  // Comprobación de archivos preparados antes de reemplazar el conjunto activo.
  const stagedPkg = JSON.parse(fs.readFileSync(packageStage, 'utf8'));
  if (stagedPkg.publicFingerprint !== fingerprint(fs.readFileSync(publicStage, 'utf8'))) fail('El paquete cifrado no coincide con la clave pública preparada.');
  if (!fs.readFileSync(configStage, 'utf8').includes(publicPem.trim().split(/\r?\n/)[1])) fail('La configuración de ProControl no contiene la nueva clave pública.');

  replaceFromStage(packageStage, PACKAGE_PATH);
  replaceFromStage(publicStage, PUBLIC_PATH);
  replaceFromStage(configStage, CONFIG_PATH);
  replaceFromStage(htmlStage, GENERATOR_PATH);

  // La clave anterior se elimina del árbol de trabajo después de instalar y verificar
  // el nuevo conjunto. La eliminación no revoca copias previas: eso lo hace la nueva pública.
  try { fs.rmSync(LEGACY_PRIVATE_PATH, { force: true }); } catch (_) { fail('No se pudo retirar license_private.pem antiguo. Mantén bloqueada la emisión y elimínalo manualmente.'); }
  if (fs.existsSync(LEGACY_PRIVATE_PATH)) fail('La clave antigua sigue presente. No utilices el generador.');

  delete require.cache[require.resolve(CONFIG_PATH)];
  const freshConfig = require(CONFIG_PATH);
  if (freshConfig.LICENSE_PUBLIC_KEY_PEM.trim() !== publicPem.trim()) fail('La clave pública instalada no coincide con la configuración de ProControl.');
  const embeddedMatch = fs.readFileSync(GENERATOR_PATH, 'utf8').match(/const EMBEDDED_PACKAGE = (\{[\s\S]*?\});/);
  if (!embeddedMatch || JSON.parse(embeddedMatch[1]).publicFingerprint !== pkg.publicFingerprint) fail('El generador HTML no quedó vinculado a la nueva clave.');

  console.log('\nROTACIÓN COMPLETADA.');
  console.log('Nueva pareja Ed25519 generada y verificada.');
  console.log(`Huella SHA-256 pública: ${pkg.publicFingerprint}`);
  console.log('Clave pública integrada en app/electron/license-config.js.');
  console.log('Clave privada guardada únicamente cifrada en licensor/private/ProControl-Emisor.pckey.');
  console.log('El HTML del generador ya incluye ese paquete CIFRADO y no necesita seleccionar archivos.');
  console.log('Abre licensor/Generador-Codigos-ProControl.html, desbloquéalo con tu contraseña y pega el ID del cliente.');
  console.log('Guarda una copia de ProControl-Emisor.pckey y recuerda la contraseña: sin ambas no podrás emitir licencias.');
  console.log('El bloqueo de los emisores antiguos por consola permanece activo.');
  if (backupDir) console.log(`Configuración pública antigua respaldada en: ${path.relative(path.join(__dirname, '..'), backupDir)}`);
}

try { main(); }
catch (error) {
  console.error(`\nERROR: ${error && error.message ? error.message : 'No se pudo completar la rotación.'}`);
  console.error('No retires el bloqueo de rotación. Revisa los archivos antes de volver a intentarlo.');
  process.exitCode = 1;
} finally {
  for (const file of staged) { try { fs.rmSync(file, { force: true }); } catch (_) {} }
}
