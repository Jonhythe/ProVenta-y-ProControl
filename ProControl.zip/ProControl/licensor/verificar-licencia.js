#!/usr/bin/env node
// ============================================================
// PROCONTROL - VERIFICADOR DE LICENCIAS (solo para el vendedor)
// ============================================================
// Uso:
//   node verificar-licencia.js <licencia-o-archivo.lic> <ID>
//
// Comprueba formato, firma Ed25519, app, plan, PC y vencimiento.
// Sale con codigo 0 si es valida; distinto de 0 si no.
// ============================================================
'use strict';

const fs = require('fs');
const path = require('path');

const core = require(path.join(__dirname, '..', 'app', 'electron', 'license-core.js'));
const config = require(path.join(__dirname, '..', 'app', 'electron', 'license-config.js'));

function normalizeId(value) {
  const clean = String(value || '').toUpperCase().replace(/[^0-9A-F]/g, '');
  return clean.length === 32 ? clean : null;
}

const args = process.argv.slice(2);
if (args.length < 2) {
  console.log('Uso: node verificar-licencia.js <licencia-o-archivo.lic> <ID>');
  process.exit(1);
}

let text = args[0];
try {
  if (fs.existsSync(text) && fs.statSync(text).isFile()) {
    text = fs.readFileSync(text, 'utf8');
  }
} catch (_) { /* se usa tal cual */ }

const id = normalizeId(args[1]);
if (!id) {
  console.error('ERROR: el ID debe tener 32 caracteres hexadecimales.');
  process.exit(1);
}

const result = core.verifyLicense(text, {
  publicKey: config.LICENSE_PUBLIC_KEY_PEM,
  deviceId: id,
  now: Date.now()
});

if (!result.ok) {
  console.error('LICENCIA INVALIDA [' + result.code + ']: ' + result.error);
  process.exit(1);
}

console.log('LICENCIA VALIDA.');
console.log('Cliente:  ' + (result.payload.customer || '(sin nombre)'));
console.log('ID PC:    ' + result.payload.deviceId);
console.log('Plan:     ' + result.payload.plan + (result.payload.expiresAt ? ' (vence ' + result.payload.expiresAt + ')' : ''));
console.log('Emitida:  ' + result.payload.issuedAt);
console.log('LicenseID:' + result.payload.licenseId);
process.exit(0);
