#!/usr/bin/env node
// ============================================================
// PROCONTROL - EMISOR DE LICENCIAS (solo para el vendedor)
// ============================================================
// Uso:
//   node emitir-licencia.js <ID> "<Cliente>" [--dias N] [--force]
//
// - <ID>: MachineGuid de la PC del cliente (32 hexadecimales).
// - Sin --dias: licencia permanente.
// - Con --dias N: licencia de prueba que vence en N dias.
// - Reemision del mismo ID o cliente con mas de 2 IDs distintos
//   en 12 meses: exige --force.
//
// Emisor heredado de consola: permanece bloqueado. La vía aprobada es el HTML seguro.
// ============================================================
'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const APP_VERSION = '1.2.0';
const PRIVATE_PATH = path.join(__dirname, 'private', 'license_private.pem');
const ROTATION_LOCK_PATH = path.join(__dirname, 'ROTACION-CLAVE-REQUERIDA.txt');
const OUTPUT_DIR = path.join(__dirname, 'emitidas');
const CSV_PATH = path.join(__dirname, 'registro-ventas.csv');
const CSV_HEADER = 'fecha,cliente,deviceId,licenseId,plan,expiresAt,version';

function usage() {
  console.log('Uso: node emitir-licencia.js <ID> "<Cliente>" [--dias N] [--force]');
  console.log('Ejemplo: node emitir-licencia.js E5A913DBE60647098605531B320F5D5F "Bodega La Habana"');
}

function normalizeId(value) {
  const clean = String(value || '').toUpperCase().replace(/[^0-9A-F]/g, '');
  return clean.length === 32 ? clean : null;
}

function parseArgs(argv) {
  const out = { force: false, dias: null, positional: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--force') {
      out.force = true;
    } else if (a === '--modo-con-app') {
      throw new Error('CON APP permanece bloqueado hasta que exista la app móvil y se completen las pruebas de extremo a extremo.');
    } else if (a === '--dias') {
      out.dias = argv[++i];
    } else if (a.indexOf('--dias=') === 0) {
      out.dias = a.slice('--dias='.length);
    } else {
      out.positional.push(a);
    }
  }
  return out;
}

// Parser CSV minimo (soporta campos entre comillas con comas y comillas dobles).
function parseCsvLine(line) {
  const fields = [];
  let current = '';
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (quoted) {
      if (ch === '"' && line[i + 1] === '"') { current += '"'; i++; }
      else if (ch === '"') { quoted = false; }
      else { current += ch; }
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ',') {
      fields.push(current); current = '';
    } else {
      current += ch;
    }
  }
  fields.push(current);
  return fields;
}

function csvEscape(value) {
  const s = value === null || value === undefined ? '' : String(value);
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function readRegistry() {
  if (!fs.existsSync(CSV_PATH)) return [];
  let raw;
  try {
    raw = fs.readFileSync(CSV_PATH, 'utf8');
  } catch (_) {
    return [];
  }
  const lines = raw.split(/\r?\n/).filter(function (l) { return l.trim() !== ''; });
  if (lines.length < 2) return [];
  return lines.slice(1).map(function (line) {
    const f = parseCsvLine(line);
    return {
      fecha: f[0] || '',
      cliente: f[1] || '',
      deviceId: f[2] || '',
      licenseId: f[3] || '',
      plan: f[4] || '',
      expiresAt: f[5] || '',
      version: f[6] || ''
    };
  });
}

function appendRegistry(row) {
  if (!fs.existsSync(CSV_PATH)) {
    fs.writeFileSync(CSV_PATH, CSV_HEADER + '\r\n', 'utf8');
  } else {
    const st = fs.statSync(CSV_PATH);
    if (st.size > 0) {
      const fd = fs.openSync(CSV_PATH, 'r');
      const buf = Buffer.alloc(1);
      fs.readSync(fd, buf, 0, 1, st.size - 1);
      fs.closeSync(fd);
      if (buf.toString('utf8') !== '\n') fs.appendFileSync(CSV_PATH, '\r\n', 'utf8');
    }
  }
  const line = [
    row.fecha, row.cliente, row.deviceId, row.licenseId, row.plan, row.expiresAt, row.version
  ].map(csvEscape).join(',');
  fs.appendFileSync(CSV_PATH, line + '\r\n', 'utf8');
}

function slug(value) {
  const clean = String(value || 'cliente')
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, '_')
    .replace(/^[. ]+|[. ]+$/g, '')
    .slice(0, 48);
  return clean || 'cliente';
}

function stamp(date) {
  const p = function (n) { return String(n).padStart(2, '0'); };
  return String(date.getFullYear()) + p(date.getMonth() + 1) + p(date.getDate()) +
    '-' + p(date.getHours()) + p(date.getMinutes()) + p(date.getSeconds());
}

function buildLicense(id, customer, dias, force) {
  if (!fs.existsSync(PRIVATE_PATH)) {
    console.error('ERROR: el emisor de consola está retirado. Usa licensor/Generador-Codigos-ProControl.html.');
    process.exit(1);
  }

  const now = new Date();
  let expiresAt = null;
  let plan = 'permanent';

  if (dias !== null) {
    const n = Number(dias);
    if (!Number.isInteger(n) || n <= 0) {
      console.error('ERROR: --dias debe ser un numero entero mayor que 0.');
      process.exit(1);
    }
    plan = 'trial';
    expiresAt = new Date(now.getTime() + n * 24 * 60 * 60 * 1000).toISOString();
  }

  // ---- Avisos de reemision / exceso de IDs ----
  const rows = readRegistry();
  const sameId = rows.filter(function (r) { return normalizeId(r.deviceId) === id; });
  const clientKey = customer.trim().toLowerCase();
  const cutoff = now.getTime() - 365 * 24 * 60 * 60 * 1000;
  const recentIds = new Set(
    rows
      .filter(function (r) {
        const t = Date.parse(r.fecha);
        return r.cliente.trim().toLowerCase() === clientKey && Number.isFinite(t) && t >= cutoff;
      })
      .map(function (r) { return normalizeId(r.deviceId); })
      .filter(Boolean)
  );

  let blocked = false;
  if (sameId.length > 0) {
    console.warn('AVISO: este ID ya aparece en registro-ventas.csv (' + sameId.length + ' vez/veces). Es una REEMISION.');
    blocked = true;
  }
  if (recentIds.size > 2) {
    console.warn('AVISO: el cliente "' + customer + '" ya tiene ' + recentIds.size +
      ' IDs distintos en los ultimos 12 meses (politica: 1 o 2 reemisiones gratis al año).');
    blocked = true;
  }
  if (blocked && !force) {
    console.error('Para emitir igualmente, repita el comando con --force.');
    process.exit(1);
  }

  const licenseId = crypto.randomBytes(8).toString('hex');
  const payload = {
    v: 1,
    app: 'procontrol',
    licenseType: 'installation',
    modules: ['core', 'inventory', 'purchases', 'pos', 'closings', 'reports'],
    allowedModes: ['SIN_APP'],
    deviceId: id,
    plan: plan,
    issuedAt: now.toISOString()
  };
  if (expiresAt) payload.expiresAt = expiresAt;
  payload.licenseId = licenseId;
  payload.customer = customer;

  const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const signedData = Buffer.from('PCL1.' + payloadB64, 'ascii');

  let privateKey;
  try {
    privateKey = crypto.createPrivateKey(fs.readFileSync(PRIVATE_PATH, 'utf8'));
  } catch (_) {
    console.error('ERROR: no se pudo leer o interpretar la clave privada.');
    process.exit(1);
  }

  const signature = crypto.sign(null, signedData, privateKey);
  const licenseText = 'PCL1.' + payloadB64 + '.' + signature.toString('base64url');

  // ---- Guardar .lic ----
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  const fileName = slug(customer) + '_' + id.slice(0, 8) + '_' + stamp(now) + '.lic';
  const outPath = path.join(OUTPUT_DIR, fileName);
  fs.writeFileSync(outPath, licenseText + '\r\n', 'utf8');

  // ---- Registro ----
  appendRegistry({
    fecha: now.toISOString(),
    cliente: customer,
    deviceId: id,
    licenseId: licenseId,
    plan: plan,
    expiresAt: expiresAt || '',
    version: APP_VERSION
  });

  return { payload: payload, licenseText: licenseText, outPath: outPath };
}

function main() {
  if (fs.existsSync(ROTATION_LOCK_PATH)) throw new Error('Emisión bloqueada: completa la rotación indicada en licensor/ROTACION-CLAVE-REQUERIDA.txt.');
  throw new Error('Este emisor de consola fue retirado. Abre licensor/Generador-Codigos-ProControl.html para emitir códigos.');
  const args = parseArgs(process.argv.slice(2));
  if (args.positional.length < 2) {
    usage();
    process.exit(1);
  }

  const id = normalizeId(args.positional[0]);
  if (!id) {
    console.error('ERROR: el ID de la PC debe tener exactamente 32 caracteres hexadecimales (0-9, A-F).');
    process.exit(1);
  }

  const customer = args.positional.slice(1).join(' ').trim();
  if (!customer) {
    console.error('ERROR: falta el nombre del cliente.');
    process.exit(1);
  }

  const result = buildLicense(id, customer, args.dias, args.force);

  console.log('');
  console.log('Licencia emitida correctamente.');
  console.log('Cliente: ' + result.payload.customer);
  console.log('ID PC:   ' + result.payload.deviceId);
  console.log('Plan:    ' + result.payload.plan + (result.payload.expiresAt ? ' (vence ' + result.payload.expiresAt + ')' : ''));
  console.log('Módulos: ' + result.payload.modules.join(', '));
  console.log('Modos permitidos: ' + result.payload.allowedModes.join(', '));
  console.log('Archivo: ' + result.outPath);
  console.log('');
  console.log('--- LICENCIA (copiela completa) ---');
  console.log(result.licenseText);
  console.log('--- FIN DE LA LICENCIA ---');
}

if (require.main === module) {
  try { main(); }
  catch (error) {
    console.error('ERROR: ' + String(error && error.message || 'No se pudo procesar la emisión.'));
    process.exitCode = 1;
  }
}

module.exports = { parseArgs, normalizeId, ROTATION_LOCK_PATH };
